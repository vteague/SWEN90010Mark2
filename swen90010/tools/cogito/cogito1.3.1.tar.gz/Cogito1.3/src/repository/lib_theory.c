/* 
 Copyright (C) 1999
 Software Verification Research Centre
 The University of Queensland
 Australia 4072

 email: svrc@cs.uq.oz.au

 The Cogito 1.3 Software and Documentation  

 Cogito 1.3 COPYRIGHT, LICENCE AND DISCLAIMER NOTICE.
 
 Copyright 1999 by The University of Queensland, Queensland 4072 Australia
 
 Permission to use, copy and distribute this software and associated
 documentation for any non-commercial purpose and without fee is hereby 
 granted, subject to the following conditions:
 
 1. 	that the above copyright notice and this permission notice and 
	warranty disclaimer appear in all copies and in supporting 
	documentation;

 2.	that the name of "The University of Queensland" not be used in 
	advertising or publicity pertaining to distribution of the software 
	without specific, written prior permission; 

 3.	that users of this software shall be responsible for determining the 
	fitness of the software for the purposes for which the software is 
	employed by them; 

 4. 	that no changes to the system or documentation are subsequently 
	made available to third parties or redistributed without prior 
	written consent from the SVRC; and

 5. 	that individuals, groups or institutions using this software register 
	their use with the SVRC.
 
 The University of Queensland disclaims all warranties with regard to this
 software including all implied warranties of merchantability and fitness
 to the extent permitted by law. In no event shall the University of 
 Queensland be liable for any special, indirect or consequential damages or 
 any damages whatsoever resulting from loss of use, data or profits, whether 
 in an action of contract, negligence or other tortious action, arising out 
 of or in connection with the use or performance of this software.

 THE UNIVERSITY OF QUEENSLAND MAKES NO REPRESENTATIONS ABOUT THE ACCURACY OR
 SUITABILITY OF THIS MATERIAL FOR ANY PURPOSE.  IT IS PROVIDED "AS IS",
 WITHOUT ANY EXPRESSED OR IMPLIED WARRANTIES.


For information on commercial use of this software contact the SVRC.
*/

/*library manager prototype: External C routines for C compilation and execution
Tue Oct  4 17:12:33 EST 1994
Copyright (C) 1994 Owen Traynor SVRC
*/

#include "structures.h" 
#include "grammar.h"
#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>

#define APP1 SIGUSR1
#define APP2 SIGUSR2


#define NMODS 20
#define STRSIZE 256
#define TRUE 1
#define FALSE 0
#define ERGODIR "ergo"
#define ERGOPIDFILE "ergo-loaded"

int ErgoPID = -1;

static int StartUpTries = 0;

char * Create_Proof(pname)
char * pname;
{
char *path;
char pfname[STRSIZE];
FILE * fp;

path = getenv("REPOSPATH");
if(path == (char *)NULL) path = "./";

sprintf(pfname,"%s/%s", path, pname);

if ((fp = fopen(pfname, "w")) == (FILE *)NULL){
	printf("Can't create proof file %s \n", pname);
	return(pname);
}
fclose(fp);
return(pname);
}

int CheckForErgoPID(){
FILE *fp;
int pid;

char * path;
char erfile[STRSIZE];
    path = getenv("REPOSPATH");
    if(path == (char *)NULL) path = "./";
    sprintf(erfile, "%s/ergo/%s", path, ERGOPIDFILE);
    if( (fp = fopen(ERGOPIDFILE, "r")) == (FILE *)NULL) return(-1);
    fscanf(fp, "%d", &pid);
    fclose(fp);
    return(pid);
}

#define TRIES 5
int GetErgoPID()
{
/* Tries TRIES times to get the PID of ergo and then aborts */

int tries = 0; 
int ergopid = -1;

    for ( ; (ergopid == -1) && (tries <= TRIES); tries++)
        if ( (ergopid = CheckForErgoPID()) == -1) sleep(2);
    return(ergopid);
}

int CdCRepdir(dirnm)
char * dirnm;
{
	int status;
        char *path, fpath[STRSIZE];
	fpath[0] = NULL;
        path = getenv("REPOSPATH");
        if(path == NULL) path = "./";
	strcat (fpath, path);
	strcat (fpath, "/");
	strcat (fpath, dirnm);
	
	status = chdir(fpath);
	if (status == -1) {
		mkdir(fpath, S_IRWXU | S_IRGRP);
		status = chdir(fpath);
	}
	return(status);
}
		
	
	
int Start_Ergo()
{
/* Starts up an Emacs process that initialises ergo 
   Stores the PID of Ergo in the Static Variable ErgoPID
*/
static char emacscmd[] = "emacs dummy.thy -f run-default-ergo";

char * olddir; /* saves the path of the current working direcotry */
char * ergohome; /* Context of the ERGOHOME env var. */
FILE *fp;
char cpycmd[256];

int stat, pid;

ergohome = (char *)NULL;

	/* change to the REPOSPATH/ergo directory (create ergo dir
	   if it doesn't exist. 
	   Create the file dummy.thy is it doesn't exist.
	*/

    olddir = getenv("PWD");
    if (CdCRepdir(ERGODIR) != 0) {
		printf("Can't change to ergo directory\n");
		ErgoPID = -1;
		return( ErgoPID );
	}
    if ((fp=fopen("global.erg","r")) == (FILE *) NULL) {
	/*create a new global.erg
		1. first check if the ERGOHOME env var is set
			if it is, copy the global.erg from there
		2. if env var not set, assume ergo will find the
			correct global.erg
	*/
	printf("Creating global.erg...\n");
	
	ergohome = getenv("ERGOHOME");
	if(ergohome != (char *)NULL) {
	    sprintf(cpycmd, "cp %s/sum/obj/global.erg ./global.erg", ergohome);
	    system(cpycmd);
	}
    }
    else fclose(fp);

	/* Start emacs */

    if(StartUpTries == 0) {
	unlink(ERGOPIDFILE);
        printf("Starting emacs\n");
        if((pid = fork())==0) { /*child */
	    /* execl("emacs", "emacs", "dummy.thy", (char *) 0); */
	    system(emacscmd);
	    exit(0);
            }
	    /* parent - carry on */
        if(pid < 0) {
	    printf("Can't create emacs process\n");
	    ErgoPID = -1;
        }
    } 
    if ( (ErgoPID = GetErgoPID()) == -1)
        printf("Can't find the PID of Ergo\n");
    else printf("PID of Ergo is %d\n", ErgoPID);
    StartUpTries++;

	/* change back to startup directory */
    chdir(olddir);
    free(olddir);
    /* if (ergohome != N(char *)ULL) free(ergohome); */
    return(ErgoPID);
}


/* Ex_Sum_Translate_To_Ergo(ifile, config, ofile, mfile) */
char * Ex_Sum_Translate_To_Ergo(ifname, config, ofname, modnm)
char * ifname;
char * config;
char * ofname;
char * modnm;
{
static char * msg="ok";
char modules[NMODS][STRSIZE];
int status, pid;
int i,j; /* loopers */
/* FILE *fp;*/
 char commandline[10000], cmd[10000], svcmd[10000];
char *path, *wdir, tmpdir[256];
int modcount = 0;
int modsleft = TRUE;
int base = 0;

for(i=0; i<NMODS; i++) modules[i][0] = '\0';

printf("Translating: %s Using Config: %s\n", ifname, config);

/* extract the modules */
while(modsleft){
    sscanf(config+base, "%s", modules[modcount]);
    if(modules[modcount][0] == '\0'){
        modsleft = FALSE;
        }
    else base += strlen(modules[modcount++])+1;
    }
printf("found %d modules\n", modcount);

for (i=0; i<modcount; i++){
    j = strlen(modules[i]);
    modules[i][j-3] = '\0';
    strcat(modules[i], "mod");
    }

commandline[0] = '\0';

strcat(commandline, "typecheck -E ../");
strcat(commandline, ifname);
for (i=0; i<modcount; i++){
        strcat(commandline, " ../");
        strcat(commandline, modules[i]);
        }
wdir = getenv("PWD");

path = getenv("REPOSPATH");
if(path == NULL) {
    printf("Repository Path not set\n");
    return(path);
    }
if (chdir(path)==-1){
    printf("Repository Directory doesn't exists\n");
    return(path);
    }
/*save the old version of the .mod file*/
sprintf(svcmd, "mv %s tmp.mod", modnm);
system(svcmd);
 

pid = getpid();
sprintf(tmpdir, "tp%d", pid);
if (mkdir(tmpdir, S_IRWXU) == -1) {
        printf("Can't create translation scratch directory\n");
        return(path);
        }
if( chdir(tmpdir) == -1) {
        printf("Can't change to translation scratch directory\n");
        return(path);
        }

sprintf(cmd, "#!/bin/csh -f\n#\n\n%s \n exit $status\n", commandline);
status = Execute_Cmd(cmd);

if(status == 0){ /* if successful, copy theory file to appropriate repository 
		    file */
    sprintf(cmd, "#!/bin/csh -f\ncp *.thy ../%s \n exit $status\n", ofname);
    status = Execute_Cmd(cmd);
    }
    
chdir("../");
printf("Removing Scratch Directory %s \n", tmpdir);
RemDir(tmpdir);

/*retrieve the old version of the mod file*/
sprintf(svcmd, "mv tmp.mod %s ", modnm);
system(svcmd);


if (chdir(wdir)==-1) return(wdir);

return( (status == 0) ? msg : path);
}

#define MODNAMEFILE "modname"

/* this was the first try!!!
static char awkscript[] = 
	"/add_theory/{while((substr($1,i,1) != \"'\")&&(i<=length($1))) ++i;\
          j = i+1;\
	  while((substr($1,j,1)!=\"'\")&&(j<=length($1))) ++j;\
          if ( i <= length($1)) {print substr($1,i+1,j-i-1)} else {print $1}\
	  i = 0;j=0 }";

replaced by:
	/bin/awk -F\\' '/add_theory/{print $2}'

Ha! ha! wot a wanker
*/

void RunAwkMod(ifile)
char * ifile;
{
char *path;
char cmd[10000];

path = getenv("REPOSPATH");
sprintf(cmd, "/bin/awk -F\\' '/add_theory/ {print $2}' %s/%s > %s", path, ifile, MODNAMEFILE);
system(cmd);
}


char * GetRealModName(ifile)
char * ifile;
{
	/* looks at the repository file ifile an tries to determine the
	   real name of the module defined in that file. In fact, ifile 
	   is a theory file, so it contains an ergo theory that corresponds 
	   to the original spec */
FILE *fp;
char * RealName;
	RunAwkMod(ifile);
	if((fp = fopen(MODNAMEFILE,"r")) == NULL) return((char *)NULL);

	RealName = (char *) malloc((size_t)STRSIZE);
	fscanf(fp, "%s", RealName);
	fclose(fp);
	unlink(MODNAMEFILE);
	return(RealName);
}

char * Ex_Ergo_Load_Theory(ifile)
char * ifile;
{
static char msg[]="ok";
static char msg2[]="ok?";
char cmd[10000];
char ergopath[10000];
FILE * fp;
char ergfile[10000];
char * modnm;
char * path;

/* signals ergo to process the theory file, ifile.
   If Ergo replies with a busy message, task is aborted, otherwise
   we wait until the appropriate theory file in REPOSPATH/ergo
   is generated
*/

/* if a theory file for ifile aleady exists, then the process is aborted.
   This is a probelm, since it means that each family can only have one active
   theory at any time. In particular, it means that this must be changed
   in order to accommodate refinement where more that one theory will be
   active for a given family
*/

if(ErgoPID == -1) {
    ErgoPID = GetErgoPID(); 
    if(ErgoPID == -1) return(ifile);
}

    path = getenv("REPOSPATH");

    modnm = GetRealModName(ifile);
    if(modnm == NULL) return(ifile);

    /* check to see if the theory file is there */
    sprintf(ergfile, "%s/ergo/%s.erg.qge", path, modnm);
    if ( (fp = fopen(ergfile, "r")) != NULL){
	printf("Theory file for %s already exists", ifile);
	free(modnm);
	return(ifile);
    }
    free(modnm);
    /* Create the Spec.thy file for Ergo */
    cmd[0] = '\0';
    sprintf(cmd, "cp %s/%s %s/ergo/Spec.thy", path, ifile, path);
    system(cmd);
    /*Add some additional stuff to the end of the theory file
	"generate_proof_obligations.": to generate the POs, and
	"save." to save the theory
    */
    sprintf(ergopath, "%s/ergo/Spec.thy", path);
    if ((fp = fopen(ergopath, "a")) == (FILE *)NULL) return(ifile);
    fprintf(fp, "\ngenerate_proof_obligations.\nsave.\n");
    fclose(fp);
    
    /* Tell ergo to read the theory file */
    kill((pid_t)ErgoPID, APP1);
    if (WaitForFile(ergfile, 20) == -1){
	printf("Giving up waiting for Ergo\n"); 
	return(msg2);
    }
    return(msg);
}

int WaitForFile(fnm, cnt)
char * fnm; int cnt;
{
FILE *fp, *fper;
int loop;
char *path, erfile[STRSIZE];

fp = (FILE *)NULL;
fper = (FILE *)NULL;

path = getenv("REPOSPATH");
if(path== (char *)NULL) path = "./";
sprintf(erfile, "%s/ergo/ergo-error", path);

for( loop = 0; (fp ==(FILE *) NULL) && (loop < cnt); loop++){
    sleep(2);
    if ((fper = fopen(erfile, "r")) != NULL){
	fclose(fper);
	unlink(erfile);
	printf("Ergo Interface Error \n");
	return(-1);
    }
    fp = fopen(fnm, "r") ;
}
if(fp == (FILE *) NULL) return(-1);

fclose(fp);
sleep(1); /* just to make sure if finishes getting written */
return(0);
}

int CheckForTheory(realname)
char * realname;
{
FILE *fp;
char *path;
char tfile[STRSIZE];

path = getenv("REPOSPATH");
if (path == NULL) path = "./";
sprintf(tfile,"%s/ergo/%s.erg.qge", path, realname);
if(( fp = fopen(tfile, "r")) == NULL) return(-1);
fclose(fp);
return(0);
}


char *Ex_Check_Proof_Obs(theoryname)
char *theoryname;
{
	/* Get the module name.
	   Create the query file for ergo po-theory containing
	   the name of the theory to check in the form: "'theoryname'.".
	   Send the APP2 signal to ergo.
	   Retrieve the list of open proof obligation from the file:
	   <theoryname>.po.
	*/

char *realname, *path, pofile[STRSIZE], pofileout[STRSIZE];
char proof_obs[10000];
char *retvar;
int cnt = 0; 
FILE *fp;
static char err[]="error";

	if(ErgoPID == -1) {
	    ErgoPID = GetErgoPID(); 
	    if(ErgoPID == -1) return(err);
	}
	realname = GetRealModName(theoryname);
	if(realname == NULL) return(err);
	if(CheckForTheory(realname) == -1){
	    printf("Theory file for %s doesn't yet exist\n", theoryname);
	    return(err);
	}
	printf("Found theory file for (%s)...\n", realname);

	path = getenv("REPOSPATH");
	if (path == NULL) path = "./";
	sprintf(pofileout, "%s/ergo/%s.po", path, realname);
	/*remove any earlier theory output*/
	unlink(pofileout);
	sprintf(pofile, "%s/ergo/po-theory", path);
	if ((fp = fopen(pofile, "w")) == NULL) return(err);
	fprintf(fp, "'%s'.\n", realname);
	fclose(fp);
	sprintf(pofileout, "%s/ergo/%s.po", path, realname);
	free(realname);
	kill(ErgoPID, APP2); /* tell ergo to generate list of POs */
	
	if( WaitForFile(pofileout, 50) != 0) return(err);

	/* open file and return the POs */
	fp = fopen(pofileout, "r");
	while (fscanf(fp, "%c", proof_obs+(cnt++)) != EOF){
	    if (cnt >= 10000){
		printf("Proof Obs too large\n");
		return(err);
	    }
        }
	proof_obs[cnt-1] = '\0';
	fclose(fp);
        printf("Check Prf Obs:Got the proof obs: \n%s\n", proof_obs);
/*HERE*/
	retvar = (char *)malloc((size_t)(cnt * (sizeof(char))));
	if(retvar == (char *)NULL) return(err);
	retvar[0] = NULL;
	strncpy(retvar, proof_obs, (size_t)strlen(proof_obs));
	return(retvar);
}
char *ConstructProofCmd(open_obs)
char *open_obs;
	/* extracts the list of (completely) unproven postulates in
	   the list open_obs and constructs an ergo command
	   to complete these proofs
	*/
{
char postname[STRSIZE];
char prfcmd[10000];
char *retvar;
	
int cmdsz=0;
int cmdcnt=0;
int lscnt=0,cnt=0;

	/*the first line in open_obs is just intro text*/

while((open_obs[lscnt] != '\n') && (open_obs[lscnt] != NULL)) lscnt++;
if(open_obs[lscnt] == NULL) return((char *) NULL);
lscnt++;

sprintf(prfcmd, "prove_postulate([");
while (open_obs[lscnt + cnt] != NULL) {
    while((open_obs[lscnt + cnt ] != '\n') && (open_obs[lscnt+cnt] != NULL))
	cnt++;

    /*lscnt to lscnt+cnt denotes the line for the current PO*/
    /* A single name denotes an unproven postulate
       name + qualifiers denotes a proven postulate that relies on
       unproven postulates in the current theory - not included in the
       proof command 
    */

    if( open_obs[lscnt + cnt ] == NULL) break;
    sscanf(open_obs+lscnt, "%s", postname);
    printf("\nCPC:Got a proof obligation: %s\n", postname);

    if(!(cnt >= (int)(strlen(postname)+1) )) { /* qualifiers*/
	if(cmdcnt++ != 0) sprintf(strlen(prfcmd)+prfcmd, ", ");
        sprintf(strlen(prfcmd)+prfcmd, " '%s' ", postname);
	printf("found open postulate %s\n", postname);
    }
    lscnt += (cnt+1);
    cnt = 0;
}
    
cmdsz = strlen(prfcmd);
sprintf(prfcmd+cmdsz, "]).\n");
retvar = (char *)malloc((size_t)strlen(prfcmd)+1);
strcpy(retvar, prfcmd);
return(retvar);
	
}
char * Ex_Complete_Proof_Obs(theoryname)
char * theoryname;
{
	/* find the current POs for the theory.
	   Construct a theory file with the ergo command to complete
	   the POs. 
	   return to the RM, explict action must be taken by the user
	   (via "Check Proof Obs") 
	*/

char * realname;

char *path, ergfile[STRSIZE], *ergocommand;
FILE *fp;
char *open_obs;
static char err[]="error";

printf("Check current po's for (%s)...\n", theoryname);


if(ErgoPID == -1) return(err);

open_obs = Ex_Check_Proof_Obs(theoryname);

if((open_obs == (char *) NULL) || (strcmp(open_obs, "error") == 0)) 
    return(err);

ergocommand = ConstructProofCmd(open_obs);
if(ergocommand == (char *)NULL) return(err);

path = getenv("REPOSPATH");
if(path == (char *)NULL) path = "./";

sprintf(ergfile, "%s/ergo/Spec.thy", path);
if((fp = fopen(ergfile, "w")) == (FILE *)NULL) {
    printf("Can't open ergo Spec.thy file\n");
    return(err);
}
realname = GetRealModName(theoryname);

fprintf(fp, "cd('%s').\n", realname);
fprintf(fp, ergocommand);
fclose(fp);
kill((pid_t)ErgoPID, APP1);

free(path); free(realname); free(ergocommand);

return(open_obs);
}
    
