/* 
 Copyright (C) 1999
 Software Verification Research Centre
 The University of Queensland
 Australia 4072

 email: svrc@cs.uq.oz.au

 The Cogito 1.3 Software and Documentation  

 Cogito 1.3 COPYRIGHT, LICENCE AND DISCLAIMER NOTICE.
 
 Copyright 1999 by The University of Queensland, Queensland 4072 Australia
 
 Permission to use, copy and distribute this software and associated
 documentation for any non-commercial purpose and without fee is hereby 
 granted, subject to the following conditions:
 
 1. 	that the above copyright notice and this permission notice and 
	warranty disclaimer appear in all copies and in supporting 
	documentation;

 2.	that the name of "The University of Queensland" not be used in 
	advertising or publicity pertaining to distribution of the software 
	without specific, written prior permission; 

 3.	that users of this software shall be responsible for determining the 
	fitness of the software for the purposes for which the software is 
	employed by them; 

 4. 	that no changes to the system or documentation are subsequently 
	made available to third parties or redistributed without prior 
	written consent from the SVRC; and

 5. 	that individuals, groups or institutions using this software register 
	their use with the SVRC.
 
 The University of Queensland disclaims all warranties with regard to this
 software including all implied warranties of merchantability and fitness
 to the extent permitted by law. In no event shall the University of 
 Queensland be liable for any special, indirect or consequential damages or 
 any damages whatsoever resulting from loss of use, data or profits, whether 
 in an action of contract, negligence or other tortious action, arising out 
 of or in connection with the use or performance of this software.

 THE UNIVERSITY OF QUEENSLAND MAKES NO REPRESENTATIONS ABOUT THE ACCURACY OR
 SUITABILITY OF THIS MATERIAL FOR ANY PURPOSE.  IT IS PROVIDED "AS IS",
 WITHOUT ANY EXPRESSED OR IMPLIED WARRANTIES.


For information on commercial use of this software contact the SVRC.
*/



#include "structures.h" 
#include "grammar.h"
#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>

/* only one editing process is allowed in parallel with repository manager
activity
*/
int EdProcessID;

char * Ex_Par_Edit(fname)
char * fname;
{
	FILE *fp; char cmd[256];
        char *path;
        char *editor;
        char repository[255];

        path = getenv("REPOSPATH");
        if(path == NULL) path = ".";

        editor = getenv("EDITOR");
        if(editor == NULL) editor = "vi";

        strcpy(repository, path);
        strcat(repository, "/");
        strcat(repository, fname);

	cmd[0] = '\0';
	sprintf(cmd, "#!/bin/csh\n\nxterm -e %s %s\n", editor, repository);
	if(EdProcessID != 0) return(fname);
	printf("Starting background process\n");
	EdProcessID = ExecuteBgrndCmd(cmd);
	return(fname);
}

int ExecuteBgrndCmd(cmd)
char * cmd;
{
long pid;
int status;
FILE *fp;
char fname[255];

        pid = getpid();
        sprintf(fname, "/tmp/repos%d", pid);
        fp = fopen(fname,"wb");
        if (fp == NULL) return(1);
        fprintf(fp, cmd);
        fclose(fp);
        status = mysystembg("/bin/csh", fname);
	sleep(3);
        unlink(fname);
        return(status);
}

int mysystembg(exc, param)
char *exc, *param;
{
 int stat, pid;
 printf("Forking to start shell\n");
 if((pid = fork())==0) { /*child */
        execl(exc, exc, param, (char *) 0);
        }
 /*parent*/
 /*pid = waitpid(pid, &stat, NULL);
 printf("Exit status is %d \n", WEXITSTATUS(stat));
 return(WEXITSTATUS(stat));*/
 printf("Process pid is %d\n",pid);
 return(pid);
}

char *  Ex_Stop_Edit(fname)
char * fname; /*ignored*/
{
int status, stat;
	status = waitpid(EdProcessID, &stat, NULL);
	EdProcessID = 0;
	return(fname);
}
