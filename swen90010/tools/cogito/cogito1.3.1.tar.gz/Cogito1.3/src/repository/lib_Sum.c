/* 
 Copyright (C) 1999
 Software Verification Research Centre
 The University of Queensland
 Australia 4072

 email: svrc@cs.uq.oz.au

 The Cogito 1.3 Software and Documentation  

 Cogito 1.3 COPYRIGHT, LICENCE AND DISCLAIMER NOTICE.
 
 Copyright 1999 by The University of Queensland, Queensland 4072 Australia
 
 Permission to use, copy and distribute this software and associated
 documentation for any non-commercial purpose and without fee is hereby 
 granted, subject to the following conditions:
 
 1. 	that the above copyright notice and this permission notice and 
	warranty disclaimer appear in all copies and in supporting 
	documentation;

 2.	that the name of "The University of Queensland" not be used in 
	advertising or publicity pertaining to distribution of the software 
	without specific, written prior permission; 

 3.	that users of this software shall be responsible for determining the 
	fitness of the software for the purposes for which the software is 
	employed by them; 

 4. 	that no changes to the system or documentation are subsequently 
	made available to third parties or redistributed without prior 
	written consent from the SVRC; and

 5. 	that individuals, groups or institutions using this software register 
	their use with the SVRC.
 
 The University of Queensland disclaims all warranties with regard to this
 software including all implied warranties of merchantability and fitness
 to the extent permitted by law. In no event shall the University of 
 Queensland be liable for any special, indirect or consequential damages or 
 any damages whatsoever resulting from loss of use, data or profits, whether 
 in an action of contract, negligence or other tortious action, arising out 
 of or in connection with the use or performance of this software.

 THE UNIVERSITY OF QUEENSLAND MAKES NO REPRESENTATIONS ABOUT THE ACCURACY OR
 SUITABILITY OF THIS MATERIAL FOR ANY PURPOSE.  IT IS PROVIDED "AS IS",
 WITHOUT ANY EXPRESSED OR IMPLIED WARRANTIES.


For information on commercial use of this software contact the SVRC.
*/
/*library manager prototype: External C routines for C compilation and execution
Tue Oct  4 17:12:33 EST 1994
Copyright (C) 1994 Owen Traynor SVRC
*/

#include "structures.h" 
#include "grammar.h"
#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>


#define NMODS 20
#define STRSIZE 256
#define TRUE 1
#define FALSE 0


/* Removes a temporary directory which may contain files */
void RemDir(fname)
char * fname;
{
char rmcmd[255];

rmcmd[0] = NULL;
sprintf(rmcmd, "/bin/rm -rf %s", fname);
system(rmcmd);
}

/* Interface to the type check operation */
char * Ex_Sum_synchk(ifnm)
char * ifnm;
{
        FILE *fp; char cmd[10000];

        char *path, *wdir;
        static char result[256];
        int status; /*exit status of command*/
        strcpy(result, "ok");

        wdir = getenv("PWD");
        path = getenv("REPOSPATH");
        if(path == NULL) path = "./";
        if (chdir(path)==-1) return(path);
	sprintf(cmd, "typecheck -S %s \n exit $status\n", ifnm); 
	status = Execute_Cmd(cmd);
/*
	fp = fopen("/tmp/xxx","wb");
        fprintf(fp, cmd);
        fclose(fp);
        status = mysystem("/bin/csh", "/tmp/xxx");
*/
        if (chdir(wdir)==-1) return(wdir);
        return( (status == 0) ? result : path); 
} 

int Execute_Cmd(cmd)
char * cmd;
{
long pid;
int status;
FILE *fp;
char fname[255];

	pid = getpid();
	sprintf(fname, "/tmp/repos%d", pid);
	fp = fopen(fname,"wb");
	if (fp == NULL) return(1);
	fprintf(fp, cmd);
	fclose(fp);
	status = mysystem("/bin/csh", fname);
	unlink(fname);
	return(status);
}



/* Test Stub.....
char * Ex_Sum_synchk(ifname)
char * ifname;
{
static char * msg="ok";
printf("Syntax Check: %s\n", ifname);
return(msg);
}
*/



char * Ex_Sum_typchk(ifname, config)
char * ifname;
char * config;
/*
The existence of a denotation for each module cited in the configuration should
be established by the repository manager before calling the C interface.

For each unit in config, extract the module cited in the selected
spec's import statement and rename the denotation associated with
each config entry to the module name (needed for typechecking).

After typechecking, rename the generated module denotation to reflect the
library name, family name and version from which it was derived.

Name extraction uses awk.
*/

{
static char * msg="ok";
char modules[NMODS][STRSIZE];
int status, pid;
int i,j; /* loopers */
/* FILE *fp;*/
 char commandline[10000], cmd[10000];
char *path, *wdir, tmpdir[255];
int modcount = 0;
int modsleft = TRUE;
int base = 0;

for(i=0; i<NMODS; i++) modules[i][0] = '\0';

printf("Type Check: %s Using Config: %s\n", ifname, config);

/* extract the modules */
while(modsleft){
        sscanf(config+base, "%s", modules[modcount]);
	printf("Got Module (%s)...\n", modules[modcount]);
        if(modules[modcount][0] == '\0'){
                modsleft = FALSE;
                }
        else base += strlen(modules[modcount++])+1;
        }
/*modcount--;*/
printf("found %d modules\n", modcount);

/*change the suffixes*/
for (i=0; i<modcount; i++){
        j = strlen(modules[i]);
        modules[i][j-3] = '\0';
        strcat(modules[i], "mod");
        }
/* generate the command line to the typechecking script */
/* typecheck modulename <denotation list> */
commandline[0] = '\0';

strcat(commandline, "typecheck -T ../");
strcat(commandline, ifname);
for (i=0; i<modcount; i++){
	strcat(commandline, " ../");
        strcat(commandline, modules[i]);
	}

wdir = getenv("PWD");
path = getenv("REPOSPATH");
if(path == NULL) { 
	printf("Repository Path not set\n"); 
	return(path); 
	}

if (chdir(path)==-1){	
	printf("Repository Directory doesn't exists\n"); 
	return(path);
	}

pid = getpid();
sprintf(tmpdir, "tp%d", pid);
if (mkdir(tmpdir, S_IRWXU) == -1) { 
	printf("Can't create typechecking scratch directory\n");
	return(path);
	}


if( chdir(tmpdir) == -1) {   
	printf("Repository Directory doesn't exists\n");
        return(path);
	}
sprintf(cmd, "#!/bin/csh -f\n#\n\n%s \n exit $status\n", commandline);
status = Execute_Cmd(cmd);

chdir("../"); /* move back out of scratch directory */
printf("Removing Scratch Directory %s \n", tmpdir);
RemDir(tmpdir);

if (chdir(wdir)==-1) return(wdir);

return( (status == 0) ? msg : path);

}


