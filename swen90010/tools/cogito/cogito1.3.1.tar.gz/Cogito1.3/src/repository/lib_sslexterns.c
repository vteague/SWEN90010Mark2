/* 
 Copyright (C) 1999
 Software Verification Research Centre
 The University of Queensland
 Australia 4072

 email: svrc@cs.uq.oz.au

 The Cogito 1.3 Software and Documentation  

 Cogito 1.3 COPYRIGHT, LICENCE AND DISCLAIMER NOTICE.
 
 Copyright 1999 by The University of Queensland, Queensland 4072 Australia
 
 Permission to use, copy and distribute this software and associated
 documentation for any non-commercial purpose and without fee is hereby 
 granted, subject to the following conditions:
 
 1. 	that the above copyright notice and this permission notice and 
	warranty disclaimer appear in all copies and in supporting 
	documentation;

 2.	that the name of "The University of Queensland" not be used in 
	advertising or publicity pertaining to distribution of the software 
	without specific, written prior permission; 

 3.	that users of this software shall be responsible for determining the 
	fitness of the software for the purposes for which the software is 
	employed by them; 

 4. 	that no changes to the system or documentation are subsequently 
	made available to third parties or redistributed without prior 
	written consent from the SVRC; and

 5. 	that individuals, groups or institutions using this software register 
	their use with the SVRC.
 
 The University of Queensland disclaims all warranties with regard to this
 software including all implied warranties of merchantability and fitness
 to the extent permitted by law. In no event shall the University of 
 Queensland be liable for any special, indirect or consequential damages or 
 any damages whatsoever resulting from loss of use, data or profits, whether 
 in an action of contract, negligence or other tortious action, arising out 
 of or in connection with the use or performance of this software.

 THE UNIVERSITY OF QUEENSLAND MAKES NO REPRESENTATIONS ABOUT THE ACCURACY OR
 SUITABILITY OF THIS MATERIAL FOR ANY PURPOSE.  IT IS PROVIDED "AS IS",
 WITHOUT ANY EXPRESSED OR IMPLIED WARRANTIES.


For information on commercial use of this software contact the SVRC.
*/
/*
Library manager prototype: External C routines for ssl compilation and execution
Mon Mar 14 10:02:35 EST 1994
Copyright (C) 1994 Owen Traynor SVRC
*/

#include "structures.h" 
#include "grammar.h"
#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/wait.h>

char * Ex_ssl_Compile(exfnm, ifnm)
char * exfnm;
char * ifnm;
{
        FILE *fp; char cmd[10000];
 
	char *path, *wdir;
        static char repository1[255];
	int status; /*exit status of command*/
	strcpy(repository1, "ok");

	wdir = getenv("PWD");
        path = getenv("REPOSPATH");
        if(path == NULL) path = "./";
	if (chdir(path)==-1) return(path);

        cmd[0] = '\0'; 
	printf("1: %s 2: %s\n", ifnm, exfnm);
	sprintf(cmd, "sgen -o %s %s \n exit $status\n", exfnm, ifnm);
	status = Execute_Cmd(cmd);
	if (chdir(wdir)==-1) return(wdir);
        return( (status == 0) ? repository1 : path); 
} 

int mysystem(exc, param)
char *exc, *param;
{
 int stat, pid;
 if((pid = fork())==0) { /*child */
	execl(exc, exc, "-f", param, (char *) 0);
	}
 /*parent*/
 pid = waitpid(pid, &stat, NULL);
 printf("Exit status is %d \n", WEXITSTATUS(stat));
 return(WEXITSTATUS(stat));
}

 
