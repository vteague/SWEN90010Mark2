/* 
 Copyright (C) 1999
 Software Verification Research Centre
 The University of Queensland
 Australia 4072

 email: svrc@cs.uq.oz.au

 The Cogito 1.3 Software and Documentation  

 Cogito 1.3 COPYRIGHT, LICENCE AND DISCLAIMER NOTICE.
 
 Copyright 1999 by The University of Queensland, Queensland 4072 Australia
 
 Permission to use, copy and distribute this software and associated
 documentation for any non-commercial purpose and without fee is hereby 
 granted, subject to the following conditions:
 
 1. 	that the above copyright notice and this permission notice and 
	warranty disclaimer appear in all copies and in supporting 
	documentation;

 2.	that the name of "The University of Queensland" not be used in 
	advertising or publicity pertaining to distribution of the software 
	without specific, written prior permission; 

 3.	that users of this software shall be responsible for determining the 
	fitness of the software for the purposes for which the software is 
	employed by them; 

 4. 	that no changes to the system or documentation are subsequently 
	made available to third parties or redistributed without prior 
	written consent from the SVRC; and

 5. 	that individuals, groups or institutions using this software register 
	their use with the SVRC.
 
 The University of Queensland disclaims all warranties with regard to this
 software including all implied warranties of merchantability and fitness
 to the extent permitted by law. In no event shall the University of 
 Queensland be liable for any special, indirect or consequential damages or 
 any damages whatsoever resulting from loss of use, data or profits, whether 
 in an action of contract, negligence or other tortious action, arising out 
 of or in connection with the use or performance of this software.

 THE UNIVERSITY OF QUEENSLAND MAKES NO REPRESENTATIONS ABOUT THE ACCURACY OR
 SUITABILITY OF THIS MATERIAL FOR ANY PURPOSE.  IT IS PROVIDED "AS IS",
 WITHOUT ANY EXPRESSED OR IMPLIED WARRANTIES.


For information on commercial use of this software contact the SVRC.
*/


#include "structures.h" 
#include "grammar.h"
#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>

char * CEdit(fname)
char * fname;
{
	FILE *fp; char cmd[256];
        char *path;
        char *editor;
        char repository[255];
        path = getenv("REPOSPATH");
        editor = getenv("EDITOR");

        if(path == NULL) path = "./";
        if(editor == NULL) editor = "vi";

        strcpy(repository, path);
        strcat(repository, "/");
        strcat(repository, fname);


	printf("trying to create file \"%s\"", repository);
	fflush(stdout);
	fp = fopen(repository, "w");
	fclose(fp);
	cmd[0] = '\0';
	sprintf(cmd, "xterm -e %s %s", editor, repository);
	system(cmd);
	return(fname);
}

char * Edit(ifname, ofname)
char * ifname;
char * ofname;
{
        FILE *fp; char cmd[256];
 
	char *path;
	char *editor;
        char repository1[255];
        char repository2[255];

        path = getenv("REPOSPATH");
	editor = getenv("EDITOR");

        if(path == NULL) path = "./";
	if(editor == NULL) editor = "vi";


        strcpy(repository1, path);
        strcat(repository1, "/");
        strcat(repository1, ifname);
        strcpy(repository2, path);
        strcat(repository2, "/");
        strcat(repository2, ofname);

        fp = fopen(repository1, "r"); 
	if (fp == NULL) {
		printf("Can't open file \"%s\"", repository1);
		fflush(stdout);
		return("Cant_Open");
	}
        fclose(fp); 
        cmd[0] = '\0'; 
	sprintf(cmd, "cp %s %s", repository1, repository2);
	system(cmd);
	cmd[0] = '\0';
        sprintf(cmd, "xterm -e %s %s", editor,  repository2); 
        system(cmd); 
        return(ofname); 
} 
 
char * Secs_To_Date(secs)
	int secs;
{
	static char *errstr = "File Error";
	char * date;
	long tt = (long) secs;

	if(secs == -1) date = errstr;
	else {
		date = ctime(&(tt));
		date[24] = '\0';
	}
	return(date);
}

int Get_Date_Secs(file)
	char * file;
{
	int sts, secs;
        struct stat buf;
        char *path;
        char repository[255];

        path = getenv("REPOSPATH");
	if(path == NULL) path = "./";

        strcpy(repository, path);
        strcat(repository, "/");
        strcat(repository, file);
        printf("Stating file %s\n", repository);

        sts = stat(repository, &buf);
        if (sts != NULL) return(-1);

        secs = buf.st_mtime;
        return( secs );
}

char * C_Get_Date(file)
	char * file;
{
	int sts;
	char *err;
	struct stat buf;
	char *date;
	char *path;
	char repository[255];
	
	err = malloc(sizeof("File Error"));
	strcpy(err, "File Error");
	path = getenv("REPOSPATH");
	if(path == NULL) path = "./";

	strcpy(repository, path);
	strcat(repository, "/");
	strcat(repository, file);
	printf("Stating file %s\n", repository);

	sts = stat(repository, &buf);
	if (sts != NULL) return(err);

	date = ctime(&(buf.st_mtime) );
	date[24] = '\0'; /* God, why do I do these things? */
	return( date );
}
	
