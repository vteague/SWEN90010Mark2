/* 
 Copyright (C) 1999
 Software Verification Research Centre
 The University of Queensland
 Australia 4072

 email: svrc@cs.uq.oz.au

 The Cogito 1.3 Software and Documentation  

 Cogito 1.3 COPYRIGHT, LICENCE AND DISCLAIMER NOTICE.
 
 Copyright 1999 by The University of Queensland, Queensland 4072 Australia
 
 Permission to use, copy and distribute this software and associated
 documentation for any non-commercial purpose and without fee is hereby 
 granted, subject to the following conditions:
 
 1. 	that the above copyright notice and this permission notice and 
	warranty disclaimer appear in all copies and in supporting 
	documentation;

 2.	that the name of "The University of Queensland" not be used in 
	advertising or publicity pertaining to distribution of the software 
	without specific, written prior permission; 

 3.	that users of this software shall be responsible for determining the 
	fitness of the software for the purposes for which the software is 
	employed by them; 

 4. 	that no changes to the system or documentation are subsequently 
	made available to third parties or redistributed without prior 
	written consent from the SVRC; and

 5. 	that individuals, groups or institutions using this software register 
	their use with the SVRC.
 
 The University of Queensland disclaims all warranties with regard to this
 software including all implied warranties of merchantability and fitness
 to the extent permitted by law. In no event shall the University of 
 Queensland be liable for any special, indirect or consequential damages or 
 any damages whatsoever resulting from loss of use, data or profits, whether 
 in an action of contract, negligence or other tortious action, arising out 
 of or in connection with the use or performance of this software.

 THE UNIVERSITY OF QUEENSLAND MAKES NO REPRESENTATIONS ABOUT THE ACCURACY OR
 SUITABILITY OF THIS MATERIAL FOR ANY PURPOSE.  IT IS PROVIDED "AS IS",
 WITHOUT ANY EXPRESSED OR IMPLIED WARRANTIES.


For information on commercial use of this software contact the SVRC.
*/

#include "structures.h"
#include "grammar.h"
#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>


#define STRSIZE 256
#define TRUE 1
#define FALSE 0

/* takes as a paramter the mod file that should be generated from the current spec
unit. Brings this up to date wrt all dependencies

*/

extern char * Ex_Make_Exe(modfl)
char * modfl;
{
    FILE *fp; char cmd[10000];

        char *path, *wdir;
        static char result[256];
	int status;
        strcpy(result, "ok");

        wdir = getenv("PWD");
        path = getenv("REPOSPATH");
        if(path == NULL) path = "./";
        if (chdir(path)==-1) return(path);

	sprintf(cmd, "make %s \n", modfl);
	printf("Executing Makefile:\n");
	status = Execute_Cmd(cmd);

	if (chdir(wdir)==-1) return(wdir);
	return( (status == 0) ? result : path);

}
