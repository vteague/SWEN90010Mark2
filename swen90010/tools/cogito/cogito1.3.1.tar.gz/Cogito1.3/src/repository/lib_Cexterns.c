/* 
 Copyright (C) 1999
 Software Verification Research Centre
 The University of Queensland
 Australia 4072

 email: svrc@cs.uq.oz.au

 The Cogito 1.3 Software and Documentation  

 Cogito 1.3 COPYRIGHT, LICENCE AND DISCLAIMER NOTICE.
 
 Copyright 1999 by The University of Queensland, Queensland 4072 Australia
 
 Permission to use, copy and distribute this software and associated
 documentation for any non-commercial purpose and without fee is hereby 
 granted, subject to the following conditions:
 
 1. 	that the above copyright notice and this permission notice and 
	warranty disclaimer appear in all copies and in supporting 
	documentation;

 2.	that the name of "The University of Queensland" not be used in 
	advertising or publicity pertaining to distribution of the software 
	without specific, written prior permission; 

 3.	that users of this software shall be responsible for determining the 
	fitness of the software for the purposes for which the software is 
	employed by them; 

 4. 	that no changes to the system or documentation are subsequently 
	made available to third parties or redistributed without prior 
	written consent from the SVRC; and

 5. 	that individuals, groups or institutions using this software register 
	their use with the SVRC.
 
 The University of Queensland disclaims all warranties with regard to this
 software including all implied warranties of merchantability and fitness
 to the extent permitted by law. In no event shall the University of 
 Queensland be liable for any special, indirect or consequential damages or 
 any damages whatsoever resulting from loss of use, data or profits, whether 
 in an action of contract, negligence or other tortious action, arising out 
 of or in connection with the use or performance of this software.

 THE UNIVERSITY OF QUEENSLAND MAKES NO REPRESENTATIONS ABOUT THE ACCURACY OR
 SUITABILITY OF THIS MATERIAL FOR ANY PURPOSE.  IT IS PROVIDED "AS IS",
 WITHOUT ANY EXPRESSED OR IMPLIED WARRANTIES.


For information on commercial use of this software contact the SVRC.
*/
/*
Library manager prototype: External C routines for C compilation and execution
Mon Mar 14 10:02:35 EST 1994
Copyright (C) 1994 Owen Traynor SVRC
*/

#include "structures.h" 
#include "grammar.h"
#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>

char * Ex_C_Compile(ifname, ofname)
char * ifname;
char * ofname;
{
        FILE *fp; char cmd[256];
 
	char *path;
        char repository1[255];
        char repository2[255];
	int status; /*exit status of command*/

        path = getenv("REPOSPATH");
        if(path == NULL) path = "./";

        strcpy(repository1, path);
        strcat(repository1, "/");
        strcat(repository1, ifname);
        strcpy(repository2, path);
        strcat(repository2, "/");
        strcat(repository2, ofname);

        fp = fopen(repository1, "r"); 
	if (fp == NULL) {
		printf("Can't open file \"%s\"", repository1);
		fflush(stdout);
		return("Cant_Open");
	}
        fclose(fp); 
        cmd[0] = '\0'; 
	sprintf(cmd, "#!/bin/csh\n cc %s -o %s \n echo Press Return\n echo $<", repository1, repository2);
	status = Execute_Cmd(cmd);
	return( (status == 0) ? "ok" : ofname);
} 

char * Ex_C_Execute(ifname)
char * ifname;
{
        FILE *fp; char cmd[256];
 
	char *path;
        char repository1[255];

        path = getenv("REPOSPATH");
        if(path == NULL) path = "./";

        strcpy(repository1, path);
        strcat(repository1, "/");
        strcat(repository1, ifname);

        fp = fopen(repository1, "r"); 
	if (fp == NULL) {
		printf("Can't open file \"%s\"", repository1);
		fflush(stdout);
		return("Cant_Open");
	}
        cmd[0] = '\0'; 
	sprintf(cmd, "xterm -e %s", repository1);
	system(cmd);
        return(ifname); 
} 
 
