/* 
 Copyright (C) 1999
 Software Verification Research Centre
 The University of Queensland
 Australia 4072

 email: svrc@cs.uq.oz.au

 The Cogito 1.3 Software and Documentation  

 Cogito 1.3 COPYRIGHT, LICENCE AND DISCLAIMER NOTICE.
 
 Copyright 1999 by The University of Queensland, Queensland 4072 Australia
 
 Permission to use, copy and distribute this software and associated
 documentation for any non-commercial purpose and without fee is hereby 
 granted, subject to the following conditions:
 
 1. 	that the above copyright notice and this permission notice and 
	warranty disclaimer appear in all copies and in supporting 
	documentation;

 2.	that the name of "The University of Queensland" not be used in 
	advertising or publicity pertaining to distribution of the software 
	without specific, written prior permission; 

 3.	that users of this software shall be responsible for determining the 
	fitness of the software for the purposes for which the software is 
	employed by them; 

 4. 	that no changes to the system or documentation are subsequently 
	made available to third parties or redistributed without prior 
	written consent from the SVRC; and

 5. 	that individuals, groups or institutions using this software register 
	their use with the SVRC.
 
 The University of Queensland disclaims all warranties with regard to this
 software including all implied warranties of merchantability and fitness
 to the extent permitted by law. In no event shall the University of 
 Queensland be liable for any special, indirect or consequential damages or 
 any damages whatsoever resulting from loss of use, data or profits, whether 
 in an action of contract, negligence or other tortious action, arising out 
 of or in connection with the use or performance of this software.

 THE UNIVERSITY OF QUEENSLAND MAKES NO REPRESENTATIONS ABOUT THE ACCURACY OR
 SUITABILITY OF THIS MATERIAL FOR ANY PURPOSE.  IT IS PROVIDED "AS IS",
 WITHOUT ANY EXPRESSED OR IMPLIED WARRANTIES.


For information on commercial use of this software contact the SVRC.
*/



#include "structures.h" 
#include "grammar.h"
#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>

char * Ex_View_Graphical(ifname)
char * ifname;
{
	int pid;
	FILE *fp; char cmd[256];
	char efile[256];
	int status;
        char *path, *wdir;
        static char result[256];
	char fres[256];
        path = getenv("REPOSPATH");

	strcpy(result, "ok");
        if(path == NULL) path = "./";

        wdir = getenv("PWD");
        path = getenv("REPOSPATH");
        if(path == NULL) path = "./";
        if (chdir(path)==-1) return(path);

	sprintf(cmd, "/bin/rm  *.aux *.log ; exit $status\n");
	status = Execute_Cmd(cmd);

	sprintf(cmd, "/bin/rm  *.tex *.dvi ; exit $status\n");
	status = Execute_Cmd(cmd);
	
	sprintf(cmd, "tcsum1 -G %s ; exit $status\n",  ifname);
	status = Execute_Cmd(cmd);
	if(status != 0) return(wdir);

	sprintf(cmd, "latex *.tex ; exit $status\n");
	status = Execute_Cmd(cmd);
	
	if(status != 0) return(wdir);
	
	sprintf(cmd, "xdvi *.dvi ; exit $status\n");
	status = Execute_Cmd(cmd);

	if(status == 0) {
		if (chdir(wdir)==-1) return(wdir);
		return(result);
		}
	else {
	        chdir(wdir);
                return(wdir);
	}
}
/*
char * Ex_Latex_Print(fname)
char * fname;
{
	char *path;
	char cmd[256];
	char ifile[256];

	path = getenv("REPOSPATH");
	if(path == NULL) path = "./";
	
	strcpy(ifile, path);
	strcat(ifile, "/");
	strcat(ifile, fname);

	sprintf(cmd, "dvipr -Php8 %s", ifile);
	system(cmd);
	return(fname);
}

char *Ex_Modify(Fname)
char *Fname;
{
	char *path;
	char *editor;
	char cmd[256];
	char *wdir;
	int pid;

	path = getenv("REPOSPATH");
	if(path == NULL) path = "./";

	editor = getenv("EDITOR");
	if(editor == NULL) editor = "vi";

	wdir = getenv("PWD");
	chdir(path);
	
	sprintf(cmd, "xterm -e %s %s", editor, Fname);
	system(cmd);
	chdir(wdir);
	return(Fname);
}

char *Ex_Dvi(Fname)
char *Fname;
{
        char *path;
	char cmd[256];
        int pid;

        path = getenv("REPOSPATH");
        if(path == NULL) path = "./";

	if((pid = fork())==0) { */ /*child */ /*
	chdir(path);
	sprintf(cmd, "xdvi %s", Fname);
	system(cmd); 
	exit(0);
        }
	*/ /*parent*/ /*
	return(Fname);
}


*/
	
