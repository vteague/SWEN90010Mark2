# include "TypeAccess.h"
# include "yyTypeAccess.w"
# include "System.h"
# include <stdio.h>
# include "Type.h"
# include "Syms.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 21 "types.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include <string.h>
#include <stdlib.h> 
#include "Idents.h"
#include "Type.h"
#include "Positions.h"
#include "ratc.h"


static void yyExit () { Exit (1); }

void (* TypeAccess_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module TypeAccess, routine %s failed\n", yyFunction);
 TypeAccess_Exit ();
}

static bool SameIds ARGS((tIdent id1, tIdent id2));
bool IsBoolOrSchRef ARGS((tType ty));
tIdent RemoveDecn ARGS((tIdent id));
static tType ObjectType ARGS((tSyms yyP1));
static tType ThetaBinding ARGS((tType S, tSyms DeclsIn));
tType ThetaType ARGS((tType S, tSyms DeclsIn));
static void WPrintTy ARGS((tType typ));
static void PrintCartList ARGS((tType yyP2));
static void PrintSchFieldList ARGS((tType yyP3));

static bool SameIds
# if defined __STDC__ | defined __cplusplus
(tIdent id1, tIdent id2)
# else
(id1, id2)
 tIdent id1;
 tIdent id2;
# endif
{
/* line 37 "types.puma" */
  {
/* line 38 "types.puma" */
char str1[IDENT_LENGTH],str2[IDENT_LENGTH];
	bool same=false;
	GetString(id1,str1);
	GetString(id2,str2);
	if (strcmp(str1,str2)==0)
		same = true;
/* line 44 "types.puma" */
   if (! ((same))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

bool IsBoolOrSchRef
# if defined __STDC__ | defined __cplusplus
(register tType ty)
# else
(ty)
 register tType ty;
# endif
{
  if (ty->Kind == kTp_Base) {
/* line 48 "types.puma" */
  {
/* line 48 "types.puma" */
   if (! (SameIds (ty->Tp_Base.Ident, MakeIdent ("bool", strlen ("bool"))))) goto yyL1;
  }
   return true;
yyL1:;

  }
  if (ty->Kind == kTp_Schema) {
/* line 49 "types.puma" */
   return true;

  }
  return false;
}

tIdent RemoveDecn
# if defined __STDC__ | defined __cplusplus
(tIdent id)
# else
(id)
 tIdent id;
# endif
{
/* line 52 "types.puma" */
tIdent newid;
/* line 53 "types.puma" */
  {
/* line 54 "types.puma" */
char str[IDENT_LENGTH];
	int len;
	GetString(id,str);
	len = strlen(str);
	if (str[len-1] == '\'')
		{str[len-1] = '\0';
		len--;}
	newid = MakeIdent(str,len);
  }
   return newid;

}

static tType ObjectType
# if defined __STDC__ | defined __cplusplus
(register tSyms yyP1)
# else
(yyP1)
 register tSyms yyP1;
# endif
{
  if (yyP1 == NULL) {
/* line 66 "types.puma" */
   return NoType;

  }
  if (Syms_IsType (yyP1, kObject)) {
/* line 67 "types.puma" */
   return yyP1->Object.Type;

  }
/* line 68 "types.puma" */
   return NoType;

}

static tType ThetaBinding
# if defined __STDC__ | defined __cplusplus
(register tType S, register tSyms DeclsIn)
# else
(S, DeclsIn)
 register tType S;
 register tSyms DeclsIn;
# endif
{
/* line 76 "types.puma" */
tType newlist;
  if (S == NULL) {
/* line 77 "types.puma" */
  {
/* line 78 "types.puma" */
newlist = mTp_NoSchField();
  }
   return newlist;

  }
  if (S->Kind == kTp_NoSchField) {
/* line 79 "types.puma" */
  {
/* line 80 "types.puma" */
newlist = mTp_NoSchField();
  }
   return newlist;

  }
  if (S->Kind == kTp_SchField) {
/* line 81 "types.puma" */
  {
/* line 82 "types.puma" */
tObjects sym;
		
		tType typ = S->Tp_SchField.Tp_Exp;
		sym = LookUp(DeclsIn,S->Tp_SchField.Ident,NoSym);
		if (sym==NoSym)  
			typ = CopyType(S->Tp_SchField.Tp_Exp);
		else typ = CopyType(ObjectType(sym));
		newlist = mTp_SchField(ThetaBinding(S->Tp_SchField.Next,DeclsIn),S->Tp_SchField.ModId,RemoveDecn(S->Tp_SchField.Ident),typ,S->Tp_SchField.QuId);
  }
   return newlist;

  }
/* line 90 "types.puma" */
  {
/* line 91 "types.puma" */
newlist = mTp_NoSchField();
  }
   return newlist;

}

tType ThetaType
# if defined __STDC__ | defined __cplusplus
(register tType S, register tSyms DeclsIn)
# else
(S, DeclsIn)
 register tType S;
 register tSyms DeclsIn;
# endif
{
/* line 94 "types.puma" */
tType typ=S;
  if (S->Kind == kTp_Schema) {
/* line 95 "types.puma" */
  {
/* line 96 "types.puma" */
typ = mTp_Schema(S->Tp_Schema.ModId,NoIdent,ThetaBinding(S->Tp_Schema.Tp_SchFieldList,DeclsIn));
  }
   return typ;

  }
/* line 97 "types.puma" */
   return typ;

}

static void WPrintTy
# if defined __STDC__ | defined __cplusplus
(register tType typ)
# else
(typ)
 register tType typ;
# endif
{
/* line 101 "types.puma" */
char mystr[IDENT_LENGTH];
  if (typ == NULL) {
/* line 102 "types.puma" */
   return;

  }

  switch (typ->Kind) {
  case kTp_Exp:
  case kTp_Poly:
  case kTp_Err:
  case kTp_Any:
  case kTp_Base:
  case kTp_Power:
  case kTp_Seq:
  case kTp_Prefix:
  case kTp_Infix:
  case kTp_CartProd:
  case kTp_Schema:
/* line 103 "types.puma" */
  {
/* line 104 "types.puma" */
GetString(typ->Tp_Exp.Ident,mystr);
		printf("%s", mystr);
  }
   return;

  }

;
}

static void PrintCartList
# if defined __STDC__ | defined __cplusplus
(register tType yyP2)
# else
(yyP2)
 register tType yyP2;
# endif
{
  if (yyP2 == NULL) {
/* line 144 "types.puma" */
   return;

  }
  if (yyP2->Kind == kTp_Cart) {
/* line 145 "types.puma" */
  {
/* line 146 "types.puma" */
WPrintTy(yyP2->Tp_Cart.Tp_Exp);
		if (Type_IsType(yyP2->Tp_Cart.Next,kTp_Cart))
			printf(" # ");
		PrintCartList(yyP2->Tp_Cart.Next);
  }
   return;

  }
  if (yyP2->Kind == kTp_NoCart) {
/* line 150 "types.puma" */
   return;

  }
/* line 151 "types.puma" */
   return;

;
}

static void PrintSchFieldList
# if defined __STDC__ | defined __cplusplus
(register tType yyP3)
# else
(yyP3)
 register tType yyP3;
# endif
{
/* line 153 "types.puma" */
char mystr[IDENT_LENGTH];
  if (yyP3 == NULL) {
/* line 154 "types.puma" */
   return;

  }
  if (yyP3->Kind == kTp_NoSchField) {
/* line 155 "types.puma" */
   return;

  }
  if (yyP3->Kind == kTp_SchField) {
/* line 156 "types.puma" */
  {
/* line 157 "types.puma" */
GetString(yyP3->Tp_SchField.Ident,mystr);
		("%s",mystr);
		if (yyP3->Tp_SchField.QuId != NoIdent) {
			mystr[0] = '\0';
                        GetString (yyP3->Tp_SchField.QuId,mystr);
			printf ("(%s):", mystr);
			}
		else
			printf (":");
		WPrintTy(yyP3->Tp_SchField.Tp_Exp);
		if (Type_IsType(yyP3->Tp_SchField.Next,kTp_SchField))
			printf (", ");
		
  }
   return;

  }
;
}

void BeginTypeAccess ()
{
}

void CloseTypeAccess ()
{
}
