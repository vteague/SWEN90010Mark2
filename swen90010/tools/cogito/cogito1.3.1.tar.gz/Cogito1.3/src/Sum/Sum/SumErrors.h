# ifndef yySumErrors
# define yySumErrors

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "Tree.h"
# include "Type.h"

/* line 6 "sumerrors.puma" */

#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "env.h"
#include "DecodeType.h"


extern void (* SumErrors_Exit) ();

extern void ErrorInSetElab ARGS((tType t));
extern void ErrorInParams ARGS((tType ftype, tType argtype, int i));
extern void ErrorInFnType ARGS((tType f));
extern void ErrorInFnResult ARGS((tType ftype, tType rtype));
extern void ErrorInInfix ARGS((tIdent inId, tType ltype, tType rtype));
extern void ErrorInPrefix ARGS((tIdent preId, tType argtype));
extern void ErrorInPrefixNoArg ARGS((tIdent preId));
extern void NoMoreFncOverloads ARGS((tType ftype, tType argtype));
extern void NoMorePrefixOverloads ARGS((tIdent preId, tType ftype, tType argtype));
extern void NoMoreInfixOverloads ARGS((tIdent inId, tType ftype, tType ltype, tType rtype));
extern void ErrorInName ARGS((tTree id));
extern void ErrorInThetaName ARGS((tType exp));

extern void BeginSumErrors ();
extern void CloseSumErrors ();

# endif
