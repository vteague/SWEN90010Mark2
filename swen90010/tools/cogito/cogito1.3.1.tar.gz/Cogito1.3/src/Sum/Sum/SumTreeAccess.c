# include "SumTreeAccess.h"
# include "yySumTreeAccess.w"
# include "System.h"
# include <stdio.h>
# include "Tree.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 17 "sumtree.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "env.h"
#include "Tree.h"


static void yyExit () { Exit (1); }

void (* SumTreeAccess_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module SumTreeAccess, routine %s failed\n", yyFunction);
 SumTreeAccess_Exit ();
}

tTree CatDeclList ARGS((tTree d1, tTree d2));
tTree CatPredList ARGS((tTree p1, tTree p2));
tTree FormalParams2CartProd ARGS((tTree yyP1));
static tTree ExpressionListFromFormalParams ARGS((tTree yyP2));
tTree CatExpressionList ARGS((tTree e1, tTree e2));
static bool SameIds ARGS((tIdPos id1, tIdPos id2));
static bool InParamList ARGS((tTree yyP3, tIdPos id));
tTree CatFormalParams ARGS((tTree f1, tTree f2));
bool InImportList ARGS((tIdPos n, tTree yyP4));
bool InIdList ARGS((tIdPos n, tTree yyP5));

tTree CatDeclList
# if defined __STDC__ | defined __cplusplus
(register tTree d1, register tTree d2)
# else
(d1, d2)
 register tTree d1;
 register tTree d2;
# endif
{
/* line 31 "sumtree.puma" */
tTree tree;
  if (d1->Kind == kNoDecl) {
/* line 32 "sumtree.puma" */
  {
/* line 32 "sumtree.puma" */
tree = d2;
  }
   return tree;

  }

  switch (d2->Kind) {
  case kNoDecl:
/* line 33 "sumtree.puma" */
  {
/* line 33 "sumtree.puma" */
tree = d1;
  }
   return tree;

  case kVarDecl:
/* line 34 "sumtree.puma" */
  {
/* line 35 "sumtree.puma" */
tree = CatDeclList(mVarDecl(d1,d2->VarDecl.IdList,d2->VarDecl.Exp,d2->VarDecl.VarDeclKind),d2->VarDecl.Next);
  }
   return tree;

  case kGivenSet:
/* line 36 "sumtree.puma" */
  {
/* line 37 "sumtree.puma" */
tree = CatDeclList(mGivenSet(d1,d2->GivenSet.IdList),d2->GivenSet.Next);
  }
   return tree;

  case kAxiomDecl:
/* line 38 "sumtree.puma" */
  {
/* line 39 "sumtree.puma" */
tree = CatDeclList(mAxiomDecl(d1,d2->AxiomDecl.FormalParams,d2->AxiomDecl.DeclList,d2->AxiomDecl.PredList),d2->AxiomDecl.Next);
  }
   return tree;

  case kSchemaDef:
/* line 40 "sumtree.puma" */
  {
/* line 41 "sumtree.puma" */
tree = CatDeclList(mSchemaDef(d1,d2->SchemaDef.Ident,d2->SchemaDef.FormalParams,d2->SchemaDef.DeclList,d2->SchemaDef.PredList,d2->SchemaDef.IsOp),d2->SchemaDef.Next);
  }
   return tree;

  case kAbbreviation:
/* line 42 "sumtree.puma" */
  {
/* line 43 "sumtree.puma" */
tree = CatDeclList(mAbbreviation(d1,d2->Abbreviation.Ident,d2->Abbreviation.Exp),d2->Abbreviation.Next);
  }
   return tree;

  case kFreeType:
/* line 44 "sumtree.puma" */
  {
/* line 45 "sumtree.puma" */
tree = CatDeclList(mFreeType(d1,d2->FreeType.Ident,d2->FreeType.BranchList),d2->FreeType.Next);
  }
   return tree;

  case kFunctionDecl:
/* line 46 "sumtree.puma" */
  {
/* line 47 "sumtree.puma" */
tree = CatDeclList(mFunctionDecl(d1,d2->FunctionDecl.DeclList,d2->FunctionDecl.PredList),d2->FunctionDecl.Next);
  }
   return tree;

  case kImport:
/* line 48 "sumtree.puma" */
  {
/* line 49 "sumtree.puma" */
tree = CatDeclList(mImport(d1,d2->Import.Ident,d2->Import.ExpressionList,d2->Import.RenameList,d2->Import.NewIdent),d2->Import.Next);
  }
   return tree;

  case kModuleDecl:
/* line 50 "sumtree.puma" */
  {
/* line 51 "sumtree.puma" */
tree = CatDeclList(mModuleDecl(d1,d2->ModuleDecl.Module),d2->ModuleDecl.Next);
  }
   return tree;

  case kConstraint:
/* line 52 "sumtree.puma" */
  {
/* line 53 "sumtree.puma" */
tree = CatDeclList(mConstraint(d1,d2->Constraint.Pred),d2->Constraint.Next);
  }
   return tree;

  case kSchemaIncl:
/* line 54 "sumtree.puma" */
  {
/* line 55 "sumtree.puma" */
tree = CatDeclList(mSchemaIncl(d1,d2->SchemaIncl.IdList,d2->SchemaIncl.ExpressionList),d2->SchemaIncl.Next);
  }
   return tree;

  case kVisibility:
/* line 56 "sumtree.puma" */
  {
/* line 57 "sumtree.puma" */
tree = CatDeclList(mVisibility(d1,d2->Visibility.Ident,d2->Visibility.SelectionList),d2->Visibility.Next);
  }
   return tree;

  }

/* line 58 "sumtree.puma" */
  {
/* line 58 "sumtree.puma" */
tree = d1;
  }
   return tree;

}

tTree CatPredList
# if defined __STDC__ | defined __cplusplus
(register tTree p1, register tTree p2)
# else
(p1, p2)
 register tTree p1;
 register tTree p2;
# endif
{
/* line 61 "sumtree.puma" */
tTree tree;
  if (p1->Kind == kNoPred) {
/* line 62 "sumtree.puma" */
  {
/* line 62 "sumtree.puma" */
tree = p2;
  }
   return tree;

  }

  switch (p2->Kind) {
  case kNoPred:
/* line 63 "sumtree.puma" */
  {
/* line 63 "sumtree.puma" */
tree = p1;
  }
   return tree;

  case kQuantPred:
/* line 64 "sumtree.puma" */
  {
/* line 65 "sumtree.puma" */
tree = CatPredList(mQuantPred(p1,p2->QuantPred.LogQuant,p2->QuantPred.SchemaText,p2->QuantPred.Pred),p2->QuantPred.Next);
  }
   return tree;

  case kRelBinPred:
/* line 66 "sumtree.puma" */
  {
/* line 67 "sumtree.puma" */
tree = CatPredList(mRelBinPred(p1,p2->RelBinPred.L,p2->RelBinPred.RelBinOp,p2->RelBinPred.R),p2->RelBinPred.Next);
  }
   return tree;

  case kRelPrePred:
/* line 68 "sumtree.puma" */
  {
/* line 69 "sumtree.puma" */
tree = CatPredList(mRelPrePred(p1,p2->RelPrePred.RelPreOp,p2->RelPrePred.Exp),p2->RelPrePred.Next);
  }
   return tree;

  case kLogBinPred:
/* line 70 "sumtree.puma" */
  {
/* line 71 "sumtree.puma" */
tree = CatPredList(mLogBinPred(p1,p2->LogBinPred.L,p2->LogBinPred.LogBinOp,p2->LogBinPred.R),p2->LogBinPred.Next);
  }
   return tree;

  case kLogicalNot:
/* line 72 "sumtree.puma" */
  {
/* line 73 "sumtree.puma" */
tree = CatPredList(mLogicalNot(p1,p2->LogicalNot.Pred),p2->LogicalNot.Next);
  }
   return tree;

  case kPreCondPred:
/* line 74 "sumtree.puma" */
  {
/* line 75 "sumtree.puma" */
tree = CatPredList(mPreCondPred(p1,p2->PreCondPred.Pred),p2->PreCondPred.Next);
  }
   return tree;

  case kIfPred:
/* line 76 "sumtree.puma" */
  {
/* line 77 "sumtree.puma" */
tree = CatPredList(mIfPred(p1,p2->IfPred.Con,p2->IfPred.Then,p2->IfPred.Else),p2->IfPred.Next);
  }
   return tree;

  case kChgOnly:
/* line 78 "sumtree.puma" */
  {
/* line 79 "sumtree.puma" */
tree = CatPredList(mChgOnly(p1,p2->ChgOnly.NameList),p2->ChgOnly.Next);
  }
   return tree;

  case kSchemaPred:
/* line 80 "sumtree.puma" */
  {
/* line 81 "sumtree.puma" */
tree = CatPredList(mSchemaPred(p1,p2->SchemaPred.Schema),p2->SchemaPred.Next);
  }
   return tree;

  case kBoolValue:
/* line 82 "sumtree.puma" */
  {
/* line 83 "sumtree.puma" */
tree = CatPredList(mBoolValue(p1,p2->BoolValue.Ident),p2->BoolValue.Next);
  }
   return tree;

  }

/* line 84 "sumtree.puma" */
   return mNoPred ();

}

tTree FormalParams2CartProd
# if defined __STDC__ | defined __cplusplus
(register tTree yyP1)
# else
(yyP1)
 register tTree yyP1;
# endif
{
/* line 87 "sumtree.puma" */
tTree tree;
  if (yyP1->Kind == kTyParam) {
/* line 88 "sumtree.puma" */
  {
/* line 89 "sumtree.puma" */
tTree it,el;
		it = mId(mNoId(),yyP1->TyParam.Ident,4);
		el = mVariable(ExpressionListFromFormalParams(yyP1->TyParam.Next),it);
		tree = mCartProd(mNoExp(),el);
  }
   return tree;

  }
/* line 93 "sumtree.puma" */
   return mCartProd (mNoExp (), mNoExp ());

}

static tTree ExpressionListFromFormalParams
# if defined __STDC__ | defined __cplusplus
(register tTree yyP2)
# else
(yyP2)
 register tTree yyP2;
# endif
{
/* line 96 "sumtree.puma" */
tTree tree;
  if (yyP2->Kind == kTyParam) {
/* line 97 "sumtree.puma" */
  {
/* line 98 "sumtree.puma" */
tTree it,et;
		it = mId(mNoId(),yyP2->TyParam.Ident,4);
		tree = mVariable(ExpressionListFromFormalParams(yyP2->TyParam.Next),it);
  }
   return tree;

  }
  if (yyP2->Kind == kNoParam) {
/* line 101 "sumtree.puma" */
   return mNoExp ();

  }
 yyAbort ("ExpressionListFromFormalParams");
}

tTree CatExpressionList
# if defined __STDC__ | defined __cplusplus
(register tTree e1, register tTree e2)
# else
(e1, e2)
 register tTree e1;
 register tTree e2;
# endif
{
/* line 105 "sumtree.puma" */
tTree tree;
  if (e2->Kind == kNoExp) {
/* line 106 "sumtree.puma" */
  {
/* line 106 "sumtree.puma" */
tree=e1;
  }
   return tree;

  }
  if (e1->Kind == kNoExp) {
/* line 107 "sumtree.puma" */
  {
/* line 107 "sumtree.puma" */
tree=e2;
  }
   return tree;

  }

  switch (e2->Kind) {
  case kVariable:
/* line 108 "sumtree.puma" */
  {
/* line 109 "sumtree.puma" */
tree = CatExpressionList(mVariable(e1,e2->Variable.IdList),e2->Variable.Next);
  }
   return tree;

  case kLiteral:
/* line 110 "sumtree.puma" */
  {
/* line 111 "sumtree.puma" */
tree = CatExpressionList(mLiteral(e1,e2->Literal.Literal),e2->Literal.Next);
  }
   return tree;

  case kPrefixOp:
/* line 112 "sumtree.puma" */
  {
/* line 113 "sumtree.puma" */
tree = CatExpressionList(mPrefixOp(e1,e2->PrefixOp.Prefix,e2->PrefixOp.Exp),e2->PrefixOp.Next);
  }
   return tree;

  case kLambda:
/* line 114 "sumtree.puma" */
  {
/* line 115 "sumtree.puma" */
tree = CatExpressionList(mLambda(e1,e2->Lambda.SchemaText,e2->Lambda.Exp),e2->Lambda.Next);
  }
   return tree;

  case kMu:
/* line 116 "sumtree.puma" */
  {
/* line 117 "sumtree.puma" */
tree = CatExpressionList(mMu(e1,e2->Mu.SchemaText,e2->Mu.ExpressionList),e2->Mu.Next);
  }
   return tree;

  case kIfExp:
/* line 118 "sumtree.puma" */
  {
/* line 119 "sumtree.puma" */
tree = CatExpressionList(mIfExp(e1,e2->IfExp.Con,e2->IfExp.Then,e2->IfExp.Else),e2->IfExp.Next);
  }
   return tree;

  case kFncApplication:
/* line 120 "sumtree.puma" */
  {
/* line 121 "sumtree.puma" */
tree = CatExpressionList(mFncApplication(e1,e2->FncApplication.Fnc,e2->FncApplication.Arg),e2->FncApplication.Next);
  }
   return tree;

  case kSetComp:
/* line 122 "sumtree.puma" */
  {
/* line 123 "sumtree.puma" */
tree = CatExpressionList(mSetComp(e1,e2->SetComp.SchemaText,e2->SetComp.ExpressionList),e2->SetComp.Next);
  }
   return tree;

  case kSetElab:
/* line 124 "sumtree.puma" */
  {
/* line 125 "sumtree.puma" */
tree = CatExpressionList(mSetElab(e1,e2->SetElab.ExpressionList),e2->SetElab.Next);
  }
   return tree;

  case kSequence:
/* line 126 "sumtree.puma" */
  {
/* line 127 "sumtree.puma" */
tree = CatExpressionList(mSequence(e1,e2->Sequence.ExpressionList),e2->Sequence.Next);
  }
   return tree;

  case kBag:
/* line 128 "sumtree.puma" */
  {
/* line 129 "sumtree.puma" */
tree = CatExpressionList(mBag(e1,e2->Bag.ExpressionList),e2->Bag.Next);
  }
   return tree;

  case kCartProd:
/* line 130 "sumtree.puma" */
  {
/* line 131 "sumtree.puma" */
tree = CatExpressionList(mCartProd(e1,e2->CartProd.ExpressionList),e2->CartProd.Next);
  }
   return tree;

  case kTuple:
/* line 132 "sumtree.puma" */
  {
/* line 133 "sumtree.puma" */
tree = CatExpressionList(mTuple(e1,e2->Tuple.ExpressionList),e2->Tuple.Next);
  }
   return tree;

  case kExp_SchemaRef:
/* line 134 "sumtree.puma" */
  {
/* line 135 "sumtree.puma" */
tree = CatExpressionList(mExp_SchemaRef(e1,e2->Exp_SchemaRef.IdList,e2->Exp_SchemaRef.ExpressionList),e2->Exp_SchemaRef.Next);
  }
   return tree;

  case kInfixOp:
/* line 136 "sumtree.puma" */
  {
/* line 137 "sumtree.puma" */
tree = CatExpressionList(mInfixOp(e1,e2->InfixOp.Op1,e2->InfixOp.Infix,e2->InfixOp.Op2),e2->InfixOp.Next);
  }
   return tree;

  case kPredExp:
/* line 138 "sumtree.puma" */
  {
/* line 139 "sumtree.puma" */
tree = CatExpressionList(mPredExp(e1,e2->PredExp.Pred),e2->PredExp.Next);
  }
   return tree;

  }

/* line 140 "sumtree.puma" */
  {
/* line 140 "sumtree.puma" */
tree=e1;
  }
   return tree;

}

static bool SameIds
# if defined __STDC__ | defined __cplusplus
(tIdPos id1, tIdPos id2)
# else
(id1, id2)
 tIdPos id1;
 tIdPos id2;
# endif
{
/* line 144 "sumtree.puma" */
int found;
/* line 147 "sumtree.puma" */
  {
/* line 149 "sumtree.puma" */
char s1[256], s2[256]; 
	GetString(id1.Ident,s1);
	GetString(id2.Ident,s2);
	found = strcmp(s1,s2);

	
/* line 155 "sumtree.puma" */
   if (! ((found != 0))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

static bool InParamList
# if defined __STDC__ | defined __cplusplus
(register tTree yyP3, tIdPos id)
# else
(yyP3, id)
 register tTree yyP3;
 tIdPos id;
# endif
{
  if (yyP3->Kind == kTyParam) {
/* line 160 "sumtree.puma" */
  {
/* line 160 "sumtree.puma" */
   if (! (SameIds (yyP3->TyParam.Ident, id))) goto yyL1;
  }
   return true;
yyL1:;

  }
  return false;
}

tTree CatFormalParams
# if defined __STDC__ | defined __cplusplus
(register tTree f1, register tTree f2)
# else
(f1, f2)
 register tTree f1;
 register tTree f2;
# endif
{
/* line 164 "sumtree.puma" */
tTree tree;
  if (f2->Kind == kNoParam) {
/* line 165 "sumtree.puma" */
  {
/* line 165 "sumtree.puma" */
tree=f1;
  }
   return tree;

  }
  if (f1->Kind == kNoParam) {
/* line 166 "sumtree.puma" */
  {
/* line 166 "sumtree.puma" */
tree=f2;
  }
   return tree;

  }
  if (f2->Kind == kTyParam) {
/* line 167 "sumtree.puma" */
  {
/* line 168 "sumtree.puma" */
if (InParamList(f1,f2->TyParam.Ident))
			tree = f1;
		else
			tree = CatFormalParams(mTyParam(f1,f2->TyParam.Ident,f2->TyParam.IsPolyTy),f2->TyParam.Next);
  }
   return tree;

  }
/* line 172 "sumtree.puma" */
  {
/* line 172 "sumtree.puma" */
tree=f1;
  }
   return tree;

}

bool InImportList
# if defined __STDC__ | defined __cplusplus
(tIdPos n, register tTree yyP4)
# else
(n, yyP4)
 tIdPos n;
 register tTree yyP4;
# endif
{
  if (yyP4->Kind == kImport) {
/* line 176 "sumtree.puma" */
  {
/* line 177 "sumtree.puma" */
   if (! ((SameIds (yyP4->Import.Ident, n) || InImportList (n, yyP4->Import.Next)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  if (yyP4->Kind == kVisibility) {
/* line 178 "sumtree.puma" */
  {
/* line 179 "sumtree.puma" */
   if (! ((SameIds (yyP4->Visibility.Ident, n) || InImportList (n, yyP4->Visibility.Next)))) goto yyL2;
  }
   return true;
yyL2:;

  }
  return false;
}

bool InIdList
# if defined __STDC__ | defined __cplusplus
(tIdPos n, register tTree yyP5)
# else
(n, yyP5)
 tIdPos n;
 register tTree yyP5;
# endif
{
  if (yyP5->Kind == kId) {
/* line 183 "sumtree.puma" */
  {
/* line 184 "sumtree.puma" */
   if (! ((SameIds (yyP5->Id.Ident, n) || InIdList (n, yyP5->Id.Next)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  return false;
}

void BeginSumTreeAccess ()
{
}

void CloseSumTreeAccess ()
{
}
