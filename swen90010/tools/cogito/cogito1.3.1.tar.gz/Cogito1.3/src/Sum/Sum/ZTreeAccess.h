# ifndef yyZTreeAccess
# define yyZTreeAccess

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "ZTree.h"

/* line 7 "ztree.puma" */

#include "Idents.h"
#include "Positions.h"
#include "global.h"
typedef char * string;
#include "env.h"


extern void (* ZTreeAccess_Exit) ();

extern void VarDecCat ARGS((tZTree * dec, tIdPos * id));
extern void StrokeCat ARGS((tZTree dec, tString str));
extern tIdPos IdDecCat ARGS((tIdPos id, tZTree dec));
extern tPosition VarPos ARGS((tZTree yyP1));
extern tPosition NamePos ARGS((tZTree yyP2));
extern void AddDeltaDes ARGS((tZTree * d));
extern void AddDeltaWord ARGS((tIdPos * id));
extern void AddXiDes ARGS((tZTree * d));
extern void AddXiWord ARGS((tIdPos * id));
extern void CatSubscriptWord ARGS((tIdPos * id1, tIdPos id2));
extern bool IsPre ARGS((tIdPos id));
extern void AddSchemaRef ARGS((tZTree * d));
extern bool IsEmptySet ARGS((tIdPos id));
extern bool IsEol ARGS((tIdPos id));
extern bool ThetaNotRenamed ARGS((tZTree yyP3));

extern void BeginZTreeAccess ();
extern void CloseZTreeAccess ();

# endif
