# ifndef yySemantics
# define yySemantics

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# include "Tree.h"

/* line 77 "sum.cg" */

# include "Tree.h"
# include "global.h"
# include "Idents.h"
# include "Positions.h"
# include "ratc.h"
# include "Syms.h"
# include "Type.h"
# include "copymod.h"


extern void Semantics ARGS((tTree yyt));
extern void BeginSemantics ();
extern void CloseSemantics ();

# endif
