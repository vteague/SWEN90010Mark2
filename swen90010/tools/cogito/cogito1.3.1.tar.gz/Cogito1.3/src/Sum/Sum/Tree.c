# include "Tree.h"
# define yyALLOC(ptr, size)	if ((ptr = (tTree) Tree_PoolFreePtr) >= (tTree) Tree_PoolMaxPtr) \
  ptr = Tree_Alloc (); \
  Tree_PoolFreePtr += size;
# define yyFREE(ptr, size)	
# ifdef __cplusplus
extern "C" {
# include <stdio.h>
# include "yyTree.w"
# include "System.h"
# include "General.h"
# include "Memory.h"
# include "DynArray.h"
# include "StringMem.h"
# include "Idents.h"
# include "Sets.h"
# include "Positions.h"
}
# else
# include <stdio.h>
# include "yyTree.w"
# include "System.h"
# include "General.h"
# include "Memory.h"
# include "DynArray.h"
# include "StringMem.h"
# include "Idents.h"
# include "Sets.h"
# include "Positions.h"
# endif

/* line 40 "sum.cg" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
# include "Idents.h"
# include "Positions.h"
# include "ratc.h"
# include "Syms.h"
# include "global.h"
# include "Type.h" 
# include "copymod.h"
# include "SymAccess.h"
#include <stdlib.h>

#define writetPosition(pos) WritePosition(yyf,pos);
#define readtPosition(a) ReadPosition(yyf,&a);
#define writetIdPos(a) WriteIdPos(yyf,a);
#define readtIdPos(a) ReadIdPos(yyf,&a);


int CountSemErr = 0;
tIdent ModIdent;
IML_List cur_mod_imllist_hd = (IML_List) NULL;
IML_List cur_mod_imllist = (IML_List) NULL;

void Error (Position, Text) 
    tPosition Position;
    char *Text;
{
    Message (Text, xxError, Position);
    CountSemErr++;
}



static void yyExit () { Exit (1); }

void (* Tree_Exit) () = yyExit;

# define yyBlockSize 20480

typedef struct yysBlock {
 char yyBlock [yyBlockSize];
 struct yysBlock * yySuccessor;
} yytBlock, * yytBlockPtr;

tTree TreeRoot;
unsigned long Tree_HeapUsed = 0;

static yytBlockPtr yyBlockList	= (yytBlockPtr) NoTree;
char * Tree_PoolFreePtr	= (char *) NoTree;
char * Tree_PoolMaxPtr	= (char *) NoTree;
static unsigned short yyMaxSize	= 0;
unsigned short Tree_NodeSize [116 + 1] = { 0,
 sizeof (ySum),
 sizeof (yModuleList),
 sizeof (yNoModule),
 sizeof (yModule),
 sizeof (yFormalParams),
 sizeof (yNoParam),
 sizeof (yParam),
 sizeof (yTyParam),
 sizeof (yFncParam),
 sizeof (yRenameList),
 sizeof (yNoRename),
 sizeof (yRename),
 sizeof (ySelectionList),
 sizeof (yNoSelection),
 sizeof (ySelection),
 sizeof (yIdList),
 sizeof (yNoId),
 sizeof (yId),
 sizeof (yNameList),
 sizeof (yNoName),
 sizeof (yName),
 sizeof (yExpressionList),
 sizeof (yNoExp),
 sizeof (yExp),
 sizeof (yVariable),
 sizeof (yLiteral),
 sizeof (yString),
 sizeof (yChar),
 sizeof (yPrefixOp),
 sizeof (yLambda),
 sizeof (yRecDisp),
 sizeof (yMu),
 sizeof (yTupSelection),
 sizeof (yVarSelection),
 sizeof (yIfExp),
 sizeof (yFncApplication),
 sizeof (ySetComp),
 sizeof (ySetElab),
 sizeof (yArrayUpd),
 sizeof (yNamedArrayAgg),
 sizeof (ySequence),
 sizeof (yBag),
 sizeof (yCartProd),
 sizeof (yTuple),
 sizeof (yExp_SchemaRef),
 sizeof (yTheta),
 sizeof (yInfixOp),
 sizeof (yPredExp),
 sizeof (yPredList),
 sizeof (yNoPred),
 sizeof (yPred),
 sizeof (yQuantPred),
 sizeof (yRelBinPred),
 sizeof (yAssign),
 sizeof (yRelPrePred),
 sizeof (yLogBinPred),
 sizeof (yLogicalNot),
 sizeof (yPreCondPred),
 sizeof (yIfPred),
 sizeof (yWhilePred),
 sizeof (yCallPred),
 sizeof (yChgOnly),
 sizeof (yDefined),
 sizeof (ySchemaPred),
 sizeof (yBoolValue),
 sizeof (yInputBindList),
 sizeof (yNoInputBind),
 sizeof (yInputBind),
 sizeof (yOutputBindList),
 sizeof (yNoOutputBind),
 sizeof (yOutputBind),
 sizeof (yLogBinOp),
 sizeof (yLogSeq),
 sizeof (yLogAnd),
 sizeof (yLogExor),
 sizeof (yLogOr),
 sizeof (yLogImply),
 sizeof (yLogEquiv),
 sizeof (yDeclList),
 sizeof (yNoDecl),
 sizeof (yDecl),
 sizeof (yVarDecl),
 sizeof (yGivenSet),
 sizeof (yAxiomDecl),
 sizeof (ySchemaDef),
 sizeof (yAnnotation),
 sizeof (yErgoAnno),
 sizeof (yStateMachine),
 sizeof (yAbbreviation),
 sizeof (yFunctionDecl),
 sizeof (yFreeType),
 sizeof (yEnum),
 sizeof (yImport),
 sizeof (yModuleDecl),
 sizeof (yConstraint),
 sizeof (ySchemaIncl),
 sizeof (yVisibility),
 sizeof (yBranchList),
 sizeof (yNoBranch),
 sizeof (yBranch),
 sizeof (yFTConstant),
 sizeof (yFTConstructor),
 sizeof (ySchema),
 sizeof (yExpPred),
 sizeof (ySchemaText),
 sizeof (ySchemaRef),
 sizeof (ySchemaCons),
 sizeof (ySchemaCompos),
 sizeof (ySchemaProj),
 sizeof (ySchemaSubst),
 sizeof (ySchemaHiding),
 sizeof (yLogOp),
 sizeof (ySDisjunction),
 sizeof (ySConjunction),
 sizeof (ySImplication),
 sizeof (ySEquivalence),
};
char * Tree_NodeName [116 + 1] = {
 "NoTree",
 "Sum",
 "ModuleList",
 "NoModule",
 "Module",
 "FormalParams",
 "NoParam",
 "Param",
 "TyParam",
 "FncParam",
 "RenameList",
 "NoRename",
 "Rename",
 "SelectionList",
 "NoSelection",
 "Selection",
 "IdList",
 "NoId",
 "Id",
 "NameList",
 "NoName",
 "Name",
 "ExpressionList",
 "NoExp",
 "Exp",
 "Variable",
 "Literal",
 "String",
 "Char",
 "PrefixOp",
 "Lambda",
 "RecDisp",
 "Mu",
 "TupSelection",
 "VarSelection",
 "IfExp",
 "FncApplication",
 "SetComp",
 "SetElab",
 "ArrayUpd",
 "NamedArrayAgg",
 "Sequence",
 "Bag",
 "CartProd",
 "Tuple",
 "Exp_SchemaRef",
 "Theta",
 "InfixOp",
 "PredExp",
 "PredList",
 "NoPred",
 "Pred",
 "QuantPred",
 "RelBinPred",
 "Assign",
 "RelPrePred",
 "LogBinPred",
 "LogicalNot",
 "PreCondPred",
 "IfPred",
 "WhilePred",
 "CallPred",
 "ChgOnly",
 "Defined",
 "SchemaPred",
 "BoolValue",
 "InputBindList",
 "NoInputBind",
 "InputBind",
 "OutputBindList",
 "NoOutputBind",
 "OutputBind",
 "LogBinOp",
 "LogSeq",
 "LogAnd",
 "LogExor",
 "LogOr",
 "LogImply",
 "LogEquiv",
 "DeclList",
 "NoDecl",
 "Decl",
 "VarDecl",
 "GivenSet",
 "AxiomDecl",
 "SchemaDef",
 "Annotation",
 "ErgoAnno",
 "StateMachine",
 "Abbreviation",
 "FunctionDecl",
 "FreeType",
 "Enum",
 "Import",
 "ModuleDecl",
 "Constraint",
 "SchemaIncl",
 "Visibility",
 "BranchList",
 "NoBranch",
 "Branch",
 "FTConstant",
 "FTConstructor",
 "Schema",
 "ExpPred",
 "SchemaText",
 "SchemaRef",
 "SchemaCons",
 "SchemaCompos",
 "SchemaProj",
 "SchemaSubst",
 "SchemaHiding",
 "LogOp",
 "SDisjunction",
 "SConjunction",
 "SImplication",
 "SEquivalence",
};
static Tree_tKind yyTypeRange [116 + 1] = { 0,
 kSum,
 kModule,
 kNoModule,
 kModule,
 kFncParam,
 kNoParam,
 kFncParam,
 kTyParam,
 kFncParam,
 kRename,
 kNoRename,
 kRename,
 kSelection,
 kNoSelection,
 kSelection,
 kId,
 kNoId,
 kId,
 kName,
 kNoName,
 kName,
 kPredExp,
 kNoExp,
 kPredExp,
 kVariable,
 kLiteral,
 kString,
 kChar,
 kPrefixOp,
 kLambda,
 kRecDisp,
 kMu,
 kTupSelection,
 kVarSelection,
 kIfExp,
 kFncApplication,
 kSetComp,
 kSetElab,
 kArrayUpd,
 kNamedArrayAgg,
 kSequence,
 kBag,
 kCartProd,
 kTuple,
 kExp_SchemaRef,
 kTheta,
 kInfixOp,
 kPredExp,
 kBoolValue,
 kNoPred,
 kBoolValue,
 kQuantPred,
 kRelBinPred,
 kAssign,
 kRelPrePred,
 kLogBinPred,
 kLogicalNot,
 kPreCondPred,
 kIfPred,
 kWhilePred,
 kCallPred,
 kChgOnly,
 kDefined,
 kSchemaPred,
 kBoolValue,
 kInputBind,
 kNoInputBind,
 kInputBind,
 kOutputBind,
 kNoOutputBind,
 kOutputBind,
 kLogEquiv,
 kLogSeq,
 kLogAnd,
 kLogExor,
 kLogOr,
 kLogImply,
 kLogEquiv,
 kVisibility,
 kNoDecl,
 kVisibility,
 kVarDecl,
 kGivenSet,
 kAxiomDecl,
 kSchemaDef,
 kAnnotation,
 kErgoAnno,
 kStateMachine,
 kAbbreviation,
 kFunctionDecl,
 kFreeType,
 kEnum,
 kImport,
 kModuleDecl,
 kConstraint,
 kSchemaIncl,
 kVisibility,
 kFTConstructor,
 kNoBranch,
 kFTConstructor,
 kFTConstant,
 kFTConstructor,
 kSchemaHiding,
 kExpPred,
 kSchemaText,
 kSchemaRef,
 kSchemaCons,
 kSchemaCompos,
 kSchemaProj,
 kSchemaSubst,
 kSchemaHiding,
 kSEquivalence,
 kSDisjunction,
 kSConjunction,
 kSImplication,
 kSEquivalence,
};

tTree Tree_Alloc ()
{
 register yytBlockPtr yyBlockPtr = yyBlockList;
 register int i;

 if (yyMaxSize == 0)
  for (i = 1; i <= 116; i ++) {
   Tree_NodeSize [i] = (Tree_NodeSize [i] + yyMaxAlign - 1) & yyAlignMasks [yyMaxAlign];
   yyMaxSize = Max (Tree_NodeSize [i], yyMaxSize);
  }
 yyBlockList = (yytBlockPtr) Alloc (sizeof (yytBlock));
 yyBlockList->yySuccessor = yyBlockPtr;
 Tree_PoolFreePtr = yyBlockList->yyBlock;
 Tree_PoolMaxPtr = Tree_PoolFreePtr + yyBlockSize - yyMaxSize + 1;
 Tree_HeapUsed += yyBlockSize;
 return (tTree) Tree_PoolFreePtr;
}

tTree MakeTree
# if defined __STDC__ | defined __cplusplus
 (Tree_tKind yyKind)
# else
 (yyKind) Tree_tKind yyKind;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [yyKind])
 yyt->Kind = yyKind;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

bool Tree_IsType
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt, register Tree_tKind yyKind)
# else
 (yyt, yyKind) register tTree yyt; register Tree_tKind yyKind;
# endif
{
 return yyt != NoTree && yyKind <= yyt->Kind && yyt->Kind <= yyTypeRange [yyKind];
}


tTree mSum
# if defined __STDC__ | defined __cplusplus
(tTree pModuleList)
# else
(pModuleList)
tTree pModuleList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSum])
 yyt->Kind = kSum;
 yyt->yyHead.yyMark = 0;
 yyt->Sum.ModuleList = pModuleList;
 return yyt;
}

tTree mModuleList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kModuleList])
 yyt->Kind = kModuleList;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->ModuleList.Pos)
 begintObjects(yyt->ModuleList.DeclsIn)
 begintObjects(yyt->ModuleList.DeclsOut)
 return yyt;
}

tTree mNoModule
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoModule])
 yyt->Kind = kNoModule;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->NoModule.Pos)
 begintObjects(yyt->NoModule.DeclsIn)
 begintObjects(yyt->NoModule.DeclsOut)
 return yyt;
}

tTree mModule
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent, tTree pFormalParams, tTree pPredList, tTree pDeclList, bool pIsNested)
# else
(pNext, pIdent, pFormalParams, pPredList, pDeclList, pIsNested)
tTree pNext;
tIdPos pIdent;
tTree pFormalParams;
tTree pPredList;
tTree pDeclList;
bool pIsNested;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kModule])
 yyt->Kind = kModule;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Module.Pos)
 begintObjects(yyt->Module.DeclsIn)
 begintObjects(yyt->Module.DeclsOut)
 yyt->Module.Next = pNext;
 yyt->Module.Ident = pIdent;
 yyt->Module.FormalParams = pFormalParams;
 yyt->Module.PredList = pPredList;
 yyt->Module.DeclList = pDeclList;
 yyt->Module.IsNested = pIsNested;
 return yyt;
}

tTree mFormalParams
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kFormalParams])
 yyt->Kind = kFormalParams;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->FormalParams.Pos)
 begintObjects(yyt->FormalParams.DeclsIn)
 begintObjects(yyt->FormalParams.DeclsOut)
 return yyt;
}

tTree mNoParam
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoParam])
 yyt->Kind = kNoParam;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->NoParam.Pos)
 begintObjects(yyt->NoParam.DeclsIn)
 begintObjects(yyt->NoParam.DeclsOut)
 return yyt;
}

tTree mParam
# if defined __STDC__ | defined __cplusplus
(tTree pNext)
# else
(pNext)
tTree pNext;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kParam])
 yyt->Kind = kParam;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Param.Pos)
 begintObjects(yyt->Param.DeclsIn)
 begintObjects(yyt->Param.DeclsOut)
 yyt->Param.Next = pNext;
 return yyt;
}

tTree mTyParam
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent, bool pIsPolyTy)
# else
(pNext, pIdent, pIsPolyTy)
tTree pNext;
tIdPos pIdent;
bool pIsPolyTy;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kTyParam])
 yyt->Kind = kTyParam;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->TyParam.Pos)
 begintObjects(yyt->TyParam.DeclsIn)
 begintObjects(yyt->TyParam.DeclsOut)
 yyt->TyParam.Next = pNext;
 yyt->TyParam.Ident = pIdent;
 yyt->TyParam.IsPolyTy = pIsPolyTy;
 return yyt;
}

tTree mFncParam
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pVarDecl)
# else
(pNext, pVarDecl)
tTree pNext;
tTree pVarDecl;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kFncParam])
 yyt->Kind = kFncParam;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->FncParam.Pos)
 begintObjects(yyt->FncParam.DeclsIn)
 begintObjects(yyt->FncParam.DeclsOut)
 yyt->FncParam.Next = pNext;
 yyt->FncParam.VarDecl = pVarDecl;
 return yyt;
}

tTree mRenameList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kRenameList])
 yyt->Kind = kRenameList;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->RenameList.DeclsIn)
 begintObjects(yyt->RenameList.DeclsOut)
 return yyt;
}

tTree mNoRename
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoRename])
 yyt->Kind = kNoRename;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->NoRename.DeclsIn)
 begintObjects(yyt->NoRename.DeclsOut)
 return yyt;
}

tTree mRename
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pNewIdent, tTree pOldIdent)
# else
(pNext, pNewIdent, pOldIdent)
tTree pNext;
tIdPos pNewIdent;
tTree pOldIdent;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kRename])
 yyt->Kind = kRename;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->Rename.DeclsIn)
 begintObjects(yyt->Rename.DeclsOut)
 yyt->Rename.Next = pNext;
 yyt->Rename.NewIdent = pNewIdent;
 yyt->Rename.OldIdent = pOldIdent;
 return yyt;
}

tTree mSelectionList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSelectionList])
 yyt->Kind = kSelectionList;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mNoSelection
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoSelection])
 yyt->Kind = kNoSelection;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mSelection
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent)
# else
(pNext, pIdent)
tTree pNext;
tIdPos pIdent;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSelection])
 yyt->Kind = kSelection;
 yyt->yyHead.yyMark = 0;
 yyt->Selection.Next = pNext;
 yyt->Selection.Ident = pIdent;
 return yyt;
}

tTree mIdList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kIdList])
 yyt->Kind = kIdList;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->IdList.Pos)
 begintObjects(yyt->IdList.DeclsIn)
 begintObjects(yyt->IdList.DeclsOut)
 return yyt;
}

tTree mNoId
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoId])
 yyt->Kind = kNoId;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->NoId.Pos)
 begintObjects(yyt->NoId.DeclsIn)
 begintObjects(yyt->NoId.DeclsOut)
 return yyt;
}

tTree mId
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent, int pIdKind)
# else
(pNext, pIdent, pIdKind)
tTree pNext;
tIdPos pIdent;
int pIdKind;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kId])
 yyt->Kind = kId;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Id.Pos)
 begintObjects(yyt->Id.DeclsIn)
 begintObjects(yyt->Id.DeclsOut)
 yyt->Id.Next = pNext;
 yyt->Id.Ident = pIdent;
 yyt->Id.IdKind = pIdKind;
 return yyt;
}

tTree mNameList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNameList])
 yyt->Kind = kNameList;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->NameList.Pos)
 begintObjects(yyt->NameList.DeclsIn)
 begintObjects(yyt->NameList.DeclsOut)
 return yyt;
}

tTree mNoName
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoName])
 yyt->Kind = kNoName;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->NoName.Pos)
 begintObjects(yyt->NoName.DeclsIn)
 begintObjects(yyt->NoName.DeclsOut)
 return yyt;
}

tTree mName
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pIdList)
# else
(pNext, pIdList)
tTree pNext;
tTree pIdList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kName])
 yyt->Kind = kName;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Name.Pos)
 begintObjects(yyt->Name.DeclsIn)
 begintObjects(yyt->Name.DeclsOut)
 yyt->Name.Next = pNext;
 yyt->Name.IdList = pIdList;
 return yyt;
}

tTree mExpressionList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kExpressionList])
 yyt->Kind = kExpressionList;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->ExpressionList.Pos)
 beginbool(yyt->ExpressionList.IsTypeExp)
 begintObjects(yyt->ExpressionList.DeclsIn)
 begintObjects(yyt->ExpressionList.DeclsOut)
 begintType(yyt->ExpressionList.Type)
 return yyt;
}

tTree mNoExp
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoExp])
 yyt->Kind = kNoExp;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->NoExp.Pos)
 beginbool(yyt->NoExp.IsTypeExp)
 begintObjects(yyt->NoExp.DeclsIn)
 begintObjects(yyt->NoExp.DeclsOut)
 begintType(yyt->NoExp.Type)
 return yyt;
}

tTree mExp
# if defined __STDC__ | defined __cplusplus
(tTree pNext)
# else
(pNext)
tTree pNext;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kExp])
 yyt->Kind = kExp;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Exp.Pos)
 beginbool(yyt->Exp.IsTypeExp)
 begintObjects(yyt->Exp.DeclsIn)
 begintObjects(yyt->Exp.DeclsOut)
 begintType(yyt->Exp.Type)
 yyt->Exp.Next = pNext;
 return yyt;
}

tTree mVariable
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pIdList)
# else
(pNext, pIdList)
tTree pNext;
tTree pIdList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kVariable])
 yyt->Kind = kVariable;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Variable.Pos)
 beginbool(yyt->Variable.IsTypeExp)
 begintObjects(yyt->Variable.DeclsIn)
 begintObjects(yyt->Variable.DeclsOut)
 begintType(yyt->Variable.Type)
 yyt->Variable.Next = pNext;
 yyt->Variable.IdList = pIdList;
 begintObjects(yyt->Variable.SymPtr)
 beginbool(yyt->Variable.IsBinding)
 return yyt;
}

tTree mLiteral
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pLiteral)
# else
(pNext, pLiteral)
tTree pNext;
tIdPos pLiteral;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLiteral])
 yyt->Kind = kLiteral;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Literal.Pos)
 beginbool(yyt->Literal.IsTypeExp)
 begintObjects(yyt->Literal.DeclsIn)
 begintObjects(yyt->Literal.DeclsOut)
 begintType(yyt->Literal.Type)
 yyt->Literal.Next = pNext;
 yyt->Literal.Literal = pLiteral;
 return yyt;
}

tTree mString
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pString)
# else
(pNext, pString)
tTree pNext;
tIdPos pString;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kString])
 yyt->Kind = kString;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->String.Pos)
 beginbool(yyt->String.IsTypeExp)
 begintObjects(yyt->String.DeclsIn)
 begintObjects(yyt->String.DeclsOut)
 begintType(yyt->String.Type)
 yyt->String.Next = pNext;
 yyt->String.String = pString;
 return yyt;
}

tTree mChar
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pChar)
# else
(pNext, pChar)
tTree pNext;
tIdPos pChar;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kChar])
 yyt->Kind = kChar;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Char.Pos)
 beginbool(yyt->Char.IsTypeExp)
 begintObjects(yyt->Char.DeclsIn)
 begintObjects(yyt->Char.DeclsOut)
 begintType(yyt->Char.Type)
 yyt->Char.Next = pNext;
 yyt->Char.Char = pChar;
 return yyt;
}

tTree mPrefixOp
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pPrefix, tTree pExp)
# else
(pNext, pPrefix, pExp)
tTree pNext;
tIdPos pPrefix;
tTree pExp;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kPrefixOp])
 yyt->Kind = kPrefixOp;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->PrefixOp.Pos)
 beginbool(yyt->PrefixOp.IsTypeExp)
 begintObjects(yyt->PrefixOp.DeclsIn)
 begintObjects(yyt->PrefixOp.DeclsOut)
 begintType(yyt->PrefixOp.Type)
 yyt->PrefixOp.Next = pNext;
 yyt->PrefixOp.Prefix = pPrefix;
 yyt->PrefixOp.Exp = pExp;
 return yyt;
}

tTree mLambda
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pSchemaText, tTree pExp)
# else
(pNext, pSchemaText, pExp)
tTree pNext;
tTree pSchemaText;
tTree pExp;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLambda])
 yyt->Kind = kLambda;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Lambda.Pos)
 beginbool(yyt->Lambda.IsTypeExp)
 begintObjects(yyt->Lambda.DeclsIn)
 begintObjects(yyt->Lambda.DeclsOut)
 begintType(yyt->Lambda.Type)
 yyt->Lambda.Next = pNext;
 yyt->Lambda.SchemaText = pSchemaText;
 yyt->Lambda.Exp = pExp;
 return yyt;
}

tTree mRecDisp
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pSchemaText, tTree pPredList)
# else
(pNext, pSchemaText, pPredList)
tTree pNext;
tTree pSchemaText;
tTree pPredList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kRecDisp])
 yyt->Kind = kRecDisp;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->RecDisp.Pos)
 beginbool(yyt->RecDisp.IsTypeExp)
 begintObjects(yyt->RecDisp.DeclsIn)
 begintObjects(yyt->RecDisp.DeclsOut)
 begintType(yyt->RecDisp.Type)
 yyt->RecDisp.Next = pNext;
 yyt->RecDisp.SchemaText = pSchemaText;
 yyt->RecDisp.PredList = pPredList;
 return yyt;
}

tTree mMu
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pSchemaText, tTree pExpressionList)
# else
(pNext, pSchemaText, pExpressionList)
tTree pNext;
tTree pSchemaText;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kMu])
 yyt->Kind = kMu;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Mu.Pos)
 beginbool(yyt->Mu.IsTypeExp)
 begintObjects(yyt->Mu.DeclsIn)
 begintObjects(yyt->Mu.DeclsOut)
 begintType(yyt->Mu.Type)
 yyt->Mu.Next = pNext;
 yyt->Mu.SchemaText = pSchemaText;
 yyt->Mu.ExpressionList = pExpressionList;
 return yyt;
}

tTree mTupSelection
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pExp, tIdPos pNumber)
# else
(pNext, pExp, pNumber)
tTree pNext;
tTree pExp;
tIdPos pNumber;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kTupSelection])
 yyt->Kind = kTupSelection;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->TupSelection.Pos)
 beginbool(yyt->TupSelection.IsTypeExp)
 begintObjects(yyt->TupSelection.DeclsIn)
 begintObjects(yyt->TupSelection.DeclsOut)
 begintType(yyt->TupSelection.Type)
 yyt->TupSelection.Next = pNext;
 yyt->TupSelection.Exp = pExp;
 yyt->TupSelection.Number = pNumber;
 return yyt;
}

tTree mVarSelection
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pExp, tIdPos pIdent)
# else
(pNext, pExp, pIdent)
tTree pNext;
tTree pExp;
tIdPos pIdent;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kVarSelection])
 yyt->Kind = kVarSelection;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->VarSelection.Pos)
 beginbool(yyt->VarSelection.IsTypeExp)
 begintObjects(yyt->VarSelection.DeclsIn)
 begintObjects(yyt->VarSelection.DeclsOut)
 begintType(yyt->VarSelection.Type)
 yyt->VarSelection.Next = pNext;
 yyt->VarSelection.Exp = pExp;
 yyt->VarSelection.Ident = pIdent;
 return yyt;
}

tTree mIfExp
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pCon, tTree pThen, tTree pElse)
# else
(pNext, pCon, pThen, pElse)
tTree pNext;
tTree pCon;
tTree pThen;
tTree pElse;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kIfExp])
 yyt->Kind = kIfExp;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->IfExp.Pos)
 beginbool(yyt->IfExp.IsTypeExp)
 begintObjects(yyt->IfExp.DeclsIn)
 begintObjects(yyt->IfExp.DeclsOut)
 begintType(yyt->IfExp.Type)
 yyt->IfExp.Next = pNext;
 yyt->IfExp.Con = pCon;
 yyt->IfExp.Then = pThen;
 yyt->IfExp.Else = pElse;
 return yyt;
}

tTree mFncApplication
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pFnc, tTree pArg)
# else
(pNext, pFnc, pArg)
tTree pNext;
tTree pFnc;
tTree pArg;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kFncApplication])
 yyt->Kind = kFncApplication;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->FncApplication.Pos)
 beginbool(yyt->FncApplication.IsTypeExp)
 begintObjects(yyt->FncApplication.DeclsIn)
 begintObjects(yyt->FncApplication.DeclsOut)
 begintType(yyt->FncApplication.Type)
 yyt->FncApplication.Next = pNext;
 yyt->FncApplication.Fnc = pFnc;
 yyt->FncApplication.Arg = pArg;
 return yyt;
}

tTree mSetComp
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pSchemaText, tTree pExpressionList)
# else
(pNext, pSchemaText, pExpressionList)
tTree pNext;
tTree pSchemaText;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSetComp])
 yyt->Kind = kSetComp;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SetComp.Pos)
 beginbool(yyt->SetComp.IsTypeExp)
 begintObjects(yyt->SetComp.DeclsIn)
 begintObjects(yyt->SetComp.DeclsOut)
 begintType(yyt->SetComp.Type)
 yyt->SetComp.Next = pNext;
 yyt->SetComp.SchemaText = pSchemaText;
 yyt->SetComp.ExpressionList = pExpressionList;
 return yyt;
}

tTree mSetElab
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pExpressionList)
# else
(pNext, pExpressionList)
tTree pNext;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSetElab])
 yyt->Kind = kSetElab;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SetElab.Pos)
 beginbool(yyt->SetElab.IsTypeExp)
 begintObjects(yyt->SetElab.DeclsIn)
 begintObjects(yyt->SetElab.DeclsOut)
 begintType(yyt->SetElab.Type)
 yyt->SetElab.Next = pNext;
 yyt->SetElab.ExpressionList = pExpressionList;
 return yyt;
}

tTree mArrayUpd
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pArray, tTree pIndex, tTree pValue)
# else
(pNext, pArray, pIndex, pValue)
tTree pNext;
tTree pArray;
tTree pIndex;
tTree pValue;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kArrayUpd])
 yyt->Kind = kArrayUpd;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->ArrayUpd.Pos)
 beginbool(yyt->ArrayUpd.IsTypeExp)
 begintObjects(yyt->ArrayUpd.DeclsIn)
 begintObjects(yyt->ArrayUpd.DeclsOut)
 begintType(yyt->ArrayUpd.Type)
 yyt->ArrayUpd.Next = pNext;
 yyt->ArrayUpd.Array = pArray;
 yyt->ArrayUpd.Index = pIndex;
 yyt->ArrayUpd.Value = pValue;
 return yyt;
}

tTree mNamedArrayAgg
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pExpressionList)
# else
(pNext, pExpressionList)
tTree pNext;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNamedArrayAgg])
 yyt->Kind = kNamedArrayAgg;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->NamedArrayAgg.Pos)
 beginbool(yyt->NamedArrayAgg.IsTypeExp)
 begintObjects(yyt->NamedArrayAgg.DeclsIn)
 begintObjects(yyt->NamedArrayAgg.DeclsOut)
 begintType(yyt->NamedArrayAgg.Type)
 yyt->NamedArrayAgg.Next = pNext;
 yyt->NamedArrayAgg.ExpressionList = pExpressionList;
 return yyt;
}

tTree mSequence
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pExpressionList)
# else
(pNext, pExpressionList)
tTree pNext;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSequence])
 yyt->Kind = kSequence;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Sequence.Pos)
 beginbool(yyt->Sequence.IsTypeExp)
 begintObjects(yyt->Sequence.DeclsIn)
 begintObjects(yyt->Sequence.DeclsOut)
 begintType(yyt->Sequence.Type)
 yyt->Sequence.Next = pNext;
 yyt->Sequence.ExpressionList = pExpressionList;
 return yyt;
}

tTree mBag
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pExpressionList)
# else
(pNext, pExpressionList)
tTree pNext;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kBag])
 yyt->Kind = kBag;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Bag.Pos)
 beginbool(yyt->Bag.IsTypeExp)
 begintObjects(yyt->Bag.DeclsIn)
 begintObjects(yyt->Bag.DeclsOut)
 begintType(yyt->Bag.Type)
 yyt->Bag.Next = pNext;
 yyt->Bag.ExpressionList = pExpressionList;
 return yyt;
}

tTree mCartProd
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pExpressionList)
# else
(pNext, pExpressionList)
tTree pNext;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kCartProd])
 yyt->Kind = kCartProd;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->CartProd.Pos)
 beginbool(yyt->CartProd.IsTypeExp)
 begintObjects(yyt->CartProd.DeclsIn)
 begintObjects(yyt->CartProd.DeclsOut)
 begintType(yyt->CartProd.Type)
 yyt->CartProd.Next = pNext;
 yyt->CartProd.ExpressionList = pExpressionList;
 return yyt;
}

tTree mTuple
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pExpressionList)
# else
(pNext, pExpressionList)
tTree pNext;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kTuple])
 yyt->Kind = kTuple;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Tuple.Pos)
 beginbool(yyt->Tuple.IsTypeExp)
 begintObjects(yyt->Tuple.DeclsIn)
 begintObjects(yyt->Tuple.DeclsOut)
 begintType(yyt->Tuple.Type)
 yyt->Tuple.Next = pNext;
 yyt->Tuple.ExpressionList = pExpressionList;
 return yyt;
}

tTree mExp_SchemaRef
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pIdList, tTree pExpressionList)
# else
(pNext, pIdList, pExpressionList)
tTree pNext;
tTree pIdList;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kExp_SchemaRef])
 yyt->Kind = kExp_SchemaRef;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Exp_SchemaRef.Pos)
 beginbool(yyt->Exp_SchemaRef.IsTypeExp)
 begintObjects(yyt->Exp_SchemaRef.DeclsIn)
 begintObjects(yyt->Exp_SchemaRef.DeclsOut)
 begintType(yyt->Exp_SchemaRef.Type)
 yyt->Exp_SchemaRef.Next = pNext;
 yyt->Exp_SchemaRef.IdList = pIdList;
 yyt->Exp_SchemaRef.ExpressionList = pExpressionList;
 return yyt;
}

tTree mTheta
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pExp)
# else
(pNext, pExp)
tTree pNext;
tTree pExp;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kTheta])
 yyt->Kind = kTheta;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Theta.Pos)
 beginbool(yyt->Theta.IsTypeExp)
 begintObjects(yyt->Theta.DeclsIn)
 begintObjects(yyt->Theta.DeclsOut)
 begintType(yyt->Theta.Type)
 yyt->Theta.Next = pNext;
 yyt->Theta.Exp = pExp;
 return yyt;
}

tTree mInfixOp
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pOp1, tIdPos pInfix, tTree pOp2)
# else
(pNext, pOp1, pInfix, pOp2)
tTree pNext;
tTree pOp1;
tIdPos pInfix;
tTree pOp2;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kInfixOp])
 yyt->Kind = kInfixOp;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->InfixOp.Pos)
 beginbool(yyt->InfixOp.IsTypeExp)
 begintObjects(yyt->InfixOp.DeclsIn)
 begintObjects(yyt->InfixOp.DeclsOut)
 begintType(yyt->InfixOp.Type)
 yyt->InfixOp.Next = pNext;
 yyt->InfixOp.Op1 = pOp1;
 yyt->InfixOp.Infix = pInfix;
 yyt->InfixOp.Op2 = pOp2;
 return yyt;
}

tTree mPredExp
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pPred)
# else
(pNext, pPred)
tTree pNext;
tTree pPred;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kPredExp])
 yyt->Kind = kPredExp;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->PredExp.Pos)
 beginbool(yyt->PredExp.IsTypeExp)
 begintObjects(yyt->PredExp.DeclsIn)
 begintObjects(yyt->PredExp.DeclsOut)
 begintType(yyt->PredExp.Type)
 yyt->PredExp.Next = pNext;
 yyt->PredExp.Pred = pPred;
 return yyt;
}

tTree mPredList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kPredList])
 yyt->Kind = kPredList;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->PredList.Pos)
 beginbool(yyt->PredList.IsTypeExp)
 begintObjects(yyt->PredList.DeclsIn)
 begintObjects(yyt->PredList.DeclsOut)
 begintType(yyt->PredList.Type)
 return yyt;
}

tTree mNoPred
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoPred])
 yyt->Kind = kNoPred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->NoPred.Pos)
 beginbool(yyt->NoPred.IsTypeExp)
 begintObjects(yyt->NoPred.DeclsIn)
 begintObjects(yyt->NoPred.DeclsOut)
 begintType(yyt->NoPred.Type)
 return yyt;
}

tTree mPred
# if defined __STDC__ | defined __cplusplus
(tTree pNext)
# else
(pNext)
tTree pNext;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kPred])
 yyt->Kind = kPred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Pred.Pos)
 beginbool(yyt->Pred.IsTypeExp)
 begintObjects(yyt->Pred.DeclsIn)
 begintObjects(yyt->Pred.DeclsOut)
 begintType(yyt->Pred.Type)
 yyt->Pred.Next = pNext;
 return yyt;
}

tTree mQuantPred
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pLogQuant, tTree pSchemaText, tTree pPred)
# else
(pNext, pLogQuant, pSchemaText, pPred)
tTree pNext;
tIdPos pLogQuant;
tTree pSchemaText;
tTree pPred;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kQuantPred])
 yyt->Kind = kQuantPred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->QuantPred.Pos)
 beginbool(yyt->QuantPred.IsTypeExp)
 begintObjects(yyt->QuantPred.DeclsIn)
 begintObjects(yyt->QuantPred.DeclsOut)
 begintType(yyt->QuantPred.Type)
 yyt->QuantPred.Next = pNext;
 yyt->QuantPred.LogQuant = pLogQuant;
 yyt->QuantPred.SchemaText = pSchemaText;
 yyt->QuantPred.Pred = pPred;
 return yyt;
}

tTree mRelBinPred
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pL, tIdPos pRelBinOp, tTree pR)
# else
(pNext, pL, pRelBinOp, pR)
tTree pNext;
tTree pL;
tIdPos pRelBinOp;
tTree pR;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kRelBinPred])
 yyt->Kind = kRelBinPred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->RelBinPred.Pos)
 beginbool(yyt->RelBinPred.IsTypeExp)
 begintObjects(yyt->RelBinPred.DeclsIn)
 begintObjects(yyt->RelBinPred.DeclsOut)
 begintType(yyt->RelBinPred.Type)
 yyt->RelBinPred.Next = pNext;
 yyt->RelBinPred.L = pL;
 yyt->RelBinPred.RelBinOp = pRelBinOp;
 yyt->RelBinPred.R = pR;
 return yyt;
}

tTree mAssign
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pL, tTree pR)
# else
(pNext, pL, pR)
tTree pNext;
tTree pL;
tTree pR;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kAssign])
 yyt->Kind = kAssign;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Assign.Pos)
 beginbool(yyt->Assign.IsTypeExp)
 begintObjects(yyt->Assign.DeclsIn)
 begintObjects(yyt->Assign.DeclsOut)
 begintType(yyt->Assign.Type)
 yyt->Assign.Next = pNext;
 yyt->Assign.L = pL;
 yyt->Assign.R = pR;
 return yyt;
}

tTree mRelPrePred
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pRelPreOp, tTree pExp)
# else
(pNext, pRelPreOp, pExp)
tTree pNext;
tIdPos pRelPreOp;
tTree pExp;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kRelPrePred])
 yyt->Kind = kRelPrePred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->RelPrePred.Pos)
 beginbool(yyt->RelPrePred.IsTypeExp)
 begintObjects(yyt->RelPrePred.DeclsIn)
 begintObjects(yyt->RelPrePred.DeclsOut)
 begintType(yyt->RelPrePred.Type)
 yyt->RelPrePred.Next = pNext;
 yyt->RelPrePred.RelPreOp = pRelPreOp;
 yyt->RelPrePred.Exp = pExp;
 return yyt;
}

tTree mLogBinPred
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pL, tTree pLogBinOp, tTree pR)
# else
(pNext, pL, pLogBinOp, pR)
tTree pNext;
tTree pL;
tTree pLogBinOp;
tTree pR;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLogBinPred])
 yyt->Kind = kLogBinPred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->LogBinPred.Pos)
 beginbool(yyt->LogBinPred.IsTypeExp)
 begintObjects(yyt->LogBinPred.DeclsIn)
 begintObjects(yyt->LogBinPred.DeclsOut)
 begintType(yyt->LogBinPred.Type)
 yyt->LogBinPred.Next = pNext;
 yyt->LogBinPred.L = pL;
 yyt->LogBinPred.LogBinOp = pLogBinOp;
 yyt->LogBinPred.R = pR;
 return yyt;
}

tTree mLogicalNot
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pPred)
# else
(pNext, pPred)
tTree pNext;
tTree pPred;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLogicalNot])
 yyt->Kind = kLogicalNot;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->LogicalNot.Pos)
 beginbool(yyt->LogicalNot.IsTypeExp)
 begintObjects(yyt->LogicalNot.DeclsIn)
 begintObjects(yyt->LogicalNot.DeclsOut)
 begintType(yyt->LogicalNot.Type)
 yyt->LogicalNot.Next = pNext;
 yyt->LogicalNot.Pred = pPred;
 return yyt;
}

tTree mPreCondPred
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pPred)
# else
(pNext, pPred)
tTree pNext;
tTree pPred;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kPreCondPred])
 yyt->Kind = kPreCondPred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->PreCondPred.Pos)
 beginbool(yyt->PreCondPred.IsTypeExp)
 begintObjects(yyt->PreCondPred.DeclsIn)
 begintObjects(yyt->PreCondPred.DeclsOut)
 begintType(yyt->PreCondPred.Type)
 yyt->PreCondPred.Next = pNext;
 yyt->PreCondPred.Pred = pPred;
 return yyt;
}

tTree mIfPred
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pCon, tTree pThen, tTree pElse)
# else
(pNext, pCon, pThen, pElse)
tTree pNext;
tTree pCon;
tTree pThen;
tTree pElse;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kIfPred])
 yyt->Kind = kIfPred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->IfPred.Pos)
 beginbool(yyt->IfPred.IsTypeExp)
 begintObjects(yyt->IfPred.DeclsIn)
 begintObjects(yyt->IfPred.DeclsOut)
 begintType(yyt->IfPred.Type)
 yyt->IfPred.Next = pNext;
 yyt->IfPred.Con = pCon;
 yyt->IfPred.Then = pThen;
 yyt->IfPred.Else = pElse;
 return yyt;
}

tTree mWhilePred
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pCon, tTree pDo)
# else
(pNext, pCon, pDo)
tTree pNext;
tTree pCon;
tTree pDo;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kWhilePred])
 yyt->Kind = kWhilePred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->WhilePred.Pos)
 beginbool(yyt->WhilePred.IsTypeExp)
 begintObjects(yyt->WhilePred.DeclsIn)
 begintObjects(yyt->WhilePred.DeclsOut)
 begintType(yyt->WhilePred.Type)
 yyt->WhilePred.Next = pNext;
 yyt->WhilePred.Con = pCon;
 yyt->WhilePred.Do = pDo;
 return yyt;
}

tTree mCallPred
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pIdList, tTree pInputBindList, tTree pOutputBindList)
# else
(pNext, pIdList, pInputBindList, pOutputBindList)
tTree pNext;
tTree pIdList;
tTree pInputBindList;
tTree pOutputBindList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kCallPred])
 yyt->Kind = kCallPred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->CallPred.Pos)
 beginbool(yyt->CallPred.IsTypeExp)
 begintObjects(yyt->CallPred.DeclsIn)
 begintObjects(yyt->CallPred.DeclsOut)
 begintType(yyt->CallPred.Type)
 yyt->CallPred.Next = pNext;
 yyt->CallPred.IdList = pIdList;
 yyt->CallPred.InputBindList = pInputBindList;
 yyt->CallPred.OutputBindList = pOutputBindList;
 return yyt;
}

tTree mChgOnly
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pNameList)
# else
(pNext, pNameList)
tTree pNext;
tTree pNameList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kChgOnly])
 yyt->Kind = kChgOnly;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->ChgOnly.Pos)
 beginbool(yyt->ChgOnly.IsTypeExp)
 begintObjects(yyt->ChgOnly.DeclsIn)
 begintObjects(yyt->ChgOnly.DeclsOut)
 begintType(yyt->ChgOnly.Type)
 yyt->ChgOnly.Next = pNext;
 yyt->ChgOnly.NameList = pNameList;
 return yyt;
}

tTree mDefined
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pExp)
# else
(pNext, pExp)
tTree pNext;
tTree pExp;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kDefined])
 yyt->Kind = kDefined;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Defined.Pos)
 beginbool(yyt->Defined.IsTypeExp)
 begintObjects(yyt->Defined.DeclsIn)
 begintObjects(yyt->Defined.DeclsOut)
 begintType(yyt->Defined.Type)
 yyt->Defined.Next = pNext;
 yyt->Defined.Exp = pExp;
 return yyt;
}

tTree mSchemaPred
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pSchema)
# else
(pNext, pSchema)
tTree pNext;
tTree pSchema;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSchemaPred])
 yyt->Kind = kSchemaPred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SchemaPred.Pos)
 beginbool(yyt->SchemaPred.IsTypeExp)
 begintObjects(yyt->SchemaPred.DeclsIn)
 begintObjects(yyt->SchemaPred.DeclsOut)
 begintType(yyt->SchemaPred.Type)
 yyt->SchemaPred.Next = pNext;
 yyt->SchemaPred.Schema = pSchema;
 return yyt;
}

tTree mBoolValue
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent)
# else
(pNext, pIdent)
tTree pNext;
tIdPos pIdent;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kBoolValue])
 yyt->Kind = kBoolValue;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->BoolValue.Pos)
 beginbool(yyt->BoolValue.IsTypeExp)
 begintObjects(yyt->BoolValue.DeclsIn)
 begintObjects(yyt->BoolValue.DeclsOut)
 begintType(yyt->BoolValue.Type)
 yyt->BoolValue.Next = pNext;
 yyt->BoolValue.Ident = pIdent;
 return yyt;
}

tTree mInputBindList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kInputBindList])
 yyt->Kind = kInputBindList;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->InputBindList.DeclsIn)
 begintObjects(yyt->InputBindList.DeclsOut)
 begintType(yyt->InputBindList.Type)
 return yyt;
}

tTree mNoInputBind
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoInputBind])
 yyt->Kind = kNoInputBind;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->NoInputBind.DeclsIn)
 begintObjects(yyt->NoInputBind.DeclsOut)
 begintType(yyt->NoInputBind.Type)
 return yyt;
}

tTree mInputBind
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent, tTree pExpressionList)
# else
(pNext, pIdent, pExpressionList)
tTree pNext;
tIdPos pIdent;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kInputBind])
 yyt->Kind = kInputBind;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->InputBind.DeclsIn)
 begintObjects(yyt->InputBind.DeclsOut)
 begintType(yyt->InputBind.Type)
 yyt->InputBind.Next = pNext;
 yyt->InputBind.Ident = pIdent;
 yyt->InputBind.ExpressionList = pExpressionList;
 return yyt;
}

tTree mOutputBindList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kOutputBindList])
 yyt->Kind = kOutputBindList;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->OutputBindList.DeclsIn)
 begintObjects(yyt->OutputBindList.DeclsOut)
 begintType(yyt->OutputBindList.Type)
 return yyt;
}

tTree mNoOutputBind
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoOutputBind])
 yyt->Kind = kNoOutputBind;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->NoOutputBind.DeclsIn)
 begintObjects(yyt->NoOutputBind.DeclsOut)
 begintType(yyt->NoOutputBind.Type)
 return yyt;
}

tTree mOutputBind
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent, tTree pIdList)
# else
(pNext, pIdent, pIdList)
tTree pNext;
tIdPos pIdent;
tTree pIdList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kOutputBind])
 yyt->Kind = kOutputBind;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->OutputBind.DeclsIn)
 begintObjects(yyt->OutputBind.DeclsOut)
 begintType(yyt->OutputBind.Type)
 yyt->OutputBind.Next = pNext;
 yyt->OutputBind.Ident = pIdent;
 yyt->OutputBind.IdList = pIdList;
 return yyt;
}

tTree mLogBinOp
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLogBinOp])
 yyt->Kind = kLogBinOp;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mLogSeq
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLogSeq])
 yyt->Kind = kLogSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mLogAnd
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLogAnd])
 yyt->Kind = kLogAnd;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mLogExor
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLogExor])
 yyt->Kind = kLogExor;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mLogOr
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLogOr])
 yyt->Kind = kLogOr;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mLogImply
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLogImply])
 yyt->Kind = kLogImply;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mLogEquiv
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLogEquiv])
 yyt->Kind = kLogEquiv;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mDeclList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kDeclList])
 yyt->Kind = kDeclList;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->DeclList.Pos)
 begintObjects(yyt->DeclList.DeclsIn)
 begintObjects(yyt->DeclList.DeclsOut)
 begintType(yyt->DeclList.Type)
 return yyt;
}

tTree mNoDecl
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoDecl])
 yyt->Kind = kNoDecl;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->NoDecl.Pos)
 begintObjects(yyt->NoDecl.DeclsIn)
 begintObjects(yyt->NoDecl.DeclsOut)
 begintType(yyt->NoDecl.Type)
 return yyt;
}

tTree mDecl
# if defined __STDC__ | defined __cplusplus
(tTree pNext)
# else
(pNext)
tTree pNext;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kDecl])
 yyt->Kind = kDecl;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Decl.Pos)
 begintObjects(yyt->Decl.DeclsIn)
 begintObjects(yyt->Decl.DeclsOut)
 begintType(yyt->Decl.Type)
 yyt->Decl.Next = pNext;
 return yyt;
}

tTree mVarDecl
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pIdList, tTree pExp, int pVarDeclKind)
# else
(pNext, pIdList, pExp, pVarDeclKind)
tTree pNext;
tTree pIdList;
tTree pExp;
int pVarDeclKind;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kVarDecl])
 yyt->Kind = kVarDecl;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->VarDecl.Pos)
 begintObjects(yyt->VarDecl.DeclsIn)
 begintObjects(yyt->VarDecl.DeclsOut)
 begintType(yyt->VarDecl.Type)
 yyt->VarDecl.Next = pNext;
 yyt->VarDecl.IdList = pIdList;
 yyt->VarDecl.Exp = pExp;
 yyt->VarDecl.VarDeclKind = pVarDeclKind;
 return yyt;
}

tTree mGivenSet
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pIdList)
# else
(pNext, pIdList)
tTree pNext;
tTree pIdList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kGivenSet])
 yyt->Kind = kGivenSet;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->GivenSet.Pos)
 begintObjects(yyt->GivenSet.DeclsIn)
 begintObjects(yyt->GivenSet.DeclsOut)
 begintType(yyt->GivenSet.Type)
 yyt->GivenSet.Next = pNext;
 yyt->GivenSet.IdList = pIdList;
 return yyt;
}

tTree mAxiomDecl
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pFormalParams, tTree pDeclList, tTree pPredList)
# else
(pNext, pFormalParams, pDeclList, pPredList)
tTree pNext;
tTree pFormalParams;
tTree pDeclList;
tTree pPredList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kAxiomDecl])
 yyt->Kind = kAxiomDecl;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->AxiomDecl.Pos)
 begintObjects(yyt->AxiomDecl.DeclsIn)
 begintObjects(yyt->AxiomDecl.DeclsOut)
 begintType(yyt->AxiomDecl.Type)
 yyt->AxiomDecl.Next = pNext;
 yyt->AxiomDecl.FormalParams = pFormalParams;
 yyt->AxiomDecl.DeclList = pDeclList;
 yyt->AxiomDecl.PredList = pPredList;
 return yyt;
}

tTree mSchemaDef
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent, tTree pFormalParams, tTree pDeclList, tTree pPredList, bool pIsOp)
# else
(pNext, pIdent, pFormalParams, pDeclList, pPredList, pIsOp)
tTree pNext;
tIdPos pIdent;
tTree pFormalParams;
tTree pDeclList;
tTree pPredList;
bool pIsOp;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSchemaDef])
 yyt->Kind = kSchemaDef;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SchemaDef.Pos)
 begintObjects(yyt->SchemaDef.DeclsIn)
 begintObjects(yyt->SchemaDef.DeclsOut)
 begintType(yyt->SchemaDef.Type)
 yyt->SchemaDef.Next = pNext;
 yyt->SchemaDef.Ident = pIdent;
 yyt->SchemaDef.FormalParams = pFormalParams;
 yyt->SchemaDef.DeclList = pDeclList;
 yyt->SchemaDef.PredList = pPredList;
 yyt->SchemaDef.IsOp = pIsOp;
 beginbool(yyt->SchemaDef.HasStateIncl)
 return yyt;
}

tTree mAnnotation
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pDecl)
# else
(pNext, pDecl)
tTree pNext;
tTree pDecl;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kAnnotation])
 yyt->Kind = kAnnotation;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Annotation.Pos)
 begintObjects(yyt->Annotation.DeclsIn)
 begintObjects(yyt->Annotation.DeclsOut)
 begintType(yyt->Annotation.Type)
 yyt->Annotation.Next = pNext;
 yyt->Annotation.Decl = pDecl;
 return yyt;
}

tTree mErgoAnno
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent)
# else
(pNext, pIdent)
tTree pNext;
tIdPos pIdent;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kErgoAnno])
 yyt->Kind = kErgoAnno;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->ErgoAnno.Pos)
 begintObjects(yyt->ErgoAnno.DeclsIn)
 begintObjects(yyt->ErgoAnno.DeclsOut)
 begintType(yyt->ErgoAnno.Type)
 yyt->ErgoAnno.Next = pNext;
 yyt->ErgoAnno.Ident = pIdent;
 return yyt;
}

tTree mStateMachine
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pIdList)
# else
(pNext, pIdList)
tTree pNext;
tTree pIdList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kStateMachine])
 yyt->Kind = kStateMachine;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->StateMachine.Pos)
 begintObjects(yyt->StateMachine.DeclsIn)
 begintObjects(yyt->StateMachine.DeclsOut)
 begintType(yyt->StateMachine.Type)
 yyt->StateMachine.Next = pNext;
 yyt->StateMachine.IdList = pIdList;
 return yyt;
}

tTree mAbbreviation
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent, tTree pExp)
# else
(pNext, pIdent, pExp)
tTree pNext;
tIdPos pIdent;
tTree pExp;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kAbbreviation])
 yyt->Kind = kAbbreviation;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Abbreviation.Pos)
 begintObjects(yyt->Abbreviation.DeclsIn)
 begintObjects(yyt->Abbreviation.DeclsOut)
 begintType(yyt->Abbreviation.Type)
 yyt->Abbreviation.Next = pNext;
 yyt->Abbreviation.Ident = pIdent;
 yyt->Abbreviation.Exp = pExp;
 return yyt;
}

tTree mFunctionDecl
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pDeclList, tTree pPredList)
# else
(pNext, pDeclList, pPredList)
tTree pNext;
tTree pDeclList;
tTree pPredList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kFunctionDecl])
 yyt->Kind = kFunctionDecl;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->FunctionDecl.Pos)
 begintObjects(yyt->FunctionDecl.DeclsIn)
 begintObjects(yyt->FunctionDecl.DeclsOut)
 begintType(yyt->FunctionDecl.Type)
 yyt->FunctionDecl.Next = pNext;
 yyt->FunctionDecl.DeclList = pDeclList;
 yyt->FunctionDecl.PredList = pPredList;
 return yyt;
}

tTree mFreeType
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent, tTree pBranchList)
# else
(pNext, pIdent, pBranchList)
tTree pNext;
tIdPos pIdent;
tTree pBranchList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kFreeType])
 yyt->Kind = kFreeType;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->FreeType.Pos)
 begintObjects(yyt->FreeType.DeclsIn)
 begintObjects(yyt->FreeType.DeclsOut)
 begintType(yyt->FreeType.Type)
 yyt->FreeType.Next = pNext;
 yyt->FreeType.Ident = pIdent;
 yyt->FreeType.BranchList = pBranchList;
 begintIdent(yyt->FreeType.ModId)
 return yyt;
}

tTree mEnum
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent, tTree pBranchList)
# else
(pNext, pIdent, pBranchList)
tTree pNext;
tIdPos pIdent;
tTree pBranchList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kEnum])
 yyt->Kind = kEnum;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Enum.Pos)
 begintObjects(yyt->Enum.DeclsIn)
 begintObjects(yyt->Enum.DeclsOut)
 begintType(yyt->Enum.Type)
 yyt->Enum.Next = pNext;
 yyt->Enum.Ident = pIdent;
 yyt->Enum.BranchList = pBranchList;
 begintIdent(yyt->Enum.ModId)
 return yyt;
}

tTree mImport
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent, tTree pExpressionList, tTree pRenameList, tIdPos pNewIdent)
# else
(pNext, pIdent, pExpressionList, pRenameList, pNewIdent)
tTree pNext;
tIdPos pIdent;
tTree pExpressionList;
tTree pRenameList;
tIdPos pNewIdent;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kImport])
 yyt->Kind = kImport;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Import.Pos)
 begintObjects(yyt->Import.DeclsIn)
 begintObjects(yyt->Import.DeclsOut)
 begintType(yyt->Import.Type)
 yyt->Import.Next = pNext;
 yyt->Import.Ident = pIdent;
 yyt->Import.ExpressionList = pExpressionList;
 yyt->Import.RenameList = pRenameList;
 yyt->Import.NewIdent = pNewIdent;
 beginIML_List(yyt->Import.ModIMLlist)
 begintObjects(yyt->Import.FmlParams)
 return yyt;
}

tTree mModuleDecl
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pModule)
# else
(pNext, pModule)
tTree pNext;
tTree pModule;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kModuleDecl])
 yyt->Kind = kModuleDecl;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->ModuleDecl.Pos)
 begintObjects(yyt->ModuleDecl.DeclsIn)
 begintObjects(yyt->ModuleDecl.DeclsOut)
 begintType(yyt->ModuleDecl.Type)
 yyt->ModuleDecl.Next = pNext;
 yyt->ModuleDecl.Module = pModule;
 return yyt;
}

tTree mConstraint
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pPred)
# else
(pNext, pPred)
tTree pNext;
tTree pPred;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kConstraint])
 yyt->Kind = kConstraint;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Constraint.Pos)
 begintObjects(yyt->Constraint.DeclsIn)
 begintObjects(yyt->Constraint.DeclsOut)
 begintType(yyt->Constraint.Type)
 yyt->Constraint.Next = pNext;
 yyt->Constraint.Pred = pPred;
 return yyt;
}

tTree mSchemaIncl
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tTree pIdList, tTree pExpressionList)
# else
(pNext, pIdList, pExpressionList)
tTree pNext;
tTree pIdList;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSchemaIncl])
 yyt->Kind = kSchemaIncl;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SchemaIncl.Pos)
 begintObjects(yyt->SchemaIncl.DeclsIn)
 begintObjects(yyt->SchemaIncl.DeclsOut)
 begintType(yyt->SchemaIncl.Type)
 yyt->SchemaIncl.Next = pNext;
 yyt->SchemaIncl.IdList = pIdList;
 yyt->SchemaIncl.ExpressionList = pExpressionList;
 begintIdent(yyt->SchemaIncl.ModId)
 return yyt;
}

tTree mVisibility
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdPos pIdent, tTree pSelectionList)
# else
(pNext, pIdent, pSelectionList)
tTree pNext;
tIdPos pIdent;
tTree pSelectionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kVisibility])
 yyt->Kind = kVisibility;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Visibility.Pos)
 begintObjects(yyt->Visibility.DeclsIn)
 begintObjects(yyt->Visibility.DeclsOut)
 begintType(yyt->Visibility.Type)
 yyt->Visibility.Next = pNext;
 yyt->Visibility.Ident = pIdent;
 yyt->Visibility.SelectionList = pSelectionList;
 return yyt;
}

tTree mBranchList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kBranchList])
 yyt->Kind = kBranchList;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->BranchList.DeclsIn)
 begintObjects(yyt->BranchList.DeclsOut)
 begintType(yyt->BranchList.Type)
 return yyt;
}

tTree mNoBranch
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kNoBranch])
 yyt->Kind = kNoBranch;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->NoBranch.DeclsIn)
 begintObjects(yyt->NoBranch.DeclsOut)
 begintType(yyt->NoBranch.Type)
 return yyt;
}

tTree mBranch
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdent pFTIdent)
# else
(pNext, pFTIdent)
tTree pNext;
tIdent pFTIdent;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kBranch])
 yyt->Kind = kBranch;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->Branch.DeclsIn)
 begintObjects(yyt->Branch.DeclsOut)
 begintType(yyt->Branch.Type)
 yyt->Branch.Next = pNext;
 yyt->Branch.FTIdent = pFTIdent;
 return yyt;
}

tTree mFTConstant
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdent pFTIdent, tIdPos pIdent)
# else
(pNext, pFTIdent, pIdent)
tTree pNext;
tIdent pFTIdent;
tIdPos pIdent;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kFTConstant])
 yyt->Kind = kFTConstant;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->FTConstant.DeclsIn)
 begintObjects(yyt->FTConstant.DeclsOut)
 begintType(yyt->FTConstant.Type)
 yyt->FTConstant.Next = pNext;
 yyt->FTConstant.FTIdent = pFTIdent;
 yyt->FTConstant.Ident = pIdent;
 return yyt;
}

tTree mFTConstructor
# if defined __STDC__ | defined __cplusplus
(tTree pNext, tIdent pFTIdent, tIdPos pIdent, tTree pExp)
# else
(pNext, pFTIdent, pIdent, pExp)
tTree pNext;
tIdent pFTIdent;
tIdPos pIdent;
tTree pExp;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kFTConstructor])
 yyt->Kind = kFTConstructor;
 yyt->yyHead.yyMark = 0;
 begintObjects(yyt->FTConstructor.DeclsIn)
 begintObjects(yyt->FTConstructor.DeclsOut)
 begintType(yyt->FTConstructor.Type)
 yyt->FTConstructor.Next = pNext;
 yyt->FTConstructor.FTIdent = pFTIdent;
 yyt->FTConstructor.Ident = pIdent;
 yyt->FTConstructor.Exp = pExp;
 return yyt;
}

tTree mSchema
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSchema])
 yyt->Kind = kSchema;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->Schema.Pos)
 beginbool(yyt->Schema.IsTypeExp)
 begintObjects(yyt->Schema.DeclsIn)
 begintObjects(yyt->Schema.DeclsOut)
 begintType(yyt->Schema.Type)
 return yyt;
}

tTree mExpPred
# if defined __STDC__ | defined __cplusplus
(tTree pExp)
# else
(pExp)
tTree pExp;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kExpPred])
 yyt->Kind = kExpPred;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->ExpPred.Pos)
 beginbool(yyt->ExpPred.IsTypeExp)
 begintObjects(yyt->ExpPred.DeclsIn)
 begintObjects(yyt->ExpPred.DeclsOut)
 begintType(yyt->ExpPred.Type)
 yyt->ExpPred.Exp = pExp;
 return yyt;
}

tTree mSchemaText
# if defined __STDC__ | defined __cplusplus
(tTree pDeclList, tTree pPredList, bool pIs_local_dec)
# else
(pDeclList, pPredList, pIs_local_dec)
tTree pDeclList;
tTree pPredList;
bool pIs_local_dec;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSchemaText])
 yyt->Kind = kSchemaText;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SchemaText.Pos)
 beginbool(yyt->SchemaText.IsTypeExp)
 begintObjects(yyt->SchemaText.DeclsIn)
 begintObjects(yyt->SchemaText.DeclsOut)
 begintType(yyt->SchemaText.Type)
 yyt->SchemaText.DeclList = pDeclList;
 yyt->SchemaText.PredList = pPredList;
 yyt->SchemaText.Is_local_dec = pIs_local_dec;
 return yyt;
}

tTree mSchemaRef
# if defined __STDC__ | defined __cplusplus
(tTree pIdList, tTree pExpressionList)
# else
(pIdList, pExpressionList)
tTree pIdList;
tTree pExpressionList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSchemaRef])
 yyt->Kind = kSchemaRef;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SchemaRef.Pos)
 beginbool(yyt->SchemaRef.IsTypeExp)
 begintObjects(yyt->SchemaRef.DeclsIn)
 begintObjects(yyt->SchemaRef.DeclsOut)
 begintType(yyt->SchemaRef.Type)
 yyt->SchemaRef.IdList = pIdList;
 yyt->SchemaRef.ExpressionList = pExpressionList;
 return yyt;
}

tTree mSchemaCons
# if defined __STDC__ | defined __cplusplus
(tTree pLogOp, tTree pL, tTree pR)
# else
(pLogOp, pL, pR)
tTree pLogOp;
tTree pL;
tTree pR;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSchemaCons])
 yyt->Kind = kSchemaCons;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SchemaCons.Pos)
 beginbool(yyt->SchemaCons.IsTypeExp)
 begintObjects(yyt->SchemaCons.DeclsIn)
 begintObjects(yyt->SchemaCons.DeclsOut)
 begintType(yyt->SchemaCons.Type)
 yyt->SchemaCons.LogOp = pLogOp;
 yyt->SchemaCons.L = pL;
 yyt->SchemaCons.R = pR;
 return yyt;
}

tTree mSchemaCompos
# if defined __STDC__ | defined __cplusplus
(tTree pSch1, tIdPos pCompos, tTree pSch2)
# else
(pSch1, pCompos, pSch2)
tTree pSch1;
tIdPos pCompos;
tTree pSch2;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSchemaCompos])
 yyt->Kind = kSchemaCompos;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SchemaCompos.Pos)
 beginbool(yyt->SchemaCompos.IsTypeExp)
 begintObjects(yyt->SchemaCompos.DeclsIn)
 begintObjects(yyt->SchemaCompos.DeclsOut)
 begintType(yyt->SchemaCompos.Type)
 yyt->SchemaCompos.Sch1 = pSch1;
 yyt->SchemaCompos.Compos = pCompos;
 yyt->SchemaCompos.Sch2 = pSch2;
 return yyt;
}

tTree mSchemaProj
# if defined __STDC__ | defined __cplusplus
(tTree pSch1, tIdPos pProj, tTree pSch2)
# else
(pSch1, pProj, pSch2)
tTree pSch1;
tIdPos pProj;
tTree pSch2;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSchemaProj])
 yyt->Kind = kSchemaProj;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SchemaProj.Pos)
 beginbool(yyt->SchemaProj.IsTypeExp)
 begintObjects(yyt->SchemaProj.DeclsIn)
 begintObjects(yyt->SchemaProj.DeclsOut)
 begintType(yyt->SchemaProj.Type)
 yyt->SchemaProj.Sch1 = pSch1;
 yyt->SchemaProj.Proj = pProj;
 yyt->SchemaProj.Sch2 = pSch2;
 return yyt;
}

tTree mSchemaSubst
# if defined __STDC__ | defined __cplusplus
(tTree pSchema, tTree pRenameList)
# else
(pSchema, pRenameList)
tTree pSchema;
tTree pRenameList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSchemaSubst])
 yyt->Kind = kSchemaSubst;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SchemaSubst.Pos)
 beginbool(yyt->SchemaSubst.IsTypeExp)
 begintObjects(yyt->SchemaSubst.DeclsIn)
 begintObjects(yyt->SchemaSubst.DeclsOut)
 begintType(yyt->SchemaSubst.Type)
 yyt->SchemaSubst.Schema = pSchema;
 yyt->SchemaSubst.RenameList = pRenameList;
 return yyt;
}

tTree mSchemaHiding
# if defined __STDC__ | defined __cplusplus
(tTree pSchema, tTree pNameList)
# else
(pSchema, pNameList)
tTree pSchema;
tTree pNameList;
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSchemaHiding])
 yyt->Kind = kSchemaHiding;
 yyt->yyHead.yyMark = 0;
 begintPosition(yyt->SchemaHiding.Pos)
 beginbool(yyt->SchemaHiding.IsTypeExp)
 begintObjects(yyt->SchemaHiding.DeclsIn)
 begintObjects(yyt->SchemaHiding.DeclsOut)
 begintType(yyt->SchemaHiding.Type)
 yyt->SchemaHiding.Schema = pSchema;
 yyt->SchemaHiding.NameList = pNameList;
 return yyt;
}

tTree mLogOp
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kLogOp])
 yyt->Kind = kLogOp;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mSDisjunction
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSDisjunction])
 yyt->Kind = kSDisjunction;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mSConjunction
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSConjunction])
 yyt->Kind = kSConjunction;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mSImplication
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSImplication])
 yyt->Kind = kSImplication;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tTree mSEquivalence
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tTree yyt;
 yyALLOC (yyt, Tree_NodeSize [kSEquivalence])
 yyt->Kind = kSEquivalence;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

typedef tTree * yyPtrtTree;

static FILE * yyf;

static void yyMark
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt) register tTree yyt;
# endif
{
 for (;;) {
  if (yyt == NoTree || ++ yyt->yyHead.yyMark > 1) return;

  switch (yyt->Kind) {
case kSum:
yyt = yyt->Sum.ModuleList; break;
case kModule:
yyMark (yyt->Module.FormalParams);
yyMark (yyt->Module.PredList);
yyMark (yyt->Module.DeclList);
yyt = yyt->Module.Next; break;
case kParam:
yyt = yyt->Param.Next; break;
case kTyParam:
yyt = yyt->TyParam.Next; break;
case kFncParam:
yyMark (yyt->FncParam.VarDecl);
yyt = yyt->FncParam.Next; break;
case kRename:
yyMark (yyt->Rename.OldIdent);
yyt = yyt->Rename.Next; break;
case kSelection:
yyt = yyt->Selection.Next; break;
case kId:
yyt = yyt->Id.Next; break;
case kName:
yyMark (yyt->Name.Next);
yyt = yyt->Name.IdList; break;
case kExp:
yyt = yyt->Exp.Next; break;
case kVariable:
yyMark (yyt->Variable.IdList);
yyt = yyt->Variable.Next; break;
case kLiteral:
yyt = yyt->Literal.Next; break;
case kString:
yyt = yyt->String.Next; break;
case kChar:
yyt = yyt->Char.Next; break;
case kPrefixOp:
yyMark (yyt->PrefixOp.Exp);
yyt = yyt->PrefixOp.Next; break;
case kLambda:
yyMark (yyt->Lambda.SchemaText);
yyMark (yyt->Lambda.Exp);
yyt = yyt->Lambda.Next; break;
case kRecDisp:
yyMark (yyt->RecDisp.SchemaText);
yyMark (yyt->RecDisp.PredList);
yyt = yyt->RecDisp.Next; break;
case kMu:
yyMark (yyt->Mu.SchemaText);
yyMark (yyt->Mu.ExpressionList);
yyt = yyt->Mu.Next; break;
case kTupSelection:
yyMark (yyt->TupSelection.Exp);
yyt = yyt->TupSelection.Next; break;
case kVarSelection:
yyMark (yyt->VarSelection.Exp);
yyt = yyt->VarSelection.Next; break;
case kIfExp:
yyMark (yyt->IfExp.Con);
yyMark (yyt->IfExp.Then);
yyMark (yyt->IfExp.Else);
yyt = yyt->IfExp.Next; break;
case kFncApplication:
yyMark (yyt->FncApplication.Fnc);
yyMark (yyt->FncApplication.Arg);
yyt = yyt->FncApplication.Next; break;
case kSetComp:
yyMark (yyt->SetComp.SchemaText);
yyMark (yyt->SetComp.ExpressionList);
yyt = yyt->SetComp.Next; break;
case kSetElab:
yyMark (yyt->SetElab.ExpressionList);
yyt = yyt->SetElab.Next; break;
case kArrayUpd:
yyMark (yyt->ArrayUpd.Array);
yyMark (yyt->ArrayUpd.Index);
yyMark (yyt->ArrayUpd.Value);
yyt = yyt->ArrayUpd.Next; break;
case kNamedArrayAgg:
yyMark (yyt->NamedArrayAgg.ExpressionList);
yyt = yyt->NamedArrayAgg.Next; break;
case kSequence:
yyMark (yyt->Sequence.ExpressionList);
yyt = yyt->Sequence.Next; break;
case kBag:
yyMark (yyt->Bag.ExpressionList);
yyt = yyt->Bag.Next; break;
case kCartProd:
yyMark (yyt->CartProd.ExpressionList);
yyt = yyt->CartProd.Next; break;
case kTuple:
yyMark (yyt->Tuple.ExpressionList);
yyt = yyt->Tuple.Next; break;
case kExp_SchemaRef:
yyMark (yyt->Exp_SchemaRef.IdList);
yyMark (yyt->Exp_SchemaRef.ExpressionList);
yyt = yyt->Exp_SchemaRef.Next; break;
case kTheta:
yyMark (yyt->Theta.Exp);
yyt = yyt->Theta.Next; break;
case kInfixOp:
yyMark (yyt->InfixOp.Op1);
yyMark (yyt->InfixOp.Op2);
yyt = yyt->InfixOp.Next; break;
case kPredExp:
yyMark (yyt->PredExp.Pred);
yyt = yyt->PredExp.Next; break;
case kPred:
yyt = yyt->Pred.Next; break;
case kQuantPred:
yyMark (yyt->QuantPred.SchemaText);
yyMark (yyt->QuantPred.Pred);
yyt = yyt->QuantPred.Next; break;
case kRelBinPred:
yyMark (yyt->RelBinPred.L);
yyMark (yyt->RelBinPred.R);
yyt = yyt->RelBinPred.Next; break;
case kAssign:
yyMark (yyt->Assign.L);
yyMark (yyt->Assign.R);
yyt = yyt->Assign.Next; break;
case kRelPrePred:
yyMark (yyt->RelPrePred.Exp);
yyt = yyt->RelPrePred.Next; break;
case kLogBinPred:
yyMark (yyt->LogBinPred.L);
yyMark (yyt->LogBinPred.LogBinOp);
yyMark (yyt->LogBinPred.R);
yyt = yyt->LogBinPred.Next; break;
case kLogicalNot:
yyMark (yyt->LogicalNot.Pred);
yyt = yyt->LogicalNot.Next; break;
case kPreCondPred:
yyMark (yyt->PreCondPred.Pred);
yyt = yyt->PreCondPred.Next; break;
case kIfPred:
yyMark (yyt->IfPred.Con);
yyMark (yyt->IfPred.Then);
yyMark (yyt->IfPred.Else);
yyt = yyt->IfPred.Next; break;
case kWhilePred:
yyMark (yyt->WhilePred.Con);
yyMark (yyt->WhilePred.Do);
yyt = yyt->WhilePred.Next; break;
case kCallPred:
yyMark (yyt->CallPred.IdList);
yyMark (yyt->CallPred.InputBindList);
yyMark (yyt->CallPred.OutputBindList);
yyt = yyt->CallPred.Next; break;
case kChgOnly:
yyMark (yyt->ChgOnly.NameList);
yyt = yyt->ChgOnly.Next; break;
case kDefined:
yyMark (yyt->Defined.Exp);
yyt = yyt->Defined.Next; break;
case kSchemaPred:
yyMark (yyt->SchemaPred.Schema);
yyt = yyt->SchemaPred.Next; break;
case kBoolValue:
yyt = yyt->BoolValue.Next; break;
case kInputBind:
yyMark (yyt->InputBind.ExpressionList);
yyt = yyt->InputBind.Next; break;
case kOutputBind:
yyMark (yyt->OutputBind.IdList);
yyt = yyt->OutputBind.Next; break;
case kDecl:
yyt = yyt->Decl.Next; break;
case kVarDecl:
yyMark (yyt->VarDecl.IdList);
yyMark (yyt->VarDecl.Exp);
yyt = yyt->VarDecl.Next; break;
case kGivenSet:
yyMark (yyt->GivenSet.IdList);
yyt = yyt->GivenSet.Next; break;
case kAxiomDecl:
yyMark (yyt->AxiomDecl.FormalParams);
yyMark (yyt->AxiomDecl.DeclList);
yyMark (yyt->AxiomDecl.PredList);
yyt = yyt->AxiomDecl.Next; break;
case kSchemaDef:
yyMark (yyt->SchemaDef.FormalParams);
yyMark (yyt->SchemaDef.DeclList);
yyMark (yyt->SchemaDef.PredList);
yyt = yyt->SchemaDef.Next; break;
case kAnnotation:
yyMark (yyt->Annotation.Decl);
yyt = yyt->Annotation.Next; break;
case kErgoAnno:
yyt = yyt->ErgoAnno.Next; break;
case kStateMachine:
yyMark (yyt->StateMachine.IdList);
yyt = yyt->StateMachine.Next; break;
case kAbbreviation:
yyMark (yyt->Abbreviation.Exp);
yyt = yyt->Abbreviation.Next; break;
case kFunctionDecl:
yyMark (yyt->FunctionDecl.DeclList);
yyMark (yyt->FunctionDecl.PredList);
yyt = yyt->FunctionDecl.Next; break;
case kFreeType:
yyMark (yyt->FreeType.BranchList);
yyt = yyt->FreeType.Next; break;
case kEnum:
yyMark (yyt->Enum.BranchList);
yyt = yyt->Enum.Next; break;
case kImport:
yyMark (yyt->Import.ExpressionList);
yyMark (yyt->Import.RenameList);
yyt = yyt->Import.Next; break;
case kModuleDecl:
yyMark (yyt->ModuleDecl.Module);
yyt = yyt->ModuleDecl.Next; break;
case kConstraint:
yyMark (yyt->Constraint.Pred);
yyt = yyt->Constraint.Next; break;
case kSchemaIncl:
yyMark (yyt->SchemaIncl.IdList);
yyMark (yyt->SchemaIncl.ExpressionList);
yyt = yyt->SchemaIncl.Next; break;
case kVisibility:
yyMark (yyt->Visibility.SelectionList);
yyt = yyt->Visibility.Next; break;
case kBranch:
yyt = yyt->Branch.Next; break;
case kFTConstant:
yyt = yyt->FTConstant.Next; break;
case kFTConstructor:
yyMark (yyt->FTConstructor.Exp);
yyt = yyt->FTConstructor.Next; break;
case kExpPred:
yyt = yyt->ExpPred.Exp; break;
case kSchemaText:
yyMark (yyt->SchemaText.DeclList);
yyt = yyt->SchemaText.PredList; break;
case kSchemaRef:
yyMark (yyt->SchemaRef.IdList);
yyt = yyt->SchemaRef.ExpressionList; break;
case kSchemaCons:
yyMark (yyt->SchemaCons.LogOp);
yyMark (yyt->SchemaCons.L);
yyt = yyt->SchemaCons.R; break;
case kSchemaCompos:
yyMark (yyt->SchemaCompos.Sch1);
yyt = yyt->SchemaCompos.Sch2; break;
case kSchemaProj:
yyMark (yyt->SchemaProj.Sch1);
yyt = yyt->SchemaProj.Sch2; break;
case kSchemaSubst:
yyMark (yyt->SchemaSubst.Schema);
yyt = yyt->SchemaSubst.RenameList; break;
case kSchemaHiding:
yyMark (yyt->SchemaHiding.Schema);
yyt = yyt->SchemaHiding.NameList; break;
  default: return;
  }
 }
}

# define yyInitTreeStoreSize 32
# define yyMapToTree(yyLabel) yyTreeStorePtr [yyLabel]

static unsigned long yyTreeStoreSize = yyInitTreeStoreSize;
static tTree yyTreeStore [yyInitTreeStoreSize];
static tTree * yyTreeStorePtr = yyTreeStore;
static int yyLabelCount;
static short yyRecursionLevel = 0;

static Tree_tLabel yyMapToLabel
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyLabelCount; yyi ++) if (yyTreeStorePtr [yyi] == yyt) return yyi;
 if (++ yyLabelCount == yyTreeStoreSize)
  ExtendArray ((char * *) & yyTreeStorePtr, & yyTreeStoreSize, sizeof (tTree));
 yyTreeStorePtr [yyLabelCount] = yyt;
 return yyLabelCount;
}

static void yyWriteTree ();

static void yyWriteNl () { (void) putc ('\n', yyf); }

static void yyWriteSelector
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyi = 16 - strlen (yys);
 (void) fputs (yys, yyf);
 while (yyi -- > 0) (void) putc (' ', yyf);
 (void) fputs (" = ", yyf);
}

static void yyWriteHex
# if defined __STDC__ | defined __cplusplus
 (unsigned char * yyx, int yysize)
# else
 (yyx, yysize) unsigned char * yyx; int yysize;
# endif
{ register int yyi; for (yyi = 0; yyi < yysize; yyi ++) (void) fprintf (yyf, "%02x ", yyx [yyi]); }

static void yyWriteAdr
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 if (yyt == NoTree) (void) fputs ("NoTree", yyf);
 else yyWriteHex ((unsigned char *) & yyt, sizeof (yyt));
 yyWriteNl ();
}

static void yWriteNodeSum
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("ModuleList"); yyWriteAdr (yyt->Sum.ModuleList);
}

static void yWriteNodeModuleList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("Pos"); writetPosition (yyt->ModuleList.Pos) yyWriteNl ();
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->ModuleList.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->ModuleList.DeclsOut) yyWriteNl ();
}

static void yWriteNodeNoModule
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeModuleList (yyt); 
}

static void yWriteNodeModule
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeModuleList (yyt); 
 yyWriteSelector ("Next"); yyWriteAdr (yyt->Module.Next);
 yyWriteSelector ("Ident"); writetIdPos (yyt->Module.Ident) yyWriteNl ();
 yyWriteSelector ("FormalParams"); yyWriteAdr (yyt->Module.FormalParams);
 yyWriteSelector ("PredList"); yyWriteAdr (yyt->Module.PredList);
 yyWriteSelector ("DeclList"); yyWriteAdr (yyt->Module.DeclList);
 yyWriteSelector ("IsNested"); writebool (yyt->Module.IsNested) yyWriteNl ();
}

static void yWriteNodeFormalParams
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("Pos"); writetPosition (yyt->FormalParams.Pos) yyWriteNl ();
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->FormalParams.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->FormalParams.DeclsOut) yyWriteNl ();
}

static void yWriteNodeNoParam
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeFormalParams (yyt); 
}

static void yWriteNodeParam
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeFormalParams (yyt); 
 yyWriteSelector ("Next"); yyWriteAdr (yyt->Param.Next);
}

static void yWriteNodeTyParam
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeParam (yyt); 
 yyWriteSelector ("Ident"); writetIdPos (yyt->TyParam.Ident) yyWriteNl ();
 yyWriteSelector ("IsPolyTy"); writebool (yyt->TyParam.IsPolyTy) yyWriteNl ();
}

static void yWriteNodeFncParam
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeParam (yyt); 
 yyWriteSelector ("VarDecl"); yyWriteAdr (yyt->FncParam.VarDecl);
}

static void yWriteNodeRenameList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->RenameList.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->RenameList.DeclsOut) yyWriteNl ();
}

static void yWriteNodeNoRename
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeRenameList (yyt); 
}

static void yWriteNodeRename
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeRenameList (yyt); 
 yyWriteSelector ("Next"); yyWriteAdr (yyt->Rename.Next);
 yyWriteSelector ("NewIdent"); writetIdPos (yyt->Rename.NewIdent) yyWriteNl ();
 yyWriteSelector ("OldIdent"); yyWriteAdr (yyt->Rename.OldIdent);
}

static void yWriteNodeSelection
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("Next"); yyWriteAdr (yyt->Selection.Next);
 yyWriteSelector ("Ident"); writetIdPos (yyt->Selection.Ident) yyWriteNl ();
}

static void yWriteNodeIdList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("Pos"); writetPosition (yyt->IdList.Pos) yyWriteNl ();
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->IdList.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->IdList.DeclsOut) yyWriteNl ();
}

static void yWriteNodeNoId
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeIdList (yyt); 
}

static void yWriteNodeId
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeIdList (yyt); 
 yyWriteSelector ("Next"); yyWriteAdr (yyt->Id.Next);
 yyWriteSelector ("Ident"); writetIdPos (yyt->Id.Ident) yyWriteNl ();
 yyWriteSelector ("IdKind"); writeint (yyt->Id.IdKind) yyWriteNl ();
}

static void yWriteNodeNameList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("Pos"); writetPosition (yyt->NameList.Pos) yyWriteNl ();
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->NameList.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->NameList.DeclsOut) yyWriteNl ();
}

static void yWriteNodeNoName
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeNameList (yyt); 
}

static void yWriteNodeName
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeNameList (yyt); 
 yyWriteSelector ("Next"); yyWriteAdr (yyt->Name.Next);
 yyWriteSelector ("IdList"); yyWriteAdr (yyt->Name.IdList);
}

static void yWriteNodeExpressionList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("Pos"); writetPosition (yyt->ExpressionList.Pos) yyWriteNl ();
 yyWriteSelector ("IsTypeExp"); writebool (yyt->ExpressionList.IsTypeExp) yyWriteNl ();
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->ExpressionList.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->ExpressionList.DeclsOut) yyWriteNl ();
 yyWriteSelector ("Type"); writetType (yyt->ExpressionList.Type) yyWriteNl ();
}

static void yWriteNodeNoExp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExpressionList (yyt); 
}

static void yWriteNodeExp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExpressionList (yyt); 
 yyWriteSelector ("Next"); yyWriteAdr (yyt->Exp.Next);
}

static void yWriteNodeVariable
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("IdList"); yyWriteAdr (yyt->Variable.IdList);
 yyWriteSelector ("SymPtr"); writetObjects (yyt->Variable.SymPtr) yyWriteNl ();
 yyWriteSelector ("IsBinding"); writebool (yyt->Variable.IsBinding) yyWriteNl ();
}

static void yWriteNodeLiteral
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("Literal"); writetIdPos (yyt->Literal.Literal) yyWriteNl ();
}

static void yWriteNodeString
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("String"); writetIdPos (yyt->String.String) yyWriteNl ();
}

static void yWriteNodeChar
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("Char"); writetIdPos (yyt->Char.Char) yyWriteNl ();
}

static void yWriteNodePrefixOp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("Prefix"); writetIdPos (yyt->PrefixOp.Prefix) yyWriteNl ();
 yyWriteSelector ("Exp"); yyWriteAdr (yyt->PrefixOp.Exp);
}

static void yWriteNodeLambda
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("SchemaText"); yyWriteAdr (yyt->Lambda.SchemaText);
 yyWriteSelector ("Exp"); yyWriteAdr (yyt->Lambda.Exp);
}

static void yWriteNodeRecDisp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("SchemaText"); yyWriteAdr (yyt->RecDisp.SchemaText);
 yyWriteSelector ("PredList"); yyWriteAdr (yyt->RecDisp.PredList);
}

static void yWriteNodeMu
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("SchemaText"); yyWriteAdr (yyt->Mu.SchemaText);
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->Mu.ExpressionList);
}

static void yWriteNodeTupSelection
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("Exp"); yyWriteAdr (yyt->TupSelection.Exp);
 yyWriteSelector ("Number"); writetIdPos (yyt->TupSelection.Number) yyWriteNl ();
}

static void yWriteNodeVarSelection
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("Exp"); yyWriteAdr (yyt->VarSelection.Exp);
 yyWriteSelector ("Ident"); writetIdPos (yyt->VarSelection.Ident) yyWriteNl ();
}

static void yWriteNodeIfExp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("Con"); yyWriteAdr (yyt->IfExp.Con);
 yyWriteSelector ("Then"); yyWriteAdr (yyt->IfExp.Then);
 yyWriteSelector ("Else"); yyWriteAdr (yyt->IfExp.Else);
}

static void yWriteNodeFncApplication
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("Fnc"); yyWriteAdr (yyt->FncApplication.Fnc);
 yyWriteSelector ("Arg"); yyWriteAdr (yyt->FncApplication.Arg);
}

static void yWriteNodeSetComp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("SchemaText"); yyWriteAdr (yyt->SetComp.SchemaText);
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->SetComp.ExpressionList);
}

static void yWriteNodeSetElab
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->SetElab.ExpressionList);
}

static void yWriteNodeArrayUpd
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("Array"); yyWriteAdr (yyt->ArrayUpd.Array);
 yyWriteSelector ("Index"); yyWriteAdr (yyt->ArrayUpd.Index);
 yyWriteSelector ("Value"); yyWriteAdr (yyt->ArrayUpd.Value);
}

static void yWriteNodeNamedArrayAgg
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->NamedArrayAgg.ExpressionList);
}

static void yWriteNodeSequence
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->Sequence.ExpressionList);
}

static void yWriteNodeBag
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->Bag.ExpressionList);
}

static void yWriteNodeCartProd
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->CartProd.ExpressionList);
}

static void yWriteNodeTuple
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->Tuple.ExpressionList);
}

static void yWriteNodeExp_SchemaRef
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("IdList"); yyWriteAdr (yyt->Exp_SchemaRef.IdList);
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->Exp_SchemaRef.ExpressionList);
}

static void yWriteNodeTheta
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("Exp"); yyWriteAdr (yyt->Theta.Exp);
}

static void yWriteNodeInfixOp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("Op1"); yyWriteAdr (yyt->InfixOp.Op1);
 yyWriteSelector ("Infix"); writetIdPos (yyt->InfixOp.Infix) yyWriteNl ();
 yyWriteSelector ("Op2"); yyWriteAdr (yyt->InfixOp.Op2);
}

static void yWriteNodePredExp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeExp (yyt); 
 yyWriteSelector ("Pred"); yyWriteAdr (yyt->PredExp.Pred);
}

static void yWriteNodePredList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("Pos"); writetPosition (yyt->PredList.Pos) yyWriteNl ();
 yyWriteSelector ("IsTypeExp"); writebool (yyt->PredList.IsTypeExp) yyWriteNl ();
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->PredList.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->PredList.DeclsOut) yyWriteNl ();
 yyWriteSelector ("Type"); writetType (yyt->PredList.Type) yyWriteNl ();
}

static void yWriteNodeNoPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePredList (yyt); 
}

static void yWriteNodePred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePredList (yyt); 
 yyWriteSelector ("Next"); yyWriteAdr (yyt->Pred.Next);
}

static void yWriteNodeQuantPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("LogQuant"); writetIdPos (yyt->QuantPred.LogQuant) yyWriteNl ();
 yyWriteSelector ("SchemaText"); yyWriteAdr (yyt->QuantPred.SchemaText);
 yyWriteSelector ("Pred"); yyWriteAdr (yyt->QuantPred.Pred);
}

static void yWriteNodeRelBinPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("L"); yyWriteAdr (yyt->RelBinPred.L);
 yyWriteSelector ("RelBinOp"); writetIdPos (yyt->RelBinPred.RelBinOp) yyWriteNl ();
 yyWriteSelector ("R"); yyWriteAdr (yyt->RelBinPred.R);
}

static void yWriteNodeAssign
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("L"); yyWriteAdr (yyt->Assign.L);
 yyWriteSelector ("R"); yyWriteAdr (yyt->Assign.R);
}

static void yWriteNodeRelPrePred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("RelPreOp"); writetIdPos (yyt->RelPrePred.RelPreOp) yyWriteNl ();
 yyWriteSelector ("Exp"); yyWriteAdr (yyt->RelPrePred.Exp);
}

static void yWriteNodeLogBinPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("L"); yyWriteAdr (yyt->LogBinPred.L);
 yyWriteSelector ("LogBinOp"); yyWriteAdr (yyt->LogBinPred.LogBinOp);
 yyWriteSelector ("R"); yyWriteAdr (yyt->LogBinPred.R);
}

static void yWriteNodeLogicalNot
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("Pred"); yyWriteAdr (yyt->LogicalNot.Pred);
}

static void yWriteNodePreCondPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("Pred"); yyWriteAdr (yyt->PreCondPred.Pred);
}

static void yWriteNodeIfPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("Con"); yyWriteAdr (yyt->IfPred.Con);
 yyWriteSelector ("Then"); yyWriteAdr (yyt->IfPred.Then);
 yyWriteSelector ("Else"); yyWriteAdr (yyt->IfPred.Else);
}

static void yWriteNodeWhilePred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("Con"); yyWriteAdr (yyt->WhilePred.Con);
 yyWriteSelector ("Do"); yyWriteAdr (yyt->WhilePred.Do);
}

static void yWriteNodeCallPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("IdList"); yyWriteAdr (yyt->CallPred.IdList);
 yyWriteSelector ("InputBindList"); yyWriteAdr (yyt->CallPred.InputBindList);
 yyWriteSelector ("OutputBindList"); yyWriteAdr (yyt->CallPred.OutputBindList);
}

static void yWriteNodeChgOnly
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("NameList"); yyWriteAdr (yyt->ChgOnly.NameList);
}

static void yWriteNodeDefined
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("Exp"); yyWriteAdr (yyt->Defined.Exp);
}

static void yWriteNodeSchemaPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("Schema"); yyWriteAdr (yyt->SchemaPred.Schema);
}

static void yWriteNodeBoolValue
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodePred (yyt); 
 yyWriteSelector ("Ident"); writetIdPos (yyt->BoolValue.Ident) yyWriteNl ();
}

static void yWriteNodeInputBindList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->InputBindList.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->InputBindList.DeclsOut) yyWriteNl ();
 yyWriteSelector ("Type"); writetType (yyt->InputBindList.Type) yyWriteNl ();
}

static void yWriteNodeNoInputBind
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeInputBindList (yyt); 
}

static void yWriteNodeInputBind
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeInputBindList (yyt); 
 yyWriteSelector ("Next"); yyWriteAdr (yyt->InputBind.Next);
 yyWriteSelector ("Ident"); writetIdPos (yyt->InputBind.Ident) yyWriteNl ();
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->InputBind.ExpressionList);
}

static void yWriteNodeOutputBindList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->OutputBindList.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->OutputBindList.DeclsOut) yyWriteNl ();
 yyWriteSelector ("Type"); writetType (yyt->OutputBindList.Type) yyWriteNl ();
}

static void yWriteNodeNoOutputBind
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeOutputBindList (yyt); 
}

static void yWriteNodeOutputBind
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeOutputBindList (yyt); 
 yyWriteSelector ("Next"); yyWriteAdr (yyt->OutputBind.Next);
 yyWriteSelector ("Ident"); writetIdPos (yyt->OutputBind.Ident) yyWriteNl ();
 yyWriteSelector ("IdList"); yyWriteAdr (yyt->OutputBind.IdList);
}

static void yWriteNodeDeclList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("Pos"); writetPosition (yyt->DeclList.Pos) yyWriteNl ();
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->DeclList.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->DeclList.DeclsOut) yyWriteNl ();
 yyWriteSelector ("Type"); writetType (yyt->DeclList.Type) yyWriteNl ();
}

static void yWriteNodeNoDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDeclList (yyt); 
}

static void yWriteNodeDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDeclList (yyt); 
 yyWriteSelector ("Next"); yyWriteAdr (yyt->Decl.Next);
}

static void yWriteNodeVarDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("IdList"); yyWriteAdr (yyt->VarDecl.IdList);
 yyWriteSelector ("Exp"); yyWriteAdr (yyt->VarDecl.Exp);
 yyWriteSelector ("VarDeclKind"); writeint (yyt->VarDecl.VarDeclKind) yyWriteNl ();
}

static void yWriteNodeGivenSet
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("IdList"); yyWriteAdr (yyt->GivenSet.IdList);
}

static void yWriteNodeAxiomDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("FormalParams"); yyWriteAdr (yyt->AxiomDecl.FormalParams);
 yyWriteSelector ("DeclList"); yyWriteAdr (yyt->AxiomDecl.DeclList);
 yyWriteSelector ("PredList"); yyWriteAdr (yyt->AxiomDecl.PredList);
}

static void yWriteNodeSchemaDef
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("Ident"); writetIdPos (yyt->SchemaDef.Ident) yyWriteNl ();
 yyWriteSelector ("FormalParams"); yyWriteAdr (yyt->SchemaDef.FormalParams);
 yyWriteSelector ("DeclList"); yyWriteAdr (yyt->SchemaDef.DeclList);
 yyWriteSelector ("PredList"); yyWriteAdr (yyt->SchemaDef.PredList);
 yyWriteSelector ("IsOp"); writebool (yyt->SchemaDef.IsOp) yyWriteNl ();
 yyWriteSelector ("HasStateIncl"); writebool (yyt->SchemaDef.HasStateIncl) yyWriteNl ();
}

static void yWriteNodeAnnotation
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("Decl"); yyWriteAdr (yyt->Annotation.Decl);
}

static void yWriteNodeErgoAnno
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("Ident"); writetIdPos (yyt->ErgoAnno.Ident) yyWriteNl ();
}

static void yWriteNodeStateMachine
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("IdList"); yyWriteAdr (yyt->StateMachine.IdList);
}

static void yWriteNodeAbbreviation
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("Ident"); writetIdPos (yyt->Abbreviation.Ident) yyWriteNl ();
 yyWriteSelector ("Exp"); yyWriteAdr (yyt->Abbreviation.Exp);
}

static void yWriteNodeFunctionDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("DeclList"); yyWriteAdr (yyt->FunctionDecl.DeclList);
 yyWriteSelector ("PredList"); yyWriteAdr (yyt->FunctionDecl.PredList);
}

static void yWriteNodeFreeType
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("Ident"); writetIdPos (yyt->FreeType.Ident) yyWriteNl ();
 yyWriteSelector ("BranchList"); yyWriteAdr (yyt->FreeType.BranchList);
 yyWriteSelector ("ModId"); writetIdent (yyt->FreeType.ModId) yyWriteNl ();
}

static void yWriteNodeEnum
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("Ident"); writetIdPos (yyt->Enum.Ident) yyWriteNl ();
 yyWriteSelector ("BranchList"); yyWriteAdr (yyt->Enum.BranchList);
 yyWriteSelector ("ModId"); writetIdent (yyt->Enum.ModId) yyWriteNl ();
}

static void yWriteNodeImport
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("Ident"); writetIdPos (yyt->Import.Ident) yyWriteNl ();
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->Import.ExpressionList);
 yyWriteSelector ("RenameList"); yyWriteAdr (yyt->Import.RenameList);
 yyWriteSelector ("NewIdent"); writetIdPos (yyt->Import.NewIdent) yyWriteNl ();
 yyWriteSelector ("ModIMLlist"); writeIML_List (yyt->Import.ModIMLlist) yyWriteNl ();
 yyWriteSelector ("FmlParams"); writetObjects (yyt->Import.FmlParams) yyWriteNl ();
}

static void yWriteNodeModuleDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("Module"); yyWriteAdr (yyt->ModuleDecl.Module);
}

static void yWriteNodeConstraint
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("Pred"); yyWriteAdr (yyt->Constraint.Pred);
}

static void yWriteNodeSchemaIncl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("IdList"); yyWriteAdr (yyt->SchemaIncl.IdList);
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->SchemaIncl.ExpressionList);
 yyWriteSelector ("ModId"); writetIdent (yyt->SchemaIncl.ModId) yyWriteNl ();
}

static void yWriteNodeVisibility
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeDecl (yyt); 
 yyWriteSelector ("Ident"); writetIdPos (yyt->Visibility.Ident) yyWriteNl ();
 yyWriteSelector ("SelectionList"); yyWriteAdr (yyt->Visibility.SelectionList);
}

static void yWriteNodeBranchList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->BranchList.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->BranchList.DeclsOut) yyWriteNl ();
 yyWriteSelector ("Type"); writetType (yyt->BranchList.Type) yyWriteNl ();
}

static void yWriteNodeNoBranch
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeBranchList (yyt); 
}

static void yWriteNodeBranch
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeBranchList (yyt); 
 yyWriteSelector ("Next"); yyWriteAdr (yyt->Branch.Next);
 yyWriteSelector ("FTIdent"); writetIdent (yyt->Branch.FTIdent) yyWriteNl ();
}

static void yWriteNodeFTConstant
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeBranch (yyt); 
 yyWriteSelector ("Ident"); writetIdPos (yyt->FTConstant.Ident) yyWriteNl ();
}

static void yWriteNodeFTConstructor
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeBranch (yyt); 
 yyWriteSelector ("Ident"); writetIdPos (yyt->FTConstructor.Ident) yyWriteNl ();
 yyWriteSelector ("Exp"); yyWriteAdr (yyt->FTConstructor.Exp);
}

static void yWriteNodeSchema
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyWriteSelector ("Pos"); writetPosition (yyt->Schema.Pos) yyWriteNl ();
 yyWriteSelector ("IsTypeExp"); writebool (yyt->Schema.IsTypeExp) yyWriteNl ();
 yyWriteSelector ("DeclsIn"); writetObjects (yyt->Schema.DeclsIn) yyWriteNl ();
 yyWriteSelector ("DeclsOut"); writetObjects (yyt->Schema.DeclsOut) yyWriteNl ();
 yyWriteSelector ("Type"); writetType (yyt->Schema.Type) yyWriteNl ();
}

static void yWriteNodeExpPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeSchema (yyt); 
 yyWriteSelector ("Exp"); yyWriteAdr (yyt->ExpPred.Exp);
}

static void yWriteNodeSchemaText
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeSchema (yyt); 
 yyWriteSelector ("DeclList"); yyWriteAdr (yyt->SchemaText.DeclList);
 yyWriteSelector ("PredList"); yyWriteAdr (yyt->SchemaText.PredList);
 yyWriteSelector ("Is_local_dec"); writebool (yyt->SchemaText.Is_local_dec) yyWriteNl ();
}

static void yWriteNodeSchemaRef
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeSchema (yyt); 
 yyWriteSelector ("IdList"); yyWriteAdr (yyt->SchemaRef.IdList);
 yyWriteSelector ("ExpressionList"); yyWriteAdr (yyt->SchemaRef.ExpressionList);
}

static void yWriteNodeSchemaCons
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeSchema (yyt); 
 yyWriteSelector ("LogOp"); yyWriteAdr (yyt->SchemaCons.LogOp);
 yyWriteSelector ("L"); yyWriteAdr (yyt->SchemaCons.L);
 yyWriteSelector ("R"); yyWriteAdr (yyt->SchemaCons.R);
}

static void yWriteNodeSchemaCompos
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeSchema (yyt); 
 yyWriteSelector ("Sch1"); yyWriteAdr (yyt->SchemaCompos.Sch1);
 yyWriteSelector ("Compos"); writetIdPos (yyt->SchemaCompos.Compos) yyWriteNl ();
 yyWriteSelector ("Sch2"); yyWriteAdr (yyt->SchemaCompos.Sch2);
}

static void yWriteNodeSchemaProj
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeSchema (yyt); 
 yyWriteSelector ("Sch1"); yyWriteAdr (yyt->SchemaProj.Sch1);
 yyWriteSelector ("Proj"); writetIdPos (yyt->SchemaProj.Proj) yyWriteNl ();
 yyWriteSelector ("Sch2"); yyWriteAdr (yyt->SchemaProj.Sch2);
}

static void yWriteNodeSchemaSubst
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeSchema (yyt); 
 yyWriteSelector ("Schema"); yyWriteAdr (yyt->SchemaSubst.Schema);
 yyWriteSelector ("RenameList"); yyWriteAdr (yyt->SchemaSubst.RenameList);
}

static void yWriteNodeSchemaHiding
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yWriteNodeSchema (yyt); 
 yyWriteSelector ("Schema"); yyWriteAdr (yyt->SchemaHiding.Schema);
 yyWriteSelector ("NameList"); yyWriteAdr (yyt->SchemaHiding.NameList);
}

void WriteTreeNode
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf, tTree yyt)
# else
 (yyyf, yyt) FILE * yyyf; tTree yyt;
# endif
{
 yyf = yyyf;
 if (yyt == NoTree) { (void) fputs ("NoTree\n", yyf); return; }

 switch (yyt->Kind) {
case kSum: (void) fputs (Tree_NodeName [kSum], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSum (yyt); break;
case kModuleList: (void) fputs (Tree_NodeName [kModuleList], yyf); (void) fputc ('\n', yyf);
 yWriteNodeModuleList (yyt); break;
case kNoModule: (void) fputs (Tree_NodeName [kNoModule], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNoModule (yyt); break;
case kModule: (void) fputs (Tree_NodeName [kModule], yyf); (void) fputc ('\n', yyf);
 yWriteNodeModule (yyt); break;
case kFormalParams: (void) fputs (Tree_NodeName [kFormalParams], yyf); (void) fputc ('\n', yyf);
 yWriteNodeFormalParams (yyt); break;
case kNoParam: (void) fputs (Tree_NodeName [kNoParam], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNoParam (yyt); break;
case kParam: (void) fputs (Tree_NodeName [kParam], yyf); (void) fputc ('\n', yyf);
 yWriteNodeParam (yyt); break;
case kTyParam: (void) fputs (Tree_NodeName [kTyParam], yyf); (void) fputc ('\n', yyf);
 yWriteNodeTyParam (yyt); break;
case kFncParam: (void) fputs (Tree_NodeName [kFncParam], yyf); (void) fputc ('\n', yyf);
 yWriteNodeFncParam (yyt); break;
case kRenameList: (void) fputs (Tree_NodeName [kRenameList], yyf); (void) fputc ('\n', yyf);
 yWriteNodeRenameList (yyt); break;
case kNoRename: (void) fputs (Tree_NodeName [kNoRename], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNoRename (yyt); break;
case kRename: (void) fputs (Tree_NodeName [kRename], yyf); (void) fputc ('\n', yyf);
 yWriteNodeRename (yyt); break;
case kSelectionList: (void) fputs (Tree_NodeName [kSelectionList], yyf); (void) fputc ('\n', yyf);
 break;
case kNoSelection: (void) fputs (Tree_NodeName [kNoSelection], yyf); (void) fputc ('\n', yyf);
 break;
case kSelection: (void) fputs (Tree_NodeName [kSelection], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSelection (yyt); break;
case kIdList: (void) fputs (Tree_NodeName [kIdList], yyf); (void) fputc ('\n', yyf);
 yWriteNodeIdList (yyt); break;
case kNoId: (void) fputs (Tree_NodeName [kNoId], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNoId (yyt); break;
case kId: (void) fputs (Tree_NodeName [kId], yyf); (void) fputc ('\n', yyf);
 yWriteNodeId (yyt); break;
case kNameList: (void) fputs (Tree_NodeName [kNameList], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNameList (yyt); break;
case kNoName: (void) fputs (Tree_NodeName [kNoName], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNoName (yyt); break;
case kName: (void) fputs (Tree_NodeName [kName], yyf); (void) fputc ('\n', yyf);
 yWriteNodeName (yyt); break;
case kExpressionList: (void) fputs (Tree_NodeName [kExpressionList], yyf); (void) fputc ('\n', yyf);
 yWriteNodeExpressionList (yyt); break;
case kNoExp: (void) fputs (Tree_NodeName [kNoExp], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNoExp (yyt); break;
case kExp: (void) fputs (Tree_NodeName [kExp], yyf); (void) fputc ('\n', yyf);
 yWriteNodeExp (yyt); break;
case kVariable: (void) fputs (Tree_NodeName [kVariable], yyf); (void) fputc ('\n', yyf);
 yWriteNodeVariable (yyt); break;
case kLiteral: (void) fputs (Tree_NodeName [kLiteral], yyf); (void) fputc ('\n', yyf);
 yWriteNodeLiteral (yyt); break;
case kString: (void) fputs (Tree_NodeName [kString], yyf); (void) fputc ('\n', yyf);
 yWriteNodeString (yyt); break;
case kChar: (void) fputs (Tree_NodeName [kChar], yyf); (void) fputc ('\n', yyf);
 yWriteNodeChar (yyt); break;
case kPrefixOp: (void) fputs (Tree_NodeName [kPrefixOp], yyf); (void) fputc ('\n', yyf);
 yWriteNodePrefixOp (yyt); break;
case kLambda: (void) fputs (Tree_NodeName [kLambda], yyf); (void) fputc ('\n', yyf);
 yWriteNodeLambda (yyt); break;
case kRecDisp: (void) fputs (Tree_NodeName [kRecDisp], yyf); (void) fputc ('\n', yyf);
 yWriteNodeRecDisp (yyt); break;
case kMu: (void) fputs (Tree_NodeName [kMu], yyf); (void) fputc ('\n', yyf);
 yWriteNodeMu (yyt); break;
case kTupSelection: (void) fputs (Tree_NodeName [kTupSelection], yyf); (void) fputc ('\n', yyf);
 yWriteNodeTupSelection (yyt); break;
case kVarSelection: (void) fputs (Tree_NodeName [kVarSelection], yyf); (void) fputc ('\n', yyf);
 yWriteNodeVarSelection (yyt); break;
case kIfExp: (void) fputs (Tree_NodeName [kIfExp], yyf); (void) fputc ('\n', yyf);
 yWriteNodeIfExp (yyt); break;
case kFncApplication: (void) fputs (Tree_NodeName [kFncApplication], yyf); (void) fputc ('\n', yyf);
 yWriteNodeFncApplication (yyt); break;
case kSetComp: (void) fputs (Tree_NodeName [kSetComp], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSetComp (yyt); break;
case kSetElab: (void) fputs (Tree_NodeName [kSetElab], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSetElab (yyt); break;
case kArrayUpd: (void) fputs (Tree_NodeName [kArrayUpd], yyf); (void) fputc ('\n', yyf);
 yWriteNodeArrayUpd (yyt); break;
case kNamedArrayAgg: (void) fputs (Tree_NodeName [kNamedArrayAgg], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNamedArrayAgg (yyt); break;
case kSequence: (void) fputs (Tree_NodeName [kSequence], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSequence (yyt); break;
case kBag: (void) fputs (Tree_NodeName [kBag], yyf); (void) fputc ('\n', yyf);
 yWriteNodeBag (yyt); break;
case kCartProd: (void) fputs (Tree_NodeName [kCartProd], yyf); (void) fputc ('\n', yyf);
 yWriteNodeCartProd (yyt); break;
case kTuple: (void) fputs (Tree_NodeName [kTuple], yyf); (void) fputc ('\n', yyf);
 yWriteNodeTuple (yyt); break;
case kExp_SchemaRef: (void) fputs (Tree_NodeName [kExp_SchemaRef], yyf); (void) fputc ('\n', yyf);
 yWriteNodeExp_SchemaRef (yyt); break;
case kTheta: (void) fputs (Tree_NodeName [kTheta], yyf); (void) fputc ('\n', yyf);
 yWriteNodeTheta (yyt); break;
case kInfixOp: (void) fputs (Tree_NodeName [kInfixOp], yyf); (void) fputc ('\n', yyf);
 yWriteNodeInfixOp (yyt); break;
case kPredExp: (void) fputs (Tree_NodeName [kPredExp], yyf); (void) fputc ('\n', yyf);
 yWriteNodePredExp (yyt); break;
case kPredList: (void) fputs (Tree_NodeName [kPredList], yyf); (void) fputc ('\n', yyf);
 yWriteNodePredList (yyt); break;
case kNoPred: (void) fputs (Tree_NodeName [kNoPred], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNoPred (yyt); break;
case kPred: (void) fputs (Tree_NodeName [kPred], yyf); (void) fputc ('\n', yyf);
 yWriteNodePred (yyt); break;
case kQuantPred: (void) fputs (Tree_NodeName [kQuantPred], yyf); (void) fputc ('\n', yyf);
 yWriteNodeQuantPred (yyt); break;
case kRelBinPred: (void) fputs (Tree_NodeName [kRelBinPred], yyf); (void) fputc ('\n', yyf);
 yWriteNodeRelBinPred (yyt); break;
case kAssign: (void) fputs (Tree_NodeName [kAssign], yyf); (void) fputc ('\n', yyf);
 yWriteNodeAssign (yyt); break;
case kRelPrePred: (void) fputs (Tree_NodeName [kRelPrePred], yyf); (void) fputc ('\n', yyf);
 yWriteNodeRelPrePred (yyt); break;
case kLogBinPred: (void) fputs (Tree_NodeName [kLogBinPred], yyf); (void) fputc ('\n', yyf);
 yWriteNodeLogBinPred (yyt); break;
case kLogicalNot: (void) fputs (Tree_NodeName [kLogicalNot], yyf); (void) fputc ('\n', yyf);
 yWriteNodeLogicalNot (yyt); break;
case kPreCondPred: (void) fputs (Tree_NodeName [kPreCondPred], yyf); (void) fputc ('\n', yyf);
 yWriteNodePreCondPred (yyt); break;
case kIfPred: (void) fputs (Tree_NodeName [kIfPred], yyf); (void) fputc ('\n', yyf);
 yWriteNodeIfPred (yyt); break;
case kWhilePred: (void) fputs (Tree_NodeName [kWhilePred], yyf); (void) fputc ('\n', yyf);
 yWriteNodeWhilePred (yyt); break;
case kCallPred: (void) fputs (Tree_NodeName [kCallPred], yyf); (void) fputc ('\n', yyf);
 yWriteNodeCallPred (yyt); break;
case kChgOnly: (void) fputs (Tree_NodeName [kChgOnly], yyf); (void) fputc ('\n', yyf);
 yWriteNodeChgOnly (yyt); break;
case kDefined: (void) fputs (Tree_NodeName [kDefined], yyf); (void) fputc ('\n', yyf);
 yWriteNodeDefined (yyt); break;
case kSchemaPred: (void) fputs (Tree_NodeName [kSchemaPred], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchemaPred (yyt); break;
case kBoolValue: (void) fputs (Tree_NodeName [kBoolValue], yyf); (void) fputc ('\n', yyf);
 yWriteNodeBoolValue (yyt); break;
case kInputBindList: (void) fputs (Tree_NodeName [kInputBindList], yyf); (void) fputc ('\n', yyf);
 yWriteNodeInputBindList (yyt); break;
case kNoInputBind: (void) fputs (Tree_NodeName [kNoInputBind], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNoInputBind (yyt); break;
case kInputBind: (void) fputs (Tree_NodeName [kInputBind], yyf); (void) fputc ('\n', yyf);
 yWriteNodeInputBind (yyt); break;
case kOutputBindList: (void) fputs (Tree_NodeName [kOutputBindList], yyf); (void) fputc ('\n', yyf);
 yWriteNodeOutputBindList (yyt); break;
case kNoOutputBind: (void) fputs (Tree_NodeName [kNoOutputBind], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNoOutputBind (yyt); break;
case kOutputBind: (void) fputs (Tree_NodeName [kOutputBind], yyf); (void) fputc ('\n', yyf);
 yWriteNodeOutputBind (yyt); break;
case kLogBinOp: (void) fputs (Tree_NodeName [kLogBinOp], yyf); (void) fputc ('\n', yyf);
 break;
case kLogSeq: (void) fputs (Tree_NodeName [kLogSeq], yyf); (void) fputc ('\n', yyf);
 break;
case kLogAnd: (void) fputs (Tree_NodeName [kLogAnd], yyf); (void) fputc ('\n', yyf);
 break;
case kLogExor: (void) fputs (Tree_NodeName [kLogExor], yyf); (void) fputc ('\n', yyf);
 break;
case kLogOr: (void) fputs (Tree_NodeName [kLogOr], yyf); (void) fputc ('\n', yyf);
 break;
case kLogImply: (void) fputs (Tree_NodeName [kLogImply], yyf); (void) fputc ('\n', yyf);
 break;
case kLogEquiv: (void) fputs (Tree_NodeName [kLogEquiv], yyf); (void) fputc ('\n', yyf);
 break;
case kDeclList: (void) fputs (Tree_NodeName [kDeclList], yyf); (void) fputc ('\n', yyf);
 yWriteNodeDeclList (yyt); break;
case kNoDecl: (void) fputs (Tree_NodeName [kNoDecl], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNoDecl (yyt); break;
case kDecl: (void) fputs (Tree_NodeName [kDecl], yyf); (void) fputc ('\n', yyf);
 yWriteNodeDecl (yyt); break;
case kVarDecl: (void) fputs (Tree_NodeName [kVarDecl], yyf); (void) fputc ('\n', yyf);
 yWriteNodeVarDecl (yyt); break;
case kGivenSet: (void) fputs (Tree_NodeName [kGivenSet], yyf); (void) fputc ('\n', yyf);
 yWriteNodeGivenSet (yyt); break;
case kAxiomDecl: (void) fputs (Tree_NodeName [kAxiomDecl], yyf); (void) fputc ('\n', yyf);
 yWriteNodeAxiomDecl (yyt); break;
case kSchemaDef: (void) fputs (Tree_NodeName [kSchemaDef], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchemaDef (yyt); break;
case kAnnotation: (void) fputs (Tree_NodeName [kAnnotation], yyf); (void) fputc ('\n', yyf);
 yWriteNodeAnnotation (yyt); break;
case kErgoAnno: (void) fputs (Tree_NodeName [kErgoAnno], yyf); (void) fputc ('\n', yyf);
 yWriteNodeErgoAnno (yyt); break;
case kStateMachine: (void) fputs (Tree_NodeName [kStateMachine], yyf); (void) fputc ('\n', yyf);
 yWriteNodeStateMachine (yyt); break;
case kAbbreviation: (void) fputs (Tree_NodeName [kAbbreviation], yyf); (void) fputc ('\n', yyf);
 yWriteNodeAbbreviation (yyt); break;
case kFunctionDecl: (void) fputs (Tree_NodeName [kFunctionDecl], yyf); (void) fputc ('\n', yyf);
 yWriteNodeFunctionDecl (yyt); break;
case kFreeType: (void) fputs (Tree_NodeName [kFreeType], yyf); (void) fputc ('\n', yyf);
 yWriteNodeFreeType (yyt); break;
case kEnum: (void) fputs (Tree_NodeName [kEnum], yyf); (void) fputc ('\n', yyf);
 yWriteNodeEnum (yyt); break;
case kImport: (void) fputs (Tree_NodeName [kImport], yyf); (void) fputc ('\n', yyf);
 yWriteNodeImport (yyt); break;
case kModuleDecl: (void) fputs (Tree_NodeName [kModuleDecl], yyf); (void) fputc ('\n', yyf);
 yWriteNodeModuleDecl (yyt); break;
case kConstraint: (void) fputs (Tree_NodeName [kConstraint], yyf); (void) fputc ('\n', yyf);
 yWriteNodeConstraint (yyt); break;
case kSchemaIncl: (void) fputs (Tree_NodeName [kSchemaIncl], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchemaIncl (yyt); break;
case kVisibility: (void) fputs (Tree_NodeName [kVisibility], yyf); (void) fputc ('\n', yyf);
 yWriteNodeVisibility (yyt); break;
case kBranchList: (void) fputs (Tree_NodeName [kBranchList], yyf); (void) fputc ('\n', yyf);
 yWriteNodeBranchList (yyt); break;
case kNoBranch: (void) fputs (Tree_NodeName [kNoBranch], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNoBranch (yyt); break;
case kBranch: (void) fputs (Tree_NodeName [kBranch], yyf); (void) fputc ('\n', yyf);
 yWriteNodeBranch (yyt); break;
case kFTConstant: (void) fputs (Tree_NodeName [kFTConstant], yyf); (void) fputc ('\n', yyf);
 yWriteNodeFTConstant (yyt); break;
case kFTConstructor: (void) fputs (Tree_NodeName [kFTConstructor], yyf); (void) fputc ('\n', yyf);
 yWriteNodeFTConstructor (yyt); break;
case kSchema: (void) fputs (Tree_NodeName [kSchema], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchema (yyt); break;
case kExpPred: (void) fputs (Tree_NodeName [kExpPred], yyf); (void) fputc ('\n', yyf);
 yWriteNodeExpPred (yyt); break;
case kSchemaText: (void) fputs (Tree_NodeName [kSchemaText], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchemaText (yyt); break;
case kSchemaRef: (void) fputs (Tree_NodeName [kSchemaRef], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchemaRef (yyt); break;
case kSchemaCons: (void) fputs (Tree_NodeName [kSchemaCons], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchemaCons (yyt); break;
case kSchemaCompos: (void) fputs (Tree_NodeName [kSchemaCompos], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchemaCompos (yyt); break;
case kSchemaProj: (void) fputs (Tree_NodeName [kSchemaProj], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchemaProj (yyt); break;
case kSchemaSubst: (void) fputs (Tree_NodeName [kSchemaSubst], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchemaSubst (yyt); break;
case kSchemaHiding: (void) fputs (Tree_NodeName [kSchemaHiding], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchemaHiding (yyt); break;
case kLogOp: (void) fputs (Tree_NodeName [kLogOp], yyf); (void) fputc ('\n', yyf);
 break;
case kSDisjunction: (void) fputs (Tree_NodeName [kSDisjunction], yyf); (void) fputc ('\n', yyf);
 break;
case kSConjunction: (void) fputs (Tree_NodeName [kSConjunction], yyf); (void) fputc ('\n', yyf);
 break;
case kSImplication: (void) fputs (Tree_NodeName [kSImplication], yyf); (void) fputc ('\n', yyf);
 break;
case kSEquivalence: (void) fputs (Tree_NodeName [kSEquivalence], yyf); (void) fputc ('\n', yyf);
 break;
 default: ;
 }
}

static short yyIndentLevel;

void WriteTree
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf, tTree yyt)
# else
 (yyyf, yyt) FILE * yyyf; tTree yyt;
# endif
{
 short yySaveLevel = yyIndentLevel;
 yyf = yyyf;
 if (yyRecursionLevel ++ == 0) yyLabelCount = 0;
 yyMark (yyt);
 yyIndentLevel = 0;
 yyWriteTree (yyt);
 yyIndentLevel = yySaveLevel;
 yyRecursionLevel --;
}

static void yyIndentSelector
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyIndentLevel; yyi ++) (void) putc (' ', yyf);
 yyWriteSelector (yys);
}

static void yyIndentSelectorTree
# if defined __STDC__ | defined __cplusplus
 (char * yys, tTree yyt)
# else
 (yys, yyt) char * yys; tTree yyt;
# endif
{ yyIndentSelector (yys); writetTree (yyt) }

static void yWriteSum
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSum], yyf); (void) fputc ('\n', yyf);
}

static void yWriteModuleList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kModuleList], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->ModuleList.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->ModuleList.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->ModuleList.DeclsOut) yyWriteNl ();
}

static void yWriteNoModule
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNoModule], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->NoModule.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NoModule.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NoModule.DeclsOut) yyWriteNl ();
}

static void yWriteModule
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kModule], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Module.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Module.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Module.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->Module.Ident) yyWriteNl ();
 yyIndentSelectorTree ("FormalParams", yyt->Module.FormalParams);
 yyIndentSelectorTree ("PredList", yyt->Module.PredList);
 yyIndentSelectorTree ("DeclList", yyt->Module.DeclList);
 yyIndentSelector ("IsNested"); writebool (yyt->Module.IsNested) yyWriteNl ();
}

static void yWriteFormalParams
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kFormalParams], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->FormalParams.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->FormalParams.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->FormalParams.DeclsOut) yyWriteNl ();
}

static void yWriteNoParam
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNoParam], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->NoParam.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NoParam.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NoParam.DeclsOut) yyWriteNl ();
}

static void yWriteParam
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kParam], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Param.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Param.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Param.DeclsOut) yyWriteNl ();
}

static void yWriteTyParam
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kTyParam], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->TyParam.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->TyParam.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->TyParam.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->TyParam.Ident) yyWriteNl ();
 yyIndentSelector ("IsPolyTy"); writebool (yyt->TyParam.IsPolyTy) yyWriteNl ();
}

static void yWriteFncParam
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kFncParam], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->FncParam.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->FncParam.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->FncParam.DeclsOut) yyWriteNl ();
 yyIndentSelectorTree ("VarDecl", yyt->FncParam.VarDecl);
}

static void yWriteRenameList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kRenameList], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->RenameList.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->RenameList.DeclsOut) yyWriteNl ();
}

static void yWriteNoRename
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNoRename], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NoRename.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NoRename.DeclsOut) yyWriteNl ();
}

static void yWriteRename
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kRename], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Rename.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Rename.DeclsOut) yyWriteNl ();
 yyIndentSelector ("NewIdent"); writetIdPos (yyt->Rename.NewIdent) yyWriteNl ();
 yyIndentSelectorTree ("OldIdent", yyt->Rename.OldIdent);
}

static void yWriteSelection
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSelection], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Ident"); writetIdPos (yyt->Selection.Ident) yyWriteNl ();
}

static void yWriteIdList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kIdList], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->IdList.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->IdList.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->IdList.DeclsOut) yyWriteNl ();
}

static void yWriteNoId
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNoId], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->NoId.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NoId.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NoId.DeclsOut) yyWriteNl ();
}

static void yWriteId
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kId], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Id.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Id.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Id.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->Id.Ident) yyWriteNl ();
 yyIndentSelector ("IdKind"); writeint (yyt->Id.IdKind) yyWriteNl ();
}

static void yWriteNameList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNameList], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->NameList.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NameList.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NameList.DeclsOut) yyWriteNl ();
}

static void yWriteNoName
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNoName], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->NoName.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NoName.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NoName.DeclsOut) yyWriteNl ();
}

static void yWriteName
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kName], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Name.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Name.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Name.DeclsOut) yyWriteNl ();
 yyIndentSelectorTree ("Next", yyt->Name.Next);
}

static void yWriteExpressionList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kExpressionList], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->ExpressionList.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->ExpressionList.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->ExpressionList.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->ExpressionList.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->ExpressionList.Type) yyWriteNl ();
}

static void yWriteNoExp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNoExp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->NoExp.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->NoExp.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NoExp.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NoExp.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->NoExp.Type) yyWriteNl ();
}

static void yWriteExp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kExp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Exp.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Exp.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Exp.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Exp.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Exp.Type) yyWriteNl ();
}

static void yWriteVariable
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kVariable], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Variable.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Variable.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Variable.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Variable.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Variable.Type) yyWriteNl ();
 yyIndentSelectorTree ("IdList", yyt->Variable.IdList);
 yyIndentSelector ("SymPtr"); writetObjects (yyt->Variable.SymPtr) yyWriteNl ();
 yyIndentSelector ("IsBinding"); writebool (yyt->Variable.IsBinding) yyWriteNl ();
}

static void yWriteLiteral
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kLiteral], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Literal.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Literal.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Literal.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Literal.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Literal.Type) yyWriteNl ();
 yyIndentSelector ("Literal"); writetIdPos (yyt->Literal.Literal) yyWriteNl ();
}

static void yWriteString
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kString], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->String.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->String.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->String.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->String.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->String.Type) yyWriteNl ();
 yyIndentSelector ("String"); writetIdPos (yyt->String.String) yyWriteNl ();
}

static void yWriteChar
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kChar], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Char.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Char.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Char.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Char.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Char.Type) yyWriteNl ();
 yyIndentSelector ("Char"); writetIdPos (yyt->Char.Char) yyWriteNl ();
}

static void yWritePrefixOp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kPrefixOp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->PrefixOp.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->PrefixOp.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->PrefixOp.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->PrefixOp.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->PrefixOp.Type) yyWriteNl ();
 yyIndentSelector ("Prefix"); writetIdPos (yyt->PrefixOp.Prefix) yyWriteNl ();
 yyIndentSelectorTree ("Exp", yyt->PrefixOp.Exp);
}

static void yWriteLambda
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kLambda], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Lambda.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Lambda.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Lambda.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Lambda.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Lambda.Type) yyWriteNl ();
 yyIndentSelectorTree ("SchemaText", yyt->Lambda.SchemaText);
 yyIndentSelectorTree ("Exp", yyt->Lambda.Exp);
}

static void yWriteRecDisp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kRecDisp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->RecDisp.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->RecDisp.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->RecDisp.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->RecDisp.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->RecDisp.Type) yyWriteNl ();
 yyIndentSelectorTree ("SchemaText", yyt->RecDisp.SchemaText);
 yyIndentSelectorTree ("PredList", yyt->RecDisp.PredList);
}

static void yWriteMu
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kMu], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Mu.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Mu.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Mu.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Mu.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Mu.Type) yyWriteNl ();
 yyIndentSelectorTree ("SchemaText", yyt->Mu.SchemaText);
 yyIndentSelectorTree ("ExpressionList", yyt->Mu.ExpressionList);
}

static void yWriteTupSelection
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kTupSelection], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->TupSelection.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->TupSelection.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->TupSelection.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->TupSelection.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->TupSelection.Type) yyWriteNl ();
 yyIndentSelectorTree ("Exp", yyt->TupSelection.Exp);
 yyIndentSelector ("Number"); writetIdPos (yyt->TupSelection.Number) yyWriteNl ();
}

static void yWriteVarSelection
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kVarSelection], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->VarSelection.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->VarSelection.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->VarSelection.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->VarSelection.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->VarSelection.Type) yyWriteNl ();
 yyIndentSelectorTree ("Exp", yyt->VarSelection.Exp);
 yyIndentSelector ("Ident"); writetIdPos (yyt->VarSelection.Ident) yyWriteNl ();
}

static void yWriteIfExp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kIfExp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->IfExp.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->IfExp.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->IfExp.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->IfExp.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->IfExp.Type) yyWriteNl ();
 yyIndentSelectorTree ("Con", yyt->IfExp.Con);
 yyIndentSelectorTree ("Then", yyt->IfExp.Then);
 yyIndentSelectorTree ("Else", yyt->IfExp.Else);
}

static void yWriteFncApplication
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kFncApplication], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->FncApplication.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->FncApplication.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->FncApplication.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->FncApplication.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->FncApplication.Type) yyWriteNl ();
 yyIndentSelectorTree ("Fnc", yyt->FncApplication.Fnc);
 yyIndentSelectorTree ("Arg", yyt->FncApplication.Arg);
}

static void yWriteSetComp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSetComp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SetComp.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->SetComp.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SetComp.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SetComp.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SetComp.Type) yyWriteNl ();
 yyIndentSelectorTree ("SchemaText", yyt->SetComp.SchemaText);
 yyIndentSelectorTree ("ExpressionList", yyt->SetComp.ExpressionList);
}

static void yWriteSetElab
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSetElab], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SetElab.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->SetElab.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SetElab.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SetElab.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SetElab.Type) yyWriteNl ();
 yyIndentSelectorTree ("ExpressionList", yyt->SetElab.ExpressionList);
}

static void yWriteArrayUpd
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kArrayUpd], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->ArrayUpd.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->ArrayUpd.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->ArrayUpd.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->ArrayUpd.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->ArrayUpd.Type) yyWriteNl ();
 yyIndentSelectorTree ("Array", yyt->ArrayUpd.Array);
 yyIndentSelectorTree ("Index", yyt->ArrayUpd.Index);
 yyIndentSelectorTree ("Value", yyt->ArrayUpd.Value);
}

static void yWriteNamedArrayAgg
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNamedArrayAgg], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->NamedArrayAgg.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->NamedArrayAgg.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NamedArrayAgg.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NamedArrayAgg.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->NamedArrayAgg.Type) yyWriteNl ();
 yyIndentSelectorTree ("ExpressionList", yyt->NamedArrayAgg.ExpressionList);
}

static void yWriteSequence
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSequence], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Sequence.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Sequence.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Sequence.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Sequence.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Sequence.Type) yyWriteNl ();
 yyIndentSelectorTree ("ExpressionList", yyt->Sequence.ExpressionList);
}

static void yWriteBag
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kBag], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Bag.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Bag.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Bag.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Bag.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Bag.Type) yyWriteNl ();
 yyIndentSelectorTree ("ExpressionList", yyt->Bag.ExpressionList);
}

static void yWriteCartProd
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kCartProd], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->CartProd.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->CartProd.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->CartProd.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->CartProd.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->CartProd.Type) yyWriteNl ();
 yyIndentSelectorTree ("ExpressionList", yyt->CartProd.ExpressionList);
}

static void yWriteTuple
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kTuple], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Tuple.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tuple.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Tuple.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Tuple.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Tuple.Type) yyWriteNl ();
 yyIndentSelectorTree ("ExpressionList", yyt->Tuple.ExpressionList);
}

static void yWriteExp_SchemaRef
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kExp_SchemaRef], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Exp_SchemaRef.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Exp_SchemaRef.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Exp_SchemaRef.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Exp_SchemaRef.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Exp_SchemaRef.Type) yyWriteNl ();
 yyIndentSelectorTree ("IdList", yyt->Exp_SchemaRef.IdList);
 yyIndentSelectorTree ("ExpressionList", yyt->Exp_SchemaRef.ExpressionList);
}

static void yWriteTheta
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kTheta], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Theta.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Theta.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Theta.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Theta.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Theta.Type) yyWriteNl ();
 yyIndentSelectorTree ("Exp", yyt->Theta.Exp);
}

static void yWriteInfixOp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kInfixOp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->InfixOp.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->InfixOp.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->InfixOp.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->InfixOp.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->InfixOp.Type) yyWriteNl ();
 yyIndentSelectorTree ("Op1", yyt->InfixOp.Op1);
 yyIndentSelector ("Infix"); writetIdPos (yyt->InfixOp.Infix) yyWriteNl ();
 yyIndentSelectorTree ("Op2", yyt->InfixOp.Op2);
}

static void yWritePredExp
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kPredExp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->PredExp.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->PredExp.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->PredExp.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->PredExp.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->PredExp.Type) yyWriteNl ();
 yyIndentSelectorTree ("Pred", yyt->PredExp.Pred);
}

static void yWritePredList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kPredList], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->PredList.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->PredList.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->PredList.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->PredList.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->PredList.Type) yyWriteNl ();
}

static void yWriteNoPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNoPred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->NoPred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->NoPred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NoPred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NoPred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->NoPred.Type) yyWriteNl ();
}

static void yWritePred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kPred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Pred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Pred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Pred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Pred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Pred.Type) yyWriteNl ();
}

static void yWriteQuantPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kQuantPred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->QuantPred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->QuantPred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->QuantPred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->QuantPred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->QuantPred.Type) yyWriteNl ();
 yyIndentSelector ("LogQuant"); writetIdPos (yyt->QuantPred.LogQuant) yyWriteNl ();
 yyIndentSelectorTree ("SchemaText", yyt->QuantPred.SchemaText);
 yyIndentSelectorTree ("Pred", yyt->QuantPred.Pred);
}

static void yWriteRelBinPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kRelBinPred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->RelBinPred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->RelBinPred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->RelBinPred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->RelBinPred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->RelBinPred.Type) yyWriteNl ();
 yyIndentSelectorTree ("L", yyt->RelBinPred.L);
 yyIndentSelector ("RelBinOp"); writetIdPos (yyt->RelBinPred.RelBinOp) yyWriteNl ();
 yyIndentSelectorTree ("R", yyt->RelBinPred.R);
}

static void yWriteAssign
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kAssign], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Assign.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Assign.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Assign.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Assign.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Assign.Type) yyWriteNl ();
 yyIndentSelectorTree ("L", yyt->Assign.L);
 yyIndentSelectorTree ("R", yyt->Assign.R);
}

static void yWriteRelPrePred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kRelPrePred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->RelPrePred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->RelPrePred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->RelPrePred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->RelPrePred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->RelPrePred.Type) yyWriteNl ();
 yyIndentSelector ("RelPreOp"); writetIdPos (yyt->RelPrePred.RelPreOp) yyWriteNl ();
 yyIndentSelectorTree ("Exp", yyt->RelPrePred.Exp);
}

static void yWriteLogBinPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kLogBinPred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->LogBinPred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->LogBinPred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->LogBinPred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->LogBinPred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->LogBinPred.Type) yyWriteNl ();
 yyIndentSelectorTree ("L", yyt->LogBinPred.L);
 yyIndentSelectorTree ("LogBinOp", yyt->LogBinPred.LogBinOp);
 yyIndentSelectorTree ("R", yyt->LogBinPred.R);
}

static void yWriteLogicalNot
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kLogicalNot], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->LogicalNot.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->LogicalNot.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->LogicalNot.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->LogicalNot.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->LogicalNot.Type) yyWriteNl ();
 yyIndentSelectorTree ("Pred", yyt->LogicalNot.Pred);
}

static void yWritePreCondPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kPreCondPred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->PreCondPred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->PreCondPred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->PreCondPred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->PreCondPred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->PreCondPred.Type) yyWriteNl ();
 yyIndentSelectorTree ("Pred", yyt->PreCondPred.Pred);
}

static void yWriteIfPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kIfPred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->IfPred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->IfPred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->IfPred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->IfPred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->IfPred.Type) yyWriteNl ();
 yyIndentSelectorTree ("Con", yyt->IfPred.Con);
 yyIndentSelectorTree ("Then", yyt->IfPred.Then);
 yyIndentSelectorTree ("Else", yyt->IfPred.Else);
}

static void yWriteWhilePred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kWhilePred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->WhilePred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->WhilePred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->WhilePred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->WhilePred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->WhilePred.Type) yyWriteNl ();
 yyIndentSelectorTree ("Con", yyt->WhilePred.Con);
 yyIndentSelectorTree ("Do", yyt->WhilePred.Do);
}

static void yWriteCallPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kCallPred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->CallPred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->CallPred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->CallPred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->CallPred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->CallPred.Type) yyWriteNl ();
 yyIndentSelectorTree ("IdList", yyt->CallPred.IdList);
 yyIndentSelectorTree ("InputBindList", yyt->CallPred.InputBindList);
 yyIndentSelectorTree ("OutputBindList", yyt->CallPred.OutputBindList);
}

static void yWriteChgOnly
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kChgOnly], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->ChgOnly.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->ChgOnly.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->ChgOnly.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->ChgOnly.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->ChgOnly.Type) yyWriteNl ();
 yyIndentSelectorTree ("NameList", yyt->ChgOnly.NameList);
}

static void yWriteDefined
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kDefined], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Defined.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Defined.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Defined.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Defined.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Defined.Type) yyWriteNl ();
 yyIndentSelectorTree ("Exp", yyt->Defined.Exp);
}

static void yWriteSchemaPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSchemaPred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SchemaPred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->SchemaPred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SchemaPred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SchemaPred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SchemaPred.Type) yyWriteNl ();
 yyIndentSelectorTree ("Schema", yyt->SchemaPred.Schema);
}

static void yWriteBoolValue
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kBoolValue], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->BoolValue.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->BoolValue.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->BoolValue.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->BoolValue.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->BoolValue.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->BoolValue.Ident) yyWriteNl ();
}

static void yWriteInputBindList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kInputBindList], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->InputBindList.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->InputBindList.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->InputBindList.Type) yyWriteNl ();
}

static void yWriteNoInputBind
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNoInputBind], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NoInputBind.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NoInputBind.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->NoInputBind.Type) yyWriteNl ();
}

static void yWriteInputBind
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kInputBind], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->InputBind.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->InputBind.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->InputBind.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->InputBind.Ident) yyWriteNl ();
 yyIndentSelectorTree ("ExpressionList", yyt->InputBind.ExpressionList);
}

static void yWriteOutputBindList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kOutputBindList], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->OutputBindList.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->OutputBindList.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->OutputBindList.Type) yyWriteNl ();
}

static void yWriteNoOutputBind
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNoOutputBind], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NoOutputBind.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NoOutputBind.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->NoOutputBind.Type) yyWriteNl ();
}

static void yWriteOutputBind
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kOutputBind], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->OutputBind.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->OutputBind.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->OutputBind.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->OutputBind.Ident) yyWriteNl ();
 yyIndentSelectorTree ("IdList", yyt->OutputBind.IdList);
}

static void yWriteDeclList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kDeclList], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->DeclList.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->DeclList.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->DeclList.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->DeclList.Type) yyWriteNl ();
}

static void yWriteNoDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNoDecl], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->NoDecl.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NoDecl.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NoDecl.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->NoDecl.Type) yyWriteNl ();
}

static void yWriteDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kDecl], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Decl.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Decl.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Decl.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Decl.Type) yyWriteNl ();
}

static void yWriteVarDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kVarDecl], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->VarDecl.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->VarDecl.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->VarDecl.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->VarDecl.Type) yyWriteNl ();
 yyIndentSelectorTree ("IdList", yyt->VarDecl.IdList);
 yyIndentSelectorTree ("Exp", yyt->VarDecl.Exp);
 yyIndentSelector ("VarDeclKind"); writeint (yyt->VarDecl.VarDeclKind) yyWriteNl ();
}

static void yWriteGivenSet
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kGivenSet], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->GivenSet.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->GivenSet.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->GivenSet.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->GivenSet.Type) yyWriteNl ();
 yyIndentSelectorTree ("IdList", yyt->GivenSet.IdList);
}

static void yWriteAxiomDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kAxiomDecl], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->AxiomDecl.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->AxiomDecl.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->AxiomDecl.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->AxiomDecl.Type) yyWriteNl ();
 yyIndentSelectorTree ("FormalParams", yyt->AxiomDecl.FormalParams);
 yyIndentSelectorTree ("DeclList", yyt->AxiomDecl.DeclList);
 yyIndentSelectorTree ("PredList", yyt->AxiomDecl.PredList);
}

static void yWriteSchemaDef
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSchemaDef], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SchemaDef.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SchemaDef.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SchemaDef.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SchemaDef.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->SchemaDef.Ident) yyWriteNl ();
 yyIndentSelectorTree ("FormalParams", yyt->SchemaDef.FormalParams);
 yyIndentSelectorTree ("DeclList", yyt->SchemaDef.DeclList);
 yyIndentSelectorTree ("PredList", yyt->SchemaDef.PredList);
 yyIndentSelector ("IsOp"); writebool (yyt->SchemaDef.IsOp) yyWriteNl ();
 yyIndentSelector ("HasStateIncl"); writebool (yyt->SchemaDef.HasStateIncl) yyWriteNl ();
}

static void yWriteAnnotation
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kAnnotation], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Annotation.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Annotation.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Annotation.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Annotation.Type) yyWriteNl ();
 yyIndentSelectorTree ("Decl", yyt->Annotation.Decl);
}

static void yWriteErgoAnno
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kErgoAnno], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->ErgoAnno.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->ErgoAnno.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->ErgoAnno.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->ErgoAnno.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->ErgoAnno.Ident) yyWriteNl ();
}

static void yWriteStateMachine
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kStateMachine], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->StateMachine.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->StateMachine.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->StateMachine.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->StateMachine.Type) yyWriteNl ();
 yyIndentSelectorTree ("IdList", yyt->StateMachine.IdList);
}

static void yWriteAbbreviation
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kAbbreviation], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Abbreviation.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Abbreviation.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Abbreviation.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Abbreviation.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->Abbreviation.Ident) yyWriteNl ();
 yyIndentSelectorTree ("Exp", yyt->Abbreviation.Exp);
}

static void yWriteFunctionDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kFunctionDecl], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->FunctionDecl.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->FunctionDecl.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->FunctionDecl.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->FunctionDecl.Type) yyWriteNl ();
 yyIndentSelectorTree ("DeclList", yyt->FunctionDecl.DeclList);
 yyIndentSelectorTree ("PredList", yyt->FunctionDecl.PredList);
}

static void yWriteFreeType
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kFreeType], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->FreeType.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->FreeType.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->FreeType.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->FreeType.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->FreeType.Ident) yyWriteNl ();
 yyIndentSelectorTree ("BranchList", yyt->FreeType.BranchList);
 yyIndentSelector ("ModId"); writetIdent (yyt->FreeType.ModId) yyWriteNl ();
}

static void yWriteEnum
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kEnum], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Enum.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Enum.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Enum.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Enum.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->Enum.Ident) yyWriteNl ();
 yyIndentSelectorTree ("BranchList", yyt->Enum.BranchList);
 yyIndentSelector ("ModId"); writetIdent (yyt->Enum.ModId) yyWriteNl ();
}

static void yWriteImport
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kImport], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Import.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Import.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Import.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Import.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->Import.Ident) yyWriteNl ();
 yyIndentSelectorTree ("ExpressionList", yyt->Import.ExpressionList);
 yyIndentSelectorTree ("RenameList", yyt->Import.RenameList);
 yyIndentSelector ("NewIdent"); writetIdPos (yyt->Import.NewIdent) yyWriteNl ();
 yyIndentSelector ("ModIMLlist"); writeIML_List (yyt->Import.ModIMLlist) yyWriteNl ();
 yyIndentSelector ("FmlParams"); writetObjects (yyt->Import.FmlParams) yyWriteNl ();
}

static void yWriteModuleDecl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kModuleDecl], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->ModuleDecl.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->ModuleDecl.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->ModuleDecl.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->ModuleDecl.Type) yyWriteNl ();
 yyIndentSelectorTree ("Module", yyt->ModuleDecl.Module);
}

static void yWriteConstraint
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kConstraint], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Constraint.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Constraint.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Constraint.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Constraint.Type) yyWriteNl ();
 yyIndentSelectorTree ("Pred", yyt->Constraint.Pred);
}

static void yWriteSchemaIncl
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSchemaIncl], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SchemaIncl.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SchemaIncl.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SchemaIncl.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SchemaIncl.Type) yyWriteNl ();
 yyIndentSelectorTree ("IdList", yyt->SchemaIncl.IdList);
 yyIndentSelectorTree ("ExpressionList", yyt->SchemaIncl.ExpressionList);
 yyIndentSelector ("ModId"); writetIdent (yyt->SchemaIncl.ModId) yyWriteNl ();
}

static void yWriteVisibility
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kVisibility], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Visibility.Pos) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Visibility.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Visibility.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Visibility.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->Visibility.Ident) yyWriteNl ();
 yyIndentSelectorTree ("SelectionList", yyt->Visibility.SelectionList);
}

static void yWriteBranchList
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kBranchList], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->BranchList.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->BranchList.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->BranchList.Type) yyWriteNl ();
}

static void yWriteNoBranch
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kNoBranch], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->NoBranch.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->NoBranch.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->NoBranch.Type) yyWriteNl ();
}

static void yWriteBranch
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kBranch], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Branch.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Branch.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Branch.Type) yyWriteNl ();
 yyIndentSelector ("FTIdent"); writetIdent (yyt->Branch.FTIdent) yyWriteNl ();
}

static void yWriteFTConstant
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kFTConstant], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->FTConstant.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->FTConstant.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->FTConstant.Type) yyWriteNl ();
 yyIndentSelector ("FTIdent"); writetIdent (yyt->FTConstant.FTIdent) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->FTConstant.Ident) yyWriteNl ();
}

static void yWriteFTConstructor
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kFTConstructor], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->FTConstructor.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->FTConstructor.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->FTConstructor.Type) yyWriteNl ();
 yyIndentSelector ("FTIdent"); writetIdent (yyt->FTConstructor.FTIdent) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdPos (yyt->FTConstructor.Ident) yyWriteNl ();
 yyIndentSelectorTree ("Exp", yyt->FTConstructor.Exp);
}

static void yWriteSchema
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSchema], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->Schema.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Schema.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->Schema.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->Schema.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Schema.Type) yyWriteNl ();
}

static void yWriteExpPred
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kExpPred], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->ExpPred.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->ExpPred.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->ExpPred.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->ExpPred.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->ExpPred.Type) yyWriteNl ();
}

static void yWriteSchemaText
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSchemaText], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SchemaText.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->SchemaText.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SchemaText.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SchemaText.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SchemaText.Type) yyWriteNl ();
 yyIndentSelectorTree ("DeclList", yyt->SchemaText.DeclList);
 yyIndentSelector ("Is_local_dec"); writebool (yyt->SchemaText.Is_local_dec) yyWriteNl ();
}

static void yWriteSchemaRef
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSchemaRef], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SchemaRef.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->SchemaRef.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SchemaRef.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SchemaRef.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SchemaRef.Type) yyWriteNl ();
 yyIndentSelectorTree ("IdList", yyt->SchemaRef.IdList);
}

static void yWriteSchemaCons
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSchemaCons], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SchemaCons.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->SchemaCons.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SchemaCons.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SchemaCons.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SchemaCons.Type) yyWriteNl ();
 yyIndentSelectorTree ("LogOp", yyt->SchemaCons.LogOp);
 yyIndentSelectorTree ("L", yyt->SchemaCons.L);
}

static void yWriteSchemaCompos
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSchemaCompos], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SchemaCompos.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->SchemaCompos.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SchemaCompos.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SchemaCompos.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SchemaCompos.Type) yyWriteNl ();
 yyIndentSelectorTree ("Sch1", yyt->SchemaCompos.Sch1);
 yyIndentSelector ("Compos"); writetIdPos (yyt->SchemaCompos.Compos) yyWriteNl ();
}

static void yWriteSchemaProj
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSchemaProj], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SchemaProj.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->SchemaProj.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SchemaProj.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SchemaProj.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SchemaProj.Type) yyWriteNl ();
 yyIndentSelectorTree ("Sch1", yyt->SchemaProj.Sch1);
 yyIndentSelector ("Proj"); writetIdPos (yyt->SchemaProj.Proj) yyWriteNl ();
}

static void yWriteSchemaSubst
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSchemaSubst], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SchemaSubst.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->SchemaSubst.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SchemaSubst.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SchemaSubst.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SchemaSubst.Type) yyWriteNl ();
 yyIndentSelectorTree ("Schema", yyt->SchemaSubst.Schema);
}

static void yWriteSchemaHiding
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 (void) fputs (Tree_NodeName [kSchemaHiding], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pos"); writetPosition (yyt->SchemaHiding.Pos) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->SchemaHiding.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("DeclsIn"); writetObjects (yyt->SchemaHiding.DeclsIn) yyWriteNl ();
 yyIndentSelector ("DeclsOut"); writetObjects (yyt->SchemaHiding.DeclsOut) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->SchemaHiding.Type) yyWriteNl ();
 yyIndentSelectorTree ("Schema", yyt->SchemaHiding.Schema);
}

static void yyWriteTree
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{ unsigned short yyLevel = yyIndentLevel;
 for (;;) {
  if (yyt == NoTree) { (void) fputs (" NoTree\n", yyf); goto yyExit;
  } else if (yyt->yyHead.yyMark == 0) { (void) fprintf (yyf, "^%d\n", yyMapToLabel (yyt)); goto yyExit;
  } else if (yyt->yyHead.yyMark > 1) {
   register int yyi;
   (void) fprintf (yyf, "\n%06d:", yyMapToLabel (yyt));
   for (yyi = 8; yyi <= yyIndentLevel; yyi ++) (void) putc (' ', yyf);
  } else (void) putc (' ', yyf);
  yyt->yyHead.yyMark = 0;
  yyIndentLevel += 2;

  switch (yyt->Kind) {
case kSum: yWriteSum (yyt); yyIndentSelector ("ModuleList"); yyt = yyt->Sum.ModuleList; break;
case kModuleList: yWriteModuleList (yyt); goto yyExit;
case kNoModule: yWriteNoModule (yyt); goto yyExit;
case kModule: yWriteModule (yyt); yyIndentSelector ("Next"); yyt = yyt->Module.Next; break;
case kFormalParams: yWriteFormalParams (yyt); goto yyExit;
case kNoParam: yWriteNoParam (yyt); goto yyExit;
case kParam: yWriteParam (yyt); yyIndentSelector ("Next"); yyt = yyt->Param.Next; break;
case kTyParam: yWriteTyParam (yyt); yyIndentSelector ("Next"); yyt = yyt->TyParam.Next; break;
case kFncParam: yWriteFncParam (yyt); yyIndentSelector ("Next"); yyt = yyt->FncParam.Next; break;
case kRenameList: yWriteRenameList (yyt); goto yyExit;
case kNoRename: yWriteNoRename (yyt); goto yyExit;
case kRename: yWriteRename (yyt); yyIndentSelector ("Next"); yyt = yyt->Rename.Next; break;
case kSelectionList: (void) fputs (Tree_NodeName [kSelectionList], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kNoSelection: (void) fputs (Tree_NodeName [kNoSelection], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kSelection: yWriteSelection (yyt); yyIndentSelector ("Next"); yyt = yyt->Selection.Next; break;
case kIdList: yWriteIdList (yyt); goto yyExit;
case kNoId: yWriteNoId (yyt); goto yyExit;
case kId: yWriteId (yyt); yyIndentSelector ("Next"); yyt = yyt->Id.Next; break;
case kNameList: yWriteNameList (yyt); goto yyExit;
case kNoName: yWriteNoName (yyt); goto yyExit;
case kName: yWriteName (yyt); yyIndentSelector ("IdList"); yyt = yyt->Name.IdList; break;
case kExpressionList: yWriteExpressionList (yyt); goto yyExit;
case kNoExp: yWriteNoExp (yyt); goto yyExit;
case kExp: yWriteExp (yyt); yyIndentSelector ("Next"); yyt = yyt->Exp.Next; break;
case kVariable: yWriteVariable (yyt); yyIndentSelector ("Next"); yyt = yyt->Variable.Next; break;
case kLiteral: yWriteLiteral (yyt); yyIndentSelector ("Next"); yyt = yyt->Literal.Next; break;
case kString: yWriteString (yyt); yyIndentSelector ("Next"); yyt = yyt->String.Next; break;
case kChar: yWriteChar (yyt); yyIndentSelector ("Next"); yyt = yyt->Char.Next; break;
case kPrefixOp: yWritePrefixOp (yyt); yyIndentSelector ("Next"); yyt = yyt->PrefixOp.Next; break;
case kLambda: yWriteLambda (yyt); yyIndentSelector ("Next"); yyt = yyt->Lambda.Next; break;
case kRecDisp: yWriteRecDisp (yyt); yyIndentSelector ("Next"); yyt = yyt->RecDisp.Next; break;
case kMu: yWriteMu (yyt); yyIndentSelector ("Next"); yyt = yyt->Mu.Next; break;
case kTupSelection: yWriteTupSelection (yyt); yyIndentSelector ("Next"); yyt = yyt->TupSelection.Next; break;
case kVarSelection: yWriteVarSelection (yyt); yyIndentSelector ("Next"); yyt = yyt->VarSelection.Next; break;
case kIfExp: yWriteIfExp (yyt); yyIndentSelector ("Next"); yyt = yyt->IfExp.Next; break;
case kFncApplication: yWriteFncApplication (yyt); yyIndentSelector ("Next"); yyt = yyt->FncApplication.Next; break;
case kSetComp: yWriteSetComp (yyt); yyIndentSelector ("Next"); yyt = yyt->SetComp.Next; break;
case kSetElab: yWriteSetElab (yyt); yyIndentSelector ("Next"); yyt = yyt->SetElab.Next; break;
case kArrayUpd: yWriteArrayUpd (yyt); yyIndentSelector ("Next"); yyt = yyt->ArrayUpd.Next; break;
case kNamedArrayAgg: yWriteNamedArrayAgg (yyt); yyIndentSelector ("Next"); yyt = yyt->NamedArrayAgg.Next; break;
case kSequence: yWriteSequence (yyt); yyIndentSelector ("Next"); yyt = yyt->Sequence.Next; break;
case kBag: yWriteBag (yyt); yyIndentSelector ("Next"); yyt = yyt->Bag.Next; break;
case kCartProd: yWriteCartProd (yyt); yyIndentSelector ("Next"); yyt = yyt->CartProd.Next; break;
case kTuple: yWriteTuple (yyt); yyIndentSelector ("Next"); yyt = yyt->Tuple.Next; break;
case kExp_SchemaRef: yWriteExp_SchemaRef (yyt); yyIndentSelector ("Next"); yyt = yyt->Exp_SchemaRef.Next; break;
case kTheta: yWriteTheta (yyt); yyIndentSelector ("Next"); yyt = yyt->Theta.Next; break;
case kInfixOp: yWriteInfixOp (yyt); yyIndentSelector ("Next"); yyt = yyt->InfixOp.Next; break;
case kPredExp: yWritePredExp (yyt); yyIndentSelector ("Next"); yyt = yyt->PredExp.Next; break;
case kPredList: yWritePredList (yyt); goto yyExit;
case kNoPred: yWriteNoPred (yyt); goto yyExit;
case kPred: yWritePred (yyt); yyIndentSelector ("Next"); yyt = yyt->Pred.Next; break;
case kQuantPred: yWriteQuantPred (yyt); yyIndentSelector ("Next"); yyt = yyt->QuantPred.Next; break;
case kRelBinPred: yWriteRelBinPred (yyt); yyIndentSelector ("Next"); yyt = yyt->RelBinPred.Next; break;
case kAssign: yWriteAssign (yyt); yyIndentSelector ("Next"); yyt = yyt->Assign.Next; break;
case kRelPrePred: yWriteRelPrePred (yyt); yyIndentSelector ("Next"); yyt = yyt->RelPrePred.Next; break;
case kLogBinPred: yWriteLogBinPred (yyt); yyIndentSelector ("Next"); yyt = yyt->LogBinPred.Next; break;
case kLogicalNot: yWriteLogicalNot (yyt); yyIndentSelector ("Next"); yyt = yyt->LogicalNot.Next; break;
case kPreCondPred: yWritePreCondPred (yyt); yyIndentSelector ("Next"); yyt = yyt->PreCondPred.Next; break;
case kIfPred: yWriteIfPred (yyt); yyIndentSelector ("Next"); yyt = yyt->IfPred.Next; break;
case kWhilePred: yWriteWhilePred (yyt); yyIndentSelector ("Next"); yyt = yyt->WhilePred.Next; break;
case kCallPred: yWriteCallPred (yyt); yyIndentSelector ("Next"); yyt = yyt->CallPred.Next; break;
case kChgOnly: yWriteChgOnly (yyt); yyIndentSelector ("Next"); yyt = yyt->ChgOnly.Next; break;
case kDefined: yWriteDefined (yyt); yyIndentSelector ("Next"); yyt = yyt->Defined.Next; break;
case kSchemaPred: yWriteSchemaPred (yyt); yyIndentSelector ("Next"); yyt = yyt->SchemaPred.Next; break;
case kBoolValue: yWriteBoolValue (yyt); yyIndentSelector ("Next"); yyt = yyt->BoolValue.Next; break;
case kInputBindList: yWriteInputBindList (yyt); goto yyExit;
case kNoInputBind: yWriteNoInputBind (yyt); goto yyExit;
case kInputBind: yWriteInputBind (yyt); yyIndentSelector ("Next"); yyt = yyt->InputBind.Next; break;
case kOutputBindList: yWriteOutputBindList (yyt); goto yyExit;
case kNoOutputBind: yWriteNoOutputBind (yyt); goto yyExit;
case kOutputBind: yWriteOutputBind (yyt); yyIndentSelector ("Next"); yyt = yyt->OutputBind.Next; break;
case kLogBinOp: (void) fputs (Tree_NodeName [kLogBinOp], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kLogSeq: (void) fputs (Tree_NodeName [kLogSeq], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kLogAnd: (void) fputs (Tree_NodeName [kLogAnd], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kLogExor: (void) fputs (Tree_NodeName [kLogExor], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kLogOr: (void) fputs (Tree_NodeName [kLogOr], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kLogImply: (void) fputs (Tree_NodeName [kLogImply], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kLogEquiv: (void) fputs (Tree_NodeName [kLogEquiv], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kDeclList: yWriteDeclList (yyt); goto yyExit;
case kNoDecl: yWriteNoDecl (yyt); goto yyExit;
case kDecl: yWriteDecl (yyt); yyIndentSelector ("Next"); yyt = yyt->Decl.Next; break;
case kVarDecl: yWriteVarDecl (yyt); yyIndentSelector ("Next"); yyt = yyt->VarDecl.Next; break;
case kGivenSet: yWriteGivenSet (yyt); yyIndentSelector ("Next"); yyt = yyt->GivenSet.Next; break;
case kAxiomDecl: yWriteAxiomDecl (yyt); yyIndentSelector ("Next"); yyt = yyt->AxiomDecl.Next; break;
case kSchemaDef: yWriteSchemaDef (yyt); yyIndentSelector ("Next"); yyt = yyt->SchemaDef.Next; break;
case kAnnotation: yWriteAnnotation (yyt); yyIndentSelector ("Next"); yyt = yyt->Annotation.Next; break;
case kErgoAnno: yWriteErgoAnno (yyt); yyIndentSelector ("Next"); yyt = yyt->ErgoAnno.Next; break;
case kStateMachine: yWriteStateMachine (yyt); yyIndentSelector ("Next"); yyt = yyt->StateMachine.Next; break;
case kAbbreviation: yWriteAbbreviation (yyt); yyIndentSelector ("Next"); yyt = yyt->Abbreviation.Next; break;
case kFunctionDecl: yWriteFunctionDecl (yyt); yyIndentSelector ("Next"); yyt = yyt->FunctionDecl.Next; break;
case kFreeType: yWriteFreeType (yyt); yyIndentSelector ("Next"); yyt = yyt->FreeType.Next; break;
case kEnum: yWriteEnum (yyt); yyIndentSelector ("Next"); yyt = yyt->Enum.Next; break;
case kImport: yWriteImport (yyt); yyIndentSelector ("Next"); yyt = yyt->Import.Next; break;
case kModuleDecl: yWriteModuleDecl (yyt); yyIndentSelector ("Next"); yyt = yyt->ModuleDecl.Next; break;
case kConstraint: yWriteConstraint (yyt); yyIndentSelector ("Next"); yyt = yyt->Constraint.Next; break;
case kSchemaIncl: yWriteSchemaIncl (yyt); yyIndentSelector ("Next"); yyt = yyt->SchemaIncl.Next; break;
case kVisibility: yWriteVisibility (yyt); yyIndentSelector ("Next"); yyt = yyt->Visibility.Next; break;
case kBranchList: yWriteBranchList (yyt); goto yyExit;
case kNoBranch: yWriteNoBranch (yyt); goto yyExit;
case kBranch: yWriteBranch (yyt); yyIndentSelector ("Next"); yyt = yyt->Branch.Next; break;
case kFTConstant: yWriteFTConstant (yyt); yyIndentSelector ("Next"); yyt = yyt->FTConstant.Next; break;
case kFTConstructor: yWriteFTConstructor (yyt); yyIndentSelector ("Next"); yyt = yyt->FTConstructor.Next; break;
case kSchema: yWriteSchema (yyt); goto yyExit;
case kExpPred: yWriteExpPred (yyt); yyIndentSelector ("Exp"); yyt = yyt->ExpPred.Exp; break;
case kSchemaText: yWriteSchemaText (yyt); yyIndentSelector ("PredList"); yyt = yyt->SchemaText.PredList; break;
case kSchemaRef: yWriteSchemaRef (yyt); yyIndentSelector ("ExpressionList"); yyt = yyt->SchemaRef.ExpressionList; break;
case kSchemaCons: yWriteSchemaCons (yyt); yyIndentSelector ("R"); yyt = yyt->SchemaCons.R; break;
case kSchemaCompos: yWriteSchemaCompos (yyt); yyIndentSelector ("Sch2"); yyt = yyt->SchemaCompos.Sch2; break;
case kSchemaProj: yWriteSchemaProj (yyt); yyIndentSelector ("Sch2"); yyt = yyt->SchemaProj.Sch2; break;
case kSchemaSubst: yWriteSchemaSubst (yyt); yyIndentSelector ("RenameList"); yyt = yyt->SchemaSubst.RenameList; break;
case kSchemaHiding: yWriteSchemaHiding (yyt); yyIndentSelector ("NameList"); yyt = yyt->SchemaHiding.NameList; break;
case kLogOp: (void) fputs (Tree_NodeName [kLogOp], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kSDisjunction: (void) fputs (Tree_NodeName [kSDisjunction], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kSConjunction: (void) fputs (Tree_NodeName [kSConjunction], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kSImplication: (void) fputs (Tree_NodeName [kSImplication], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kSEquivalence: (void) fputs (Tree_NodeName [kSEquivalence], yyf); (void) fputc ('\n', yyf); goto yyExit;
  default: goto yyExit;
  }
 }
yyExit:
 yyIndentLevel = yyLevel;
}

# define yyNil	0374
# define yyNoLabel	0375
# define yyLabelDef	0376
# define yyLabelUse	0377

tTree ReverseTree
# if defined __STDC__ | defined __cplusplus
 (tTree yyOld)
# else
 (yyOld) tTree yyOld;
# endif
{
 register tTree yyNew, yyNext, yyTail;
 yyNew = yyOld;
 yyTail = yyOld;
 for (;;) {
  switch (yyOld->Kind) {
case kModule: yyNext = yyOld->Module.Next; yyOld->Module.Next = yyNew; break;
case kParam: yyNext = yyOld->Param.Next; yyOld->Param.Next = yyNew; break;
case kTyParam: yyNext = yyOld->TyParam.Next; yyOld->TyParam.Next = yyNew; break;
case kFncParam: yyNext = yyOld->FncParam.Next; yyOld->FncParam.Next = yyNew; break;
case kRename: yyNext = yyOld->Rename.Next; yyOld->Rename.Next = yyNew; break;
case kId: yyNext = yyOld->Id.Next; yyOld->Id.Next = yyNew; break;
case kExp: yyNext = yyOld->Exp.Next; yyOld->Exp.Next = yyNew; break;
case kVariable: yyNext = yyOld->Variable.Next; yyOld->Variable.Next = yyNew; break;
case kLiteral: yyNext = yyOld->Literal.Next; yyOld->Literal.Next = yyNew; break;
case kString: yyNext = yyOld->String.Next; yyOld->String.Next = yyNew; break;
case kChar: yyNext = yyOld->Char.Next; yyOld->Char.Next = yyNew; break;
case kPrefixOp: yyNext = yyOld->PrefixOp.Next; yyOld->PrefixOp.Next = yyNew; break;
case kLambda: yyNext = yyOld->Lambda.Next; yyOld->Lambda.Next = yyNew; break;
case kRecDisp: yyNext = yyOld->RecDisp.Next; yyOld->RecDisp.Next = yyNew; break;
case kMu: yyNext = yyOld->Mu.Next; yyOld->Mu.Next = yyNew; break;
case kTupSelection: yyNext = yyOld->TupSelection.Next; yyOld->TupSelection.Next = yyNew; break;
case kVarSelection: yyNext = yyOld->VarSelection.Next; yyOld->VarSelection.Next = yyNew; break;
case kIfExp: yyNext = yyOld->IfExp.Next; yyOld->IfExp.Next = yyNew; break;
case kFncApplication: yyNext = yyOld->FncApplication.Next; yyOld->FncApplication.Next = yyNew; break;
case kSetComp: yyNext = yyOld->SetComp.Next; yyOld->SetComp.Next = yyNew; break;
case kSetElab: yyNext = yyOld->SetElab.Next; yyOld->SetElab.Next = yyNew; break;
case kArrayUpd: yyNext = yyOld->ArrayUpd.Next; yyOld->ArrayUpd.Next = yyNew; break;
case kNamedArrayAgg: yyNext = yyOld->NamedArrayAgg.Next; yyOld->NamedArrayAgg.Next = yyNew; break;
case kSequence: yyNext = yyOld->Sequence.Next; yyOld->Sequence.Next = yyNew; break;
case kBag: yyNext = yyOld->Bag.Next; yyOld->Bag.Next = yyNew; break;
case kCartProd: yyNext = yyOld->CartProd.Next; yyOld->CartProd.Next = yyNew; break;
case kTuple: yyNext = yyOld->Tuple.Next; yyOld->Tuple.Next = yyNew; break;
case kExp_SchemaRef: yyNext = yyOld->Exp_SchemaRef.Next; yyOld->Exp_SchemaRef.Next = yyNew; break;
case kTheta: yyNext = yyOld->Theta.Next; yyOld->Theta.Next = yyNew; break;
case kInfixOp: yyNext = yyOld->InfixOp.Next; yyOld->InfixOp.Next = yyNew; break;
case kPredExp: yyNext = yyOld->PredExp.Next; yyOld->PredExp.Next = yyNew; break;
case kPred: yyNext = yyOld->Pred.Next; yyOld->Pred.Next = yyNew; break;
case kQuantPred: yyNext = yyOld->QuantPred.Next; yyOld->QuantPred.Next = yyNew; break;
case kRelBinPred: yyNext = yyOld->RelBinPred.Next; yyOld->RelBinPred.Next = yyNew; break;
case kAssign: yyNext = yyOld->Assign.Next; yyOld->Assign.Next = yyNew; break;
case kRelPrePred: yyNext = yyOld->RelPrePred.Next; yyOld->RelPrePred.Next = yyNew; break;
case kLogBinPred: yyNext = yyOld->LogBinPred.Next; yyOld->LogBinPred.Next = yyNew; break;
case kLogicalNot: yyNext = yyOld->LogicalNot.Next; yyOld->LogicalNot.Next = yyNew; break;
case kPreCondPred: yyNext = yyOld->PreCondPred.Next; yyOld->PreCondPred.Next = yyNew; break;
case kIfPred: yyNext = yyOld->IfPred.Next; yyOld->IfPred.Next = yyNew; break;
case kWhilePred: yyNext = yyOld->WhilePred.Next; yyOld->WhilePred.Next = yyNew; break;
case kCallPred: yyNext = yyOld->CallPred.Next; yyOld->CallPred.Next = yyNew; break;
case kChgOnly: yyNext = yyOld->ChgOnly.Next; yyOld->ChgOnly.Next = yyNew; break;
case kDefined: yyNext = yyOld->Defined.Next; yyOld->Defined.Next = yyNew; break;
case kSchemaPred: yyNext = yyOld->SchemaPred.Next; yyOld->SchemaPred.Next = yyNew; break;
case kBoolValue: yyNext = yyOld->BoolValue.Next; yyOld->BoolValue.Next = yyNew; break;
case kInputBind: yyNext = yyOld->InputBind.Next; yyOld->InputBind.Next = yyNew; break;
case kOutputBind: yyNext = yyOld->OutputBind.Next; yyOld->OutputBind.Next = yyNew; break;
case kDecl: yyNext = yyOld->Decl.Next; yyOld->Decl.Next = yyNew; break;
case kVarDecl: yyNext = yyOld->VarDecl.Next; yyOld->VarDecl.Next = yyNew; break;
case kGivenSet: yyNext = yyOld->GivenSet.Next; yyOld->GivenSet.Next = yyNew; break;
case kAxiomDecl: yyNext = yyOld->AxiomDecl.Next; yyOld->AxiomDecl.Next = yyNew; break;
case kSchemaDef: yyNext = yyOld->SchemaDef.Next; yyOld->SchemaDef.Next = yyNew; break;
case kAnnotation: yyNext = yyOld->Annotation.Next; yyOld->Annotation.Next = yyNew; break;
case kErgoAnno: yyNext = yyOld->ErgoAnno.Next; yyOld->ErgoAnno.Next = yyNew; break;
case kStateMachine: yyNext = yyOld->StateMachine.Next; yyOld->StateMachine.Next = yyNew; break;
case kAbbreviation: yyNext = yyOld->Abbreviation.Next; yyOld->Abbreviation.Next = yyNew; break;
case kFunctionDecl: yyNext = yyOld->FunctionDecl.Next; yyOld->FunctionDecl.Next = yyNew; break;
case kFreeType: yyNext = yyOld->FreeType.Next; yyOld->FreeType.Next = yyNew; break;
case kEnum: yyNext = yyOld->Enum.Next; yyOld->Enum.Next = yyNew; break;
case kImport: yyNext = yyOld->Import.Next; yyOld->Import.Next = yyNew; break;
case kModuleDecl: yyNext = yyOld->ModuleDecl.Next; yyOld->ModuleDecl.Next = yyNew; break;
case kConstraint: yyNext = yyOld->Constraint.Next; yyOld->Constraint.Next = yyNew; break;
case kSchemaIncl: yyNext = yyOld->SchemaIncl.Next; yyOld->SchemaIncl.Next = yyNew; break;
case kVisibility: yyNext = yyOld->Visibility.Next; yyOld->Visibility.Next = yyNew; break;
case kBranch: yyNext = yyOld->Branch.Next; yyOld->Branch.Next = yyNew; break;
case kFTConstant: yyNext = yyOld->FTConstant.Next; yyOld->FTConstant.Next = yyNew; break;
case kFTConstructor: yyNext = yyOld->FTConstructor.Next; yyOld->FTConstructor.Next = yyNew; break;
  default: goto yyExit;
  }
  yyNew = yyOld;
  yyOld = yyNext;
 }
yyExit:
 switch (yyTail->Kind) {
case kModule: yyTail->Module.Next = yyOld; break;
case kParam: yyTail->Param.Next = yyOld; break;
case kTyParam: yyTail->TyParam.Next = yyOld; break;
case kFncParam: yyTail->FncParam.Next = yyOld; break;
case kRename: yyTail->Rename.Next = yyOld; break;
case kId: yyTail->Id.Next = yyOld; break;
case kExp: yyTail->Exp.Next = yyOld; break;
case kVariable: yyTail->Variable.Next = yyOld; break;
case kLiteral: yyTail->Literal.Next = yyOld; break;
case kString: yyTail->String.Next = yyOld; break;
case kChar: yyTail->Char.Next = yyOld; break;
case kPrefixOp: yyTail->PrefixOp.Next = yyOld; break;
case kLambda: yyTail->Lambda.Next = yyOld; break;
case kRecDisp: yyTail->RecDisp.Next = yyOld; break;
case kMu: yyTail->Mu.Next = yyOld; break;
case kTupSelection: yyTail->TupSelection.Next = yyOld; break;
case kVarSelection: yyTail->VarSelection.Next = yyOld; break;
case kIfExp: yyTail->IfExp.Next = yyOld; break;
case kFncApplication: yyTail->FncApplication.Next = yyOld; break;
case kSetComp: yyTail->SetComp.Next = yyOld; break;
case kSetElab: yyTail->SetElab.Next = yyOld; break;
case kArrayUpd: yyTail->ArrayUpd.Next = yyOld; break;
case kNamedArrayAgg: yyTail->NamedArrayAgg.Next = yyOld; break;
case kSequence: yyTail->Sequence.Next = yyOld; break;
case kBag: yyTail->Bag.Next = yyOld; break;
case kCartProd: yyTail->CartProd.Next = yyOld; break;
case kTuple: yyTail->Tuple.Next = yyOld; break;
case kExp_SchemaRef: yyTail->Exp_SchemaRef.Next = yyOld; break;
case kTheta: yyTail->Theta.Next = yyOld; break;
case kInfixOp: yyTail->InfixOp.Next = yyOld; break;
case kPredExp: yyTail->PredExp.Next = yyOld; break;
case kPred: yyTail->Pred.Next = yyOld; break;
case kQuantPred: yyTail->QuantPred.Next = yyOld; break;
case kRelBinPred: yyTail->RelBinPred.Next = yyOld; break;
case kAssign: yyTail->Assign.Next = yyOld; break;
case kRelPrePred: yyTail->RelPrePred.Next = yyOld; break;
case kLogBinPred: yyTail->LogBinPred.Next = yyOld; break;
case kLogicalNot: yyTail->LogicalNot.Next = yyOld; break;
case kPreCondPred: yyTail->PreCondPred.Next = yyOld; break;
case kIfPred: yyTail->IfPred.Next = yyOld; break;
case kWhilePred: yyTail->WhilePred.Next = yyOld; break;
case kCallPred: yyTail->CallPred.Next = yyOld; break;
case kChgOnly: yyTail->ChgOnly.Next = yyOld; break;
case kDefined: yyTail->Defined.Next = yyOld; break;
case kSchemaPred: yyTail->SchemaPred.Next = yyOld; break;
case kBoolValue: yyTail->BoolValue.Next = yyOld; break;
case kInputBind: yyTail->InputBind.Next = yyOld; break;
case kOutputBind: yyTail->OutputBind.Next = yyOld; break;
case kDecl: yyTail->Decl.Next = yyOld; break;
case kVarDecl: yyTail->VarDecl.Next = yyOld; break;
case kGivenSet: yyTail->GivenSet.Next = yyOld; break;
case kAxiomDecl: yyTail->AxiomDecl.Next = yyOld; break;
case kSchemaDef: yyTail->SchemaDef.Next = yyOld; break;
case kAnnotation: yyTail->Annotation.Next = yyOld; break;
case kErgoAnno: yyTail->ErgoAnno.Next = yyOld; break;
case kStateMachine: yyTail->StateMachine.Next = yyOld; break;
case kAbbreviation: yyTail->Abbreviation.Next = yyOld; break;
case kFunctionDecl: yyTail->FunctionDecl.Next = yyOld; break;
case kFreeType: yyTail->FreeType.Next = yyOld; break;
case kEnum: yyTail->Enum.Next = yyOld; break;
case kImport: yyTail->Import.Next = yyOld; break;
case kModuleDecl: yyTail->ModuleDecl.Next = yyOld; break;
case kConstraint: yyTail->Constraint.Next = yyOld; break;
case kSchemaIncl: yyTail->SchemaIncl.Next = yyOld; break;
case kVisibility: yyTail->Visibility.Next = yyOld; break;
case kBranch: yyTail->Branch.Next = yyOld; break;
case kFTConstant: yyTail->FTConstant.Next = yyOld; break;
case kFTConstructor: yyTail->FTConstructor.Next = yyOld; break;
 default: ;
 }
 return yyNew;
}

# define yyInitOldToNewStoreSize 32

typedef struct { tTree yyOld, yyNew; } yytOldToNew;
static unsigned long yyOldToNewStoreSize = yyInitOldToNewStoreSize;
static yytOldToNew yyOldToNewStore [yyInitOldToNewStoreSize];
static yytOldToNew * yyOldToNewStorePtr = yyOldToNewStore;
static int yyOldToNewCount;

static void yyStoreOldToNew
# if defined __STDC__ | defined __cplusplus
 (tTree yyOld, tTree yyNew)
# else
 (yyOld, yyNew) tTree yyOld, yyNew;
# endif
{
 if (++ yyOldToNewCount == yyOldToNewStoreSize)
  ExtendArray ((char * *) & yyOldToNewStorePtr, & yyOldToNewStoreSize, sizeof (yytOldToNew));
 yyOldToNewStorePtr [yyOldToNewCount].yyOld = yyOld;
 yyOldToNewStorePtr [yyOldToNewCount].yyNew = yyNew;
}

static tTree yyMapOldToNew
# if defined __STDC__ | defined __cplusplus
 (tTree yyOld)
# else
 (yyOld) tTree yyOld;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyOldToNewCount; yyi ++)
  if (yyOldToNewStorePtr [yyi].yyOld == yyOld) return yyOldToNewStorePtr [yyi].yyNew;
}

static tTree yyCopyTree
# if defined __STDC__ | defined __cplusplus
 (tTree yyt, yyPtrtTree yyNew)
# else
 (yyt, yyNew) tTree yyt; yyPtrtTree yyNew;
# endif
{
 for (;;) {
  if (yyt == NoTree) { * yyNew = NoTree; return; }
  if (yyt->yyHead.yyMark == 0) { * yyNew = yyMapOldToNew (yyt); return; }
  yyALLOC (* yyNew, Tree_NodeSize [yyt->Kind])
  if (yyt->yyHead.yyMark > 1) { yyStoreOldToNew (yyt, * yyNew); }
  yyt->yyHead.yyMark = 0;

  switch (yyt->Kind) {
case kSum: (* yyNew)->Sum = yyt->Sum;
yyt = yyt->Sum.ModuleList;
yyNew = & (* yyNew)->Sum.ModuleList; break;
case kModuleList: (* yyNew)->ModuleList = yyt->ModuleList;
copytPosition ((* yyNew)->ModuleList.Pos, yyt->ModuleList.Pos)
copytObjects ((* yyNew)->ModuleList.DeclsIn, yyt->ModuleList.DeclsIn)
copytObjects ((* yyNew)->ModuleList.DeclsOut, yyt->ModuleList.DeclsOut)
return;
case kNoModule: (* yyNew)->NoModule = yyt->NoModule;
copytPosition ((* yyNew)->NoModule.Pos, yyt->NoModule.Pos)
copytObjects ((* yyNew)->NoModule.DeclsIn, yyt->NoModule.DeclsIn)
copytObjects ((* yyNew)->NoModule.DeclsOut, yyt->NoModule.DeclsOut)
return;
case kModule: (* yyNew)->Module = yyt->Module;
copytPosition ((* yyNew)->Module.Pos, yyt->Module.Pos)
copytObjects ((* yyNew)->Module.DeclsIn, yyt->Module.DeclsIn)
copytObjects ((* yyNew)->Module.DeclsOut, yyt->Module.DeclsOut)
copytIdPos ((* yyNew)->Module.Ident, yyt->Module.Ident)
copytTree ((* yyNew)->Module.FormalParams, yyt->Module.FormalParams)
copytTree ((* yyNew)->Module.PredList, yyt->Module.PredList)
copytTree ((* yyNew)->Module.DeclList, yyt->Module.DeclList)
copybool ((* yyNew)->Module.IsNested, yyt->Module.IsNested)
yyt = yyt->Module.Next;
yyNew = & (* yyNew)->Module.Next; break;
case kFormalParams: (* yyNew)->FormalParams = yyt->FormalParams;
copytPosition ((* yyNew)->FormalParams.Pos, yyt->FormalParams.Pos)
copytObjects ((* yyNew)->FormalParams.DeclsIn, yyt->FormalParams.DeclsIn)
copytObjects ((* yyNew)->FormalParams.DeclsOut, yyt->FormalParams.DeclsOut)
return;
case kNoParam: (* yyNew)->NoParam = yyt->NoParam;
copytPosition ((* yyNew)->NoParam.Pos, yyt->NoParam.Pos)
copytObjects ((* yyNew)->NoParam.DeclsIn, yyt->NoParam.DeclsIn)
copytObjects ((* yyNew)->NoParam.DeclsOut, yyt->NoParam.DeclsOut)
return;
case kParam: (* yyNew)->Param = yyt->Param;
copytPosition ((* yyNew)->Param.Pos, yyt->Param.Pos)
copytObjects ((* yyNew)->Param.DeclsIn, yyt->Param.DeclsIn)
copytObjects ((* yyNew)->Param.DeclsOut, yyt->Param.DeclsOut)
yyt = yyt->Param.Next;
yyNew = & (* yyNew)->Param.Next; break;
case kTyParam: (* yyNew)->TyParam = yyt->TyParam;
copytPosition ((* yyNew)->TyParam.Pos, yyt->TyParam.Pos)
copytObjects ((* yyNew)->TyParam.DeclsIn, yyt->TyParam.DeclsIn)
copytObjects ((* yyNew)->TyParam.DeclsOut, yyt->TyParam.DeclsOut)
copytIdPos ((* yyNew)->TyParam.Ident, yyt->TyParam.Ident)
copybool ((* yyNew)->TyParam.IsPolyTy, yyt->TyParam.IsPolyTy)
yyt = yyt->TyParam.Next;
yyNew = & (* yyNew)->TyParam.Next; break;
case kFncParam: (* yyNew)->FncParam = yyt->FncParam;
copytPosition ((* yyNew)->FncParam.Pos, yyt->FncParam.Pos)
copytObjects ((* yyNew)->FncParam.DeclsIn, yyt->FncParam.DeclsIn)
copytObjects ((* yyNew)->FncParam.DeclsOut, yyt->FncParam.DeclsOut)
copytTree ((* yyNew)->FncParam.VarDecl, yyt->FncParam.VarDecl)
yyt = yyt->FncParam.Next;
yyNew = & (* yyNew)->FncParam.Next; break;
case kRenameList: (* yyNew)->RenameList = yyt->RenameList;
copytObjects ((* yyNew)->RenameList.DeclsIn, yyt->RenameList.DeclsIn)
copytObjects ((* yyNew)->RenameList.DeclsOut, yyt->RenameList.DeclsOut)
return;
case kNoRename: (* yyNew)->NoRename = yyt->NoRename;
copytObjects ((* yyNew)->NoRename.DeclsIn, yyt->NoRename.DeclsIn)
copytObjects ((* yyNew)->NoRename.DeclsOut, yyt->NoRename.DeclsOut)
return;
case kRename: (* yyNew)->Rename = yyt->Rename;
copytObjects ((* yyNew)->Rename.DeclsIn, yyt->Rename.DeclsIn)
copytObjects ((* yyNew)->Rename.DeclsOut, yyt->Rename.DeclsOut)
copytIdPos ((* yyNew)->Rename.NewIdent, yyt->Rename.NewIdent)
copytTree ((* yyNew)->Rename.OldIdent, yyt->Rename.OldIdent)
yyt = yyt->Rename.Next;
yyNew = & (* yyNew)->Rename.Next; break;
case kSelectionList: (* yyNew)->SelectionList = yyt->SelectionList;
return;
case kNoSelection: (* yyNew)->NoSelection = yyt->NoSelection;
return;
case kSelection: (* yyNew)->Selection = yyt->Selection;
copytIdPos ((* yyNew)->Selection.Ident, yyt->Selection.Ident)
yyt = yyt->Selection.Next;
yyNew = & (* yyNew)->Selection.Next; break;
case kIdList: (* yyNew)->IdList = yyt->IdList;
copytPosition ((* yyNew)->IdList.Pos, yyt->IdList.Pos)
copytObjects ((* yyNew)->IdList.DeclsIn, yyt->IdList.DeclsIn)
copytObjects ((* yyNew)->IdList.DeclsOut, yyt->IdList.DeclsOut)
return;
case kNoId: (* yyNew)->NoId = yyt->NoId;
copytPosition ((* yyNew)->NoId.Pos, yyt->NoId.Pos)
copytObjects ((* yyNew)->NoId.DeclsIn, yyt->NoId.DeclsIn)
copytObjects ((* yyNew)->NoId.DeclsOut, yyt->NoId.DeclsOut)
return;
case kId: (* yyNew)->Id = yyt->Id;
copytPosition ((* yyNew)->Id.Pos, yyt->Id.Pos)
copytObjects ((* yyNew)->Id.DeclsIn, yyt->Id.DeclsIn)
copytObjects ((* yyNew)->Id.DeclsOut, yyt->Id.DeclsOut)
copytIdPos ((* yyNew)->Id.Ident, yyt->Id.Ident)
copyint ((* yyNew)->Id.IdKind, yyt->Id.IdKind)
yyt = yyt->Id.Next;
yyNew = & (* yyNew)->Id.Next; break;
case kNameList: (* yyNew)->NameList = yyt->NameList;
copytPosition ((* yyNew)->NameList.Pos, yyt->NameList.Pos)
copytObjects ((* yyNew)->NameList.DeclsIn, yyt->NameList.DeclsIn)
copytObjects ((* yyNew)->NameList.DeclsOut, yyt->NameList.DeclsOut)
return;
case kNoName: (* yyNew)->NoName = yyt->NoName;
copytPosition ((* yyNew)->NoName.Pos, yyt->NoName.Pos)
copytObjects ((* yyNew)->NoName.DeclsIn, yyt->NoName.DeclsIn)
copytObjects ((* yyNew)->NoName.DeclsOut, yyt->NoName.DeclsOut)
return;
case kName: (* yyNew)->Name = yyt->Name;
copytPosition ((* yyNew)->Name.Pos, yyt->Name.Pos)
copytObjects ((* yyNew)->Name.DeclsIn, yyt->Name.DeclsIn)
copytObjects ((* yyNew)->Name.DeclsOut, yyt->Name.DeclsOut)
copytTree ((* yyNew)->Name.Next, yyt->Name.Next)
yyt = yyt->Name.IdList;
yyNew = & (* yyNew)->Name.IdList; break;
case kExpressionList: (* yyNew)->ExpressionList = yyt->ExpressionList;
copytPosition ((* yyNew)->ExpressionList.Pos, yyt->ExpressionList.Pos)
copybool ((* yyNew)->ExpressionList.IsTypeExp, yyt->ExpressionList.IsTypeExp)
copytObjects ((* yyNew)->ExpressionList.DeclsIn, yyt->ExpressionList.DeclsIn)
copytObjects ((* yyNew)->ExpressionList.DeclsOut, yyt->ExpressionList.DeclsOut)
copytType ((* yyNew)->ExpressionList.Type, yyt->ExpressionList.Type)
return;
case kNoExp: (* yyNew)->NoExp = yyt->NoExp;
copytPosition ((* yyNew)->NoExp.Pos, yyt->NoExp.Pos)
copybool ((* yyNew)->NoExp.IsTypeExp, yyt->NoExp.IsTypeExp)
copytObjects ((* yyNew)->NoExp.DeclsIn, yyt->NoExp.DeclsIn)
copytObjects ((* yyNew)->NoExp.DeclsOut, yyt->NoExp.DeclsOut)
copytType ((* yyNew)->NoExp.Type, yyt->NoExp.Type)
return;
case kExp: (* yyNew)->Exp = yyt->Exp;
copytPosition ((* yyNew)->Exp.Pos, yyt->Exp.Pos)
copybool ((* yyNew)->Exp.IsTypeExp, yyt->Exp.IsTypeExp)
copytObjects ((* yyNew)->Exp.DeclsIn, yyt->Exp.DeclsIn)
copytObjects ((* yyNew)->Exp.DeclsOut, yyt->Exp.DeclsOut)
copytType ((* yyNew)->Exp.Type, yyt->Exp.Type)
yyt = yyt->Exp.Next;
yyNew = & (* yyNew)->Exp.Next; break;
case kVariable: (* yyNew)->Variable = yyt->Variable;
copytPosition ((* yyNew)->Variable.Pos, yyt->Variable.Pos)
copybool ((* yyNew)->Variable.IsTypeExp, yyt->Variable.IsTypeExp)
copytObjects ((* yyNew)->Variable.DeclsIn, yyt->Variable.DeclsIn)
copytObjects ((* yyNew)->Variable.DeclsOut, yyt->Variable.DeclsOut)
copytType ((* yyNew)->Variable.Type, yyt->Variable.Type)
copytTree ((* yyNew)->Variable.IdList, yyt->Variable.IdList)
copytObjects ((* yyNew)->Variable.SymPtr, yyt->Variable.SymPtr)
copybool ((* yyNew)->Variable.IsBinding, yyt->Variable.IsBinding)
yyt = yyt->Variable.Next;
yyNew = & (* yyNew)->Variable.Next; break;
case kLiteral: (* yyNew)->Literal = yyt->Literal;
copytPosition ((* yyNew)->Literal.Pos, yyt->Literal.Pos)
copybool ((* yyNew)->Literal.IsTypeExp, yyt->Literal.IsTypeExp)
copytObjects ((* yyNew)->Literal.DeclsIn, yyt->Literal.DeclsIn)
copytObjects ((* yyNew)->Literal.DeclsOut, yyt->Literal.DeclsOut)
copytType ((* yyNew)->Literal.Type, yyt->Literal.Type)
copytIdPos ((* yyNew)->Literal.Literal, yyt->Literal.Literal)
yyt = yyt->Literal.Next;
yyNew = & (* yyNew)->Literal.Next; break;
case kString: (* yyNew)->String = yyt->String;
copytPosition ((* yyNew)->String.Pos, yyt->String.Pos)
copybool ((* yyNew)->String.IsTypeExp, yyt->String.IsTypeExp)
copytObjects ((* yyNew)->String.DeclsIn, yyt->String.DeclsIn)
copytObjects ((* yyNew)->String.DeclsOut, yyt->String.DeclsOut)
copytType ((* yyNew)->String.Type, yyt->String.Type)
copytIdPos ((* yyNew)->String.String, yyt->String.String)
yyt = yyt->String.Next;
yyNew = & (* yyNew)->String.Next; break;
case kChar: (* yyNew)->Char = yyt->Char;
copytPosition ((* yyNew)->Char.Pos, yyt->Char.Pos)
copybool ((* yyNew)->Char.IsTypeExp, yyt->Char.IsTypeExp)
copytObjects ((* yyNew)->Char.DeclsIn, yyt->Char.DeclsIn)
copytObjects ((* yyNew)->Char.DeclsOut, yyt->Char.DeclsOut)
copytType ((* yyNew)->Char.Type, yyt->Char.Type)
copytIdPos ((* yyNew)->Char.Char, yyt->Char.Char)
yyt = yyt->Char.Next;
yyNew = & (* yyNew)->Char.Next; break;
case kPrefixOp: (* yyNew)->PrefixOp = yyt->PrefixOp;
copytPosition ((* yyNew)->PrefixOp.Pos, yyt->PrefixOp.Pos)
copybool ((* yyNew)->PrefixOp.IsTypeExp, yyt->PrefixOp.IsTypeExp)
copytObjects ((* yyNew)->PrefixOp.DeclsIn, yyt->PrefixOp.DeclsIn)
copytObjects ((* yyNew)->PrefixOp.DeclsOut, yyt->PrefixOp.DeclsOut)
copytType ((* yyNew)->PrefixOp.Type, yyt->PrefixOp.Type)
copytIdPos ((* yyNew)->PrefixOp.Prefix, yyt->PrefixOp.Prefix)
copytTree ((* yyNew)->PrefixOp.Exp, yyt->PrefixOp.Exp)
yyt = yyt->PrefixOp.Next;
yyNew = & (* yyNew)->PrefixOp.Next; break;
case kLambda: (* yyNew)->Lambda = yyt->Lambda;
copytPosition ((* yyNew)->Lambda.Pos, yyt->Lambda.Pos)
copybool ((* yyNew)->Lambda.IsTypeExp, yyt->Lambda.IsTypeExp)
copytObjects ((* yyNew)->Lambda.DeclsIn, yyt->Lambda.DeclsIn)
copytObjects ((* yyNew)->Lambda.DeclsOut, yyt->Lambda.DeclsOut)
copytType ((* yyNew)->Lambda.Type, yyt->Lambda.Type)
copytTree ((* yyNew)->Lambda.SchemaText, yyt->Lambda.SchemaText)
copytTree ((* yyNew)->Lambda.Exp, yyt->Lambda.Exp)
yyt = yyt->Lambda.Next;
yyNew = & (* yyNew)->Lambda.Next; break;
case kRecDisp: (* yyNew)->RecDisp = yyt->RecDisp;
copytPosition ((* yyNew)->RecDisp.Pos, yyt->RecDisp.Pos)
copybool ((* yyNew)->RecDisp.IsTypeExp, yyt->RecDisp.IsTypeExp)
copytObjects ((* yyNew)->RecDisp.DeclsIn, yyt->RecDisp.DeclsIn)
copytObjects ((* yyNew)->RecDisp.DeclsOut, yyt->RecDisp.DeclsOut)
copytType ((* yyNew)->RecDisp.Type, yyt->RecDisp.Type)
copytTree ((* yyNew)->RecDisp.SchemaText, yyt->RecDisp.SchemaText)
copytTree ((* yyNew)->RecDisp.PredList, yyt->RecDisp.PredList)
yyt = yyt->RecDisp.Next;
yyNew = & (* yyNew)->RecDisp.Next; break;
case kMu: (* yyNew)->Mu = yyt->Mu;
copytPosition ((* yyNew)->Mu.Pos, yyt->Mu.Pos)
copybool ((* yyNew)->Mu.IsTypeExp, yyt->Mu.IsTypeExp)
copytObjects ((* yyNew)->Mu.DeclsIn, yyt->Mu.DeclsIn)
copytObjects ((* yyNew)->Mu.DeclsOut, yyt->Mu.DeclsOut)
copytType ((* yyNew)->Mu.Type, yyt->Mu.Type)
copytTree ((* yyNew)->Mu.SchemaText, yyt->Mu.SchemaText)
copytTree ((* yyNew)->Mu.ExpressionList, yyt->Mu.ExpressionList)
yyt = yyt->Mu.Next;
yyNew = & (* yyNew)->Mu.Next; break;
case kTupSelection: (* yyNew)->TupSelection = yyt->TupSelection;
copytPosition ((* yyNew)->TupSelection.Pos, yyt->TupSelection.Pos)
copybool ((* yyNew)->TupSelection.IsTypeExp, yyt->TupSelection.IsTypeExp)
copytObjects ((* yyNew)->TupSelection.DeclsIn, yyt->TupSelection.DeclsIn)
copytObjects ((* yyNew)->TupSelection.DeclsOut, yyt->TupSelection.DeclsOut)
copytType ((* yyNew)->TupSelection.Type, yyt->TupSelection.Type)
copytTree ((* yyNew)->TupSelection.Exp, yyt->TupSelection.Exp)
copytIdPos ((* yyNew)->TupSelection.Number, yyt->TupSelection.Number)
yyt = yyt->TupSelection.Next;
yyNew = & (* yyNew)->TupSelection.Next; break;
case kVarSelection: (* yyNew)->VarSelection = yyt->VarSelection;
copytPosition ((* yyNew)->VarSelection.Pos, yyt->VarSelection.Pos)
copybool ((* yyNew)->VarSelection.IsTypeExp, yyt->VarSelection.IsTypeExp)
copytObjects ((* yyNew)->VarSelection.DeclsIn, yyt->VarSelection.DeclsIn)
copytObjects ((* yyNew)->VarSelection.DeclsOut, yyt->VarSelection.DeclsOut)
copytType ((* yyNew)->VarSelection.Type, yyt->VarSelection.Type)
copytTree ((* yyNew)->VarSelection.Exp, yyt->VarSelection.Exp)
copytIdPos ((* yyNew)->VarSelection.Ident, yyt->VarSelection.Ident)
yyt = yyt->VarSelection.Next;
yyNew = & (* yyNew)->VarSelection.Next; break;
case kIfExp: (* yyNew)->IfExp = yyt->IfExp;
copytPosition ((* yyNew)->IfExp.Pos, yyt->IfExp.Pos)
copybool ((* yyNew)->IfExp.IsTypeExp, yyt->IfExp.IsTypeExp)
copytObjects ((* yyNew)->IfExp.DeclsIn, yyt->IfExp.DeclsIn)
copytObjects ((* yyNew)->IfExp.DeclsOut, yyt->IfExp.DeclsOut)
copytType ((* yyNew)->IfExp.Type, yyt->IfExp.Type)
copytTree ((* yyNew)->IfExp.Con, yyt->IfExp.Con)
copytTree ((* yyNew)->IfExp.Then, yyt->IfExp.Then)
copytTree ((* yyNew)->IfExp.Else, yyt->IfExp.Else)
yyt = yyt->IfExp.Next;
yyNew = & (* yyNew)->IfExp.Next; break;
case kFncApplication: (* yyNew)->FncApplication = yyt->FncApplication;
copytPosition ((* yyNew)->FncApplication.Pos, yyt->FncApplication.Pos)
copybool ((* yyNew)->FncApplication.IsTypeExp, yyt->FncApplication.IsTypeExp)
copytObjects ((* yyNew)->FncApplication.DeclsIn, yyt->FncApplication.DeclsIn)
copytObjects ((* yyNew)->FncApplication.DeclsOut, yyt->FncApplication.DeclsOut)
copytType ((* yyNew)->FncApplication.Type, yyt->FncApplication.Type)
copytTree ((* yyNew)->FncApplication.Fnc, yyt->FncApplication.Fnc)
copytTree ((* yyNew)->FncApplication.Arg, yyt->FncApplication.Arg)
yyt = yyt->FncApplication.Next;
yyNew = & (* yyNew)->FncApplication.Next; break;
case kSetComp: (* yyNew)->SetComp = yyt->SetComp;
copytPosition ((* yyNew)->SetComp.Pos, yyt->SetComp.Pos)
copybool ((* yyNew)->SetComp.IsTypeExp, yyt->SetComp.IsTypeExp)
copytObjects ((* yyNew)->SetComp.DeclsIn, yyt->SetComp.DeclsIn)
copytObjects ((* yyNew)->SetComp.DeclsOut, yyt->SetComp.DeclsOut)
copytType ((* yyNew)->SetComp.Type, yyt->SetComp.Type)
copytTree ((* yyNew)->SetComp.SchemaText, yyt->SetComp.SchemaText)
copytTree ((* yyNew)->SetComp.ExpressionList, yyt->SetComp.ExpressionList)
yyt = yyt->SetComp.Next;
yyNew = & (* yyNew)->SetComp.Next; break;
case kSetElab: (* yyNew)->SetElab = yyt->SetElab;
copytPosition ((* yyNew)->SetElab.Pos, yyt->SetElab.Pos)
copybool ((* yyNew)->SetElab.IsTypeExp, yyt->SetElab.IsTypeExp)
copytObjects ((* yyNew)->SetElab.DeclsIn, yyt->SetElab.DeclsIn)
copytObjects ((* yyNew)->SetElab.DeclsOut, yyt->SetElab.DeclsOut)
copytType ((* yyNew)->SetElab.Type, yyt->SetElab.Type)
copytTree ((* yyNew)->SetElab.ExpressionList, yyt->SetElab.ExpressionList)
yyt = yyt->SetElab.Next;
yyNew = & (* yyNew)->SetElab.Next; break;
case kArrayUpd: (* yyNew)->ArrayUpd = yyt->ArrayUpd;
copytPosition ((* yyNew)->ArrayUpd.Pos, yyt->ArrayUpd.Pos)
copybool ((* yyNew)->ArrayUpd.IsTypeExp, yyt->ArrayUpd.IsTypeExp)
copytObjects ((* yyNew)->ArrayUpd.DeclsIn, yyt->ArrayUpd.DeclsIn)
copytObjects ((* yyNew)->ArrayUpd.DeclsOut, yyt->ArrayUpd.DeclsOut)
copytType ((* yyNew)->ArrayUpd.Type, yyt->ArrayUpd.Type)
copytTree ((* yyNew)->ArrayUpd.Array, yyt->ArrayUpd.Array)
copytTree ((* yyNew)->ArrayUpd.Index, yyt->ArrayUpd.Index)
copytTree ((* yyNew)->ArrayUpd.Value, yyt->ArrayUpd.Value)
yyt = yyt->ArrayUpd.Next;
yyNew = & (* yyNew)->ArrayUpd.Next; break;
case kNamedArrayAgg: (* yyNew)->NamedArrayAgg = yyt->NamedArrayAgg;
copytPosition ((* yyNew)->NamedArrayAgg.Pos, yyt->NamedArrayAgg.Pos)
copybool ((* yyNew)->NamedArrayAgg.IsTypeExp, yyt->NamedArrayAgg.IsTypeExp)
copytObjects ((* yyNew)->NamedArrayAgg.DeclsIn, yyt->NamedArrayAgg.DeclsIn)
copytObjects ((* yyNew)->NamedArrayAgg.DeclsOut, yyt->NamedArrayAgg.DeclsOut)
copytType ((* yyNew)->NamedArrayAgg.Type, yyt->NamedArrayAgg.Type)
copytTree ((* yyNew)->NamedArrayAgg.ExpressionList, yyt->NamedArrayAgg.ExpressionList)
yyt = yyt->NamedArrayAgg.Next;
yyNew = & (* yyNew)->NamedArrayAgg.Next; break;
case kSequence: (* yyNew)->Sequence = yyt->Sequence;
copytPosition ((* yyNew)->Sequence.Pos, yyt->Sequence.Pos)
copybool ((* yyNew)->Sequence.IsTypeExp, yyt->Sequence.IsTypeExp)
copytObjects ((* yyNew)->Sequence.DeclsIn, yyt->Sequence.DeclsIn)
copytObjects ((* yyNew)->Sequence.DeclsOut, yyt->Sequence.DeclsOut)
copytType ((* yyNew)->Sequence.Type, yyt->Sequence.Type)
copytTree ((* yyNew)->Sequence.ExpressionList, yyt->Sequence.ExpressionList)
yyt = yyt->Sequence.Next;
yyNew = & (* yyNew)->Sequence.Next; break;
case kBag: (* yyNew)->Bag = yyt->Bag;
copytPosition ((* yyNew)->Bag.Pos, yyt->Bag.Pos)
copybool ((* yyNew)->Bag.IsTypeExp, yyt->Bag.IsTypeExp)
copytObjects ((* yyNew)->Bag.DeclsIn, yyt->Bag.DeclsIn)
copytObjects ((* yyNew)->Bag.DeclsOut, yyt->Bag.DeclsOut)
copytType ((* yyNew)->Bag.Type, yyt->Bag.Type)
copytTree ((* yyNew)->Bag.ExpressionList, yyt->Bag.ExpressionList)
yyt = yyt->Bag.Next;
yyNew = & (* yyNew)->Bag.Next; break;
case kCartProd: (* yyNew)->CartProd = yyt->CartProd;
copytPosition ((* yyNew)->CartProd.Pos, yyt->CartProd.Pos)
copybool ((* yyNew)->CartProd.IsTypeExp, yyt->CartProd.IsTypeExp)
copytObjects ((* yyNew)->CartProd.DeclsIn, yyt->CartProd.DeclsIn)
copytObjects ((* yyNew)->CartProd.DeclsOut, yyt->CartProd.DeclsOut)
copytType ((* yyNew)->CartProd.Type, yyt->CartProd.Type)
copytTree ((* yyNew)->CartProd.ExpressionList, yyt->CartProd.ExpressionList)
yyt = yyt->CartProd.Next;
yyNew = & (* yyNew)->CartProd.Next; break;
case kTuple: (* yyNew)->Tuple = yyt->Tuple;
copytPosition ((* yyNew)->Tuple.Pos, yyt->Tuple.Pos)
copybool ((* yyNew)->Tuple.IsTypeExp, yyt->Tuple.IsTypeExp)
copytObjects ((* yyNew)->Tuple.DeclsIn, yyt->Tuple.DeclsIn)
copytObjects ((* yyNew)->Tuple.DeclsOut, yyt->Tuple.DeclsOut)
copytType ((* yyNew)->Tuple.Type, yyt->Tuple.Type)
copytTree ((* yyNew)->Tuple.ExpressionList, yyt->Tuple.ExpressionList)
yyt = yyt->Tuple.Next;
yyNew = & (* yyNew)->Tuple.Next; break;
case kExp_SchemaRef: (* yyNew)->Exp_SchemaRef = yyt->Exp_SchemaRef;
copytPosition ((* yyNew)->Exp_SchemaRef.Pos, yyt->Exp_SchemaRef.Pos)
copybool ((* yyNew)->Exp_SchemaRef.IsTypeExp, yyt->Exp_SchemaRef.IsTypeExp)
copytObjects ((* yyNew)->Exp_SchemaRef.DeclsIn, yyt->Exp_SchemaRef.DeclsIn)
copytObjects ((* yyNew)->Exp_SchemaRef.DeclsOut, yyt->Exp_SchemaRef.DeclsOut)
copytType ((* yyNew)->Exp_SchemaRef.Type, yyt->Exp_SchemaRef.Type)
copytTree ((* yyNew)->Exp_SchemaRef.IdList, yyt->Exp_SchemaRef.IdList)
copytTree ((* yyNew)->Exp_SchemaRef.ExpressionList, yyt->Exp_SchemaRef.ExpressionList)
yyt = yyt->Exp_SchemaRef.Next;
yyNew = & (* yyNew)->Exp_SchemaRef.Next; break;
case kTheta: (* yyNew)->Theta = yyt->Theta;
copytPosition ((* yyNew)->Theta.Pos, yyt->Theta.Pos)
copybool ((* yyNew)->Theta.IsTypeExp, yyt->Theta.IsTypeExp)
copytObjects ((* yyNew)->Theta.DeclsIn, yyt->Theta.DeclsIn)
copytObjects ((* yyNew)->Theta.DeclsOut, yyt->Theta.DeclsOut)
copytType ((* yyNew)->Theta.Type, yyt->Theta.Type)
copytTree ((* yyNew)->Theta.Exp, yyt->Theta.Exp)
yyt = yyt->Theta.Next;
yyNew = & (* yyNew)->Theta.Next; break;
case kInfixOp: (* yyNew)->InfixOp = yyt->InfixOp;
copytPosition ((* yyNew)->InfixOp.Pos, yyt->InfixOp.Pos)
copybool ((* yyNew)->InfixOp.IsTypeExp, yyt->InfixOp.IsTypeExp)
copytObjects ((* yyNew)->InfixOp.DeclsIn, yyt->InfixOp.DeclsIn)
copytObjects ((* yyNew)->InfixOp.DeclsOut, yyt->InfixOp.DeclsOut)
copytType ((* yyNew)->InfixOp.Type, yyt->InfixOp.Type)
copytTree ((* yyNew)->InfixOp.Op1, yyt->InfixOp.Op1)
copytIdPos ((* yyNew)->InfixOp.Infix, yyt->InfixOp.Infix)
copytTree ((* yyNew)->InfixOp.Op2, yyt->InfixOp.Op2)
yyt = yyt->InfixOp.Next;
yyNew = & (* yyNew)->InfixOp.Next; break;
case kPredExp: (* yyNew)->PredExp = yyt->PredExp;
copytPosition ((* yyNew)->PredExp.Pos, yyt->PredExp.Pos)
copybool ((* yyNew)->PredExp.IsTypeExp, yyt->PredExp.IsTypeExp)
copytObjects ((* yyNew)->PredExp.DeclsIn, yyt->PredExp.DeclsIn)
copytObjects ((* yyNew)->PredExp.DeclsOut, yyt->PredExp.DeclsOut)
copytType ((* yyNew)->PredExp.Type, yyt->PredExp.Type)
copytTree ((* yyNew)->PredExp.Pred, yyt->PredExp.Pred)
yyt = yyt->PredExp.Next;
yyNew = & (* yyNew)->PredExp.Next; break;
case kPredList: (* yyNew)->PredList = yyt->PredList;
copytPosition ((* yyNew)->PredList.Pos, yyt->PredList.Pos)
copybool ((* yyNew)->PredList.IsTypeExp, yyt->PredList.IsTypeExp)
copytObjects ((* yyNew)->PredList.DeclsIn, yyt->PredList.DeclsIn)
copytObjects ((* yyNew)->PredList.DeclsOut, yyt->PredList.DeclsOut)
copytType ((* yyNew)->PredList.Type, yyt->PredList.Type)
return;
case kNoPred: (* yyNew)->NoPred = yyt->NoPred;
copytPosition ((* yyNew)->NoPred.Pos, yyt->NoPred.Pos)
copybool ((* yyNew)->NoPred.IsTypeExp, yyt->NoPred.IsTypeExp)
copytObjects ((* yyNew)->NoPred.DeclsIn, yyt->NoPred.DeclsIn)
copytObjects ((* yyNew)->NoPred.DeclsOut, yyt->NoPred.DeclsOut)
copytType ((* yyNew)->NoPred.Type, yyt->NoPred.Type)
return;
case kPred: (* yyNew)->Pred = yyt->Pred;
copytPosition ((* yyNew)->Pred.Pos, yyt->Pred.Pos)
copybool ((* yyNew)->Pred.IsTypeExp, yyt->Pred.IsTypeExp)
copytObjects ((* yyNew)->Pred.DeclsIn, yyt->Pred.DeclsIn)
copytObjects ((* yyNew)->Pred.DeclsOut, yyt->Pred.DeclsOut)
copytType ((* yyNew)->Pred.Type, yyt->Pred.Type)
yyt = yyt->Pred.Next;
yyNew = & (* yyNew)->Pred.Next; break;
case kQuantPred: (* yyNew)->QuantPred = yyt->QuantPred;
copytPosition ((* yyNew)->QuantPred.Pos, yyt->QuantPred.Pos)
copybool ((* yyNew)->QuantPred.IsTypeExp, yyt->QuantPred.IsTypeExp)
copytObjects ((* yyNew)->QuantPred.DeclsIn, yyt->QuantPred.DeclsIn)
copytObjects ((* yyNew)->QuantPred.DeclsOut, yyt->QuantPred.DeclsOut)
copytType ((* yyNew)->QuantPred.Type, yyt->QuantPred.Type)
copytIdPos ((* yyNew)->QuantPred.LogQuant, yyt->QuantPred.LogQuant)
copytTree ((* yyNew)->QuantPred.SchemaText, yyt->QuantPred.SchemaText)
copytTree ((* yyNew)->QuantPred.Pred, yyt->QuantPred.Pred)
yyt = yyt->QuantPred.Next;
yyNew = & (* yyNew)->QuantPred.Next; break;
case kRelBinPred: (* yyNew)->RelBinPred = yyt->RelBinPred;
copytPosition ((* yyNew)->RelBinPred.Pos, yyt->RelBinPred.Pos)
copybool ((* yyNew)->RelBinPred.IsTypeExp, yyt->RelBinPred.IsTypeExp)
copytObjects ((* yyNew)->RelBinPred.DeclsIn, yyt->RelBinPred.DeclsIn)
copytObjects ((* yyNew)->RelBinPred.DeclsOut, yyt->RelBinPred.DeclsOut)
copytType ((* yyNew)->RelBinPred.Type, yyt->RelBinPred.Type)
copytTree ((* yyNew)->RelBinPred.L, yyt->RelBinPred.L)
copytIdPos ((* yyNew)->RelBinPred.RelBinOp, yyt->RelBinPred.RelBinOp)
copytTree ((* yyNew)->RelBinPred.R, yyt->RelBinPred.R)
yyt = yyt->RelBinPred.Next;
yyNew = & (* yyNew)->RelBinPred.Next; break;
case kAssign: (* yyNew)->Assign = yyt->Assign;
copytPosition ((* yyNew)->Assign.Pos, yyt->Assign.Pos)
copybool ((* yyNew)->Assign.IsTypeExp, yyt->Assign.IsTypeExp)
copytObjects ((* yyNew)->Assign.DeclsIn, yyt->Assign.DeclsIn)
copytObjects ((* yyNew)->Assign.DeclsOut, yyt->Assign.DeclsOut)
copytType ((* yyNew)->Assign.Type, yyt->Assign.Type)
copytTree ((* yyNew)->Assign.L, yyt->Assign.L)
copytTree ((* yyNew)->Assign.R, yyt->Assign.R)
yyt = yyt->Assign.Next;
yyNew = & (* yyNew)->Assign.Next; break;
case kRelPrePred: (* yyNew)->RelPrePred = yyt->RelPrePred;
copytPosition ((* yyNew)->RelPrePred.Pos, yyt->RelPrePred.Pos)
copybool ((* yyNew)->RelPrePred.IsTypeExp, yyt->RelPrePred.IsTypeExp)
copytObjects ((* yyNew)->RelPrePred.DeclsIn, yyt->RelPrePred.DeclsIn)
copytObjects ((* yyNew)->RelPrePred.DeclsOut, yyt->RelPrePred.DeclsOut)
copytType ((* yyNew)->RelPrePred.Type, yyt->RelPrePred.Type)
copytIdPos ((* yyNew)->RelPrePred.RelPreOp, yyt->RelPrePred.RelPreOp)
copytTree ((* yyNew)->RelPrePred.Exp, yyt->RelPrePred.Exp)
yyt = yyt->RelPrePred.Next;
yyNew = & (* yyNew)->RelPrePred.Next; break;
case kLogBinPred: (* yyNew)->LogBinPred = yyt->LogBinPred;
copytPosition ((* yyNew)->LogBinPred.Pos, yyt->LogBinPred.Pos)
copybool ((* yyNew)->LogBinPred.IsTypeExp, yyt->LogBinPred.IsTypeExp)
copytObjects ((* yyNew)->LogBinPred.DeclsIn, yyt->LogBinPred.DeclsIn)
copytObjects ((* yyNew)->LogBinPred.DeclsOut, yyt->LogBinPred.DeclsOut)
copytType ((* yyNew)->LogBinPred.Type, yyt->LogBinPred.Type)
copytTree ((* yyNew)->LogBinPred.L, yyt->LogBinPred.L)
copytTree ((* yyNew)->LogBinPred.LogBinOp, yyt->LogBinPred.LogBinOp)
copytTree ((* yyNew)->LogBinPred.R, yyt->LogBinPred.R)
yyt = yyt->LogBinPred.Next;
yyNew = & (* yyNew)->LogBinPred.Next; break;
case kLogicalNot: (* yyNew)->LogicalNot = yyt->LogicalNot;
copytPosition ((* yyNew)->LogicalNot.Pos, yyt->LogicalNot.Pos)
copybool ((* yyNew)->LogicalNot.IsTypeExp, yyt->LogicalNot.IsTypeExp)
copytObjects ((* yyNew)->LogicalNot.DeclsIn, yyt->LogicalNot.DeclsIn)
copytObjects ((* yyNew)->LogicalNot.DeclsOut, yyt->LogicalNot.DeclsOut)
copytType ((* yyNew)->LogicalNot.Type, yyt->LogicalNot.Type)
copytTree ((* yyNew)->LogicalNot.Pred, yyt->LogicalNot.Pred)
yyt = yyt->LogicalNot.Next;
yyNew = & (* yyNew)->LogicalNot.Next; break;
case kPreCondPred: (* yyNew)->PreCondPred = yyt->PreCondPred;
copytPosition ((* yyNew)->PreCondPred.Pos, yyt->PreCondPred.Pos)
copybool ((* yyNew)->PreCondPred.IsTypeExp, yyt->PreCondPred.IsTypeExp)
copytObjects ((* yyNew)->PreCondPred.DeclsIn, yyt->PreCondPred.DeclsIn)
copytObjects ((* yyNew)->PreCondPred.DeclsOut, yyt->PreCondPred.DeclsOut)
copytType ((* yyNew)->PreCondPred.Type, yyt->PreCondPred.Type)
copytTree ((* yyNew)->PreCondPred.Pred, yyt->PreCondPred.Pred)
yyt = yyt->PreCondPred.Next;
yyNew = & (* yyNew)->PreCondPred.Next; break;
case kIfPred: (* yyNew)->IfPred = yyt->IfPred;
copytPosition ((* yyNew)->IfPred.Pos, yyt->IfPred.Pos)
copybool ((* yyNew)->IfPred.IsTypeExp, yyt->IfPred.IsTypeExp)
copytObjects ((* yyNew)->IfPred.DeclsIn, yyt->IfPred.DeclsIn)
copytObjects ((* yyNew)->IfPred.DeclsOut, yyt->IfPred.DeclsOut)
copytType ((* yyNew)->IfPred.Type, yyt->IfPred.Type)
copytTree ((* yyNew)->IfPred.Con, yyt->IfPred.Con)
copytTree ((* yyNew)->IfPred.Then, yyt->IfPred.Then)
copytTree ((* yyNew)->IfPred.Else, yyt->IfPred.Else)
yyt = yyt->IfPred.Next;
yyNew = & (* yyNew)->IfPred.Next; break;
case kWhilePred: (* yyNew)->WhilePred = yyt->WhilePred;
copytPosition ((* yyNew)->WhilePred.Pos, yyt->WhilePred.Pos)
copybool ((* yyNew)->WhilePred.IsTypeExp, yyt->WhilePred.IsTypeExp)
copytObjects ((* yyNew)->WhilePred.DeclsIn, yyt->WhilePred.DeclsIn)
copytObjects ((* yyNew)->WhilePred.DeclsOut, yyt->WhilePred.DeclsOut)
copytType ((* yyNew)->WhilePred.Type, yyt->WhilePred.Type)
copytTree ((* yyNew)->WhilePred.Con, yyt->WhilePred.Con)
copytTree ((* yyNew)->WhilePred.Do, yyt->WhilePred.Do)
yyt = yyt->WhilePred.Next;
yyNew = & (* yyNew)->WhilePred.Next; break;
case kCallPred: (* yyNew)->CallPred = yyt->CallPred;
copytPosition ((* yyNew)->CallPred.Pos, yyt->CallPred.Pos)
copybool ((* yyNew)->CallPred.IsTypeExp, yyt->CallPred.IsTypeExp)
copytObjects ((* yyNew)->CallPred.DeclsIn, yyt->CallPred.DeclsIn)
copytObjects ((* yyNew)->CallPred.DeclsOut, yyt->CallPred.DeclsOut)
copytType ((* yyNew)->CallPred.Type, yyt->CallPred.Type)
copytTree ((* yyNew)->CallPred.IdList, yyt->CallPred.IdList)
copytTree ((* yyNew)->CallPred.InputBindList, yyt->CallPred.InputBindList)
copytTree ((* yyNew)->CallPred.OutputBindList, yyt->CallPred.OutputBindList)
yyt = yyt->CallPred.Next;
yyNew = & (* yyNew)->CallPred.Next; break;
case kChgOnly: (* yyNew)->ChgOnly = yyt->ChgOnly;
copytPosition ((* yyNew)->ChgOnly.Pos, yyt->ChgOnly.Pos)
copybool ((* yyNew)->ChgOnly.IsTypeExp, yyt->ChgOnly.IsTypeExp)
copytObjects ((* yyNew)->ChgOnly.DeclsIn, yyt->ChgOnly.DeclsIn)
copytObjects ((* yyNew)->ChgOnly.DeclsOut, yyt->ChgOnly.DeclsOut)
copytType ((* yyNew)->ChgOnly.Type, yyt->ChgOnly.Type)
copytTree ((* yyNew)->ChgOnly.NameList, yyt->ChgOnly.NameList)
yyt = yyt->ChgOnly.Next;
yyNew = & (* yyNew)->ChgOnly.Next; break;
case kDefined: (* yyNew)->Defined = yyt->Defined;
copytPosition ((* yyNew)->Defined.Pos, yyt->Defined.Pos)
copybool ((* yyNew)->Defined.IsTypeExp, yyt->Defined.IsTypeExp)
copytObjects ((* yyNew)->Defined.DeclsIn, yyt->Defined.DeclsIn)
copytObjects ((* yyNew)->Defined.DeclsOut, yyt->Defined.DeclsOut)
copytType ((* yyNew)->Defined.Type, yyt->Defined.Type)
copytTree ((* yyNew)->Defined.Exp, yyt->Defined.Exp)
yyt = yyt->Defined.Next;
yyNew = & (* yyNew)->Defined.Next; break;
case kSchemaPred: (* yyNew)->SchemaPred = yyt->SchemaPred;
copytPosition ((* yyNew)->SchemaPred.Pos, yyt->SchemaPred.Pos)
copybool ((* yyNew)->SchemaPred.IsTypeExp, yyt->SchemaPred.IsTypeExp)
copytObjects ((* yyNew)->SchemaPred.DeclsIn, yyt->SchemaPred.DeclsIn)
copytObjects ((* yyNew)->SchemaPred.DeclsOut, yyt->SchemaPred.DeclsOut)
copytType ((* yyNew)->SchemaPred.Type, yyt->SchemaPred.Type)
copytTree ((* yyNew)->SchemaPred.Schema, yyt->SchemaPred.Schema)
yyt = yyt->SchemaPred.Next;
yyNew = & (* yyNew)->SchemaPred.Next; break;
case kBoolValue: (* yyNew)->BoolValue = yyt->BoolValue;
copytPosition ((* yyNew)->BoolValue.Pos, yyt->BoolValue.Pos)
copybool ((* yyNew)->BoolValue.IsTypeExp, yyt->BoolValue.IsTypeExp)
copytObjects ((* yyNew)->BoolValue.DeclsIn, yyt->BoolValue.DeclsIn)
copytObjects ((* yyNew)->BoolValue.DeclsOut, yyt->BoolValue.DeclsOut)
copytType ((* yyNew)->BoolValue.Type, yyt->BoolValue.Type)
copytIdPos ((* yyNew)->BoolValue.Ident, yyt->BoolValue.Ident)
yyt = yyt->BoolValue.Next;
yyNew = & (* yyNew)->BoolValue.Next; break;
case kInputBindList: (* yyNew)->InputBindList = yyt->InputBindList;
copytObjects ((* yyNew)->InputBindList.DeclsIn, yyt->InputBindList.DeclsIn)
copytObjects ((* yyNew)->InputBindList.DeclsOut, yyt->InputBindList.DeclsOut)
copytType ((* yyNew)->InputBindList.Type, yyt->InputBindList.Type)
return;
case kNoInputBind: (* yyNew)->NoInputBind = yyt->NoInputBind;
copytObjects ((* yyNew)->NoInputBind.DeclsIn, yyt->NoInputBind.DeclsIn)
copytObjects ((* yyNew)->NoInputBind.DeclsOut, yyt->NoInputBind.DeclsOut)
copytType ((* yyNew)->NoInputBind.Type, yyt->NoInputBind.Type)
return;
case kInputBind: (* yyNew)->InputBind = yyt->InputBind;
copytObjects ((* yyNew)->InputBind.DeclsIn, yyt->InputBind.DeclsIn)
copytObjects ((* yyNew)->InputBind.DeclsOut, yyt->InputBind.DeclsOut)
copytType ((* yyNew)->InputBind.Type, yyt->InputBind.Type)
copytIdPos ((* yyNew)->InputBind.Ident, yyt->InputBind.Ident)
copytTree ((* yyNew)->InputBind.ExpressionList, yyt->InputBind.ExpressionList)
yyt = yyt->InputBind.Next;
yyNew = & (* yyNew)->InputBind.Next; break;
case kOutputBindList: (* yyNew)->OutputBindList = yyt->OutputBindList;
copytObjects ((* yyNew)->OutputBindList.DeclsIn, yyt->OutputBindList.DeclsIn)
copytObjects ((* yyNew)->OutputBindList.DeclsOut, yyt->OutputBindList.DeclsOut)
copytType ((* yyNew)->OutputBindList.Type, yyt->OutputBindList.Type)
return;
case kNoOutputBind: (* yyNew)->NoOutputBind = yyt->NoOutputBind;
copytObjects ((* yyNew)->NoOutputBind.DeclsIn, yyt->NoOutputBind.DeclsIn)
copytObjects ((* yyNew)->NoOutputBind.DeclsOut, yyt->NoOutputBind.DeclsOut)
copytType ((* yyNew)->NoOutputBind.Type, yyt->NoOutputBind.Type)
return;
case kOutputBind: (* yyNew)->OutputBind = yyt->OutputBind;
copytObjects ((* yyNew)->OutputBind.DeclsIn, yyt->OutputBind.DeclsIn)
copytObjects ((* yyNew)->OutputBind.DeclsOut, yyt->OutputBind.DeclsOut)
copytType ((* yyNew)->OutputBind.Type, yyt->OutputBind.Type)
copytIdPos ((* yyNew)->OutputBind.Ident, yyt->OutputBind.Ident)
copytTree ((* yyNew)->OutputBind.IdList, yyt->OutputBind.IdList)
yyt = yyt->OutputBind.Next;
yyNew = & (* yyNew)->OutputBind.Next; break;
case kLogBinOp: (* yyNew)->LogBinOp = yyt->LogBinOp;
return;
case kLogSeq: (* yyNew)->LogSeq = yyt->LogSeq;
return;
case kLogAnd: (* yyNew)->LogAnd = yyt->LogAnd;
return;
case kLogExor: (* yyNew)->LogExor = yyt->LogExor;
return;
case kLogOr: (* yyNew)->LogOr = yyt->LogOr;
return;
case kLogImply: (* yyNew)->LogImply = yyt->LogImply;
return;
case kLogEquiv: (* yyNew)->LogEquiv = yyt->LogEquiv;
return;
case kDeclList: (* yyNew)->DeclList = yyt->DeclList;
copytPosition ((* yyNew)->DeclList.Pos, yyt->DeclList.Pos)
copytObjects ((* yyNew)->DeclList.DeclsIn, yyt->DeclList.DeclsIn)
copytObjects ((* yyNew)->DeclList.DeclsOut, yyt->DeclList.DeclsOut)
copytType ((* yyNew)->DeclList.Type, yyt->DeclList.Type)
return;
case kNoDecl: (* yyNew)->NoDecl = yyt->NoDecl;
copytPosition ((* yyNew)->NoDecl.Pos, yyt->NoDecl.Pos)
copytObjects ((* yyNew)->NoDecl.DeclsIn, yyt->NoDecl.DeclsIn)
copytObjects ((* yyNew)->NoDecl.DeclsOut, yyt->NoDecl.DeclsOut)
copytType ((* yyNew)->NoDecl.Type, yyt->NoDecl.Type)
return;
case kDecl: (* yyNew)->Decl = yyt->Decl;
copytPosition ((* yyNew)->Decl.Pos, yyt->Decl.Pos)
copytObjects ((* yyNew)->Decl.DeclsIn, yyt->Decl.DeclsIn)
copytObjects ((* yyNew)->Decl.DeclsOut, yyt->Decl.DeclsOut)
copytType ((* yyNew)->Decl.Type, yyt->Decl.Type)
yyt = yyt->Decl.Next;
yyNew = & (* yyNew)->Decl.Next; break;
case kVarDecl: (* yyNew)->VarDecl = yyt->VarDecl;
copytPosition ((* yyNew)->VarDecl.Pos, yyt->VarDecl.Pos)
copytObjects ((* yyNew)->VarDecl.DeclsIn, yyt->VarDecl.DeclsIn)
copytObjects ((* yyNew)->VarDecl.DeclsOut, yyt->VarDecl.DeclsOut)
copytType ((* yyNew)->VarDecl.Type, yyt->VarDecl.Type)
copytTree ((* yyNew)->VarDecl.IdList, yyt->VarDecl.IdList)
copytTree ((* yyNew)->VarDecl.Exp, yyt->VarDecl.Exp)
copyint ((* yyNew)->VarDecl.VarDeclKind, yyt->VarDecl.VarDeclKind)
yyt = yyt->VarDecl.Next;
yyNew = & (* yyNew)->VarDecl.Next; break;
case kGivenSet: (* yyNew)->GivenSet = yyt->GivenSet;
copytPosition ((* yyNew)->GivenSet.Pos, yyt->GivenSet.Pos)
copytObjects ((* yyNew)->GivenSet.DeclsIn, yyt->GivenSet.DeclsIn)
copytObjects ((* yyNew)->GivenSet.DeclsOut, yyt->GivenSet.DeclsOut)
copytType ((* yyNew)->GivenSet.Type, yyt->GivenSet.Type)
copytTree ((* yyNew)->GivenSet.IdList, yyt->GivenSet.IdList)
yyt = yyt->GivenSet.Next;
yyNew = & (* yyNew)->GivenSet.Next; break;
case kAxiomDecl: (* yyNew)->AxiomDecl = yyt->AxiomDecl;
copytPosition ((* yyNew)->AxiomDecl.Pos, yyt->AxiomDecl.Pos)
copytObjects ((* yyNew)->AxiomDecl.DeclsIn, yyt->AxiomDecl.DeclsIn)
copytObjects ((* yyNew)->AxiomDecl.DeclsOut, yyt->AxiomDecl.DeclsOut)
copytType ((* yyNew)->AxiomDecl.Type, yyt->AxiomDecl.Type)
copytTree ((* yyNew)->AxiomDecl.FormalParams, yyt->AxiomDecl.FormalParams)
copytTree ((* yyNew)->AxiomDecl.DeclList, yyt->AxiomDecl.DeclList)
copytTree ((* yyNew)->AxiomDecl.PredList, yyt->AxiomDecl.PredList)
yyt = yyt->AxiomDecl.Next;
yyNew = & (* yyNew)->AxiomDecl.Next; break;
case kSchemaDef: (* yyNew)->SchemaDef = yyt->SchemaDef;
copytPosition ((* yyNew)->SchemaDef.Pos, yyt->SchemaDef.Pos)
copytObjects ((* yyNew)->SchemaDef.DeclsIn, yyt->SchemaDef.DeclsIn)
copytObjects ((* yyNew)->SchemaDef.DeclsOut, yyt->SchemaDef.DeclsOut)
copytType ((* yyNew)->SchemaDef.Type, yyt->SchemaDef.Type)
copytIdPos ((* yyNew)->SchemaDef.Ident, yyt->SchemaDef.Ident)
copytTree ((* yyNew)->SchemaDef.FormalParams, yyt->SchemaDef.FormalParams)
copytTree ((* yyNew)->SchemaDef.DeclList, yyt->SchemaDef.DeclList)
copytTree ((* yyNew)->SchemaDef.PredList, yyt->SchemaDef.PredList)
copybool ((* yyNew)->SchemaDef.IsOp, yyt->SchemaDef.IsOp)
copybool ((* yyNew)->SchemaDef.HasStateIncl, yyt->SchemaDef.HasStateIncl)
yyt = yyt->SchemaDef.Next;
yyNew = & (* yyNew)->SchemaDef.Next; break;
case kAnnotation: (* yyNew)->Annotation = yyt->Annotation;
copytPosition ((* yyNew)->Annotation.Pos, yyt->Annotation.Pos)
copytObjects ((* yyNew)->Annotation.DeclsIn, yyt->Annotation.DeclsIn)
copytObjects ((* yyNew)->Annotation.DeclsOut, yyt->Annotation.DeclsOut)
copytType ((* yyNew)->Annotation.Type, yyt->Annotation.Type)
copytTree ((* yyNew)->Annotation.Decl, yyt->Annotation.Decl)
yyt = yyt->Annotation.Next;
yyNew = & (* yyNew)->Annotation.Next; break;
case kErgoAnno: (* yyNew)->ErgoAnno = yyt->ErgoAnno;
copytPosition ((* yyNew)->ErgoAnno.Pos, yyt->ErgoAnno.Pos)
copytObjects ((* yyNew)->ErgoAnno.DeclsIn, yyt->ErgoAnno.DeclsIn)
copytObjects ((* yyNew)->ErgoAnno.DeclsOut, yyt->ErgoAnno.DeclsOut)
copytType ((* yyNew)->ErgoAnno.Type, yyt->ErgoAnno.Type)
copytIdPos ((* yyNew)->ErgoAnno.Ident, yyt->ErgoAnno.Ident)
yyt = yyt->ErgoAnno.Next;
yyNew = & (* yyNew)->ErgoAnno.Next; break;
case kStateMachine: (* yyNew)->StateMachine = yyt->StateMachine;
copytPosition ((* yyNew)->StateMachine.Pos, yyt->StateMachine.Pos)
copytObjects ((* yyNew)->StateMachine.DeclsIn, yyt->StateMachine.DeclsIn)
copytObjects ((* yyNew)->StateMachine.DeclsOut, yyt->StateMachine.DeclsOut)
copytType ((* yyNew)->StateMachine.Type, yyt->StateMachine.Type)
copytTree ((* yyNew)->StateMachine.IdList, yyt->StateMachine.IdList)
yyt = yyt->StateMachine.Next;
yyNew = & (* yyNew)->StateMachine.Next; break;
case kAbbreviation: (* yyNew)->Abbreviation = yyt->Abbreviation;
copytPosition ((* yyNew)->Abbreviation.Pos, yyt->Abbreviation.Pos)
copytObjects ((* yyNew)->Abbreviation.DeclsIn, yyt->Abbreviation.DeclsIn)
copytObjects ((* yyNew)->Abbreviation.DeclsOut, yyt->Abbreviation.DeclsOut)
copytType ((* yyNew)->Abbreviation.Type, yyt->Abbreviation.Type)
copytIdPos ((* yyNew)->Abbreviation.Ident, yyt->Abbreviation.Ident)
copytTree ((* yyNew)->Abbreviation.Exp, yyt->Abbreviation.Exp)
yyt = yyt->Abbreviation.Next;
yyNew = & (* yyNew)->Abbreviation.Next; break;
case kFunctionDecl: (* yyNew)->FunctionDecl = yyt->FunctionDecl;
copytPosition ((* yyNew)->FunctionDecl.Pos, yyt->FunctionDecl.Pos)
copytObjects ((* yyNew)->FunctionDecl.DeclsIn, yyt->FunctionDecl.DeclsIn)
copytObjects ((* yyNew)->FunctionDecl.DeclsOut, yyt->FunctionDecl.DeclsOut)
copytType ((* yyNew)->FunctionDecl.Type, yyt->FunctionDecl.Type)
copytTree ((* yyNew)->FunctionDecl.DeclList, yyt->FunctionDecl.DeclList)
copytTree ((* yyNew)->FunctionDecl.PredList, yyt->FunctionDecl.PredList)
yyt = yyt->FunctionDecl.Next;
yyNew = & (* yyNew)->FunctionDecl.Next; break;
case kFreeType: (* yyNew)->FreeType = yyt->FreeType;
copytPosition ((* yyNew)->FreeType.Pos, yyt->FreeType.Pos)
copytObjects ((* yyNew)->FreeType.DeclsIn, yyt->FreeType.DeclsIn)
copytObjects ((* yyNew)->FreeType.DeclsOut, yyt->FreeType.DeclsOut)
copytType ((* yyNew)->FreeType.Type, yyt->FreeType.Type)
copytIdPos ((* yyNew)->FreeType.Ident, yyt->FreeType.Ident)
copytTree ((* yyNew)->FreeType.BranchList, yyt->FreeType.BranchList)
copytIdent ((* yyNew)->FreeType.ModId, yyt->FreeType.ModId)
yyt = yyt->FreeType.Next;
yyNew = & (* yyNew)->FreeType.Next; break;
case kEnum: (* yyNew)->Enum = yyt->Enum;
copytPosition ((* yyNew)->Enum.Pos, yyt->Enum.Pos)
copytObjects ((* yyNew)->Enum.DeclsIn, yyt->Enum.DeclsIn)
copytObjects ((* yyNew)->Enum.DeclsOut, yyt->Enum.DeclsOut)
copytType ((* yyNew)->Enum.Type, yyt->Enum.Type)
copytIdPos ((* yyNew)->Enum.Ident, yyt->Enum.Ident)
copytTree ((* yyNew)->Enum.BranchList, yyt->Enum.BranchList)
copytIdent ((* yyNew)->Enum.ModId, yyt->Enum.ModId)
yyt = yyt->Enum.Next;
yyNew = & (* yyNew)->Enum.Next; break;
case kImport: (* yyNew)->Import = yyt->Import;
copytPosition ((* yyNew)->Import.Pos, yyt->Import.Pos)
copytObjects ((* yyNew)->Import.DeclsIn, yyt->Import.DeclsIn)
copytObjects ((* yyNew)->Import.DeclsOut, yyt->Import.DeclsOut)
copytType ((* yyNew)->Import.Type, yyt->Import.Type)
copytIdPos ((* yyNew)->Import.Ident, yyt->Import.Ident)
copytTree ((* yyNew)->Import.ExpressionList, yyt->Import.ExpressionList)
copytTree ((* yyNew)->Import.RenameList, yyt->Import.RenameList)
copytIdPos ((* yyNew)->Import.NewIdent, yyt->Import.NewIdent)
copyIML_List ((* yyNew)->Import.ModIMLlist, yyt->Import.ModIMLlist)
copytObjects ((* yyNew)->Import.FmlParams, yyt->Import.FmlParams)
yyt = yyt->Import.Next;
yyNew = & (* yyNew)->Import.Next; break;
case kModuleDecl: (* yyNew)->ModuleDecl = yyt->ModuleDecl;
copytPosition ((* yyNew)->ModuleDecl.Pos, yyt->ModuleDecl.Pos)
copytObjects ((* yyNew)->ModuleDecl.DeclsIn, yyt->ModuleDecl.DeclsIn)
copytObjects ((* yyNew)->ModuleDecl.DeclsOut, yyt->ModuleDecl.DeclsOut)
copytType ((* yyNew)->ModuleDecl.Type, yyt->ModuleDecl.Type)
copytTree ((* yyNew)->ModuleDecl.Module, yyt->ModuleDecl.Module)
yyt = yyt->ModuleDecl.Next;
yyNew = & (* yyNew)->ModuleDecl.Next; break;
case kConstraint: (* yyNew)->Constraint = yyt->Constraint;
copytPosition ((* yyNew)->Constraint.Pos, yyt->Constraint.Pos)
copytObjects ((* yyNew)->Constraint.DeclsIn, yyt->Constraint.DeclsIn)
copytObjects ((* yyNew)->Constraint.DeclsOut, yyt->Constraint.DeclsOut)
copytType ((* yyNew)->Constraint.Type, yyt->Constraint.Type)
copytTree ((* yyNew)->Constraint.Pred, yyt->Constraint.Pred)
yyt = yyt->Constraint.Next;
yyNew = & (* yyNew)->Constraint.Next; break;
case kSchemaIncl: (* yyNew)->SchemaIncl = yyt->SchemaIncl;
copytPosition ((* yyNew)->SchemaIncl.Pos, yyt->SchemaIncl.Pos)
copytObjects ((* yyNew)->SchemaIncl.DeclsIn, yyt->SchemaIncl.DeclsIn)
copytObjects ((* yyNew)->SchemaIncl.DeclsOut, yyt->SchemaIncl.DeclsOut)
copytType ((* yyNew)->SchemaIncl.Type, yyt->SchemaIncl.Type)
copytTree ((* yyNew)->SchemaIncl.IdList, yyt->SchemaIncl.IdList)
copytTree ((* yyNew)->SchemaIncl.ExpressionList, yyt->SchemaIncl.ExpressionList)
copytIdent ((* yyNew)->SchemaIncl.ModId, yyt->SchemaIncl.ModId)
yyt = yyt->SchemaIncl.Next;
yyNew = & (* yyNew)->SchemaIncl.Next; break;
case kVisibility: (* yyNew)->Visibility = yyt->Visibility;
copytPosition ((* yyNew)->Visibility.Pos, yyt->Visibility.Pos)
copytObjects ((* yyNew)->Visibility.DeclsIn, yyt->Visibility.DeclsIn)
copytObjects ((* yyNew)->Visibility.DeclsOut, yyt->Visibility.DeclsOut)
copytType ((* yyNew)->Visibility.Type, yyt->Visibility.Type)
copytIdPos ((* yyNew)->Visibility.Ident, yyt->Visibility.Ident)
copytTree ((* yyNew)->Visibility.SelectionList, yyt->Visibility.SelectionList)
yyt = yyt->Visibility.Next;
yyNew = & (* yyNew)->Visibility.Next; break;
case kBranchList: (* yyNew)->BranchList = yyt->BranchList;
copytObjects ((* yyNew)->BranchList.DeclsIn, yyt->BranchList.DeclsIn)
copytObjects ((* yyNew)->BranchList.DeclsOut, yyt->BranchList.DeclsOut)
copytType ((* yyNew)->BranchList.Type, yyt->BranchList.Type)
return;
case kNoBranch: (* yyNew)->NoBranch = yyt->NoBranch;
copytObjects ((* yyNew)->NoBranch.DeclsIn, yyt->NoBranch.DeclsIn)
copytObjects ((* yyNew)->NoBranch.DeclsOut, yyt->NoBranch.DeclsOut)
copytType ((* yyNew)->NoBranch.Type, yyt->NoBranch.Type)
return;
case kBranch: (* yyNew)->Branch = yyt->Branch;
copytObjects ((* yyNew)->Branch.DeclsIn, yyt->Branch.DeclsIn)
copytObjects ((* yyNew)->Branch.DeclsOut, yyt->Branch.DeclsOut)
copytType ((* yyNew)->Branch.Type, yyt->Branch.Type)
copytIdent ((* yyNew)->Branch.FTIdent, yyt->Branch.FTIdent)
yyt = yyt->Branch.Next;
yyNew = & (* yyNew)->Branch.Next; break;
case kFTConstant: (* yyNew)->FTConstant = yyt->FTConstant;
copytObjects ((* yyNew)->FTConstant.DeclsIn, yyt->FTConstant.DeclsIn)
copytObjects ((* yyNew)->FTConstant.DeclsOut, yyt->FTConstant.DeclsOut)
copytType ((* yyNew)->FTConstant.Type, yyt->FTConstant.Type)
copytIdent ((* yyNew)->FTConstant.FTIdent, yyt->FTConstant.FTIdent)
copytIdPos ((* yyNew)->FTConstant.Ident, yyt->FTConstant.Ident)
yyt = yyt->FTConstant.Next;
yyNew = & (* yyNew)->FTConstant.Next; break;
case kFTConstructor: (* yyNew)->FTConstructor = yyt->FTConstructor;
copytObjects ((* yyNew)->FTConstructor.DeclsIn, yyt->FTConstructor.DeclsIn)
copytObjects ((* yyNew)->FTConstructor.DeclsOut, yyt->FTConstructor.DeclsOut)
copytType ((* yyNew)->FTConstructor.Type, yyt->FTConstructor.Type)
copytIdent ((* yyNew)->FTConstructor.FTIdent, yyt->FTConstructor.FTIdent)
copytIdPos ((* yyNew)->FTConstructor.Ident, yyt->FTConstructor.Ident)
copytTree ((* yyNew)->FTConstructor.Exp, yyt->FTConstructor.Exp)
yyt = yyt->FTConstructor.Next;
yyNew = & (* yyNew)->FTConstructor.Next; break;
case kSchema: (* yyNew)->Schema = yyt->Schema;
copytPosition ((* yyNew)->Schema.Pos, yyt->Schema.Pos)
copybool ((* yyNew)->Schema.IsTypeExp, yyt->Schema.IsTypeExp)
copytObjects ((* yyNew)->Schema.DeclsIn, yyt->Schema.DeclsIn)
copytObjects ((* yyNew)->Schema.DeclsOut, yyt->Schema.DeclsOut)
copytType ((* yyNew)->Schema.Type, yyt->Schema.Type)
return;
case kExpPred: (* yyNew)->ExpPred = yyt->ExpPred;
copytPosition ((* yyNew)->ExpPred.Pos, yyt->ExpPred.Pos)
copybool ((* yyNew)->ExpPred.IsTypeExp, yyt->ExpPred.IsTypeExp)
copytObjects ((* yyNew)->ExpPred.DeclsIn, yyt->ExpPred.DeclsIn)
copytObjects ((* yyNew)->ExpPred.DeclsOut, yyt->ExpPred.DeclsOut)
copytType ((* yyNew)->ExpPred.Type, yyt->ExpPred.Type)
yyt = yyt->ExpPred.Exp;
yyNew = & (* yyNew)->ExpPred.Exp; break;
case kSchemaText: (* yyNew)->SchemaText = yyt->SchemaText;
copytPosition ((* yyNew)->SchemaText.Pos, yyt->SchemaText.Pos)
copybool ((* yyNew)->SchemaText.IsTypeExp, yyt->SchemaText.IsTypeExp)
copytObjects ((* yyNew)->SchemaText.DeclsIn, yyt->SchemaText.DeclsIn)
copytObjects ((* yyNew)->SchemaText.DeclsOut, yyt->SchemaText.DeclsOut)
copytType ((* yyNew)->SchemaText.Type, yyt->SchemaText.Type)
copytTree ((* yyNew)->SchemaText.DeclList, yyt->SchemaText.DeclList)
copybool ((* yyNew)->SchemaText.Is_local_dec, yyt->SchemaText.Is_local_dec)
yyt = yyt->SchemaText.PredList;
yyNew = & (* yyNew)->SchemaText.PredList; break;
case kSchemaRef: (* yyNew)->SchemaRef = yyt->SchemaRef;
copytPosition ((* yyNew)->SchemaRef.Pos, yyt->SchemaRef.Pos)
copybool ((* yyNew)->SchemaRef.IsTypeExp, yyt->SchemaRef.IsTypeExp)
copytObjects ((* yyNew)->SchemaRef.DeclsIn, yyt->SchemaRef.DeclsIn)
copytObjects ((* yyNew)->SchemaRef.DeclsOut, yyt->SchemaRef.DeclsOut)
copytType ((* yyNew)->SchemaRef.Type, yyt->SchemaRef.Type)
copytTree ((* yyNew)->SchemaRef.IdList, yyt->SchemaRef.IdList)
yyt = yyt->SchemaRef.ExpressionList;
yyNew = & (* yyNew)->SchemaRef.ExpressionList; break;
case kSchemaCons: (* yyNew)->SchemaCons = yyt->SchemaCons;
copytPosition ((* yyNew)->SchemaCons.Pos, yyt->SchemaCons.Pos)
copybool ((* yyNew)->SchemaCons.IsTypeExp, yyt->SchemaCons.IsTypeExp)
copytObjects ((* yyNew)->SchemaCons.DeclsIn, yyt->SchemaCons.DeclsIn)
copytObjects ((* yyNew)->SchemaCons.DeclsOut, yyt->SchemaCons.DeclsOut)
copytType ((* yyNew)->SchemaCons.Type, yyt->SchemaCons.Type)
copytTree ((* yyNew)->SchemaCons.LogOp, yyt->SchemaCons.LogOp)
copytTree ((* yyNew)->SchemaCons.L, yyt->SchemaCons.L)
yyt = yyt->SchemaCons.R;
yyNew = & (* yyNew)->SchemaCons.R; break;
case kSchemaCompos: (* yyNew)->SchemaCompos = yyt->SchemaCompos;
copytPosition ((* yyNew)->SchemaCompos.Pos, yyt->SchemaCompos.Pos)
copybool ((* yyNew)->SchemaCompos.IsTypeExp, yyt->SchemaCompos.IsTypeExp)
copytObjects ((* yyNew)->SchemaCompos.DeclsIn, yyt->SchemaCompos.DeclsIn)
copytObjects ((* yyNew)->SchemaCompos.DeclsOut, yyt->SchemaCompos.DeclsOut)
copytType ((* yyNew)->SchemaCompos.Type, yyt->SchemaCompos.Type)
copytTree ((* yyNew)->SchemaCompos.Sch1, yyt->SchemaCompos.Sch1)
copytIdPos ((* yyNew)->SchemaCompos.Compos, yyt->SchemaCompos.Compos)
yyt = yyt->SchemaCompos.Sch2;
yyNew = & (* yyNew)->SchemaCompos.Sch2; break;
case kSchemaProj: (* yyNew)->SchemaProj = yyt->SchemaProj;
copytPosition ((* yyNew)->SchemaProj.Pos, yyt->SchemaProj.Pos)
copybool ((* yyNew)->SchemaProj.IsTypeExp, yyt->SchemaProj.IsTypeExp)
copytObjects ((* yyNew)->SchemaProj.DeclsIn, yyt->SchemaProj.DeclsIn)
copytObjects ((* yyNew)->SchemaProj.DeclsOut, yyt->SchemaProj.DeclsOut)
copytType ((* yyNew)->SchemaProj.Type, yyt->SchemaProj.Type)
copytTree ((* yyNew)->SchemaProj.Sch1, yyt->SchemaProj.Sch1)
copytIdPos ((* yyNew)->SchemaProj.Proj, yyt->SchemaProj.Proj)
yyt = yyt->SchemaProj.Sch2;
yyNew = & (* yyNew)->SchemaProj.Sch2; break;
case kSchemaSubst: (* yyNew)->SchemaSubst = yyt->SchemaSubst;
copytPosition ((* yyNew)->SchemaSubst.Pos, yyt->SchemaSubst.Pos)
copybool ((* yyNew)->SchemaSubst.IsTypeExp, yyt->SchemaSubst.IsTypeExp)
copytObjects ((* yyNew)->SchemaSubst.DeclsIn, yyt->SchemaSubst.DeclsIn)
copytObjects ((* yyNew)->SchemaSubst.DeclsOut, yyt->SchemaSubst.DeclsOut)
copytType ((* yyNew)->SchemaSubst.Type, yyt->SchemaSubst.Type)
copytTree ((* yyNew)->SchemaSubst.Schema, yyt->SchemaSubst.Schema)
yyt = yyt->SchemaSubst.RenameList;
yyNew = & (* yyNew)->SchemaSubst.RenameList; break;
case kSchemaHiding: (* yyNew)->SchemaHiding = yyt->SchemaHiding;
copytPosition ((* yyNew)->SchemaHiding.Pos, yyt->SchemaHiding.Pos)
copybool ((* yyNew)->SchemaHiding.IsTypeExp, yyt->SchemaHiding.IsTypeExp)
copytObjects ((* yyNew)->SchemaHiding.DeclsIn, yyt->SchemaHiding.DeclsIn)
copytObjects ((* yyNew)->SchemaHiding.DeclsOut, yyt->SchemaHiding.DeclsOut)
copytType ((* yyNew)->SchemaHiding.Type, yyt->SchemaHiding.Type)
copytTree ((* yyNew)->SchemaHiding.Schema, yyt->SchemaHiding.Schema)
yyt = yyt->SchemaHiding.NameList;
yyNew = & (* yyNew)->SchemaHiding.NameList; break;
case kLogOp: (* yyNew)->LogOp = yyt->LogOp;
return;
case kSDisjunction: (* yyNew)->SDisjunction = yyt->SDisjunction;
return;
case kSConjunction: (* yyNew)->SConjunction = yyt->SConjunction;
return;
case kSImplication: (* yyNew)->SImplication = yyt->SImplication;
return;
case kSEquivalence: (* yyNew)->SEquivalence = yyt->SEquivalence;
return;
  default: ;
  }
 }
}

tTree CopyTree
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 tTree yyNew;
 yyMark (yyt);
 yyOldToNewCount = 0;
 yyCopyTree (yyt, & yyNew);
 return yyNew;
}

# define yyyWrite	1
# define yyyRead	2
# define yyyQuit	3

static char yyyString [32], yyCh;
static int yyLength, yyState;

static bool yyyIsEqual
# if defined __STDC__ | defined __cplusplus
 (char * yya)
# else
 (yya) char * yya;
# endif
{
 register int yyi;
 if (yyLength >= 0 && yyyString [yyLength] == ' ') {
  if (yyLength != strlen (yya)) return false;
  for (yyi = 0; yyi < yyLength; yyi ++)
   if (yyyString [yyi] != yya [yyi]) return false;
 } else {
  if (yyLength >= strlen (yya)) return false;
  for (yyi = 0; yyi <= yyLength; yyi ++)
   if (yyyString [yyi] != yya [yyi]) return false;
 }
 return true;
}

void QueryTree
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyState = yyyWrite;
 for (;;) {
  switch (yyState) {
  case yyyQuit : return;
  case yyyWrite: WriteTreeNode (stdout, yyt); yyState = yyyRead;
  case yyyRead : (void) printf ("? "); yyLength = -1; yyCh = getc (stdin);
   while (yyCh != '\n' && yyCh > 0)
    { yyyString [++ yyLength] = yyCh; yyCh = getc (stdin); }
   if (yyCh < 0) { (void) fputs ("QueryTree: eof reached\n", stderr);
    yyState = yyyQuit; return; }
   if      (yyyIsEqual ("parent")) { yyState = yyyWrite; return; }
   else if (yyyIsEqual ("quit"  )) { yyState = yyyQuit ; return; }
   else if (yyt != NoTree) {
    switch (yyt->Kind) {
case kSum: if (false) ;
else if (yyyIsEqual ("ModuleList")) QueryTree (yyt->Sum.ModuleList);
break;
case kModule: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Module.Next);
else if (yyyIsEqual ("FormalParams")) QueryTree (yyt->Module.FormalParams);
else if (yyyIsEqual ("PredList")) QueryTree (yyt->Module.PredList);
else if (yyyIsEqual ("DeclList")) QueryTree (yyt->Module.DeclList);
break;
case kParam: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Param.Next);
break;
case kTyParam: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->TyParam.Next);
break;
case kFncParam: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->FncParam.Next);
else if (yyyIsEqual ("VarDecl")) QueryTree (yyt->FncParam.VarDecl);
break;
case kRename: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Rename.Next);
else if (yyyIsEqual ("OldIdent")) QueryTree (yyt->Rename.OldIdent);
break;
case kSelection: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Selection.Next);
break;
case kId: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Id.Next);
break;
case kName: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Name.Next);
else if (yyyIsEqual ("IdList")) QueryTree (yyt->Name.IdList);
break;
case kExp: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Exp.Next);
break;
case kVariable: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Variable.Next);
else if (yyyIsEqual ("IdList")) QueryTree (yyt->Variable.IdList);
break;
case kLiteral: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Literal.Next);
break;
case kString: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->String.Next);
break;
case kChar: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Char.Next);
break;
case kPrefixOp: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->PrefixOp.Next);
else if (yyyIsEqual ("Exp")) QueryTree (yyt->PrefixOp.Exp);
break;
case kLambda: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Lambda.Next);
else if (yyyIsEqual ("SchemaText")) QueryTree (yyt->Lambda.SchemaText);
else if (yyyIsEqual ("Exp")) QueryTree (yyt->Lambda.Exp);
break;
case kRecDisp: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->RecDisp.Next);
else if (yyyIsEqual ("SchemaText")) QueryTree (yyt->RecDisp.SchemaText);
else if (yyyIsEqual ("PredList")) QueryTree (yyt->RecDisp.PredList);
break;
case kMu: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Mu.Next);
else if (yyyIsEqual ("SchemaText")) QueryTree (yyt->Mu.SchemaText);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->Mu.ExpressionList);
break;
case kTupSelection: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->TupSelection.Next);
else if (yyyIsEqual ("Exp")) QueryTree (yyt->TupSelection.Exp);
break;
case kVarSelection: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->VarSelection.Next);
else if (yyyIsEqual ("Exp")) QueryTree (yyt->VarSelection.Exp);
break;
case kIfExp: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->IfExp.Next);
else if (yyyIsEqual ("Con")) QueryTree (yyt->IfExp.Con);
else if (yyyIsEqual ("Then")) QueryTree (yyt->IfExp.Then);
else if (yyyIsEqual ("Else")) QueryTree (yyt->IfExp.Else);
break;
case kFncApplication: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->FncApplication.Next);
else if (yyyIsEqual ("Fnc")) QueryTree (yyt->FncApplication.Fnc);
else if (yyyIsEqual ("Arg")) QueryTree (yyt->FncApplication.Arg);
break;
case kSetComp: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->SetComp.Next);
else if (yyyIsEqual ("SchemaText")) QueryTree (yyt->SetComp.SchemaText);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->SetComp.ExpressionList);
break;
case kSetElab: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->SetElab.Next);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->SetElab.ExpressionList);
break;
case kArrayUpd: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->ArrayUpd.Next);
else if (yyyIsEqual ("Array")) QueryTree (yyt->ArrayUpd.Array);
else if (yyyIsEqual ("Index")) QueryTree (yyt->ArrayUpd.Index);
else if (yyyIsEqual ("Value")) QueryTree (yyt->ArrayUpd.Value);
break;
case kNamedArrayAgg: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->NamedArrayAgg.Next);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->NamedArrayAgg.ExpressionList);
break;
case kSequence: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Sequence.Next);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->Sequence.ExpressionList);
break;
case kBag: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Bag.Next);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->Bag.ExpressionList);
break;
case kCartProd: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->CartProd.Next);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->CartProd.ExpressionList);
break;
case kTuple: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Tuple.Next);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->Tuple.ExpressionList);
break;
case kExp_SchemaRef: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Exp_SchemaRef.Next);
else if (yyyIsEqual ("IdList")) QueryTree (yyt->Exp_SchemaRef.IdList);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->Exp_SchemaRef.ExpressionList);
break;
case kTheta: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Theta.Next);
else if (yyyIsEqual ("Exp")) QueryTree (yyt->Theta.Exp);
break;
case kInfixOp: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->InfixOp.Next);
else if (yyyIsEqual ("Op1")) QueryTree (yyt->InfixOp.Op1);
else if (yyyIsEqual ("Op2")) QueryTree (yyt->InfixOp.Op2);
break;
case kPredExp: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->PredExp.Next);
else if (yyyIsEqual ("Pred")) QueryTree (yyt->PredExp.Pred);
break;
case kPred: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Pred.Next);
break;
case kQuantPred: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->QuantPred.Next);
else if (yyyIsEqual ("SchemaText")) QueryTree (yyt->QuantPred.SchemaText);
else if (yyyIsEqual ("Pred")) QueryTree (yyt->QuantPred.Pred);
break;
case kRelBinPred: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->RelBinPred.Next);
else if (yyyIsEqual ("L")) QueryTree (yyt->RelBinPred.L);
else if (yyyIsEqual ("R")) QueryTree (yyt->RelBinPred.R);
break;
case kAssign: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Assign.Next);
else if (yyyIsEqual ("L")) QueryTree (yyt->Assign.L);
else if (yyyIsEqual ("R")) QueryTree (yyt->Assign.R);
break;
case kRelPrePred: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->RelPrePred.Next);
else if (yyyIsEqual ("Exp")) QueryTree (yyt->RelPrePred.Exp);
break;
case kLogBinPred: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->LogBinPred.Next);
else if (yyyIsEqual ("L")) QueryTree (yyt->LogBinPred.L);
else if (yyyIsEqual ("LogBinOp")) QueryTree (yyt->LogBinPred.LogBinOp);
else if (yyyIsEqual ("R")) QueryTree (yyt->LogBinPred.R);
break;
case kLogicalNot: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->LogicalNot.Next);
else if (yyyIsEqual ("Pred")) QueryTree (yyt->LogicalNot.Pred);
break;
case kPreCondPred: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->PreCondPred.Next);
else if (yyyIsEqual ("Pred")) QueryTree (yyt->PreCondPred.Pred);
break;
case kIfPred: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->IfPred.Next);
else if (yyyIsEqual ("Con")) QueryTree (yyt->IfPred.Con);
else if (yyyIsEqual ("Then")) QueryTree (yyt->IfPred.Then);
else if (yyyIsEqual ("Else")) QueryTree (yyt->IfPred.Else);
break;
case kWhilePred: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->WhilePred.Next);
else if (yyyIsEqual ("Con")) QueryTree (yyt->WhilePred.Con);
else if (yyyIsEqual ("Do")) QueryTree (yyt->WhilePred.Do);
break;
case kCallPred: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->CallPred.Next);
else if (yyyIsEqual ("IdList")) QueryTree (yyt->CallPred.IdList);
else if (yyyIsEqual ("InputBindList")) QueryTree (yyt->CallPred.InputBindList);
else if (yyyIsEqual ("OutputBindList")) QueryTree (yyt->CallPred.OutputBindList);
break;
case kChgOnly: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->ChgOnly.Next);
else if (yyyIsEqual ("NameList")) QueryTree (yyt->ChgOnly.NameList);
break;
case kDefined: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Defined.Next);
else if (yyyIsEqual ("Exp")) QueryTree (yyt->Defined.Exp);
break;
case kSchemaPred: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->SchemaPred.Next);
else if (yyyIsEqual ("Schema")) QueryTree (yyt->SchemaPred.Schema);
break;
case kBoolValue: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->BoolValue.Next);
break;
case kInputBind: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->InputBind.Next);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->InputBind.ExpressionList);
break;
case kOutputBind: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->OutputBind.Next);
else if (yyyIsEqual ("IdList")) QueryTree (yyt->OutputBind.IdList);
break;
case kDecl: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Decl.Next);
break;
case kVarDecl: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->VarDecl.Next);
else if (yyyIsEqual ("IdList")) QueryTree (yyt->VarDecl.IdList);
else if (yyyIsEqual ("Exp")) QueryTree (yyt->VarDecl.Exp);
break;
case kGivenSet: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->GivenSet.Next);
else if (yyyIsEqual ("IdList")) QueryTree (yyt->GivenSet.IdList);
break;
case kAxiomDecl: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->AxiomDecl.Next);
else if (yyyIsEqual ("FormalParams")) QueryTree (yyt->AxiomDecl.FormalParams);
else if (yyyIsEqual ("DeclList")) QueryTree (yyt->AxiomDecl.DeclList);
else if (yyyIsEqual ("PredList")) QueryTree (yyt->AxiomDecl.PredList);
break;
case kSchemaDef: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->SchemaDef.Next);
else if (yyyIsEqual ("FormalParams")) QueryTree (yyt->SchemaDef.FormalParams);
else if (yyyIsEqual ("DeclList")) QueryTree (yyt->SchemaDef.DeclList);
else if (yyyIsEqual ("PredList")) QueryTree (yyt->SchemaDef.PredList);
break;
case kAnnotation: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Annotation.Next);
else if (yyyIsEqual ("Decl")) QueryTree (yyt->Annotation.Decl);
break;
case kErgoAnno: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->ErgoAnno.Next);
break;
case kStateMachine: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->StateMachine.Next);
else if (yyyIsEqual ("IdList")) QueryTree (yyt->StateMachine.IdList);
break;
case kAbbreviation: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Abbreviation.Next);
else if (yyyIsEqual ("Exp")) QueryTree (yyt->Abbreviation.Exp);
break;
case kFunctionDecl: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->FunctionDecl.Next);
else if (yyyIsEqual ("DeclList")) QueryTree (yyt->FunctionDecl.DeclList);
else if (yyyIsEqual ("PredList")) QueryTree (yyt->FunctionDecl.PredList);
break;
case kFreeType: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->FreeType.Next);
else if (yyyIsEqual ("BranchList")) QueryTree (yyt->FreeType.BranchList);
break;
case kEnum: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Enum.Next);
else if (yyyIsEqual ("BranchList")) QueryTree (yyt->Enum.BranchList);
break;
case kImport: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Import.Next);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->Import.ExpressionList);
else if (yyyIsEqual ("RenameList")) QueryTree (yyt->Import.RenameList);
break;
case kModuleDecl: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->ModuleDecl.Next);
else if (yyyIsEqual ("Module")) QueryTree (yyt->ModuleDecl.Module);
break;
case kConstraint: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Constraint.Next);
else if (yyyIsEqual ("Pred")) QueryTree (yyt->Constraint.Pred);
break;
case kSchemaIncl: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->SchemaIncl.Next);
else if (yyyIsEqual ("IdList")) QueryTree (yyt->SchemaIncl.IdList);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->SchemaIncl.ExpressionList);
break;
case kVisibility: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Visibility.Next);
else if (yyyIsEqual ("SelectionList")) QueryTree (yyt->Visibility.SelectionList);
break;
case kBranch: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->Branch.Next);
break;
case kFTConstant: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->FTConstant.Next);
break;
case kFTConstructor: if (false) ;
else if (yyyIsEqual ("Next")) QueryTree (yyt->FTConstructor.Next);
else if (yyyIsEqual ("Exp")) QueryTree (yyt->FTConstructor.Exp);
break;
case kExpPred: if (false) ;
else if (yyyIsEqual ("Exp")) QueryTree (yyt->ExpPred.Exp);
break;
case kSchemaText: if (false) ;
else if (yyyIsEqual ("DeclList")) QueryTree (yyt->SchemaText.DeclList);
else if (yyyIsEqual ("PredList")) QueryTree (yyt->SchemaText.PredList);
break;
case kSchemaRef: if (false) ;
else if (yyyIsEqual ("IdList")) QueryTree (yyt->SchemaRef.IdList);
else if (yyyIsEqual ("ExpressionList")) QueryTree (yyt->SchemaRef.ExpressionList);
break;
case kSchemaCons: if (false) ;
else if (yyyIsEqual ("LogOp")) QueryTree (yyt->SchemaCons.LogOp);
else if (yyyIsEqual ("L")) QueryTree (yyt->SchemaCons.L);
else if (yyyIsEqual ("R")) QueryTree (yyt->SchemaCons.R);
break;
case kSchemaCompos: if (false) ;
else if (yyyIsEqual ("Sch1")) QueryTree (yyt->SchemaCompos.Sch1);
else if (yyyIsEqual ("Sch2")) QueryTree (yyt->SchemaCompos.Sch2);
break;
case kSchemaProj: if (false) ;
else if (yyyIsEqual ("Sch1")) QueryTree (yyt->SchemaProj.Sch1);
else if (yyyIsEqual ("Sch2")) QueryTree (yyt->SchemaProj.Sch2);
break;
case kSchemaSubst: if (false) ;
else if (yyyIsEqual ("Schema")) QueryTree (yyt->SchemaSubst.Schema);
else if (yyyIsEqual ("RenameList")) QueryTree (yyt->SchemaSubst.RenameList);
break;
case kSchemaHiding: if (false) ;
else if (yyyIsEqual ("Schema")) QueryTree (yyt->SchemaHiding.Schema);
else if (yyyIsEqual ("NameList")) QueryTree (yyt->SchemaHiding.NameList);
break;
    default: ;
    }
   }
  }
 }
}

void BeginTree ()
{
}

void CloseTree ()
{
}
