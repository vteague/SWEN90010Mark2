# ifndef yyZSyms
# define yyZSyms

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

/* line 10 "zsyms.ast" */

#include "Idents.h" 
#include "Positions.h"
#include "global.h" 
#include "env.h"


# ifndef bool
# define bool char
# endif
# define NoZSyms (tZSyms) 0L
# define kEnvirons 1
# define kno_env 2
# define kscope_env 3
# define kSymbols 4
# define kno_symbol 5
# define ksymbol 6
# define kSymbol 7
# define kvar 8
# define kgeneric 9
# define kschema 10
# define kZSymList 11
# define knoZSym 12
# define kzSym 13
# define kSumRenames 14
# define knoSumRename 15
# define ksumRename 16

typedef unsigned char ZSyms_tKind;
typedef unsigned short ZSyms_tMark;
typedef unsigned short ZSyms_tLabel;
typedef union ZSyms_Node * tZSyms;
typedef void (* ZSyms_tProcTree) ();
/* line 17 "zsyms.ast" */



# ifndef ZSyms_NodeHead
# define ZSyms_NodeHead
# endif
typedef struct { ZSyms_tKind yyKind; ZSyms_tMark yyMark; ZSyms_NodeHead } ZSyms_tNodeHead;
typedef struct { ZSyms_tNodeHead yyHead; } yEnvirons;
typedef struct { ZSyms_tNodeHead yyHead; } yno_env;
typedef struct { ZSyms_tNodeHead yyHead; tZSyms Symbols; tZSyms Outer; } yscope_env;
typedef struct { ZSyms_tNodeHead yyHead; } ySymbols;
typedef struct { ZSyms_tNodeHead yyHead; } yno_symbol;
typedef struct { ZSyms_tNodeHead yyHead; tZSyms Rest; tZSyms Symbol; tIdPos Sym; tIdPos schid; tIdPos modid; } ysymbol;
typedef struct { ZSyms_tNodeHead yyHead; } ySymbol;
typedef struct { ZSyms_tNodeHead yyHead; } yvar;
typedef struct { ZSyms_tNodeHead yyHead; tZSyms params; } ygeneric;
typedef struct { ZSyms_tNodeHead yyHead; tZSyms params; tZSyms locs; } yschema;
typedef struct { ZSyms_tNodeHead yyHead; } yZSymList;
typedef struct { ZSyms_tNodeHead yyHead; } ynoZSym;
typedef struct { ZSyms_tNodeHead yyHead; tIdPos Sym; tZSyms Next; } yzSym;
typedef struct { ZSyms_tNodeHead yyHead; } ySumRenames;
typedef struct { ZSyms_tNodeHead yyHead; } ynoSumRename;
typedef struct { ZSyms_tNodeHead yyHead; tZSyms Next; tIdPos zname; tIdPos sumname; } ysumRename;

union ZSyms_Node {
 ZSyms_tKind Kind;
 ZSyms_tNodeHead yyHead;
 yEnvirons Environs;
 yno_env no_env;
 yscope_env scope_env;
 ySymbols Symbols;
 yno_symbol no_symbol;
 ysymbol symbol;
 ySymbol Symbol;
 yvar var;
 ygeneric generic;
 yschema schema;
 yZSymList ZSymList;
 ynoZSym noZSym;
 yzSym zSym;
 ySumRenames SumRenames;
 ynoSumRename noSumRename;
 ysumRename sumRename;
};

extern tZSyms ZSymsRoot;
extern unsigned long ZSyms_HeapUsed;
extern char * ZSyms_PoolFreePtr, * ZSyms_PoolMaxPtr;
extern unsigned short ZSyms_NodeSize [16 + 1];
extern char * ZSyms_NodeName [16 + 1];

extern void (* ZSyms_Exit) ();
extern tZSyms ZSyms_Alloc ();
extern tZSyms MakeZSyms ARGS((ZSyms_tKind yyKind));
extern bool ZSyms_IsType ARGS((register tZSyms yyt, register ZSyms_tKind yyKind));

extern tZSyms nEnvirons ();
extern tZSyms nno_env ();
extern tZSyms nscope_env ();
extern tZSyms nSymbols ();
extern tZSyms nno_symbol ();
extern tZSyms nsymbol ();
extern tZSyms nSymbol ();
extern tZSyms nvar ();
extern tZSyms ngeneric ();
extern tZSyms nschema ();
extern tZSyms nZSymList ();
extern tZSyms nnoZSym ();
extern tZSyms nzSym ();
extern tZSyms nSumRenames ();
extern tZSyms nnoSumRename ();
extern tZSyms nsumRename ();

extern tZSyms mEnvirons ARGS(());
extern tZSyms mno_env ARGS(());
extern tZSyms mscope_env ARGS((tZSyms pSymbols, tZSyms pOuter));
extern tZSyms mSymbols ARGS(());
extern tZSyms mno_symbol ARGS(());
extern tZSyms msymbol ARGS((tZSyms pRest, tZSyms pSymbol, tIdPos pSym, tIdPos pschid, tIdPos pmodid));
extern tZSyms mSymbol ARGS(());
extern tZSyms mvar ARGS(());
extern tZSyms mgeneric ARGS((tZSyms pparams));
extern tZSyms mschema ARGS((tZSyms pparams, tZSyms plocs));
extern tZSyms mZSymList ARGS(());
extern tZSyms mnoZSym ARGS(());
extern tZSyms mzSym ARGS((tIdPos pSym, tZSyms pNext));
extern tZSyms mSumRenames ARGS(());
extern tZSyms mnoSumRename ARGS(());
extern tZSyms msumRename ARGS((tZSyms pNext, tIdPos pzname, tIdPos psumname));

extern void ReleaseZSyms ARGS((tZSyms yyt));
extern void ReleaseZSymsModule ();
extern void WriteZSymsNode ARGS((FILE * yyyf, tZSyms yyt));
extern void WriteZSyms ARGS((FILE * yyyf, tZSyms yyt));
extern tZSyms ReadZSyms ARGS((FILE * yyyf));
extern void PutZSyms ARGS((FILE * yyyf, tZSyms yyt));
extern tZSyms GetZSyms ARGS((FILE * yyyf));
extern void TraverseZSymsTD ARGS((tZSyms yyt, ZSyms_tProcTree yyyProc));
extern void TraverseZSymsBU ARGS((tZSyms yyt, ZSyms_tProcTree yyyProc));
extern tZSyms ReverseZSyms ARGS((tZSyms yyOld));
extern tZSyms CopyZSyms ARGS((tZSyms yyt));
extern bool CheckZSyms ARGS((tZSyms yyt));
extern void QueryZSyms ARGS((tZSyms yyt));
extern bool IsEqualZSyms ARGS((tZSyms yyt1, tZSyms yyt2));
extern void BeginZSyms ();
extern void CloseZSyms ();

# endif
