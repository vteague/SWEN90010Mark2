# include "ZSumAccess.h"
# include "yyZSumAccess.w"
# include "System.h"
# include <stdio.h>
# include "ZTree.h"
# include "Tree.h"
# include "ZSyms.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 21 "zsum.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "env.h"
#include "SumTreeAccess.h"
#include "ZTreeAccess.h"
#include "ZSymTabAccess.h"
struct maplet {
	char Zreserve[32];
	char Sumreserve[32];
} map[] = {
	"_Nat","nat",
/*	"_Natone","natural_1",*/
	"_Natone","nat_1",
	"_Integer","int",
	"_Real","real",
	"_div","div",
	"_mod","mod",
	"_succ","succ",
	"_EQUAL","=",
	"_neq","/=",
	"_LT","<",
	"_leq","<=",
	"_GT",">",
	"_geq",">=",
	"_STAR","*",
	"_plus","+",
	"_minus","-",
	"_LNOT","not",
	"_LAND","and",
	"_EOL","-EOL",
	"_LOR","or",
	"_ALL","forall",
	"_EXI","exists",
	"_EXIONE","exists_1",
	"_NEXI","nexi",
	"_IMP","=>",
	"_IFF","<=>",
	"_TRUE","true",
	"_FALSE","false",
	"_Boolean","bool",
	"_emptyset","{}",
	"_MEM","in",
	"_nmem","not_in",
	"_fset","finite",
	"_psetone","power_1",
	"_fsetone","finite_1",
	"_union","union",
	"_inter","inter",
	"_psubs","p_subset",
	"_subs","subset",
	"_min","min",
	"_max","max",
	"_SIZE_OF","#",
	"_duni","gen_union",
	"_dinter","gen_inter",
	"_upto","..",
	"_diff","diff",
	"_dom","dom",
	"_ran","ran",
	"_dres","dom_restrict",
	"_dsub","dom_subtract",
	"_rres","ran_restrict",
	"_rsub","ran_subtract",
	"_fovr","func_override",
	"_cmp","b_compose",
	"_fcmp","f_compose",
	"_LIMG","limg",
	"_id","id",
	"_inv","inverse",
	"_tcl","t_closure",
	"_rtcl","rt_closure",
	"_mapsto","|-->",
	"_rel","<-->",
	"_tfun","-->",
	"_tinj",">-->",
	"_tsur","-->>",
	"_pfun","-|->",
	"_pinj",">-|->",
	"_psur","-|->>",
	"_ffun","-||->",
	"_finj",">-||->",
	"_bij",">-->>",
	"_seq","seq",
	"_seqone","seq_1",
	"_emptyseq","{}",
	"_iseq","iseq",
	"_head","head",
	"_tail","tail",
	"_front","front",
	"_last","last",
	"_rev","rev",
	"_inseq","inseq",
	"_prefix","prefix",
	"_squash","squash",
	"_cat","^",
	"_extract","extract",
	"_filter","filter",
	"_partitions","partitions",
	"_disjoint","disjoint",
	"_suffix","suffix",
	"_ZPRED","zpred",
	"_PRE","pre",
	"_ZAND","and",
	"_ZOR","or",
	"_ZCMP","s_compose",
	"_ZEXI","exists",
	"_ZEXIONE","exists_1",
	"_ZALL","forall",
	"_ZNOT","no",
	"_ZIMP","=>",
	"_ZEQ","<=>",
	"_bag","bag",
	"_emptybag","{}",
	"_items","items",
	"_buni","bag_union",
	"_bagminus","bminus",
	"_bagmult","bmult",
	"_bagscale","bscale",
	"_bagmem","in_bag",
	"_subbag","bsub",
	"_GCH","ZGCH",
	"_PARALLEL","ZPARALLEL",
	"_BIGZCMP","DZCMP",
	"_BIGGCH","DGCH",
	"_BIGZAND","DZAND",
	"_BIGPARALLEL","DPARALLEL",
	"_CNJ","ZCNJ",
	"_negative","-",
	"_first","first",
	"_second","second",
	"_count","count",
	"XXX", "unknown"
};
#define maxmap (sizeof(map) / sizeof(struct maplet))


static void yyExit () { Exit (1); }

void (* ZSumAccess_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module ZSumAccess, routine %s failed\n", yyFunction);
 ZSumAccess_Exit ();
}

tString DeMap ARGS((tIdent id));
tPosition IdPosPos ARGS((tIdPos id));
tIdent IdPosId ARGS((tIdPos id));
tTree LogBinOpFromLogOp ARGS((tIdPos op));
bool SameIds ARGS((tIdPos id1, tIdPos id2));
bool NoTranslationErrors ARGS(());
tIdPos ModName ARGS((tZSyms yyP1, tIdPos cid));
static bool IsDelta ARGS((tIdPos id));
static bool IsXi ARGS((tIdPos id));
bool IsDeltaOrXi ARGS((tIdPos id));
tIdPos IdFromDeltaOrXiName ARGS((tIdPos id));
tIdPos PrimeName ARGS((tIdPos id));
tTree ChangesOnlyFromXiRefs ARGS((tZTree yyP2));
bool IsRenamed ARGS((tZTree yyP3));
tTree ExpListFromDesignator ARGS((tZTree yyP4, tIdPos name, tTree el, tIdPos modname, tIdPos cid));
tTree LogBinOpFromSchemaOp ARGS((tIdPos op));
static tTree RenameListFromRenameSeq ARGS((tZTree yyP5));
static tIdPos IdPosFromVarName ARGS((tZTree yyP6));
tTree MergePredsFromSchematext ARGS((tZSyms locs, tIdPos cid, bool schcalc));
static tTree MergeA ARGS((tZSyms locs, tTree pred, tIdPos cid, bool schcalc));
tZSyms AddIncludedLocals ARGS((tIdPos id, tZTree dec, tZSyms syms, tZSyms env));
static tZSyms AddIncludedLocalsA ARGS((tZSyms des, tZSyms syms));
static tZSyms AddIncludedLocalsB ARGS((tZSyms yyP7, tZSyms syms, tIdPos sch));
static tZSyms AddIncludedLocalsC ARGS((tZSyms des, tZSyms syms));
static tZSyms AddIncludedLocalsD ARGS((tZSyms yyP8, tZSyms syms, tIdPos sch));
tTree PredFromXi ARGS((tZTree yyP9, tZSyms syms, tZSyms env, tIdPos cid, tTree pred));
static tTree PredFromXiA ARGS((tZSyms yyP10, tIdPos cid, tTree pred));
static tTree PredFromXiB ARGS((tZSyms yyP11, tIdPos cid, tTree pred, tIdPos sch));
static tZSyms AddDecoratedLocalsA ARGS((tZSyms des, tZSyms syms, tZTree dec));
static tZSyms AddDecoratedLocals ARGS((tZSyms yyP12, tZSyms syms, tZTree dec, tIdPos sch));
tIdPos DecorateName ARGS((tIdPos id, tZTree dec));
bool InPreDefs ARGS((tIdPos id));
bool InSumRenamesZ ARGS((tZSyms yyP13, tIdPos id));
bool InSumRenamesSum ARGS((tZSyms yyP14, tIdPos id));
tIdPos SumNameForZName ARGS((tZSyms yyP15, tIdPos id));
static tIdPos PrefixName ARGS((tIdPos id));
tIdPos AllocateName ARGS((tZSyms locs, tZSyms env, tIdPos id));
tTree RenameSchemaForCompat ARGS((tZSyms rlocs, tZSyms llocs, tIdPos cid));
tIdPos ReWriteDeltaOrXi ARGS((tIdPos id));
bool IsPrefixOp ARGS((tTree yyP16));
tIdPos IdPosFromFncApp ARGS((tTree yyP17));

tString DeMap
# if defined __STDC__ | defined __cplusplus
(tIdent id)
# else
(id)
 tIdent id;
# endif
{
/* line 165 "zsum.puma" */
tString str;
/* line 166 "zsum.puma" */
  {
/* line 167 "zsum.puma" */
int i,found;
	char res[256],s[256];
	GetString(id,res);
	i = 0; found = 1;
	while ((found == 1) && (i <= maxmap))
	{	if (strcmp(res,map[i].Zreserve)==0)
		{	strcpy(s,map[i].Sumreserve);
			found = 0;}
		i++;}
	if (found == 1) {
		strcpy(s,res);}
	str = s;
  }
   return str;

}

tPosition IdPosPos
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 182 "zsum.puma" */
   return id . Pos;

}

tIdent IdPosId
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 186 "zsum.puma" */
   return id . Ident;

}

tTree LogBinOpFromLogOp
# if defined __STDC__ | defined __cplusplus
(tIdPos op)
# else
(op)
 tIdPos op;
# endif
{
/* line 190 "zsum.puma" */
tTree tree=mLogSeq();
/* line 191 "zsum.puma" */
  {
/* line 192 "zsum.puma" */
char str[256];
	GetString(op.Ident,str);
	if (strcmp(str,"_LAND")==0) tree = mLogAnd();
	if (strcmp(str,"_LOR")==0) tree = mLogOr();
	if (strcmp(str,"_IMP")==0) tree = mLogImply();
	if (strcmp(str,"_IFF")==0) tree = mLogEquiv();
  }
   return tree;

}

bool SameIds
# if defined __STDC__ | defined __cplusplus
(tIdPos id1, tIdPos id2)
# else
(id1, id2)
 tIdPos id1;
 tIdPos id2;
# endif
{
/* line 201 "zsum.puma" */
int found;
/* line 204 "zsum.puma" */
  {
/* line 206 "zsum.puma" */
char s1[256], s2[256]; 
	GetString(id1.Ident,s1);
	GetString(id2.Ident,s2);
	found = strcmp(s1,s2);

	
/* line 212 "zsum.puma" */
   if (! ((found == 0))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

bool NoTranslationErrors
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
/* line 216 "zsum.puma" */
  {
/* line 216 "zsum.puma" */
   if (! ((ErrorsInTranslation == 0))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

tIdPos ModName
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP1, tIdPos cid)
# else
(yyP1, cid)
 register tZSyms yyP1;
 tIdPos cid;
# endif
{
  if (yyP1->Kind == kno_symbol) {
/* line 220 "zsum.puma" */
   return cid;

  }
  if (yyP1->Kind == ksymbol) {
/* line 221 "zsum.puma" */
   return yyP1->symbol.modid;

  }
 yyAbort ("ModName");
}

static bool IsDelta
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 227 "zsum.puma" */
  {
/* line 228 "zsum.puma" */
char str[256];
	int found = 0;
	GetString(id.Ident,str);
	str[6] = '\0';
	if (strcmp(str,"_Delta")==0)
		found = 1;
/* line 234 "zsum.puma" */
   if (! ((found == 1))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

static bool IsXi
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 238 "zsum.puma" */
  {
/* line 239 "zsum.puma" */
char str[256];
	int found = 0;
	GetString(id.Ident,str);
	str[3] = '\0';
	if (strcmp(str,"_Xi")==0)
		found = 1;
/* line 245 "zsum.puma" */
   if (! ((found == 1))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

bool IsDeltaOrXi
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 249 "zsum.puma" */
  {
/* line 250 "zsum.puma" */
int found = 0;
	if (IsDelta(id)) found=1;
	if (IsXi(id)) found = 1;
/* line 253 "zsum.puma" */
   if (! ((found == 1))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

tIdPos IdFromDeltaOrXiName
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 256 "zsum.puma" */
tIdPos name;
/* line 257 "zsum.puma" */
  {
/* line 258 "zsum.puma" */
char str[256],str1[256];
	int len,i;
	name = id;
	GetString(id.Ident,str);
	if (IsDelta(id)) 
		{len = strlen(str)-6;
		for (i=0; i<len; i++) str1[i]=str[7+i];
		name = ZMakeIdPos(str1,id.Pos);}
	else if (IsXi(id)) 
		{len = strlen(str)-3;
		for (i=0; i<len; i++) str1[i]=str[4+i];
		name = ZMakeIdPos(str1,id.Pos);}
  }
   return name;

}

tIdPos PrimeName
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 272 "zsum.puma" */
tIdPos name;
/* line 273 "zsum.puma" */
  {
/* line 274 "zsum.puma" */
char str[256];
	int len;
	GetString(id.Ident,str);
	len = strlen(str);
	if (len>0)
		{str[len] = '\'';
		str[len+1] = '\0';
		name = ZMakeIdPos(str,id.Pos);}
	else name = NoIdPos;
  }
   return name;

}

tTree ChangesOnlyFromXiRefs
# if defined __STDC__ | defined __cplusplus
(register tZTree yyP2)
# else
(yyP2)
 register tZTree yyP2;
# endif
{
/* line 285 "zsum.puma" */
tTree tree;
  if (yyP2->Kind == kdecl) {
  if (yyP2->decl.BasicDecl->Kind == kschemaRef) {
/* line 286 "zsum.puma" */
  {
/* line 287 "zsum.puma" */
if (IsXi(yyP2->decl.BasicDecl->schemaRef.Designator->Designator.ZName->ZName.Ident))
			tree = mChgOnly(ChangesOnlyFromXiRefs(yyP2->decl.Next),mNoName());
		else tree = ChangesOnlyFromXiRefs(yyP2->decl.Next);
  }
   return tree;

  }
  }
/* line 290 "zsum.puma" */
   return mNoPred ();

}

bool IsRenamed
# if defined __STDC__ | defined __cplusplus
(register tZTree yyP3)
# else
(yyP3)
 register tZTree yyP3;
# endif
{
  if (yyP3->Designator.RenameSeq->Kind == krenames) {
/* line 294 "zsum.puma" */
   return true;

  }
  return false;
}

tTree ExpListFromDesignator
# if defined __STDC__ | defined __cplusplus
(register tZTree yyP4, tIdPos name, register tTree el, tIdPos modname, tIdPos cid)
# else
(yyP4, name, el, modname, cid)
 register tZTree yyP4;
 tIdPos name;
 register tTree el;
 tIdPos modname;
 tIdPos cid;
# endif
{
/* line 297 "zsum.puma" */
tTree tree;
/* line 298 "zsum.puma" */
  {
/* line 299 "zsum.puma" */
tTree idtree,modtree,itree,schtree;
/*********** sum calls a name without any actual instantiation of generic parameters a variable!!!, only schema refs have parameters!!!***********/
		idtree = mId(mNoId(),IdDecCat(name,yyP4->Designator.Decoration),ID);
		modtree = mId(idtree,modname,ID);
		if (SameIds(modname,cid)) 
			itree = idtree;
		else
			itree = modtree;
	
/********* can lose renamed schema references ************/
	
		if (ZTree_IsType(yyP4->Designator.ExpressionSeq,kexpSeq))  
			{if (yyP4->Designator.IsSchemaRef)
				tree = mExp_SchemaRef(mNoExp(),itree,el);
			else
				{Message("variable has been interpreted as a schema reference",4,yyP4->Designator.ZName->ZName.Ident.Pos);
				if (IsEmptySet(name))
					tree = mSetElab(mNoExp(),mNoExp());
				else tree = mExp_SchemaRef(mNoExp(),itree,el);}}
		else 
			{if (yyP4->Designator.IsSchemaRef)
				tree = mVariable(mNoExp(),itree);
			else
				{if (IsEmptySet(name))
					tree = mSetElab(mNoExp(),mNoExp());
				else tree = mVariable(mNoExp(),itree);}}
  }
   return tree;

}

tTree LogBinOpFromSchemaOp
# if defined __STDC__ | defined __cplusplus
(tIdPos op)
# else
(op)
 tIdPos op;
# endif
{
/* line 329 "zsum.puma" */
tTree tree=mSDisjunction();
/* line 330 "zsum.puma" */
  {
/* line 331 "zsum.puma" */
char str[256];
	GetString(op.Ident,str);
	if (strcmp(str,"_ZOR")==0)
		tree = mLogOr();
	if (strcmp(str,"_ZAND")==0)
		tree = mLogAnd();
	if (strcmp(str,"_ZIMP")==0)
		tree = mLogImply();
	if (strcmp(str,"_ZEQ")==0)
		tree = mLogEquiv();
  }
   return tree;

}

static tTree RenameListFromRenameSeq
# if defined __STDC__ | defined __cplusplus
(register tZTree yyP5)
# else
(yyP5)
 register tZTree yyP5;
# endif
{
  if (yyP5->Kind == knoRename) {
/* line 344 "zsum.puma" */
   return mNoRename ();

  }
  if (yyP5->Kind == krenames) {
/* line 345 "zsum.puma" */
   return mRename (RenameListFromRenameSeq (yyP5->renames.Next), IdPosFromVarName (yyP5->renames.VarRename->VarRename.New), mId (mNoId (), IdPosFromVarName (yyP5->renames.VarRename->VarRename.Old), ID));

  }
 yyAbort ("RenameListFromRenameSeq");
}

static tIdPos IdPosFromVarName
# if defined __STDC__ | defined __cplusplus
(register tZTree yyP6)
# else
(yyP6)
 register tZTree yyP6;
# endif
{
/* line 350 "zsum.puma" */
   return ZMakeIdPos (DeMap (IdDecCat (yyP6->VarName.Ident, yyP6->VarName.Decoration) . Ident), yyP6->VarName.Ident . Pos);

}

tTree MergePredsFromSchematext
# if defined __STDC__ | defined __cplusplus
(register tZSyms locs, tIdPos cid, bool schcalc)
# else
(locs, cid, schcalc)
 register tZSyms locs;
 tIdPos cid;
 bool schcalc;
# endif
{
/* line 354 "zsum.puma" */
tTree tree;
/* line 355 "zsum.puma" */
   return MergeA (locs, mNoPred (), cid, schcalc);

}

static tTree MergeA
# if defined __STDC__ | defined __cplusplus
(register tZSyms locs, register tTree pred, tIdPos cid, bool schcalc)
# else
(locs, pred, cid, schcalc)
 register tZSyms locs;
 register tTree pred;
 tIdPos cid;
 bool schcalc;
# endif
{
/* line 357 "zsum.puma" */
tTree tree;
  if (locs->Kind == kno_symbol) {
/* line 358 "zsum.puma" */
   return pred;

  }
  if (locs->Kind == ksymbol) {
/* line 359 "zsum.puma" */
  {
/* line 360 "zsum.puma" */
tZSyms t;
		tTree il1,il2,il3,il4;
		t = LocalLookup(locs->symbol.Sym,locs->symbol.Rest);
		
		if (ZSyms_IsType(t,kno_symbol))
			tree = MergeA(locs->symbol.Rest,pred,cid,schcalc);

		else if (SameIds(ModName(t,cid),cid)&&SameIds(SchemaName(t),locs->symbol.schid))
			tree = MergeA(locs->symbol.Rest,pred,cid,schcalc);
		else if (schcalc && SameIds(ModName(t,cid),cid))
			tree = MergeA(locs->symbol.Rest,pred,cid,schcalc);

		else
			{il3 = mId(mId(mNoId(),locs->symbol.Sym,ID),locs->symbol.schid,ID);
			if (SameIds(NoIdPos,locs->symbol.schid))
				il3 = mId(mNoId(),locs->symbol.Sym,ID);
			if (SameIds(locs->symbol.modid,cid)) 
				il1 = il3;
			else
				il1 = mId(il3,locs->symbol.modid,ID);
			il4 = mId(mId(mNoId(),locs->symbol.Sym,ID),SchemaName(t),ID);
			if (SameIds(NoIdPos,SchemaName(t)))
				il4 = mId(mNoId(),locs->symbol.Sym,ID);
			if (SameIds(ModName(t,cid),cid))
				il2 = il4;
			else
				il2 = mId(il4,ModName(t,cid),ID);
			tree = MergeA(locs->symbol.Rest,mRelBinPred(pred,mVariable(mNoExp(),il1),ZMakeIdPos("=",NoPosition),mVariable(mNoExp(),il2)),cid,schcalc);}
  }
   return tree;

  }
 yyAbort ("MergeA");
}

tZSyms AddIncludedLocals
# if defined __STDC__ | defined __cplusplus
(tIdPos id, register tZTree dec, register tZSyms syms, register tZSyms env)
# else
(id, dec, syms, env)
 tIdPos id;
 register tZTree dec;
 register tZSyms syms;
 register tZSyms env;
# endif
{
/* line 392 "zsum.puma" */
tZSyms tree;
  if (dec->Kind == knoDecoration) {
/* line 393 "zsum.puma" */
  {
/* line 394 "zsum.puma" */
tZSyms s;
		tIdPos name;
		s = TotalLookup(id,syms,env);
		if (ZSyms_IsType(s,kno_symbol))
		
			{if (IsDeltaOrXi(id))
				{name = IdFromDeltaOrXiName(id);
				tree = AddIncludedLocalsC(TotalLookup(name,syms,env),syms);}
			else tree = syms;}
		else
			tree = AddIncludedLocalsA(s,syms);
  }
   return tree;

  }
  if (dec->Kind == kdecoration) {
/* line 405 "zsum.puma" */
  {
/* line 406 "zsum.puma" */
tZSyms s;
		tIdPos name;
		char str[32];
		s = TotalLookup(id,syms,env);
		if (ZSyms_IsType(s,kno_symbol))
			tree = syms;
		else
		
			{tree = AddDecoratedLocalsA(s,syms,dec);}
  }
   return tree;

  }
 yyAbort ("AddIncludedLocals");
}

static tZSyms AddIncludedLocalsA
# if defined __STDC__ | defined __cplusplus
(register tZSyms des, register tZSyms syms)
# else
(des, syms)
 register tZSyms des;
 register tZSyms syms;
# endif
{
  if (des->Kind == ksymbol) {
  if (des->symbol.Symbol->Kind == kschema) {
/* line 418 "zsum.puma" */
   return AddIncludedLocalsB (des->symbol.Symbol->schema.locs, syms, des->symbol.Sym);

  }
  }
/* line 420 "zsum.puma" */
   return syms;

}

static tZSyms AddIncludedLocalsB
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP7, register tZSyms syms, tIdPos sch)
# else
(yyP7, syms, sch)
 register tZSyms yyP7;
 register tZSyms syms;
 tIdPos sch;
# endif
{
/* line 423 "zsum.puma" */
tZSyms tree;
  if (yyP7->Kind == kno_symbol) {
/* line 424 "zsum.puma" */
   return syms;

  }
  if (yyP7->Kind == ksymbol) {
/* line 425 "zsum.puma" */
  {
/* line 426 "zsum.puma" */
if (SameIds(NoIdPos,yyP7->symbol.schid))
			tree = AddIncludedLocalsB(yyP7->symbol.Rest,msymbol(syms,CopyZSyms(yyP7->symbol.Symbol),yyP7->symbol.Sym,sch,yyP7->symbol.modid),sch);
		else tree = AddIncludedLocalsB(yyP7->symbol.Rest,msymbol(syms,CopyZSyms(yyP7->symbol.Symbol),yyP7->symbol.Sym,yyP7->symbol.schid,yyP7->symbol.modid),sch);
  }
   return tree;

  }
 yyAbort ("AddIncludedLocalsB");
}

static tZSyms AddIncludedLocalsC
# if defined __STDC__ | defined __cplusplus
(register tZSyms des, register tZSyms syms)
# else
(des, syms)
 register tZSyms des;
 register tZSyms syms;
# endif
{
  if (des->Kind == ksymbol) {
  if (des->symbol.Symbol->Kind == kschema) {
/* line 432 "zsum.puma" */
   return AddIncludedLocalsD (des->symbol.Symbol->schema.locs, syms, des->symbol.Sym);

  }
  }
/* line 434 "zsum.puma" */
   return syms;

}

static tZSyms AddIncludedLocalsD
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP8, register tZSyms syms, tIdPos sch)
# else
(yyP8, syms, sch)
 register tZSyms yyP8;
 register tZSyms syms;
 tIdPos sch;
# endif
{
/* line 437 "zsum.puma" */
tZSyms tree;
  if (yyP8->Kind == kno_symbol) {
/* line 438 "zsum.puma" */
   return syms;

  }
  if (yyP8->Kind == ksymbol) {
/* line 439 "zsum.puma" */
  {
/* line 440 "zsum.puma" */
tIdPos pname1,pname2;
		pname1 = PrimeName(yyP8->symbol.Sym);
		if (SameIds(NoIdPos,yyP8->symbol.schid))
			{pname2 = PrimeName(sch);
			tree = AddIncludedLocalsD(yyP8->symbol.Rest,msymbol(msymbol(syms,CopyZSyms(yyP8->symbol.Symbol),yyP8->symbol.Sym,sch,yyP8->symbol.modid),CopyZSyms(yyP8->symbol.Symbol),pname1,pname2,yyP8->symbol.modid),sch);}
		else
			{pname2 = PrimeName(yyP8->symbol.schid);
			tree = AddIncludedLocalsD(yyP8->symbol.Rest,msymbol(msymbol(syms,CopyZSyms(yyP8->symbol.Symbol),yyP8->symbol.Sym,yyP8->symbol.schid,yyP8->symbol.modid),CopyZSyms(yyP8->symbol.Symbol),pname1,pname2,yyP8->symbol.modid),sch);}
  }
   return tree;

  }
 yyAbort ("AddIncludedLocalsD");
}

tTree PredFromXi
# if defined __STDC__ | defined __cplusplus
(register tZTree yyP9, register tZSyms syms, register tZSyms env, tIdPos cid, register tTree pred)
# else
(yyP9, syms, env, cid, pred)
 register tZTree yyP9;
 register tZSyms syms;
 register tZSyms env;
 tIdPos cid;
 register tTree pred;
# endif
{
/* line 452 "zsum.puma" */
tTree tree;
  if (yyP9->Kind == kdecl) {
  if (yyP9->decl.BasicDecl->Kind == kschemaRef) {
/* line 453 "zsum.puma" */
  {
/* line 454 "zsum.puma" */
tZSyms s;
	s = TotalLookup(yyP9->decl.BasicDecl->schemaRef.Designator->Designator.ZName->ZName.Ident,syms,env);
	if (ZSyms_IsType(s,kno_symbol) && IsXi(yyP9->decl.BasicDecl->schemaRef.Designator->Designator.ZName->ZName.Ident))

		tree = PredFromXi(yyP9->decl.Next,syms,env,cid,PredFromXiA(TotalLookup(IdFromDeltaOrXiName(yyP9->decl.BasicDecl->schemaRef.Designator->Designator.ZName->ZName.Ident),syms,env),cid,pred));
	else
		tree = PredFromXi(yyP9->decl.Next,syms,env,cid,pred);
  }
   return tree;

  }
/* line 461 "zsum.puma" */
  {
/* line 462 "zsum.puma" */
tree = PredFromXi(yyP9->decl.Next,syms,env,cid,pred);
  }
   return tree;

  }
  if (yyP9->Kind == knoDecl) {
/* line 463 "zsum.puma" */
  {
/* line 463 "zsum.puma" */
tree = pred;
  }
   return tree;

  }
 yyAbort ("PredFromXi");
}

static tTree PredFromXiA
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP10, tIdPos cid, register tTree pred)
# else
(yyP10, cid, pred)
 register tZSyms yyP10;
 tIdPos cid;
 register tTree pred;
# endif
{
/* line 467 "zsum.puma" */
tTree tree;
  if (yyP10->Kind == ksymbol) {
  if (yyP10->symbol.Symbol->Kind == kschema) {
/* line 468 "zsum.puma" */
   return PredFromXiB (yyP10->symbol.Symbol->schema.locs, cid, pred, yyP10->symbol.Sym);

  }
  }
/* line 470 "zsum.puma" */
  {
/* line 470 "zsum.puma" */
tree = pred;
  }
   return tree;

}

static tTree PredFromXiB
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP11, tIdPos cid, register tTree pred, tIdPos sch)
# else
(yyP11, cid, pred, sch)
 register tZSyms yyP11;
 tIdPos cid;
 register tTree pred;
 tIdPos sch;
# endif
{
/* line 474 "zsum.puma" */
tTree tree;
  if (yyP11->Kind == ksymbol) {
/* line 475 "zsum.puma" */
  {
/* line 476 "zsum.puma" */
tIdPos sidprime,schprime;
		tTree il1,il2,il3,il4;
		
		sidprime = PrimeName(yyP11->symbol.Sym);
		
		schprime = PrimeName(sch);
		
		il3 = mId(mId(mNoId(),yyP11->symbol.Sym,ID),sch,ID);
		il4 = mId(mId(mNoId(),sidprime,ID),schprime,ID);
		
		if (SameIds(yyP11->symbol.modid,cid))
			{
			il1 = mId(mNoId(),yyP11->symbol.Sym,ID);
			il2 = mId(mNoId(),sidprime,ID);}
		else 
			{il1 = mId(il3,yyP11->symbol.modid,ID);

			il2 = mId(il4,yyP11->symbol.modid,ID);}

		tree = PredFromXiB(yyP11->symbol.Rest,cid,mRelBinPred(pred,mVariable(mNoExp(),il1),ZMakeIdPos("=",NoPosition),mVariable(mNoExp(),il2)),sch);
  }
   return tree;

  }
/* line 496 "zsum.puma" */
  {
/* line 496 "zsum.puma" */
tree = pred;
  }
   return tree;

}

static tZSyms AddDecoratedLocalsA
# if defined __STDC__ | defined __cplusplus
(register tZSyms des, register tZSyms syms, register tZTree dec)
# else
(des, syms, dec)
 register tZSyms des;
 register tZSyms syms;
 register tZTree dec;
# endif
{
  if (des->Kind == ksymbol) {
  if (des->symbol.Symbol->Kind == kschema) {
/* line 500 "zsum.puma" */
   return AddDecoratedLocals (des->symbol.Symbol->schema.locs, syms, dec, des->symbol.Sym);

  }
  }
/* line 502 "zsum.puma" */
   return syms;

}

static tZSyms AddDecoratedLocals
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP12, register tZSyms syms, register tZTree dec, tIdPos sch)
# else
(yyP12, syms, dec, sch)
 register tZSyms yyP12;
 register tZSyms syms;
 register tZTree dec;
 tIdPos sch;
# endif
{
/* line 505 "zsum.puma" */
tZSyms tree;
  if (yyP12->Kind == kno_symbol) {
/* line 506 "zsum.puma" */
   return syms;

  }
  if (yyP12->Kind == ksymbol) {
/* line 507 "zsum.puma" */
  {
/* line 508 "zsum.puma" */
if (SameIds(NoIdPos,yyP12->symbol.schid))
			tree = AddDecoratedLocals(yyP12->symbol.Rest,msymbol(syms,CopyZSyms(yyP12->symbol.Symbol),DecorateName(yyP12->symbol.Sym,dec),DecorateName(sch,dec),yyP12->symbol.modid),dec,sch);
		else
			tree = AddDecoratedLocals(yyP12->symbol.Rest,msymbol(syms,CopyZSyms(yyP12->symbol.Symbol),DecorateName(yyP12->symbol.Sym,dec),DecorateName(yyP12->symbol.schid,dec),yyP12->symbol.modid),dec,sch);
  }
   return tree;

  }
 yyAbort ("AddDecoratedLocals");
}

tIdPos DecorateName
# if defined __STDC__ | defined __cplusplus
(tIdPos id, register tZTree dec)
# else
(id, dec)
 tIdPos id;
 register tZTree dec;
# endif
{
/* line 514 "zsum.puma" */
tIdPos sym;
/* line 515 "zsum.puma" */
  {
/* line 516 "zsum.puma" */
char str[256],decstr[256];
	GetString(id.Ident,str);
	StrokeCat(dec,decstr);
	strcat(str,decstr);
	sym = ZMakeIdPos(str,id.Pos);
  }
   return sym;

}

bool InPreDefs
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 524 "zsum.puma" */
  {
/* line 525 "zsum.puma" */
char str[256];
	int i,done;
	i=0; done=0;
	GetString(id.Ident,str);
	while ((done==0) && (i<maxmap))
		{if (strcmp(str,map[i].Sumreserve)==0)
			done=1;
		else i++;}
/* line 533 "zsum.puma" */
   if (! ((done == 1))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

bool InSumRenamesZ
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP13, tIdPos id)
# else
(yyP13, id)
 register tZSyms yyP13;
 tIdPos id;
# endif
{
  if (yyP13->Kind == ksumRename) {
/* line 537 "zsum.puma" */
  {
/* line 538 "zsum.puma" */
   if (! ((SameIds (yyP13->sumRename.zname, id) || InSumRenamesZ (yyP13->sumRename.Next, id)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  return false;
}

bool InSumRenamesSum
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP14, tIdPos id)
# else
(yyP14, id)
 register tZSyms yyP14;
 tIdPos id;
# endif
{
  if (yyP14->Kind == ksumRename) {
/* line 542 "zsum.puma" */
  {
/* line 543 "zsum.puma" */
   if (! ((SameIds (yyP14->sumRename.sumname, id) || InSumRenamesSum (yyP14->sumRename.Next, id)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  return false;
}

tIdPos SumNameForZName
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP15, tIdPos id)
# else
(yyP15, id)
 register tZSyms yyP15;
 tIdPos id;
# endif
{
/* line 546 "zsum.puma" */
tIdPos sym;
  if (yyP15->Kind == knoSumRename) {
/* line 547 "zsum.puma" */
   return id;

  }
  if (yyP15->Kind == ksumRename) {
/* line 548 "zsum.puma" */
  {
/* line 549 "zsum.puma" */
if (SameIds(id,yyP15->sumRename.zname))
			sym = yyP15->sumRename.sumname;
		else
			sym = SumNameForZName(yyP15->sumRename.Next,id);
  }
   return sym;

  }
 yyAbort ("SumNameForZName");
}

static tIdPos PrefixName
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 555 "zsum.puma" */
tIdPos sym;
/* line 556 "zsum.puma" */
  {
/* line 557 "zsum.puma" */
char str[256],str1[256];
	strcpy(str,"z");
	GetString(id.Ident,str1);
	strcat(str,str1);
	sym = ZMakeIdPos(str,id.Pos);
  }
   return sym;

}

tIdPos AllocateName
# if defined __STDC__ | defined __cplusplus
(register tZSyms locs, register tZSyms env, tIdPos id)
# else
(locs, env, id)
 register tZSyms locs;
 register tZSyms env;
 tIdPos id;
# endif
{
/* line 564 "zsum.puma" */
tIdPos sym;
/* line 565 "zsum.puma" */
  {
/* line 566 "zsum.puma" */
int done,term;
	char str[256];
	GetString(id.Ident,str);
	done=0;term=strlen(str);
	sym = id;
	while ((done==0) && (term<255))
		{sym = PrefixName(sym);
		if (InPreDefs(sym) || InWholeTable(sym,locs,env)) term++;
		else done=1;}
	
  }
   return sym;

}

tTree RenameSchemaForCompat
# if defined __STDC__ | defined __cplusplus
(register tZSyms rlocs, register tZSyms llocs, tIdPos cid)
# else
(rlocs, llocs, cid)
 register tZSyms rlocs;
 register tZSyms llocs;
 tIdPos cid;
# endif
{
/* line 579 "zsum.puma" */
tTree rlist;
  if (rlocs->Kind == kno_symbol) {
/* line 583 "zsum.puma" */
   return mNoRename ();

  }
  if (llocs->Kind == kno_symbol) {
/* line 584 "zsum.puma" */
   return mNoRename ();

  }
  if (llocs->Kind == ksymbol) {
/* line 585 "zsum.puma" */
  {
/* line 586 "zsum.puma" */
tZSyms t;
		t = LocalLookup(llocs->symbol.Sym,rlocs);
		if (ZSyms_IsType(t,kno_symbol))
		   rlist = RenameSchemaForCompat(rlocs,llocs->symbol.Rest,cid);
		else
		   {if (SameIds(ModName(t,cid),llocs->symbol.modid))
		      rlist = RenameSchemaForCompat(rlocs,llocs->symbol.Rest,cid);
		   else
		      rlist = mRename(RenameSchemaForCompat(rlocs,llocs->symbol.Rest,cid),llocs->symbol.Sym,mId(mId(mNoId(),llocs->symbol.Sym,ID),llocs->symbol.modid,ID));}
  }
   return rlist;

  }
 yyAbort ("RenameSchemaForCompat");
}

tIdPos ReWriteDeltaOrXi
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 597 "zsum.puma" */
tIdPos newid;
/* line 598 "zsum.puma" */
  {
/* line 599 "zsum.puma" */
char str[256],str1[256];
	int i,len;
	GetString(id.Ident,str);
	len = strlen(str);
	
	for (i=0;i<len;i++)
		str1[i] = str[i+1];
	
	if (IsDelta(id))
		str1[5] = '_';
	if (IsXi(id))
		str1[2] = '_';
	
	newid = ZMakeIdPos(str1,id.Pos);
  }
   return newid;

}

bool IsPrefixOp
# if defined __STDC__ | defined __cplusplus
(register tTree yyP16)
# else
(yyP16)
 register tTree yyP16;
# endif
{
/* line 616 "zsum.puma" */
bool check=false;
  if (yyP16->Kind == kVariable) {
  if (yyP16->Variable.IdList->Kind == kId) {
  if (yyP16->Variable.IdList->Id.Next->Kind == kNoId) {
/* line 617 "zsum.puma" */
  {
/* line 618 "zsum.puma" */
if (SameIds(yyP16->Variable.IdList->Id.Ident,ZMakeIdPos("dom",NoPosition))) check=true;
	if (SameIds(yyP16->Variable.IdList->Id.Ident,ZMakeIdPos("ran",NoPosition))) check=true;
	if (SameIds(yyP16->Variable.IdList->Id.Ident,ZMakeIdPos("#",NoPosition))) check=true;
	if (SameIds(yyP16->Variable.IdList->Id.Ident,ZMakeIdPos("rev",NoPosition))) check=true;
	if (SameIds(yyP16->Variable.IdList->Id.Ident,ZMakeIdPos("gen_inter",NoPosition))) check=true;
	if (SameIds(yyP16->Variable.IdList->Id.Ident,ZMakeIdPos("gen_union",NoPosition))) check=true;
/* line 624 "zsum.puma" */
   if (! ((check))) goto yyL1;
  }
   return true;
yyL1:;

  }
  }
  }
  return false;
}

tIdPos IdPosFromFncApp
# if defined __STDC__ | defined __cplusplus
(register tTree yyP17)
# else
(yyP17)
 register tTree yyP17;
# endif
{
/* line 628 "zsum.puma" */
tIdPos name=NoIdPos;
  if (yyP17->Kind == kNoExp) {
/* line 629 "zsum.puma" */
   return name;

  }
  if (yyP17->Kind == kVariable) {
  if (yyP17->Variable.IdList->Kind == kId) {
  if (yyP17->Variable.IdList->Id.Next->Kind == kNoId) {
/* line 630 "zsum.puma" */
   return yyP17->Variable.IdList->Id.Ident;

  }
  }
  }
/* line 631 "zsum.puma" */
   return name;

}

void BeginZSumAccess ()
{
}

void CloseZSumAccess ()
{
}
