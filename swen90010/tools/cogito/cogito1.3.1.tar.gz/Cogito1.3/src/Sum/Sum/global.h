/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
/* 
Version: $Id: global.h,v 1.5 2000/03/22 04:06:30 cogito Exp $
*/

#ifndef yyglobal
#define yyglobal 

#include "Idents.h"
#include "Positions.h"

#define IDENT_LENGTH 127 


/* Base types and constants
 */
#define Ident_int     MakeIdent("int", 3)
#define Ident_nat_1   MakeIdent("nat_1", 5)
#define Ident_nat     MakeIdent("nat", 3)
#define Ident_bool    MakeIdent("bool", 4)
#define Ident_true    MakeIdent("true", 4)
#define Ident_false   MakeIdent("false", 5)
#define Ident_char    MakeIdent("char", 4)
#define Ident_string  MakeIdent("string", 6)
#define Ident_math    MakeIdent("math", 4)
#define Ident_natural_1       MakeIdent("natural_1", 9)
#define Ident_integer_first   MakeIdent("integer_first",13)
#define Ident_integer_last    MakeIdent("integer_last",12)
#define Ident_integer         MakeIdent("integer",7)

/* Prefix operators
 */
#define Ident_dom      MakeIdent("dom", 3)
#define Ident_ran      MakeIdent("ran", 3)
#define Ident_seq      MakeIdent("seq", 3)
#define Ident_iseq     MakeIdent("iseq", 4)
#define Ident_seq_1    MakeIdent("seq_1", 5)
#define Ident_bag      MakeIdent("bag", 3)
#define Ident_id       MakeIdent("id", 2)
#define Ident_finite   MakeIdent("finite", 6)
#define Ident_finite_1 MakeIdent("finite_1", 8)
#define Ident_power    MakeIdent("power", 5)
#define Ident_power_1  MakeIdent("power_1", 7)
#define Ident_disjoint MakeIdent("disjoint", 8)
#define Ident_card     MakeIdent("#", 1)
#define Ident_gen_inter    MakeIdent("gen_inter", 9)
#define Ident_gen_union    MakeIdent("gen_union", 9)
#define Ident_rev      MakeIdent("rev", 3)


/* Infix operators
 */
#define Ident_relation  MakeIdent("<-->", 4)
#define Ident_partfunc  MakeIdent("-|->", 4)
#define Ident_totalfunc MakeIdent("-->", 3)
#define Ident_partinj   MakeIdent(">-|->", 5)
#define Ident_totalinj  MakeIdent(">-->", 4)
#define Ident_partsur   MakeIdent("-|->>", 5)
#define Ident_totalsur  MakeIdent("-->>", 4)
#define Ident_bij       MakeIdent(">-->>", 5)
#define Ident_fpartfunc MakeIdent("-||->", 5)
#define Ident_fpartinj  MakeIdent(">-||->", 6)
#define Ident_upto      MakeIdent("..", 2)
#define Ident_concat    MakeIdent("^", 1)
#define Ident_maplet    MakeIdent("|-->", 4)
#define Ident_bag_union MakeIdent("bag_union", 9)
#define Ident_inter     MakeIdent("inter", 5)
#define Ident_union     MakeIdent("union", 5)
#define Ident_diff      MakeIdent("diff", 4)
#define Ident_f_compose   MakeIdent("f_compose", 9)
#define Ident_func_override MakeIdent("func_override", 13)
#define Ident_dom_restrict  MakeIdent("dom_restrict", 12)
#define Ident_ran_restrict  MakeIdent("ran_restrict", 12)
#define Ident_dom_subtract  MakeIdent("dom_subtract", 12)
#define Ident_ran_subtract  MakeIdent("ran_subtract", 12)
#define Ident_sym_diff  MakeIdent("sym_diff",8)

/* Binary relational operators
 */
#define Ident_equal   MakeIdent("=", 1)
#define Ident_notequ  MakeIdent("/=", 2)
#define Ident_in      MakeIdent("in", 2)
#define Ident_in_bag  MakeIdent("in_bag", 6)
#define Ident_not_in  MakeIdent("not_in", 6)
#define Ident_grt     MakeIdent(">", 1)
#define Ident_less    MakeIdent("<", 1)
#define Ident_notless MakeIdent(">=", 2) 
#define Ident_notgrt  MakeIdent("<=", 2)
#define Ident_subset  MakeIdent("subset", 6)
#define Ident_p_subset   MakeIdent("p_subset", 8)
#define Ident_partitions MakeIdent("partitions", 10)
#define Ident_inverse    MakeIdent("inverse", 7)
#define Ident_iter       MakeIdent("iter", 4)
#define Ident_t_closure  MakeIdent("t_closure", 9)
#define Ident_rt_closure MakeIdent("rt_closure", 10)

/* arithmatic operators 
 */
#define Ident_add  MakeIdent("+", 1)
#define Ident_sub  MakeIdent("-", 1)
#define Ident_mult MakeIdent("*", 1)
#define Ident_div  MakeIdent("div", 3)
#define Ident_mod  MakeIdent("mod", 3)
#define Ident_expo MakeIdent("**", 2)

/*
 * computational integer operations for IL 
 */

#define Ident_subc  MakeIdent("subc", 4)
#define Ident_addc  MakeIdent("addc", 4)
#define Ident_multc  MakeIdent("multc", 5)
#define Ident_divc  MakeIdent("divc", 4)
#define Ident_modc  MakeIdent("modc", 4)
#define Ident_expc  MakeIdent("expc", 4)
#define Ident_ltc  MakeIdent("ltc", 3)
#define Ident_ltec  MakeIdent("ltec", 4)
#define Ident_gtc  MakeIdent("gtc", 3)
#define Ident_gtec  MakeIdent("gtec", 4)
#define Ident_eqc   MakeIdent("eqc", 3)
#define Ident_neqc  MakeIdent("neqc", 4)
#define Ident_andc  MakeIdent("andc", 4)
#define Ident_orc  MakeIdent("orc", 3)
#define Ident_xorc  MakeIdent("xorc", 4)
#define Ident_notc  MakeIdent("notc", 4)
#define Ident_uptoc  MakeIdent("uptoc", 5)

/*  IL array operators */

#define Ident_array  MakeIdent("array", 5)

/* Auxiliary symbols
 */
#define Ident_pre          MakeIdent("pre", 3)
#define Ident_changes_only MakeIdent("changes_only", 12)

/* Standard math toolkit functions 
 */
#define Ident_head   MakeIdent("head", 4)
#define Ident_tail   MakeIdent("tail", 4)
#define Ident_front  MakeIdent("front", 5)
#define Ident_last   MakeIdent("last", 4)
#define Ident_first  MakeIdent("first", 5)
#define Ident_second MakeIdent("second", 6)
#define Ident_count  MakeIdent("count", 5)

/* Quantifiers
 */
#define Ident_forall   MakeIdent("forall", 6)
#define Ident_exists   MakeIdent("exists", 6)
#define Ident_exists_1 MakeIdent("exists_1", 8)
#define Ident_var      MakeIdent("var", 3)
#define Ident_sm_1     MakeIdent("sm_1", 4)
#define Ident_let      MakeIdent("let", 3)

/* Reserved schema names
 */
#define Ident_state MakeIdent("state", 5)
#define Ident_init  MakeIdent("init", 4)

/* Special Ada Library Names
 */

#define Ident_INTIO   MakeIdent("Integer_IO", 10)

/* newident for backward compose */

#define Ident_b_compose    MakeIdent("b_compose", 9)

/* ID and OPNAME are used for attribute IdKind of Id tree node 
 */
#define ID       1
#define OPNAME   2

/* Semantic error messages 
 */

/* error2 is to report the type imcompatibility among a list of expressions
 * as such in a tuple, a sequence, a set elaboration, etc.
 */
#define error2  "Expressions' types not compatible in the list."
#define error3  "Types not compatible between actual parameters and formal ones."

#define error6  "Tuple selection out of range."
#define error7  "The expression is not a tuple."

/* error8 is used by the parser.
 */
#define error8  "Nested module not allowed to have parameters."
#define error9  "This is supposed to be a schema reference."

/* error10 is used by the parser.
 */
#define error10 "The end name does not match the declared one."
#define error11 "Name not found."
#define error12 "Two schema signatures not compatible."
#define error13 "The name not found in the schema signature."

/* error15 is triggered by a function application, where the function does not 
 * have the function type.
 */
#define error15 "This is supposed to be a function."

/* error19 is used by the parser.
 */
#define error19 "State is the reserved non-operational and non-parameterized schema."
/* error20 is reported when referring to a generic declaration before
 * instantiation.
 */
#define error20 "The generic declaration needs to be instantiated."

#define error22 "Identifier already declared."

#define error24 "Arguments' types not compatible with the operator."

/* error29 is reported when using a symbol as an operator, which is not a predefined 
 * one in the math toolkit. Users are not allowed to introduce a new operator.
 */
#define error29 "The operator not found."

/* error31 is to report an internal error, it means a bug existing in
 * the Sum type checking system. 
 */
#define error31 "Internal error."

/* error32 is to report an error where a type expression should be present.
 */
#define error32 "Not a type expression."

/* error33 is to report an error occuring where a predicate should be present, which
 * should be either a schema reference or an expression having a boolean type.
 */
#define error33 "Not a predicate."
#define error34 "Schema included not compatible with the current schema."

#define error35 "The banged or primed object not allowed to appear in a pre-condition."

/* error36 is reported when the primed one of a object listed in the 
 * changes_only is not found in the current schema signature.
 */
#define error36 "The corresponding primed object not found in the current schema signature."
#define error37 "Only top scope objects can appear in the rename list of an import statement." 

/* error38 is to report that the objects referenced in the schema predicate 
 * part are not found in the current scope.
 */
#define error38 "The schema predicate part is not applicable in the environment."

/* error39 reports a theta expression for which some variables are missing
 * from the environment 
 */
#define error39 "The Theta expression is not applicable in the environment."

/* error40 is ejected when an object of a schema listed in the changes_only 
 * is not found in the current scope.
 */
#define error40 "An Object in this schema signature not found in the current scope."

/*  error41 reports that a theta has been applied to a name that is not a schema name */
#define error41 "The Theta expression has been applied to a name that does not represent a schema."

/* Semanitic error messages for intermediate language */

#define il_error1 "The condition in If expression is not Bool"

#define il_error2 "Too few expressions on rhs of assignment."
#define il_error3 "Too many expressions on rhs of assignment."
#define il_error4 "Input var on lhs of assignment."

/* The data structure for an identifier in the AST.
 */
typedef struct { tIdent Ident; tPosition Pos; } tIdPos; 

/* Values of the attribute [ObjKind: int] for Obj_Inn in the 
 * symbol table structure.
 */
#define Obj_schema 1 
#define Obj_module 2
#define Obj_import 3

/* Values of attribute [VarDeclKind: int] for VarDecl in AST.
 * Is_local_id:     to specify variables declared in QuantPred, SchemaText, etc.
 * Is_schema_field: to specify variables declared in SchemaDef.
 */
# define Is_param        1
# define Is_schema_field 2
# define Is_decl_id      3
# define Is_axiom_id     4
# define Is_local_id     5

/* status of [VarKind: int], attribute for Obj_Id of the symbol table.
 * Is_obj:     to specify an object declared at Module level.
 * Is_zvar:    to specify an object declared in a SchemaDef.
 * Is_local:   to specify an object declared in QuantPred, SchemaText, etc.
 * Is_schincl: to specify an object introduced by schema inclusion.
 */
# define Is_obj   0
# define Is_zvar  1
# define Is_local 2
# define Is_schincl 3

/* a macro to handle malloc failure.
 * The disadvantage of such wrapper function is that it handles all
 * malloc failures in the same way.
 */
extern void* mymy_malloc();
#define my_malloc(n) mymy_malloc(n, __LINE__, __FILE__) 

/* The macro to report the internal error.
 */
#define InterErr(x) fprintf(stderr, "Internal error: %s, LINE %ld, FILE `%s'\n", x, __LINE__, __FILE__)

#define DError(pos, error) Error(pos, error); fprintf(stderr, "LINE %ld, FILE `%s'\n", __LINE__, __FILE__)

/* Internal error messages
 */
#define Ierror1 "Routine IsDeclared() is not consistent with LookUp()." 
#define Ierror2 "Type category not defined."
#define Ierror3 "Something wrong with ReadType routine."
#define Ierror4 "Array is out of limit."
#define Ierror5 "Type is not available."
#define Ierror6 "Write error: wrong # of bytes." /* added for WIN32 */
#define Ierror7 "Read error: wrong # of bytes." /* added for WIN32 */

/* macros for constructing some base types 
 */
#define ErrTy    mTp_Err  (NoIdent, NoIdent)
#define BoolTy   mTp_Base (NoIdent, Ident_bool)
#define IntTy    mTp_Base (NoIdent, Ident_int)
#define StringTy mTp_Base (NoIdent, Ident_string)
#define CharTy   mTp_Base (NoIdent, Ident_char)

#endif

/* error messages repoted during translation to Ergo.
 * It generally tells information about some translations have not been 
 * handled yet. 
 */
#define tr_error2 "The parameterised schema is not translatd at this stage."
#define tr_error3 "The parameterised axiom is not translatd at this stage."
#define tr_error4 "The nested module is not translated at this stage."

#define tr_error6 "Visible statement with selection part is not translated." 
#define tr_error7 "String is not translated yet."
#define tr_error8 "Char is not translated yet."

#define tr_error10 "Predicate constraint not translated yet."

#define tr_error12 "Schema variable selection not handled."
#define tr_error13 "Schema binding not translated at this stage."

/* Error messages reported during translation to Ada */

/* While translating an op schema to a procedure a declaration occurred
which was not a variable declaration */

#define ada_error1 "Non-var decl in Op sig."

/* Translations exist only for abbreviations of kinds range type or Array type*/

#define ada_error2 "Abbreviation not range type or array type."

/* a IL function definition occured with a non-vardecl parameter */

#define ada_error3 "Incorrect declaration in function."

/* A function is not declared as a function (ie with fun or pfun etc) */

#define ada_error4 "Function not declared as function."

/* A function definition must quantify input variables */

#define ada_error5 "No quantified variables in function predicate."

/* function definition should be of form all x . f(x) = r */
 
#define ada_error6 "First pred not function definition."
#define ada_error7 "First function application is not a simple reference."
#define ada_error8 "First function application is not the declared function."
#define ada_error9 "Function parameters not simple or cartesian product."
#define ada_error10 "Argument is not simple variable reference."

/* Only simple types (variable references) are allowed for argument types */
#define ada_error11 "Formal argument is not simple type."

/* can't locate type of variable in parallel assignment" */
/* internal error */
#define ada_error12 "Internal Error:Assignment variable has no type."

/* An array definition occurred without an range component */

#define ada_error13 "Array without range."

/* In a named array aggregate the index -> value mapping was not correct */

#define ada_error14 "Not proper array aggregate element."

/* In ada record display must have form tag = value */

#define ada_error15 "Not proper array record display predicate."
#define ada_error16 "Not proper array record display variable."

/* In translating schema defs the state is checked for redeclarations */

#define ada_error17 "state not a schema"

/* adding indentation for translated Ergo code. 
 */
/* extern int indenttabs; */
#ifdef WIN32
extern int indenttabs; /* I can't set initial value here. why? */
#else
int indenttabs; /* I can't set initial value here. why? */
#endif

/* variables for checking whether a module being translated 
   by TransAda or Trans has stae and init schemas  */

 bool has_state;
 bool has_init;

#define TABI (indenttabs++)
#define TABO (indenttabs--)
#define INDENT {short i; for(i=indenttabs; i>0; i--) {fprintf(fp,"\t");} }

/* global variables for storing the Sum file name 
 */

#ifndef WIN32
char *SumFileName, *SumPathName, *SumSpecFile;
#endif

void ReadPosition(); /* read a Position from ascii tree file */
void WriteIdPos(); /* write an IdPos to ascii tree file */
void ReadIdPos(); /* read an IdPos from ascii tree file */

