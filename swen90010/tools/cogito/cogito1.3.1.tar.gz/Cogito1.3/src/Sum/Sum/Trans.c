# include "Trans.h"
# include "yyTrans.w"
# include "System.h"
# include <stdio.h>
# include "Tree.h"
# include "Type.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 24 "Trans.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
# include "Scanner.h"
# include "Tree.h"
# include "Syms.h"
# include "Type.h"
# include "global.h"
# include "Trans.h"

# include "Idents.h"
# include "Positions.h"
# include "ratc.h"
# include <string.h>
# include <stdio.h>

FILE *fp;
int axiom_name_counter=0;
int minor_axiom_name_counter=0;
char axiom_prefix[IDENT_LENGTH]="axiom";
char cur_mod_name[IDENT_LENGTH];

bool below_sch_line=false;

bool IsBoolPred (PredList)
    tTree PredList;
{
    tTree predlist=PredList;

    for (; predlist && predlist->Kind != kNoPred; predlist=predlist->Pred.Next)
        if (predlist->Pred.Type 
            && predlist->Pred.Type->Kind == kTp_Base
            && Ident_bool == predlist->Pred.Type->Tp_Base.Ident) 
            ;
        else
            return false;
    return true;
}

void Tr_PredList (PredList)
    tTree PredList;
{
    tTree predlist=PredList;
    short ktmp;
    short andt = 0;
	tType ty;

	if (predlist->Kind == kNoPred) { 
		fprintf(fp, "'ergo.true'");
		return;
	}

    fprintf(fp,"\n");
    for(; predlist->Kind != kNoPred; predlist = predlist->Pred.Next) {
		ktmp = predlist->Pred.Next->Kind;
		if (ktmp != kNoPred) {
			INDENT;
			fprintf (fp, "'ergo.and'(\n");
			TABI;
			andt++;
		}
		predlist->Pred.Next->Kind = kNoPred;
		INDENT;
		ty = predlist->Pred.Type;
		if (ty && ty->Kind == kTp_Schema && below_sch_line) {
			fprintf (fp, "'schema.schema_ex_pred'(");
			TransErgo(predlist);
			fprintf (fp, ", !_s)");
		}
		else 
			TransErgo(predlist);
		predlist->Pred.Next->Kind = ktmp;
		if (ktmp != kNoPred)
            fprintf (fp, ",\n");
    }

    for(; andt > 0; andt--) {
		INDENT;
		fprintf (fp, ")\n");
		TABO;
    }
}

void Tr_ExpList (ExpList)
    tTree ExpList;
{
    tTree explist=ExpList;

	for (; explist->Kind != kNoExp; explist=explist->Exp.Next) {
		TransErgo (explist);
		if (explist->Exp.Next->Kind != kNoExp)
		fprintf (fp, ", ");
	}
}

void WrtErgoTheory (Ident)
    tIdPos Ident;
{
    char theory_name[IDENT_LENGTH];

    theory_name[0] = '\0';
    cur_mod_name[0] = '\0';
    GetString (Ident.Ident, cur_mod_name);

/*  strcat (theory_name, SumPathName); */
    strcat (theory_name, cur_mod_name);
    strcat (theory_name, ".thy");
    fp = fopen (theory_name, "w");
    if (fp == NULL) {
        fprintf (stderr, "Can't write to file: %s\n", theory_name); 
        exit(1);
    }
}

void mygetstr (Ident, str)
    tIdent Ident;
    char *str;
{
    str[0]='\0';
    GetString (Ident, str);
    /* ?? to give qualified name
     * sprintf (id_str, "%s.%s", cur_mod_name, id_str);
     */
}

void Unparse_Name (IdList, str)
	tTree IdList;
	char *str;
{
	tTree idlist=IdList;
	char idstr[IDENT_LENGTH];

	str[0] = '\0';
	for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) {
		idstr[0] = '\0';
		mygetstr (idlist->Id.Ident.Ident, idstr);
		strcat (str, idstr);
		if (idlist->Id.Next->Kind != kNoId)
			strcat (str, ".");
	}
}

void has_state_and_init (DeclsIn)
    tObjects DeclsIn;
{
    tObjects sym_ptr = NoSym;

    sym_ptr = DeclsIn->Obj_Inn.Inner;

    for (; sym_ptr && sym_ptr->Kind != kNoObject; sym_ptr=sym_ptr->Object.Next) {
        if (Ident_state == sym_ptr->Object.Ident)
            has_state = true;
        if (Ident_init == sym_ptr->Object.Ident)
            has_init = true;
    }
}

void EndPartOfMod (DeclList)
    tTree DeclList;
{
    tTree decllist=DeclList;
    bool fst=true;
    char idstr[IDENT_LENGTH];


    /* LW changed cur_mod_name to state_machine 26/8/96 */
    fprintf (fp, "define 'state_machine' === 'schema.module'(");

    if (has_state)
        fprintf (fp, "'%s.state', ", cur_mod_name); 
    else fprintf (fp, "'schema.empty_schema', ");
    if (has_init)
        fprintf (fp, "'%s.init', ", cur_mod_name); 
    else fprintf (fp, "'schema.empty_schema', ");
    fprintf (fp, "[");

    for (; decllist->Kind != kNoDecl; decllist=decllist->Decl.Next) 

        if (decllist->Kind == kSchemaDef && decllist->SchemaDef.IsOp) {
                mygetstr (decllist->SchemaDef.Ident.Ident, idstr);
                if (fst) {
                    fprintf (fp, "'%s.%s'", cur_mod_name, idstr); 
                    fst = false;
                }
                else 
                    fprintf (fp, ", '%s.%s'", cur_mod_name, idstr); 
            }

    fprintf (fp, "]");
    fprintf (fp, ").\n");
}

void TransClose ()
{
	AddRefComm (fp);
    fclose (fp);
    /* error print out ??*/
}

void TrError (Position, Text)
    tPosition Position;
    char *Text;
{
    /* Message (Text, xxWarning, Position); */
    Message (Text, xxError, Position); 
    fprintf (stderr, "... Translation failed. \n");
    exit (1);
}

void ax_name_gen(str)
    char *str;
{
    axiom_name_counter++;
    sprintf (str, "%s_%d", axiom_prefix, axiom_name_counter);
}

void mi_ax_name_gen(str)
    char *str;
{
    minor_axiom_name_counter++;
    sprintf (str, "%s_%d_%d", axiom_prefix, axiom_name_counter, minor_axiom_name_counter);
}

void reset_mi_ax_name_gen()
{ 
	minor_axiom_name_counter = 0; 
}

void IsAllowedId (Ident)
    tIdPos Ident;
{
    char str[IDENT_LENGTH];
    int n = 0;

    str[0] = '\0';
    GetString (Ident.Ident, str);
    n = strlen (str) - 1;
    if (str[n] == '!'|| str[n] == '\'') 
        Error (Ident.Pos, error35);
}

void IsAllowedIdList (IdList)
    tTree IdList;
{
    tTree idlist=IdList;

    for (; idlist->Kind != kNoId; idlist=idlist->Id.Next)
        IsAllowedId (idlist->Id.Ident);
}

void IsAllowedQuId (IdList)
    tTree IdList;
{
    tTree idlist=IdList;

    for (; idlist->Kind != kNoId; idlist=idlist->Id.Next)
        if (idlist->Id.Next->Kind == kNoId)
            break;

    IsAllowedId (idlist->Id.Ident);
}

void Tr_VarDecl (IdList, Exp, IsRigorous)
    tTree IdList;
    tTree Exp;
	bool IsRigorous;
{
    tTree idlist = IdList;
    char idstr[IDENT_LENGTH], ax_name[IDENT_LENGTH];

    for (; idlist && idlist->Kind != kNoId; idlist = idlist->Id.Next) {
        mygetstr(idlist->Id.Ident.Ident, idstr);
        ax_name_gen(ax_name);
        fprintf (fp, "declare '%s'.\naxiom %s === ", idstr, ax_name);
		if (IsRigorous) {
			fprintf (fp, "'ergo.=>'('types.:'(");
			TransErgo(Exp);
			fprintf (fp, ", 'ztypes.zsets'), "); 
			fprintf (fp, "'ztypes.::'('%s.%s', ", cur_mod_name, idstr);
			TransErgo (Exp);
			fprintf (fp, ")).\n");
		}
		else {
			fprintf (fp, "'ztypes.::'('%s.%s', ", cur_mod_name, idstr);
			TransErgo (Exp);
			fprintf (fp, ").\n");
		}
    }
}

/* old version of translating Module structure.
 * delete_theory('ModName').
 * add_theory('ModName').
void Tr_Module (Ident, FormalParams)
    tIdPos Ident;
	tTree FormalParams;
{
    char idstr[IDENT_LENGTH], ax_name[IDENT_LENGTH];
	tTree fmllist=FormalParams;

    mygetstr (Ident.Ident, idstr);
    fprintf (fp, "delete_theory('%s').\n", idstr);
    fprintf (fp, "add_theory('%s').\ninclude_theory(sum,share).\n",
        idstr);
	for (; fmllist->Kind != kNoParam; fmllist=fmllist->Param.Next)
		if (fmllist->Kind == kTyParam) {
			mygetstr (fmllist->TyParam.Ident.Ident, idstr);
			fprintf (fp, 
				"declare '%s'.\naxiom type_%s === 'types.:'('%s.%s', 'ztypes.zsets').\n", 
				idstr, idstr, cur_mod_name, idstr);
			fprintf (fp, "rulegroup(typef, 'type_%s', t).\n", idstr);
		}
		else {
			Tr_VarDecl (fmllist->FncParam.VarDecl->VarDecl.IdList,
				fmllist->FncParam.VarDecl->VarDecl.Exp, 1);
		}
}
*/

void Tr_Axiom (PredList) 
    tTree PredList; 
{
    tTree predlist = PredList;
    char ax_name[IDENT_LENGTH]; 
    short ktmp;

	if (PredList->Kind == kNoPred)
		return;
    ax_name_gen(ax_name);
    reset_mi_ax_name_gen();
    for(; predlist->Kind != kNoPred; predlist = predlist->Pred.Next) {
       	ktmp = predlist->Pred.Next->Kind;
        predlist->Pred.Next->Kind = kNoPred;
       	mi_ax_name_gen(ax_name);
       	fprintf (fp, "axiom %s === !!'jpred.all' [!_s :'schema.sitns']", ax_name);
       	TransErgo (predlist);
       	predlist->Pred.Next->Kind = ktmp;
       	fprintf (fp, ".\n");
    }
}

void Tr_Module (Ident, FormalParams, PredList)
    tIdPos Ident;
    tTree FormalParams, PredList;
{
    char idstr[IDENT_LENGTH], ax_name[IDENT_LENGTH], tyid[IDENT_LENGTH];
    char mod_name[IDENT_LENGTH];
    tTree fmllist;
    tObjects declsin;

    mygetstr (Ident.Ident, idstr);
    if (FormalParams->Kind != kNoParam) {
	fprintf (fp, "delete_theory_and_dependents('%s#Param').\n", idstr);
	fprintf (fp,"add_theory('%s#Param').\ninclude_theory(sum,share).\n", idstr);
	mod_name[0] = '\0';
	strcat (mod_name, cur_mod_name); 
	strcat (cur_mod_name, "#Param"); 

	declsin = FormalParams->Param.DeclsIn->Obj_Inn.Inner;
	for (declsin; declsin && (declsin->Kind == kObj_PTyId || declsin->Kind == kObj_PId); declsin=declsin->Object.Next) {

	  declsin->Object.ModId = MakeIdent(cur_mod_name, strlen(cur_mod_name));
	  declsin->Object.Type->Tp_Exp.ModId =
		MakeIdent (cur_mod_name, strlen(cur_mod_name));
	}
    }
    else {
	/* fprintf (fp, "delete_theory('%s').\n", idstr); */
	fprintf (fp, "delete_theory_and_dependents('%s').\n", idstr);
	fprintf (fp, "add_theory('%s').\ninclude_theory(sum,share).\n", idstr);
    }
    for (fmllist=FormalParams; fmllist->Kind != kNoParam; fmllist=fmllist->Param.Next) {

	if (fmllist->Kind == kTyParam) {
	   mygetstr (fmllist->TyParam.Ident.Ident, tyid);
	   fprintf (fp, 
		"declare '%s'.\naxiom type_%s === 'types.:'('%s.%s', 'ztypes.zsets').\n", 
		tyid, tyid, cur_mod_name, tyid);
	   fprintf (fp,
                 "axiom non_empty_%s === !!ex [!_x:zsets] 'zsets.z_in'(!_x , '%s.%s').\n",
                 tyid, cur_mod_name, tyid);
	   fprintf (fp, "rulegroup(typef, 'type_%s', t).\n", tyid);
	}
	else {
	   Tr_VarDecl (fmllist->FncParam.VarDecl->VarDecl.IdList,
			fmllist->FncParam.VarDecl->VarDecl.Exp, 1);
	}
    }
    if (FormalParams->Kind != kNoParam) {
	Tr_Axiom (PredList);
	fprintf (fp, "delete_theory_and_dependents('%s').\n", idstr);
	fprintf (fp,
           "add_theory('%s').\ninclude_theory(sum,share).\ninclude_theory('%s#Param',all).\n",
            idstr, idstr);
	cur_mod_name[0] = '\0';
	strcat (cur_mod_name, mod_name); 
    }
}

void Tr_GivenSet (IdList)
    tTree IdList;
{
    tTree idlist=IdList;
    char idstr[IDENT_LENGTH];

    for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) {
        mygetstr(idlist->Id.Ident.Ident, idstr); 
        fprintf (fp, 
            "declare '%s'.\naxiom type_%s === 'types.:'('%s.%s', 'ztypes.zsets').\n", 
            idstr, idstr, cur_mod_name, idstr);
		fprintf (fp, "axiom non_empty_%s === !!ex [!_x:zsets] 'zsets.z_in'(!_x , '%s.%s').\n", idstr, cur_mod_name, idstr);
        fprintf (fp, "rulegroup(typef, 'type_%s', t).\n", idstr);
    }
}


    /* Translate the signature of a schema - declares with normalised type */
    /* generates signature from symbol table entry NOT abstract syntax */
    /* symtab may have duplicates from inclusions - must eliminate */


void Tr_SchemaSig (SymPtr)
    tObjects SymPtr;
{
    tObjects symptr1, symptr2;
    char idstr[IDENT_LENGTH], modidstr[IDENT_LENGTH], prefix[IDENT_LENGTH];
    tIdent ParentModId=NoIdent;
    bool fst=true;


    /* eliminate duplicated variable declarations - maybe after inclusion ?? */

      /* initialise tags */

    symptr1 = SymPtr;
    for (; symptr1 && symptr1->Kind != kNoObject; symptr1=symptr1->Object.Next)
        symptr1->Object.Tag = true;

      /* look for identical ids - set duplicate tags to false */

    symptr1 = SymPtr;
    for (; symptr1 && symptr1->Kind != kNoObject; symptr1=symptr1->Object.Next)
        if (symptr1->Object.Next && symptr1->Object.Next->Kind != kNoObject) {
            symptr2 = symptr1->Object.Next;
            for (; symptr2 && symptr2->Kind != kNoObject; symptr2=symptr2->Object.Next)
                if (symptr1->Object.Ident == symptr2->Object.Ident
                    && symptr1->Object.ModId == symptr2->Object.ModId)
                    symptr1->Object.Tag = false;
        }

    /* print out variable declarations */

    fprintf (fp, "\n[");

    symptr1 = SymPtr;
    for (; symptr1 && symptr1->Kind != kNoObject; symptr1=symptr1->Object.Next){
        if (symptr1->Object.Tag) {
            mygetstr (symptr1->Object.Ident, idstr);
            mygetstr (symptr1->Object.ModId, modidstr);
            if (fst)
                fst = false;
            else
                fprintf (fp, ", \n");

            /* if primed variable print prime otherwise dont*/
            /* In either case look up import_as name, if any, for prefix */

            if (idstr[strlen(idstr) - 1] == '\'') {
		ParentModId = ImportAsMod (symptr1->Object.ModId);
		if (ParentModId != NoIdent)
			mygetstr (ParentModId, prefix);
		else 
			prefix[0] = '\0';

		if (prefix[0] != '\0')
			fprintf (fp, "'schema.~'(param_const('schema.state_var', '%s_%s#%s''), ", prefix, modidstr, idstr);
		else 
			fprintf (fp, "'schema.~'(param_const('schema.state_var', '%s#%s''), ", modidstr, idstr);
	    }
            else {
		ParentModId = ImportAsMod (symptr1->Object.ModId);
		if (ParentModId != NoIdent)
			mygetstr (ParentModId, prefix);
		else 
			prefix[0] = '\0';

		if (prefix[0] != '\0')
			fprintf (fp, "'schema.~'(param_const('schema.state_var', '%s_%s#%s'), ", prefix, modidstr, idstr);
		else 
			fprintf (fp, "'schema.~'(param_const('schema.state_var', '%s#%s'), ", modidstr, idstr);
	    }
           
            /* Print type */

            if (symptr1->Object.Type == NoType) {
		/* Type should be available here, if not, Internal error. */
				InterErr (Ierror5);
                exit (1);     
            }
            TransTpExp (symptr1->Object.Type); 

	/* debug printf ("Type ====\n");
		ObjPrint (symptr1, 1);
		PrintTy (symptr1->Object.Type); 
		printf ("\n"); */

            fprintf (fp, ")");
        }
    }
    fprintf (fp, "]\n");
}

/* old version
void Tr_SchemaSig (DeclList)
    tTree DeclList;
{
    tTree siglist=DeclList;
    tTree idlist=NoTree;
    char idstr[IDENT_LENGTH];

    if (siglist->Kind == kNoDecl) {
        fprintf (fp, "[]");
        return;
    }
    
    if (siglist->Kind != kNoDecl)
        fprintf (fp, "[");

    for (; siglist->Kind != kNoDecl; siglist=siglist->Decl.Next) {
        if (siglist->Kind == kVarDecl) {
            for (idlist=siglist->VarDecl.IdList; idlist->Kind != kNoId;
                idlist=idlist->Id.Next) {
                mygetstr (idlist->Id.Ident.Ident, idstr);
                fprintf (fp, "'schema.~'(%s, ", idstr);
                TransErgo (siglist->VarDecl.Exp);
                fprintf (fp, ")");
                if (idlist->Id.Next->Kind == kNoId && 
                    siglist->Decl.Next->Kind == kNoDecl)
                    fprintf (fp, "]");
                else 
                    fprintf (fp, ", ");
            }
        }
    }
}
*/

/* Ref: See Page 77-78 of my Sum working notebook. 
 */
int IsStateRef(cmod, mod, idstr)
    char *cmod, *mod, *idstr;
{
#ifdef WIN32
return( (stricmp(cmod, mod) == 0) && 
      ((stricmp(idstr,"state") == 0) || 
          (stricmp(idstr,"state'") == 0)));
#else
return( (strcasecmp(cmod, mod) == 0) && 
      ((strcasecmp(idstr,"state") == 0) || 
          (strcasecmp(idstr,"state'") == 0)));
#endif
}

/* Translate vardecllist as components of schema sig */
void Tr_VarDeclList(VarDecl)
    tTree VarDecl; /* really VarDeclList */
{
    tTree vardecllist=VarDecl;
    tTree idlist=NoTree;
    tObjects declsin;
    char idstr[IDENT_LENGTH], modidstr[IDENT_LENGTH]; 

    /* declare schema signature containing each quantified variable */
    /* only interested in VarDecls */

    for (; vardecllist->Kind != kNoDecl; vardecllist=vardecllist->VarDecl.Next) 
         if (vardecllist->Kind == kVarDecl)
             for (idlist=vardecllist->VarDecl.IdList; idlist->Kind != kNoId;
                  idlist=idlist->Id.Next) {

                  mygetstr (idlist->Id.Ident.Ident, idstr);
                  if (idstr[strlen(idstr) - 1] == '\'') 
                      fprintf (fp, "'schema.~'(param_const('schema.state_var', '%s#%s''), ", cur_mod_name, idstr);
                  else
                      fprintf (fp, "'schema.~'(param_const('schema.state_var', '%s#%s'), ", cur_mod_name, idstr);

                  TransErgo (vardecllist->VarDecl.Exp);
                  fprintf (fp, ")");
                  if (vardecllist->VarDecl.Next->Kind == kNoDecl &&
                      idlist->Id.Next->Kind == kNoId)
                      break;
                  else
                      fprintf (fp, ", \n");
             }

}


/* print out a schema definition */

void Tr_SchemaBody(DeclList, PredList)
    tTree DeclList;
    tTree PredList;
{
    fprintf (fp, "'schema.schema'([");
    Tr_VarDeclList (DeclList);

    fprintf (fp, "], (!!'func.lambda' [!_s: 'schema.sitns'] ");
    Tr_PredList (PredList);
    fprintf (fp, "))");

}
/* recursive proc to handle inclusions */

void Tr_InclusionAndBody (DeclList, decl, PredList, IsOp)
    tTree DeclList;
    tTree decl;
    tTree PredList;
    bool IsOp;

{
    char idstr[IDENT_LENGTH], modstr[IDENT_LENGTH], prefix[IDENT_LENGTH];
    tTree idlist=NoTree;
    tIdent ParentModId;


    /* if this decl in an inclusion */
    /* then generate an inclusion, do rest of body, recurse out */ 

    if (decl->Kind == kSchemaIncl &&
        decl->SchemaIncl.ExpressionList->Kind == kNoExp) {
        mygetstr (decl->SchemaIncl.ModId, modstr);
        for (idlist=decl->SchemaIncl.IdList;
            idlist->Kind != kNoId; idlist=idlist->Id.Next)
            if (idlist->Id.Next->Kind == kNoId) {
                mygetstr (idlist->Id.Ident.Ident, idstr);    
                break;
            }
        if(!(IsOp == true && IsStateRef(cur_mod_name, modstr, idstr)) ){
	   ParentModId = ImportAsMod (decl->SchemaIncl.ModId);
	   if (ParentModId != NoIdent)
	       mygetstr (ParentModId, prefix);
	   else 
	       prefix[0] = '\0';
           if (idstr[strlen(idstr)-1] == '\'') {
/* wj -- ignore final prime */
		idstr[strlen(idstr)-1] = '\0';
	       if (prefix[0] != '\0') {
/* wj --- need to include schema_dash */
  /*                 fprintf(fp, "'schema.schema_include'('%s_%s.%s', ", prefix, modstr, idstr);*/
		   fprintf(fp, "'schema.schema_include'('schema.schema_dash'('%s_%s.%s'), ", prefix, modstr, idstr); }
	       else {
 /*                  fprintf(fp, "'schema.schema_include'('%s.%s', ", modstr, idstr);*/
		   fprintf(fp, "'schema.schema_include'('schema.schema_dash'('%s.%s'), ", modstr, idstr);}
	   }
           else{
	       if (prefix[0] != '\0')
                   fprintf(fp, "'schema.schema_include'('%s_%s.%s', ", prefix, modstr, idstr);
	       else
                   fprintf(fp, "'schema.schema_include'('%s.%s', ", modstr, idstr);
           }



        }
        /* if more decls then process in case more inclusions  */
        /* o/w finish body, close incl and recurse out */

        if (decl->Decl.Next && decl->Decl.Next->Kind != kNoDecl)
           Tr_InclusionAndBody(DeclList, decl->Decl.Next, PredList );
        else
           Tr_SchemaBody(DeclList, PredList);
        fprintf(fp, ")");
    }
    else
       if (decl->Kind != kNoDecl && decl->Decl.Next && decl->Decl.Next->Kind != kNoDecl)
           Tr_InclusionAndBody(DeclList, decl->Decl.Next, PredList );
       else
           Tr_SchemaBody(DeclList, PredList);
    return;
}

    
/* new version of Tr_SchemaDef uses abstract syntax and lets ergo do inclusion*/

void Tr_SchemaDef (Ident, DeclList, PredList, IsOp, SymPtr, HasStateIncl) 
    tIdPos Ident;
    tTree DeclList;
    tTree PredList;
    bool IsOp;
    tObjects SymPtr;
    bool HasStateIncl;
{
    char idstr[IDENT_LENGTH], modstr[IDENT_LENGTH], prefix[IDENT_LENGTH];
    tTree decllist=DeclList;
    int num_sch_incl=0;
    tIdent ParentModId;
    tTree idlist=NoTree;

    mygetstr(Ident.Ident, idstr);
    fprintf(fp, "\n%%Begin%s Schema Definition\n",
    (IsOp)? " Operation":"");

    fprintf (fp, "define '%s' === ", idstr);

    /* do inclusions of state (primed and unprimed) */
    if (Ident_init == Ident.Ident) {
        fprintf(fp, "'schema.schema_include'('schema.schema_dash'(");
        fprintf(fp, "'%s.state'), ", cur_mod_name);
        num_sch_incl++;
    }

    if (IsOp && Ident_init != Ident.Ident /* && HasStateIncl OT*/ )  {
        fprintf(fp, "'schema.schema_include'('%s.state', ", cur_mod_name);
        fprintf(fp, "'schema.schema_include'('schema.schema_dash'(");
        fprintf(fp, "'%s.state'), ", cur_mod_name);
        num_sch_incl++;
        num_sch_incl++;
    }

    Tr_InclusionAndBody (DeclList, decllist, PredList, IsOp);

    for (; num_sch_incl > 0; num_sch_incl--)
        fprintf (fp, ")");

    fprintf (fp, ".\n");
    fprintf (fp, "%%End Schema Definition\n");
}



/* Old version using symbol table to generate schema def

void Tr_SchemaDef (Ident, DeclList, PredList, IsOp, SymPtr, HasStateIncl) 
    tIdPos Ident;
    tTree DeclList;
    tTree PredList;
    bool IsOp;
    tObjects SymPtr;
    bool HasStateIncl;
{
    char idstr[IDENT_LENGTH], modstr[IDENT_LENGTH], prefix[IDENT_LENGTH];
    tTree decllist=DeclList;
    int num_sch_incl=0;
    tIdent ParentModId;
    tTree idlist=NoTree;

    mygetstr(Ident.Ident, idstr);
    fprintf(fp, "\n%%Begin%s Schema Definition\n",
    (IsOp)? " Operation":"");

    fprintf (fp, "define '%s' === 'schema.schema'(", idstr);
    Tr_SchemaSig (SymPtr->Obj_Inn.Inner);

    fprintf (fp, ", (!!'func.lambda' [!_s: 'schema.sitns'] ");

    if (Ident_init == Ident.Ident) {
        fprintf (fp,"'ergo.and'('schema.schema_ex_pred'('schema.schema_dash'(");
        fprintf(fp, "'%s.state'), !_s), ", cur_mod_name);  
        num_sch_incl++;
    }

    if (IsOp && Ident_init != Ident.Ident * && HasStateIncl OT* )  {
        fprintf (fp, "'ergo.and'('schema.schema_ex_pred'('%s.state', !_s),", cur_mod_name);
        fprintf (fp, " 'ergo.and'('schema.schema_ex_pred'('schema.schema_dash'(");
        fprintf (fp, "'%s.state'), !_s), ", cur_mod_name); 
        num_sch_incl++;
        num_sch_incl++;
    }

    * add predicate part of included schemas *
    for (; decllist->Kind != kNoDecl; decllist=decllist->Decl.Next) 
        if (decllist->Kind == kSchemaIncl && 
	    decllist->SchemaIncl.ExpressionList->Kind == kNoExp) {

            * get module name *

            mygetstr (decllist->SchemaIncl.ModId, modstr);

            * get last part of qualified name *

            for (idlist=decllist->SchemaIncl.IdList;
                 idlist->Kind != kNoId; idlist=idlist->Id.Next)
                 if (idlist->Id.Next->Kind == kNoId) {
                    mygetstr (idlist->Id.Ident.Ident, idstr);    
                    break;
                 }
             * if not an operation or not referring to state ???*

            if(!(IsOp == true && IsStateRef(cur_mod_name, modstr, idstr)) ){
                 if (idstr[strlen(idstr)-1] == '\'') {

	 	   ParentModId = ImportAsMod (decllist->SchemaIncl.ModId);
		   if (ParentModId != NoIdent)
			mygetstr (ParentModId, prefix);
		   else 
			prefix[0] = '\0';

		   if (prefix[0] != '\0')
		        fprintf (fp, "'ergo.and'('schema.schema_ex_pred'('schema.schema_dash'('%s_%s.%s''), !_s), ", prefix, modstr, idstr); 
		   else
			fprintf (fp, "'ergo.and'('schema.schema_ex_pred'('schema.schema_dash'('%s.%s''), !_s), ", modstr, idstr); 
		 }
                 else{
                   fprintf (fp, "'ergo.and'('schema.schema_ex_pred'('");
		   ParentModId = ImportAsMod (decllist->SchemaIncl.ModId);
		   if (ParentModId != NoIdent)
		       mygetstr (ParentModId, prefix);
		   else 
		       prefix[0] = '\0';
		   if (prefix[0] != '\0')
		       fprintf (fp, "%s_%s.%s', !_s), ", prefix, modstr, idstr); 
		   else
		       fprintf (fp, "%s.%s', !_s), ", modstr, idstr); 
		 }
                num_sch_incl++;
	    }
	}
        
    Tr_PredList (PredList);

    for (; num_sch_incl > 0; num_sch_incl--)
        fprintf (fp, ")");

    fprintf (fp, ")).\n");
    fprintf (fp, "%%End Schema Definition\n");
}

 ^^ Old version of Tr_SchemaDef  */


void Tr_Abbr (Ident, Exp) 
    tIdPos Ident;
    tTree Exp;
{
    char idstr[IDENT_LENGTH];

    mygetstr(Ident.Ident, idstr);
    fprintf (fp,
        "define '%s' === ", idstr);
    TransErgo(Exp);
    fprintf (fp, ".\n");
}

void Tr_Import (Ident, ExpList, NewIdent, iml, FmlParams, RenameList)
    tIdPos Ident;
    tTree ExpList;
    tIdPos NewIdent;
    IML_List iml;
    tObjects FmlParams;
    tTree RenameList;
{
    char idstr[IDENT_LENGTH], newidstr[IDENT_LENGTH];
    char oldname[IDENT_LENGTH], newname[IDENT_LENGTH];
    char fp_str[IDENT_LENGTH];
    IML_List imllist=iml;
    tTree explist = ExpList;
    tObjects fmlparams = FmlParams;
    tTree renamelist=RenameList;
    char mod_name[IDENT_LENGTH];
    char tp_mod_name[IDENT_LENGTH];
    char cp_mod_name[IDENT_LENGTH];
   

    mygetstr(Ident.Ident, idstr);
    if (Ident.Ident == NewIdent.Ident && ExpList->Kind == kNoExp) {
    	/* import A; */
    	fprintf (fp, "inherit_theory('%s').\n", idstr);
    }
    else { /* import A ... as NewA; */
    	mygetstr(NewIdent.Ident, newidstr);
    	if (ExpList->Kind != kNoExp) { /* import A (...) as NewA; */
/* wj --- 13/5/99 Prefixing the new instantiation name with the name of the */
/*current module causes problems in ergo as it is not consistent.  */
/* The prefixed name is not known by the user who expects the instantiation */
/*name to be as is.  */
/* It causes incompatibility with the type checker if the visible clause is used  ---  the user and type checker expects instName but ergo expects currentModule_instName.  */
/* In like manner, ergo doesn't recognise the variables of the imported module, as they haven't the prefix. */
    	    fprintf (fp, "\ninterpret('%s#Param', '%s_%s#Param', [", idstr, cur_mod_name, newidstr);
    	    /* formal params being mapped to actual params */		
    	    for (; explist->Kind != kNoExp; explist=explist->Exp.Next) {
    		mygetstr (fmlparams->Object.Ident, fp_str);
    		fprintf (fp, "'%s#Param.%s'--->", idstr, fp_str);
    		TransErgo(explist);
    		if (explist->Exp.Next->Kind != kNoExp)
    			fprintf (fp, ", ");
    		else
    			fprintf (fp, "], [], []).\n");

                /* change denotation of theoryname of type formals in symtab */
                mygetstr(fmlparams->Object.ModId, mod_name);
                mygetstr(fmlparams->Object.Type->Tp_Exp.ModId, tp_mod_name);
                /* strcat(mod_name, "#Param"); */
                /* fmlparams->Object.ModId = MakeIdent(mod_name, strlen(mod_name)); */

                if (fmlparams->Object.Type->Tp_Exp.PtrToCopy != NoType) {
 mygetstr(fmlparams->Object.Type->Tp_Exp.PtrToCopy->Tp_Exp.ModId, cp_mod_name);
                *(fmlparams->Object.Type) = *(fmlparams->Object.Type->Tp_Exp.PtrToCopy); } 
    		fmlparams = fmlparams->Object.Next;
    	    }
    	}
/* wj --- 13/5/99  The instantiated name is prefixed by the */
/*current module name but the user doesn t know about it and ergo does and */
/*the two are incompatible */
    	fprintf (fp, "\ninstantiate('%s', '%s_%s', [", idstr, cur_mod_name, newidstr);
    	/* renames */
    	for (; renamelist->Kind != kNoRename; 
    		renamelist=renamelist->Rename.Next) {

    		Unparse_Name (renamelist->Rename.OldIdent, oldname);
    		mygetstr (renamelist->Rename.NewIdent.Ident, newname);
    		fprintf (fp, "'%s--->%s'", oldname, newname);
    		if (renamelist->Rename.Next->Kind != kNoRename)
    			fprintf (fp, ", ");
    	}
    	fprintf (fp, "], ");
    	/* parent theory mapping */
/* wj --- 13/5/99  prefix instantiated name with current module name*/
/* this is not known to the user and so ergo s interpretation is */
/*incompatible with the ergo translation of rest of the user s specification */
    	if (ExpList->Kind != kNoExp) 
    		fprintf (fp, "['%s#Param'--->'%s_%s#Param'], ", idstr, cur_mod_name, newidstr);
    	else 
    		fprintf (fp, "[], "); 
    	/* subtheory mapping */
    	fprintf (fp, "[");
    	for (; imllist != NULL; imllist = imllist->next) {
    		fprintf (fp, "'%s_%s'--->'%s_%s_%s'", idstr, imllist->subthyid,
    			cur_mod_name, newidstr, imllist->subthyid);
    		if (imllist->next != NULL)
    			fprintf (fp, ", ");
    	}
    	fprintf (fp, "]).\n\n");
    }
}

/*
Free Type:

T ::= c1 | ... | cm | d1 <<E1>> | ... | dn <<En>>

|-

[T]

axiom is
dec
  c1, ..., cm : T;
  d1: E1 >--> T;
  ...;
  dn: En >--> T
pred
  disjoint (<{c1}, ..., {cm}, ran d1, ..., ran dn>)
end

  There are two axioms constraining the constants and constructors.
First, all the constants are distinct, and the constructors have disjoint
ranges which do not contain any of the constants.
*/
void Tr_FreeType (Ident, BranchList)
    tIdPos Ident;
    tTree BranchList;
{
    tTree blist=BranchList;
    char ftstr[IDENT_LENGTH], const_str[IDENT_LENGTH];
    char ax_name[IDENT_LENGTH];

    mygetstr (Ident.Ident, ftstr);
    fprintf (fp, "\n%%Free type Declaration begins\n");
    fprintf (fp, "declare '%s'.\n", ftstr);
    fprintf (fp, "axiom type_%s === 'types.:'('%s.%s', 'ztypes.zsets').\n", 
    ftstr, cur_mod_name, ftstr);
	fprintf (fp, "rulegroup(typef, 'type_%s', t).\n", ftstr);

    for (; blist->Kind != kNoBranch; blist=blist->Branch.Next) {
        ax_name_gen(ax_name);
        if (blist->Kind == kFTConstant) {
            mygetstr (blist->FTConstant.Ident.Ident, const_str);
            fprintf (fp, "declare '%s'.\naxiom %s === 'ztypes.::'('%s.%s', ",
                const_str, ax_name, cur_mod_name, const_str);
            fprintf (fp, "'%s.%s').\n", cur_mod_name, ftstr);
        }
        if (blist->Kind == kFTConstructor) {
            mygetstr (blist->FTConstructor.Ident.Ident, const_str);
            fprintf (fp, "declare '%s'.\naxiom %s === 'ztypes.::'('%s.%s', ",
				const_str, ax_name, cur_mod_name, const_str);
			fprintf(fp, "'zfunc.z_>-->'(");
			TransErgo(blist->FTConstructor.Exp);
			fprintf(fp,  ", '%s.%s')", cur_mod_name, ftstr);
            fprintf (fp, ").\n");
        }
		fprintf (fp, "rulegroup(typef, '%s', t).\n", ax_name);
    }

	/* disjoint part */
	ax_name_gen(ax_name);
	fprintf (fp, "axiom %s === ", ax_name);
    fprintf (fp, "'zseq.z_partitions'('zseq.z_seq'([");
    for (blist=BranchList; blist->Kind != kNoBranch; blist=blist->Branch.Next) {
		if (blist->Kind == kFTConstant) {
            mygetstr (blist->FTConstant.Ident.Ident, const_str);
            fprintf (fp, "'zsets.z_set'(['%s.%s'])",
                cur_mod_name, const_str);
		}
		if (blist->Kind == kFTConstructor) {
            mygetstr (blist->FTConstructor.Ident.Ident, const_str);
            fprintf (fp, "'zrel.z_range'('%s.%s')",
				cur_mod_name, const_str);
		}
		if (blist->Branch.Next->Kind != kNoBranch)
            fprintf (fp, ",");
	}
    fprintf (fp, "]), '%s').", ftstr);
    fprintf (fp, "\n%%Free type Declaration ends\n");
}

void Tr_Visible (Ident) 
    tIdPos Ident;
{
    char idstr[IDENT_LENGTH];

    mygetstr(Ident.Ident, idstr);
    fprintf (fp, 
        "add_visible_theory('%s').\n", idstr);
}

void Tr_ErgoAnno (Ident)
	tIdPos Ident;
{
	axiom_name_counter = 0;	
	axiom_prefix[0] = '\0';
	mygetstr (Ident.Ident, axiom_prefix);
}


/* Predicates */

void Tr_QuantPred (LogQuant, SchemaText, Pred)
    tIdPos LogQuant;
    tTree SchemaText; /* actually, it is VarDeclList */
    tTree Pred;
{
    tTree vardecllist=SchemaText->SchemaText.DeclList;
    tTree idlist=NoTree;
    tObjects declsin;
    int c = 0;
    char idstr[IDENT_LENGTH], quantid[IDENT_LENGTH], modidstr[IDENT_LENGTH]; 
	tType ty;

    /* Get quantifier string  */

    if (LogQuant.Ident == Ident_forall) 
         sprintf (quantid, "%s", "all");
    else if (LogQuant.Ident == Ident_exists)
         sprintf (quantid, "%s", "ex");
    else if (LogQuant.Ident == Ident_exists_1)
         sprintf (quantid, "%s", "ex1");
    else mygetstr (LogQuant.Ident, quantid);

   /* print schema quantifier and start of schema decl */
   /* could use Tr_SchemaText to translate VarDecl into a schema */
   /* Tr_SchemaText(vardecllist, Pred, ty) */
   /* except that you would get normalised types not actual declared type */
   /* I made Tr_VarDeclList to just do schema.~ parts */

    fprintf(fp, "'func.lambda_at'('schema.schema_%s_p'(", quantid);

   /* 'schema.schema'([n;
    Tr_VarDeclList(vardecllist);
    fprintf (fp, "],\n "); 
     * print true for raised predicate body */
    /*fprintf(fp,"(!!'func.lambda' [!_s:'schema.sitns'] 'ergo.true')), \n"); */

    Tr_SchemaBody(SchemaText->SchemaText.DeclList, SchemaText->SchemaText.PredList);
    fprintf(fp, ", \n");



    /* print second parameter to quantifier as raised predicate */

    fprintf (fp, "(!!'func.lambda' [!_s: 'schema.sitns'] ");

    ty = Pred->Pred.Type;
    if (ty && ty->Kind == kTp_Schema && below_sch_line) {
	fprintf (fp, "'schema.schema_ex_pred'(");
	TransErgo (Pred); 
	fprintf (fp, ", !_s)");
    }
    else 
	TransErgo (Pred); 

    /* close raised predicate, schema_Q_p, apply situation */
    
    fprintf(fp, ")), !_s) \n ");

}

void Tr_RelBinPred (L, RelBinOp, R) 
    tTree L, R;
    tIdPos RelBinOp;
{
    bool swap=false;

    if (RelBinOp.Ident == Ident_grt) {
        fprintf (fp, "'iarith.<'(");
        swap = true;
    }

    else if (RelBinOp.Ident == Ident_less)
        fprintf (fp, "'iarith.<'(");

    else if (RelBinOp.Ident == Ident_notless) {
        fprintf (fp, "'iarith.=<'(");
        swap = true;
    }

    else if (RelBinOp.Ident == Ident_notgrt)
        fprintf (fp, "'iarith.=<'(");

    else if (RelBinOp.Ident == Ident_equal)
        fprintf (fp, "'ergo.='(");

    else if (RelBinOp.Ident == Ident_notequ)
        fprintf (fp, "'apart.apart'(");

    else if (RelBinOp.Ident == Ident_in)
        fprintf (fp, "'zsets.z_in'(");

    else if (RelBinOp.Ident == Ident_not_in)
        fprintf (fp, "'jprop.not'('zsets.z_in'(");

    else if (RelBinOp.Ident == Ident_subset)
        fprintf (fp, "'zsets.z_subset_of'(");

    else if (RelBinOp.Ident == Ident_p_subset)
        fprintf (fp, "'zsets.z_p_subset_of'(");

    else if (RelBinOp.Ident == Ident_partitions)
        fprintf (fp, "'zseq.z_partitions'(");

/* insert IL for ltc, ltec, gtc, gtec, eqc and neqc here, wj 4/8/99 */
    else if (RelBinOp.Ident == Ident_ltc)
        fprintf (fp, "'arefine.ltc'(");

   else if (RelBinOp.Ident == Ident_ltec)
        fprintf (fp, "'arefine.ltec'(");

   else if (RelBinOp.Ident == Ident_gtc)
        fprintf (fp, "'arefine.gtc'(");

   else if (RelBinOp.Ident == Ident_gtec)
        fprintf (fp, "'arefine.gtec'(");

     else if (RelBinOp.Ident == Ident_eqc)
        fprintf (fp, "'arefine.eqc'(");

     else if (RelBinOp.Ident == Ident_neqc)
        fprintf (fp, "'arefine.neqc'(");


    if (swap) {
        TransErgo (R);
        fprintf (fp, ", ");
        TransErgo (L);
    }
    else {
        TransErgo (L);
        fprintf (fp, ", ");
        TransErgo (R);
    }

    if (RelBinOp.Ident == Ident_not_in)
        fprintf (fp, "))");
    else
        fprintf (fp, ")");
}

void Tr_RelPrePred (RelPreOp, Exp)
    tIdPos RelPreOp;
    tTree Exp;
{
    if (RelPreOp.Ident == Ident_disjoint) 
        fprintf (fp, "'zsets.disjoint'(");

    TransErgo (Exp);
    fprintf (fp, ")\n");
}

void Tr_LogBinPred (L, LogBinOp, R, Next) 
    tTree L, R;
    tTree LogBinOp;
    tTree Next;
{
    bool both_are_sch = false;
    tType tyL, tyR;

    if (L->Pred.Type && L->Pred.Type->Kind == kTp_Schema &&
        R->Pred.Type && R->Pred.Type->Kind == kTp_Schema)
	both_are_sch = true;

    switch (LogBinOp->Kind) {
    case kLogEquiv: 
        if (both_are_sch)
            fprintf (fp, "'schema.schema_iff'(");
        else 
            fprintf (fp, "'ergo.<=>'(");
        break;
    case kLogImply: 
        if (both_are_sch)
            fprintf (fp, "'schema.schema_imp'(");
        else 
            fprintf (fp, "'ergo.=>'(");
        break;
    case kLogAnd: 
        if (both_are_sch)
            fprintf (fp, "'schema.schema_and'(");
        else 
            fprintf (fp, "'ergo.and'(");
        break;
    case kLogOr: 
        if (both_are_sch)
            fprintf (fp, "'schema.schema_or'(");
        else 
            fprintf (fp, "'jprop.or'(");
        break;
    case kLogExor: 
        if (both_are_sch)
            fprintf (fp, "'schema.schema_exor'(");
        else 
            fprintf (fp, "'jprop.exor'(");
        break;
    }

    tyL = L->Pred.Type;
    tyR = R->Pred.Type;

    if (below_sch_line &&
	tyL && tyL->Kind == kTp_Schema &&
	tyR && tyR->Kind == kTp_Base && 
        tyR->Tp_Base.Ident == Ident_bool) {

        fprintf (fp, "'schema.schema_ex_pred'(");
	TransErgo (L);
	fprintf (fp, ", !_s)");
    }
    else 
	TransErgo (L);

    fprintf (fp, ", ");

    if (below_sch_line &&
	tyR && tyR->Kind == kTp_Schema && 
	tyL && tyL->Kind == kTp_Base &&
        tyL->Tp_Base.Ident == Ident_bool) {

	fprintf (fp, "'schema.schema_ex_pred'(");
	TransErgo (R);
	fprintf (fp, ", !_s)");
    }
    else 
	TransErgo (R);

    fprintf (fp, ")");
    TransErgo (Next);
}

void Tr_LogicalNot (Pred) 
    tTree Pred;
{
	tType ty;

    fprintf (fp, "'jprop.not'(");
    ty = Pred->Pred.Type;
    if (ty && ty->Kind == kTp_Schema && below_sch_line) {
	fprintf (fp, "'schema.schema_ex_pred'(");
	TransErgo (Pred);
	fprintf (fp, ", !_s)");
    }
    else 
	TransErgo (Pred);
    fprintf (fp, ")\n");
}

void Tr_PreCondPred (Pred, Next)
    tTree Pred;
    tTree Next;
{
    fprintf (fp, "'schema.pre'(");
    TransErgo (Pred);
    fprintf (fp, ")"); 
    TransErgo (Next);
}

/* changes_only {name, ...} 
 * name could be either an object name or a schema reference.
 */
void Tr_ChgOnly(NameList, DeclsIn)
    tTree NameList;
    tObjects DeclsIn;
{
    tTree namelist=NameList, idlist=NoTree;
    tObjects declsin=DeclsIn;
    tObjects symptr1, symptr2;
    char idstr[IDENT_LENGTH], modstr[IDENT_LENGTH], prefix[IDENT_LENGTH];
    tIdent Ident=NoIdent, IdentP=NoIdent, ModId=NoIdent, QuId=NoIdent;
	tIdent ParentModId;
    tTree store=NoTree;
    int num=0;

    for (; declsin && declsin->Kind != kNoObject; declsin=declsin->Object.Pre)
        if (declsin->Kind == kObj_Inn && declsin->Obj_Inn.ObjKind == Obj_schema)
            break;
    
    if (declsin == NoSym || declsin->Kind == kNoObject)
        return;

    symptr1 = declsin->Obj_Inn.Inner;

    for (; symptr1 && symptr1->Kind != kNoObject; symptr1=symptr1->Object.Next)
        symptr1->Object.Tag = false;

    symptr1 = declsin->Obj_Inn.Inner;
	/* finding the pairs of unprimed and primed objects */
    for (; symptr1 && symptr1->Kind != kNoObject;
        symptr1=symptr1->Object.Next) {

        if (symptr1->Object.Tag == false && symptr1->Object.Next
            && symptr1->Object.Next->Kind != kNoObject) {

            symptr2 = symptr1->Object.Next;
            mygetstr (symptr1->Object.Ident, idstr);
            if (idstr[strlen(idstr) - 1] == '\'') {
                idstr[strlen(idstr) - 1] = '\0';
                Ident = MakeIdent (idstr, strlen(idstr));
            }
            else {
                strcat (idstr, "'");
                Ident = MakeIdent (idstr, strlen(idstr));
            }
                
            for (; symptr2 && symptr2->Kind != kNoObject;
                symptr2=symptr2->Object.Next)

                if (symptr2->Object.Tag == false 
                    && Ident == symptr2->Object.Ident
                    && symptr1->Object.ModId == symptr2->Object.ModId) {
                    symptr1->Object.Tag = true;
                    symptr2->Object.Tag = true;
                    break;
                }
        }
    }

	/* mark those unprimed objects appearing in changes_only list,
	 * and also corresponding primed ones.
	 */
	for (; namelist && namelist->Kind != kNoName; namelist=namelist->Name.Next) {
        idlist = namelist->Name.IdList;
        if (idlist->Id.Next->Kind == kNoId) {
            Ident = idlist->Id.Ident.Ident;
            QuId = NoIdent;
        }
        else 
            for (; idlist->Kind != kNoId; idlist=idlist->Id.Next)
                if (idlist->Id.Next->Kind != kNoId &&
                    idlist->Id.Next->Id.Next->Kind == kNoId) {

                    Ident = idlist->Id.Next->Id.Ident.Ident;
                    store = idlist->Id.Next;
                    idlist->Id.Next = mNoId();
                    QuId = FormtIdent (namelist->Name.IdList);
                    idlist->Id.Next = store;
                    break;
                }

        mygetstr (Ident, idstr);
        strcat (idstr, "'");
        IdentP = MakeIdent (idstr, strlen(idstr));
        for (symptr1=declsin->Obj_Inn.Inner; 
            symptr1 && symptr1->Kind != kNoObject;
            symptr1=symptr1->Object.Next) 
                
            if (symptr1->Object.Tag &&
                ((Ident == symptr1->Object.Ident && QuId == symptr1->Obj_Id.QuId) 
                || (IdentP == symptr1->Object.Ident && QuId == symptr1->Obj_Id.QuId))) 
                symptr1->Object.Tag = false;
    }

	/* translation to Ergo */
    symptr1 = declsin->Obj_Inn.Inner;
    for (; symptr1 && symptr1->Kind != kNoObject; 
        symptr1=symptr1->Object.Next) 
        
        if (symptr1->Object.Tag) {
            fprintf (fp, "\n'ergo.and'('ergo.='(");
            mygetstr (symptr1->Object.Ident, idstr);
            if (idstr[strlen(idstr)-1] == '\'') {
                idstr[strlen(idstr)-1] = '\0';
                Ident = MakeIdent (idstr, strlen(idstr));
            }
            else {
                strcat (idstr, "'");
                Ident = MakeIdent (idstr, strlen(idstr));
                idstr[strlen(idstr)-1] = '\0';
            }
            mygetstr (symptr1->Object.ModId, modstr);
			ParentModId = ImportAsMod (symptr1->Object.ModId);
			if (ParentModId != NoIdent)
				mygetstr (ParentModId, prefix);
			else 
				prefix[0] = '\0';

			if (prefix[0] != '\0')
				fprintf (fp,
                "'schema.@'(param_const('schema.state_var', '%s_%s#%s'''), !_s), 'schema.@'(param_const('schema.state_var', '%s_%s#%s'), !_s)), ",
                prefix, modstr, idstr, prefix, modstr, idstr);
			else 
				fprintf (fp,
                "'schema.@'(param_const('schema.state_var', '%s#%s'''), !_s), 'schema.@'(param_const('schema.state_var', '%s#%s'), !_s)), ",
                modstr, idstr, modstr, idstr);
            num++;

            if (symptr1->Object.Next && 
                symptr1->Object.Next->Kind != kNoObject) {

                symptr2 = symptr1->Object.Next;

                for (; symptr2 && symptr2->Kind != kNoObject;
                    symptr2=symptr2->Object.Next)

                    if (symptr2->Object.Tag && Ident == symptr2->Object.Ident
                        && symptr1->Object.ModId == symptr2->Object.ModId) {
                         symptr2->Object.Tag = false;
                         break;
                    }
            }
        }
    fprintf (fp, "'ergo.true'");
    for (; num > 0; num--)
        fprintf (fp, ")");
}

void Tr_BoolValue (Ident)
    tIdPos Ident;
{
    if (Ident.Ident == Ident_true)
        fprintf (fp, "'ergo.true'");
    else if (Ident.Ident == Ident_false)
        fprintf (fp, "'iprop.false'");
}

/* Schemas */
void Tr_SchemaText (DeclList, PredList, Type)
    tTree DeclList, PredList;
    tType Type; /*not used*/
{
    fprintf (fp, "'schema.schema'(");
    if (DeclList->Kind == kNoDecl)
        Tr_SchemaSig (NoSym); 
    else
        Tr_SchemaSig(DeclList->Decl.DeclsIn); 
    fprintf (fp, ", ");
    fprintf (fp, "(!!'func.lambda' [!_s: 'schema.sitns'] ");
    Tr_PredList (PredList);
    fprintf (fp, "))\n");
}

void Tr_SchemaCompos (Sch1, Compos, Sch2)
    tTree Sch1, Sch2;
    tIdPos Compos;
{
    fprintf (fp, "'schema.schema_compose'(");
    TransErgo (Sch1);
    fprintf (fp, ", ");
    TransErgo (Sch2);
    fprintf (fp, ")\n");
}

void Tr_SchemaHiding (Schema, NameList)
    tTree Schema, NameList;
{
    tTree namelist=NameList;
    tType SchTy=NoType;
    tType fldlist=NoType;
    tIdent QuId=NoIdent, Ident=NoIdent;  
    tTree idlist=NoTree;
    tTree store=NoTree;
    char modstr[IDENT_LENGTH], idstr[IDENT_LENGTH];
	bool fst = true;

    SchTy = Schema->Schema.Type;
    if (SchTy && SchTy->Kind == kTp_Schema) {
        fprintf (fp, "'schema.schema_hide'(");
        TransErgo (Schema);
        fprintf (fp, ", [");
        fldlist = SchTy->Tp_Schema.Tp_SchFieldList;
		fst = true;
        for (; namelist->Kind != kNoName;
            namelist=namelist->Name.Next) {

            idlist = namelist->Name.IdList;    
            if (idlist->Id.Next->Kind == kNoId) {
                QuId = NoIdent;
                Ident = idlist->Id.Ident.Ident;
            }
            else 
                for (; idlist->Kind != kNoId; idlist=idlist->Id.Next)
                    if (idlist->Id.Next->Kind != kNoId &&
                        idlist->Id.Next->Id.Next->Kind == kNoId) {

                        Ident = idlist->Id.Next->Id.Ident.Ident;
                        store = idlist->Id.Next;
                        idlist->Id.Next = mNoId();
                        QuId = FormtIdent (namelist->Name.IdList);
                        idlist->Id.Next = store;
                        break;
                    }

            fldlist = SchTy->Tp_Schema.Tp_SchFieldList;
            for (; fldlist; fldlist = fldlist->Tp_SchField.Next)
                if (Ident == fldlist->Tp_SchField.Ident &&
                    QuId == fldlist->Tp_SchField.QuId) {

                    mygetstr (fldlist->Tp_SchField.ModId, modstr);
                    mygetstr (fldlist->Tp_SchField.Ident, idstr);
					if (fst == false)
						fprintf (fp, ", ");
                    if (idstr[strlen(idstr)-1] == '\'') 
                        fprintf (fp, "param_const('schema.state_var', '%s#%s'')", modstr,idstr);
                    else
                        fprintf (fp, "param_const('schema.state_var', '%s#%s')", modstr,idstr);
					fst = false;
                    break;
            }
        }

        fprintf (fp, "])");
    }
}

void Tr_SchemaProj (Sch1, Proj, Sch2)
    tTree Sch1, Sch2;
    tIdPos Proj;
{
    fprintf (fp, "'schema.schema_project'(");
    TransErgo (Sch1);
    fprintf (fp, ", ");
    TransErgo (Sch2);
    fprintf (fp, ")\n");
}

void Tr_SchemaSubst (DeclsIn, Schema, RenameList)
    tObjects  DeclsIn;         /* LW scope to look up new variable types */
    tTree Schema, RenameList;
{
    tTree renamelist=RenameList;
    tType SchTy=NoType;
    tType fldlist=NoType;
    tIdent QuId=NoIdent, Ident=NoIdent, ParentModId=NoIdent;  
    tTree idlist=NoTree;
    tTree store=NoTree;
    char modstr[IDENT_LENGTH], oldidstr[IDENT_LENGTH], newidstr[IDENT_LENGTH];
	char prefix[IDENT_LENGTH];
    bool fst=true;
    tObjects SymPtr;           /* LW objects of new variables */

    SchTy = Schema->Schema.Type;
    if (SchTy && SchTy->Kind == kTp_Schema) {
        fprintf (fp, "'schema.schema_rename'(");
        TransErgo (Schema);
        fprintf (fp, ", [");

        for (; renamelist->Kind != kNoRename;
            renamelist=renamelist->Rename.Next) {

            idlist = renamelist->Rename.OldIdent;    
            if (idlist->Id.Next->Kind == kNoId) {
                QuId = NoIdent;
                Ident = idlist->Id.Ident.Ident;
            }
            else 
                for (; idlist->Kind != kNoId; idlist=idlist->Id.Next)
                    if (idlist->Id.Next->Kind != kNoId &&
                        idlist->Id.Next->Id.Next->Kind == kNoId) {

                        Ident = idlist->Id.Next->Id.Ident.Ident;
                        store = idlist->Id.Next;
                        idlist->Id.Next = mNoId();
                        QuId = FormtIdent (renamelist->Rename.OldIdent);
                        idlist->Id.Next = store;
                        break;
                    }

            fldlist = SchTy->Tp_Schema.Tp_SchFieldList;
            for (; fldlist; fldlist = fldlist->Tp_SchField.Next)
                if (Ident == fldlist->Tp_SchField.Ident &&
                    QuId == fldlist->Tp_SchField.QuId) {

                    if (fst) {
                        fprintf (fp, "'schema.//'(");
                        fst = false;
                    }
                    else
                        fprintf (fp, ", 'schema.//'(");

		    ParentModId = ImportAsMod (fldlist->Tp_SchField.ModId);
		    if (ParentModId != NoIdent)
			mygetstr (ParentModId, prefix);
		    else 
			prefix[0] = '\0';
                    mygetstr (fldlist->Tp_SchField.ModId, modstr);
		    if (prefix[0] != '\0') {
			strcat (prefix, "_");
			strcat (prefix, modstr);
			modstr[0] = '\0';
			strcpy (modstr, prefix);
		    }
                    mygetstr (fldlist->Tp_SchField.Ident, oldidstr);
                    mygetstr (renamelist->Rename.NewIdent.Ident, newidstr);

		/* Added by Luke Wildman 19/6/96 code to print different types
                   of variables used as new variables in substitution */
		/* if the variable is a schema variable then */

                /* 29/8/96 just print out name of NewIdent in all cases */

                /* SymPtr = LookUp(DeclsIn, renamelist->Rename.NewIdent.Ident, NoSym);

                   if (SymPtr && SymPtr->Kind == kObj_Id &&
	               (SymPtr->Obj_Id.VarKind == Is_zvar ||
                        SymPtr->Obj_Id.VarKind == Is_local ||
                        SymPtr->Obj_Id.VarKind == Is_schincl)) {
                       if (newidstr[strlen(newidstr)-1] == '\'')
                          fprintf (fp, "param_const('schema.state_var', '%s#%s'')", cur_mod_name, newidstr);
                       else
                          fprintf (fp, "param_const('schema.state_var', '%s#%s')", cur_mod_name, newidstr);
                   } */ 
		/* 3/7/96 Luke Wildman no more object variables
                   If the variable is an object variable 
	           else if (SymPtr && SymPtr->Kind == kObj_Id && 
                               SymPtr->Obj_Id.VarKind == Is_local) {
		            fprintf (fp, "!");
		            if (idstr[strlen(idstr) -1] == '\'')
		                fprintf (fp, "'%s''", newidstr);
		            else
		                fprintf (fp, "'%s'", newidstr);
	           } */


                    if (newidstr[strlen(newidstr)-1] == '\'')
                        fprintf (fp, "param_const('schema.state_var', '%s#%s'')", cur_mod_name, newidstr);
                    else
                        fprintf (fp, "param_const('schema.state_var', '%s#%s')", cur_mod_name, newidstr);

                    if (oldidstr[strlen(oldidstr)-1] == '\'')
                        /*fprintf (fp, ", 'schema.@'(param_const('schema.state_var', '%s#%s''), !_s))", modstr, oldidstr);*/
                        fprintf (fp, ", param_const('schema.state_var', '%s#%s''))", modstr, oldidstr);
                    else
                        /*fprintf (fp, ", 'schema.@'(param_const('schema.state_var', '%s#%s'), !_s))", modstr, oldidstr);*/
                        fprintf (fp, ", param_const('schema.state_var', '%s#%s'))", modstr, oldidstr);

                    break;
            }
        }
        fprintf (fp, "])\n");
    }
}

/* Expressions */

void Tr_Variable (DeclsIn, IdList, SymPtr, IsBinding)
/* ordinary name reference
 * schema binding
 * zvar reference
 * schema and primed-schema reference
 */
    tObjects DeclsIn;
    tTree IdList;
    tObjects SymPtr;
    bool IsBinding;
{
    tTree idlist=IdList;
    char idstr[IDENT_LENGTH], modidstr[IDENT_LENGTH];
    bool pred_was_import_as=false;
    tObjects declsin;

	/* ?? schema binding is not handled */

    if (IsBinding) TrError (IdList->Id.Ident.Pos, tr_error13);

    if (SymPtr == NoSym) { return; }

    modidstr[0] = '\0';
    if (idlist->Id.Next->Kind == kNoId) {
	if (SymPtr->Object.ModId != NoIdent) {
 	    mygetstr(SymPtr->Object.ModId, modidstr);
	}
    }
    else {
	/* handle the qualified name referring from an imported module */ 

	for (declsin=DeclsIn; declsin && declsin->Kind != kNoObject; 
	         declsin=declsin->Object.Pre) {
	     if (idlist->Id.Ident.Ident == declsin->Object.Ident &&
				declsin->Kind == kObj_Inn && 
				declsin->Obj_Inn.ObjKind == Obj_import) {
		if (declsin->Obj_Inn.ImportHasAsPart) {
		    mygetstr(idlist->Id.Ident.Ident, idstr);
		    sprintf (modidstr, "%s_%s", cur_mod_name, idstr);
		    pred_was_import_as = true;
		}
		else {
		    mygetstr(idlist->Id.Ident.Ident, modidstr);
		    pred_was_import_as = false;
		}
		break;
	     }
	}

	if (modidstr[0] != '\0') { /* is a qualified name */
	    idlist = idlist->Id.Next;
	    for (; idlist->Kind != kNoId; idlist=idlist->Id.Next) {
		if (idlist->Id.Next->Kind == kNoId) 
	 	   break; 
		for (declsin=declsin->Obj_Inn.Inner; 
			 declsin && declsin->Kind != kNoObject; 
			 declsin=declsin->Object.Next)

		    if (idlist->Id.Ident.Ident == declsin->Object.Ident &&
				declsin->Kind == kObj_Inn && 
				declsin->Obj_Inn.ObjKind == Obj_import) {
			if (declsin->Obj_Inn.ImportHasAsPart) {
			    idstr[0] = '\0';
			    mygetstr(idlist->Id.Ident.Ident, idstr);
			    strcat (modidstr,"_");
			    strcat (modidstr, idstr);
			    pred_was_import_as = true;
			}
			else {
			    pred_was_import_as = false;
			    modidstr[0] = '\0';
			    mygetstr (idlist->Id.Ident.Ident, modidstr);
			}
			break;
		    }
		    if (declsin == NULL || declsin->Kind == kNoObject)
			break;
		}
	}
    }

    mygetstr (idlist->Id.Ident.Ident, idstr);
    /* a reference to an object in a schema signature */ 
    if (SymPtr && SymPtr->Kind == kObj_Id &&
	 (SymPtr->Obj_Id.VarKind == Is_zvar ||
          SymPtr->Obj_Id.VarKind == Is_local || 
          SymPtr->Obj_Id.VarKind == Is_schincl)) {
        fprintf (fp, "'schema.@'(param_const('schema.state_var', '%s#", modidstr);
	if (idstr[strlen(idstr) -1] == '\'')
	    fprintf (fp, "%s''", idstr);
	else
	    fprintf (fp, "%s'", idstr);

        fprintf (fp, "), !_s)");
    }
	/* base types */
    else if (Ident_int == idlist->Id.Ident.Ident)
		fprintf (fp, "'iarith.ints'");
	 else if (Ident_nat == idlist->Id.Ident.Ident)
		fprintf (fp, "'iarith.nats'");
	 else if (Ident_nat_1 == idlist->Id.Ident.Ident)
		fprintf (fp, "'iarith.pos_ints'");
	 else if (Ident_bool == idlist->Id.Ident.Ident)
		fprintf (fp, "'bools.bools'");
	 else if (Ident_char == idlist->Id.Ident.Ident)
		fprintf (fp, "'char.chars'");
/* handle integer, natural_1, integer_first, integer_last here wj 4/8/99 */
	else if (Ident_integer == idlist->Id.Ident.Ident)
		fprintf (fp, "'arefine.integer'");
	else if (Ident_natural_1 == idlist->Id.Ident.Ident)
		fprintf (fp, "'arefine.natural_1'");
	else if (Ident_integer_first == idlist->Id.Ident.Ident)
		fprintf (fp, "'arefine.minint'");
	else if (Ident_integer_last == idlist->Id.Ident.Ident)
		fprintf (fp, "'arefine.maxint'");
         /* 3/7/96 Luke Wildman no more object variables 
	 else if (SymPtr && SymPtr->Kind == kObj_Id && 
                      SymPtr->Obj_Id.VarKind == Is_local) {
		fprintf (fp, "!");

		if (idstr[strlen(idstr) -1] == '\'')
		    fprintf (fp, "'%s''", idstr);
		else
		    fprintf (fp, "'%s'", idstr);
	 } */
	 else { /* the rest case */ 
	 /* 5 Mar. 1996, Li Wang
		if (below_sch_line && SymPtr && SymPtr->Object.Type && 
			SymPtr->Object.Type->Kind == kTp_Schema) 
			fprintf (fp, "'schema.schema_ex_pred'(");
		if (modidstr[0] == '\0')
			fprintf (fp, "'");
		else  
			fprintf (fp, "'%s.", modidstr);

		if (idstr[strlen(idstr) -1] == '\'')
			fprintf (fp, "%s''", idstr);
		else
			fprintf (fp, "%s'", idstr);
		if (below_sch_line && SymPtr && SymPtr->Object.Type && 
			SymPtr->Object.Type->Kind == kTp_Schema) 
			fprintf (fp, ", !_s)");
	*/
		if (modidstr[0] == '\0')
			fprintf (fp, "'");
		else  
			fprintf (fp, "'%s.", modidstr);

		if (idstr[strlen(idstr) -1] == '\'')
			fprintf (fp, "%s''", idstr);
		else
			fprintf (fp, "%s'", idstr);
	}
}

void Tr_Literal (Ident)
    tIdPos Ident;
{
    char idstr[IDENT_LENGTH];

    mygetstr(Ident.Ident, idstr);
    fprintf (fp, "param_const('iarith.intconst', '%s')", idstr);
}

void Tr_PrefixOp (Prefix, Exp)
    tIdPos Prefix;
    tTree Exp;
{
    char idstr[IDENT_LENGTH];

    mygetstr (Prefix.Ident, idstr);
    if (Prefix.Ident == Ident_gen_union || Prefix.Ident == Ident_gen_inter
        || Prefix.Ident == Ident_power || Prefix.Ident == Ident_power_1)
        
        fprintf (fp, "'zsets.z_%s'(", idstr); 
    
    else if (Prefix.Ident == Ident_seq)
        fprintf (fp, "'zseq.z_sequence'(");

    else if (Prefix.Ident == Ident_seq_1)
        fprintf (fp, "'zseq.z_sequence_1'(");

    else if (Prefix.Ident == Ident_iseq)
        fprintf (fp, "'zseq.z_isequence'(");

    else if (Prefix.Ident == Ident_bag)
        fprintf (fp, "'zbag.z_%s'(", idstr);

    else if (Prefix.Ident == Ident_finite || Prefix.Ident == Ident_finite_1)
        fprintf (fp, "'zfin.z_%s_power'(", idstr);

    else if (Prefix.Ident == Ident_dom) 
        fprintf (fp, "'zrel.z_domain'(");

    else if (Prefix.Ident == Ident_ran) 
        fprintf (fp, "'zrel.z_range'(");

	/* Mark Utting comments: Map it to z_ident(T),
	   where T is the base type of the domain
       (or range) of the relation. */
    else if (Prefix.Ident == Ident_id)
        fprintf (fp, "'zrel.z_ident'(");
    
    else if (Prefix.Ident == Ident_card)
        fprintf (fp, "'zfin.z_card'(");
    
    else if (Prefix.Ident == Ident_sub)
        fprintf (fp, "'iarith.-'(");

    else if (Prefix.Ident == Ident_rev)
        fprintf (fp, "'zseq.z_reverse'(");


    TransErgo (Exp);
    fprintf (fp, ")");
}

void Tr_InfixOp (Exp1, Infix, Exp2)
    tTree Exp1, Exp2;
    tIdPos Infix;
{
    char idstr[IDENT_LENGTH];

    mygetstr (Infix.Ident, idstr);

    if (Infix.Ident == Ident_add || 
        Infix.Ident == Ident_div || Infix.Ident == Ident_mod ||
        Infix.Ident == Ident_expo || Infix.Ident == Ident_mult)
    
        fprintf (fp, "'iarith.%s'(", idstr);

/* include IL here for subc, addc, multc, divc, modc, expc, uptoc, andc orc, xorc, notc   wj 4/8/99 */
    if (Infix.Ident == Ident_addc || Infix.Ident == Ident_subc ||
        Infix.Ident == Ident_divc || Infix.Ident == Ident_modc ||
        Infix.Ident == Ident_expc || Infix.Ident == Ident_multc ||
        Infix.Ident == Ident_uptoc || Infix.Ident == Ident_andc ||
        Infix.Ident == Ident_orc || Infix.Ident == Ident_xorc ||
        Infix.Ident == Ident_notc )
    
        fprintf (fp, "'arefine.%s'(", idstr);

    else if (Infix.Ident == Ident_sub) 
	/* a-b is translated as a+(-b) */
        fprintf (fp, "'iarith.+'(");
    
    else if (Infix.Ident == Ident_upto) 
        fprintf (fp, "'fin.up_to'(");

    else if (Infix.Ident == Ident_totalfunc ||
        Infix.Ident == Ident_partfunc ||
        Infix.Ident == Ident_totalinj ||
        Infix.Ident == Ident_partinj  ||
        Infix.Ident == Ident_totalsur ||
        Infix.Ident == Ident_partsur  ||
        Infix.Ident == Ident_bij      ||
        Infix.Ident == Ident_fpartfunc ||
        Infix.Ident == Ident_fpartinj ||
        Infix.Ident == Ident_func_override)

        fprintf (fp, "'zfunc.z_%s'(", idstr);

    else if (Infix.Ident == Ident_dom_restrict)
        fprintf (fp, "'zrel.z_domain_restrict'(");

    else if (Infix.Ident == Ident_f_compose)
         fprintf (fp, "'z_compose'(");

    else if (Infix.Ident == Ident_b_compose)
         fprintf (fp, "'zrel.z_bkwd_compose'(");

    else if (Infix.Ident == Ident_ran_restrict)
        fprintf (fp, "'zrel.z_range_restrict'(");

    else if (Infix.Ident == Ident_dom_subtract)
        fprintf (fp, "'zrel.z_domain_anti_restrict'(");

    else if (Infix.Ident == Ident_ran_subtract)
        fprintf (fp, "'zrel.z_range_anti_restrict'(");

    else if (Infix.Ident == Ident_relation)
        fprintf (fp, "'zrel.z_<-->'(");

    else if (Infix.Ident == Ident_maplet)
        /*fprintf (fp, "'zrel.z_maps_to'(");*/
        fprintf (fp, "'zsets.z_ordered_pair'(");

    else if (Infix.Ident == Ident_bag_union)
		fprintf (fp, "'zbag.z_bag_union'(");

    else if (Infix.Ident == Ident_union ||
        Infix.Ident == Ident_diff ||
        Infix.Ident == Ident_inter ||
/* wj -- include sym_diff 3/11/98 */
	Infix.Ident == Ident_sym_diff )
        fprintf (fp, "'zsets.z_%s'(", idstr);

    else if (Infix.Ident == Ident_concat)

        fprintf (fp, "'zseq.z_concat'(");

    TransErgo (Exp1);
    fprintf (fp, ", ");
	if (Infix.Ident == Ident_sub) {
        fprintf (fp, "'iarith.-'(");
		TransErgo (Exp2);
		fprintf (fp, "))");
	}
	else {
		TransErgo (Exp2);
		fprintf (fp, ")");
	}
}

void Tr_FncApplication (Exp, ExpList)
    tTree Exp, ExpList;
{
    int array_indicator = 0;
    tTree explist=ExpList;

	if (Exp->Kind == kVariable) {
		if (Exp->Variable.IdList->Id.Ident.Ident == Ident_front)
			fprintf (fp, "'zseq.z_front'(");
		else if (Exp->Variable.IdList->Id.Ident.Ident == Ident_last)
			fprintf (fp, "'zseq.z_last'(");
		else if (Exp->Variable.IdList->Id.Ident.Ident == Ident_head)
			fprintf (fp, "'zseq.z_head'(");
		else if (Exp->Variable.IdList->Id.Ident.Ident == Ident_tail)
			fprintf (fp, "'zseq.z_tail'(");
		else if (Exp->Variable.IdList->Id.Ident.Ident == Ident_first)
			fprintf (fp, "'zsets.z_first'(");
		else if (Exp->Variable.IdList->Id.Ident.Ident == Ident_second)
			fprintf (fp, "'zsets.z_second'(");
		else if (Exp->Variable.IdList->Id.Ident.Ident == Ident_inverse)
			fprintf (fp, "'zrel.z_inverse'(");
		else if (Exp->Variable.IdList->Id.Ident.Ident == Ident_iter)
			fprintf (fp, "'zrel.z_iter'(");
		else if (Exp->Variable.IdList->Id.Ident.Ident == Ident_t_closure)
			fprintf (fp, "'zrel.z_t_closure'(");
		else if (Exp->Variable.IdList->Id.Ident.Ident == Ident_rt_closure)
			fprintf (fp, "'zrel.z_rt_closure'(");
/* wj 4/8/99, handle IL array */
		else if (Exp->Variable.IdList->Id.Ident.Ident == Ident_array)
			{fprintf(fp, "'zfunc.z_-->'(");
			array_indicator = 1;}
		else {
			fprintf (fp, "'zfunc.z_at'(");
			TransErgo (Exp);
			fprintf (fp, ", ");
		}
	}
	else {
		fprintf (fp, "'zfunc.z_at'(");
		TransErgo (Exp);
		fprintf (fp, ", ");
	}

    if (ExpList->Exp.Next->Kind == kNoExp)
        TransErgo (ExpList);
    else if (array_indicator==1) {
	Tr_ExpList(explist);
    }
    else {
        fprintf (fp, "'zsets.z_tuple'(["); 
		Tr_ExpList(explist);
		fprintf (fp, "])");
    }    
    
    fprintf (fp, ")");
}


void Tr_SetComp(SchemaText, Exp)
    tTree SchemaText, Exp;
{
    tTree vardecllist=SchemaText->SchemaText.DeclList;
    tTree idlist=NoTree;
    char idstr[IDENT_LENGTH]; 

    /* if there is an expression then use that as the type of the set */
    
    if (Exp->Kind != kNoExp){
      fprintf (fp, "(!!'zsets.zset_of' [(!_t: ");
      TransTpExp (Exp->Exp.Type);
      fprintf (fp, ")] \n");
    }
    /*else if there is only one variable then use a new variable of its type */
    /* do not use z_cross */

    else if (vardecllist->VarDecl.Next->Kind == kNoDecl &&
        vardecllist->VarDecl.IdList->Id.Next->Kind == kNoId) {

        mygetstr (vardecllist->VarDecl.IdList->Id.Ident.Ident, idstr);    
        fprintf (fp, "(!!'zsets.zset_of' [(!_t: ");
        TransErgo (vardecllist->VarDecl.Exp);
        fprintf (fp, ")] \n");
    } 
    else {

    /*for more than one variable use a new set-variable of cross product type */

    fprintf (fp, "(!!'zsets.zset_of' [!_t: 'zsets.z_cross'(["); 

    /* print cross product type list */

    for (; vardecllist->Kind != kNoDecl;
        vardecllist=vardecllist->VarDecl.Next) 

        for (idlist=vardecllist->VarDecl.IdList; 
             idlist->Kind != kNoId; idlist=idlist->Id.Next) {
            
            TransErgo (vardecllist->VarDecl.Exp);
            if (vardecllist->VarDecl.Next->Kind == kNoDecl &&
                idlist->Id.Next->Kind == kNoId) 
                break;

            fprintf (fp, ", ");
        }
    fprintf (fp, "]) ] \n");
    }
    /* create predicate using schema_ex_p, and a schema of declared variables */

    fprintf(fp, "'func.lambda_at'('schema.schema_ex_p'('schema.schema'([");
  
    vardecllist =SchemaText->SchemaText.DeclList; 

    Tr_VarDeclList(vardecllist);
    
    fprintf (fp, "],\n "); 

    /* equate set-var and schema variables for raised predicate body */

    fprintf (fp, "(!!'func.lambda' [!_s: 'schema.sitns'] 'ergo.='(!_t, ");
    
    /* if there is an expression component use that */

    if (Exp->Kind != kNoExp){
/* wj -- try replacement */
	Tr_ExpList(Exp);
/*        TransAda(Exp);*/
        fprintf (fp, ") ");
    }
    /* else if only one variable then use that type */

    else if (vardecllist->VarDecl.Next->Kind == kNoDecl &&
        vardecllist->VarDecl.IdList->Id.Next->Kind == kNoId) {

        mygetstr (vardecllist->VarDecl.IdList->Id.Ident.Ident, idstr);    
        if (idstr[strlen(idstr)-1] == '\'')
            fprintf (fp, "'schema.@'(param_const('schema.state_var', '%s#%s''), !_s)", cur_mod_name, idstr);
        else
            fprintf (fp, "'schema.@'(param_const('schema.state_var', '%s#%s'), !_s)", cur_mod_name, idstr);

        fprintf (fp, ") ");
    } 
    else { /* otherwise use tuple */

        fprintf (fp, "'zsets.z_tuple'([");

        for (; vardecllist->Kind != kNoDecl;
             vardecllist=vardecllist->VarDecl.Next) 

             for (idlist=vardecllist->VarDecl.IdList; 
                 idlist->Kind != kNoId; idlist=idlist->Id.Next) {

                 mygetstr (idlist->Id.Ident.Ident, idstr);
                 if (idstr[strlen(idstr)-1] == '\'')
                    fprintf (fp, "'schema.@'(param_const('schema.state_var', '%s#%s''), !_s)", cur_mod_name, idstr);
                 else
                    fprintf (fp, "'schema.@'(param_const('schema.state_var', '%s#%s'), !_s)", cur_mod_name, idstr);


                 if  (vardecllist->VarDecl.Next->Kind == kNoDecl &&
                     idlist->Id.Next->Kind == kNoId)
                     break;
                 else
                     fprintf (fp, ", ");
             }

         /* close tuple list, z_tuple, ergo.= */
        /* fprintf (fp, "]) ),  ");*/
	fprintf (fp, "]) )  ");

    } /*else*/

    /* close raised predicate and schema */
    fprintf (fp, " )), \n ");

    /* print set predicate as raised predicate */

    fprintf (fp, "(!!'func.lambda' [!_s: 'schema.sitns'] ");

	Tr_PredList (SchemaText->SchemaText.PredList); 
    
    /* close raised predicate, schema_ex_p, apply situation, close zset_of */

    fprintf(fp, ")), !_s))");

}


/* Old Version of Tr_set-comprehension using object variables 

void Tr_SetComp (VarDeclList, PredList)
    tTree VarDeclList, PredList;
{
    tTree vardecllist=VarDeclList;
    tTree idlist=NoTree;
    int c = 0;
    char idstr[IDENT_LENGTH]; 

    * if there is only one variable then do not use z_cross *

    if (VarDeclList->VarDecl.Next->Kind == kNoDecl &&
        VarDeclList->VarDecl.IdList->Id.Next->Kind == kNoId) {

        mygetstr (VarDeclList->VarDecl.IdList->Id.Ident.Ident, idstr);    
        fprintf (fp, "(!!'zsets.zset_of' [(!_'%s': ", idstr);
        TransErgo (VarDeclList->VarDecl.Exp);
        fprintf (fp, ")] ");
        Tr_PredList (PredList);
        fprintf (fp, ")\n");
        return;                  * RETURN *
    }

    *for more than one variable use a new set-variable of cross product type *

    fprintf (fp, "(!!'zsets.zset_of' [!_t: 'zsets.z_cross'(["); 

    * print cross product type list *

    for (vardecllist=VarDeclList; vardecllist->Kind != kNoDecl;
        vardecllist=vardecllist->VarDecl.Next) 

        for (idlist=vardecllist->VarDecl.IdList; 
             idlist->Kind != kNoId; idlist=idlist->Id.Next) {
            
            TransErgo (vardecllist->VarDecl.Exp);
            if (vardecllist->VarDecl.Next->Kind == kNoDecl &&
                idlist->Id.Next->Kind == kNoId) 
                break;

            fprintf (fp, ", ");
        }
    fprintf (fp, "]) ] \n");

    * print each variable as an existentially quantified object variable *

    for (vardecllist=VarDeclList; vardecllist->Kind != kNoDecl;
        vardecllist=vardecllist->VarDecl.Next) {

        for (idlist=vardecllist->VarDecl.IdList; 
             idlist->Kind != kNoId; idlist=idlist->Id.Next) {

            c++;
            mygetstr (idlist->Id.Ident.Ident, idstr);
            fprintf (fp, "(!!'zsets.z_ex' [!_'%s': ", idstr);
            TransErgo (vardecllist->VarDecl.Exp); 
            fprintf (fp, "] ");
        }
    }

    * equat set-variable with tuple of quantified variables *

    fprintf (fp, "'ergo.and'('ergo.='(!_t, 'zsets.z_tuple'([");

    for (vardecllist=VarDeclList; vardecllist->Kind != kNoDecl;
        vardecllist=vardecllist->VarDecl.Next) 

        for (idlist=vardecllist->VarDecl.IdList; 
             idlist->Kind != kNoId; idlist=idlist->Id.Next) {

            mygetstr (idlist->Id.Ident.Ident, idstr);
            fprintf (fp, "!'%s'", idstr); 
            if  (vardecllist->VarDecl.Next->Kind == kNoDecl &&
                idlist->Id.Next->Kind == kNoId)
                break;
            else
                fprintf (fp, ", ");
        }

    fprintf (fp, "]) ),  ");
    Tr_PredList (PredList);
    for (; c>0; c--)
        fprintf (fp, ")"); 
    fprintf (fp, "))\n"); 
}

*/
        
void Tr_SetElab (ExpList)
    tTree ExpList;
{
    tTree explist=ExpList;

    if (ExpList->Kind == kNoExp) { /* empty set */
        fprintf (fp, "'zfc.empty_set'");
        return;
    }

    fprintf (fp, "'zsets.z_set'([");
    Tr_ExpList(explist);
    fprintf (fp, "])\n");

    /* another approach, which also applies to bag, sequence, etc.
    int num=0;
    fprintf (fp, "'zsets.z_set'(");
    for (; explist->Kind != kNoExp; explist=explist->Exp.Next) {
        fprintf (fp, "'p_list..'(");
        TransErgo (explist);
        fprintf (fp, ", ");
        num++;
    }
    fprintf (fp, "'p_list.[]'");
    for (; num>0; num--)
        fprintf (fp, ")");
    
    fprintf (fp, ")\n");
     */
}

void Tr_Bag (ExpList)
    tTree ExpList;
{
    tTree explist=ExpList;

    if (ExpList->Kind == kNoExp) { /* empty bag */
        fprintf (fp, "'zbag.z_empty_bag'");
        return;
    }

    fprintf (fp, "'zbag.the_z_bag'([");
    Tr_ExpList(explist);
    fprintf (fp, "])\n");
}

void Tr_Tuple (ExpList)
    tTree ExpList;
{
    tTree explist=ExpList;

    fprintf (fp, "'zsets.z_tuple'([");
    Tr_ExpList(explist);
    fprintf (fp, "])");
}

void Tr_Sequence (ExpList)
    tTree ExpList;
{
    tTree explist=ExpList;

    if (explist->Kind == kNoExp) {
        fprintf (fp, "'zseq.z_empty_seq'");
        return;
    }

    fprintf (fp, "'zseq.z_seq'([");
    Tr_ExpList(explist);
    fprintf (fp, "])\n");
}
   
void Tr_TupSelection (Exp, Number)
    tTree Exp;
    tIdPos Number;
{
    char idstr[IDENT_LENGTH];

    fprintf (fp, "'zsets.nth'(");
    TransErgo (Exp);
    mygetstr (Number.Ident, idstr);
    fprintf (fp, ", %s)", idstr);
}

void Tr_CartProd (ExpList)
    tTree ExpList;
{
    tTree explist=ExpList;

    fprintf (fp, "'zsets.z_cross'([");
    Tr_ExpList(explist);
    fprintf (fp, "])\n");
}

void Tr_IfExp (Cond, Then, Else)
    tTree Cond, Then, Else;
{
	tType ty;

    fprintf (fp, "'if.if'(");
	ty = Cond->Pred.Type;
	if (ty && ty->Kind == kTp_Schema && below_sch_line) {
		fprintf (fp, "'schema.schema_ex_pred'(");
		TransErgo (Cond);
		fprintf (fp, ", !_s)");
	}
	else 
		TransErgo (Cond);

    fprintf (fp, ", ");
    TransErgo (Then);
    fprintf (fp, ", ");
    TransErgo (Else);
    fprintf (fp, ")\n");
}


void Tr_Lambda (SchemaText, Exp)
    tTree SchemaText, Exp;
{
    /* very similar to set comprehension */

    tTree vardecllist=SchemaText->SchemaText.DeclList;
    tTree idlist=NoTree;
    char idstr[IDENT_LENGTH]; 

    /* if there is only one variable then use a new variable of its type */
    /* do not use z_cross */

    if (vardecllist->VarDecl.Next->Kind == kNoDecl &&
        vardecllist->VarDecl.IdList->Id.Next->Kind == kNoId) {

        mygetstr (vardecllist->VarDecl.IdList->Id.Ident.Ident, idstr);    
        fprintf (fp, "(!!'func.lambda' [(!_t: ");
        TransErgo (vardecllist->VarDecl.Exp);
        fprintf (fp, ")] \n");
    } 
    else {

    /*for more than one variable use a new set-variable of cross product type */

    fprintf (fp, "(!!'func.lambda' [!_t: 'zsets.z_cross'(["); 

    /* print cross product type list */

    for (; vardecllist->Kind != kNoDecl;
        vardecllist=vardecllist->VarDecl.Next) 

        for (idlist=vardecllist->VarDecl.IdList; 
             idlist->Kind != kNoId; idlist=idlist->Id.Next) {
            
            TransErgo (vardecllist->VarDecl.Exp);
            if (vardecllist->VarDecl.Next->Kind == kNoDecl &&
                idlist->Id.Next->Kind == kNoId) 
                break;

            fprintf (fp, ", ");
        }
    fprintf (fp, "]) ] \n");
    }
    /* the result is some value which equals the expression */
    /* create domain using schema_ex_p, and a schema of declared variables */

    fprintf(fp, "!!'sm.sm'[!_a] 'func.lambda_at'('schema.schema_ex_p'('schema.schema'([\n");
  
    vardecllist = SchemaText->SchemaText.DeclList; 

    Tr_VarDeclList(vardecllist);
    
    fprintf (fp, "],\n "); 

    /* equate set-var and schema variables for raised predicate body */

    fprintf (fp, "(!!'func.lambda' [!_s: 'schema.sitns'] 'ergo.and'('ergo.='(!_t, ");

    /* if only one variable then use that type */

    if (vardecllist->VarDecl.Next->Kind == kNoDecl &&
        vardecllist->VarDecl.IdList->Id.Next->Kind == kNoId) {

        mygetstr (vardecllist->VarDecl.IdList->Id.Ident.Ident, idstr);    
        if (idstr[strlen(idstr)-1] == '\'')
            fprintf (fp, "'schema.@'(param_const('schema.state_var', '%s#%s''), !_s)", cur_mod_name, idstr);
        else
            fprintf (fp, "'schema.@'(param_const('schema.state_var', '%s#%s'), !_s)", cur_mod_name, idstr);

        fprintf (fp, "), ");
    } 
    else { /* otherwise use tuple */

        fprintf (fp, "'zsets.z_tuple'([");

        for (; vardecllist->Kind != kNoDecl;
             vardecllist=vardecllist->VarDecl.Next) 

             for (idlist=vardecllist->VarDecl.IdList; 
                 idlist->Kind != kNoId; idlist=idlist->Id.Next) {

                 mygetstr (idlist->Id.Ident.Ident, idstr);
                 if (idstr[strlen(idstr)-1] == '\'')
                    fprintf (fp, "'schema.@'(param_const('schema.state_var', '%s#%s''), !_s)", cur_mod_name, idstr);
                 else
                    fprintf (fp, "'schema.@'(param_const('schema.state_var', '%s#%s'), !_s)", cur_mod_name, idstr);


                 if  (vardecllist->VarDecl.Next->Kind == kNoDecl &&
                     idlist->Id.Next->Kind == kNoId)
                     break;
                 else
                     fprintf (fp, ", ");
             }

         /* close tuple list, z_tuple, ergo.= */
        fprintf (fp, "]) ),  ");

    } /*else*/

    /* add in predicate from SchemaText

	/*wj --- need true for the empty predicate part */
	if (Tree_IsType(SchemaText->SchemaText.PredList,kNoPred))
		fprintf(fp, "'ergo.true' ");
	else
    		TransErgo(SchemaText->SchemaText.PredList);

    /* close ergo.and, raised predicate and schema */
    fprintf (fp, " ))), \n ");

    /* print a = lambda expression as raised predicate */

    fprintf (fp, "(!!'func.lambda' [!_s: 'schema.sitns'] 'ergo.='(!_a, ");

    TransErgo(Exp); 
    
    /* close ergo.=, raised predicate, schema_ex_p, apply situation, */
    /* close lambda */

    fprintf(fp, "))), !_s))");

}

void Tr_Mu(SchemaText, Exp)
    tTree SchemaText, Exp;
{}

void Tr_RecDisp(SchemaText, PredList)
    tTree SchemaText, PredList;
{}

void Tr_Exp_SchemaRef (IdList, ExpList) 
    tTree IdList, ExpList;
{
}

void Tr_TpName (ModId, Ident)
    tIdent ModId, Ident;
{
    char idstr[IDENT_LENGTH], modstr[IDENT_LENGTH], prefix[IDENT_LENGTH];
	tIdent ParentModId=NoIdent;	

    idstr[0] = '\0';
    if (Ident_nat == Ident) {
        strcpy(idstr, "iarith.nats");
        fprintf (fp, "'%s'", idstr);
		return;
	}
    else if (Ident_nat_1 == Ident) {
        strcpy(idstr, "iarith.pos_ints");
        fprintf (fp, "'%s'", idstr);
		return;
	}
    else if (Ident_int == Ident) {
        strcpy(idstr, "iarith.ints");
        fprintf (fp, "'%s'", idstr);
		return;
	}
    else if (Ident_bool == Ident) {
        strcpy(idstr, "bools.bools");
        fprintf (fp, "'%s'", idstr);
		return;
	}
/* insert here the IL integer stuff, wj 4/8/99 */
    else if (Ident_integer == Ident) {
        strcpy(idstr, "arefine.integer");
        fprintf (fp, "'%s'", idstr);
		return;
	}
    else if (Ident_natural_1 == Ident) {
        strcpy(idstr, "arefine.natural_1");
        fprintf (fp, "'%s'", idstr);
		return;
	}
    else if (Ident_integer_first == Ident) {
        strcpy(idstr, "arefine.minint");
        fprintf (fp, "'%s'", idstr);
		return;
	}
    else if (Ident_integer_last == Ident) {
        strcpy(idstr, "arefine.maxint");
        fprintf (fp, "'%s'", idstr);
		return;
	}
    else {
        mygetstr (Ident, idstr);
		if (ModId == NoIdent)
			fprintf (fp, "'%s'", idstr);
		else {
			mygetstr (ModId, modstr);
			ParentModId = ImportAsMod (ModId);
			if (ParentModId != NoIdent)
				mygetstr (ParentModId, prefix);
			else 
				prefix[0] = '\0';
			if (prefix[0] != '\0')
				fprintf (fp, "'%s_%s.%s'", prefix, modstr, idstr);
			else
				fprintf (fp, "'%s.%s'", modstr, idstr);
		}
	}
}

void Tr_TpPrefix (Ident, Tp_Exp) 
    tIdent Ident;
    tType Tp_Exp;
{
    char idstr[IDENT_LENGTH];

    mygetstr (Ident, idstr);

    if (Ident == Ident_power || Ident == Ident_power_1)
        
        fprintf (fp, "'zsets.z_%s'(", idstr); 
    
    else if (Ident == Ident_seq)
        fprintf (fp, "'zseq.z_sequence'(");

	else if (Ident == Ident_seq_1)
        fprintf (fp, "'zseq.z_sequence_1'(");

	else if (Ident == Ident_iseq)

        fprintf (fp, "'zseq.z_isequence'(");

    else if (Ident == Ident_bag)

        fprintf (fp, "'zbag.z_%s'(", idstr);

    else if (Ident == Ident_finite ||
        Ident == Ident_finite_1)
    
        fprintf (fp, "'zfin.z_%s_power'(", idstr);

    TransTpExp (Tp_Exp);
    fprintf (fp, ")");
}

void Tr_InfixIdent (Ident)
    tIdent Ident;
{
    char idstr[IDENT_LENGTH];

    mygetstr (Ident, idstr);

    if (Ident == Ident_totalfunc ||
        Ident == Ident_partfunc ||
        Ident == Ident_totalinj ||
        Ident == Ident_partinj  ||
        Ident == Ident_totalsur ||
        Ident == Ident_partsur  ||
        Ident == Ident_bij      ||
        Ident == Ident_fpartfunc ||
        Ident == Ident_fpartinj ||
        Ident == Ident_func_override) 

        fprintf (fp, "'zfunc.z_%s'(", idstr);

    else if (Ident == Ident_dom_restrict)
        fprintf (fp, "'zrel.z_domain_restrict'(");

    else if (Ident == Ident_ran_restrict)
        fprintf (fp, "'zrel.z_range_restrict'(");

    else if (Ident == Ident_dom_subtract)
        fprintf (fp, "'zrel.z_domain_anti_restrict'(");

    else if (Ident == Ident_ran_subtract)
        fprintf (fp, "'zrel.z_range_anti_restrict'(");

    else if (Ident == Ident_relation) 

        fprintf (fp, "'zrel.z_%s'(", idstr);
}


/* REPLACED BY PROCEDURE LPW 5/6/98
void Tr_TpCartProd(Tp_CartList)
    tType Tp_CartList;
{
    tType cartlist=Tp_CartList;

    fprintf (fp, "'zsets.z_cross'([");
 * OT was here *

    for (; cartlist && cartlist->Kind != kTp_NoCart; 
        cartlist=cartlist->Tp_Cart.Next) {

        TransTpExp (cartlist->Tp_Cart.Tp_Exp);
 	if (cartlist->Tp_Cart.Next)  if (cartlist->Tp_Cart.Next->Kind != kTp_NoCart)
            fprintf (fp, ", ");
    }
            
    fprintf (fp, "])\n");
}
*/
 


static void yyExit () { Exit (1); }

void (* Trans_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module Trans, routine %s failed\n", yyFunction);
 Trans_Exit ();
}

void CkPreCond ARGS((tTree t));
void TransErgo ARGS((tTree t));
static void Tr_TpCartList ARGS((tType Tp_CartList));
void TransTpExp ARGS((tType t));

void CkPreCond
# if defined __STDC__ | defined __cplusplus
(register tTree t)
# else
(t)
 register tTree t;
# endif
{

  switch (t->Kind) {
  case kLogicalNot:
/* line 2709 "Trans.puma" */
  {
/* line 2710 "Trans.puma" */
   CkPreCond (t->LogicalNot.Pred);
  }
   return;

  case kRelBinPred:
/* line 2712 "Trans.puma" */
  {
/* line 2713 "Trans.puma" */
   CkPreCond (t->RelBinPred.L);
/* line 2714 "Trans.puma" */
   CkPreCond (t->RelBinPred.R);
  }
   return;

  case kRelPrePred:
/* line 2716 "Trans.puma" */
  {
/* line 2717 "Trans.puma" */
   CkPreCond (t->RelPrePred.Exp);
  }
   return;

  case kSchemaPred:
/* line 2719 "Trans.puma" */
  {
/* line 2720 "Trans.puma" */
   CkPreCond (t->SchemaPred.Schema);
  }
   return;

  case kQuantPred:
/* line 2722 "Trans.puma" */
  {
/* line 2723 "Trans.puma" */
   CkPreCond (t->QuantPred.SchemaText);
/* line 2724 "Trans.puma" */
   CkPreCond (t->QuantPred.Pred);
  }
   return;

  case kLogBinPred:
/* line 2726 "Trans.puma" */
  {
/* line 2727 "Trans.puma" */
   CkPreCond (t->LogBinPred.L);
/* line 2728 "Trans.puma" */
   CkPreCond (t->LogBinPred.R);
  }
   return;

  case kPreCondPred:
/* line 2730 "Trans.puma" */
  {
/* line 2731 "Trans.puma" */
   CkPreCond (t->PreCondPred.Pred);
  }
   return;

  case kExpPred:
/* line 2734 "Trans.puma" */
  {
/* line 2735 "Trans.puma" */
   CkPreCond (t->ExpPred.Exp);
  }
   return;

  case kSchemaText:
/* line 2737 "Trans.puma" */
  {
/* line 2738 "Trans.puma" */
   CkPreCond (t->SchemaText.DeclList);
/* line 2739 "Trans.puma" */
   CkPreCond (t->SchemaText.PredList);
  }
   return;

  case kVariable:
/* line 2742 "Trans.puma" */
  {
/* line 2743 "Trans.puma" */
   IsAllowedQuId (t->Variable.IdList);
  }
   return;

  case kPrefixOp:
/* line 2745 "Trans.puma" */
  {
/* line 2746 "Trans.puma" */
   CkPreCond (t->PrefixOp.Exp);
  }
   return;

  case kIfExp:
/* line 2748 "Trans.puma" */
  {
/* line 2749 "Trans.puma" */
   CkPreCond (t->IfExp.Con);
/* line 2750 "Trans.puma" */
   CkPreCond (t->IfExp.Then);
/* line 2751 "Trans.puma" */
   CkPreCond (t->IfExp.Else);
  }
   return;

  case kFncApplication:
/* line 2753 "Trans.puma" */
  {
/* line 2754 "Trans.puma" */
   CkPreCond (t->FncApplication.Fnc);
/* line 2755 "Trans.puma" */
   CkPreCond (t->FncApplication.Arg);
  }
   return;

  case kInfixOp:
/* line 2757 "Trans.puma" */
  {
/* line 2758 "Trans.puma" */
   CkPreCond (t->InfixOp.Op1);
/* line 2759 "Trans.puma" */
   CkPreCond (t->InfixOp.Op2);
  }
   return;

  case kPredExp:
/* line 2761 "Trans.puma" */
  {
/* line 2762 "Trans.puma" */
   CkPreCond (t->PredExp.Pred);
  }
   return;

  case kVarDecl:
/* line 2765 "Trans.puma" */
  {
/* line 2766 "Trans.puma" */
   IsAllowedIdList (t->VarDecl.IdList);
  }
   return;

  }

;
}

void TransErgo
# if defined __STDC__ | defined __cplusplus
(register tTree t)
# else
(t)
 register tTree t;
# endif
{
  if (t == NULL) {
/* line 2770 "Trans.puma" */
   return;

  }

  switch (t->Kind) {
  case kSum:
/* line 2772 "Trans.puma" */
  {
/* line 2773 "Trans.puma" */
   TransErgo (t->Sum.ModuleList);
  }
   return;

  case kModule:
/* line 2776 "Trans.puma" */
  {
/* line 2776 "Trans.puma" */

		WrtErgoTheory (t->Module.Ident);
		has_state_and_init (t->Module.Next->Module.DeclsIn);
		Tr_Module (t->Module.Ident, t->Module.FormalParams, t->Module.PredList); 
		TransErgo (t->Module.DeclList); 
		EndPartOfMod(t->Module.DeclList);
		TransClose();    
    
/* line 2784 "Trans.puma" */
   TransErgo (t->Module.Next);
  }
   return;

  case kVarDecl:
/* line 2787 "Trans.puma" */
  {
/* line 2788 "Trans.puma" */
   Tr_VarDecl (t->VarDecl.IdList, t->VarDecl.Exp, 0);
/* line 2789 "Trans.puma" */
   TransErgo (t->VarDecl.Next);
  }
   return;

  case kGivenSet:
/* line 2791 "Trans.puma" */
  {
/* line 2792 "Trans.puma" */
   Tr_GivenSet (t->GivenSet.IdList);
/* line 2793 "Trans.puma" */
   TransErgo (t->GivenSet.Next);
  }
   return;

  case kAxiomDecl:
/* line 2795 "Trans.puma" */
  {
/* line 2795 "Trans.puma" */

        if (t->AxiomDecl.FormalParams->Kind != kNoParam)
            TrError (t->AxiomDecl.FormalParams->TyParam.Ident.Pos, tr_error3);
        printf("Checking Predicate in Axiom Decl...\n");
    printf("Ax Dec Pred Checked OK\n");

        TransErgo (t->AxiomDecl.DeclList);
        Tr_Axiom (t->AxiomDecl.PredList);
    
/* line 2804 "Trans.puma" */
   TransErgo (t->AxiomDecl.Next);
  }
   return;

  case kSchemaDef:
/* line 2806 "Trans.puma" */
  {
/* line 2806 "Trans.puma" */

        if (t->SchemaDef.FormalParams->Kind != kNoParam)
            TrError (t->SchemaDef.Ident.Pos, tr_error2);
		below_sch_line = true;
        Tr_SchemaDef (t->SchemaDef.Ident, t->SchemaDef.DeclList, t->SchemaDef.PredList, t->SchemaDef.IsOp, t->SchemaDef.Next->Decl.DeclsIn, t->SchemaDef.HasStateIncl); 
		below_sch_line = false;
    
/* line 2813 "Trans.puma" */
   TransErgo (t->SchemaDef.Next);
  }
   return;

  case kAbbreviation:
/* line 2815 "Trans.puma" */
  {
/* line 2816 "Trans.puma" */
Tr_Abbr (t->Abbreviation.Ident, t->Abbreviation.Exp); 
        TransErgo (t->Abbreviation.Next);
  }
   return;

  case kImport:
/* line 2819 "Trans.puma" */
  {
/* line 2820 "Trans.puma" */
   Tr_Import (t->Import.Ident, t->Import.ExpressionList, t->Import.NewIdent, t->Import.ModIMLlist, t->Import.FmlParams, t->Import.RenameList);
/* line 2821 "Trans.puma" */
   TransErgo (t->Import.Next);
  }
   return;

  case kModuleDecl:
/* line 2823 "Trans.puma" */
  {
/* line 2824 "Trans.puma" */
   TrError (t->ModuleDecl.Module -> Module . Ident . Pos, tr_error4);
  }
   return;

  case kFreeType:
/* line 2826 "Trans.puma" */
  {
/* line 2827 "Trans.puma" */
Tr_FreeType (t->FreeType.Ident, t->FreeType.BranchList);
        TransErgo (t->FreeType.Next);
  }
   return;

  case kConstraint:
/* line 2830 "Trans.puma" */
  {
/* line 2831 "Trans.puma" */
   TrError (t->Constraint.Pred -> Pred . Pos, tr_error10);
  }
   return;

  case kVisibility:
/* line 2833 "Trans.puma" */
  {
/* line 2833 "Trans.puma" */

        if (t->Visibility.SelectionList->Kind == kNoSelection)
            Tr_Visible (t->Visibility.Ident);
        else
            TrError (t->Visibility.Ident.Pos, tr_error6);
    
/* line 2839 "Trans.puma" */
   TransErgo (t->Visibility.Next);
  }
   return;

  case kErgoAnno:
/* line 2840 "Trans.puma" */
  {
/* line 2841 "Trans.puma" */
   Tr_ErgoAnno (t->ErgoAnno.Ident);
/* line 2842 "Trans.puma" */
   TransErgo (t->ErgoAnno.Next);
  }
   return;

  case kNoPred:
/* line 2845 "Trans.puma" */
   return;

  case kQuantPred:
/* line 2847 "Trans.puma" */
  {
/* line 2847 "Trans.puma" */

        Tr_QuantPred (t->QuantPred.LogQuant, t->QuantPred.SchemaText, t->QuantPred.Pred);
		TransErgo (t->QuantPred.Next); 
    
  }
   return;

  case kRelBinPred:
/* line 2852 "Trans.puma" */
  {
/* line 2853 "Trans.puma" */
   Tr_RelBinPred (t->RelBinPred.L, t->RelBinPred.RelBinOp, t->RelBinPred.R);
/* line 2854 "Trans.puma" */
   TransErgo (t->RelBinPred.Next);
  }
   return;

  case kAssign:
/* line 2857 "Trans.puma" */
  {
/* line 2857 "Trans.puma" */
   TransErgo (t->Assign.Next);
  }
   return;

  case kRelPrePred:
/* line 2859 "Trans.puma" */
  {
/* line 2860 "Trans.puma" */
   Tr_RelPrePred (t->RelPrePred.RelPreOp, t->RelPrePred.Exp);
/* line 2861 "Trans.puma" */
   TransErgo (t->RelPrePred.Next);
  }
   return;

  case kLogBinPred:
/* line 2863 "Trans.puma" */
  {
/* line 2864 "Trans.puma" */
   Tr_LogBinPred (t->LogBinPred.L, t->LogBinPred.LogBinOp, t->LogBinPred.R, t->LogBinPred.Next);
  }
   return;

  case kLogicalNot:
/* line 2866 "Trans.puma" */
  {
/* line 2867 "Trans.puma" */
   Tr_LogicalNot (t->LogicalNot.Pred);
/* line 2868 "Trans.puma" */
   TransErgo (t->LogicalNot.Next);
  }
   return;

  case kPreCondPred:
/* line 2870 "Trans.puma" */
  {
/* line 2871 "Trans.puma" */
   Tr_PreCondPred (t->PreCondPred.Pred, t->PreCondPred.Next);
  }
   return;

  case kIfPred:
/* line 2873 "Trans.puma" */
  {
/* line 2873 "Trans.puma" */
   TransErgo (t->IfPred.Next);
  }
   return;

  case kWhilePred:
/* line 2876 "Trans.puma" */
  {
/* line 2876 "Trans.puma" */
   TransErgo (t->WhilePred.Next);
  }
   return;

  case kCallPred:
/* line 2879 "Trans.puma" */
  {
/* line 2879 "Trans.puma" */
   TransErgo (t->CallPred.Next);
  }
   return;

  case kChgOnly:
/* line 2881 "Trans.puma" */
  {
/* line 2882 "Trans.puma" */
   Tr_ChgOnly (t->ChgOnly.NameList, t->ChgOnly.DeclsIn);
/* line 2883 "Trans.puma" */
   TransErgo (t->ChgOnly.Next);
  }
   return;

  case kDefined:
/* line 2886 "Trans.puma" */
  {
/* line 2886 "Trans.puma" */
   TransErgo (t->Defined.Next);
  }
   return;

  case kSchemaPred:
/* line 2888 "Trans.puma" */
  {
/* line 2888 "Trans.puma" */
 
        if (t->SchemaPred.Next->Kind == kNoPred && t->SchemaPred.Schema->Kind == kExpPred)
            TransErgo (t->SchemaPred.Schema); 
        else {
            TransErgo (t->SchemaPred.Schema); 
            TransErgo (t->SchemaPred.Next); 
        }
    
  }
   return;

  case kBoolValue:
/* line 2897 "Trans.puma" */
  {
/* line 2898 "Trans.puma" */
   Tr_BoolValue (t->BoolValue.Ident);
/* line 2899 "Trans.puma" */
   TransErgo (t->BoolValue.Next);
  }
   return;

  case kExpPred:
/* line 2902 "Trans.puma" */
  {
/* line 2903 "Trans.puma" */
   TransErgo (t->ExpPred.Exp);
  }
   return;

  case kSchemaText:
/* line 2905 "Trans.puma" */
  {
/* line 2905 "Trans.puma" */

		below_sch_line = true;	
        Tr_SchemaText (t->SchemaText.DeclList, t->SchemaText.PredList, t->SchemaText.Type); 
		below_sch_line = false;	
	
  }
   return;

  case kSchemaCompos:
/* line 2911 "Trans.puma" */
  {
/* line 2912 "Trans.puma" */
   Tr_SchemaCompos (t->SchemaCompos.Sch1, t->SchemaCompos.Compos, t->SchemaCompos.Sch2);
  }
   return;

  case kSchemaHiding:
/* line 2914 "Trans.puma" */
  {
/* line 2915 "Trans.puma" */
   Tr_SchemaHiding (t->SchemaHiding.Schema, t->SchemaHiding.NameList);
  }
   return;

  case kSchemaProj:
/* line 2917 "Trans.puma" */
  {
/* line 2918 "Trans.puma" */
   Tr_SchemaProj (t->SchemaProj.Sch1, t->SchemaProj.Proj, t->SchemaProj.Sch2);
  }
   return;

  case kSchemaSubst:
/* line 2920 "Trans.puma" */
  {
/* line 2921 "Trans.puma" */
   Tr_SchemaSubst (t->SchemaSubst.DeclsIn, t->SchemaSubst.Schema, t->SchemaSubst.RenameList);
  }
   return;

  case kVariable:
/* line 2925 "Trans.puma" */
  {
/* line 2926 "Trans.puma" */
   Tr_Variable (t->Variable.DeclsIn, t->Variable.IdList, t->Variable.SymPtr, t->Variable.IsBinding);
  }
   return;

  case kLiteral:
/* line 2928 "Trans.puma" */
  {
/* line 2929 "Trans.puma" */
   Tr_Literal (t->Literal.Literal);
  }
   return;

  case kString:
/* line 2931 "Trans.puma" */
  {
/* line 2932 "Trans.puma" */
   TrError (t->String.String . Pos, tr_error7);
  }
   return;

  case kChar:
/* line 2934 "Trans.puma" */
  {
/* line 2935 "Trans.puma" */
   TrError (t->Char.Char . Pos, tr_error8);
  }
   return;

  case kPrefixOp:
/* line 2937 "Trans.puma" */
  {
/* line 2938 "Trans.puma" */
   Tr_PrefixOp (t->PrefixOp.Prefix, t->PrefixOp.Exp);
  }
   return;

  case kInfixOp:
/* line 2940 "Trans.puma" */
  {
/* line 2941 "Trans.puma" */
   Tr_InfixOp (t->InfixOp.Op1, t->InfixOp.Infix, t->InfixOp.Op2);
  }
   return;

  case kFncApplication:
/* line 2943 "Trans.puma" */
  {
/* line 2944 "Trans.puma" */
   Tr_FncApplication (t->FncApplication.Fnc, t->FncApplication.Arg);
  }
   return;

  case kSetComp:
/* line 2946 "Trans.puma" */
  {
/* line 2947 "Trans.puma" */
   Tr_SetComp (t->SetComp.SchemaText, t->SetComp.ExpressionList);
  }
   return;

  case kLambda:
/* line 2949 "Trans.puma" */
  {
/* line 2950 "Trans.puma" */
   Tr_Lambda (t->Lambda.SchemaText, t->Lambda.Exp);
  }
   return;

  case kMu:
/* line 2952 "Trans.puma" */
  {
/* line 2953 "Trans.puma" */
   Tr_Mu (t->Mu.SchemaText, t->Mu.ExpressionList);
  }
   return;

  case kRecDisp:
/* line 2955 "Trans.puma" */
  {
/* line 2956 "Trans.puma" */
   Tr_RecDisp (t->RecDisp.SchemaText, t->RecDisp.PredList);
  }
   return;

  case kSetElab:
/* line 2958 "Trans.puma" */
  {
/* line 2959 "Trans.puma" */
   Tr_SetElab (t->SetElab.ExpressionList);
  }
   return;

  case kSequence:
/* line 2961 "Trans.puma" */
  {
/* line 2962 "Trans.puma" */
   Tr_Sequence (t->Sequence.ExpressionList);
  }
   return;

  case kTuple:
/* line 2964 "Trans.puma" */
  {
/* line 2965 "Trans.puma" */
   Tr_Tuple (t->Tuple.ExpressionList);
  }
   return;

  case kBag:
/* line 2967 "Trans.puma" */
  {
/* line 2968 "Trans.puma" */
   Tr_Bag (t->Bag.ExpressionList);
  }
   return;

  case kIfExp:
/* line 2970 "Trans.puma" */
  {
/* line 2971 "Trans.puma" */
   Tr_IfExp (t->IfExp.Con, t->IfExp.Then, t->IfExp.Else);
  }
   return;

  case kCartProd:
/* line 2973 "Trans.puma" */
  {
/* line 2974 "Trans.puma" */
   Tr_CartProd (t->CartProd.ExpressionList);
  }
   return;

  case kVarSelection:
/* line 2976 "Trans.puma" */
  {
/* line 2977 "Trans.puma" */
   TrError (t->VarSelection.Exp -> Exp . Pos, tr_error12);
  }
   return;

  case kTupSelection:
/* line 2979 "Trans.puma" */
  {
/* line 2980 "Trans.puma" */
   Tr_TupSelection (t->TupSelection.Exp, t->TupSelection.Number);
  }
   return;

  case kExp_SchemaRef:
/* line 2982 "Trans.puma" */
  {
/* line 2983 "Trans.puma" */
   Tr_Exp_SchemaRef (t->Exp_SchemaRef.IdList, t->Exp_SchemaRef.ExpressionList);
  }
   return;

  case kPredExp:
/* line 2985 "Trans.puma" */
  {
/* line 2986 "Trans.puma" */
   TransErgo (t->PredExp.Pred);
  }
   return;

  }

/* line 2987 "Trans.puma" */
   return;

;
}

static void Tr_TpCartList
# if defined __STDC__ | defined __cplusplus
(register tType Tp_CartList)
# else
(Tp_CartList)
 register tType Tp_CartList;
# endif
{
  if (Tp_CartList == NULL) {
/* line 2991 "Trans.puma" */
   return;

  }
  if (Tp_CartList->Kind == kTp_NoCart) {
/* line 2992 "Trans.puma" */
   return;

  }
  if (Tp_CartList->Kind == kTp_Cart) {
/* line 2993 "Trans.puma" */
  {
/* line 2993 "Trans.puma" */

           TransTpExp(Tp_CartList->Tp_Cart.Tp_Exp);
           if (Tp_CartList->Tp_Cart.Next) if (Tp_CartList->Tp_Cart.Next->Kind != kTp_NoCart) fprintf (fp, ", "); 
           Tr_TpCartList(Tp_CartList->Tp_Cart.Next);  
        
  }
   return;

  }
;
}

void TransTpExp
# if defined __STDC__ | defined __cplusplus
(register tType t)
# else
(t)
 register tType t;
# endif
{

  switch (t->Kind) {
  case kTp_Poly:
/* line 3001 "Trans.puma" */
  {
/* line 3002 "Trans.puma" */
   Tr_TpName (t->Tp_Poly.ModId, t->Tp_Poly.Ident);
  }
   return;

  case kTp_Base:
/* line 3004 "Trans.puma" */
  {
/* line 3005 "Trans.puma" */
   Tr_TpName (t->Tp_Base.ModId, t->Tp_Base.Ident);
  }
   return;

  case kTp_Power:
/* line 3007 "Trans.puma" */
  {
/* line 3008 "Trans.puma" */
   Tr_TpPrefix (t->Tp_Power.Ident, t->Tp_Power.Tp_Exp);
  }
   return;

  case kTp_Seq:
/* line 3010 "Trans.puma" */
  {
/* line 3011 "Trans.puma" */
   Tr_TpPrefix (t->Tp_Seq.Ident, t->Tp_Seq.Tp_Exp);
  }
   return;

  case kTp_Prefix:
/* line 3013 "Trans.puma" */
  {
/* line 3014 "Trans.puma" */
   Tr_TpPrefix (t->Tp_Prefix.Ident, t->Tp_Prefix.Tp_Exp);
  }
   return;

  case kTp_Infix:
/* line 3016 "Trans.puma" */
  {
/* line 3017 "Trans.puma" */
   Tr_InfixIdent (t->Tp_Infix.Ident);
/* line 3018 "Trans.puma" */
   TransTpExp (t->Tp_Infix.Fst);
/* line 3019 "Trans.puma" */
   fprintf (fp, ", ");
/* line 3020 "Trans.puma" */
   TransTpExp (t->Tp_Infix.Snd);
/* line 3021 "Trans.puma" */
   fprintf (fp, ")");
  }
   return;

  case kTp_CartProd:
/* line 3023 "Trans.puma" */
  {
/* line 3024 "Trans.puma" */
 fprintf (fp, "'zsets.z_cross'([");
              Tr_TpCartList(t->Tp_CartProd.Tp_CartList);
              fprintf (fp, "])\n");
            
  }
   return;

  case kTp_Schema:
/* line 3029 "Trans.puma" */
  {
/* line 3030 "Trans.puma" */
   Tr_TpName (t->Tp_Schema.ModId, t->Tp_Schema.Ident);
  }
   return;

  case kTp_Exp:
  case kTp_Err:
  case kTp_Any:
/* line 3032 "Trans.puma" */
  {
/* line 3033 "Trans.puma" */
   Tr_TpName (t->Tp_Exp.ModId, t->Tp_Exp.Ident);
  }
   return;

  }

;
}

void BeginTrans ()
{
/* line 15 "Trans.puma" */

extern int indenttabs;
extern bool has_state;
extern bool has_init;
indenttabs=0;
has_state=false;
has_init=false;

}

void CloseTrans ()
{
}
