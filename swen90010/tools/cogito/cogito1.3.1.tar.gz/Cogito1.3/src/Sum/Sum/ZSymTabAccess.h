# ifndef yyZSymTabAccess
# define yyZSymTabAccess

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "ZSyms.h"

/* line 7 "zsymtab.puma" */

#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "env.h"
#include <stdio.h>


extern void (* ZSymTabAccess_Exit) ();

extern tZSyms AddVarSeq ARGS((tZSyms yyP1, tZSyms locs, tIdPos mid));
extern tZSyms AddAxSeq ARGS((tZSyms yyP2, tZSyms locs, tIdPos mid));
extern tZSyms AddGenSeq ARGS((tZSyms g, tZSyms yyP3, tZSyms locs, tIdPos mid));
extern tZSyms TotalLookup ARGS((tIdPos id, tZSyms syms, tZSyms env));
extern tZSyms LocalLookup ARGS((tIdPos id, tZSyms syms));
extern tZSyms IncSymbols ARGS((tZSyms alocs, tZSyms blocs));
extern bool InTable ARGS((tIdPos s1, tZSyms list, tZSyms env));
extern tZSyms HideSymbols ARGS((tZSyms locs, tZSyms zsyms));
extern tZSyms ComposeSymbols ARGS((tZSyms slocs, tZSyms tlocs));
extern tZSyms PipeSymbols ARGS((tZSyms slocs, tZSyms tlocs));
extern tIdPos SchemaName ARGS((tZSyms yyP5));
extern bool InWholeTable ARGS((tIdPos s1, tZSyms list, tZSyms env));

extern void BeginZSymTabAccess ();
extern void CloseZSymTabAccess ();

# endif
