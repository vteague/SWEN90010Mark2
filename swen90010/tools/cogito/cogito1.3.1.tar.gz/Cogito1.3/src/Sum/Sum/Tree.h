# ifndef yyTree
# define yyTree

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif


# ifndef bool
# define bool char
# endif
# define NoTree (tTree) 0L
# define kSum 1
# define kModuleList 2
# define kNoModule 3
# define kModule 4
# define kFormalParams 5
# define kNoParam 6
# define kParam 7
# define kTyParam 8
# define kFncParam 9
# define kRenameList 10
# define kNoRename 11
# define kRename 12
# define kSelectionList 13
# define kNoSelection 14
# define kSelection 15
# define kIdList 16
# define kNoId 17
# define kId 18
# define kNameList 19
# define kNoName 20
# define kName 21
# define kExpressionList 22
# define kNoExp 23
# define kExp 24
# define kVariable 25
# define kLiteral 26
# define kString 27
# define kChar 28
# define kPrefixOp 29
# define kLambda 30
# define kRecDisp 31
# define kMu 32
# define kTupSelection 33
# define kVarSelection 34
# define kIfExp 35
# define kFncApplication 36
# define kSetComp 37
# define kSetElab 38
# define kArrayUpd 39
# define kNamedArrayAgg 40
# define kSequence 41
# define kBag 42
# define kCartProd 43
# define kTuple 44
# define kExp_SchemaRef 45
# define kTheta 46
# define kInfixOp 47
# define kPredExp 48
# define kPredList 49
# define kNoPred 50
# define kPred 51
# define kQuantPred 52
# define kRelBinPred 53
# define kAssign 54
# define kRelPrePred 55
# define kLogBinPred 56
# define kLogicalNot 57
# define kPreCondPred 58
# define kIfPred 59
# define kWhilePred 60
# define kCallPred 61
# define kChgOnly 62
# define kDefined 63
# define kSchemaPred 64
# define kBoolValue 65
# define kInputBindList 66
# define kNoInputBind 67
# define kInputBind 68
# define kOutputBindList 69
# define kNoOutputBind 70
# define kOutputBind 71
# define kLogBinOp 72
# define kLogSeq 73
# define kLogAnd 74
# define kLogExor 75
# define kLogOr 76
# define kLogImply 77
# define kLogEquiv 78
# define kDeclList 79
# define kNoDecl 80
# define kDecl 81
# define kVarDecl 82
# define kGivenSet 83
# define kAxiomDecl 84
# define kSchemaDef 85
# define kAnnotation 86
# define kErgoAnno 87
# define kStateMachine 88
# define kAbbreviation 89
# define kFunctionDecl 90
# define kFreeType 91
# define kEnum 92
# define kImport 93
# define kModuleDecl 94
# define kConstraint 95
# define kSchemaIncl 96
# define kVisibility 97
# define kBranchList 98
# define kNoBranch 99
# define kBranch 100
# define kFTConstant 101
# define kFTConstructor 102
# define kSchema 103
# define kExpPred 104
# define kSchemaText 105
# define kSchemaRef 106
# define kSchemaCons 107
# define kSchemaCompos 108
# define kSchemaProj 109
# define kSchemaSubst 110
# define kSchemaHiding 111
# define kLogOp 112
# define kSDisjunction 113
# define kSConjunction 114
# define kSImplication 115
# define kSEquivalence 116

typedef unsigned char Tree_tKind;
typedef unsigned short Tree_tMark;
typedef unsigned short Tree_tLabel;
typedef union Tree_Node * tTree;
typedef void (* Tree_tProcTree) ();
/* line 9 "sum.cg" */

/* exportation */
# include "Idents.h"
# include "Positions.h"
# include "ratc.h"
# include "Syms.h"
# include "global.h"
# include "Type.h" 
# include "Trans.h" 

extern void Error ();
extern int CountSemErr;
extern tIdent ModIdent;

/* This structure is for storing information about importations which
 * is used later on in the translation to Ergo. 
 */
struct IMLstruct {
	tIdent ParentModId;
		/* prefix name for the imported-as module(subtheory in ergo) */ 
	char subthyid[IDENT_LENGTH]; 
		/* formed name for the imported-as module(subtheory in ergo) */
	struct IMLstruct *next;
};

typedef struct IMLstruct * IML_List; 
/* cur_mod_imllist_hd: the head pointer */
extern IML_List cur_mod_imllist_hd;
extern IML_List cur_mod_imllist;


# ifndef Tree_NodeHead
# define Tree_NodeHead
# endif
typedef struct { Tree_tKind yyKind; Tree_tMark yyMark; Tree_NodeHead } Tree_tNodeHead;
typedef struct { Tree_tNodeHead yyHead; tTree ModuleList; } ySum;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; } yModuleList;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; } yNoModule;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tTree Next; tIdPos Ident; tTree FormalParams; tTree PredList; tTree DeclList; bool IsNested; } yModule;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; } yFormalParams;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; } yNoParam;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tTree Next; } yParam;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tTree Next; tIdPos Ident; bool IsPolyTy; } yTyParam;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tTree Next; tTree VarDecl; } yFncParam;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; } yRenameList;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; } yNoRename;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tTree Next; tIdPos NewIdent; tTree OldIdent; } yRename;
typedef struct { Tree_tNodeHead yyHead; } ySelectionList;
typedef struct { Tree_tNodeHead yyHead; } yNoSelection;
typedef struct { Tree_tNodeHead yyHead; tTree Next; tIdPos Ident; } ySelection;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; } yIdList;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; } yNoId;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tTree Next; tIdPos Ident; int IdKind; } yId;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; } yNameList;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; } yNoName;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tTree Next; tTree IdList; } yName;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yExpressionList;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yNoExp;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; } yExp;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree IdList; tObjects SymPtr; bool IsBinding; } yVariable;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Literal; } yLiteral;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos String; } yString;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Char; } yChar;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Prefix; tTree Exp; } yPrefixOp;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree SchemaText; tTree Exp; } yLambda;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree SchemaText; tTree PredList; } yRecDisp;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree SchemaText; tTree ExpressionList; } yMu;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Exp; tIdPos Number; } yTupSelection;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Exp; tIdPos Ident; } yVarSelection;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Con; tTree Then; tTree Else; } yIfExp;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Fnc; tTree Arg; } yFncApplication;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree SchemaText; tTree ExpressionList; } ySetComp;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree ExpressionList; } ySetElab;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Array; tTree Index; tTree Value; } yArrayUpd;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree ExpressionList; } yNamedArrayAgg;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree ExpressionList; } ySequence;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree ExpressionList; } yBag;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree ExpressionList; } yCartProd;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree ExpressionList; } yTuple;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree IdList; tTree ExpressionList; } yExp_SchemaRef;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Exp; } yTheta;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Op1; tIdPos Infix; tTree Op2; } yInfixOp;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Pred; } yPredExp;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yPredList;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yNoPred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; } yPred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos LogQuant; tTree SchemaText; tTree Pred; } yQuantPred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree L; tIdPos RelBinOp; tTree R; } yRelBinPred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree L; tTree R; } yAssign;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos RelPreOp; tTree Exp; } yRelPrePred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree L; tTree LogBinOp; tTree R; } yLogBinPred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Pred; } yLogicalNot;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Pred; } yPreCondPred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Con; tTree Then; tTree Else; } yIfPred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Con; tTree Do; } yWhilePred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree IdList; tTree InputBindList; tTree OutputBindList; } yCallPred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree NameList; } yChgOnly;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Exp; } yDefined;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Schema; } ySchemaPred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Ident; } yBoolValue;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yInputBindList;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yNoInputBind;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Ident; tTree ExpressionList; } yInputBind;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yOutputBindList;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yNoOutputBind;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Ident; tTree IdList; } yOutputBind;
typedef struct { Tree_tNodeHead yyHead; } yLogBinOp;
typedef struct { Tree_tNodeHead yyHead; } yLogSeq;
typedef struct { Tree_tNodeHead yyHead; } yLogAnd;
typedef struct { Tree_tNodeHead yyHead; } yLogExor;
typedef struct { Tree_tNodeHead yyHead; } yLogOr;
typedef struct { Tree_tNodeHead yyHead; } yLogImply;
typedef struct { Tree_tNodeHead yyHead; } yLogEquiv;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yDeclList;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yNoDecl;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; } yDecl;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree IdList; tTree Exp; int VarDeclKind; } yVarDecl;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree IdList; } yGivenSet;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree FormalParams; tTree DeclList; tTree PredList; } yAxiomDecl;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Ident; tTree FormalParams; tTree DeclList; tTree PredList; bool IsOp; bool HasStateIncl; } ySchemaDef;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Decl; } yAnnotation;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Ident; } yErgoAnno;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree IdList; } yStateMachine;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Ident; tTree Exp; } yAbbreviation;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree DeclList; tTree PredList; } yFunctionDecl;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Ident; tTree BranchList; tIdent ModId; } yFreeType;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Ident; tTree BranchList; tIdent ModId; } yEnum;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Ident; tTree ExpressionList; tTree RenameList; tIdPos NewIdent; IML_List ModIMLlist; tObjects FmlParams; } yImport;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Module; } yModuleDecl;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree Pred; } yConstraint;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tTree IdList; tTree ExpressionList; tIdent ModId; } ySchemaIncl;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdPos Ident; tTree SelectionList; } yVisibility;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yBranchList;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tType Type; } yNoBranch;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdent FTIdent; } yBranch;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdent FTIdent; tIdPos Ident; } yFTConstant;
typedef struct { Tree_tNodeHead yyHead; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Next; tIdent FTIdent; tIdPos Ident; tTree Exp; } yFTConstructor;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; } ySchema;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Exp; } yExpPred;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree DeclList; tTree PredList; bool Is_local_dec; } ySchemaText;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree IdList; tTree ExpressionList; } ySchemaRef;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree LogOp; tTree L; tTree R; } ySchemaCons;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Sch1; tIdPos Compos; tTree Sch2; } ySchemaCompos;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Sch1; tIdPos Proj; tTree Sch2; } ySchemaProj;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Schema; tTree RenameList; } ySchemaSubst;
typedef struct { Tree_tNodeHead yyHead; tPosition Pos; bool IsTypeExp; tObjects DeclsIn; tObjects DeclsOut; tType Type; tTree Schema; tTree NameList; } ySchemaHiding;
typedef struct { Tree_tNodeHead yyHead; } yLogOp;
typedef struct { Tree_tNodeHead yyHead; } ySDisjunction;
typedef struct { Tree_tNodeHead yyHead; } ySConjunction;
typedef struct { Tree_tNodeHead yyHead; } ySImplication;
typedef struct { Tree_tNodeHead yyHead; } ySEquivalence;

union Tree_Node {
 Tree_tKind Kind;
 Tree_tNodeHead yyHead;
 ySum Sum;
 yModuleList ModuleList;
 yNoModule NoModule;
 yModule Module;
 yFormalParams FormalParams;
 yNoParam NoParam;
 yParam Param;
 yTyParam TyParam;
 yFncParam FncParam;
 yRenameList RenameList;
 yNoRename NoRename;
 yRename Rename;
 ySelectionList SelectionList;
 yNoSelection NoSelection;
 ySelection Selection;
 yIdList IdList;
 yNoId NoId;
 yId Id;
 yNameList NameList;
 yNoName NoName;
 yName Name;
 yExpressionList ExpressionList;
 yNoExp NoExp;
 yExp Exp;
 yVariable Variable;
 yLiteral Literal;
 yString String;
 yChar Char;
 yPrefixOp PrefixOp;
 yLambda Lambda;
 yRecDisp RecDisp;
 yMu Mu;
 yTupSelection TupSelection;
 yVarSelection VarSelection;
 yIfExp IfExp;
 yFncApplication FncApplication;
 ySetComp SetComp;
 ySetElab SetElab;
 yArrayUpd ArrayUpd;
 yNamedArrayAgg NamedArrayAgg;
 ySequence Sequence;
 yBag Bag;
 yCartProd CartProd;
 yTuple Tuple;
 yExp_SchemaRef Exp_SchemaRef;
 yTheta Theta;
 yInfixOp InfixOp;
 yPredExp PredExp;
 yPredList PredList;
 yNoPred NoPred;
 yPred Pred;
 yQuantPred QuantPred;
 yRelBinPred RelBinPred;
 yAssign Assign;
 yRelPrePred RelPrePred;
 yLogBinPred LogBinPred;
 yLogicalNot LogicalNot;
 yPreCondPred PreCondPred;
 yIfPred IfPred;
 yWhilePred WhilePred;
 yCallPred CallPred;
 yChgOnly ChgOnly;
 yDefined Defined;
 ySchemaPred SchemaPred;
 yBoolValue BoolValue;
 yInputBindList InputBindList;
 yNoInputBind NoInputBind;
 yInputBind InputBind;
 yOutputBindList OutputBindList;
 yNoOutputBind NoOutputBind;
 yOutputBind OutputBind;
 yLogBinOp LogBinOp;
 yLogSeq LogSeq;
 yLogAnd LogAnd;
 yLogExor LogExor;
 yLogOr LogOr;
 yLogImply LogImply;
 yLogEquiv LogEquiv;
 yDeclList DeclList;
 yNoDecl NoDecl;
 yDecl Decl;
 yVarDecl VarDecl;
 yGivenSet GivenSet;
 yAxiomDecl AxiomDecl;
 ySchemaDef SchemaDef;
 yAnnotation Annotation;
 yErgoAnno ErgoAnno;
 yStateMachine StateMachine;
 yAbbreviation Abbreviation;
 yFunctionDecl FunctionDecl;
 yFreeType FreeType;
 yEnum Enum;
 yImport Import;
 yModuleDecl ModuleDecl;
 yConstraint Constraint;
 ySchemaIncl SchemaIncl;
 yVisibility Visibility;
 yBranchList BranchList;
 yNoBranch NoBranch;
 yBranch Branch;
 yFTConstant FTConstant;
 yFTConstructor FTConstructor;
 ySchema Schema;
 yExpPred ExpPred;
 ySchemaText SchemaText;
 ySchemaRef SchemaRef;
 ySchemaCons SchemaCons;
 ySchemaCompos SchemaCompos;
 ySchemaProj SchemaProj;
 ySchemaSubst SchemaSubst;
 ySchemaHiding SchemaHiding;
 yLogOp LogOp;
 ySDisjunction SDisjunction;
 ySConjunction SConjunction;
 ySImplication SImplication;
 ySEquivalence SEquivalence;
};

extern tTree TreeRoot;
extern unsigned long Tree_HeapUsed;
extern char * Tree_PoolFreePtr, * Tree_PoolMaxPtr;
extern unsigned short Tree_NodeSize [116 + 1];
extern char * Tree_NodeName [116 + 1];

extern void (* Tree_Exit) ();
extern tTree Tree_Alloc ();
extern tTree MakeTree ARGS((Tree_tKind yyKind));
extern bool Tree_IsType ARGS((register tTree yyt, register Tree_tKind yyKind));

extern tTree mSum ARGS((tTree pModuleList));
extern tTree mModuleList ARGS(());
extern tTree mNoModule ARGS(());
extern tTree mModule ARGS((tTree pNext, tIdPos pIdent, tTree pFormalParams, tTree pPredList, tTree pDeclList, bool pIsNested));
extern tTree mFormalParams ARGS(());
extern tTree mNoParam ARGS(());
extern tTree mParam ARGS((tTree pNext));
extern tTree mTyParam ARGS((tTree pNext, tIdPos pIdent, bool pIsPolyTy));
extern tTree mFncParam ARGS((tTree pNext, tTree pVarDecl));
extern tTree mRenameList ARGS(());
extern tTree mNoRename ARGS(());
extern tTree mRename ARGS((tTree pNext, tIdPos pNewIdent, tTree pOldIdent));
extern tTree mSelectionList ARGS(());
extern tTree mNoSelection ARGS(());
extern tTree mSelection ARGS((tTree pNext, tIdPos pIdent));
extern tTree mIdList ARGS(());
extern tTree mNoId ARGS(());
extern tTree mId ARGS((tTree pNext, tIdPos pIdent, int pIdKind));
extern tTree mNameList ARGS(());
extern tTree mNoName ARGS(());
extern tTree mName ARGS((tTree pNext, tTree pIdList));
extern tTree mExpressionList ARGS(());
extern tTree mNoExp ARGS(());
extern tTree mExp ARGS((tTree pNext));
extern tTree mVariable ARGS((tTree pNext, tTree pIdList));
extern tTree mLiteral ARGS((tTree pNext, tIdPos pLiteral));
extern tTree mString ARGS((tTree pNext, tIdPos pString));
extern tTree mChar ARGS((tTree pNext, tIdPos pChar));
extern tTree mPrefixOp ARGS((tTree pNext, tIdPos pPrefix, tTree pExp));
extern tTree mLambda ARGS((tTree pNext, tTree pSchemaText, tTree pExp));
extern tTree mRecDisp ARGS((tTree pNext, tTree pSchemaText, tTree pPredList));
extern tTree mMu ARGS((tTree pNext, tTree pSchemaText, tTree pExpressionList));
extern tTree mTupSelection ARGS((tTree pNext, tTree pExp, tIdPos pNumber));
extern tTree mVarSelection ARGS((tTree pNext, tTree pExp, tIdPos pIdent));
extern tTree mIfExp ARGS((tTree pNext, tTree pCon, tTree pThen, tTree pElse));
extern tTree mFncApplication ARGS((tTree pNext, tTree pFnc, tTree pArg));
extern tTree mSetComp ARGS((tTree pNext, tTree pSchemaText, tTree pExpressionList));
extern tTree mSetElab ARGS((tTree pNext, tTree pExpressionList));
extern tTree mArrayUpd ARGS((tTree pNext, tTree pArray, tTree pIndex, tTree pValue));
extern tTree mNamedArrayAgg ARGS((tTree pNext, tTree pExpressionList));
extern tTree mSequence ARGS((tTree pNext, tTree pExpressionList));
extern tTree mBag ARGS((tTree pNext, tTree pExpressionList));
extern tTree mCartProd ARGS((tTree pNext, tTree pExpressionList));
extern tTree mTuple ARGS((tTree pNext, tTree pExpressionList));
extern tTree mExp_SchemaRef ARGS((tTree pNext, tTree pIdList, tTree pExpressionList));
extern tTree mTheta ARGS((tTree pNext, tTree pExp));
extern tTree mInfixOp ARGS((tTree pNext, tTree pOp1, tIdPos pInfix, tTree pOp2));
extern tTree mPredExp ARGS((tTree pNext, tTree pPred));
extern tTree mPredList ARGS(());
extern tTree mNoPred ARGS(());
extern tTree mPred ARGS((tTree pNext));
extern tTree mQuantPred ARGS((tTree pNext, tIdPos pLogQuant, tTree pSchemaText, tTree pPred));
extern tTree mRelBinPred ARGS((tTree pNext, tTree pL, tIdPos pRelBinOp, tTree pR));
extern tTree mAssign ARGS((tTree pNext, tTree pL, tTree pR));
extern tTree mRelPrePred ARGS((tTree pNext, tIdPos pRelPreOp, tTree pExp));
extern tTree mLogBinPred ARGS((tTree pNext, tTree pL, tTree pLogBinOp, tTree pR));
extern tTree mLogicalNot ARGS((tTree pNext, tTree pPred));
extern tTree mPreCondPred ARGS((tTree pNext, tTree pPred));
extern tTree mIfPred ARGS((tTree pNext, tTree pCon, tTree pThen, tTree pElse));
extern tTree mWhilePred ARGS((tTree pNext, tTree pCon, tTree pDo));
extern tTree mCallPred ARGS((tTree pNext, tTree pIdList, tTree pInputBindList, tTree pOutputBindList));
extern tTree mChgOnly ARGS((tTree pNext, tTree pNameList));
extern tTree mDefined ARGS((tTree pNext, tTree pExp));
extern tTree mSchemaPred ARGS((tTree pNext, tTree pSchema));
extern tTree mBoolValue ARGS((tTree pNext, tIdPos pIdent));
extern tTree mInputBindList ARGS(());
extern tTree mNoInputBind ARGS(());
extern tTree mInputBind ARGS((tTree pNext, tIdPos pIdent, tTree pExpressionList));
extern tTree mOutputBindList ARGS(());
extern tTree mNoOutputBind ARGS(());
extern tTree mOutputBind ARGS((tTree pNext, tIdPos pIdent, tTree pIdList));
extern tTree mLogBinOp ARGS(());
extern tTree mLogSeq ARGS(());
extern tTree mLogAnd ARGS(());
extern tTree mLogExor ARGS(());
extern tTree mLogOr ARGS(());
extern tTree mLogImply ARGS(());
extern tTree mLogEquiv ARGS(());
extern tTree mDeclList ARGS(());
extern tTree mNoDecl ARGS(());
extern tTree mDecl ARGS((tTree pNext));
extern tTree mVarDecl ARGS((tTree pNext, tTree pIdList, tTree pExp, int pVarDeclKind));
extern tTree mGivenSet ARGS((tTree pNext, tTree pIdList));
extern tTree mAxiomDecl ARGS((tTree pNext, tTree pFormalParams, tTree pDeclList, tTree pPredList));
extern tTree mSchemaDef ARGS((tTree pNext, tIdPos pIdent, tTree pFormalParams, tTree pDeclList, tTree pPredList, bool pIsOp));
extern tTree mAnnotation ARGS((tTree pNext, tTree pDecl));
extern tTree mErgoAnno ARGS((tTree pNext, tIdPos pIdent));
extern tTree mStateMachine ARGS((tTree pNext, tTree pIdList));
extern tTree mAbbreviation ARGS((tTree pNext, tIdPos pIdent, tTree pExp));
extern tTree mFunctionDecl ARGS((tTree pNext, tTree pDeclList, tTree pPredList));
extern tTree mFreeType ARGS((tTree pNext, tIdPos pIdent, tTree pBranchList));
extern tTree mEnum ARGS((tTree pNext, tIdPos pIdent, tTree pBranchList));
extern tTree mImport ARGS((tTree pNext, tIdPos pIdent, tTree pExpressionList, tTree pRenameList, tIdPos pNewIdent));
extern tTree mModuleDecl ARGS((tTree pNext, tTree pModule));
extern tTree mConstraint ARGS((tTree pNext, tTree pPred));
extern tTree mSchemaIncl ARGS((tTree pNext, tTree pIdList, tTree pExpressionList));
extern tTree mVisibility ARGS((tTree pNext, tIdPos pIdent, tTree pSelectionList));
extern tTree mBranchList ARGS(());
extern tTree mNoBranch ARGS(());
extern tTree mBranch ARGS((tTree pNext, tIdent pFTIdent));
extern tTree mFTConstant ARGS((tTree pNext, tIdent pFTIdent, tIdPos pIdent));
extern tTree mFTConstructor ARGS((tTree pNext, tIdent pFTIdent, tIdPos pIdent, tTree pExp));
extern tTree mSchema ARGS(());
extern tTree mExpPred ARGS((tTree pExp));
extern tTree mSchemaText ARGS((tTree pDeclList, tTree pPredList, bool pIs_local_dec));
extern tTree mSchemaRef ARGS((tTree pIdList, tTree pExpressionList));
extern tTree mSchemaCons ARGS((tTree pLogOp, tTree pL, tTree pR));
extern tTree mSchemaCompos ARGS((tTree pSch1, tIdPos pCompos, tTree pSch2));
extern tTree mSchemaProj ARGS((tTree pSch1, tIdPos pProj, tTree pSch2));
extern tTree mSchemaSubst ARGS((tTree pSchema, tTree pRenameList));
extern tTree mSchemaHiding ARGS((tTree pSchema, tTree pNameList));
extern tTree mLogOp ARGS(());
extern tTree mSDisjunction ARGS(());
extern tTree mSConjunction ARGS(());
extern tTree mSImplication ARGS(());
extern tTree mSEquivalence ARGS(());

extern void WriteTreeNode ARGS((FILE * yyyf, tTree yyt));
extern void WriteTree ARGS((FILE * yyyf, tTree yyt));
extern tTree ReverseTree ARGS((tTree yyOld));
extern tTree CopyTree ARGS((tTree yyt));
extern void QueryTree ARGS((tTree yyt));
extern void BeginTree ();
extern void CloseTree ();

# endif
