/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
/* 
Version: $Id: sum.c,v 1.5 2000/04/26 04:58:38 cogito Exp $
*/

# include "Parser.h"
# include "Tree.h"
# include "Scanner.h"
# include <string.h>
# include "Syms.h"
# include "Semantics.h"
# include "Trans.h"
# include "ZParser.h"
# include "BuildSymtab.h"

#ifdef WIN32
int indenttabs;
char *SumFileName, *SumPathName, *SumSpecFile;
#endif


/* command line interface:
 * sumtt stands for Sum type checking and translation to Ergo.
 * sumtt [ -STEAGstv ] [ Sum-file [ -m {module-name=module-file}* ] ]
 * sumtt -p module-name[.mod] 
 * sumtt [-ZOTEWsvtz ] Z-file
 * -S -- Syntax checking only. 
 * -T -- Syntax and type checking.
 * -E -- Translation to Ergo.
 * -A -- Translation to Ada.
 * -G -- Translation to the Latex graphical form.  
 * -W -- Translation to the RTF graphical form.  
 * -s -- Display all the symbols defined in the specification file.
 * -v -- Display all the symbols defined with type denotation. 
 * -t -- Save the Abstract Syntax Tree in the file *.ast. 
 * -m -- Specify the module denotation for importation.
 * -p -- Display the symbol table content of the module. 
 * -Z -- Input from Latex Z spec -- Z syntax checking only
 * -O -- Output to ascii Sum, filename.sum, generated from the Z input
 * -z -- Write the Z abstract syntax tree in filename.zast  
 */

main (argc, argv, envp)
int argc;
char *argv[];
char *envp[];
{
    int argu, option, len, numerrs = 0;
    FILE *fp, *sum_fp, *fpz;
    int S=0, T=0, E=0, A=0, G=0, W=0, s=0, v=0, t=0, p=0;
    /* wj - follow suit with options -Z, -O, -z */
    int Z=0, O=0, z=0;
    int filenum=0, i=0;
    char version[128],zsumfilename[256],zast[256];
    char *tcname="sumtt";
    tTree sumtree=NoTree;

    printf("\n\n::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n");
    sprintf (version, "Type Checker and Translator for Sum --- Version 1.3.1 (%s).", __DATE__);

    /* get shell variable MATHPATH.*/
    /*
    for (i=0; envp[i] != NULL; i++) {
        for (j=0; j < strlen(envp[i]); j++)
            if (envp[i][j] == '=') {
                envp[i][j] = '\0';
                if (strcmp (envp[i], "MATHPATH") == 0) {
                    MATHPATH = (char *) malloc (MathPathLength);
                    MATHPATH[0] = '\0';
                    strcat (MATHPATH, envp[i]+j+1);  
                    break;
                }
            }
        if (j < strlen(envp[i]))
            break;
    }
    */
                
    printf ("\n%s\n\n", version);

    if (argc == 1) {
        printf ("usage:\n%s [ -STEAGstv ] [ Sum-file [ -m {module-name=module-file}* ] ]\n\
%s -p module-name[.mod]\n  \
-S: Syntax checking only.\n  \
-T: Syntax and type checking.\n  \
-E: Translation to Ergo.\n  \
-A: Translation to Ada.\n  \
-G: Translation to Latex graphical form.\n  \
-W: Translation to RTF graphical form.\n  \
-s: Display all the symbols defined in the specification file.\n  \
-t: Save the Abstract Syntax Tree in the file *.ast.\n  \
-v: Display all the symbols defined with type denotation.\n  \
-m {module-name=module-file}* : Module importation specification.\n  \
-p module-name[.mod] : Display the symbol table content of the module. \
-Z: Input from a Latex Z specification with syntax checking only.\n
-O: Save the ascii Sum generated from a Z specification in the file *.sum.\n
-z: Save the Z Abstract Syntax Tree in the file *.zast.\n\n", tcname, tcname); 
        exit (0);
    }

    argu = 1;
    if (argv[argu][0] == '-') {
        len = strlen (argv[argu]);
        for (option=1; option < len; option++) 
            switch (argv[argu][option]) {
                case 'S':
                    S = 1;
                    break;
                case 'T':
                    T = 1;
                    break;
                case 'E':
                    E = 1;
                    break;
                case 'A':
                    A = 1;
                    break;
                case 'G':
                    G = 1;
                    break;
                case 'W':
                    W = 1;
                    break;
                case 's':
                    s = 1;
                    break;
                case 't':
                    t = 1;
                    break;
                case 'v':
                    v = 1;
                    break;
                case 'p':
                    p = 1;
                    break;
	  /* wj - insert 3 more for Z input */
		case 'Z':
		  Z=1;
                  break;
	        case 'O':
		  O=1;
		  break;
	        case 'z':
		  z=1;
		  break;
                default:
                    fprintf (stderr, "Illegal options: %s\n", argv[argu]);
                    exit (1);
            }
        argu++;
    }

    /* to print out the content of file.mod */
    if (p) { 
        printf ("-- Symbol Table for ");
        if (strstr (argv[argu], ".mod")) {
            printf ("%s --\n", argv[argu]);
            PrintMod (argv[argu]);
        }
        else {
            char name[IDENT_LENGTH];

            name[0] = '\0';
            strcat (strcat (name, argv[argu]), ".mod");
            printf ("%s --\n", name);
            PrintMod (name);
        }
        exit(0);
    }

    if (argu < argc)
        if (sum_fp = fopen (argv[argu], "r")) {
        /* check if the file existing. */
            fclose (sum_fp);

            filenum = argu;
            argu++;
            if (argu < argc) 
                if (strcmp (argv[argu], "-m") == 0) {
                    argu++;
                    for (i=argu; i<argc; i++)
                        Argv[i-argu] = argv[i]; 
                    Argc = argc - argu; 
                }
                else {
#ifdef TKGUI
                    printf("Illegal option: %s\n", argv[argu]);
                    exit(0);
#else
                    fprintf (stderr, "Illegal option: %s\n", argv[argu]);
                    exit (1);
#endif
                }

            /* copy the file name into SumFileName */
            for (i=strlen(argv[filenum])-1; i>0; i--)
                if (argv[filenum][i] == '.')
                    break;
	    /* wj -- what if the filename has no suffix? */
	    /* i is then 0!!! */
	    /* if there is no suffix include whole file name */
	    if (i == 0) i = strlen(argv[filenum]);
            SumFileName = (char *) my_malloc (strlen(argv[filenum]));
 	    SumPathName = (char *) my_malloc (strlen(argv[filenum]));
	    SumSpecFile = (char *) my_malloc (strlen(argv[filenum]));
	    SumFileName[0] = '\0';
	    SumPathName[0] = '\0';
	    SumSpecFile[0] = '\0';
	    /* pull out the path name and the actual file name */
	    /* any generated files are written to the current directory ? */
            strncpy (SumFileName, argv[filenum], i); 
            SumFileName[i] = '\0';
 	    {
		int pathnamelen=0;
		char *pstr;

		if (pstr = strrchr (SumFileName, '/')) {
		    strcat (SumSpecFile, pstr+1);
		    pathnamelen = strlen(SumFileName) - strlen (pstr);
		    strncat (SumPathName, SumFileName, pathnamelen);
		    strcat (SumPathName, "/");
		}
		else 
		    strcat (SumSpecFile, SumFileName);
	    }

	    /********************** Syntax checking ********************/

	    /* Sum input i.e. not Z input */
	    if (Z==0) {
	      /* Sum Syntax checking */
	      printf ("::::: %s :::::\n", argv[filenum]);
	      BeginFile(argv[filenum]);
	      numerrs = Parser() + CountErr;
	      /* copy the TreeRoot into sumtree for compatibility with the Z input which has to build on the tree root */
	      sumtree = CopyTree(TreeRoot);
	    }

	    /* Z input */
	    else {
	      /* Z syntax checking */
	      printf("::::: %s :::::\n", argv[filenum]);
	      ZScanner_BeginFile(argv[filenum]);
	      numerrs = ZParser();
	      /* only translate if there are no syntax errors */
	      if (numerrs==0) {
		CheckZTree(ZTreeRoot);
		/* Translating Z abs to Sum abs */
		printf("Translating Z abstract syntax to Sum abstract syntax\n");
		BeginBuildSymtab();
		BuildSymtab(ZTreeRoot);
		CloseBuildSymtab();
		/* using the no-modules-in-Z approach */
		sumtree = mSum(mModule(mNoModule(),ZMakeIdPos("z2sum",NoPosition),mNoParam(),mNoPred(),TreeRoot,false));
		/*sumtree = mSum(mModule(mNoModule(),ZMakeIdPos(SumSpecFile,NoPosition),mNoParam(),mNoPred(),TreeRoot,false));*/
	      }
	    }

#ifdef TKGUI
            printf ("Number of Syntax Errors: %d\n", numerrs);
#else
            fprintf (stderr, "Number of Syntax Errors: %d\n", numerrs);
#endif

            if (t) {
		char *str;

		str = (char *) my_malloc (strlen(SumFileName)+5);
		str[0] = '\0';
                strcat (str, SumSpecFile);
                strcat (str, ".ast"); 
                fp = fopen(str, "w"); 
		WriteTree(fp,sumtree);
                fclose (fp);
                printf ("The Abstract Syntax Tree is written in \"%s\".\n", str);
            }

		/* write the Z abstract syntax tree */
		if ((Z==1) && (z==1)) {
		  strcpy(zast,SumSpecFile);
		  strcat(zast,".zast");
		  fpz = fopen(zast,"w");
		  printf("The Z abstract syntax tree is written in file %s\n",zast);
		  WriteZTree(fpz,ZTreeRoot);
		  fclose(fpz);
		}

            /* Attributes evaluation (Semantic checking) */
            if (numerrs == 0 && (T || E || A || G || W || O)) {
                BeginSyms();
                BeginType();
                BeginSemantics();
		Semantics (sumtree);
	     
#ifdef TKGUI
                printf ("Number of Semantic Errors: %d\n", CountSemErr);
#else
               fprintf (stderr, "Number of Semantic Errors: %d\n", CountSemErr);
#endif

                if (v) {
                    printf ("-- Symbol Table --\n");
                    PrintSymTab (1);    
                }
                else if (s) {
                    printf ("-- Symbol Table --\n");
                    PrintSymTab (0);
                }

                /* Translation to Ergo */
                if (CountSemErr == 0 && E) {
                    printf ("Start Sum Translation to Ergo ...\n");
                    BeginTrans();
                    indenttabs=0;
                    TransErgo (sumtree);   
                    printf ("Finish Sum Translation to Ergo ...\n");
                }

                /* Translation to Ada */
                if (CountSemErr == 0 && A) {
                    printf ("Start Sum Translating to Ada ...\n");
                    BeginSumToAda();
                    indenttabs=0;
                    TransAda (sumtree);
                    printf ("Finish Sum Translating to Ada ...\n");
                }

                /* Graphical Form depends on Position computation */
                if (G&&(Z==0)) {   /* not for Z input */
                printf ("The Latex graphic form is written in '%s.tex'.\n", SumSpecFile);
                SumGForm (sumtree);
                } 

                /* Graphical Form depends on Position computation */
                if (W) {
                printf ("The RTF graphic form is written in '%s.rtf'.\n", SumSpecFile);
                SumWForm (sumtree);
                } 

		/* Output the ascii Sum generated from Z input */
		if ((O==1) && (Z==1)) {
		  strcpy(zsumfilename,SumSpecFile);
		  strcat(zsumfilename,".sum");
		  UnparseSum(sumtree,zsumfilename,argv[filenum]);
		  printf ("The Sum graphic form is written in %s\n",zsumfilename);
		}
            }
        }
        else { 
            fprintf (stderr, "File \"%s\" does not exist! \n", argv[argu]);
#ifdef TKGUI
	    printf ("File \"%s\" does not exist! \n", argv[argu]);
            exit (0);
#else
            fprintf (stderr, "File \"%s\" does not exist! \n", argv[argu]);
            exit (1);
#endif
        }

    if (numerrs > 0 || CountSemErr > 0)
#ifdef TKGUI
        exit(0);
#else
        exit(1);
#endif
    else
        exit (0);
}
