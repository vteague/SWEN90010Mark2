# include "Type.h"
# define yyALLOC(ptr, size)	if ((ptr = (tType) Type_PoolFreePtr) >= (tType) Type_PoolMaxPtr) \
  ptr = Type_Alloc (); \
  Type_PoolFreePtr += size;
# define yyFREE(ptr, size)	
# ifdef __cplusplus
extern "C" {
# include <stdio.h>
# include "yyType.w"
# include "System.h"
# include "General.h"
# include "Memory.h"
# include "DynArray.h"
# include "StringMem.h"
# include "Idents.h"
# include "Sets.h"
# include "Positions.h"
}
# else
# include <stdio.h>
# include "yyType.w"
# include "System.h"
# include "General.h"
# include "Memory.h"
# include "DynArray.h"
# include "StringMem.h"
# include "Idents.h"
# include "Sets.h"
# include "Positions.h"
# endif

/* line 77 "Type.cg" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include "Idents.h"
#include "Errors.h"
#include "Positions.h"
#include "ratc.h"
#include "global.h"
#include "Syms.h"
#include "Type.h"
#include "SumErrors.h"
#include "SymAccess.h"


/* Singly linked list of matchings of generic types and instantiated types */

struct gnc_subs_struct {
    tType gncty;
    tType insty;
    struct gnc_subs_struct *next;
};

/* A list to store gen/inst pairs in as they are being checked */

struct gnc_subs_struct *GncSubsList=NULL;

/* A Garbage list to dispose of them in */

struct gnc_subs_struct *Garbage=NULL;

tType Tyof_Variable (DeclsIn, IdList, SymPtr, IsBinding, ErrOn)
    tObjects DeclsIn;
    tTree IdList;
    tObjects *SymPtr;
    bool *IsBinding;
    bool ErrOn;
{
    tObjects sym_ptr = DeclsIn, lastsym = NoSym;
    tTree idlist=NoTree, restart=NoTree;
    char *str, *strokes;
    tPosition pos;
    tType rtnty = NoType, fld=NoType;
    int i;
    tIdent o_id=NoIdent;
    tTree lastid=NoTree;
    tIdent QuId = NoIdent;

    pos = IdList->Id.Ident.Pos;
    *IsBinding = false;

    while (sym_ptr && sym_ptr->Kind != kNoObject) {
        sym_ptr =  LookUpName (sym_ptr, IdList, lastsym);
        if (sym_ptr) { 
            if (sym_ptr->Kind == kObj_Inn && sym_ptr->Obj_Inn.Inner && 
                (sym_ptr->Obj_Inn.Inner->Kind == kObj_PId ||
                    sym_ptr->Obj_Inn.Inner->Kind == kObj_PTyId)) {
                /* referring to a generic definition */
                Error (pos, error20);
                *SymPtr = NoSym;
                return ErrTy;
            }
            if (sym_ptr->Kind == kObj_Id && sym_ptr->Obj_Id.QuId != NoIdent) {

                tObjects modsym=NoSym;

                modsym = LookUp (sym_ptr->Object.Pre, sym_ptr->Obj_Id.QuId, NoSym); 
                if (modsym && modsym->Kind == kObj_Inn &&
                    modsym->Obj_Inn.Visible) {

                    rtnty = sym_ptr->Object.Type;
                    rtnty->Tp_Exp.IsTypeExp = false;
                    *SymPtr = sym_ptr;
                    return rtnty;
                }

                lastsym = sym_ptr;
                sym_ptr = sym_ptr->Object.Pre;

            }
            else {
                rtnty = sym_ptr->Object.Type;
                if (sym_ptr->Kind == kObj_TyId || sym_ptr->Kind == kObj_PTyId)
                    rtnty->Tp_Exp.IsTypeExp = true;
                else if (sym_ptr->Kind == kObj_Inn &&
                    sym_ptr->Obj_Inn.ObjKind == Obj_schema) 
                    rtnty->Tp_Exp.IsTypeExp = true;
                else 
                    if (rtnty)
                        rtnty->Tp_Exp.IsTypeExp = false;
                    else {
                        Error (pos, error32);
                        return ErrTy;
                    }
                *SymPtr = sym_ptr;
                return rtnty;
            }
        }
        else
            break;
    }

    /* check if it is qualified name */    
    for (idlist=IdList; idlist->Kind != kNoId;
        idlist=idlist->Id.Next) {

        if (idlist->Id.Next->Kind != kNoId &&
            idlist->Id.Next->Id.Next->Kind == kNoId) {
            /* the 2nd last one */
            lastid = idlist->Id.Next;
            idlist->Id.Next = mNoId();
            QuId = FormtIdent (IdList);
            idlist->Id.Next = lastid;

            sym_ptr = LookUp (DeclsIn, lastid->Id.Ident.Ident, NoSym);
            while (sym_ptr && sym_ptr->Kind != kNoObject) {
                if (sym_ptr->Kind == kObj_Id && sym_ptr->Obj_Id.QuId ==
                    QuId) {
                    rtnty = sym_ptr->Object.Type;
                    rtnty->Tp_Exp.IsTypeExp = false;
                    *SymPtr = sym_ptr;
                    return rtnty;
                }
                else {
                    sym_ptr = LookUp (sym_ptr->Object.Pre, lastid->Id.Ident.Ident, sym_ptr); 
                }
            }
            break;
        }
    }

    /* to check whether it is a primed schema
     * it would look like M.M.S' 
     * ?? only to remove the last stroke or the all strokes.
     */
    for (idlist=IdList; idlist->Kind != kNoId;
        idlist=idlist->Id.Next)
        if (idlist->Id.Next->Kind == kNoId)
            break;

    /* last Id on the idlist */
    strokes = (char *) my_malloc (IDENT_LENGTH);
    str = (char *) my_malloc (IDENT_LENGTH);
    str[0] = '\0';
    strokes[0] = '\0';
    GetString (idlist->Id.Ident.Ident, str);
    o_id = idlist->Id.Ident.Ident; /* reserve the original ident */
    for (i=0; i<strlen(str); i++)
        if (str[i] == '\'') {
            strcpy (strokes, str+i);
            str[i] = '\0';
            idlist->Id.Ident.Ident = MakeIdent (str, strlen(str)); 
            sym_ptr =  LookUpName (DeclsIn, IdList, NoSym);
            break;
        }

    if (sym_ptr) { /* primed schema */
        rtnty = sym_ptr->Object.Type;
        if (sym_ptr->Kind == kObj_Inn && sym_ptr->Obj_Inn.ObjKind == Obj_schema &&
            sym_ptr->Obj_Inn.Inner && sym_ptr->Obj_Inn.Inner->Kind != kObj_PTyId) {

            rtnty = FormTp_SchemaD(sym_ptr->Obj_Inn.Inner, strokes, sym_ptr->Obj_Inn.ModId);
            rtnty->Tp_Exp.IsTypeExp = true;
            *SymPtr = sym_ptr;
            return rtnty;
        }
        else if (sym_ptr->Kind == kObj_TyId && rtnty && rtnty->Kind == kTp_Schema) {
            /* abbreviation for a combined schema */
            rtnty = CpSchTypeD(rtnty, strokes); 
            rtnty->Tp_Exp.IsTypeExp = true;
            *SymPtr = sym_ptr;
            return rtnty;
        }
        else {
#                ifdef Debug
                DError (pos, error11);
#                else
                if (ErrOn) {
                    Error (pos, error11);
		    ErrorInName(IdList);}
#                endif
            *SymPtr = NoSym;
            return ErrTy;
        }    
    }

    /* check if it is schema binding 
     * legal form(eg.): M1.M2.S1.S2.x
     */

    idlist->Id.Ident.Ident = o_id;

    for (idlist=IdList; idlist->Kind != kNoId; 
        idlist=idlist->Id.Next) {

        restart = idlist->Id.Next;
        idlist->Id.Next = mNoId();

        sym_ptr =  LookUpName (DeclsIn, IdList, NoSym); 

        if (sym_ptr) {
            if (sym_ptr->Kind == kObj_Inn) {
                if (sym_ptr->Obj_Inn.Inner &&
                    sym_ptr->Obj_Inn.Inner->Kind == kObj_Param) {
                /* referring to a generic definition */
                    if (ErrOn)
                        Error (pos, error20);
                    *SymPtr = NoSym;
                    return ErrTy;
                }
                else if (sym_ptr->Obj_Inn.ObjKind == Obj_schema)
                    break; /* schema binding */
                else
                    idlist->Id.Next = restart;
            }
            else if (sym_ptr->Object.Type &&
                sym_ptr->Object.Type->Kind == kTp_Schema) 
                break; /* binding */
            else {
                if (ErrOn) {
                    Error (pos, error11);
		    ErrorInName(idlist);}
                *SymPtr = NoSym;
                return ErrTy;
            }
        }
        else {
            if (ErrOn){
                Error (pos, error11);
		ErrorInName(idlist);}
            *SymPtr = NoSym;
            return ErrTy;
        }
    }

    if (idlist->Kind == kNoId) {
    /* Not a schema binding */
        if (ErrOn) {
            Error (pos, error11);
	    ErrorInName(IdList);}
        *SymPtr = NoSym;
        return ErrTy;
    }
    else {
    /* Is a schema binding */
        idlist->Id.Next = restart;
        rtnty = sym_ptr->Object.Type;
    }

    /* handle schema binding */
    while (1) {
        idlist = restart;
        *SymPtr = NoSym;
        if (idlist->Id.Next->Kind == kNoId) { 
        /* binded var. has no prefix, the case of Sch.id */
            fld = rtnty->Tp_Schema.Tp_SchFieldList;
            for (; fld; fld=fld->Tp_SchField.Next)
                if (fld->Tp_SchField.Ident == idlist->Id.Ident.Ident &&
                    fld->Tp_SchField.QuId == NoIdent) {

                    *IsBinding = true;
                    fld->Tp_SchField.Tp_Exp->Tp_Exp.IsTypeExp = false;
                    return fld->Tp_SchField.Tp_Exp;
                }
            Error (pos, error11);
	    ErrorInName(idlist);
            return ErrTy;
        }

        /* the case of Sch.id.id{.id} */
        for (; idlist->Kind != kNoId; idlist=idlist->Id.Next) 
        /* try binded and qualified var. first */
            if (idlist->Id.Next->Kind != kNoId &&
                idlist->Id.Next->Id.Next->Kind == kNoId) {
                /* the 2nd last one */
                lastid = idlist->Id.Next;
                idlist->Id.Next = mNoId();
                QuId = FormtIdent (restart);
                idlist->Id.Next = lastid;
                fld = rtnty->Tp_Schema.Tp_SchFieldList;
                for (; fld; fld=fld->Tp_SchField.Next)
                    if (fld->Tp_SchField.Ident == idlist->Id.Ident.Ident &&
                        fld->Tp_SchField.QuId == QuId) {
                        *IsBinding = true;
                        fld->Tp_SchField.Tp_Exp->Tp_Exp.IsTypeExp = false;
                        return fld->Tp_SchField.Tp_Exp;
                    }
                break;
            }

        /* schema has schema variables. */
        idlist = restart;
        fld = rtnty->Tp_Schema.Tp_SchFieldList;
        for (; fld; fld=fld->Tp_SchField.Next)
            if (fld->Tp_SchField.Ident == idlist->Id.Ident.Ident && 
                fld->Tp_SchField.Tp_Exp && fld->Tp_SchField.Tp_Exp->Kind == kTp_Schema) {
                    rtnty = fld->Tp_SchField.Tp_Exp;
                    break;
            }

        if (fld)
            restart = restart->Id.Next;
        else {
            if (ErrOn) {
                Error (pos, error11);
		ErrorInName(idlist);}
            return ErrTy;
        }
    } /* while (1) */
}

/*
 * Only apply to numbers (interger).
 */
tType Tyof_Literal (Literal)
  tIdent Literal;
{ 
  return IntTy;
}

tType Tyof_PrefixExp (DeclsIn, Prefix, Exp)
  tObjects DeclsIn;
  tIdPos Prefix;
  tTree Exp;
{ 
  /* Generate a type for Pre_Gen operations plus Power operation.
   * Pre_Gen: seq, seq1, iseq, bag, id, F, F1, P, and P1. 
   */
    tType rtnty=NoType;
    tType ExpType=NoType;
    tObjects sym=NoSym;
    tType actty=NoType, fmlty=NoType;
    tType typelist=mTp_NoCart(); /* wj - trace for error reporting */
    struct gnc_subs_struct *garlink=NULL;
    
    ExpType = Exp->Exp.Type;

    if (ExpType==NoType) {
	/* wj - given argument has no type? */
        Error (Prefix.Pos, error24);
	ErrorInPrefixNoArg(Prefix.Ident);
        return ErrTy;
    }
    
    if (ExpType->Kind == kTp_Err) return ExpType; /* ill-typed */
    
    if (Prefix.Ident == Ident_power || Prefix.Ident == Ident_power_1 ||
        Prefix.Ident == Ident_finite || Prefix.Ident == Ident_finite_1) 
        if (Exp->Exp.IsTypeExp)
            rtnty = mTp_Power (NoIdent, Prefix.Ident, ExpType);
        else if (ExpType->Kind == kTp_Power)
            rtnty = mTp_Power (NoIdent, Prefix.Ident, ExpType->Tp_Power.Tp_Exp);
        else
            rtnty = ErrTy;
    if (Prefix.Ident == Ident_seq || Prefix.Ident == Ident_seq_1 || Prefix.Ident == Ident_iseq) 
        if (Exp->Exp.IsTypeExp)
            rtnty = mTp_Seq (NoIdent, Prefix.Ident, ExpType);
        else if (ExpType->Kind == kTp_Power)
            rtnty = mTp_Seq (NoIdent, Prefix.Ident, ExpType->Tp_Power.Tp_Exp);
        else
            rtnty = ErrTy;
    if (Prefix.Ident == Ident_bag)
        if (Exp->Exp.IsTypeExp)
            rtnty = mTp_Prefix (NoIdent, Prefix.Ident, ExpType);
        else if (ExpType->Kind == kTp_Power)
            rtnty = mTp_Prefix (NoIdent, Prefix.Ident, ExpType->Tp_Power.Tp_Exp);
        else
            rtnty = ErrTy;
            /*
    if (Prefix.Ident == Ident_id)
        if (Exp->Exp.IsTypeExp)
            rtnty = mTp_Infix (NoIdent, Ident_relation, ExpType, ExpType);
        else if (ExpType->Kind == kTp_Power)
            rtnty = mTp_Infix (NoIdent, Ident_relation, ExpType->Tp_Power.Tp_Exp, ExpType->Tp_Power.Tp_Exp);
        else
            rtnty = ErrTy;
    */
    if (rtnty) {
        if (rtnty->Kind == kTp_Err) 
            Error (Exp->Exp.Pos, error32);
        else
            rtnty->Tp_Exp.IsTypeExp = true;
        return rtnty; 
    }

    /* Prefix operators: instantiation by use */
    sym = LookUp (DeclsIn, Prefix.Ident, NoSym);
    if (sym==NoSym) {
/* wj - prefix not found in symbol table i.e. no match to a toolkit function was found and there is no overload */
        Error (Prefix.Pos, error24);
	ErrorInPrefix(Prefix.Ident,ExpType);
        return ErrTy;
    }
    if (Exp->Exp.IsTypeExp) 
        actty = mTp_Power (NoIdent, Ident_power, Exp->Exp.Type);
    else
        actty = Exp->Exp.Type;
    while (1) {
        fmlty = sym->Object.Type;
	typelist = mTp_Cart(typelist,fmlty); /* add to trace */
            
        if (fmlty->Kind != kTp_Infix) {
            Error (Prefix.Pos, error29);
            rtnty = ErrTy;
            break;
        }
        if (InstByUse (fmlty->Tp_Infix.Fst, actty)) {
            rtnty = MkRngTy(fmlty->Tp_Infix.Snd);
                
            if (Garbage == NULL)
                Garbage = GncSubsList;
            else
                for (garlink=Garbage; garlink; garlink=garlink->next)
                    if (garlink->next == NULL) {    
                        garlink->next = GncSubsList;
                        break;
                    }
            GncSubsList = NULL;
            break;
        }
        else {printf("\nnot instbyuse\n");
            if (Garbage == NULL)
                Garbage = GncSubsList;
            else
                for (garlink=Garbage; garlink; garlink=garlink->next)
                    if (garlink->next == NULL) {    
                        garlink->next = GncSubsList;
                        break;
                    }
            GncSubsList = NULL;
        }
        if (sym && sym->Kind != kNoObject) 
            sym = LookUp (sym->Object.Pre, Prefix.Ident, sym);
        if (sym==NoSym) {
/* wj - prefix name not a toolkit function? */
            Error (Prefix.Pos, error24);
	    NoMorePrefixOverloads(Prefix.Ident,typelist,ExpType);
            rtnty = ErrTy;
            break;
        }
    }
    if (rtnty)
        rtnty->Tp_Exp.IsTypeExp = false;
    return rtnty;
}

tType CommType (T1, T2)
    tType T1, T2;
{
    int i=0;

    i = Compatible (T1, T2);

    if (i==1) 
        return T1;
    else if (i==2)
        return T2;
    else
        return ErrTy;
}

int Compatible (T1, T2)
    tType T1, T2;
{
    tType t1=T1, t2=T2;

    if (t1 == NoType || t2 == NoType)
        return 0;
    if (t1->Kind == kTp_Err || t2->Kind == kTp_Err)
        return 0;

    if (t1->Kind == kTp_Any) 
        return 2; 
    if (t2->Kind == kTp_Any) 
        return 1;

    if (t1->Kind == t2->Kind)
        switch (t1->Kind) {
            case kTp_Base:
                if (t1->Tp_Base.Ident == t2->Tp_Base.Ident)
                    return 1;
                else return 0;
            case kTp_Power:
                return Compatible (t1->Tp_Power.Tp_Exp, t2->Tp_Power.Tp_Exp);
            case kTp_Seq:
                return Compatible (t1->Tp_Seq.Tp_Exp, t2->Tp_Seq.Tp_Exp);
            case kTp_Prefix:
                if (t1->Tp_Prefix.Ident == t2->Tp_Prefix.Ident)
                    return Compatible (t1->Tp_Prefix.Tp_Exp, t2->Tp_Prefix.Tp_Exp);
                else return 0;
            case kTp_Infix:
                return Compatible (t1->Tp_Infix.Fst, t2->Tp_Infix.Fst) &&
                    Compatible (t1->Tp_Infix.Snd, t2->Tp_Infix.Snd);
            case kTp_CartProd:
            {
                tType cart1=t1->Tp_CartProd.Tp_CartList;
                tType cart2=t2->Tp_CartProd.Tp_CartList;

                for (; cart1 && cart2; 
                    cart1=cart1->Tp_Cart.Next, cart2=cart2->Tp_Cart.Next)
                    if (!Compatible (cart1->Tp_Cart.Tp_Exp, cart2->Tp_Cart.Tp_Exp))
                        return 0;
                if (cart1 || cart2)
                    return 0;
                else
                    return 1;
            }
            case kTp_Schema: 
                if (SchCompatible (t1, t2))
                    return 1;
                else
                    return 0;
            case kTp_Poly:
                if (t1->Tp_Poly.Ident == t2->Tp_Poly.Ident)
                    return 1;
                else
                    return -1;
            case kTp_Exp:
                if (t1->Tp_Exp.Ident == t2->Tp_Exp.Ident)
                    return 1;
                else
                    return 0;
            default:
                InterErr(Ierror2);
                return 0;
        }
    else {
        tType p_t1 = ParentTy(t1);
        tType p_t2 = ParentTy(t2);

        if (p_t1 == t1 && p_t2 == t2)
	    if (Type_IsType(p_t1,kTp_Poly) || Type_IsType(p_t2,kTp_Poly))
		return -1;
	    else
                return 0;
        else return Compatible (p_t1, p_t2); 
    }
}

tType Tyof_Lambda (Vars, ExpType)
    tObjects Vars;
    tType ExpType;
{
    tObjects sym_ptr=Vars;
    tType tylist=NoType, fst=NoType;

    if (!ExpType || ExpType->Kind == kTp_Err)
        return ErrTy;
    while (sym_ptr && sym_ptr->Kind != kNoObject) {
        if (!sym_ptr->Object.Type || sym_ptr->Object.Type->Kind == kTp_Err)
            return ErrTy;
        if (!fst) { /* first one */
            fst = sym_ptr->Object.Type;
            if (!sym_ptr->Object.Next ||  /* the case of one */
                sym_ptr->Object.Next->Kind == kNoObject)
                return mTp_Infix (NoIdent, Ident_totalfunc, fst, ExpType);
            else {
                tylist = mTp_Cart(NoType, fst);
                fst = tylist;
            }
        }
        else {
            tylist->Tp_Cart.Next = mTp_Cart(NoType, sym_ptr->Object.Type);
            tylist = tylist->Tp_Cart.Next;
        }
        sym_ptr = sym_ptr->Object.Next;
    }
    /* should be Ident_totalfunc */
    return mTp_Infix (NoIdent, Ident_totalfunc, mTp_CartProd(NoIdent, NoIdent, fst), ExpType);
}

tType Tyof_RecDisp (Vars)
    tObjects Vars;
{
    tObjects sym_ptr=Vars;

    if (!sym_ptr->Object.Type || sym_ptr->Object.Type->Kind == kTp_Err)
            return ErrTy;
    else 
            return  sym_ptr->Object.Type;
}

/* 21/5/97 Added as Ty_of Mu was used for SetComp which is incorrect */

tType Tyof_SetComp (Vars, ExpType)
    tObjects Vars;
    tType ExpType;
{
    tObjects sym_ptr=Vars;
    tType tylist=NoType, fst=NoType;

    if (ExpType && ExpType->Kind != kTp_Err)
        return mTp_Power (NoIdent, Ident_power, ExpType); 
    if (ExpType && ExpType->Kind == kTp_Err)
        return ErrTy;
    /* ExpType == NoType */
    while (sym_ptr && sym_ptr->Kind != kNoObject) {
        if (!sym_ptr->Object.Type || sym_ptr->Object.Type->Kind == kTp_Err)
            return ErrTy;
        if (!fst) { /* first one */
            fst = sym_ptr->Object.Type;
            if (!sym_ptr->Object.Next ||  /* the case of one */
                sym_ptr->Object.Next->Kind == kNoObject)
                return mTp_Power (NoIdent, Ident_power, fst);
            else {
                tylist = mTp_Cart(NoType, fst);
                fst = tylist;
            }
        }
        else {
            tylist->Tp_Cart.Next = mTp_Cart(NoType, sym_ptr->Object.Type);
            tylist = tylist->Tp_Cart.Next;
        }
        sym_ptr = sym_ptr->Object.Next;
    }
   return mTp_Power (NoIdent, Ident_power, mTp_CartProd(NoIdent, NoIdent, fst));
}

tType Tyof_Mu (Vars, ExpType)
    tObjects Vars;
    tType ExpType;
{
    tObjects sym_ptr=Vars;
    tType tylist=NoType, fst=NoType;
    if (ExpType && ExpType->Kind != kTp_Err)
        return ExpType;
        /* return mTp_Power (NoIdent, Ident_power, ExpType); lpw 4/97*/
    if (ExpType && ExpType->Kind == kTp_Err)
        return ErrTy;
    /* ExpType == NoType */
    while (sym_ptr && sym_ptr->Kind != kNoObject) {
        if (!sym_ptr->Object.Type || sym_ptr->Object.Type->Kind == kTp_Err)
            return ErrTy;
        if (!fst) { /* first one */
            fst = sym_ptr->Object.Type;
            if (!sym_ptr->Object.Next ||  /* the case of one */
                sym_ptr->Object.Next->Kind == kNoObject)
                return fst;
                /* return mTp_Power (NoIdent, Ident_power, fst); lpw 4/97*/
            else {
                tylist = mTp_Cart(NoType, fst);
                fst = tylist;
            }
        }
        else {
            tylist->Tp_Cart.Next = mTp_Cart(NoType, sym_ptr->Object.Type);
            tylist = tylist->Tp_Cart.Next;
        }
        sym_ptr = sym_ptr->Object.Next;
    }
    return mTp_CartProd(NoIdent, NoIdent, fst);
     /* return mTp_Power (NoIdent, Ident_power, mTp_CartProd(NoIdent, NoIdent, fst));lpw 4/97*/
}

tType TupSelectType (ExpType, ExpPos, Number)
  tType ExpType;
  tPosition ExpPos;
  tIdPos Number;
{ 
    char s[IDENT_LENGTH];
    int no, no1;
    tType ty_ptr;

    if (ExpType && ExpType->Kind == kTp_CartProd) {
        GetString (Number.Ident, s);
        if (no = atoi (s) > 0) { 
            no--;
            for (ty_ptr=ExpType->Tp_CartProd.Tp_CartList;
                 ty_ptr && no; ty_ptr = ty_ptr->Tp_Cart.Next, no--)
                ;    
            if (no == 0)
                if (ty_ptr != NULL)
                    return ty_ptr;
        }
        Error (Number.Pos, error6);
        return ErrTy;
    }
    Error (ExpPos, error7);
    return ErrTy;
}

tType Tyof_SchemaBind (ExpType, ExpPos, Ident)
  tType ExpType;
  tPosition ExpPos;
  tIdPos Ident;
{
    tType fldlist;

    if (ExpType && ExpType->Kind == kTp_Schema) {
        fldlist = ExpType->Tp_Schema.Tp_SchFieldList;
        for (; Type_IsType(fldlist,kTp_SchField); fldlist = fldlist->Tp_SchField.Next)
            if (fldlist->Tp_SchField.Ident == Ident.Ident)
                return fldlist->Tp_SchField.Tp_Exp;
        Error (Ident.Pos, error13);
        return ErrTy;
    }
    else {
        Error (ExpPos, error9);
        return ErrTy; 
    }
}


tType Tyof_ArrayUpd (DeclsIn, Array, Index, Value)
  tObjects DeclsIn;
  tTree Array, Index, Value;
{
  tType Fst, Snd;
  tObjects sym;

   /* Return the type of array
      MUST Look it up as it is an IdList 
      howver I neednt have to instantiate array it should be fixed
      check type of index is in type of domain
      check type of Value is in type range
      should checks be strict, insisting array is an array, or loose
      ie allow array to be sequence or other.
    */

  sym = LookUpName (DeclsIn, Array, NoSym);
    
  if (sym == NoSym) {
       Error (Array->Id.Pos, error11);
	ErrorInName(Array);
       return ErrTy;
  }
  if (Functional(sym->Object.Type, &Fst, &Snd) == false) {
      Error(Array->Id.Pos, error15); 
/* wj - the function type is not suitable */
/* what is this doing here? */
      ErrorInFnType(sym->Object.Type);
      return ErrTy;
  }

  /* how do I check if these types unify - is it easy or complex */
   /* probaly complex as arguments may not be from base type */
  if (! Compatible(Fst, Index->Exp.Type)) {
      Error(Index->Exp.Pos, error3);
/* wj - expected and actual types dont match */
      ErrorInParams(Fst, Index->Exp.Type,5);
      return ErrTy;
  }

  if (! Compatible(Snd, Value->Exp.Type)) {
      Error(Value->Exp.Pos, error3);
/* wj - expected and actual types dont match */
      ErrorInFnResult(Snd, Value->Exp.Type);
      return ErrTy;
  }

  return sym->Object.Type;

}

tType Tyof_IfExp (Cond, CondPos, ThenTp, ThenPos, ElseTp)
  tType Cond;
  tPosition CondPos;
  tType ThenTp;
  tPosition ThenPos;
  tType ElseTp;
{ 
  /* check whether ThenTp is compatible with ElseTp. 
   * Cond must have type "bool".
   */

    tType comm = ErrTy;
    
    if (!ThenTp || !ElseTp) {
        return ErrTy; 
    }
    
    comm = CommType (ThenTp, ElseTp);

    /*
    if (Cond && Cond->Kind == kTp_Base && Cond->Tp_Base.Ident == Ident_bool)
        if (comm && comm->Kind == kTp_Err)
            Error (ThenPos, error2);
    else
        Error (CondPos, il_error1);
    */
    if (comm->Kind == kTp_Err)
        Error (ThenPos, error2);
    return comm;
}

/* ?? an alternative way:
 * to do ParentTy (Ty), then to retrieve Fst and Snd.
 */
bool Functional (Ty, Fst, Snd)
    tType Ty;
    tType *Fst, *Snd;
{
    switch (Ty->Kind) {
        case kTp_Infix:
            *Fst = Ty->Tp_Infix.Fst;
            *Snd = Ty->Tp_Infix.Snd;
            return true;
        case kTp_Seq:
            *Fst = IntTy;
            *Snd = Ty->Tp_Seq.Tp_Exp;
            return true;
        case kTp_Prefix:
            if (Ty->Tp_Prefix.Ident == Ident_bag) {
                *Fst = Ty->Tp_Prefix.Tp_Exp;
                *Snd = IntTy;
                return true;
            }
            else
                return false;
        default: 
        /* 
        {
            tType p_ty = ParentTy (Ty);
            tType cp=NoType, cart=NoType;

            if (p_ty->Kind == kTp_Power && cp = p_ty->Tp_Power.Tp_Exp)
                if (cp->Kind == kTp_CartProd && cart=cp->Tp_CartProd.Tp_CartList)
                    *Fst = cart->Tp_Cart.Tp_Exp;
                    if (cart=cart->Tp_Cart.Next && cart->Tp_Cart.Next==NoType) {
                        *Snd = cart->Tp_Cart.Tp_Exp;
                        return true;
                    }
            return false;
        }
        */
            return false;
    }
}

tType Tyof_FncApp (DeclsIn, Fnc, ArgType)
  tObjects DeclsIn;
  tTree Fnc;
  tType ArgType;
{
    tPosition fncpos;
    tObjects sym=NoSym;
    tType fmlty=NoType, actty=NoType;
    tType typelist=mTp_NoCart(); /* wj - trace for error reporting */
    struct gnc_subs_struct *garlink=NULL;
    tType fncty, rtnty=NoType;
    tType Fst=NoType, Snd=NoType;
    fncpos = Fnc->Exp.Pos;
    fncty = Fnc->Exp.Type;

    if (fncty == NoType || ArgType == NoType) {
        Error (fncpos, error3);
/* wj - expected and actual types dont match */
	ErrorInParams(fncty,ArgType,4);
        return ErrTy;
    }
    if (fncty->Kind == kTp_Err || ArgType->Kind == kTp_Err) {
        Error (fncpos, error3);
/* wj - expected and actual types dont match */
/* wj - the types are already in error */
	ErrorInParams(fncty,ArgType,3);
        return ErrTy;
    }

    /* if it is not a variable then all information is here*/
    /* Get domain and range of Fnc from type */
    /* try to instantiate actuals with argument return range if it works */
    /* clean up instantiation list */

    if (Fnc->Kind != kVariable) {
        if (Functional(fncty, &Fst, &Snd) == false) {
/* wj - the function type is not suitable */
            Error (fncpos, error15);
	    ErrorInFnType(fncty);
            return ErrTy;
        }
        /* if it is a product then make product ow use Tp_exp */
        if (ArgType->Tp_Cart.Next)
            actty = mTp_CartProd (NoIdent, NoIdent, ArgType);
        else
            actty = ArgType->Tp_Cart.Tp_Exp;

	if (InstByUse (Fst, actty)) {
		rtnty = MkRngTy(Snd);
	}
	else {
/* wj -- is functional but not InstByUse i.e. cant find a unique type for the result? */
		Error (fncpos, error3);
		ErrorInParams(Fst, actty,2);
		rtnty = ErrTy;
	}
	if (Garbage == NULL)
		Garbage = GncSubsList;
	else
		for (garlink=Garbage; garlink; garlink=garlink->next)
			if (garlink->next == NULL) {    
				garlink->next = GncSubsList;
				break;
			}
	GncSubsList = NULL;
	return rtnty;
    }
    /* ow the Fnc is a variable */
    /* look it up, try to instantiate it - keep looking for overloads */
    else {
        sym = LookUpName (DeclsIn, Fnc->Variable.IdList, NoSym);
        /* if not found start with recorded type */
	/* wj - inbuilt type? */
        if (sym==NoSym) {
            fmlty = fncty;
        }
        else
            fmlty = sym->Object.Type;
	/* wj - keep a record of all the functions tried for error report */
	typelist = mTp_Cart(typelist,fmlty); /* add to trace */

        /* if it is a product use cart ow use type_exp */

        if (ArgType->Tp_Cart.Next)
            actty = mTp_CartProd (NoIdent, NoIdent, ArgType);
        else
            actty = ArgType->Tp_Cart.Tp_Exp;

        /* look for a function with an instantiation that works */

        while (1) {
            if (!Functional (fmlty, &Fst, &Snd)) {
/* wj - the function type is not suitable */
                Error (fncpos, error15);
		ErrorInFnType(fmlty);
                rtnty = ErrTy;
                break;
            }

            if (InstByUse (Fst, actty)) {

                rtnty = MkRngTy(Snd);

                if (Garbage == NULL)
                    Garbage = GncSubsList;
                else
                    for (garlink=Garbage; garlink; garlink=garlink->next)
                        if (garlink->next == NULL) {    
                            garlink->next = GncSubsList;
                            break;
                        }
                GncSubsList = NULL;
                break;
            }
            else {
                if (Garbage == NULL)
                    Garbage = GncSubsList;
                else
                    for (garlink=Garbage; garlink; garlink=garlink->next)
                        if (garlink->next == NULL) {    
                            garlink->next = GncSubsList;
                            break;
                        }
                GncSubsList = NULL;
            }
            if (sym==NoSym) {
/* wj - symbol not found i.e. toolkit function? */
/* wj - functional but not InstByUse i.e. toolkit function that cant be instantiated? */
                Error (fncpos, error3);
		ErrorInParams(Fst, actty,1);
                rtnty = ErrTy;
                break;
            }
            else {
/* wj - symbol in table but didnt give a match so try for another i.e overloaded */
                sym = LookUpName (sym->Object.Pre, Fnc->Variable.IdList, sym);
		/* wj - not overloaded */
                if (sym == NoSym) {
                    Error (fncpos, error3);
		    NoMoreFncOverloads(typelist, actty);
                    rtnty = ErrTy;
                    break;
                }
                else
                    fmlty = sym->Object.Type;
		typelist = mTp_Cart(typelist,fmlty); /* add to trace */
            }
        }
        return rtnty;
    }
}

tType Tyof_SetElab (TypeExpList, ExpPos)
  tType TypeExpList;
  tPosition ExpPos;
{
    tType type_list = TypeExpList;
    tType comm = ErrTy;

    if (type_list == NoType) /* empty set */
        return mTp_Power (NoIdent, Ident_power, mTp_Any(NoIdent, NoIdent));
    if (type_list->Kind == kTp_Err)
        return ErrTy;
    else 
        if (type_list->Tp_Cart.Next) { 
            /* more than two elements */
            comm = CommType (type_list->Tp_Cart.Tp_Exp, type_list->Tp_Cart.Next->Tp_Cart.Tp_Exp);
            if (comm->Kind == kTp_Err) { 
                Error (ExpPos, error2);
		ErrorInSetElab(TypeExpList);
                return ErrTy;
            }
            else {
                type_list = type_list->Tp_Cart.Next;
                for (; type_list; type_list = type_list->Tp_Cart.Next) {
                    comm = CommType (comm, type_list->Tp_Cart.Tp_Exp);
                    if (comm->Kind == kTp_Err) {
                        Error (ExpPos, error2);
			ErrorInSetElab(TypeExpList);
                        return ErrTy;
                    }
                }
                /* comm holds the common type of all elements */
                return mTp_Power (NoIdent, Ident_power, comm);
            }
        }
        else  { /* only one element */
            comm = type_list->Tp_Cart.Tp_Exp; /* comm holds the type of only element */
            if (comm->Kind == kTp_Err)
                return ErrTy; /* subterm is ill-typed */
            else
                return mTp_Power (NoIdent, Ident_power, comm);
        }
}


/* sequence instance: empty or non-empty sequence.
 */
tType Tyof_Seq (TypeExpList, ExpPos)
  tType TypeExpList;
  tPosition ExpPos; /* the first element s position */
{
  /* check Compatible (Exp(i),Exp(i+1)), 1 <= i <= (n-1).
   */

    tType type_list = TypeExpList;
    tType comm = ErrTy;

    if (type_list == NoType) /* empty sequence */
        return mTp_Seq (NoIdent, Ident_seq, mTp_Any(NoIdent, NoIdent));
    if (type_list->Kind == kTp_Err)
        return ErrTy;
    else 
        if (type_list->Tp_Cart.Next) { 
            /* more than two elements */
            comm = CommType (type_list->Tp_Cart.Tp_Exp, type_list->Tp_Cart.Next->Tp_Cart.Tp_Exp);
            if (comm->Kind == kTp_Err) { 
                Error (ExpPos, error2);
                return ErrTy;
            }
            else {
                type_list = type_list->Tp_Cart.Next;
                for (; type_list; type_list = type_list->Tp_Cart.Next) {
                    comm = CommType (comm, type_list->Tp_Cart.Tp_Exp);
                    if (comm->Kind == kTp_Err) {
                        Error (ExpPos, error2);
                        return ErrTy;
                    }
                }
                /* comm holds the common type of all elements */
                return mTp_Seq (NoIdent, Ident_seq, comm);
            }
        }
        else  { /* only one element */
            comm = type_list->Tp_Cart.Tp_Exp; /* comm holds the type of only element */
            if (comm->Kind == kTp_Err)
                return ErrTy; /* subterm is ill-typed */
            else
                return mTp_Seq (NoIdent, Ident_seq, comm);
        }
}

tType Tyof_Bag (TypeExpList, ExpPos)
  tType TypeExpList;
  tPosition ExpPos;
{
    tType type_list = TypeExpList;
    tType comm = ErrTy;

    if (type_list == NoType) /* empty sequence */
        return mTp_Prefix (NoIdent, Ident_bag, mTp_Any(NoIdent, NoIdent));
    if (type_list->Kind == kTp_Err)
        return ErrTy;
    else 
        if (type_list->Tp_Cart.Next) { 
            /* more than two elements */
            comm = CommType (type_list->Tp_Cart.Tp_Exp, type_list->Tp_Cart.Next->Tp_Cart.Tp_Exp);
            if (comm->Kind == kTp_Err) { 
                Error (ExpPos, error2);
                return ErrTy;
            }
            else {
                type_list = type_list->Tp_Cart.Next;
                for (; type_list; type_list = type_list->Tp_Cart.Next) {
                    comm = CommType (comm, type_list->Tp_Cart.Tp_Exp);
                    if (comm->Kind == kTp_Err) {
                        Error (ExpPos, error2);
                        return ErrTy;
                    }
                }
                /* comm holds the common type of all elements */
                return mTp_Prefix (NoIdent, Ident_bag, comm);
            }
        }
        else  { /* only one element */
            comm = type_list->Tp_Cart.Tp_Exp; /* comm holds the type of only element */
            if (comm->Kind == kTp_Err)
                return ErrTy; /* subterm is ill-typed */
            else
                return mTp_Prefix (NoIdent, Ident_bag, comm);
        }
}

tType Tyof_CartProd (ExpList)
  tTree ExpList;
{
    /* T1 # ... # Tn:
     * n >= 2 (auto)
     */
    tTree list=ExpList;
    tType fst=NoType, last=NoType;
    tType ty=NoType, rtnty=NoType;

    for (; list && list->Kind != kNoExp; list=list->Exp.Next)
        if (list->Exp.Type && list->Exp.Type->Kind != kTp_Err) {
            ty = list->Exp.Type;
            if (!list->Exp.IsTypeExp) 
                if (ty->Kind == kTp_Power)
                    ty = ty->Tp_Power.Tp_Exp;
                else {
                    Error(list->Exp.Pos, error32);
                    return ErrTy;
                }
            if (fst == NoType) {
                fst = mTp_Cart(NoType, ty);
                last = fst;
            }
            else {
                last->Tp_Cart.Next = mTp_Cart(NoType, ty);
                last = last->Tp_Cart.Next;
            }
        }    
        else {
            Error(list->Exp.Pos, error32);
            return ErrTy;
        }
    rtnty = mTp_CartProd (NoIdent, NoIdent, fst); 
    rtnty->Tp_Exp.IsTypeExp = true;
    return rtnty;
}
 
tType Tyof_Tuple (TypeExpList)
    tType TypeExpList;
{
    if (TypeExpList && TypeExpList->Kind != kTp_Err)
        return mTp_CartProd (NoIdent, NoIdent, TypeExpList);  
    else
        return ErrTy;  
}

/* this handles InGen and Infix */
tType Tyof_InfixExp (DeclsIn, Infix, Op1, Op2)
  tObjects DeclsIn;
  tIdPos Infix;
  tTree Op1, Op2;
{
    tObjects sym=NoSym;
    tType fmlty=NoType, actty=NoType;
    tType typelist=mTp_NoCart(); /* wj - trace for error reporting */
    struct gnc_subs_struct *garlink=NULL;
    tType rtnty=NoType;
    tType Op1Ty, Op2Ty;


    Op1Ty = Op1->Exp.Type;
    Op2Ty = Op2->Exp.Type;

    if (!Op1Ty || !Op2Ty) {
/* wj - no operator type for lhs or rhs? */
        Error (Infix.Pos, error24); 
	ErrorInInfix(Infix.Ident,Op1Ty,Op2Ty);
        return ErrTy;
    }
    if (Op1Ty->Kind == kTp_Err || Op2Ty->Kind == kTp_Err)
        return ErrTy;    

        /* InGen operators */
    if (Infix.Ident == Ident_relation ||
        Infix.Ident == Ident_partfunc ||
        Infix.Ident == Ident_totalfunc ||
        Infix.Ident == Ident_partinj ||
        Infix.Ident == Ident_totalinj ||
        Infix.Ident == Ident_partsur ||
        Infix.Ident == Ident_totalsur ||
        Infix.Ident == Ident_bij ||
        Infix.Ident == Ident_fpartfunc ||
        Infix.Ident == Ident_fpartinj) {
            if (Op1->Exp.IsTypeExp)
                ;
            else if (Op1Ty->Kind == kTp_Power)
                Op1Ty = Op1Ty->Tp_Power.Tp_Exp;
            else {
                Op1Ty = ErrTy;
                Error (Op1->Exp.Pos, error32);
            }
            if (Op2->Exp.IsTypeExp)
                ;
            else if (Op2Ty->Kind == kTp_Power)
                Op2Ty = Op2Ty->Tp_Power.Tp_Exp;
            else {
                Op2Ty = ErrTy;
                Error (Op2->Exp.Pos, error32);
            }
            if (Op1Ty->Kind != kTp_Err && Op2Ty->Kind != kTp_Err) {
                rtnty = mTp_Infix (NoIdent, Infix.Ident, Op1Ty, Op2Ty); 
                rtnty->Tp_Exp.IsTypeExp = true;
                return rtnty;
            }
            else
                return ErrTy;
        }

    /* Infix operators: instantiation by use */
    sym = LookUp (DeclsIn, Infix.Ident, NoSym);
    if (sym==NoSym) {
/* wj - cant find infix name? */
        Error (Infix.Pos, error24);
	ErrorInInfix(Infix.Ident,Op1Ty,Op2Ty);
        return ErrTy;
    }
    if (Op1->Exp.IsTypeExp && !Op2->Exp.IsTypeExp)
        actty = mTp_CartProd (NoIdent, NoIdent, 
            mTp_Cart(mTp_Cart(NoType, Op2Ty), mTp_Power(NoIdent, Ident_power, Op1Ty)));
    else if (!Op1->Exp.IsTypeExp && Op2->Exp.IsTypeExp)
        actty = mTp_CartProd (NoIdent, NoIdent, 
            mTp_Cart(mTp_Cart(NoType, mTp_Power(NoIdent, Ident_power, Op2Ty)), Op1Ty));
    else if (Op1->Exp.IsTypeExp && Op2->Exp.IsTypeExp)
        actty = mTp_CartProd (NoIdent, NoIdent, mTp_Cart (mTp_Cart (NoType,
            mTp_Power(NoIdent, Ident_power, Op2Ty)), 
            mTp_Power(NoIdent, Ident_power, Op1Ty)));
    else
        actty = mTp_CartProd (NoIdent, NoIdent, mTp_Cart(mTp_Cart(NoType, Op2Ty), Op1Ty));
    while (1) {
        fmlty = sym->Object.Type;
	typelist = mTp_Cart(typelist,fmlty); /* add to trace */
            
        if (fmlty->Kind != kTp_Infix) {
            Error (Infix.Pos, error29);
            rtnty = ErrTy;
            break;
        }
        if (InstByUse (fmlty->Tp_Infix.Fst, actty)) {	  
            rtnty = MkRngTy(fmlty->Tp_Infix.Snd);
                
            if (Garbage == NULL)
                Garbage = GncSubsList;
            else
                for (garlink=Garbage; garlink; garlink=garlink->next)
                    if (garlink->next == NULL) {    
                        garlink->next = GncSubsList;
                        break;
                    }
            GncSubsList = NULL;
            break;
        }
        else {
            if (Garbage == NULL)
                Garbage = GncSubsList;
            else
                for (garlink=Garbage; garlink; garlink=garlink->next)
                    if (garlink->next == NULL) {    
                        garlink->next = GncSubsList;
                        break;
                    }
            GncSubsList = NULL;
        }
        if (sym && sym->Kind != kNoObject) 
            sym = LookUp (sym->Object.Pre, Infix.Ident, sym);
        if (sym==NoSym) {
/* wj - not in toolkit functions either? */
            Error (Infix.Pos, error24);
	    NoMoreInfixOverloads(Infix.Ident,typelist,Op1Ty,Op2Ty);
            rtnty = ErrTy;
            break;
        }
    }
    if (rtnty)
        rtnty->Tp_Exp.IsTypeExp = false;
    return rtnty;
}

tType MkRngTy(Ty)
    tType Ty;
{
    struct gnc_subs_struct *gnclink=NULL;
    tType ty=Ty;

    switch (ty->Kind) {
        
        case kTp_Poly:
            for (gnclink=GncSubsList; gnclink; gnclink=gnclink->next)
		{if (gnclink->gncty == ty)
                    return gnclink->insty;}
/* wj -- this is not an error in instances where the poly is local to the frame. Trying a rough fix to see what the effect is 18/8/98 */
/* At present this ErrTy exit is going unnoticed and causing errors further down the track */
/*          return ErrTy; */
	    if (IsLocalGeneric(ty)) return ty;
            return ErrTy;
        case kTp_Exp:
            return ty;
        case kTp_Any:
            return ty;
        case kTp_Base:
            return ty;
        case kTp_Power:
            return mTp_Power(NoIdent, ty->Tp_Power.Ident, MkRngTy(ty->Tp_Power.Tp_Exp));
        case kTp_Seq:
            return mTp_Seq(NoIdent, ty->Tp_Seq.Ident, MkRngTy(ty->Tp_Seq.Tp_Exp));
        case kTp_Prefix:
            return mTp_Prefix(NoIdent, ty->Tp_Prefix.Ident, MkRngTy(ty->Tp_Prefix.Tp_Exp));
        case kTp_Infix:
            return mTp_Infix(NoIdent, ty->Tp_Infix.Ident, MkRngTy(ty->Tp_Infix.Fst), MkRngTy(ty->Tp_Infix.Snd));
        case kTp_CartProd:
        { tType cart=ty->Tp_CartProd.Tp_CartList;
          tType fstcart=NoType, lastcart=NoType;
            
            for (; cart; cart=cart->Tp_Cart.Next)
                if (fstcart == NoType) {
                    fstcart = mTp_Cart(NoType, MkRngTy(cart->Tp_Cart.Tp_Exp));
                    lastcart = fstcart;
                }
                else {
                    lastcart->Tp_Cart.Next = mTp_Cart(NoType, MkRngTy(cart->Tp_Cart.Tp_Exp));
                    lastcart = lastcart->Tp_Cart.Next;
                }
            return mTp_CartProd (ty->Tp_CartProd.ModId, NoIdent, fstcart);
        }
        case kTp_Schema:
        {
            tType fld=ty->Tp_Schema.Tp_SchFieldList;
            tType fst=NoType, last=NoType;

            for (; fld; fld=fld->Tp_SchField.Next)
                if (fst == NoType) {
                    fst = mTp_SchField(NoType, 
                        fld->Tp_SchField.ModId,
                        fld->Tp_SchField.Ident,
                        MkRngTy(fld->Tp_SchField.Tp_Exp),
                        fld->Tp_SchField.QuId);
                    last = fst;
                }
                else {
                    last->Tp_SchField.Next = mTp_SchField(NoType, 
                        fld->Tp_SchField.ModId,
                        fld->Tp_SchField.Ident,
                        MkRngTy(fld->Tp_SchField.Tp_Exp),
                        fld->Tp_SchField.QuId);
                    last = last->Tp_SchField.Next;
                }
            return mTp_Schema (ty->Tp_Schema.ModId, NoIdent, fst);
        }
        default:
            return ErrTy;
    }
}

/* Instantiation by use */
bool InstByUse (GncTy, InsTy)
    tType GncTy, InsTy;
{
    struct gnc_subs_struct *gnclink=NULL;
    tType gncty = GncTy, insty = InsTy;
    int comp=0;

    if (gncty->Kind == kTp_Poly) {
        if (GncSubsList == NULL) {
            if (Garbage != NULL) {
                GncSubsList = Garbage; 
                Garbage = Garbage->next;
            }
            else {
                GncSubsList = (struct gnc_subs_struct *) my_malloc (sizeof (struct gnc_subs_struct));}
            GncSubsList->gncty = gncty;
            GncSubsList->insty = insty;
            GncSubsList->next = NULL;
            return true;
        }
        else {
            for (gnclink = GncSubsList; gnclink; gnclink=gnclink->next) {
                if (gnclink->gncty == gncty) 
                    /* already in the substituted list */
                    {
		comp = Compatible (gnclink->insty, insty);

/* wj -- when the instantiation is by generic type */
		    if (comp<0) 

/* at least one of the types is generic */
			{
/* if insty is not generic, or insty is a local generic and gnclink->insty is generic */
			if (!Type_IsType(insty,kTp_Poly)||((Type_IsType(insty,kTp_Poly)&&IsLocalGeneric(insty))&&Type_IsType(gnclink->insty,kTp_Poly)))

/* the new instantiation is not generic and should replace the generic one.Another entry is put in the structure to reflect this new generic instantiation */
			   {if  (InstByUse(gnclink->insty, insty))
			        {gnclink->insty = insty;
				return 1;}
			    else return 0;}
			else   
/* insty must be generic */
/* another entry is put in the structure to reflect this new generic instantiation */
			   return InstByUse(insty, gnclink->insty);}
			else return comp;}
			
		/* return (Compatible (gnclink->insty, insty) > 0);*/

                if (gnclink->next == NULL) {
                    break;} /* not in the list */
            }
            if (Garbage != NULL) {
                gnclink->next = Garbage; 
                Garbage = Garbage->next;
            }
            else
                gnclink->next = (struct gnc_subs_struct *) my_malloc (sizeof (struct gnc_subs_struct));
            gnclink = gnclink->next;
            gnclink->gncty = gncty;
            gnclink->insty = insty;
            gnclink->next = NULL;
            return true;
        }
    }
    else if (gncty->Kind == insty->Kind) 
        switch (gncty->Kind) {
            case kTp_Exp:
                return (gncty->Tp_Exp.Ident == insty->Tp_Exp.Ident);
            case kTp_Err:
                return false;
            case kTp_Any:
                return true;
            case kTp_Base:
                return (gncty->Tp_Base.Ident == insty->Tp_Base.Ident);
            case kTp_Power:
                return InstByUse (gncty->Tp_Power.Tp_Exp, insty->Tp_Power.Tp_Exp);
            case kTp_Seq:
                return InstByUse (gncty->Tp_Seq.Tp_Exp, insty->Tp_Seq.Tp_Exp);
            case kTp_Prefix:
                if (gncty->Tp_Prefix.Ident == insty->Tp_Prefix.Ident)
                    return InstByUse (gncty->Tp_Prefix.Tp_Exp, insty->Tp_Prefix.Tp_Exp);
                else
                    return false;
            case kTp_Infix:
                return InstByUse (gncty->Tp_Infix.Fst, insty->Tp_Infix.Fst) &&
                    InstByUse (gncty->Tp_Infix.Snd, insty->Tp_Infix.Snd);
            case kTp_CartProd:
            { tType gcart = gncty->Tp_CartProd.Tp_CartList;
              tType icart = insty->Tp_CartProd.Tp_CartList;
                for (; gcart && icart;
                    gcart=gcart->Tp_Cart.Next, icart=icart->Tp_Cart.Next) {
                    if (!InstByUse (gcart->Tp_Cart.Tp_Exp, icart->Tp_Cart.Tp_Exp))
                        return false;
                }
                if (gcart || icart)
                    return false;
                else
                    return true;
            } 
            case kTp_Schema:
                return (Compatible (gncty, insty) > 0);
            default:
            /* abort(); to cause a core dump. */
                InterErr(Ierror2);
                return false;
        }
    /* gncty->Kind != insty->Kind */
    else {
        tType p_gncty = ParentTy(gncty);
        tType p_insty = ParentTy(insty);

        if (p_gncty == gncty && p_insty == insty) {
            return Compatible(gncty, insty);
        }
        else return InstByUse (p_gncty, p_insty); 
    }
}

void PutGNCinGarbage(void)
{
    struct gnc_subs_struct *garlink=NULL;

            /* Put the GncSubsList produced by InstByUse and MkRngTy on the */
            /* end of the Garbage list (a singly linked list)               */
            /* Reset GncSubList to Null                                     */ 
                
            if (Garbage == NULL)
                Garbage = GncSubsList;
            else
                for (garlink=Garbage; garlink; garlink=garlink->next)
                    if (garlink->next == NULL) {    
                        garlink->next = GncSubsList;
                        break;
                    }
            GncSubsList = NULL;
}

tType Tyof_QuantPred (PredList)
  tTree PredList;
{

    /* Check that the predicate type is Boolean   */
    /* Anything else ???                          */

  tTree predlist=PredList;
  tType comm = ErrTy;

    for (; predlist && predlist->Kind != kNoPred; 
        predlist=predlist->Pred.Next)  {
         comm = CommType (predlist->Pred.Type, BoolTy);
         if (comm->Kind == kTp_Err) {
             Error (predlist->Pred.Pos, error33);
             return comm;
         }
    }
    return BoolTy;
}

/* Predicate */
tType Tyof_RelBinPred (DeclsIn, Op1, Op2, RelBinOp)
  tObjects DeclsIn;
  tTree Op1, Op2;
  tIdPos RelBinOp;
{
    /* Get the types of the operands if undefined return BoolTy (to cont?) */
    /* Lookup the operator, if undefined return NoType                     */
    /* actty = the product of the types of the operands, note IsTypeExpr   */
    /* try to match the types using type inference and overloading         */
    /* until a match found or search exhausted                             */
    /*   fmlty = the type of the operator                                  */
    /*   if its not infix then Error return BoolTy                         */
    /*   Call InstByUse to match domain of operator and operands           */
    /*     if it works the result is MkRngTy of the range of the operator  */
    /*         tidy up the gnc_subs_list                                   */
    /*         exit the inference loop                                     */
    /*     if it does not work                                             */
    /*         tidy up the gnc_subs_list                                   */
    /*         search for a new opertor;                                   */
    /*         if none found then                                          */
    /*            Give an Error                                            */
    /*            rtnty = ErrTy if none found                              */
    /*            exit the inference loop                                  */
    /* loop                                                                */
    /* return rtnty                                                        */
  
    struct gnc_subs_struct *garlink=NULL;
    tObjects sym=NoSym;
    tType actty=NoType;
    tType typelist=mTp_NoCart(); /* wj - trace for error reporting */
    tType fmlty=NoType;
    tType rtnty=ErrTy;
    tType Op1Ty=NoType, Op2Ty=NoType;

    /* assuming gnc_subs_struct means generic substitution structure */
    /* and garbage is what?                                          */

    Op1Ty = Op1->Exp.Type;
    Op2Ty = Op2->Exp.Type;

    if (!Op1Ty || !Op2Ty || Op1Ty->Kind == kTp_Err || Op2Ty->Kind == kTp_Err)
        return BoolTy;

    /* lookup the operator in symtab */

    sym = LookUp (DeclsIn, RelBinOp.Ident, NoSym);
    if (sym==NoSym) {
/* wj - relation not found */
        Error (RelBinOp.Pos, error24);
	ErrorInInfix(RelBinOp.Ident,Op1Ty,Op2Ty);
        return rtnty;
    }
   
    /* assign actty to product of types of operands  */
    /* if the operand is a type expression use its power type */

    rtnty = BoolTy; 
    if (Op1->Exp.IsTypeExp && !Op2->Exp.IsTypeExp)
        actty = mTp_CartProd (NoIdent, NoIdent, 
            mTp_Cart(mTp_Cart(NoType, Op2Ty), mTp_Power(NoIdent, Ident_power, Op1Ty)));
    else if (!Op1->Exp.IsTypeExp && Op2->Exp.IsTypeExp)
        actty = mTp_CartProd (NoIdent, NoIdent, 
            mTp_Cart(mTp_Cart(NoType, mTp_Power(NoIdent, Ident_power, Op2Ty)), Op1Ty));
    else if (Op1->Exp.IsTypeExp && Op2->Exp.IsTypeExp)
        actty = mTp_CartProd (NoIdent, NoIdent, mTp_Cart (mTp_Cart (NoType,
            mTp_Power(NoIdent, Ident_power, Op2Ty)), 
            mTp_Power(NoIdent, Ident_power, Op1Ty)));
    else
        actty = mTp_CartProd (NoIdent, NoIdent, mTp_Cart(mTp_Cart(NoType, Op2Ty), Op1Ty));

    /* try to match the operator & operands by type inference or overloading */

    while (1) {
        fmlty = sym->Object.Type;
	typelist = mTp_Cart(typelist,fmlty); /* add to trace */

        if (fmlty->Kind != kTp_Infix) {
            Error (RelBinOp.Pos, error29);
            return rtnty;
        }
        if (InstByUse (fmlty->Tp_Infix.Fst, actty)) {
            rtnty = MkRngTy(fmlty->Tp_Infix.Snd);

         /*   PutGNCinGarbage(); */

            /* Put the GncSubsList produced by InstByUse and MkRngTy on the */
            /* end of the Garbage list (a singly linked list)               */
            /* Reset GncSubList to Null                                     */ 
                
            if (Garbage == NULL)
                Garbage = GncSubsList;
            else
                for (garlink=Garbage; garlink; garlink=garlink->next)
                    if (garlink->next == NULL) {    
                        garlink->next = GncSubsList;
                        break;
                    }
            GncSubsList = NULL; 

            /* exit Type inference loop */

            break;
        }
        else {
            /* add GncSubsList to end of Garbage list set GncSubsList to Null */

            /* PutGNCinGarbage(); */

            if (Garbage == NULL)
                Garbage = GncSubsList;
            else
                for (garlink=Garbage; garlink; garlink=garlink->next)
                    if (garlink->next == NULL) {    
                        garlink->next = GncSubsList;
                        break;
                    }
            GncSubsList = NULL; 
        }
        /* overloading - look for another operator of the same name to try */

        if (sym && sym->Kind != kNoObject) 
            sym = LookUp (sym->Object.Pre, RelBinOp.Ident, sym);
         
        /* if none found then predicate is badly typed */

        if (sym==NoSym) {
            Error (RelBinOp.Pos, error24);
	    NoMoreInfixOverloads(RelBinOp.Ident,typelist,Op1Ty,Op2Ty);
            rtnty = ErrTy;
            break;
        }
    }
    return rtnty;
}

tType Tyof_Assign(DeclsIn, Namelist, Explist) /* , In_Init) */
    tObjects DeclsIn;
    tTree Namelist, Explist;
    /* bool In_Init; */
{
    tTree nlist=Namelist;
    tTree elist=Explist;
    tTree idlist;
    tTree save=NoTree;
    char *str;
    tIdent Ident=NoIdent;
    tIdent QuId=NoIdent;
    struct gnc_subs_struct *garlink=NULL;
    tObjects sym=NoSym, lastsym=NoSym;
    tType rtnty=NoType;
    tType vty=NoType, ety=NoType;
    int n;
    tIdent lastident=NoIdent;

    /* essentialy should match types of vars and expressions pairwise       */
    /* check if length of lists are the same,                               */
    /* no duplicated left hand sides                                        */
    /* all lhs variables and their unprimed counter-parts are defined       */
    /* could call RelBinPred for each component by using "=" or adding ":=" */
    /* ADA ONLY only primed variables appear on the left hand side          */
    /* ADA ONLY only unprimed variables appear on the rhs  VERY HARD        */

    /* Modified to reuse ChgsOnly so unprimed appear on LHS */

    /* Reuse Chngs_only ie unprimed on lhs,  */
        /* get qual and lastid of name                      */
        /* check lastid decorated                           */
        /* check undecorated one exists                     */
        /* and that they both have the same qualified names */

    /* Must also handle v? and v!. v? can not appear on the left hand side.  */
    /* v? and v! need not satisfy changes_only restrictions of v! and v?     */
    /* existing in primed forms as well.                                     */

    /* Special case of assign for Init schema as no pre-state vars           */
    /* ie No Unprimed vars declared but unprimed ids on lhs                  */
    /* if In_Init then  only check that primed idents exist                  */

    /*if (In_Init)
        rtnty = Tyof_InitAssChgOnly(DeclsIn, nlist); 
    else 

    rtnty = Tyof_AssChgOnly(DeclsIn, nlist);


    if (!rtnty || rtnty->Kind == kTp_Err)
         return BoolTy;
    */

    /* ow do more checks*/

    for (nlist=Namelist; nlist && nlist->Kind != kNoName; nlist=nlist->Name.Next) {


        if (elist && elist->Kind != kNoExp)
            ety = elist->Exp.Type;
        else {  /* not same length lists */
            Error (nlist->Name.Pos, il_error2);
            return ErrTy;
        }

        /* type of expression undefined */
        if (!ety || ety->Kind == kTp_Err)
            return BoolTy;

        /* lookup Ids? in Symtab check if there, get type   */
        /* get the type of the lastid                       */
        /* try to InstByUse? etc                            */
        /* if In_Init then prime it first                   */

        idlist = nlist->Name.IdList;

        /* sym = LookUpName(DeclsIn, idlist, NoSym);lpw 7/1/97  */
        /* if In_Init prime the variable first                  */
        /* this code only seems to work in the unprefixed case  */
        /* Should InstByUse be used or should it be CommType ???*/

        if (idlist->Id.Next->Kind == kNoId)
              lastident = idlist->Id.Ident.Ident;
        else /* to get lastident and QuId */ 
          for (; idlist && idlist->Kind != kNoId; 
               idlist = idlist->Id.Next) {
             if (idlist->Id.Next->Kind != kNoId &&
                 idlist->Id.Next->Id.Next->Kind == kNoId) {
                    save = idlist->Id.Next;
                    lastident = save->Id.Ident.Ident;
                    idlist->Id.Next = mNoId();
                    QuId = FormtIdent (nlist->Name.IdList);
                    idlist->Id.Next = save;
                    break;
             } 
          }
        
        /* if (In_Init) { */
             str = (char *) my_malloc (IDENT_LENGTH);
             str[0] = '\0';
             GetString (lastident, str);
             n = strlen (str) - 1;
             if (str[n] == '?') { 
                Error(elist->Name.Pos, il_error4);
                elist=elist->Exp.Next;
                break;
             }
             else if (str[n] == '!') {
                elist=elist->Exp.Next;
                break;
             }
             else {
               strcat (str, "'");
               Ident = MakeIdent(str, strlen(str));
             }
                        /* } else Ident = lastident; */

        sym = DeclsIn;
        lastsym = NoSym;
        while (sym && sym->Kind != kNoObject) {
            if ((sym = LookUp (sym, Ident, lastsym)) == NoSym) {
                    Error (nlist->Name.Pos, error13);
                    break;
                }
             else if (QuId == NoIdent)
                 break;
             else { 
               /* found it, and QuId prefix was found then
                * check if the Objects QuId prefix is the same too.
                */
                  if ( sym->Kind == kObj_Id && 
                      sym->Obj_Id.QuId == QuId) 
                       break;

                  lastsym = sym;
                  sym = sym->Object.Pre;
             }

          vty = sym->Object.Type;

          if (!InstByUse(vty,ety))
             Error (nlist->Name.Pos, error24);

          PutGNCinGarbage();

        }
        elist=elist->Exp.Next;
    }

    /* check no expressions left over */
    
    if (elist->Kind != kNoExp) {  /* Error too many expressions */
        Error (elist->Exp.Pos, il_error3);
        return ErrTy;
    }
    else
       return BoolTy;
}


tType Tyof_RelPrePred (DeclsIn, RelPreOp, Exp)
  tObjects DeclsIn;
  tIdPos RelPreOp;
  tTree Exp;
{
    struct gnc_subs_struct *garlink=NULL;
    tObjects sym=DeclsIn;
    tType actty=NoType;
    tType fmlty=NoType;
    tType typelist=mTp_NoCart(); /* wj - trace for error reporting */
    tType rtnty=NoType;

    actty = Exp->Exp.Type;
    rtnty = BoolTy; 

    if (!actty || actty->Kind == kTp_Err)
        return rtnty;

    if (Exp->Exp.IsTypeExp)
        actty = mTp_Power (NoIdent, Ident_power, Exp->Exp.Type);
    else
        actty = Exp->Exp.Type;

    sym = LookUp (sym, RelPreOp.Ident, NoSym);
    if (sym==NoSym) {
/* wj - cant find relpreop */
        Error (RelPreOp.Pos, error24);
	ErrorInPrefix(RelPreOp.Ident,Exp->Exp.Type);
        return ErrTy;
    }
    while (1) {
        fmlty = sym->Object.Type;
	typelist = mTp_Cart(typelist,fmlty);
            
        if (fmlty->Kind != kTp_Infix) {
            Error (RelPreOp.Pos, error29);
            break;
        }
        if (InstByUse (fmlty->Tp_Infix.Fst, actty)) {
            rtnty = MkRngTy(fmlty->Tp_Infix.Snd);
                
            if (Garbage == NULL)
                Garbage = GncSubsList;
            else
                for (garlink=Garbage; garlink; garlink=garlink->next)
                    if (garlink->next == NULL) {    
                        garlink->next = GncSubsList;
                        break;
                    }
            GncSubsList = NULL;
            break;
        }
        else {
            if (Garbage == NULL)
                Garbage = GncSubsList;
            else
                for (garlink=Garbage; garlink; garlink=garlink->next)
                    if (garlink->next == NULL) {    
                        garlink->next = GncSubsList;
                        break;
                    }
            GncSubsList = NULL;
        }
        if (sym && sym->Kind != kNoObject) 
            sym = LookUp (sym->Object.Pre, RelPreOp.Ident, sym);
        if (sym==NoSym) {
/* wj - no overloading either */
            Error (RelPreOp.Pos, error24);
	    NoMorePrefixOverloads(RelPreOp.Ident,typelist,Exp->Exp.Type);
            rtnty = ErrTy;
            break;
        }
    }
    return rtnty;
}

/* Declarations */
tType FormTp_Schema (Inner, ModId)
    tObjects Inner;
{
  /* to form the schema type for a schema definition.
   */
    tObjects inn = Inner;
    tType pty_b=NoType, pty=NoType;

    if (!inn)
        return mTp_Schema(ModId, NoIdent, NoType);
        
    if (inn->Kind == kNoObject)
        return mTp_Schema(ModId, NoIdent, NoType);
    
    for (; inn && inn->Kind == kObj_Param; inn=inn->Object.Next)
        ; /* skip over parameters */

    for (; inn && inn->Kind != kNoObject; inn=inn->Object.Next)
        if (inn->Kind == kObj_Id) 
            if (!pty_b) {
                pty_b = mTp_SchField (NoType, inn->Obj_Id.ModId, 
                    inn->Obj_Id.Ident, inn->Obj_Id.Type, inn->Obj_Id.QuId); 
                pty = pty_b;
            }
            else {
                pty->Tp_SchField.Next = mTp_SchField (NoType, 
                    inn->Obj_Id.ModId, inn->Obj_Id.Ident,
                    inn->Obj_Id.Type, inn->Obj_Id.QuId); 
                pty = pty->Tp_SchField.Next;
            }
    return mTp_Schema (ModId, NoIdent, pty_b);
}

tType FormTp_SchemaD (Inner, Strokes, ModId)
    tObjects Inner;
    char *Strokes;
{
    tType formedty=NoType;
    char *str;
    tType fldlist=NoType;

    formedty = FormTp_Schema(Inner, ModId);

    str = (char *) my_malloc (IDENT_LENGTH);
    for (fldlist=formedty->Tp_Schema.Tp_SchFieldList;
        Type_IsType(fldlist,kTp_SchField); fldlist=fldlist->Tp_SchField.Next) {
        str[0] = '\0';
        GetString (fldlist->Tp_SchField.Ident, str);
        str = strcat (str, Strokes);
        fldlist->Tp_SchField.Ident = MakeIdent (str, strlen(str));
    }
    return formedty;
}

tType CpSchType (SchTy)
    tType SchTy;
{
    tType fldlist=NoType;
    tType fst=NoType, last=NoType;

    if (SchTy && SchTy->Kind == kTp_Schema) {
        for (fldlist=SchTy->Tp_Schema.Tp_SchFieldList;
            Type_IsType(fldlist,kTp_SchField); fldlist=fldlist->Tp_SchField.Next) {
            if (fst) {
                last->Tp_SchField.Next = mTp_SchField(NoType, 
                    fldlist->Tp_SchField.ModId,
                    fldlist->Tp_SchField.Ident,
                    fldlist->Tp_SchField.Tp_Exp, 
                    fldlist->Tp_SchField.QuId);
                last = last->Tp_SchField.Next;
            }
            else {
                fst = mTp_SchField (NoType, 
                    fldlist->Tp_SchField.ModId,
                    fldlist->Tp_SchField.Ident,
                    fldlist->Tp_SchField.Tp_Exp, 
                    fldlist->Tp_SchField.QuId);
                last = fst;
            }
        }
        return mTp_Schema (SchTy->Tp_Schema.ModId, SchTy->Tp_Schema.Ident, fst);
    }
    else {
        InterErr ("Wrong using of CpSchType.");
        return ErrTy; 
    }
}

tType CpSchTypeD (SchTy, Strokes)
    tType SchTy;
    char *Strokes;
{
    char *str;
    tType fldlist=NoType;
    tType rtnty;

    rtnty = CpSchType (SchTy);
    if (rtnty && rtnty->Kind != kTp_Err) {

        str = (char *) my_malloc (IDENT_LENGTH);
        for (fldlist=rtnty->Tp_Schema.Tp_SchFieldList;
            Type_IsType(fldlist,kTp_SchField); fldlist=fldlist->Tp_SchField.Next) {
            str[0] = '\0';
            GetString (fldlist->Tp_SchField.Ident, str);
            str = strcat (str, Strokes);
            fldlist->Tp_SchField.Ident = MakeIdent (str, strlen(str));
        }
    }
    return rtnty;
}

/* Schemas instantiation */
tType Tyof_Exp_SchemaRef (DeclsIn, IdList, ExpList)
    tObjects DeclsIn;
    tTree IdList, ExpList;
{
    tObjects sym_ptr = NoSym;
    tTree act_params = ExpList, idlist=IdList;
    tType fldlist = NoType;
    tType rtnty = NoType;
    tPosition pos;
    char *str, *strokes;
    int i;
    bool primed = 0;
    FAList fahead;
    tIdent Primed=NoIdent;

    /* handling primed schema references */
    for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next)
        if (idlist->Id.Next->Kind == kNoId)
            break;
    /* last Id on the idlist */
    str = (char *) my_malloc (IDENT_LENGTH);
    strokes = (char *) my_malloc (IDENT_LENGTH);
    str[0] = '\0';
    strokes[0] = '\0';
    GetString (idlist->Id.Ident.Ident, str);
    Primed = idlist->Id.Ident.Ident;
    for (i=0; i<strlen(str); i++)
        if (str[i] == '\'' || str[i] == '!' || str[i] == '?') {
            strcpy (strokes, str+i);
            str[i] = '\0';
            idlist->Id.Ident.Ident = MakeIdent (str, strlen(str)); 
            primed = 1;
            break;
        }
    sym_ptr =  LookUpName (DeclsIn, IdList, NoSym);

    /* reset last Ident to Primed reference */
    idlist->Id.Ident.Ident = Primed;

    pos = IdList->Id.Ident.Pos;
    if (!sym_ptr) {
#        ifdef Debug
            DError (pos, error11);
#        else 
            Error (pos, error11);
	    ErrorInName(IdList);
#        endif
        return ErrTy;
    }
    if (sym_ptr->Kind != kObj_Inn || sym_ptr->Obj_Inn.ObjKind != Obj_schema) {
        Error (pos, error9);
        return ErrTy;
    }
    if (!ParamComp (sym_ptr->Obj_Inn.Inner, act_params)) {
        Error (pos, error3);   
        return ErrTy;
    }
    fahead = SchFAComInner (sym_ptr, act_params);
    if (primed)
        rtnty = FormTp_SchemaD (sym_ptr->Obj_Inn.Inner, strokes, sym_ptr->Obj_Inn.ModId);
    else
        rtnty = FormTp_Schema (sym_ptr->Obj_Inn.Inner, sym_ptr->Obj_Inn.ModId);
    fldlist = rtnty->Tp_Schema.Tp_SchFieldList;
    for (; Type_IsType(fldlist,kTp_SchField); fldlist=fldlist->Tp_SchField.Next)
        fldlist->Tp_SchField.Tp_Exp =
            SubsTy(fldlist->Tp_SchField.Tp_Exp, fahead);
    return rtnty;
}

char mystr[IDENT_LENGTH];

void PrintTy(Type)
    tType Type;
{
    tType ty=Type;

    mystr[0] = '\0';
    if (!ty)
        return;
    switch (ty->Kind) {
        case kTp_Exp:
            GetString (ty->Tp_Exp.Ident, mystr);
            printf ("%s", mystr);
            break;
        case kTp_Poly:
            GetString (ty->Tp_Poly.Ident, mystr);
            printf ("%s", mystr);
            break;
        case kTp_Err:
            printf ("E'"); 
            break;
        case kTp_Any:
            printf ("A'");
            break;
        case kTp_Base:
            GetString (ty->Tp_Exp.Ident, mystr);
            printf ("%s", mystr);
            break;
        case kTp_Prefix:
            GetString (ty->Tp_Prefix.Ident, mystr);
            printf ("(%s ", mystr);
            PrintTy(ty->Tp_Prefix.Tp_Exp);
            printf (")");
            break;
        case kTp_Power:
            GetString (ty->Tp_Power.Ident, mystr);
            printf ("(%s ", mystr);
            PrintTy(ty->Tp_Power.Tp_Exp);
            printf (")");
            break;
        case kTp_Seq:
            GetString (ty->Tp_Seq.Ident, mystr);
            printf ("(%s ", mystr);
            PrintTy(ty->Tp_Seq.Tp_Exp);
            printf (")");
            break;
        case kTp_Infix:
            printf ("(");
            PrintTy(ty->Tp_Infix.Fst);
            printf (" ");
            GetString (ty->Tp_Infix.Ident, mystr);
            printf ("%s ", mystr);
            PrintTy(ty->Tp_Infix.Snd);
            printf (")");
            break;
        case kTp_CartProd:
            printf ("(");
            { tType tylist=ty->Tp_CartProd.Tp_CartList;
                for (; tylist; tylist=tylist->Tp_Cart.Next) {
                    PrintTy (tylist->Tp_Cart.Tp_Exp);
                    if (tylist->Tp_Cart.Next)
                        printf (" # ");
                }
            }
            printf (")");
            break;
        case kTp_Schema:
            printf ("{");
            { tType fldlist=ty->Tp_Schema.Tp_SchFieldList;
                for (; Type_IsType(fldlist,kTp_SchField); fldlist=fldlist->Tp_SchField.Next) {
                    GetString (fldlist->Tp_SchField.Ident, mystr);
                    printf ("%s", mystr);
                    if (fldlist->Tp_SchField.QuId != NoIdent) {
                        mystr[0] = '\0';
                        GetString (fldlist->Tp_SchField.QuId, mystr);
                        printf ("(%s):", mystr);
                    }
                    else
                        printf (":");
                    PrintTy (fldlist->Tp_SchField.Tp_Exp);
                    if (Type_IsType(fldlist->Tp_SchField.Next,kTp_SchField))
                        printf (", ");
                }
            }
            printf ("}");
            break;
    }

    if (ty->Tp_Exp.ModId != NoIdent) {
        char modidstr[IDENT_LENGTH];

        GetString (ty->Tp_Exp.ModId, modidstr);
        printf (" (%s)", modidstr);
    }
}

/* handle schema renames */
tType Tyof_SchSubst(SchTy, RenameList, Pos)
    tType SchTy;
    tTree RenameList;
    tPosition Pos;
{
    tTree renamelist=RenameList;
    tType fldlist=NoType;
    tTree idlist=NoTree;
    tIdent OldIdent=NoIdent, QuId=NoIdent;
    tPosition pos;
    tType rtnty=NoType;
    char str[IDENT_LENGTH];
    tTree save=NoTree;

    if (SchTy && SchTy->Kind == kTp_Schema) {
        rtnty = CpSchType (SchTy);    

        for (; renamelist->Kind != kNoRename; 
            renamelist = renamelist->Rename.Next) {

            pos = renamelist->Rename.OldIdent->Id.Ident.Pos;

            idlist=renamelist->Rename.OldIdent;
            if (idlist && idlist->Id.Next && idlist->Id.Next->Kind == kNoId)
                OldIdent = idlist->Id.Ident.Ident;
            else 
                for (; idlist && idlist->Kind != kNoId; 
                    idlist = idlist->Id.Next)
                    if (idlist->Id.Next->Kind != kNoId &&
                        idlist->Id.Next->Id.Next->Kind == kNoId) {
                        save = idlist->Id.Next;
                        OldIdent = save->Id.Ident.Ident;
                        idlist->Id.Next = mNoId();
                        QuId = FormtIdent (renamelist->Rename.OldIdent);
                        idlist->Id.Next = save;
                        break;
                    }

            for (fldlist=rtnty->Tp_Schema.Tp_SchFieldList;
                 Type_IsType(fldlist,kTp_SchField); fldlist=fldlist->Tp_SchField.Next) 
                if (OldIdent == fldlist->Tp_SchField.Ident) {
					if ((QuId == fldlist->Tp_SchField.QuId) ||
						(fldlist->Tp_SchField.QuId == NoIdent && 
						QuId == SchTy->Tp_Schema.ModId) ||
						QuId == NoIdent) {

						fldlist->Tp_SchField.Ident = renamelist->Rename.NewIdent.Ident;
						fldlist->Tp_SchField.QuId = NoIdent;
						break;
					}
				}
            if (fldlist==NoType) 
                Error (pos, error13);
        }
        return rtnty;
    }
    else {
        Error (Pos, error9);
        return ErrTy;
    }
}

/* Sch  { name, ..., name }
 */
tType Tyof_SchHiding(SchTy, NameList, SchPos)
    tType SchTy;
    tTree NameList;
    tPosition SchPos;
{
    tTree elist = NameList;
    tTree idlist=NoTree;
    tType fld=NoType;
    tTree save=NoTree;
    tIdent lastident=NoIdent, QuId=NoIdent;

    if (SchTy && SchTy->Kind == kTp_Schema) {
        for (fld=SchTy->Tp_Schema.Tp_SchFieldList;
             fld; fld=fld->Tp_SchField.Next) 
            fld->Tp_SchField.Tag = true;

        for (; elist && elist->Kind != kNoName; 
            elist=elist->Name.Next) {

            idlist = elist->Name.IdList;
            if (idlist->Id.Next->Kind != kNoId) { /* with prefix */
                for (; idlist && idlist->Kind != kNoId; 
                    idlist = idlist->Id.Next)
                    if (idlist->Id.Next->Kind != kNoId &&
                        idlist->Id.Next->Id.Next->Kind == kNoId) {
                        /* to get the prefix */
                        save = idlist->Id.Next;
                        lastident = save->Id.Ident.Ident;
                        idlist->Id.Next = mNoId();
                        QuId = FormtIdent (elist->Name.IdList);
                        idlist->Id.Next = save;
                        break;
                    }
			}
            else /* no prefix */
                lastident = idlist->Id.Ident.Ident;

			for (fld=SchTy->Tp_Schema.Tp_SchFieldList;
				 fld; fld=fld->Tp_SchField.Next) 
				if (lastident == fld->Tp_SchField.Ident &&
					fld->Tp_SchField.QuId == QuId) {
					fld->Tp_SchField.Tag = false;
					break;
				}
			if (fld==NoType) 
				Error (elist->Name.Pos, error13);
		}
        return FormSchComb(SchTy, mTp_Schema(NoIdent, NoIdent, NoType));
    }
    else {
        Error (SchPos, error9);
        return ErrTy;
    }
}

tType Tyof_PreCondPred(Ty, Pos)
    tType Ty;
    tPosition Pos;
{
    tType fld=NoType; 
    char *str;
    str = (char *)my_malloc (IDENT_LENGTH);

    if (Ty && Ty->Kind == kTp_Schema) {
        for (fld=Ty->Tp_Schema.Tp_SchFieldList;
             fld; fld=fld->Tp_SchField.Next) 
            fld->Tp_SchField.Tag = true;

        for (fld=Ty->Tp_Schema.Tp_SchFieldList;
             fld; fld=fld->Tp_SchField.Next) {

            str[0] = '\0';
            GetString (fld->Tp_SchField.Ident, str);
            if (str[strlen(str)-1] == '\'' || str[strlen(str)-1] == '!')
                fld->Tp_SchField.Tag = false;
        }
        return FormSchComb(Ty, mTp_Schema(NoIdent, NoIdent, NoType));
    }
    else if (Ty && Ty->Kind == kTp_Base && Ty->Tp_Base.Ident == Ident_bool)
        return Ty;
    else {
        Error (Pos, error33);
        return ErrTy;
    }
}

tType Tyof_SchCompos(Ty1, Compos, Ty2)
    tType Ty1, Ty2;
    tIdPos Compos;
{
    tType fld1=NoType, fld2=NoType;
    char *str;
    tType fst=NoType;

    str = (char *) my_malloc (IDENT_LENGTH);

    if (SchCompatible (Ty1, Ty2)) {
        if (Ty1==Ty2)
            fst = CpSchType(Ty1);
        else
            fst = Ty1;
        fld1 = fst->Tp_Schema.Tp_SchFieldList;
        fld2 = Ty2->Tp_Schema.Tp_SchFieldList;
        for (; fld1; fld1=fld1->Tp_SchField.Next)
            fld1->Tp_SchField.Tag = true;
        for (; fld2; fld2=fld2->Tp_SchField.Next)
            fld2->Tp_SchField.Tag = true;

        fld1 = fst->Tp_Schema.Tp_SchFieldList;
        for (; fld1; fld1 = fld1->Tp_SchField.Next) {
            str[0] = '\0';
            GetString (fld1->Tp_SchField.Ident, str);
            if (str[strlen(str)-1] == '\'') {
                str[strlen(str)-1] = '\0';
                fld2 = Ty2->Tp_Schema.Tp_SchFieldList;
                for (; fld2; fld2 = fld2->Tp_SchField.Next) 
                    if (fld2->Tp_SchField.Ident == MakeIdent (str, strlen(str))) {
                        fld1->Tp_SchField.Tag = false;
                        fld2->Tp_SchField.Tag = false;
                    }
            }
        }
        fld1 = fst->Tp_Schema.Tp_SchFieldList;
        for (; fld1; fld1=fld1->Tp_SchField.Next)
            for (fld2=Ty2->Tp_Schema.Tp_SchFieldList;
                 fld2; fld2=fld2->Tp_SchField.Next)

                if (fld1->Tp_SchField.Tag && fld2->Tp_SchField.Tag
                    && (fld1->Tp_SchField.Ident == fld2->Tp_SchField.Ident))
                    fld2->Tp_SchField.Tag = false;
        return FormSchComb(fst, Ty2);
    }
    else {
        Error (Compos.Pos, error12);
        return ErrTy;
    }
}

tType FormSchComb (Ty1, Ty2)
    tType Ty1, Ty2;
{
    tType fld1=NoType, fld2=NoType;
    tType fst=NoType, last=NoType;

    fld1 = Ty1->Tp_Schema.Tp_SchFieldList;
    for (; fld1; fld1=fld1->Tp_SchField.Next) 
        if (fld1->Tp_SchField.Tag)
            if (fst==NoType) {
                fst = mTp_SchField(NoType, fld1->Tp_SchField.ModId,
                    fld1->Tp_SchField.Ident, fld1->Tp_SchField.Tp_Exp, 
                    fld1->Tp_SchField.QuId);
                last = fst;
            }
            else {
                last->Tp_SchField.Next = mTp_SchField(NoType,
                    fld1->Tp_SchField.ModId, fld1->Tp_SchField.Ident,
                    fld1->Tp_SchField.Tp_Exp, fld1->Tp_SchField.QuId);
                last = last->Tp_SchField.Next;
            }
    fld2 = Ty2->Tp_Schema.Tp_SchFieldList;
    for (; fld2; fld2=fld2->Tp_SchField.Next)
        if (fld2->Tp_SchField.Tag)
            if (fst==NoType) {
                fst = mTp_SchField(NoType, fld2->Tp_SchField.ModId, 
                    fld2->Tp_SchField.Ident, fld2->Tp_SchField.Tp_Exp, 
                    fld2->Tp_SchField.QuId);
                last = fst;
            }
            else {
                last->Tp_SchField.Next = mTp_SchField(NoType,
                    fld2->Tp_SchField.ModId, fld2->Tp_SchField.Ident, 
                    fld2->Tp_SchField.Tp_Exp, fld2->Tp_SchField.QuId);
                last = last->Tp_SchField.Next;
            }
    return mTp_Schema(Ty1->Tp_Schema.ModId, NoIdent, fst);
}

bool SchCompatible (Ty1, Ty2)
    tType Ty1, Ty2;
{
    tType fld1=NoType, fld2=NoType;

    if (Ty1 && (Ty1->Kind == kTp_Schema) && Ty2 && (Ty2->Kind == kTp_Schema)) {
        fld1 = Ty1->Tp_Schema.Tp_SchFieldList;
        for (; fld1; fld1=fld1->Tp_SchField.Next) {
            fld2 = Ty2->Tp_Schema.Tp_SchFieldList;
            for (; fld2; fld2=fld2->Tp_SchField.Next)
                if (fld1->Tp_SchField.Ident == fld2->Tp_SchField.Ident &&
                    fld1->Tp_SchField.QuId == fld2->Tp_SchField.QuId)
                    if (TypeStructEq(fld1->Tp_SchField.Tp_Exp, fld2->Tp_SchField.Tp_Exp)) 
                        break;
                    else 
                        return false;
        }
        return true;
    }
    else
        return false; /* not schemas */
}

tType Tyof_SchProj (Sch1Ty, Proj, Sch2Ty)
    tType Sch1Ty, Sch2Ty;
    tIdPos Proj;
{
    if (SchCompatible (Sch1Ty, Sch2Ty))
        return Sch2Ty;
    else {
        Error (Proj.Pos, error12);
        return ErrTy;
    }
}

/* Pred LogBinOp Pred */
tType Tyof_LogBinPred(Ty1, Ty2, Pos1, Pos2)
    tType Ty1, Ty2;
    tPosition Pos1, Pos2;
{
    tType rtnty=NoType;

    rtnty = SchCombine (Ty1, Ty2);
    if (rtnty->Kind != kTp_Err)
        return rtnty; /* schema combination */
    else {
        if (!Ty1 || Ty1->Kind == kTp_Err || !Ty2 || Ty2->Kind == kTp_Err)
            return rtnty;
        else if (Ty1->Kind == kTp_Schema && Ty2->Kind == kTp_Schema) {
            Error (Pos1, error12);
            return rtnty;
        }
    }

    if (Ty1->Kind == kTp_Schema)
        if (Ty2->Tp_Exp.Ident == Ident_bool)
            return Ty2; 
        else {
            Error (Pos2, error33);
            return ErrTy;
        }
    else if (Ty2->Kind == kTp_Schema)
        if (Ty1->Tp_Exp.Ident == Ident_bool)
            return Ty1;
        else {
            Error (Pos1, error33);
            return ErrTy;
        }
    else if (Ty1->Tp_Exp.Ident == Ident_bool) 
        if (Ty2->Tp_Exp.Ident == Ident_bool)
            return Ty1;
        else {
            Error (Pos2, error33);
            return ErrTy;
        }
    else {
        Error (Pos1, error33);
        return ErrTy;
    }
}

tType SchCombine (Ty1, Ty2)
    tType Ty1, Ty2;
{
    tType fld1=NoType, fld2=NoType;
    tType fst=NoType;

    if (SchCompatible(Ty1, Ty2)) {
    /* schema calculus */
        if (Ty1 == Ty2)
            fst = CpSchType (Ty1);
        else 
            fst = Ty1;

        fld1 = fst->Tp_Schema.Tp_SchFieldList;
        fld2 = Ty2->Tp_Schema.Tp_SchFieldList;
        for (; fld1; fld1=fld1->Tp_SchField.Next)
            fld1->Tp_SchField.Tag = true;
        for (; fld2; fld2=fld2->Tp_SchField.Next)
            fld2->Tp_SchField.Tag = true;

        fld1 = fst->Tp_Schema.Tp_SchFieldList;
        for (; fld1; fld1=fld1->Tp_SchField.Next) {
            fld2 = Ty2->Tp_Schema.Tp_SchFieldList;
            for (; fld2; fld2=fld2->Tp_SchField.Next)
                if (fld2->Tp_SchField.Tag && (fld1->Tp_SchField.Ident == fld2->Tp_SchField.Ident)) 
                    fld2->Tp_SchField.Tag = false;
        }
        return FormSchComb(fst,Ty2);
    }
    else
        return ErrTy;
}

/* old version 
tType Tyof_ChgOnly (DeclsIn, ExpList)
    tObjects DeclsIn;
    tTree ExpList;
{
    tTree elist=ExpList;
    tTree idlist=NoTree;
    char str[IDENT_LENGTH];
    tIdent store=NoIdent;

    for (; elist && elist->Kind != kNoExp; elist=elist->Exp.Next)

        if (elist->Kind != kVariable)
            Error (elist->Variable.Pos, error13);
        else if (LookUpName (DeclsIn, elist->Variable.IdList, NoSym) == NoSym) 
            Error (elist->Variable.Pos, error13);
        else { 
            idlist = elist->Variable.IdList;
            for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) 
                if (idlist->Id.Next->Kind == kNoId) { 
                    store = idlist->Id.Ident.Ident;
                    break;
                }
            str[0] = '\0';
            GetString (store, str);
            strcat (str, "'");
            idlist->Id.Ident.Ident = MakeIdent(str, strlen(str));
            if (LookUpName (DeclsIn, elist->Variable.IdList, NoSym) == NoSym)
                Error (elist->Variable.Pos, error36);
            idlist->Id.Ident.Ident = store;
        }

    return BoolTy;
}
*/

/* changes_only { name, name, ..., name }
 * name = id { .id }, is either an object or a schema.
 * If it is an object, to check it is in the schema signature(scope). 
 * In the case of qualified name, prefix.id, check id is in the scope 
 * and has the same prefix(QuId).
 * If it is a schema, unfold it to check each object is in the scope.
 */
tType Tyof_ChgOnly (DeclsIn, NameList)
    tObjects DeclsIn;
    tTree NameList;
{
    tTree elist=NameList;
    tTree idlist=NoTree;
    char str[IDENT_LENGTH];
    tIdent lastident=NoIdent, QuId=NoIdent, Ident=NoIdent;
    tObjects sym_ptr=DeclsIn, lastsym=NoSym;
    tTree save=NoTree;
    tType fld=NoType;

    for (; elist && elist->Kind != kNoName; elist=elist->Name.Next) {

        idlist = elist->Name.IdList;
        if (idlist && idlist->Id.Next->Kind == kNoId) { 
            /* no prefix */
            if ((sym_ptr = LookUp (DeclsIn, idlist->Id.Ident.Ident, NoSym))
                == NoSym) 
                Error (elist->Name.Pos, error13);

            else if (sym_ptr->Kind == kObj_Inn && 
                sym_ptr->Obj_Inn.ObjKind == Obj_schema) {

                /* It is a schema, unfold it to check each unprimed 
                 * object in the signature.
                 */
                fld = sym_ptr->Object.Type->Tp_Schema.Tp_SchFieldList;
                for (; fld; fld=fld->Tp_SchField.Next) {
                    sym_ptr = DeclsIn;  
                    lastsym = NoSym;
                    Ident = fld->Tp_SchField.Ident;
                    while (sym_ptr && sym_ptr->Kind != kNoObject) 
                        if ((sym_ptr = LookUp (sym_ptr, Ident, lastsym))
                            == NoSym) {
                            Error (elist->Name.Pos, error40);
                            break;
                        }
                        else {
                            if (sym_ptr->Kind == kObj_Id && 
                                sym_ptr->Obj_Id.QuId == fld->Tp_SchField.QuId)
                                break;

                            lastsym = sym_ptr;
                            sym_ptr = sym_ptr->Object.Pre;
                        }

                    if (sym_ptr) {
                    /* check if the primed object is also declared. */
                        str[0] = '\0';
                        GetString (Ident, str);
                        strcat (str, "'");
                        Ident = MakeIdent(str, strlen(str));

                        sym_ptr = DeclsIn;  
                        lastsym = NoSym;
                        while (sym_ptr && sym_ptr->Kind != kNoObject) 
                            if ((sym_ptr = LookUp (sym_ptr, Ident, lastsym))
                                == NoSym) {
                                Error (elist->Name.Pos, error36);
                                break;
                            }
                            else {
                                if (sym_ptr->Kind == kObj_Id && 
                                    sym_ptr->Obj_Id.QuId == fld->Tp_SchField.QuId)
                                    break;

                                lastsym = sym_ptr;
                                sym_ptr = sym_ptr->Object.Pre;
                            }
                    }
                }
            }
            else {
            /* found it, but not a schema. Check if the corresponding primed 
             * one is also declared. 
             */
                str[0] = '\0';
                GetString (idlist->Id.Ident.Ident, str);
                strcat (str, "'");
                Ident = MakeIdent(str, strlen(str));
                if (LookUp (DeclsIn, Ident, NoSym) == NoSym)
                    Error (elist->Name.Pos, error36);
                /*
                sym_ptr = DeclsIn;  
                lastsym = NoSym;
                while (sym_ptr && sym_ptr->Kind != kNoObject) 
                    if ((sym_ptr = LookUp (sym_ptr, Ident, lastsym))
                        == NoSym) {
                        Error (elist->Name.Pos, error36);
                        break;
                    }
                    else {
                        if (sym_ptr->Kind == kObj_Id &&
                            sym_ptr->Obj_Id.QuId == NoIdent)
                            break;

                        lastsym = sym_ptr;
                        sym_ptr = sym_ptr->Object.Pre;
                    }
                */
            }
        }
        else { /* with prefix */

            /* to get QuId */ 
            for (; idlist && idlist->Kind != kNoId; 
                idlist = idlist->Id.Next)
                if (idlist->Id.Next->Kind != kNoId &&
                    idlist->Id.Next->Id.Next->Kind == kNoId) {
                    /* to get the prefix */
                    save = idlist->Id.Next;
                    lastident = save->Id.Ident.Ident;
                    idlist->Id.Next = mNoId();
                    QuId = FormtIdent (elist->Name.IdList);
                    idlist->Id.Next = save;
                    break;
                }

            sym_ptr = LookUpName (DeclsIn, idlist, NoSym);
            if (sym_ptr && sym_ptr->Kind == kObj_Inn &&
                sym_ptr->Obj_Inn.ObjKind == Obj_schema) {
                /* it is a schema name. */

                fld = sym_ptr->Object.Type->Tp_Schema.Tp_SchFieldList;
                for (; fld; fld=fld->Tp_SchField.Next) {
                    sym_ptr = DeclsIn;  
                    lastsym = NoSym;
                    Ident = fld->Tp_SchField.Ident;
                    while (sym_ptr && sym_ptr->Kind != kNoObject) 
                        if ((sym_ptr = LookUp (sym_ptr, Ident, lastsym))
                            == NoSym) {
                            Error (elist->Name.Pos, error40);
                            break;
                        }
                        else {
                            if (sym_ptr->Kind == kObj_Id && 
                                sym_ptr->Obj_Id.QuId == QuId)
                                break;

                            lastsym = sym_ptr;
                            sym_ptr = sym_ptr->Object.Pre;
                        }

                    if (sym_ptr) {
                        /* check if the primed object is also declared. */
                        str[0] = '\0';
                        GetString (Ident, str);
                        strcat (str, "'");
                        Ident = MakeIdent(str, strlen(str));

                        sym_ptr = DeclsIn;  
                        lastsym = NoSym;
                        while (sym_ptr && sym_ptr->Kind != kNoObject) 
                            if ((sym_ptr = LookUp (sym_ptr, Ident, lastsym))
                                == NoSym) {
                                Error (elist->Name.Pos, error36);
                                break;
                            }
                            else {
                                if (sym_ptr->Kind == kObj_Id && 
                                    sym_ptr->Obj_Id.QuId == QuId)
                                    break;

                                lastsym = sym_ptr;
                                sym_ptr = sym_ptr->Object.Pre;
                            }
                    }
                }
                break;  
            }

            /* it is an object name */  
            sym_ptr = DeclsIn;
            lastsym = NoSym;
            while (sym_ptr && sym_ptr->Kind != kNoObject) 
                if ((sym_ptr = LookUp (sym_ptr, lastident, lastsym)) == NoSym) {
                    Error (elist->Name.Pos, error13);
                    break;
                }
                else { 
                /* found it, and
                 * to check if the prefix is the same too.
                 */
                    if (sym_ptr->Kind == kObj_Id && 
                        sym_ptr->Obj_Id.QuId == QuId) 
                        break;

                    lastsym = sym_ptr;
                    sym_ptr = sym_ptr->Object.Pre;
                }

            if (sym_ptr) {
            /* check if the primed one is also declared. */
                str[0] = '\0';
                GetString (lastident, str);
                strcat (str, "'");
                lastident = MakeIdent (str, strlen(str));

                sym_ptr = DeclsIn;
                lastsym = NoSym;
                while (sym_ptr && sym_ptr->Kind != kNoObject) 
                    if ((sym_ptr = LookUp (sym_ptr, lastident, lastsym)) == NoSym) {
                        Error (elist->Name.Pos, error36);
                        break;
                    }
                    else { 
                    /* found it, and
                     * to check if the prefix is the same too.
                     */
                        if (sym_ptr->Kind == kObj_Id && 
                            sym_ptr->Obj_Id.QuId == QuId) 
                            break;

                        lastsym = sym_ptr;
                        sym_ptr = sym_ptr->Object.Pre;
                    }
            }
        }
    }
    return BoolTy;
}

/* This is a special case of changes_only for the assignment statement
 * occuring in an Init schema.
 * In this case only the primed state variables will be in scope
 * but the unprimed variable will appear on the left hand side of the
 * assignment. The variable may be an object or a schema.
 * If it is a schema then its primed version will be looked up
 * and all of its components will be primed.
 */

tType Tyof_InitAssChgOnly (DeclsIn, NameList)
    tObjects DeclsIn;
    tTree NameList;
{
    tTree elist=NameList;
    tTree idlist=NoTree;
    char str[IDENT_LENGTH];
    tIdent lastident=NoIdent, QuId=NoIdent, Ident=NoIdent;
    tObjects sym_ptr=DeclsIn, lastsym=NoSym;
    tTree save=NoTree;
    tType fld=NoType;
    int n;

    for (; elist && elist->Kind != kNoName; elist=elist->Name.Next) {

        idlist = elist->Name.IdList;

        /* no prefix */
        if (idlist && idlist->Id.Next->Kind == kNoId) { 

        /* check if the primed object is declared. */
              str[0] = '\0';
              GetString (idlist->Id.Ident.Ident, str);
              strcat (str, "'");
              Ident = MakeIdent(str, strlen(str));

              sym_ptr = DeclsIn;  

            if ((sym_ptr = LookUp (DeclsIn, Ident, NoSym))
                == NoSym) 
                Error (elist->Name.Pos, error36);

            else if (sym_ptr->Kind == kObj_Inn && 
                sym_ptr->Obj_Inn.ObjKind == Obj_schema) {

                /* If it is a schema, unfold it to check each unprimed 
                 * object in the signature.
                 */
                fld = sym_ptr->Object.Type->Tp_Schema.Tp_SchFieldList;
                for (; fld; fld=fld->Tp_SchField.Next) {
                    sym_ptr = DeclsIn;  
                    lastsym = NoSym;
                    Ident = fld->Tp_SchField.Ident;
                    /* check if the primed object is declared. */
                    str[0] = '\0';
                    GetString (Ident, str);
                    strcat (str, "'");
                    Ident = MakeIdent(str, strlen(str));
                    while (sym_ptr && sym_ptr->Kind != kNoObject) {

                        if ((sym_ptr = LookUp (sym_ptr, Ident, lastsym))
                            == NoSym) {
                            Error (elist->Name.Pos, error40);
                            break;
                        }
                        else {
                            if (sym_ptr->Kind == kObj_Id && 
                                sym_ptr->Obj_Id.QuId == fld->Tp_SchField.QuId)
                                break;

                            lastsym = sym_ptr;
                            sym_ptr = sym_ptr->Object.Pre;
                        }
                    }

                }
            }
        }
        else { /* with prefix */

            /* to get QuId */ 
            for (; idlist && idlist->Kind != kNoId; 
                idlist = idlist->Id.Next)
                if (idlist->Id.Next->Kind != kNoId &&
                    idlist->Id.Next->Id.Next->Kind == kNoId) {
                    /* to get the prefix */
                    save = idlist->Id.Next;
                    lastident = save->Id.Ident.Ident;
                    idlist->Id.Next = mNoId();
                    QuId = FormtIdent (elist->Name.IdList);
                    idlist->Id.Next = save;
                    break;
            }

            /* Must lookup primed ? */
             /* I dont know what to do here !!!!! */

            sym_ptr = LookUpName (DeclsIn, idlist, NoSym);

            if (sym_ptr && sym_ptr->Kind == kObj_Inn &&
                sym_ptr->Obj_Inn.ObjKind == Obj_schema) {
                /* it is a schema name. */

                fld = sym_ptr->Object.Type->Tp_Schema.Tp_SchFieldList;
                for (; fld; fld=fld->Tp_SchField.Next) {
                    sym_ptr = DeclsIn;  
                    lastsym = NoSym;
                    Ident = fld->Tp_SchField.Ident;
                    /* check if the primed object is declared. */
                    str[0] = '\0';
                    GetString (Ident, str);
                    strcat (str, "'");
                    Ident = MakeIdent(str, strlen(str));

                    while (sym_ptr && sym_ptr->Kind != kNoObject) 
                        if ((sym_ptr = LookUp (sym_ptr, Ident, lastsym))
                            == NoSym) {
                            Error (elist->Name.Pos, error40);
                            break;
                        }
                        else {
                            if (sym_ptr->Kind == kObj_Id && 
                                sym_ptr->Obj_Id.QuId == QuId)
                                break;

                            lastsym = sym_ptr;
                            sym_ptr = sym_ptr->Object.Pre;
                        }

                }
                break;  
            }
            /* it is an object name */  
            sym_ptr = DeclsIn;
            lastsym = NoSym;

            /* check if the primed one is declared. */
            str[0] = '\0';
            GetString (lastident, str);
            strcat (str, "'");
            lastident = MakeIdent (str, strlen(str));

            while (sym_ptr && sym_ptr->Kind != kNoObject) 
                if ((sym_ptr = LookUp (sym_ptr, lastident, lastsym)) == NoSym) {
                    Error (elist->Name.Pos, error13);
                    break;
                }
                else { 
                /* found it, and
                 * to check if the prefix is the same too.
                 */
                    if (sym_ptr->Kind == kObj_Id && 
                        sym_ptr->Obj_Id.QuId == QuId) 
                        break;

                    lastsym = sym_ptr;
                    sym_ptr = sym_ptr->Object.Pre;
                }

        }
    }
    return BoolTy;
}


/* checks changes only for the lhs of the assign { name, name, ..., name }
 * very much like changes_only but special treatment of x! and x?
 * as they need not have primed partners and x? cant appear on lhs
 *
 * name = id { .id }, is either an object or a schema.
 * If it is an object, check it is in the schema signature(scope). 
 * If it is a schema, unfold it to check each object is in the scope.
 * In the case of qualified name, prefix.id, check id is in the scope 
 * and has the same prefix(QuId).
 */
tType Tyof_AssChgOnly (DeclsIn, NameList)
    tObjects DeclsIn;
    tTree NameList;
{
    tTree elist=NameList;
    tTree idlist=NoTree;
    char str[IDENT_LENGTH];
    tIdent lastident=NoIdent, QuId=NoIdent, Ident=NoIdent;
    tObjects sym_ptr=DeclsIn, lastsym=NoSym;
    tTree save=NoTree;
    tType fld=NoType;
    int n;

    for (; elist && elist->Kind != kNoName; elist=elist->Name.Next) {

        idlist = elist->Name.IdList;

        /* no prefix */
        if (idlist && idlist->Id.Next->Kind == kNoId) { 

            if ((sym_ptr = LookUp (DeclsIn, idlist->Id.Ident.Ident, NoSym))
                == NoSym) 
                Error (elist->Name.Pos, error13);

            else if (sym_ptr->Kind == kObj_Inn && 
                sym_ptr->Obj_Inn.ObjKind == Obj_schema) {

                /* It is a schema, unfold it to check each unprimed 
                 * object in the signature.
                 */
                fld = sym_ptr->Object.Type->Tp_Schema.Tp_SchFieldList;
                for (; fld; fld=fld->Tp_SchField.Next) {
                    sym_ptr = DeclsIn;  
                    lastsym = NoSym;
                    Ident = fld->Tp_SchField.Ident;
                    while (sym_ptr && sym_ptr->Kind != kNoObject) 
                        if ((sym_ptr = LookUp (sym_ptr, Ident, lastsym))
                            == NoSym) {
                            Error (elist->Name.Pos, error40);
                            break;
                        }
                        else {
                            if (sym_ptr->Kind == kObj_Id && 
                                sym_ptr->Obj_Id.QuId == fld->Tp_SchField.QuId)
                                break;

                            lastsym = sym_ptr;
                            sym_ptr = sym_ptr->Object.Pre;
                        }

                    if (sym_ptr) {
                    /* check if the primed object is also declared. */
                        str[0] = '\0';
                        GetString (Ident, str);
                        strcat (str, "'");
                        Ident = MakeIdent(str, strlen(str));

                        sym_ptr = DeclsIn;  
                        lastsym = NoSym;
                        while (sym_ptr && sym_ptr->Kind != kNoObject) 
                            if ((sym_ptr = LookUp (sym_ptr, Ident, lastsym))
                                == NoSym) {
                                Error (elist->Name.Pos, error36);
                                break;
                            }
                            else {
                                if (sym_ptr->Kind == kObj_Id && 
                                    sym_ptr->Obj_Id.QuId == fld->Tp_SchField.QuId)
                                    break;

                                lastsym = sym_ptr;
                                sym_ptr = sym_ptr->Object.Pre;
                            }
                    }
                }
            }
            else {
            /* found it, but not a schema. Check if the corresponding primed 
             * one is also declared. 
             * if the identifier is an input variable then error, 
             * if it is an output variable then dont check prime.
             */
                str[0] = '\0';
                GetString (idlist->Id.Ident.Ident, str);
                n = strlen (str) - 1;
                if (str[n] == '?') 
                    Error(elist->Name.Pos, il_error4);
                else if (str[n] != '!') {
                    strcat (str, "'");
                    Ident = MakeIdent(str, strlen(str));
                    if (LookUp (DeclsIn, Ident, NoSym) == NoSym)
                        Error (elist->Name.Pos, error36);
                }
            }
        }
        else { /* with prefix */

            /* to get QuId */ 
            for (; idlist && idlist->Kind != kNoId; 
                idlist = idlist->Id.Next)
                if (idlist->Id.Next->Kind != kNoId &&
                    idlist->Id.Next->Id.Next->Kind == kNoId) {
                    /* to get the prefix */
                    save = idlist->Id.Next;
                    lastident = save->Id.Ident.Ident;
                    idlist->Id.Next = mNoId();
                    QuId = FormtIdent (elist->Name.IdList);
                    idlist->Id.Next = save;
                    break;
            }

            sym_ptr = LookUpName (DeclsIn, idlist, NoSym);
            if (sym_ptr && sym_ptr->Kind == kObj_Inn &&
                sym_ptr->Obj_Inn.ObjKind == Obj_schema) {
                /* it is a schema name. */

                fld = sym_ptr->Object.Type->Tp_Schema.Tp_SchFieldList;
                for (; fld; fld=fld->Tp_SchField.Next) {
                    sym_ptr = DeclsIn;  
                    lastsym = NoSym;
                    Ident = fld->Tp_SchField.Ident;
                    while (sym_ptr && sym_ptr->Kind != kNoObject) 
                        if ((sym_ptr = LookUp (sym_ptr, Ident, lastsym))
                            == NoSym) {
                            Error (elist->Name.Pos, error40);
                            break;
                        }
                        else {
                            if (sym_ptr->Kind == kObj_Id && 
                                sym_ptr->Obj_Id.QuId == QuId)
                                break;

                            lastsym = sym_ptr;
                            sym_ptr = sym_ptr->Object.Pre;
                        }

                    if (sym_ptr) {
                        /* check if the primed object is also declared. */
                        str[0] = '\0';
                        GetString (Ident, str);
                        strcat (str, "'");
                        Ident = MakeIdent(str, strlen(str));

                        sym_ptr = DeclsIn;  
                        lastsym = NoSym;
                        while (sym_ptr && sym_ptr->Kind != kNoObject) 
                            if ((sym_ptr = LookUp (sym_ptr, Ident, lastsym))
                                == NoSym) {
                                Error (elist->Name.Pos, error36);
                                break;
                            }
                            else {
                                if (sym_ptr->Kind == kObj_Id && 
                                    sym_ptr->Obj_Id.QuId == QuId)
                                    break;

                                lastsym = sym_ptr;
                                sym_ptr = sym_ptr->Object.Pre;
                            }
                    }
                }
                break;  
            }

            /* it is an object name */  
            sym_ptr = DeclsIn;
            lastsym = NoSym;
            while (sym_ptr && sym_ptr->Kind != kNoObject) 
                if ((sym_ptr = LookUp (sym_ptr, lastident, lastsym)) == NoSym) {
                    Error (elist->Name.Pos, error13);
                    break;
                }
                else { 
                /* found it, and
                 * to check if the prefix is the same too.
                 */
                    if (sym_ptr->Kind == kObj_Id && 
                        sym_ptr->Obj_Id.QuId == QuId) 
                        break;

                    lastsym = sym_ptr;
                    sym_ptr = sym_ptr->Object.Pre;
                }

            if (sym_ptr) {
            /* check if the primed one is also declared. */
                str[0] = '\0';
                GetString (lastident, str);
                strcat (str, "'");
                lastident = MakeIdent (str, strlen(str));

                sym_ptr = DeclsIn;
                lastsym = NoSym;
                while (sym_ptr && sym_ptr->Kind != kNoObject) 
                    if ((sym_ptr = LookUp (sym_ptr, lastident, lastsym)) == NoSym) {
                        Error (elist->Name.Pos, error36);
                        break;
                    }
                    else { 
                    /* found it, and
                     * to check if the prefix is the same too.
                     */
                        if (sym_ptr->Kind == kObj_Id && 
                            sym_ptr->Obj_Id.QuId == QuId) 
                            break;

                        lastsym = sym_ptr;
                        sym_ptr = sym_ptr->Object.Pre;
                    }
            }
        }
    }
    return BoolTy;
}

/* IfPred = { Type := Tyof_IfPred(DeclsIn, Con:Type, Then:Type, Else:Type); } .
WF should be like any other PredOp, eg LogBinPred, NOPE - not schema
*/

tType Tyof_IfPred(DeclsIn, Con, Then, Else)
    tObjects DeclsIn;
    tType Con, Then, Else;
{

}

/* WhilePred { Type := Tyof_WhilePred(DeclsIn, Con:Type, Do:Type); } .
*/

tType Tyof_WhilePred(DeclsIn, Con, Do)
    tObjects DeclsIn;
    tType Con, Do;
{
}


bool TypeStructEq(T1, T2)
    tType T1, T2;
{
    if (T1==NoType || T2==NoType)
        return false;
    if (T1->Kind == kTp_Err || T2->Kind == kTp_Err)
        return false;
    if (T1 == T2)
        return true;
    
    if (T1->Kind != T2->Kind)
        return false;
    
    switch (T1->Kind) {
        case kTp_Exp: 
            return (T1->Tp_Exp.Ident == T2->Tp_Exp.Ident);
        case kTp_Poly:  /* ?? a doubt */
            return (T1->Tp_Poly.Ident == T2->Tp_Poly.Ident);
        case kTp_Any:
            return true;
        case kTp_Base: 
            return (T1->Tp_Base.Ident == T2->Tp_Base.Ident);
        case kTp_Prefix:
            return (T1->Tp_Prefix.Ident == T2->Tp_Prefix.Ident) &&
                TypeStructEq (T1->Tp_Prefix.Tp_Exp, T2->Tp_Prefix.Tp_Exp);
        case kTp_Power:
            return (T1->Tp_Power.Ident == T2->Tp_Power.Ident) &&
                TypeStructEq (T1->Tp_Power.Tp_Exp, T2->Tp_Power.Tp_Exp);
        case kTp_Seq:
            return (T1->Tp_Seq.Ident == T2->Tp_Seq.Ident) &&
                TypeStructEq (T1->Tp_Seq.Tp_Exp, T2->Tp_Seq.Tp_Exp);
        case kTp_Infix: 
            return (T1->Tp_Infix.Ident == T2->Tp_Infix.Ident) &&
                TypeStructEq (T1->Tp_Infix.Fst, T2->Tp_Infix.Fst) &&
                    TypeStructEq (T1->Tp_Infix.Snd, T2->Tp_Infix.Snd);
        case kTp_CartProd:
        { tType cart1=NoType, cart2=NoType;
            cart1 = T1->Tp_CartProd.Tp_CartList;
            cart2 = T2->Tp_CartProd.Tp_CartList;
            for (; cart1 && cart2; cart1=cart1->Tp_Cart.Next, cart2=cart2->Tp_Cart.Next)
                if (!TypeStructEq(cart1->Tp_Cart.Tp_Exp, cart2->Tp_Cart.Tp_Exp))
                    return false;
            if (cart1 || cart2)
                return false;
            return true;
        }
        case kTp_Schema: /* ?? This needs to be modified. */
        { tType fld1=NoType, fld2=NoType;
            fld1 = T1->Tp_Schema.Tp_SchFieldList;
            fld2 = T2->Tp_Schema.Tp_SchFieldList;
            for (; fld1 && fld2; fld1=fld1->Tp_SchField.Next, fld2=fld2->Tp_SchField.Next) {
                if (fld1->Tp_SchField.Ident != fld2->Tp_SchField.Ident || 
                    fld1->Tp_SchField.QuId != fld2->Tp_SchField.QuId)
                    return false;
                if (!TypeStructEq(fld1->Tp_SchField.Tp_Exp, fld2->Tp_SchField.Tp_Exp))
                    return false;
            }
            if (fld1 || fld2)
                return false;
            return true;
        }
        default:
            InterErr(Ierror2);
            return false;
    }
}

tType ParentTy(Ty)
/* wj -- takes Tp_Seq, Tp_Prefix and Tp_Infix to base types */
    tType Ty;
{
    if (Ty==NoType)
        return Ty;
        
    switch (Ty->Kind) {

        case kTp_Exp:
            return Ty;
        case kTp_Poly:
            return Ty;
        case kTp_Err:
            return Ty;
        case kTp_Any:
            return Ty;
        case kTp_Base:
            return Ty;
        case kTp_Power:
            return Ty;
        case kTp_CartProd:
            return Ty;
        case kTp_Schema:
            return Ty;
        case kTp_Seq:
            return mTp_Power (NoIdent, Ident_power, mTp_CartProd (NoIdent, NoIdent, 
                mTp_Cart(mTp_Cart(NoType, Ty->Tp_Seq.Tp_Exp), IntTy))); 
            /*return mTp_Infix (Ident_fpartfunc, IntTy, Ty->Tp_Seq.Tp_Exp); */ 
        case kTp_Infix:
            return mTp_Power (NoIdent, Ident_power, mTp_CartProd (NoIdent, NoIdent, 
                mTp_Cart(mTp_Cart(NoType, Ty->Tp_Infix.Snd), Ty->Tp_Infix.Fst))); 
        case kTp_Prefix:
            if (Ty->Tp_Prefix.Ident == Ident_bag)
                return mTp_Power (NoIdent, Ident_power, mTp_CartProd (NoIdent, NoIdent, 
                    mTp_Cart(mTp_Cart(NoType, IntTy), Ty->Tp_Prefix.Tp_Exp))); 
                /* return mTp_Infix (NoIdent, Ident_partfunc, Ty->Tp_Prefix.Tp_Exp, IntTy); */
            else
                return Ty; /* ?? not handled */    
        default:
            InterErr(Ierror2);
            return Ty;
    }
}

/* Check if theta expression is applicable in the environment */

void CkThetaAIEnv(Exp)
    tTree Exp;
{
    tTree exp=Exp;
    tType Ty, fld;
    tObjects SymPtr;
    bool IsBinding, found=false;
    tTree idlist;
    tIdPos QuId, Ident;
    tIdent ModIdent, QuIdent; 
    char modstr[IDENT_LENGTH], qustr[IDENT_LENGTH];

    
        Ty = exp->Exp.Type;

        if (Ty && Ty->Kind == kTp_Schema) {

            fld = Ty->Tp_Schema.Tp_SchFieldList;
        /* check whether the signature of the schema is compatible 
         * with the env. 
         */
            for (; fld && fld->Kind != kTp_NoSchField; 
                fld=fld->Tp_SchField.Next) {
                Ident.Pos = exp->Exp.Pos;
                Ident.Ident = fld->Tp_SchField.Ident;
                QuId.Pos = exp->Exp.Pos;
                QuId.Ident = NoIdent;
                ModIdent = Ty->Tp_Schema.ModId;
                QuIdent = fld->Tp_SchField.QuId;
                found = false;
                if (!found && QuIdent != NoIdent && ModIdent != NoIdent) {
                    qustr[0] = '\0';
                    modstr[0] = '\0';
                    mygetstr(QuIdent, qustr);
                    mygetstr(ModIdent, modstr);
                    strcat (modstr, ".");
                    strcat (modstr, qustr);
                    QuId.Ident = MakeIdent (modstr, strlen(modstr));
                    idlist = mId(mId(mNoId(), Ident, ID), QuId, ID);
                    if (Compatible (Tyof_Variable(exp->Exp.DeclsIn,
                        idlist, &SymPtr, &IsBinding, 0),
                        fld->Tp_SchField.Tp_Exp)) 

                        found = true;
                }
                if (!found && ModIdent != NoIdent) {
                    QuId.Ident = ModIdent;
                    idlist = mId(mId(mNoId(), Ident, ID), QuId, ID);
                    if (Compatible (Tyof_Variable(exp->Exp.DeclsIn,
                        idlist, &SymPtr, &IsBinding, 0),
                        fld->Tp_SchField.Tp_Exp))
                        
                        found = true;
                }
                if (!found && QuIdent != NoIdent) {

                    QuId.Ident = QuIdent;
                    idlist = mId(mId(mNoId(), Ident, ID), QuId, ID);

                    if (Compatible (Tyof_Variable(exp->Exp.DeclsIn,
                        idlist, &SymPtr, &IsBinding, 0),
                        fld->Tp_SchField.Tp_Exp))
                        
                        found = true;
                }
                if (!found) {
                
                    idlist = mId(mNoId(), Ident, ID);
                    if (!Compatible (Tyof_Variable(exp->Exp.DeclsIn,
                        idlist, &SymPtr, &IsBinding, 0),
                        fld->Tp_SchField.Tp_Exp)) {

                        Error (exp->Exp.Pos, error39);
                        break;
                    }
                }


            }
        }
/******** error if the expression type is not a schema *********/
	else 
	   {Error (exp->Exp.Pos, error41);
	    ErrorInThetaName(Ty);}
}


/* Check if a schema reference being a predicate is applicable in the 
 * environment.
 */
void CkPredListAIEnv (PredList)
    tTree PredList;
{
    tTree predlist=PredList;
    tType Ty, fld;
    tObjects SymPtr;
    bool IsBinding, found=false;
    tTree idlist;
    tIdPos QuId, Ident;
    tIdent ModIdent, QuIdent; 
    char modstr[IDENT_LENGTH], qustr[IDENT_LENGTH];

    for (; predlist && predlist->Kind != kNoPred; 
        predlist=predlist->Pred.Next)  {

        Ty = predlist->Pred.Type;

        if (Ty && Ty->Kind == kTp_Schema) {

            fld = Ty->Tp_Schema.Tp_SchFieldList;
        /* check whether the signature of the schema is compatible 
         * with the env. 
         */
            for (; fld && fld->Kind != kTp_NoSchField; 
                fld=fld->Tp_SchField.Next) {

                Ident.Pos = predlist->Pred.Pos;
                Ident.Ident = fld->Tp_SchField.Ident;
                QuId.Pos = predlist->Pred.Pos;
                QuId.Ident = NoIdent;
                ModIdent = Ty->Tp_Schema.ModId;
                QuIdent = fld->Tp_SchField.QuId;
                found = false;
                if (!found && QuIdent != NoIdent && ModIdent != NoIdent) {
                    qustr[0] = '\0';
                    modstr[0] = '\0';
                    mygetstr(QuIdent, qustr);
                    mygetstr(ModIdent, modstr);
                    strcat (modstr, ".");
                    strcat (modstr, qustr);
                    QuId.Ident = MakeIdent (modstr, strlen(modstr));
                    idlist = mId(mId(mNoId(), Ident, ID), QuId, ID);
                    if (Compatible (Tyof_Variable(predlist->Pred.DeclsIn,
                        idlist, &SymPtr, &IsBinding, 0),
                        fld->Tp_SchField.Tp_Exp)) 

                        found = true;
                }
                if (!found && ModIdent != NoIdent) {
                    QuId.Ident = ModIdent;
                    idlist = mId(mId(mNoId(), Ident, ID), QuId, ID);
                    if (Compatible (Tyof_Variable(predlist->Pred.DeclsIn,
                        idlist, &SymPtr, &IsBinding, 0),
                        fld->Tp_SchField.Tp_Exp))
                        
                        found = true;
                }
                if (!found && QuIdent != NoIdent) {

                    QuId.Ident = QuIdent;
                    idlist = mId(mId(mNoId(), Ident, ID), QuId, ID);

                    if (Compatible (Tyof_Variable(predlist->Pred.DeclsIn,
                        idlist, &SymPtr, &IsBinding, 0),
                        fld->Tp_SchField.Tp_Exp))
                        
                        found = true;
                }
                if (!found) {
                
                    idlist = mId(mNoId(), Ident, ID);
                    if (!Compatible (Tyof_Variable(predlist->Pred.DeclsIn,
                        idlist, &SymPtr, &IsBinding, 0),
                        fld->Tp_SchField.Tp_Exp)) {

                        Error (predlist->Pred.Pos, error38);
                        break;
                    }
                }
            }
        }
    }
}





static void yyExit () { Exit (1); }

void (* Type_Exit) () = yyExit;

# define yyBlockSize 20480

typedef struct yysBlock {
 char yyBlock [yyBlockSize];
 struct yysBlock * yySuccessor;
} yytBlock, * yytBlockPtr;

tType TypeRoot;
unsigned long Type_HeapUsed = 0;

static yytBlockPtr yyBlockList	= (yytBlockPtr) NoType;
char * Type_PoolFreePtr	= (char *) NoType;
char * Type_PoolMaxPtr	= (char *) NoType;
static unsigned short yyMaxSize	= 0;
unsigned short Type_NodeSize [17 + 1] = { 0,
 sizeof (yTp_Exp),
 sizeof (yTp_Poly),
 sizeof (yTp_Err),
 sizeof (yTp_Any),
 sizeof (yTp_Base),
 sizeof (yTp_Power),
 sizeof (yTp_Seq),
 sizeof (yTp_Prefix),
 sizeof (yTp_Infix),
 sizeof (yTp_CartProd),
 sizeof (yTp_Schema),
 sizeof (yTp_SchFieldList),
 sizeof (yTp_NoSchField),
 sizeof (yTp_SchField),
 sizeof (yTp_CartList),
 sizeof (yTp_NoCart),
 sizeof (yTp_Cart),
};
char * Type_NodeName [17 + 1] = {
 "NoType",
 "Tp_Exp",
 "Tp_Poly",
 "Tp_Err",
 "Tp_Any",
 "Tp_Base",
 "Tp_Power",
 "Tp_Seq",
 "Tp_Prefix",
 "Tp_Infix",
 "Tp_CartProd",
 "Tp_Schema",
 "Tp_SchFieldList",
 "Tp_NoSchField",
 "Tp_SchField",
 "Tp_CartList",
 "Tp_NoCart",
 "Tp_Cart",
};
static Type_tKind yyTypeRange [17 + 1] = { 0,
 kTp_Schema,
 kTp_Poly,
 kTp_Err,
 kTp_Any,
 kTp_Base,
 kTp_Power,
 kTp_Seq,
 kTp_Prefix,
 kTp_Infix,
 kTp_CartProd,
 kTp_Schema,
 kTp_SchField,
 kTp_NoSchField,
 kTp_SchField,
 kTp_Cart,
 kTp_NoCart,
 kTp_Cart,
};

tType Type_Alloc ()
{
 register yytBlockPtr yyBlockPtr = yyBlockList;
 register int i;

 if (yyMaxSize == 0)
  for (i = 1; i <= 17; i ++) {
   Type_NodeSize [i] = (Type_NodeSize [i] + yyMaxAlign - 1) & yyAlignMasks [yyMaxAlign];
   yyMaxSize = Max (Type_NodeSize [i], yyMaxSize);
  }
 yyBlockList = (yytBlockPtr) Alloc (sizeof (yytBlock));
 yyBlockList->yySuccessor = yyBlockPtr;
 Type_PoolFreePtr = yyBlockList->yyBlock;
 Type_PoolMaxPtr = Type_PoolFreePtr + yyBlockSize - yyMaxSize + 1;
 Type_HeapUsed += yyBlockSize;
 return (tType) Type_PoolFreePtr;
}

tType MakeType
# if defined __STDC__ | defined __cplusplus
 (Type_tKind yyKind)
# else
 (yyKind) Type_tKind yyKind;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [yyKind])
 yyt->Kind = yyKind;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

bool Type_IsType
# if defined __STDC__ | defined __cplusplus
 (register tType yyt, register Type_tKind yyKind)
# else
 (yyt, yyKind) register tType yyt; register Type_tKind yyKind;
# endif
{
 return yyt != NoType && yyKind <= yyt->Kind && yyt->Kind <= yyTypeRange [yyKind];
}


tType mTp_Exp
# if defined __STDC__ | defined __cplusplus
(tIdent pModId, tIdent pIdent)
# else
(pModId, pIdent)
tIdent pModId;
tIdent pIdent;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_Exp])
 yyt->Kind = kTp_Exp;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_Exp.ModId = pModId;
 yyt->Tp_Exp.Ident = pIdent;
 beginint(yyt->Tp_Exp.TyNo)
 beginbool(yyt->Tp_Exp.IsTypeExp)
 begintType(yyt->Tp_Exp.PtrToCopy)
 return yyt;
}

tType mTp_Poly
# if defined __STDC__ | defined __cplusplus
(tIdent pModId, tIdent pIdent)
# else
(pModId, pIdent)
tIdent pModId;
tIdent pIdent;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_Poly])
 yyt->Kind = kTp_Poly;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_Poly.ModId = pModId;
 yyt->Tp_Poly.Ident = pIdent;
 beginint(yyt->Tp_Poly.TyNo)
 beginbool(yyt->Tp_Poly.IsTypeExp)
 begintType(yyt->Tp_Poly.PtrToCopy)
 return yyt;
}

tType mTp_Err
# if defined __STDC__ | defined __cplusplus
(tIdent pModId, tIdent pIdent)
# else
(pModId, pIdent)
tIdent pModId;
tIdent pIdent;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_Err])
 yyt->Kind = kTp_Err;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_Err.ModId = pModId;
 yyt->Tp_Err.Ident = pIdent;
 beginint(yyt->Tp_Err.TyNo)
 beginbool(yyt->Tp_Err.IsTypeExp)
 begintType(yyt->Tp_Err.PtrToCopy)
 return yyt;
}

tType mTp_Any
# if defined __STDC__ | defined __cplusplus
(tIdent pModId, tIdent pIdent)
# else
(pModId, pIdent)
tIdent pModId;
tIdent pIdent;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_Any])
 yyt->Kind = kTp_Any;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_Any.ModId = pModId;
 yyt->Tp_Any.Ident = pIdent;
 beginint(yyt->Tp_Any.TyNo)
 beginbool(yyt->Tp_Any.IsTypeExp)
 begintType(yyt->Tp_Any.PtrToCopy)
 return yyt;
}

tType mTp_Base
# if defined __STDC__ | defined __cplusplus
(tIdent pModId, tIdent pIdent)
# else
(pModId, pIdent)
tIdent pModId;
tIdent pIdent;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_Base])
 yyt->Kind = kTp_Base;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_Base.ModId = pModId;
 yyt->Tp_Base.Ident = pIdent;
 beginint(yyt->Tp_Base.TyNo)
 beginbool(yyt->Tp_Base.IsTypeExp)
 begintType(yyt->Tp_Base.PtrToCopy)
 return yyt;
}

tType mTp_Power
# if defined __STDC__ | defined __cplusplus
(tIdent pModId, tIdent pIdent, tType pTp_Exp)
# else
(pModId, pIdent, pTp_Exp)
tIdent pModId;
tIdent pIdent;
tType pTp_Exp;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_Power])
 yyt->Kind = kTp_Power;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_Power.ModId = pModId;
 yyt->Tp_Power.Ident = pIdent;
 beginint(yyt->Tp_Power.TyNo)
 beginbool(yyt->Tp_Power.IsTypeExp)
 begintType(yyt->Tp_Power.PtrToCopy)
 yyt->Tp_Power.Tp_Exp = pTp_Exp;
 return yyt;
}

tType mTp_Seq
# if defined __STDC__ | defined __cplusplus
(tIdent pModId, tIdent pIdent, tType pTp_Exp)
# else
(pModId, pIdent, pTp_Exp)
tIdent pModId;
tIdent pIdent;
tType pTp_Exp;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_Seq])
 yyt->Kind = kTp_Seq;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_Seq.ModId = pModId;
 yyt->Tp_Seq.Ident = pIdent;
 beginint(yyt->Tp_Seq.TyNo)
 beginbool(yyt->Tp_Seq.IsTypeExp)
 begintType(yyt->Tp_Seq.PtrToCopy)
 yyt->Tp_Seq.Tp_Exp = pTp_Exp;
 return yyt;
}

tType mTp_Prefix
# if defined __STDC__ | defined __cplusplus
(tIdent pModId, tIdent pIdent, tType pTp_Exp)
# else
(pModId, pIdent, pTp_Exp)
tIdent pModId;
tIdent pIdent;
tType pTp_Exp;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_Prefix])
 yyt->Kind = kTp_Prefix;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_Prefix.ModId = pModId;
 yyt->Tp_Prefix.Ident = pIdent;
 beginint(yyt->Tp_Prefix.TyNo)
 beginbool(yyt->Tp_Prefix.IsTypeExp)
 begintType(yyt->Tp_Prefix.PtrToCopy)
 yyt->Tp_Prefix.Tp_Exp = pTp_Exp;
 return yyt;
}

tType mTp_Infix
# if defined __STDC__ | defined __cplusplus
(tIdent pModId, tIdent pIdent, tType pFst, tType pSnd)
# else
(pModId, pIdent, pFst, pSnd)
tIdent pModId;
tIdent pIdent;
tType pFst;
tType pSnd;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_Infix])
 yyt->Kind = kTp_Infix;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_Infix.ModId = pModId;
 yyt->Tp_Infix.Ident = pIdent;
 beginint(yyt->Tp_Infix.TyNo)
 beginbool(yyt->Tp_Infix.IsTypeExp)
 begintType(yyt->Tp_Infix.PtrToCopy)
 yyt->Tp_Infix.Fst = pFst;
 yyt->Tp_Infix.Snd = pSnd;
 return yyt;
}

tType mTp_CartProd
# if defined __STDC__ | defined __cplusplus
(tIdent pModId, tIdent pIdent, tType pTp_CartList)
# else
(pModId, pIdent, pTp_CartList)
tIdent pModId;
tIdent pIdent;
tType pTp_CartList;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_CartProd])
 yyt->Kind = kTp_CartProd;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_CartProd.ModId = pModId;
 yyt->Tp_CartProd.Ident = pIdent;
 beginint(yyt->Tp_CartProd.TyNo)
 beginbool(yyt->Tp_CartProd.IsTypeExp)
 begintType(yyt->Tp_CartProd.PtrToCopy)
 yyt->Tp_CartProd.Tp_CartList = pTp_CartList;
 return yyt;
}

tType mTp_Schema
# if defined __STDC__ | defined __cplusplus
(tIdent pModId, tIdent pIdent, tType pTp_SchFieldList)
# else
(pModId, pIdent, pTp_SchFieldList)
tIdent pModId;
tIdent pIdent;
tType pTp_SchFieldList;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_Schema])
 yyt->Kind = kTp_Schema;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_Schema.ModId = pModId;
 yyt->Tp_Schema.Ident = pIdent;
 beginint(yyt->Tp_Schema.TyNo)
 beginbool(yyt->Tp_Schema.IsTypeExp)
 begintType(yyt->Tp_Schema.PtrToCopy)
 yyt->Tp_Schema.Tp_SchFieldList = pTp_SchFieldList;
 return yyt;
}

tType mTp_SchFieldList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_SchFieldList])
 yyt->Kind = kTp_SchFieldList;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tType mTp_NoSchField
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_NoSchField])
 yyt->Kind = kTp_NoSchField;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tType mTp_SchField
# if defined __STDC__ | defined __cplusplus
(tType pNext, tIdent pModId, tIdent pIdent, tType pTp_Exp, tIdent pQuId)
# else
(pNext, pModId, pIdent, pTp_Exp, pQuId)
tType pNext;
tIdent pModId;
tIdent pIdent;
tType pTp_Exp;
tIdent pQuId;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_SchField])
 yyt->Kind = kTp_SchField;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_SchField.Next = pNext;
 yyt->Tp_SchField.ModId = pModId;
 yyt->Tp_SchField.Ident = pIdent;
 yyt->Tp_SchField.Tp_Exp = pTp_Exp;
 yyt->Tp_SchField.QuId = pQuId;
 beginbool(yyt->Tp_SchField.Tag)
 return yyt;
}

tType mTp_CartList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_CartList])
 yyt->Kind = kTp_CartList;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tType mTp_NoCart
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_NoCart])
 yyt->Kind = kTp_NoCart;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tType mTp_Cart
# if defined __STDC__ | defined __cplusplus
(tType pNext, tType pTp_Exp)
# else
(pNext, pTp_Exp)
tType pNext;
tType pTp_Exp;
# endif
{
 register tType yyt;
 yyALLOC (yyt, Type_NodeSize [kTp_Cart])
 yyt->Kind = kTp_Cart;
 yyt->yyHead.yyMark = 0;
 yyt->Tp_Cart.Next = pNext;
 yyt->Tp_Cart.Tp_Exp = pTp_Exp;
 return yyt;
}

typedef tType * yyPtrtTree;

static FILE * yyf;

static void yyMark
# if defined __STDC__ | defined __cplusplus
 (register tType yyt)
# else
 (yyt) register tType yyt;
# endif
{
 for (;;) {
  if (yyt == NoType || ++ yyt->yyHead.yyMark > 1) return;

  switch (yyt->Kind) {
case kTp_Power:
yyt = yyt->Tp_Power.Tp_Exp; break;
case kTp_Seq:
yyt = yyt->Tp_Seq.Tp_Exp; break;
case kTp_Prefix:
yyt = yyt->Tp_Prefix.Tp_Exp; break;
case kTp_Infix:
yyMark (yyt->Tp_Infix.Fst);
yyt = yyt->Tp_Infix.Snd; break;
case kTp_CartProd:
yyt = yyt->Tp_CartProd.Tp_CartList; break;
case kTp_Schema:
yyt = yyt->Tp_Schema.Tp_SchFieldList; break;
case kTp_SchField:
yyMark (yyt->Tp_SchField.Next);
yyt = yyt->Tp_SchField.Tp_Exp; break;
case kTp_Cart:
yyMark (yyt->Tp_Cart.Next);
yyt = yyt->Tp_Cart.Tp_Exp; break;
  default: return;
  }
 }
}

# define yyInitTreeStoreSize 32
# define yyMapToTree(yyLabel) yyTreeStorePtr [yyLabel]

static unsigned long yyTreeStoreSize = yyInitTreeStoreSize;
static tType yyTreeStore [yyInitTreeStoreSize];
static tType * yyTreeStorePtr = yyTreeStore;
static int yyLabelCount;
static short yyRecursionLevel = 0;

static Type_tLabel yyMapToLabel
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyLabelCount; yyi ++) if (yyTreeStorePtr [yyi] == yyt) return yyi;
 if (++ yyLabelCount == yyTreeStoreSize)
  ExtendArray ((char * *) & yyTreeStorePtr, & yyTreeStoreSize, sizeof (tType));
 yyTreeStorePtr [yyLabelCount] = yyt;
 return yyLabelCount;
}

static void yyWriteType ();

static void yyWriteNl () { (void) putc ('\n', yyf); }

static void yyWriteSelector
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyi = 16 - strlen (yys);
 (void) fputs (yys, yyf);
 while (yyi -- > 0) (void) putc (' ', yyf);
 (void) fputs (" = ", yyf);
}

static void yyWriteHex
# if defined __STDC__ | defined __cplusplus
 (unsigned char * yyx, int yysize)
# else
 (yyx, yysize) unsigned char * yyx; int yysize;
# endif
{ register int yyi; for (yyi = 0; yyi < yysize; yyi ++) (void) fprintf (yyf, "%02x ", yyx [yyi]); }

static short yyIndentLevel;

void WriteType
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf, tType yyt)
# else
 (yyyf, yyt) FILE * yyyf; tType yyt;
# endif
{
 short yySaveLevel = yyIndentLevel;
 yyf = yyyf;
 if (yyRecursionLevel ++ == 0) yyLabelCount = 0;
 yyMark (yyt);
 yyIndentLevel = 0;
 yyWriteType (yyt);
 yyIndentLevel = yySaveLevel;
 yyRecursionLevel --;
}

static void yyIndentSelector
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyIndentLevel; yyi ++) (void) putc (' ', yyf);
 yyWriteSelector (yys);
}

static void yyIndentSelectorTree
# if defined __STDC__ | defined __cplusplus
 (char * yys, tType yyt)
# else
 (yys, yyt) char * yys; tType yyt;
# endif
{ yyIndentSelector (yys); writetType (yyt) }

static void yWriteTp_Exp
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_Exp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_Exp.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_Exp.Ident) yyWriteNl ();
 yyIndentSelector ("TyNo"); writeint (yyt->Tp_Exp.TyNo) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tp_Exp.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("PtrToCopy"); writetType (yyt->Tp_Exp.PtrToCopy) yyWriteNl ();
}

static void yWriteTp_Poly
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_Poly], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_Poly.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_Poly.Ident) yyWriteNl ();
 yyIndentSelector ("TyNo"); writeint (yyt->Tp_Poly.TyNo) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tp_Poly.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("PtrToCopy"); writetType (yyt->Tp_Poly.PtrToCopy) yyWriteNl ();
}

static void yWriteTp_Err
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_Err], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_Err.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_Err.Ident) yyWriteNl ();
 yyIndentSelector ("TyNo"); writeint (yyt->Tp_Err.TyNo) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tp_Err.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("PtrToCopy"); writetType (yyt->Tp_Err.PtrToCopy) yyWriteNl ();
}

static void yWriteTp_Any
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_Any], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_Any.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_Any.Ident) yyWriteNl ();
 yyIndentSelector ("TyNo"); writeint (yyt->Tp_Any.TyNo) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tp_Any.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("PtrToCopy"); writetType (yyt->Tp_Any.PtrToCopy) yyWriteNl ();
}

static void yWriteTp_Base
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_Base], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_Base.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_Base.Ident) yyWriteNl ();
 yyIndentSelector ("TyNo"); writeint (yyt->Tp_Base.TyNo) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tp_Base.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("PtrToCopy"); writetType (yyt->Tp_Base.PtrToCopy) yyWriteNl ();
}

static void yWriteTp_Power
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_Power], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_Power.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_Power.Ident) yyWriteNl ();
 yyIndentSelector ("TyNo"); writeint (yyt->Tp_Power.TyNo) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tp_Power.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("PtrToCopy"); writetType (yyt->Tp_Power.PtrToCopy) yyWriteNl ();
}

static void yWriteTp_Seq
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_Seq], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_Seq.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_Seq.Ident) yyWriteNl ();
 yyIndentSelector ("TyNo"); writeint (yyt->Tp_Seq.TyNo) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tp_Seq.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("PtrToCopy"); writetType (yyt->Tp_Seq.PtrToCopy) yyWriteNl ();
}

static void yWriteTp_Prefix
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_Prefix], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_Prefix.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_Prefix.Ident) yyWriteNl ();
 yyIndentSelector ("TyNo"); writeint (yyt->Tp_Prefix.TyNo) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tp_Prefix.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("PtrToCopy"); writetType (yyt->Tp_Prefix.PtrToCopy) yyWriteNl ();
}

static void yWriteTp_Infix
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_Infix], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_Infix.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_Infix.Ident) yyWriteNl ();
 yyIndentSelector ("TyNo"); writeint (yyt->Tp_Infix.TyNo) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tp_Infix.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("PtrToCopy"); writetType (yyt->Tp_Infix.PtrToCopy) yyWriteNl ();
 yyIndentSelectorTree ("Fst", yyt->Tp_Infix.Fst);
}

static void yWriteTp_CartProd
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_CartProd], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_CartProd.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_CartProd.Ident) yyWriteNl ();
 yyIndentSelector ("TyNo"); writeint (yyt->Tp_CartProd.TyNo) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tp_CartProd.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("PtrToCopy"); writetType (yyt->Tp_CartProd.PtrToCopy) yyWriteNl ();
}

static void yWriteTp_Schema
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_Schema], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_Schema.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_Schema.Ident) yyWriteNl ();
 yyIndentSelector ("TyNo"); writeint (yyt->Tp_Schema.TyNo) yyWriteNl ();
 yyIndentSelector ("IsTypeExp"); writebool (yyt->Tp_Schema.IsTypeExp) yyWriteNl ();
 yyIndentSelector ("PtrToCopy"); writetType (yyt->Tp_Schema.PtrToCopy) yyWriteNl ();
}

static void yWriteTp_SchField
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_SchField], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Next", yyt->Tp_SchField.Next);
 yyIndentSelector ("ModId"); writetIdent (yyt->Tp_SchField.ModId) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Tp_SchField.Ident) yyWriteNl ();
 yyIndentSelector ("QuId"); writetIdent (yyt->Tp_SchField.QuId) yyWriteNl ();
 yyIndentSelector ("Tag"); writebool (yyt->Tp_SchField.Tag) yyWriteNl ();
}

static void yWriteTp_Cart
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 (void) fputs (Type_NodeName [kTp_Cart], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Next", yyt->Tp_Cart.Next);
}

static void yyWriteType
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{ unsigned short yyLevel = yyIndentLevel;
 for (;;) {
  if (yyt == NoType) { (void) fputs (" NoType\n", yyf); goto yyExit;
  } else if (yyt->yyHead.yyMark == 0) { (void) fprintf (yyf, "^%d\n", yyMapToLabel (yyt)); goto yyExit;
  } else if (yyt->yyHead.yyMark > 1) {
   register int yyi;
   (void) fprintf (yyf, "\n%06d:", yyMapToLabel (yyt));
   for (yyi = 8; yyi <= yyIndentLevel; yyi ++) (void) putc (' ', yyf);
  } else (void) putc (' ', yyf);
  yyt->yyHead.yyMark = 0;
  yyIndentLevel += 2;

  switch (yyt->Kind) {
case kTp_Exp: yWriteTp_Exp (yyt); goto yyExit;
case kTp_Poly: yWriteTp_Poly (yyt); goto yyExit;
case kTp_Err: yWriteTp_Err (yyt); goto yyExit;
case kTp_Any: yWriteTp_Any (yyt); goto yyExit;
case kTp_Base: yWriteTp_Base (yyt); goto yyExit;
case kTp_Power: yWriteTp_Power (yyt); yyIndentSelector ("Tp_Exp"); yyt = yyt->Tp_Power.Tp_Exp; break;
case kTp_Seq: yWriteTp_Seq (yyt); yyIndentSelector ("Tp_Exp"); yyt = yyt->Tp_Seq.Tp_Exp; break;
case kTp_Prefix: yWriteTp_Prefix (yyt); yyIndentSelector ("Tp_Exp"); yyt = yyt->Tp_Prefix.Tp_Exp; break;
case kTp_Infix: yWriteTp_Infix (yyt); yyIndentSelector ("Snd"); yyt = yyt->Tp_Infix.Snd; break;
case kTp_CartProd: yWriteTp_CartProd (yyt); yyIndentSelector ("Tp_CartList"); yyt = yyt->Tp_CartProd.Tp_CartList; break;
case kTp_Schema: yWriteTp_Schema (yyt); yyIndentSelector ("Tp_SchFieldList"); yyt = yyt->Tp_Schema.Tp_SchFieldList; break;
case kTp_SchFieldList: (void) fputs (Type_NodeName [kTp_SchFieldList], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kTp_NoSchField: (void) fputs (Type_NodeName [kTp_NoSchField], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kTp_SchField: yWriteTp_SchField (yyt); yyIndentSelector ("Tp_Exp"); yyt = yyt->Tp_SchField.Tp_Exp; break;
case kTp_CartList: (void) fputs (Type_NodeName [kTp_CartList], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kTp_NoCart: (void) fputs (Type_NodeName [kTp_NoCart], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kTp_Cart: yWriteTp_Cart (yyt); yyIndentSelector ("Tp_Exp"); yyt = yyt->Tp_Cart.Tp_Exp; break;
  default: goto yyExit;
  }
 }
yyExit:
 yyIndentLevel = yyLevel;
}

# define yyNil	0374
# define yyNoLabel	0375
# define yyLabelDef	0376
# define yyLabelUse	0377

tType ReverseType
# if defined __STDC__ | defined __cplusplus
 (tType yyOld)
# else
 (yyOld) tType yyOld;
# endif
{
 register tType yyNew, yyNext, yyTail;
 yyNew = yyOld;
 yyTail = yyOld;
 for (;;) {
  switch (yyOld->Kind) {
  default: goto yyExit;
  }
  yyNew = yyOld;
  yyOld = yyNext;
 }
yyExit:
 switch (yyTail->Kind) {
 default: ;
 }
 return yyNew;
}

# define yyInitOldToNewStoreSize 32

typedef struct { tType yyOld, yyNew; } yytOldToNew;
static unsigned long yyOldToNewStoreSize = yyInitOldToNewStoreSize;
static yytOldToNew yyOldToNewStore [yyInitOldToNewStoreSize];
static yytOldToNew * yyOldToNewStorePtr = yyOldToNewStore;
static int yyOldToNewCount;

static void yyStoreOldToNew
# if defined __STDC__ | defined __cplusplus
 (tType yyOld, tType yyNew)
# else
 (yyOld, yyNew) tType yyOld, yyNew;
# endif
{
 if (++ yyOldToNewCount == yyOldToNewStoreSize)
  ExtendArray ((char * *) & yyOldToNewStorePtr, & yyOldToNewStoreSize, sizeof (yytOldToNew));
 yyOldToNewStorePtr [yyOldToNewCount].yyOld = yyOld;
 yyOldToNewStorePtr [yyOldToNewCount].yyNew = yyNew;
}

static tType yyMapOldToNew
# if defined __STDC__ | defined __cplusplus
 (tType yyOld)
# else
 (yyOld) tType yyOld;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyOldToNewCount; yyi ++)
  if (yyOldToNewStorePtr [yyi].yyOld == yyOld) return yyOldToNewStorePtr [yyi].yyNew;
}

static tType yyCopyType
# if defined __STDC__ | defined __cplusplus
 (tType yyt, yyPtrtTree yyNew)
# else
 (yyt, yyNew) tType yyt; yyPtrtTree yyNew;
# endif
{
 for (;;) {
  if (yyt == NoType) { * yyNew = NoType; return; }
  if (yyt->yyHead.yyMark == 0) { * yyNew = yyMapOldToNew (yyt); return; }
  yyALLOC (* yyNew, Type_NodeSize [yyt->Kind])
  if (yyt->yyHead.yyMark > 1) { yyStoreOldToNew (yyt, * yyNew); }
  yyt->yyHead.yyMark = 0;

  switch (yyt->Kind) {
case kTp_Exp: (* yyNew)->Tp_Exp = yyt->Tp_Exp;
copytIdent ((* yyNew)->Tp_Exp.ModId, yyt->Tp_Exp.ModId)
copytIdent ((* yyNew)->Tp_Exp.Ident, yyt->Tp_Exp.Ident)
copyint ((* yyNew)->Tp_Exp.TyNo, yyt->Tp_Exp.TyNo)
copybool ((* yyNew)->Tp_Exp.IsTypeExp, yyt->Tp_Exp.IsTypeExp)
copytType ((* yyNew)->Tp_Exp.PtrToCopy, yyt->Tp_Exp.PtrToCopy)
return;
case kTp_Poly: (* yyNew)->Tp_Poly = yyt->Tp_Poly;
copytIdent ((* yyNew)->Tp_Poly.ModId, yyt->Tp_Poly.ModId)
copytIdent ((* yyNew)->Tp_Poly.Ident, yyt->Tp_Poly.Ident)
copyint ((* yyNew)->Tp_Poly.TyNo, yyt->Tp_Poly.TyNo)
copybool ((* yyNew)->Tp_Poly.IsTypeExp, yyt->Tp_Poly.IsTypeExp)
copytType ((* yyNew)->Tp_Poly.PtrToCopy, yyt->Tp_Poly.PtrToCopy)
return;
case kTp_Err: (* yyNew)->Tp_Err = yyt->Tp_Err;
copytIdent ((* yyNew)->Tp_Err.ModId, yyt->Tp_Err.ModId)
copytIdent ((* yyNew)->Tp_Err.Ident, yyt->Tp_Err.Ident)
copyint ((* yyNew)->Tp_Err.TyNo, yyt->Tp_Err.TyNo)
copybool ((* yyNew)->Tp_Err.IsTypeExp, yyt->Tp_Err.IsTypeExp)
copytType ((* yyNew)->Tp_Err.PtrToCopy, yyt->Tp_Err.PtrToCopy)
return;
case kTp_Any: (* yyNew)->Tp_Any = yyt->Tp_Any;
copytIdent ((* yyNew)->Tp_Any.ModId, yyt->Tp_Any.ModId)
copytIdent ((* yyNew)->Tp_Any.Ident, yyt->Tp_Any.Ident)
copyint ((* yyNew)->Tp_Any.TyNo, yyt->Tp_Any.TyNo)
copybool ((* yyNew)->Tp_Any.IsTypeExp, yyt->Tp_Any.IsTypeExp)
copytType ((* yyNew)->Tp_Any.PtrToCopy, yyt->Tp_Any.PtrToCopy)
return;
case kTp_Base: (* yyNew)->Tp_Base = yyt->Tp_Base;
copytIdent ((* yyNew)->Tp_Base.ModId, yyt->Tp_Base.ModId)
copytIdent ((* yyNew)->Tp_Base.Ident, yyt->Tp_Base.Ident)
copyint ((* yyNew)->Tp_Base.TyNo, yyt->Tp_Base.TyNo)
copybool ((* yyNew)->Tp_Base.IsTypeExp, yyt->Tp_Base.IsTypeExp)
copytType ((* yyNew)->Tp_Base.PtrToCopy, yyt->Tp_Base.PtrToCopy)
return;
case kTp_Power: (* yyNew)->Tp_Power = yyt->Tp_Power;
copytIdent ((* yyNew)->Tp_Power.ModId, yyt->Tp_Power.ModId)
copytIdent ((* yyNew)->Tp_Power.Ident, yyt->Tp_Power.Ident)
copyint ((* yyNew)->Tp_Power.TyNo, yyt->Tp_Power.TyNo)
copybool ((* yyNew)->Tp_Power.IsTypeExp, yyt->Tp_Power.IsTypeExp)
copytType ((* yyNew)->Tp_Power.PtrToCopy, yyt->Tp_Power.PtrToCopy)
yyt = yyt->Tp_Power.Tp_Exp;
yyNew = & (* yyNew)->Tp_Power.Tp_Exp; break;
case kTp_Seq: (* yyNew)->Tp_Seq = yyt->Tp_Seq;
copytIdent ((* yyNew)->Tp_Seq.ModId, yyt->Tp_Seq.ModId)
copytIdent ((* yyNew)->Tp_Seq.Ident, yyt->Tp_Seq.Ident)
copyint ((* yyNew)->Tp_Seq.TyNo, yyt->Tp_Seq.TyNo)
copybool ((* yyNew)->Tp_Seq.IsTypeExp, yyt->Tp_Seq.IsTypeExp)
copytType ((* yyNew)->Tp_Seq.PtrToCopy, yyt->Tp_Seq.PtrToCopy)
yyt = yyt->Tp_Seq.Tp_Exp;
yyNew = & (* yyNew)->Tp_Seq.Tp_Exp; break;
case kTp_Prefix: (* yyNew)->Tp_Prefix = yyt->Tp_Prefix;
copytIdent ((* yyNew)->Tp_Prefix.ModId, yyt->Tp_Prefix.ModId)
copytIdent ((* yyNew)->Tp_Prefix.Ident, yyt->Tp_Prefix.Ident)
copyint ((* yyNew)->Tp_Prefix.TyNo, yyt->Tp_Prefix.TyNo)
copybool ((* yyNew)->Tp_Prefix.IsTypeExp, yyt->Tp_Prefix.IsTypeExp)
copytType ((* yyNew)->Tp_Prefix.PtrToCopy, yyt->Tp_Prefix.PtrToCopy)
yyt = yyt->Tp_Prefix.Tp_Exp;
yyNew = & (* yyNew)->Tp_Prefix.Tp_Exp; break;
case kTp_Infix: (* yyNew)->Tp_Infix = yyt->Tp_Infix;
copytIdent ((* yyNew)->Tp_Infix.ModId, yyt->Tp_Infix.ModId)
copytIdent ((* yyNew)->Tp_Infix.Ident, yyt->Tp_Infix.Ident)
copyint ((* yyNew)->Tp_Infix.TyNo, yyt->Tp_Infix.TyNo)
copybool ((* yyNew)->Tp_Infix.IsTypeExp, yyt->Tp_Infix.IsTypeExp)
copytType ((* yyNew)->Tp_Infix.PtrToCopy, yyt->Tp_Infix.PtrToCopy)
copytType ((* yyNew)->Tp_Infix.Fst, yyt->Tp_Infix.Fst)
yyt = yyt->Tp_Infix.Snd;
yyNew = & (* yyNew)->Tp_Infix.Snd; break;
case kTp_CartProd: (* yyNew)->Tp_CartProd = yyt->Tp_CartProd;
copytIdent ((* yyNew)->Tp_CartProd.ModId, yyt->Tp_CartProd.ModId)
copytIdent ((* yyNew)->Tp_CartProd.Ident, yyt->Tp_CartProd.Ident)
copyint ((* yyNew)->Tp_CartProd.TyNo, yyt->Tp_CartProd.TyNo)
copybool ((* yyNew)->Tp_CartProd.IsTypeExp, yyt->Tp_CartProd.IsTypeExp)
copytType ((* yyNew)->Tp_CartProd.PtrToCopy, yyt->Tp_CartProd.PtrToCopy)
yyt = yyt->Tp_CartProd.Tp_CartList;
yyNew = & (* yyNew)->Tp_CartProd.Tp_CartList; break;
case kTp_Schema: (* yyNew)->Tp_Schema = yyt->Tp_Schema;
copytIdent ((* yyNew)->Tp_Schema.ModId, yyt->Tp_Schema.ModId)
copytIdent ((* yyNew)->Tp_Schema.Ident, yyt->Tp_Schema.Ident)
copyint ((* yyNew)->Tp_Schema.TyNo, yyt->Tp_Schema.TyNo)
copybool ((* yyNew)->Tp_Schema.IsTypeExp, yyt->Tp_Schema.IsTypeExp)
copytType ((* yyNew)->Tp_Schema.PtrToCopy, yyt->Tp_Schema.PtrToCopy)
yyt = yyt->Tp_Schema.Tp_SchFieldList;
yyNew = & (* yyNew)->Tp_Schema.Tp_SchFieldList; break;
case kTp_SchFieldList: (* yyNew)->Tp_SchFieldList = yyt->Tp_SchFieldList;
return;
case kTp_NoSchField: (* yyNew)->Tp_NoSchField = yyt->Tp_NoSchField;
return;
case kTp_SchField: (* yyNew)->Tp_SchField = yyt->Tp_SchField;
copytType ((* yyNew)->Tp_SchField.Next, yyt->Tp_SchField.Next)
copytIdent ((* yyNew)->Tp_SchField.ModId, yyt->Tp_SchField.ModId)
copytIdent ((* yyNew)->Tp_SchField.Ident, yyt->Tp_SchField.Ident)
copytIdent ((* yyNew)->Tp_SchField.QuId, yyt->Tp_SchField.QuId)
copybool ((* yyNew)->Tp_SchField.Tag, yyt->Tp_SchField.Tag)
yyt = yyt->Tp_SchField.Tp_Exp;
yyNew = & (* yyNew)->Tp_SchField.Tp_Exp; break;
case kTp_CartList: (* yyNew)->Tp_CartList = yyt->Tp_CartList;
return;
case kTp_NoCart: (* yyNew)->Tp_NoCart = yyt->Tp_NoCart;
return;
case kTp_Cart: (* yyNew)->Tp_Cart = yyt->Tp_Cart;
copytType ((* yyNew)->Tp_Cart.Next, yyt->Tp_Cart.Next)
yyt = yyt->Tp_Cart.Tp_Exp;
yyNew = & (* yyNew)->Tp_Cart.Tp_Exp; break;
  default: ;
  }
 }
}

tType CopyType
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 tType yyNew;
 yyMark (yyt);
 yyOldToNewCount = 0;
 yyCopyType (yyt, & yyNew);
 return yyNew;
}

void BeginType ()
{
}

void CloseType ()
{
}
