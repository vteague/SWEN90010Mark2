# include "copymod.h"
# include "yycopymod.w"
# include "System.h"
# include <stdio.h>
# include "Syms.h"
# include "Type.h"
# include "Tree.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 9 "CopySyms.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
# include "Tree.h"
# include "Syms.h"
# include "Type.h"
# include "Scanner.h"
# include "global.h"

# include "Idents.h"
# include "Positions.h"
# include "ratc.h"
# include <string.h>
# include <stdio.h>
# include <stdarg.h>
# include <ctype.h>


/* list for keeping track of types allocated in a module */
/* - init by readmodule and write module */

struct ty_allo_str {
    tType ty_addr;
    struct ty_allo_str *next;
} *alloc_head=NULL, *alloc_tail=NULL; 

int TyNoCount=0;

        /* keep a list of the type structures being allocated so that we
           can set TyNo to zero later. do it now as memory has been allocated
           but recursive calls have not been made */

void AllocTp(type)
   tType type;

{
        if (!alloc_head) {
            alloc_head = (struct ty_allo_str *) 
                            my_malloc (sizeof (struct ty_allo_str));
            alloc_head->ty_addr = type;
            alloc_head->next = NULL;
            alloc_tail = alloc_head;
        }
        else {
            alloc_tail->next = (struct ty_allo_str *) 
                             my_malloc (sizeof (struct ty_allo_str));
            alloc_tail = alloc_tail->next;
            alloc_tail->ty_addr = type; 
            alloc_tail->next = NULL;
        }

}

tType FindType(TNo)
  int TNo;
{
struct ty_allo_str *allo_ptr=alloc_head;
tType rtnty=NoType;

        for (; allo_ptr; allo_ptr=allo_ptr->next)
            if ((allo_ptr->ty_addr)->Tp_Exp.TyNo == TNo) {
                rtnty = allo_ptr->ty_addr;
                break;
            }
        if (allo_ptr==NULL) {
            InterErr(Ierror3); 
            rtnty = ErrTy;
        }
        return rtnty;
}


static void yyExit () { Exit (1); }

void (* copymod_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module copymod, routine %s failed\n", yyFunction);
 copymod_Exit ();
}

static tType CopyTp ARGS((tType Type, tIdent ObjId, tIdent NewId));
static tObjects CopyObj ARGS((tObjects Mod, tIdent NewId, tObjects Pre));
tObjects InstMod ARGS((tObjects Mod, tIdent NewId));

static tType CopyTp
# if defined __STDC__ | defined __cplusplus
(register tType Type, tIdent ObjId, tIdent NewId)
# else
(Type, ObjId, NewId)
 register tType Type;
 tIdent ObjId;
 tIdent NewId;
# endif
{
/* line 89 "CopySyms.puma" */

       tType Tp=Type;
       char str[IDENT_LENGTH];
       char mstr[IDENT_LENGTH];

       str[0] = '\0';
       if (Type && Type->Kind == kTp_Exp) {
             GetString(Type->Tp_Exp.Ident, str);
             GetString(Type->Tp_Exp.ModId, mstr);
       }
      
  if (Type == NULL) {
/* line 103 "CopySyms.puma" */
   return NoType;

  }

  switch (Type->Kind) {
  case kTp_Poly:
/* line 106 "CopySyms.puma" */
  {
/* line 107 "CopySyms.puma" */

  if (Type->Tp_Poly.ModId == ObjId) {
    if (Type->Tp_Poly.TyNo == 0){
      Tp = (tType) mTp_Poly(NewId, Type->Tp_Poly.Ident);
      TyNoCount++;
      Tp->Tp_Poly.TyNo = TyNoCount;
      
      Type->Tp_Poly.TyNo = TyNoCount;
      AllocTp(Tp);
      AllocTp(Type);
    }
    else
      Tp = FindType(Type->Tp_Poly.TyNo);
  }

  }
   return Tp;

  case kTp_Err:
/* line 123 "CopySyms.puma" */
  {
/* line 124 "CopySyms.puma" */

if (Type->Tp_Err.ModId == ObjId){
    if (Type->Tp_Err.TyNo == 0){
      Tp = (tType) mTp_Err(NewId, Type->Tp_Err.Ident); 
      TyNoCount++;
      Tp->Tp_Err.TyNo = TyNoCount;
      Type->Tp_Err.TyNo = TyNoCount;
      AllocTp(Tp);
      AllocTp(Type);
    }
    else
      Tp = FindType(Type->Tp_Err.TyNo);
  }

  }
   return Tp;

  case kTp_Any:
/* line 139 "CopySyms.puma" */
  {
/* line 140 "CopySyms.puma" */

if (Type->Tp_Any.ModId == ObjId){
    if (Type->Tp_Any.TyNo == 0){
      Tp = (tType) mTp_Any(NewId, Type->Tp_Any.Ident);
      TyNoCount++;
      Tp->Tp_Any.TyNo = TyNoCount;
      Type->Tp_Any.TyNo = TyNoCount;
      AllocTp(Tp);
      AllocTp(Type);
    }
    else
      Tp = FindType(Type->Tp_Any.TyNo);
  }

  }
   return Tp;

  case kTp_Base:
/* line 155 "CopySyms.puma" */
  {
/* line 156 "CopySyms.puma" */

if (Type->Tp_Base.ModId == ObjId){
    if (Type->Tp_Base.TyNo == 0){
      Tp = (tType) mTp_Base(NewId, Type->Tp_Base.Ident); 
      TyNoCount++;
      Tp->Tp_Base.TyNo = TyNoCount;
      
      Type->Tp_Base.TyNo = TyNoCount;
      AllocTp(Tp);
      AllocTp(Type);
    }
    else
      Tp = FindType(Type->Tp_Base.TyNo);
  }

  }
   return Tp;

  case kTp_Power:
/* line 172 "CopySyms.puma" */
  {
/* line 173 "CopySyms.puma" */

    if (Type->Tp_Power.TyNo == 0){
      Tp = (tType) mTp_Power(NewId, Type->Tp_Power.Ident, CopyTp(Type->Tp_Power.Tp_Exp, ObjId, NewId));
      TyNoCount++;
      Tp->Tp_Power.TyNo = TyNoCount;
      Type->Tp_Power.TyNo = TyNoCount;
      AllocTp(Tp);
      AllocTp(Type);
    }
    else
      Tp = FindType(Type->Tp_Power.TyNo);

  }
   return Tp;

  case kTp_Seq:
/* line 186 "CopySyms.puma" */
  {
/* line 187 "CopySyms.puma" */

    if (Type->Tp_Seq.TyNo == 0){
      Tp = (tType) mTp_Seq(NewId, Type->Tp_Seq.Ident, CopyTp(Type->Tp_Seq.Tp_Exp, ObjId, NewId));
      TyNoCount++;
      Tp->Tp_Seq.TyNo = TyNoCount;
      Type->Tp_Seq.TyNo = TyNoCount;
      AllocTp(Tp);
      AllocTp(Type);
    }
    else
      Tp = FindType(Type->Tp_Seq.TyNo);

  }
   return Tp;

  case kTp_Prefix:
/* line 200 "CopySyms.puma" */
  {
/* line 201 "CopySyms.puma" */

    if (Type->Tp_Prefix.TyNo == 0){
      Tp = (tType) mTp_Prefix(NewId, Type->Tp_Prefix.Ident, CopyTp(Type->Tp_Prefix.Tp_Exp, ObjId, NewId));
      TyNoCount++;
      Tp->Tp_Prefix.TyNo = TyNoCount;
      Type->Tp_Prefix.TyNo = TyNoCount;
      AllocTp(Tp);
      AllocTp(Type);
    }
    else
      Tp = FindType(Type->Tp_Prefix.TyNo);


  }
   return Tp;

  case kTp_Infix:
/* line 215 "CopySyms.puma" */
  {
/* line 216 "CopySyms.puma" */

  
    if (Type->Tp_Infix.TyNo == 0){
      Tp = (tType) mTp_Infix(NewId, Type->Tp_Infix.Ident, CopyTp(Type->Tp_Infix.Fst, ObjId, NewId), CopyTp(Type->Tp_Infix.Snd, ObjId, NewId));
      TyNoCount++;
      Tp->Tp_Infix.TyNo = TyNoCount;
      Type->Tp_Infix.TyNo = TyNoCount;
      AllocTp(Tp);
      AllocTp(Type);
    }
    else
      Tp = FindType(Type->Tp_Infix.TyNo);

  }
   return Tp;

  case kTp_CartProd:
/* line 230 "CopySyms.puma" */
  {
/* line 231 "CopySyms.puma" */

    if (Type->Tp_CartProd.TyNo == 0){
      Tp = (tType) mTp_CartProd(NewId, Type->Tp_CartProd.Ident, CopyTp(Type->Tp_CartProd.Tp_CartList, ObjId, NewId));
      TyNoCount++;
      Tp->Tp_CartProd.TyNo = TyNoCount;
      Type->Tp_CartProd.TyNo = TyNoCount;
      AllocTp(Tp);
      AllocTp(Type);
    }
    else
      Tp = FindType(Type->Tp_CartProd.TyNo);

  }
   return Tp;

  case kTp_Schema:
/* line 244 "CopySyms.puma" */
  {
/* line 245 "CopySyms.puma" */

if (Type->Tp_Schema.ModId == ObjId){
    if (Type->Tp_Schema.TyNo == 0){
      Tp = (tType) mTp_Schema(NewId, Type->Tp_Schema.Ident, CopyTp(Type->Tp_Schema.Tp_SchFieldList, ObjId, NewId));
      
      TyNoCount++;
      Tp->Tp_Schema.TyNo = TyNoCount;
      Type->Tp_Schema.TyNo = TyNoCount;
      AllocTp(Tp);
      AllocTp(Type);
    }
    else
      Tp = FindType(Type->Tp_Schema.TyNo);
  }

  }
   return Tp;

  case kTp_NoCart:
/* line 261 "CopySyms.puma" */
   return mTp_NoCart ();

  case kTp_Cart:
/* line 263 "CopySyms.puma" */
  {
/* line 264 "CopySyms.puma" */

Tp = mTp_Cart(CopyTp(Type->Tp_Cart.Next, ObjId, NewId), CopyTp(Type->Tp_Cart.Tp_Exp, ObjId, NewId));

  }
   return Tp;

  case kTp_NoSchField:
/* line 268 "CopySyms.puma" */
   return mTp_NoSchField ();

  case kTp_SchField:
/* line 274 "CopySyms.puma" */
  {
/* line 275 "CopySyms.puma" */

if (Type->Tp_SchField.ModId == ObjId)
 Tp =mTp_SchField(CopyTp(Type->Tp_SchField.Next, ObjId, NewId),NewId,Type->Tp_SchField.Ident,CopyTp(Type->Tp_SchField.Tp_Exp, ObjId, NewId),Type->Tp_SchField.QuId);

  }
   return Tp;

  case kTp_Exp:
/* line 280 "CopySyms.puma" */
  {
/* line 281 "CopySyms.puma" */

if (Type->Tp_Exp.ModId == ObjId){
    if (Type->Tp_Exp.TyNo == 0){
      if (Type->Tp_Exp.PtrToCopy) {
         if (Type->Tp_Exp.PtrToCopy->Tp_Exp.TyNo == 0) {
            TyNoCount++;
            Type->Tp_Exp.PtrToCopy->Tp_Exp.TyNo = TyNoCount;
            AllocTp(Type->Tp_Exp.PtrToCopy);
            Type->Tp_Exp.TyNo = TyNoCount;
            AllocTp(Type);
            Tp = Type->Tp_Exp.PtrToCopy;
         }
         else Tp = FindType(Type->Tp_Exp.PtrToCopy->Tp_Exp.TyNo);
      } 
      else {
       Tp = (tType) my_malloc (sizeof (yTp_Exp));
       Tp->Tp_Exp.ModId = NewId;
       Tp->Tp_Exp.Ident = Type->Tp_Exp.Ident;
       Tp->Kind = kTp_Exp;
       TyNoCount++;
       Tp->Tp_Exp.TyNo = TyNoCount;
       Type->Tp_Exp.TyNo = TyNoCount;
       AllocTp(Tp);
       AllocTp(Type);
      }
    }
    else
      Tp = FindType(Type->Tp_Exp.TyNo);
  }

  }
   return Tp;

  }

 yyAbort ("CopyTp");
}

static tObjects CopyObj
# if defined __STDC__ | defined __cplusplus
(tObjects Mod, tIdent NewId, tObjects Pre)
# else
(Mod, NewId, Pre)
 tObjects Mod;
 tIdent NewId;
 tObjects Pre;
# endif
{
/* line 315 "CopySyms.puma" */
tObjects Obj, sym; 
       tType type; 
       char str[IDENT_LENGTH];

       str[0] = '\0';
       if (Mod && Mod->Kind != kNoObject) GetString(Mod->Object.Ident, str);
      
  if (Mod == NULL) {
/* line 323 "CopySyms.puma" */
   return mNoObject ();

  }
  if (Mod->Kind == kNoObject) {
/* line 325 "CopySyms.puma" */
   return mNoObject ();

  }
  if (Mod->Kind == kObj_Inn) {
/* line 329 "CopySyms.puma" */
  {
/* line 331 "CopySyms.puma" */

tObjects inner;
type = CopyTp(Mod->Obj_Inn.Type, Mod->Obj_Inn.ModId, NewId); 
Obj = mObj_Inn(NoSym, Pre, NewId, type, Mod->Obj_Inn.Ident, Mod->Obj_Inn.IsSelected, NoSym, Mod->Obj_Inn.ObjKind,Mod->Obj_Inn.Visible);
inner = CopyObj(Mod->Obj_Inn.Inner, NewId, Obj);
sym = CopyObj(Mod->Obj_Inn.Next, NewId, Obj); 
Obj->Object.Next = sym;
Obj->Obj_Inn.Inner = inner;
Obj->Obj_Inn.ImportHasAsPart = Mod->Obj_Inn.ImportHasAsPart;

  }
   return Obj;

  }
  if (Mod->Kind == kObj_Id) {
/* line 343 "CopySyms.puma" */
  {
/* line 344 "CopySyms.puma" */
 
type = CopyTp(Mod->Obj_Id.Type, Mod->Obj_Id.ModId, NewId); 
Obj = mObj_Id(NoSym, Pre, NewId, type, Mod->Obj_Id.Ident, Mod->Obj_Id.IsSelected, Mod->Obj_Id.QuId, Mod->Obj_Id.VarKind);
sym = CopyObj(Mod->Obj_Id.Next, NewId, Obj); 
Obj->Object.Next = sym;

  }
   return Obj;

  }
  if (Mod->Kind == kObj_TyId) {
/* line 351 "CopySyms.puma" */
  {
/* line 352 "CopySyms.puma" */

type = CopyTp(Mod->Obj_TyId.Type, Mod->Obj_TyId.ModId, NewId); 
Obj = mObj_TyId(NoSym, Pre, NewId, type,  Mod->Obj_TyId.Ident, Mod->Obj_TyId.IsSelected); 
sym = CopyObj(Mod->Obj_TyId.Next, NewId, Obj);
Obj->Object.Next = sym;

  }
   return Obj;

  }
  if (Mod->Kind == kObj_PTyId) {
/* line 359 "CopySyms.puma" */
  {
/* line 360 "CopySyms.puma" */

type = CopyTp(Mod->Obj_PTyId.Type, Mod->Obj_PTyId.ModId, NewId);
Obj = mObj_PTyId(NoSym, Pre, NewId, type,  Mod->Obj_PTyId.Ident, Mod->Obj_PTyId.IsSelected); 
sym = CopyObj(Mod->Obj_PTyId.Next, NewId, Obj);
Obj->Object.Next = sym; 

  }
   return Obj;

  }
  if (Mod->Kind == kObj_PId) {
/* line 367 "CopySyms.puma" */
  {
/* line 368 "CopySyms.puma" */

type = CopyTp(Mod->Obj_PId.Type, Mod->Obj_PId.ModId, NewId);
Obj = mObj_PId(NoSym, Pre, NewId, type,  Mod->Obj_PId.Ident, Mod->Obj_PId.IsSelected); 
sym = CopyObj(Mod->Obj_PId.Next, NewId, Obj);
Obj->Object.Next = sym; 

  }
   return Obj;

  }
 yyAbort ("CopyObj");
}

tObjects InstMod
# if defined __STDC__ | defined __cplusplus
(tObjects Mod, tIdent NewId)
# else
(Mod, NewId)
 tObjects Mod;
 tIdent NewId;
# endif
{
/* line 376 "CopySyms.puma" */
tObjects Obj;
       struct ty_allo_str *allo_ptr;
      
/* line 380 "CopySyms.puma" */
  {
/* line 381 "CopySyms.puma" */
   
    TyNoCount = 0;
    alloc_head = NULL;
    alloc_tail = NULL;

    Obj = CopyObj(Mod, NewId, NoSym);

    for (allo_ptr=alloc_head; allo_ptr; allo_ptr=allo_ptr->next)
          allo_ptr->ty_addr->Tp_Exp.TyNo = 0; 
 

  }
   return Obj;

}

void Begincopymod ()
{
}

void Closecopymod ()
{
}
