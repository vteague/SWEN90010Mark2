# ifndef yySymAccess
# define yySymAccess

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "Tree.h"
# include "Syms.h"
# include "Type.h"

/* line 16 "objects.puma" */

#include "Idents.h"
#include "Syms.h"
#include <string.h>
#include "Type.h"
#include "global.h"
#include "Positions.h"
#include "ratc.h"
#include <fcntl.h>
#include "TypeAccess.h"

/* the structure for storing formal and actual parameters */
struct FArec {
    tType fty;
    tType aty;
    struct FArec *next;
};

typedef struct FArec * FAList;



extern void (* SymAccess_Exit) ();

extern void SetLocalGenParameters ARGS((tSyms decs));
extern void ResetLocalGenParamPtr ARGS(());
extern bool IsLocalGeneric ARGS((tType ty));
extern bool PredIsBool ARGS((tTree yyP4));
extern tObjects InitSymTab ARGS((tTree yyP1));
extern tIdent FormtIdent ARGS((tTree idlist));
extern tType SubsTy ARGS((tType ty, FAList fahead));
extern tObjects SchemaInclH ARGS((tSyms declsin, tTree idlist, tTree actparams, tIdent * modidptr));
extern bool ParamComp ARGS((tSyms f, tTree a));
extern FAList SchFACom ARGS((tSyms yyP10, tTree a));
extern void SetModGenParameters ARGS((tSyms decs));
extern void ResetModGenParameters ARGS(());
extern FAList SchFAComInner ARGS((tSyms yyP9, tTree a));
extern tPosition NonBoolPredPos ARGS((tTree yyP11));

extern void BeginSymAccess ();
extern void CloseSymAccess ();

# endif
