# ifndef yyType
# define yyType

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif


# ifndef bool
# define bool char
# endif
# define NoType (tType) 0L
# define kTp_Exp 1
# define kTp_Poly 2
# define kTp_Err 3
# define kTp_Any 4
# define kTp_Base 5
# define kTp_Power 6
# define kTp_Seq 7
# define kTp_Prefix 8
# define kTp_Infix 9
# define kTp_CartProd 10
# define kTp_Schema 11
# define kTp_SchFieldList 12
# define kTp_NoSchField 13
# define kTp_SchField 14
# define kTp_CartList 15
# define kTp_NoCart 16
# define kTp_Cart 17

typedef unsigned char Type_tKind;
typedef unsigned short Type_tMark;
typedef unsigned short Type_tLabel;
typedef union Type_Node * tType;
typedef void (* Type_tProcTree) ();
/* line 12 "Type.cg" */

#include "Idents.h"
#include "Errors.h"
#include "Positions.h"
#include "ratc.h"
#include "global.h"
#include "Syms.h"
#include "SumErrors.h"

extern tType Tyof_Variable();
extern tType Tyof_Literal ();
extern tType Tyof_PrefixExp();
extern tType TupSelectType ();
extern tType Tyof_SchemaBind();
extern int   Compatible();
extern tType CommType();
extern tType Tyof_Lambda();
extern tType Tyof_RecDisp();
extern tType Tyof_SetComp();
extern tType Tyof_Mu();
extern tType TupSelectType();
extern tType Tyof_IfExp();
extern tType Tyof_FncApp();
extern tType Tyof_ArrayUpd ();
extern tType Tyof_SetElab();
extern tType Tyof_Seq();
extern tType Tyof_Bag();
extern tType Tyof_CartProd();
extern tType Tyof_Tuple();
extern tType Tyof_InfixExp();
extern tType Tyof_RelBinPred();
extern tType Tyof_QuantPred();
extern tType Tyof_Assign();       /* il lpw 17/9/96 */
extern tType Tyof_RelPrePred();
extern tType FormTp_Schema();
extern tType FormTp_SchemaD();
extern tType Tyof_Exp_SchemaRef();
extern void  PrintTy();
extern tType Tyof_SchSubst();
extern tType Tyof_SchHiding();
extern tType Tyof_SchCompos();
extern tType Tyof_SchProj();
extern tType Tyof_LogBinPred();
extern bool  SchCompatible();
extern tType SchCombine();
extern tType Tyof_ChgOnly();
extern tType Tyof_InitAssChgOnly();
extern tType Tyof_AssChgOnly();
extern bool  TypeStructEq();
extern bool  InstByUse();
extern tType MkRngTy();
extern tType FormSchComb();
extern tType Tyof_PreCondPred();
extern tType CpSchType();
extern tType CpSchTypeD();
extern tType ParentTy();
extern bool  Functional();
extern bool IsLocalGeneric();
extern void SetLocalGens();

extern void  CkThetaAIEnv();

extern void  CkPredListAIEnv();


# ifndef Type_NodeHead
# define Type_NodeHead
# endif
typedef struct { Type_tKind yyKind; Type_tMark yyMark; Type_NodeHead } Type_tNodeHead;
typedef struct { Type_tNodeHead yyHead; tIdent ModId; tIdent Ident; int TyNo; bool IsTypeExp; tType PtrToCopy; } yTp_Exp;
typedef struct { Type_tNodeHead yyHead; tIdent ModId; tIdent Ident; int TyNo; bool IsTypeExp; tType PtrToCopy; } yTp_Poly;
typedef struct { Type_tNodeHead yyHead; tIdent ModId; tIdent Ident; int TyNo; bool IsTypeExp; tType PtrToCopy; } yTp_Err;
typedef struct { Type_tNodeHead yyHead; tIdent ModId; tIdent Ident; int TyNo; bool IsTypeExp; tType PtrToCopy; } yTp_Any;
typedef struct { Type_tNodeHead yyHead; tIdent ModId; tIdent Ident; int TyNo; bool IsTypeExp; tType PtrToCopy; } yTp_Base;
typedef struct { Type_tNodeHead yyHead; tIdent ModId; tIdent Ident; int TyNo; bool IsTypeExp; tType PtrToCopy; tType Tp_Exp; } yTp_Power;
typedef struct { Type_tNodeHead yyHead; tIdent ModId; tIdent Ident; int TyNo; bool IsTypeExp; tType PtrToCopy; tType Tp_Exp; } yTp_Seq;
typedef struct { Type_tNodeHead yyHead; tIdent ModId; tIdent Ident; int TyNo; bool IsTypeExp; tType PtrToCopy; tType Tp_Exp; } yTp_Prefix;
typedef struct { Type_tNodeHead yyHead; tIdent ModId; tIdent Ident; int TyNo; bool IsTypeExp; tType PtrToCopy; tType Fst; tType Snd; } yTp_Infix;
typedef struct { Type_tNodeHead yyHead; tIdent ModId; tIdent Ident; int TyNo; bool IsTypeExp; tType PtrToCopy; tType Tp_CartList; } yTp_CartProd;
typedef struct { Type_tNodeHead yyHead; tIdent ModId; tIdent Ident; int TyNo; bool IsTypeExp; tType PtrToCopy; tType Tp_SchFieldList; } yTp_Schema;
typedef struct { Type_tNodeHead yyHead; } yTp_SchFieldList;
typedef struct { Type_tNodeHead yyHead; } yTp_NoSchField;
typedef struct { Type_tNodeHead yyHead; tType Next; tIdent ModId; tIdent Ident; tType Tp_Exp; tIdent QuId; bool Tag; } yTp_SchField;
typedef struct { Type_tNodeHead yyHead; } yTp_CartList;
typedef struct { Type_tNodeHead yyHead; } yTp_NoCart;
typedef struct { Type_tNodeHead yyHead; tType Next; tType Tp_Exp; } yTp_Cart;

union Type_Node {
 Type_tKind Kind;
 Type_tNodeHead yyHead;
 yTp_Exp Tp_Exp;
 yTp_Poly Tp_Poly;
 yTp_Err Tp_Err;
 yTp_Any Tp_Any;
 yTp_Base Tp_Base;
 yTp_Power Tp_Power;
 yTp_Seq Tp_Seq;
 yTp_Prefix Tp_Prefix;
 yTp_Infix Tp_Infix;
 yTp_CartProd Tp_CartProd;
 yTp_Schema Tp_Schema;
 yTp_SchFieldList Tp_SchFieldList;
 yTp_NoSchField Tp_NoSchField;
 yTp_SchField Tp_SchField;
 yTp_CartList Tp_CartList;
 yTp_NoCart Tp_NoCart;
 yTp_Cart Tp_Cart;
};

extern tType TypeRoot;
extern unsigned long Type_HeapUsed;
extern char * Type_PoolFreePtr, * Type_PoolMaxPtr;
extern unsigned short Type_NodeSize [17 + 1];
extern char * Type_NodeName [17 + 1];

extern void (* Type_Exit) ();
extern tType Type_Alloc ();
extern tType MakeType ARGS((Type_tKind yyKind));
extern bool Type_IsType ARGS((register tType yyt, register Type_tKind yyKind));

extern tType mTp_Exp ARGS((tIdent pModId, tIdent pIdent));
extern tType mTp_Poly ARGS((tIdent pModId, tIdent pIdent));
extern tType mTp_Err ARGS((tIdent pModId, tIdent pIdent));
extern tType mTp_Any ARGS((tIdent pModId, tIdent pIdent));
extern tType mTp_Base ARGS((tIdent pModId, tIdent pIdent));
extern tType mTp_Power ARGS((tIdent pModId, tIdent pIdent, tType pTp_Exp));
extern tType mTp_Seq ARGS((tIdent pModId, tIdent pIdent, tType pTp_Exp));
extern tType mTp_Prefix ARGS((tIdent pModId, tIdent pIdent, tType pTp_Exp));
extern tType mTp_Infix ARGS((tIdent pModId, tIdent pIdent, tType pFst, tType pSnd));
extern tType mTp_CartProd ARGS((tIdent pModId, tIdent pIdent, tType pTp_CartList));
extern tType mTp_Schema ARGS((tIdent pModId, tIdent pIdent, tType pTp_SchFieldList));
extern tType mTp_SchFieldList ARGS(());
extern tType mTp_NoSchField ARGS(());
extern tType mTp_SchField ARGS((tType pNext, tIdent pModId, tIdent pIdent, tType pTp_Exp, tIdent pQuId));
extern tType mTp_CartList ARGS(());
extern tType mTp_NoCart ARGS(());
extern tType mTp_Cart ARGS((tType pNext, tType pTp_Exp));

extern void WriteType ARGS((FILE * yyyf, tType yyt));
extern tType ReverseType ARGS((tType yyOld));
extern tType CopyType ARGS((tType yyt));
extern void BeginType ();
extern void CloseType ();

# endif
