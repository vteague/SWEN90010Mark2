# ifndef yyZSumAccess
# define yyZSumAccess

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "ZTree.h"
# include "Tree.h"
# include "ZSyms.h"

/* line 11 "zsum.puma" */

#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "env.h"
#include "SumTreeAccess.h"
#include "ZTreeAccess.h"
#include "ZSymTabAccess.h"


extern void (* ZSumAccess_Exit) ();

extern tString DeMap ARGS((tIdent id));
extern tTree LogBinOpFromLogOp ARGS((tIdPos op));
extern bool SameIds ARGS((tIdPos id1, tIdPos id2));
extern bool NoTranslationErrors ARGS(());
extern tIdPos ModName ARGS((tZSyms yyP1, tIdPos cid));
extern tTree ExpListFromDesignator ARGS((tZTree yyP4, tIdPos name, tTree el, tIdPos modname, tIdPos cid));
extern tTree LogBinOpFromSchemaOp ARGS((tIdPos op));
extern tIdPos PrimeName ARGS((tIdPos id));
extern tPosition IdPosPos ARGS((tIdPos id));
extern tIdent IdPosId ARGS((tIdPos id));
extern tTree ChangesOnlyFromXiRefs ARGS((tZTree yyP2));
extern tIdPos IdFromDeltaOrXiName ARGS((tIdPos id));
extern bool IsDeltaOrXi ARGS((tIdPos id));
extern tTree MergePredsFromSchematext ARGS((tZSyms locs, tIdPos cid, bool schcalc));
extern tZSyms AddIncludedLocals ARGS((tIdPos id, tZTree dec, tZSyms syms, tZSyms env));
extern tTree PredFromXi ARGS((tZTree yyP9, tZSyms syms, tZSyms env, tIdPos cid, tTree pred));
extern bool IsRenamed ARGS((tZTree yyP3));
extern tIdPos DecorateName ARGS((tIdPos id, tZTree dec));
extern bool InPreDefs ARGS((tIdPos id));
extern bool InSumRenamesZ ARGS((tZSyms yyP13, tIdPos id));
extern tIdPos AllocateName ARGS((tZSyms locs, tZSyms env, tIdPos id));
extern tIdPos SumNameForZName ARGS((tZSyms yyP15, tIdPos id));
extern bool InSumRenamesSum ARGS((tZSyms yyP14, tIdPos id));
extern tTree RenameSchemaForCompat ARGS((tZSyms rlocs, tZSyms llocs, tIdPos cid));
extern tIdPos ReWriteDeltaOrXi ARGS((tIdPos id));
extern bool IsPrefixOp ARGS((tTree yyP16));
extern tIdPos IdPosFromFncApp ARGS((tTree yyP17));

extern void BeginZSumAccess ();
extern void CloseZSumAccess ();

# endif
