# define DEP(a, b) a
# define SELF yyt
# include "BuildSymtab.h"

/* line 230 "z.ast" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include "Idents.h" 
#include "Positions.h"
#include "global.h"
#include "ZSyms.h"
#include "ZSymTabAccess.h"
#include "ZTreeAccess.h"
#include "ZSumAccess.h"
tIdPos currentMod;
#define ID 1
#define OPNAME 2
#define maxMods 256


static char yyb;

static void yyVisit1Specification ARGS((register tZTree yyt));
static void yyVisit1GlobalParagraphSeq ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut)));
static void yyVisit1GlobalParagraph ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut)));
static void yyVisit1HorizParagraphs ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut)));
static void yyVisit1HorizParagraph ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut)));
static void yyVisit1TypeDef ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut)));
static void yyVisit1NameFormals ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tTree (* yyFP), tIdPos (* yyId), tTree (* yyCP), tIdPos (* yyIdent), tZSyms (* yyzsymlist)));
static void yyVisit1BranchSeq ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tIdent (* yyFreeName), tTree (* yyBL), tZSyms (* yyzsymlist)));
static void yyVisit1ZFormalParams ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tTree (* yyFP), tTree (* yyCP), tZSyms (* yyzsymlist)));
static void yyVisit1ZBranch ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tIdPos (* yyId), tTree (* yyE), tIdPos (* yyIdent)));
static void yyVisit1SchemaExp ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tTree (* yyExp), tTree (* yySch), bool (* yyIsSimple), bool (* yyIsDesig), tPosition (* yyPos), tZSyms (* yyLocs)));
static void yyVisit1Designator ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tIdPos (* yyName), tIdPos (* yymodname), tTree (* yyParamList), tPosition (* yyPos), tTree (* yySch), tZTree (* yyDes), tTree (* yyEL), tTree (* yyDesEL), tZTree (* yyRS), tIdPos (* yyIdent), tIdPos (* yyId)));
static void yyVisit1VarNameSeq ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tTree (* yyFP), tTree (* yyIdL), tTree (* yyNL), tPosition (* yyPos), tTree (* yyCP), tZSyms (* yyzsymlist)));
static void yyVisit1ExpressionSeq ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tTree (* yyEL)));
static void yyVisit1RenameSeq ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tTree (* yyRL), tZSyms (* yyzsymlist)));
static void yyVisit1VarRename ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tIdPos (* yynew), tIdPos (* yyold), tIdPos (* yyIdent)));
static void yyVisit1ZSchemaText ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tPosition (* yyPos), tTree (* yySch)));
static void yyVisit1Declaration ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tPosition (* yyPos)));
static void yyVisit1BasicDecl ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tPosition (* yyPos)));
static void yyVisit1Predicate ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut)));
static void yyVisit1PredInfixRelSeq ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut)));
static void yyVisit1PredInfixRel ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tIdPos (* yyId)));
static void yyVisit1InfixRel ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tIdPos (* yyId)));
static void yyVisit1Expression ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tTree (* yyEL)));
static void yyVisit1LetDefSeq ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tPosition (* yyPos)));
static void yyVisit1LetDef ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tPosition (* yyPos)));
static void yyVisit1VarName ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tTree (* yyFP), tIdPos (* yyId), tPosition (* yyPos), tIdPos (* yyVarDec), tIdPos (* yySumId)));
static void yyVisit1Decoration ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), int (* yyvarkind), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), bool (* yyIsLocal), tZSyms (* yyRListIn), tZSyms (* yyRListOut)));
static void yyVisit1ZName ARGS((register tZTree yyt, tZSyms (* yyLocalsIn), tZSyms (* yyLocalsOut), tZSyms (* yyEnv), tTree (* yyDeclsIn), tTree (* yyDeclsOut), tTree (* yyVisIn), tTree (* yyVisOut), tTree (* yyPredIn), tTree (* yyPredOut), tTree (* yyMListIn), tTree (* yyMListOut), tZSyms (* yyRListIn), tZSyms (* yyRListOut), tIdPos (* yyId), tIdPos (* yySumId), tPosition (* yyPos)));

void BuildSymtab
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyVisit1Specification (yyt); }

static void yyVisit1Specification
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt)
# else
 (yyt)
 register tZTree yyt;
# endif
{
 switch (yyt->Kind) {
case kSpecification: {
tZSyms GlobalParagraphSeqyyLocalsIn;
tZSyms GlobalParagraphSeqyyLocalsOut;
tZSyms GlobalParagraphSeqyyEnv;
int GlobalParagraphSeqyyvarkind;
tTree GlobalParagraphSeqyyDeclsIn;
tTree GlobalParagraphSeqyyDeclsOut;
tTree GlobalParagraphSeqyyVisIn;
tTree GlobalParagraphSeqyyVisOut;
tTree GlobalParagraphSeqyyPredIn;
tTree GlobalParagraphSeqyyPredOut;
tTree GlobalParagraphSeqyyMListIn;
tTree GlobalParagraphSeqyyMListOut;
bool GlobalParagraphSeqyyIsLocal;
tZSyms GlobalParagraphSeqyyRListIn;
tZSyms GlobalParagraphSeqyyRListOut;
/* line 272 "z.ast" */

	GlobalParagraphSeqyyLocalsIn = mno_symbol();
/* line 279 "z.ast" */

	GlobalParagraphSeqyyRListIn = mnoSumRename();
/* line 274 "z.ast" */

	GlobalParagraphSeqyyIsLocal = false;
/* line 277 "z.ast" */

	GlobalParagraphSeqyyMListIn = mNoId();
/* line 278 "z.ast" */

	GlobalParagraphSeqyyPredIn = mNoPred();
/* line 276 "z.ast" */

	GlobalParagraphSeqyyVisIn = mNoDecl();
/* line 275 "z.ast" */

	GlobalParagraphSeqyyDeclsIn = mNoDecl();
/* line 273 "z.ast" */

	GlobalParagraphSeqyyvarkind = Is_local_id;
/* line 269 "z.ast" */

		currentMod = ZMakeIdPos("z2sum",NoPosition);
		GlobalParagraphSeqyyEnv = mscope_env(mno_symbol(),mno_env());
yyVisit1GlobalParagraphSeq (yyt->Specification.GlobalParagraphSeq, & GlobalParagraphSeqyyLocalsIn, & GlobalParagraphSeqyyLocalsOut, & GlobalParagraphSeqyyEnv, & GlobalParagraphSeqyyvarkind, & GlobalParagraphSeqyyDeclsIn, & GlobalParagraphSeqyyDeclsOut, & GlobalParagraphSeqyyVisIn, & GlobalParagraphSeqyyVisOut, & GlobalParagraphSeqyyPredIn, & GlobalParagraphSeqyyPredOut, & GlobalParagraphSeqyyMListIn, & GlobalParagraphSeqyyMListOut, & GlobalParagraphSeqyyIsLocal, & GlobalParagraphSeqyyRListIn, & GlobalParagraphSeqyyRListOut);
TreeRoot = ReverseTree(GlobalParagraphSeqyyDeclsOut);;
} break;
 default: ;
 }
}

static void yyVisit1GlobalParagraphSeq
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
# endif
{
 switch (yyt->Kind) {
case kGlobalParagraphSeq: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case knoGlobalParagraph: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kglobalParagraphs: {
tZSyms GlobalParagraphyyLocalsOut;
tTree GlobalParagraphyyDeclsOut;
tTree GlobalParagraphyyVisOut;
tTree GlobalParagraphyyPredOut;
tTree GlobalParagraphyyMListOut;
tZSyms GlobalParagraphyyRListOut;
yyVisit1GlobalParagraph (yyt->globalParagraphs.GlobalParagraph, & (* yyLocalsIn), & GlobalParagraphyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & GlobalParagraphyyDeclsOut, & (* yyVisIn), & GlobalParagraphyyVisOut, & (* yyPredIn), & GlobalParagraphyyPredOut, & (* yyMListIn), & GlobalParagraphyyMListOut, & (* yyIsLocal), & (* yyRListIn), & GlobalParagraphyyRListOut);
yyVisit1GlobalParagraphSeq (yyt->globalParagraphs.Next, & GlobalParagraphyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & GlobalParagraphyyDeclsOut, & (* yyDeclsOut), & GlobalParagraphyyVisOut, & (* yyVisOut), & GlobalParagraphyyPredOut, & (* yyPredOut), & GlobalParagraphyyMListOut, & (* yyMListOut), & (* yyIsLocal), & GlobalParagraphyyRListOut, & (* yyRListOut));
} break;
 default: ;
 }
}

static void yyVisit1GlobalParagraph
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
# endif
{
 switch (yyt->Kind) {
case kGlobalParagraph: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kaxiomaticDef: {
tZSyms ZSchemaTextyyLocalsIn;
tZSyms ZSchemaTextyyLocalsOut;
tZSyms ZSchemaTextyyEnv;
int ZSchemaTextyyvarkind;
tTree ZSchemaTextyyDeclsIn;
tTree ZSchemaTextyyDeclsOut;
tTree ZSchemaTextyyPredIn;
tPosition ZSchemaTextyyPos;
tTree ZSchemaTextyySch;
/* line 305 "z.ast" */

	ZSchemaTextyyDeclsIn = mNoDecl();
/* line 306 "z.ast" */

	ZSchemaTextyyPredIn = mNoPred();
/* line 307 "z.ast" */

	ZSchemaTextyyvarkind = Is_axiom_id;
/* line 854 "z.ast" */

	ZSchemaTextyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 855 "z.ast" */

	ZSchemaTextyyLocalsIn = mno_symbol();
yyVisit1ZSchemaText (yyt->axiomaticDef.ZSchemaText, & ZSchemaTextyyLocalsIn, & ZSchemaTextyyLocalsOut, & ZSchemaTextyyEnv, & ZSchemaTextyyvarkind, & ZSchemaTextyyDeclsIn, & ZSchemaTextyyDeclsOut, & (* yyVisIn), & (* yyVisOut), & ZSchemaTextyyPredIn, & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & ZSchemaTextyyPos, & ZSchemaTextyySch);
/* line 856 "z.ast" */

	(* yyLocalsOut) = AddAxSeq(ReverseZSyms(ZSchemaTextyyLocalsOut),(* yyLocalsIn),currentMod);
/* line 308 "z.ast" */

	(* yyDeclsOut) = mAxiomDecl((* yyDeclsIn),mNoParam(),ReverseTree(ZSchemaTextyyDeclsOut),(* yyPredOut));
} break;
case khorizPar: {
yyVisit1HorizParagraphs (yyt->horizPar.HorizParagraphs, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut));
} break;
case kgenericDef: {
tZSyms ZFormalParamsyyLocalsOut;
tTree ZFormalParamsyyDeclsOut;
tTree ZFormalParamsyyVisOut;
tTree ZFormalParamsyyPredOut;
tTree ZFormalParamsyyMListOut;
tZSyms ZFormalParamsyyRListOut;
tTree ZFormalParamsyyFP;
tTree ZFormalParamsyyCP;
tZSyms ZFormalParamsyyzsymlist;
tZSyms ZSchemaTextyyLocalsIn;
tZSyms ZSchemaTextyyLocalsOut;
tZSyms ZSchemaTextyyEnv;
tTree ZSchemaTextyyDeclsIn;
tTree ZSchemaTextyyDeclsOut;
tTree ZSchemaTextyyPredIn;
tPosition ZSchemaTextyyPos;
tTree ZSchemaTextyySch;
/* line 310 "z.ast" */

	ZSchemaTextyyDeclsIn = mNoDecl();
yyVisit1ZFormalParams (yyt->genericDef.ZFormalParams, & (* yyLocalsIn), & ZFormalParamsyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & ZFormalParamsyyDeclsOut, & (* yyVisIn), & ZFormalParamsyyVisOut, & (* yyPredIn), & ZFormalParamsyyPredOut, & (* yyMListIn), & ZFormalParamsyyMListOut, & (* yyIsLocal), & (* yyRListIn), & ZFormalParamsyyRListOut, & ZFormalParamsyyFP, & ZFormalParamsyyCP, & ZFormalParamsyyzsymlist);
/* line 311 "z.ast" */

	ZSchemaTextyyPredIn = mNoPred();
/* line 859 "z.ast" */

	ZSchemaTextyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 860 "z.ast" */

	ZSchemaTextyyLocalsIn = mno_symbol();
yyVisit1ZSchemaText (yyt->genericDef.ZSchemaText, & ZSchemaTextyyLocalsIn, & ZSchemaTextyyLocalsOut, & ZSchemaTextyyEnv, & (* yyvarkind), & ZSchemaTextyyDeclsIn, & ZSchemaTextyyDeclsOut, & ZFormalParamsyyVisOut, & (* yyVisOut), & ZSchemaTextyyPredIn, & (* yyPredOut), & ZFormalParamsyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ZFormalParamsyyRListOut, & (* yyRListOut), & ZSchemaTextyyPos, & ZSchemaTextyySch);
/* line 861 "z.ast" */

	(* yyLocalsOut) = AddGenSeq(ZFormalParamsyyzsymlist,ReverseZSyms(ZSchemaTextyyLocalsOut),(* yyLocalsIn),currentMod);
/* line 312 "z.ast" */

	(* yyDeclsOut) = mAxiomDecl((* yyDeclsIn),ZFormalParamsyyFP,ReverseTree(ZSchemaTextyyDeclsOut),(* yyPredOut));
} break;
case kschemaboxDef: {
tZSyms ZNameyyLocalsOut;
tTree ZNameyyDeclsOut;
tTree ZNameyyVisOut;
tTree ZNameyyPredOut;
tTree ZNameyyMListOut;
tZSyms ZNameyyRListOut;
tIdPos ZNameyyId;
tIdPos ZNameyySumId;
tPosition ZNameyyPos;
tZSyms ZFormalParamsyyLocalsOut;
tTree ZFormalParamsyyDeclsOut;
tTree ZFormalParamsyyVisOut;
tTree ZFormalParamsyyPredOut;
tTree ZFormalParamsyyMListOut;
tZSyms ZFormalParamsyyRListOut;
tTree ZFormalParamsyyFP;
tTree ZFormalParamsyyCP;
tZSyms ZFormalParamsyyzsymlist;
tZSyms ZSchemaTextyyLocalsIn;
tZSyms ZSchemaTextyyLocalsOut;
tZSyms ZSchemaTextyyEnv;
int ZSchemaTextyyvarkind;
tTree ZSchemaTextyyDeclsIn;
tTree ZSchemaTextyyDeclsOut;
tTree ZSchemaTextyyPredIn;
tPosition ZSchemaTextyyPos;
tTree ZSchemaTextyySch;
yyVisit1ZName (yyt->schemaboxDef.ZName, & (* yyLocalsIn), & ZNameyyLocalsOut, & (* yyEnv), & (* yyDeclsIn), & ZNameyyDeclsOut, & (* yyVisIn), & ZNameyyVisOut, & (* yyPredIn), & ZNameyyPredOut, & (* yyMListIn), & ZNameyyMListOut, & (* yyRListIn), & ZNameyyRListOut, & ZNameyyId, & ZNameyySumId, & ZNameyyPos);
/* line 314 "z.ast" */

	ZSchemaTextyyDeclsIn = mNoDecl();
yyVisit1ZFormalParams (yyt->schemaboxDef.ZFormalParams, & ZNameyyLocalsOut, & ZFormalParamsyyLocalsOut, & (* yyEnv), & (* yyvarkind), & ZNameyyDeclsOut, & ZFormalParamsyyDeclsOut, & ZNameyyVisOut, & ZFormalParamsyyVisOut, & ZNameyyPredOut, & ZFormalParamsyyPredOut, & ZNameyyMListOut, & ZFormalParamsyyMListOut, & (* yyIsLocal), & ZNameyyRListOut, & ZFormalParamsyyRListOut, & ZFormalParamsyyFP, & ZFormalParamsyyCP, & ZFormalParamsyyzsymlist);
/* line 315 "z.ast" */

	ZSchemaTextyyPredIn = mNoPred();
/* line 316 "z.ast" */

	ZSchemaTextyyvarkind = Is_schema_field;
/* line 864 "z.ast" */

	ZSchemaTextyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 865 "z.ast" */

	ZSchemaTextyyLocalsIn = mno_symbol();
yyVisit1ZSchemaText (yyt->schemaboxDef.ZSchemaText, & ZSchemaTextyyLocalsIn, & ZSchemaTextyyLocalsOut, & ZSchemaTextyyEnv, & ZSchemaTextyyvarkind, & ZSchemaTextyyDeclsIn, & ZSchemaTextyyDeclsOut, & ZFormalParamsyyVisOut, & (* yyVisOut), & ZSchemaTextyyPredIn, & (* yyPredOut), & ZFormalParamsyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ZFormalParamsyyRListOut, & (* yyRListOut), & ZSchemaTextyyPos, & ZSchemaTextyySch);
/* line 866 "z.ast" */

	(* yyLocalsOut) = msymbol((* yyLocalsIn),mschema(ZFormalParamsyyzsymlist,ZSchemaTextyyLocalsOut),ZNameyyId,NoIdPos,currentMod);
/* line 317 "z.ast" */


	if (IsDeltaOrXi(ZNameyyId))
		(* yyDeclsOut) = mSchemaDef((* yyDeclsIn),ReWriteDeltaOrXi(ZNameyyId),ZFormalParamsyyFP,ReverseTree(ZSchemaTextyyDeclsOut),(* yyPredOut),false);
	else (* yyDeclsOut) = mSchemaDef((* yyDeclsIn),ZNameyyId,ZFormalParamsyyFP,ReverseTree(ZSchemaTextyyDeclsOut),(* yyPredOut),false);
} break;
 default: ;
 }
}

static void yyVisit1HorizParagraphs
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
# endif
{
 switch (yyt->Kind) {
case kHorizParagraphs: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case knoHorizParagraph: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case khorizParagraphs: {
tZSyms HorizParagraphyyLocalsOut;
tTree HorizParagraphyyDeclsOut;
tTree HorizParagraphyyVisOut;
tTree HorizParagraphyyPredOut;
tTree HorizParagraphyyMListOut;
tZSyms HorizParagraphyyRListOut;
yyVisit1HorizParagraph (yyt->horizParagraphs.HorizParagraph, & (* yyLocalsIn), & HorizParagraphyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & HorizParagraphyyDeclsOut, & (* yyVisIn), & HorizParagraphyyVisOut, & (* yyPredIn), & HorizParagraphyyPredOut, & (* yyMListIn), & HorizParagraphyyMListOut, & (* yyIsLocal), & (* yyRListIn), & HorizParagraphyyRListOut);
yyVisit1HorizParagraphs (yyt->horizParagraphs.Next, & HorizParagraphyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & HorizParagraphyyDeclsOut, & (* yyDeclsOut), & HorizParagraphyyVisOut, & (* yyVisOut), & HorizParagraphyyPredOut, & (* yyPredOut), & HorizParagraphyyMListOut, & (* yyMListOut), & (* yyIsLocal), & HorizParagraphyyRListOut, & (* yyRListOut));
} break;
 default: ;
 }
}

static void yyVisit1HorizParagraph
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
# endif
{
 switch (yyt->Kind) {
case kHorizParagraph: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case ktypeDef: {
yyVisit1TypeDef (yyt->typeDef.TypeDef, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut));
} break;
case kglobalPredicate: {
tZSyms PredicateyyLocalsIn;
tZSyms PredicateyyLocalsOut;
tZSyms PredicateyyEnv;
tTree PredicateyyDeclsOut;
tTree PredicateyyPredIn;
/* line 871 "z.ast" */
(* yyLocalsOut) = (* yyLocalsIn);
/* line 324 "z.ast" */

	PredicateyyPredIn = mNoPred();
/* line 869 "z.ast" */

	PredicateyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 870 "z.ast" */

	PredicateyyLocalsIn = mno_symbol();
yyVisit1Predicate (yyt->globalPredicate.Predicate, & PredicateyyLocalsIn, & PredicateyyLocalsOut, & PredicateyyEnv, & (* yyvarkind), & (* yyDeclsIn), & PredicateyyDeclsOut, & (* yyVisIn), & (* yyVisOut), & PredicateyyPredIn, & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut));
/* line 325 "z.ast" */

	(* yyDeclsOut) = mConstraint((* yyDeclsIn),(* yyPredOut));
} break;
case kschemaDef: {
tZSyms NameFormalsyyLocalsOut;
tTree NameFormalsyyDeclsOut;
tTree NameFormalsyyVisOut;
tTree NameFormalsyyPredOut;
tTree NameFormalsyyMListOut;
tZSyms NameFormalsyyRListOut;
tTree NameFormalsyyFP;
tIdPos NameFormalsyyId;
tTree NameFormalsyyCP;
tIdPos NameFormalsyyIdent;
tZSyms NameFormalsyyzsymlist;
tZSyms SchemaExpyyLocalsIn;
tZSyms SchemaExpyyLocalsOut;
tZSyms SchemaExpyyEnv;
int SchemaExpyyvarkind;
tTree SchemaExpyyDeclsIn;
tTree SchemaExpyyDeclsOut;
tTree SchemaExpyyPredIn;
tTree SchemaExpyyExp;
tTree SchemaExpyySch;
bool SchemaExpyyIsSimple;
bool SchemaExpyyIsDesig;
tPosition SchemaExpyyPos;
tZSyms SchemaExpyyLocs;
tTree yyExtraPred;
tIdPos yyschemaname;
/* line 338 "z.ast" */

	SchemaExpyyvarkind = Is_schema_field;
yyVisit1NameFormals (yyt->schemaDef.NameFormals, & (* yyLocalsIn), & NameFormalsyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & NameFormalsyyDeclsOut, & (* yyVisIn), & NameFormalsyyVisOut, & (* yyPredIn), & NameFormalsyyPredOut, & (* yyMListIn), & NameFormalsyyMListOut, & (* yyIsLocal), & (* yyRListIn), & NameFormalsyyRListOut, & NameFormalsyyFP, & NameFormalsyyId, & NameFormalsyyCP, & NameFormalsyyIdent, & NameFormalsyyzsymlist);
/* line 337 "z.ast" */

	SchemaExpyyPredIn = mNoPred();
/* line 336 "z.ast" */

	SchemaExpyyDeclsIn = mNoDecl();
/* line 874 "z.ast" */

	SchemaExpyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 875 "z.ast" */

	SchemaExpyyLocalsIn = mno_symbol();
yyVisit1SchemaExp (yyt->schemaDef.SchemaExp, & SchemaExpyyLocalsIn, & SchemaExpyyLocalsOut, & SchemaExpyyEnv, & SchemaExpyyvarkind, & SchemaExpyyDeclsIn, & SchemaExpyyDeclsOut, & NameFormalsyyVisOut, & (* yyVisOut), & SchemaExpyyPredIn, & (* yyPredOut), & NameFormalsyyMListOut, & (* yyMListOut), & (* yyIsLocal), & NameFormalsyyRListOut, & (* yyRListOut), & SchemaExpyyExp, & SchemaExpyySch, & SchemaExpyyIsSimple, & SchemaExpyyIsDesig, & SchemaExpyyPos, & SchemaExpyyLocs);
/* line 876 "z.ast" */

	(* yyLocalsOut) = msymbol((* yyLocalsIn),mschema(NameFormalsyyzsymlist,SchemaExpyyLocalsOut),NameFormalsyyIdent,NoIdPos,currentMod);
/* line 340 "z.ast" */

	if (IsDeltaOrXi(NameFormalsyyId))
		yyschemaname = ReWriteDeltaOrXi(NameFormalsyyId);
	else yyschemaname = NameFormalsyyId;
/* line 345 "z.ast" */


	yyExtraPred = MergePredsFromSchematext(SchemaExpyyLocs,currentMod,true);
/* line 346 "z.ast" */

	if (SchemaExpyyIsSimple)
		(* yyDeclsOut) = mSchemaDef((* yyDeclsIn),yyschemaname,NameFormalsyyFP,ReverseTree(SchemaExpyyDeclsOut),(* yyPredOut),false);
	else if (SchemaExpyyIsDesig)
		(* yyDeclsOut) = mAbbreviation((* yyDeclsIn),yyschemaname,SchemaExpyyExp);
	else if (Tree_IsType(NameFormalsyyFP,kNoParam))
		(* yyDeclsOut) = mAbbreviation((* yyDeclsIn),yyschemaname,SchemaExpyyExp);
	else 		
		{(* yyDeclsOut) = mNoDecl();
		Message("can't handle generic schema definition in-line from schema calculus",3,SchemaExpyyPos);ErrorsInTranslation++;}
} break;
 default: ;
 }
}

static void yyVisit1TypeDef
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
# endif
{
 switch (yyt->Kind) {
case kTypeDef: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kgivenSet: {
tZSyms VarNameSeqyyLocalsOut;
tTree VarNameSeqyyDeclsOut;
tTree VarNameSeqyyFP;
tTree VarNameSeqyyIdL;
tTree VarNameSeqyyNL;
tPosition VarNameSeqyyPos;
tTree VarNameSeqyyCP;
tZSyms VarNameSeqyyzsymlist;
yyVisit1VarNameSeq (yyt->givenSet.VarNameSeq, & (* yyLocalsIn), & VarNameSeqyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & VarNameSeqyyDeclsOut, & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & VarNameSeqyyFP, & VarNameSeqyyIdL, & VarNameSeqyyNL, & VarNameSeqyyPos, & VarNameSeqyyCP, & VarNameSeqyyzsymlist);
/* line 879 "z.ast" */

	(* yyLocalsOut) = AddVarSeq(VarNameSeqyyzsymlist,(* yyLocalsIn),currentMod);
/* line 358 "z.ast" */

	(* yyDeclsOut) = mGivenSet((* yyDeclsIn),VarNameSeqyyIdL);
} break;
case kfreeType: {
tZSyms VarNameyyLocalsOut;
tTree VarNameyyDeclsOut;
tTree VarNameyyVisOut;
tTree VarNameyyPredOut;
tTree VarNameyyMListOut;
tZSyms VarNameyyRListOut;
tTree VarNameyyFP;
tIdPos VarNameyyId;
tPosition VarNameyyPos;
tIdPos VarNameyyVarDec;
tIdPos VarNameyySumId;
tZSyms BranchSeqyyLocalsOut;
tTree BranchSeqyyDeclsOut;
tIdent BranchSeqyyFreeName;
tTree BranchSeqyyBL;
tZSyms BranchSeqyyzsymlist;
yyVisit1VarName (yyt->freeType.VarName, & (* yyLocalsIn), & VarNameyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & VarNameyyDeclsOut, & (* yyVisIn), & VarNameyyVisOut, & (* yyPredIn), & VarNameyyPredOut, & (* yyMListIn), & VarNameyyMListOut, & (* yyIsLocal), & (* yyRListIn), & VarNameyyRListOut, & VarNameyyFP, & VarNameyyId, & VarNameyyPos, & VarNameyyVarDec, & VarNameyySumId);
/* line 360 "z.ast" */

	BranchSeqyyFreeName = IdPosId(VarNameyyId);
yyVisit1BranchSeq (yyt->freeType.BranchSeq, & VarNameyyLocalsOut, & BranchSeqyyLocalsOut, & (* yyEnv), & (* yyvarkind), & VarNameyyDeclsOut, & BranchSeqyyDeclsOut, & VarNameyyVisOut, & (* yyVisOut), & VarNameyyPredOut, & (* yyPredOut), & VarNameyyMListOut, & (* yyMListOut), & (* yyIsLocal), & VarNameyyRListOut, & (* yyRListOut), & BranchSeqyyFreeName, & BranchSeqyyBL, & BranchSeqyyzsymlist);
/* line 882 "z.ast" */

	(* yyLocalsOut) = AddVarSeq(BranchSeqyyzsymlist,msymbol((* yyLocalsIn),mvar(),VarNameyyVarDec,NoIdPos,currentMod),currentMod);
/* line 361 "z.ast" */

	(* yyDeclsOut) = mFreeType((* yyDeclsIn),VarNameyyId,BranchSeqyyBL);
} break;
case ktypeDef1: {
tZSyms NameFormalsyyLocalsOut;
tTree NameFormalsyyDeclsOut;
tTree NameFormalsyyVisOut;
tTree NameFormalsyyPredOut;
tTree NameFormalsyyMListOut;
tZSyms NameFormalsyyRListOut;
tTree NameFormalsyyFP;
tIdPos NameFormalsyyId;
tTree NameFormalsyyCP;
tIdPos NameFormalsyyIdent;
tZSyms NameFormalsyyzsymlist;
tZSyms ExpressionyyLocalsIn;
tZSyms ExpressionyyLocalsOut;
tZSyms ExpressionyyEnv;
tTree ExpressionyyDeclsOut;
tTree ExpressionyyEL;
yyVisit1NameFormals (yyt->typeDef1.NameFormals, & (* yyLocalsIn), & NameFormalsyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & NameFormalsyyDeclsOut, & (* yyVisIn), & NameFormalsyyVisOut, & (* yyPredIn), & NameFormalsyyPredOut, & (* yyMListIn), & NameFormalsyyMListOut, & (* yyIsLocal), & (* yyRListIn), & NameFormalsyyRListOut, & NameFormalsyyFP, & NameFormalsyyId, & NameFormalsyyCP, & NameFormalsyyIdent, & NameFormalsyyzsymlist);
/* line 887 "z.ast" */

	(* yyLocalsOut) = msymbol((* yyLocalsIn),mgeneric(NameFormalsyyzsymlist),NameFormalsyyIdent,NoIdPos,currentMod);
/* line 885 "z.ast" */

	ExpressionyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 886 "z.ast" */

	ExpressionyyLocalsIn = mno_symbol();
yyVisit1Expression (yyt->typeDef1.Expression, & ExpressionyyLocalsIn, & ExpressionyyLocalsOut, & ExpressionyyEnv, & (* yyvarkind), & NameFormalsyyDeclsOut, & ExpressionyyDeclsOut, & NameFormalsyyVisOut, & (* yyVisOut), & NameFormalsyyPredOut, & (* yyPredOut), & NameFormalsyyMListOut, & (* yyMListOut), & (* yyIsLocal), & NameFormalsyyRListOut, & (* yyRListOut), & ExpressionyyEL);
/* line 367 "z.ast" */

	if (Tree_IsType(NameFormalsyyFP,kNoParam))
		(* yyDeclsOut) = mAbbreviation((* yyDeclsIn),NameFormalsyyId,ExpressionyyEL);
	else
		(* yyDeclsOut) = mAxiomDecl((* yyDeclsIn),NameFormalsyyFP,mVarDecl(mNoDecl(),mId(mNoId(),NameFormalsyyId,ID),mCartProd(mNoExp(),CatExpressionList(ExpressionyyEL,NameFormalsyyCP)),Is_axiom_id),mNoPred());
} break;
case ktypeDefPregen: {
tZSyms DecorationyyLocalsOut;
tTree DecorationyyDeclsOut;
tTree DecorationyyVisOut;
tTree DecorationyyPredOut;
tTree DecorationyyMListOut;
tZSyms DecorationyyRListOut;
tZSyms VarNameyyLocalsOut;
tTree VarNameyyDeclsOut;
tTree VarNameyyVisOut;
tTree VarNameyyPredOut;
tTree VarNameyyMListOut;
tZSyms VarNameyyRListOut;
tTree VarNameyyFP;
tIdPos VarNameyyId;
tPosition VarNameyyPos;
tIdPos VarNameyyVarDec;
tIdPos VarNameyySumId;
tZSyms ExpressionyyLocalsIn;
tZSyms ExpressionyyLocalsOut;
tZSyms ExpressionyyEnv;
tTree ExpressionyyDeclsOut;
tTree ExpressionyyEL;
yyVisit1Decoration (yyt->typeDefPregen.Decoration, & (* yyLocalsIn), & DecorationyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & DecorationyyDeclsOut, & (* yyVisIn), & DecorationyyVisOut, & (* yyPredIn), & DecorationyyPredOut, & (* yyMListIn), & DecorationyyMListOut, & (* yyIsLocal), & (* yyRListIn), & DecorationyyRListOut);
yyVisit1VarName (yyt->typeDefPregen.VarName, & DecorationyyLocalsOut, & VarNameyyLocalsOut, & (* yyEnv), & (* yyvarkind), & DecorationyyDeclsOut, & VarNameyyDeclsOut, & DecorationyyVisOut, & VarNameyyVisOut, & DecorationyyPredOut, & VarNameyyPredOut, & DecorationyyMListOut, & VarNameyyMListOut, & (* yyIsLocal), & DecorationyyRListOut, & VarNameyyRListOut, & VarNameyyFP, & VarNameyyId, & VarNameyyPos, & VarNameyyVarDec, & VarNameyySumId);
/* line 892 "z.ast" */

	(* yyLocalsOut) = msymbol((* yyLocalsIn),mgeneric(mzSym(VarNameyyVarDec,mnoZSym())),IdDecCat(yyt->typeDefPregen.PreGen,yyt->typeDefPregen.Decoration),NoIdPos,currentMod);
/* line 890 "z.ast" */

	ExpressionyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 891 "z.ast" */

	ExpressionyyLocalsIn = mno_symbol();
yyVisit1Expression (yyt->typeDefPregen.Expression, & ExpressionyyLocalsIn, & ExpressionyyLocalsOut, & ExpressionyyEnv, & (* yyvarkind), & VarNameyyDeclsOut, & ExpressionyyDeclsOut, & VarNameyyVisOut, & (* yyVisOut), & VarNameyyPredOut, & (* yyPredOut), & VarNameyyMListOut, & (* yyMListOut), & (* yyIsLocal), & VarNameyyRListOut, & (* yyRListOut), & ExpressionyyEL);
/* line 373 "z.ast" */

	(* yyDeclsOut) = mAxiomDecl((* yyDeclsIn),VarNameyyFP,mVarDecl(mNoDecl(),mId(mNoId(),IdDecCat(yyt->typeDefPregen.PreGen,yyt->typeDefPregen.Decoration),ID),mCartProd(mNoExp(),CatExpressionList(ExpressionyyEL,mVariable(mNoExp(),mId(mNoId(),VarNameyyId,ID)))),Is_axiom_id),mNoPred());
} break;
case ktypeDefIngen: {
tZSyms Var1yyLocalsOut;
tTree Var1yyDeclsOut;
tTree Var1yyVisOut;
tTree Var1yyPredOut;
tTree Var1yyMListOut;
tZSyms Var1yyRListOut;
tTree Var1yyFP;
tIdPos Var1yyId;
tPosition Var1yyPos;
tIdPos Var1yyVarDec;
tIdPos Var1yySumId;
tZSyms DecorationyyLocalsOut;
tTree DecorationyyDeclsOut;
tTree DecorationyyVisOut;
tTree DecorationyyPredOut;
tTree DecorationyyMListOut;
tZSyms DecorationyyRListOut;
tZSyms Var2yyLocalsOut;
tTree Var2yyDeclsOut;
tTree Var2yyVisOut;
tTree Var2yyPredOut;
tTree Var2yyMListOut;
tZSyms Var2yyRListOut;
tTree Var2yyFP;
tIdPos Var2yyId;
tPosition Var2yyPos;
tIdPos Var2yyVarDec;
tIdPos Var2yySumId;
tZSyms ExpressionyyLocalsIn;
tZSyms ExpressionyyLocalsOut;
tZSyms ExpressionyyEnv;
tTree ExpressionyyDeclsOut;
tTree ExpressionyyEL;
yyVisit1VarName (yyt->typeDefIngen.Var1, & (* yyLocalsIn), & Var1yyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & Var1yyDeclsOut, & (* yyVisIn), & Var1yyVisOut, & (* yyPredIn), & Var1yyPredOut, & (* yyMListIn), & Var1yyMListOut, & (* yyIsLocal), & (* yyRListIn), & Var1yyRListOut, & Var1yyFP, & Var1yyId, & Var1yyPos, & Var1yyVarDec, & Var1yySumId);
yyVisit1Decoration (yyt->typeDefIngen.Decoration, & Var1yyLocalsOut, & DecorationyyLocalsOut, & (* yyEnv), & (* yyvarkind), & Var1yyDeclsOut, & DecorationyyDeclsOut, & Var1yyVisOut, & DecorationyyVisOut, & Var1yyPredOut, & DecorationyyPredOut, & Var1yyMListOut, & DecorationyyMListOut, & (* yyIsLocal), & Var1yyRListOut, & DecorationyyRListOut);
yyVisit1VarName (yyt->typeDefIngen.Var2, & DecorationyyLocalsOut, & Var2yyLocalsOut, & (* yyEnv), & (* yyvarkind), & DecorationyyDeclsOut, & Var2yyDeclsOut, & DecorationyyVisOut, & Var2yyVisOut, & DecorationyyPredOut, & Var2yyPredOut, & DecorationyyMListOut, & Var2yyMListOut, & (* yyIsLocal), & DecorationyyRListOut, & Var2yyRListOut, & Var2yyFP, & Var2yyId, & Var2yyPos, & Var2yyVarDec, & Var2yySumId);
/* line 897 "z.ast" */

	(* yyLocalsOut) = msymbol((* yyLocalsIn),mgeneric(mzSym(Var1yyVarDec,mzSym(Var2yyVarDec,mnoZSym()))),IdDecCat(yyt->typeDefIngen.InGen,yyt->typeDefIngen.Decoration),NoIdPos,currentMod);
/* line 895 "z.ast" */

	ExpressionyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 896 "z.ast" */

	ExpressionyyLocalsIn = mno_symbol();
yyVisit1Expression (yyt->typeDefIngen.Expression, & ExpressionyyLocalsIn, & ExpressionyyLocalsOut, & ExpressionyyEnv, & (* yyvarkind), & Var2yyDeclsOut, & ExpressionyyDeclsOut, & Var2yyVisOut, & (* yyVisOut), & Var2yyPredOut, & (* yyPredOut), & Var2yyMListOut, & (* yyMListOut), & (* yyIsLocal), & Var2yyRListOut, & (* yyRListOut), & ExpressionyyEL);
/* line 375 "z.ast" */

	(* yyDeclsOut) =  mAxiomDecl((* yyDeclsIn),mTyParam(mTyParam(mNoParam(),Var2yyId,false),Var1yyId,false),mVarDecl(mNoDecl(),mId(mNoId(),IdDecCat(yyt->typeDefIngen.InGen,yyt->typeDefIngen.Decoration),ID),mCartProd(mNoExp(),CatExpressionList(ExpressionyyEL,mCartProd(mNoExp(),CatExpressionList(mVariable(mNoExp(),mId(mNoId(),Var2yyId,ID)),mVariable(mNoExp(),mId(mNoId(),Var1yyId,ID)))))),Is_axiom_id),mNoPred());
} break;
 default: ;
 }
}

static void yyVisit1NameFormals
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tTree (* yyFP) ,tIdPos (* yyId) ,tTree (* yyCP) ,tIdPos (* yyIdent) ,tZSyms (* yyzsymlist))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyFP, yyId, yyCP, yyIdent, yyzsymlist)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tTree (* yyFP);
 tIdPos (* yyId);
 tTree (* yyCP);
 tIdPos (* yyIdent);
 tZSyms (* yyzsymlist);
# endif
{
 switch (yyt->Kind) {
case kNameFormals: {
tTree VarNameyyFP;
tPosition VarNameyyPos;
tIdPos VarNameyySumId;
yyVisit1VarName (yyt->NameFormals.VarName, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & VarNameyyFP, & (* yyId), & VarNameyyPos, & (* yyIdent), & VarNameyySumId);
/* line 903 "z.ast" */

	(* yyzsymlist) = mnoZSym();
/* line 834 "z.ast" */

	(* yyCP) = mNoExp();
/* line 290 "z.ast" */

	(* yyFP) = mNoParam();
} break;
case knoFormals: {
tTree VarNameyyFP;
tPosition VarNameyyPos;
tIdPos VarNameyySumId;
yyVisit1VarName (yyt->noFormals.VarName, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & VarNameyyFP, & (* yyId), & VarNameyyPos, & (* yyIdent), & VarNameyySumId);
/* line 903 "z.ast" */

	(* yyzsymlist) = mnoZSym();
/* line 834 "z.ast" */

	(* yyCP) = mNoExp();
/* line 290 "z.ast" */

	(* yyFP) = mNoParam();
} break;
case knameFormals: {
tZSyms VarNameyyLocalsOut;
tTree VarNameyyDeclsOut;
tTree VarNameyyVisOut;
tTree VarNameyyPredOut;
tTree VarNameyyMListOut;
tZSyms VarNameyyRListOut;
tTree VarNameyyFP;
tPosition VarNameyyPos;
tIdPos VarNameyySumId;
yyVisit1VarName (yyt->nameFormals.VarName, & (* yyLocalsIn), & VarNameyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & VarNameyyDeclsOut, & (* yyVisIn), & VarNameyyVisOut, & (* yyPredIn), & VarNameyyPredOut, & (* yyMListIn), & VarNameyyMListOut, & (* yyIsLocal), & (* yyRListIn), & VarNameyyRListOut, & VarNameyyFP, & (* yyId), & VarNameyyPos, & (* yyIdent), & VarNameyySumId);
yyVisit1ZFormalParams (yyt->nameFormals.ZFormalParams, & VarNameyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & VarNameyyDeclsOut, & (* yyDeclsOut), & VarNameyyVisOut, & (* yyVisOut), & VarNameyyPredOut, & (* yyPredOut), & VarNameyyMListOut, & (* yyMListOut), & (* yyIsLocal), & VarNameyyRListOut, & (* yyRListOut), & (* yyFP), & (* yyCP), & (* yyzsymlist));
} break;
 default: ;
 }
}

static void yyVisit1BranchSeq
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tIdent (* yyFreeName) ,tTree (* yyBL) ,tZSyms (* yyzsymlist))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyFreeName, yyBL, yyzsymlist)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tIdent (* yyFreeName);
 tTree (* yyBL);
 tZSyms (* yyzsymlist);
# endif
{
 switch (yyt->Kind) {
case kBranchSeq: {
(* yyDeclsOut) =(* yyDeclsIn);
/* line 909 "z.ast" */

	(* yyzsymlist) = mnoZSym();
/* line 469 "z.ast" */

	(* yyBL) = mNoBranch();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyLocalsOut) =(* yyLocalsIn);
} break;
case knoBranch: {
(* yyDeclsOut) =(* yyDeclsIn);
/* line 909 "z.ast" */

	(* yyzsymlist) = mnoZSym();
/* line 469 "z.ast" */

	(* yyBL) = mNoBranch();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyLocalsOut) =(* yyLocalsIn);
} break;
case kbranch: {
tZSyms ZBranchyyLocalsOut;
tTree ZBranchyyDeclsOut;
tTree ZBranchyyVisOut;
tTree ZBranchyyPredOut;
tTree ZBranchyyMListOut;
tZSyms ZBranchyyRListOut;
tIdPos ZBranchyyId;
tTree ZBranchyyE;
tIdPos ZBranchyyIdent;
tTree NextyyBL;
tZSyms Nextyyzsymlist;
yyVisit1ZBranch (yyt->branch.ZBranch, & (* yyLocalsIn), & ZBranchyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & ZBranchyyDeclsOut, & (* yyVisIn), & ZBranchyyVisOut, & (* yyPredIn), & ZBranchyyPredOut, & (* yyMListIn), & ZBranchyyMListOut, & (* yyIsLocal), & (* yyRListIn), & ZBranchyyRListOut, & ZBranchyyId, & ZBranchyyE, & ZBranchyyIdent);
yyVisit1BranchSeq (yyt->branch.Next, & ZBranchyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & ZBranchyyDeclsOut, & (* yyDeclsOut), & ZBranchyyVisOut, & (* yyVisOut), & ZBranchyyPredOut, & (* yyPredOut), & ZBranchyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ZBranchyyRListOut, & (* yyRListOut), & (* yyFreeName), & NextyyBL, & Nextyyzsymlist);
/* line 911 "z.ast" */

	(* yyzsymlist) = mzSym(ZBranchyyIdent,Nextyyzsymlist);
/* line 473 "z.ast" */

	if (ZTree_IsType(yyt->branch.ZBranch,ksimpleBranch))
		(* yyBL) = mFTConstant(NextyyBL,(* yyFreeName),ZBranchyyId);
	else
		(* yyBL) = mFTConstructor(NextyyBL,(* yyFreeName),ZBranchyyId,ZBranchyyE);
} break;
 default: ;
 }
}

static void yyVisit1ZFormalParams
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tTree (* yyFP) ,tTree (* yyCP) ,tZSyms (* yyzsymlist))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyFP, yyCP, yyzsymlist)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tTree (* yyFP);
 tTree (* yyCP);
 tZSyms (* yyzsymlist);
# endif
{
 switch (yyt->Kind) {
case kZFormalParams: {
(* yyDeclsOut) =(* yyDeclsIn);
/* line 924 "z.ast" */

	(* yyzsymlist) = mnoZSym();
/* line 839 "z.ast" */

	(* yyCP) = mNoExp();
/* line 285 "z.ast" */

	(* yyFP) = mNoParam();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyLocalsOut) =(* yyLocalsIn);
} break;
case knoFormalParams: {
(* yyDeclsOut) =(* yyDeclsIn);
/* line 924 "z.ast" */

	(* yyzsymlist) = mnoZSym();
/* line 839 "z.ast" */

	(* yyCP) = mNoExp();
/* line 285 "z.ast" */

	(* yyFP) = mNoParam();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyLocalsOut) =(* yyLocalsIn);
} break;
case kformalParams: {
tTree VarNameSeqyyIdL;
tTree VarNameSeqyyNL;
tPosition VarNameSeqyyPos;
yyVisit1VarNameSeq (yyt->formalParams.VarNameSeq, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & (* yyFP), & VarNameSeqyyIdL, & VarNameSeqyyNL, & VarNameSeqyyPos, & (* yyCP), & (* yyzsymlist));
} break;
 default: ;
 }
}

static void yyVisit1ZBranch
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tIdPos (* yyId) ,tTree (* yyE) ,tIdPos (* yyIdent))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyId, yyE, yyIdent)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tIdPos (* yyId);
 tTree (* yyE);
 tIdPos (* yyIdent);
# endif
{
 switch (yyt->Kind) {
case kZBranch: {
(* yyDeclsOut) =(* yyDeclsIn);
/* line 930 "z.ast" */

	(* yyIdent) = currentMod;
/* line 460 "z.ast" */

	(* yyE) = mNoExp();
/* line 459 "z.ast" */

	(* yyId) = ZMakeIdPos("",NoPosition);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyLocalsOut) =(* yyLocalsIn);
} break;
case ksimpleBranch: {
tTree VarNameyyFP;
tPosition VarNameyyPos;
tIdPos VarNameyySumId;
yyVisit1VarName (yyt->simpleBranch.VarName, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & VarNameyyFP, & (* yyId), & VarNameyyPos, & (* yyIdent), & VarNameyySumId);
/* line 460 "z.ast" */

	(* yyE) = mNoExp();
} break;
case kcompoundBranch: {
tZSyms VarNameyyLocalsOut;
tTree VarNameyyDeclsOut;
tTree VarNameyyVisOut;
tTree VarNameyyPredOut;
tTree VarNameyyMListOut;
tZSyms VarNameyyRListOut;
tTree VarNameyyFP;
tPosition VarNameyyPos;
tIdPos VarNameyySumId;
tZSyms ExpressionyyLocalsIn;
tZSyms ExpressionyyLocalsOut;
tZSyms ExpressionyyEnv;
/* line 936 "z.ast" */

	ExpressionyyLocalsIn = mno_symbol();
yyVisit1VarName (yyt->compoundBranch.VarName, & (* yyLocalsIn), & VarNameyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & VarNameyyDeclsOut, & (* yyVisIn), & VarNameyyVisOut, & (* yyPredIn), & VarNameyyPredOut, & (* yyMListIn), & VarNameyyMListOut, & (* yyIsLocal), & (* yyRListIn), & VarNameyyRListOut, & VarNameyyFP, & (* yyId), & VarNameyyPos, & (* yyIdent), & VarNameyySumId);
/* line 935 "z.ast" */

	ExpressionyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
yyVisit1Expression (yyt->compoundBranch.Expression, & ExpressionyyLocalsIn, & ExpressionyyLocalsOut, & ExpressionyyEnv, & (* yyvarkind), & VarNameyyDeclsOut, & (* yyDeclsOut), & VarNameyyVisOut, & (* yyVisOut), & VarNameyyPredOut, & (* yyPredOut), & VarNameyyMListOut, & (* yyMListOut), & (* yyIsLocal), & VarNameyyRListOut, & (* yyRListOut), & (* yyE));
/* line 937 "z.ast" */
(* yyLocalsOut) = (* yyLocalsIn);
} break;
 default: ;
 }
}

static void yyVisit1SchemaExp
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tTree (* yyExp) ,tTree (* yySch) ,bool (* yyIsSimple) ,bool (* yyIsDesig) ,tPosition (* yyPos) ,tZSyms (* yyLocs))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyExp, yySch, yyIsSimple, yyIsDesig, yyPos, yyLocs)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tTree (* yyExp);
 tTree (* yySch);
 bool (* yyIsSimple);
 bool (* yyIsDesig);
 tPosition (* yyPos);
 tZSyms (* yyLocs);
# endif
{
 switch (yyt->Kind) {
case kSchemaExp: {
(* yyVisOut) =(* yyVisIn);
/* line 995 "z.ast" */

	(* yyLocs) = mno_symbol();
/* line 695 "z.ast" */

	(* yyPos) = NoPosition;
/* line 694 "z.ast" */

	(* yyIsDesig) = false;
/* line 693 "z.ast" */

	(* yyIsSimple) = false;
/* line 528 "z.ast" */

	(* yySch) = mExpPred(mNoExp());
/* line 492 "z.ast" */

	(* yyExp) = mPredExp(mNoExp(),mSchemaPred(mNoPred(),(* yySch)));
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyDeclsOut) =(* yyDeclsIn);
(* yyLocalsOut) =(* yyLocalsIn);
} break;
case kschemaSimple: {
tZSyms ZSchemaTextyyLocalsIn;
tZSyms ZSchemaTextyyEnv;
int ZSchemaTextyyvarkind;
bool ZSchemaTextyyIsLocal;
/* line 532 "z.ast" */

	ZSchemaTextyyIsLocal = false;
/* line 531 "z.ast" */

	ZSchemaTextyyvarkind = Is_local_id;
/* line 914 "z.ast" */

	ZSchemaTextyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 915 "z.ast" */

	ZSchemaTextyyLocalsIn = mno_symbol();
yyVisit1ZSchemaText (yyt->schemaSimple.ZSchemaText, & ZSchemaTextyyLocalsIn, & (* yyLocalsOut), & ZSchemaTextyyEnv, & ZSchemaTextyyvarkind, & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & ZSchemaTextyyIsLocal, & (* yyRListIn), & (* yyRListOut), & (* yyPos), & (* yySch));
/* line 997 "z.ast" */

	(* yyLocs) = CopyZSyms((* yyLocalsOut));
/* line 694 "z.ast" */

	(* yyIsDesig) = false;
/* line 697 "z.ast" */

	(* yyIsSimple) = true;
/* line 492 "z.ast" */

	(* yyExp) = mPredExp(mNoExp(),mSchemaPred(mNoPred(),(* yySch)));
} break;
case kschemaDes: {
tIdPos DesignatoryyName;
tIdPos Designatoryymodname;
tTree DesignatoryyParamList;
tZTree DesignatoryyDes;
tTree DesignatoryyEL;
tTree DesignatoryyDesEL;
tZTree DesignatoryyRS;
tIdPos DesignatoryyIdent;
tIdPos DesignatoryyId;
yyVisit1Designator (yyt->schemaDes.Designator, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & DesignatoryyName, & Designatoryymodname, & DesignatoryyParamList, & (* yyPos), & (* yySch), & DesignatoryyDes, & DesignatoryyEL, & DesignatoryyDesEL, & DesignatoryyRS, & DesignatoryyIdent, & DesignatoryyId);
/* line 999 "z.ast" */

	(* yyLocs) = AddIncludedLocals(DesignatoryyId,yyt->schemaDes.Designator->Designator.Decoration,mno_symbol(),mscope_env((* yyLocalsIn),(* yyEnv)));
/* line 700 "z.ast" */

	(* yyIsDesig) = true;
/* line 693 "z.ast" */

	(* yyIsSimple) = false;
/* line 497 "z.ast" */

	if (ZTree_IsType(DesignatoryyRS,knoRename))
		(* yyExp) = DesignatoryyEL;
	else
		(* yyExp) = mPredExp(mNoExp(),mSchemaPred(mNoPred(),(* yySch)));
} break;
case kschemaPreop: {
tTree SchemaExpyyExp;
tTree SchemaExpyySch;
bool SchemaExpyyIsSimple;
bool SchemaExpyyIsDesig;
tPosition SchemaExpyyPos;
yyVisit1SchemaExp (yyt->schemaPreop.SchemaExp, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & SchemaExpyyExp, & SchemaExpyySch, & SchemaExpyyIsSimple, & SchemaExpyyIsDesig, & SchemaExpyyPos, & (* yyLocs));
/* line 703 "z.ast" */

	(* yyPos) = IdPosPos(yyt->schemaPreop.PreOp);
/* line 694 "z.ast" */

	(* yyIsDesig) = false;
/* line 693 "z.ast" */

	(* yyIsSimple) = false;
/* line 538 "z.ast" */

	(* yySch) = SchemaExpyySch;
	Message("schema preop lost",3,SchemaExpyyPos);
	ErrorsInTranslation++;
/* line 492 "z.ast" */

	(* yyExp) = mPredExp(mNoExp(),mSchemaPred(mNoPred(),(* yySch)));
} break;
case kschemaCons: {
tZSyms LopyyLocalsOut;
tTree LopyyDeclsIn;
tTree LopyyDeclsOut;
tTree LopyyVisOut;
tTree LopyyPredOut;
tTree LopyyMListOut;
tZSyms LopyyRListOut;
tTree LopyyExp;
tTree LopyySch;
bool LopyyIsSimple;
bool LopyyIsDesig;
tZSyms LopyyLocs;
tTree RopyyDeclsIn;
tTree RopyyExp;
tTree RopyySch;
bool RopyyIsSimple;
bool RopyyIsDesig;
tPosition RopyyPos;
tZSyms RopyyLocs;
tTree yyleftRlist;
tTree yyrightRlist;
tTree yyLopSch;
tTree yyRopSch;
/* line 509 "z.ast" */

	LopyyDeclsIn = mNoDecl();
yyVisit1SchemaExp (yyt->schemaCons.Lop, & (* yyLocalsIn), & LopyyLocalsOut, & (* yyEnv), & (* yyvarkind), & LopyyDeclsIn, & LopyyDeclsOut, & (* yyVisIn), & LopyyVisOut, & (* yyPredIn), & LopyyPredOut, & (* yyMListIn), & LopyyMListOut, & (* yyIsLocal), & (* yyRListIn), & LopyyRListOut, & LopyyExp, & LopyySch, & LopyyIsSimple, & LopyyIsDesig, & (* yyPos), & LopyyLocs);
/* line 510 "z.ast" */

	RopyyDeclsIn = mNoDecl();
yyVisit1SchemaExp (yyt->schemaCons.Rop, & LopyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & RopyyDeclsIn, & (* yyDeclsOut), & LopyyVisOut, & (* yyVisOut), & LopyyPredOut, & (* yyPredOut), & LopyyMListOut, & (* yyMListOut), & (* yyIsLocal), & LopyyRListOut, & (* yyRListOut), & RopyyExp, & RopyySch, & RopyyIsSimple, & RopyyIsDesig, & RopyyPos, & RopyyLocs);
/* line 1003 "z.ast" */

	(* yyLocs) = IncSymbols(LopyyLocs,RopyyLocs);
/* line 512 "z.ast" */

	yyrightRlist = RenameSchemaForCompat(LopyyLocs,RopyyLocs,currentMod);
/* line 517 "z.ast" */

	if (Tree_IsType(yyrightRlist,kNoRename))
		yyRopSch = RopyySch;
	else
		yyRopSch = mSchemaSubst(RopyySch,yyrightRlist);
/* line 511 "z.ast" */

	yyleftRlist = RenameSchemaForCompat(RopyyLocs,LopyyLocs,currentMod);
/* line 513 "z.ast" */

	if (Tree_IsType(yyleftRlist,kNoRename))
		yyLopSch = LopyySch;
	else yyLopSch = mSchemaSubst(LopyySch,yyleftRlist);
/* line 694 "z.ast" */

	(* yyIsDesig) = false;
/* line 693 "z.ast" */

	(* yyIsSimple) = false;
/* line 543 "z.ast" */

	(* yySch) = mExpPred(mPredExp(mNoExp(),mLogBinPred(mNoPred(),mSchemaPred(mNoPred(),LopyySch),LogBinOpFromSchemaOp(yyt->schemaCons.SchemaOp),mSchemaPred(mNoPred(),RopyySch))));
/* line 522 "z.ast" */

	(* yyExp) = mPredExp(mNoExp(),mLogBinPred(mNoPred(),mSchemaPred(mNoPred(),yyLopSch),LogBinOpFromSchemaOp(yyt->schemaCons.SchemaOp),mSchemaPred(mNoPred(),yyRopSch)));
} break;
case kschemaHide: {
tZSyms SchemaExpyyLocalsOut;
tTree SchemaExpyyDeclsOut;
tTree SchemaExpyyVisOut;
tTree SchemaExpyyPredOut;
tTree SchemaExpyyMListOut;
tZSyms SchemaExpyyRListOut;
tTree SchemaExpyyExp;
tTree SchemaExpyySch;
bool SchemaExpyyIsSimple;
bool SchemaExpyyIsDesig;
tZSyms SchemaExpyyLocs;
tTree VarNameSeqyyFP;
tTree VarNameSeqyyIdL;
tTree VarNameSeqyyNL;
tPosition VarNameSeqyyPos;
tTree VarNameSeqyyCP;
tZSyms VarNameSeqyyzsymlist;
yyVisit1SchemaExp (yyt->schemaHide.SchemaExp, & (* yyLocalsIn), & SchemaExpyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & SchemaExpyyDeclsOut, & (* yyVisIn), & SchemaExpyyVisOut, & (* yyPredIn), & SchemaExpyyPredOut, & (* yyMListIn), & SchemaExpyyMListOut, & (* yyIsLocal), & (* yyRListIn), & SchemaExpyyRListOut, & SchemaExpyyExp, & SchemaExpyySch, & SchemaExpyyIsSimple, & SchemaExpyyIsDesig, & (* yyPos), & SchemaExpyyLocs);
yyVisit1VarNameSeq (yyt->schemaHide.VarNameSeq, & SchemaExpyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & SchemaExpyyDeclsOut, & (* yyDeclsOut), & SchemaExpyyVisOut, & (* yyVisOut), & SchemaExpyyPredOut, & (* yyPredOut), & SchemaExpyyMListOut, & (* yyMListOut), & (* yyIsLocal), & SchemaExpyyRListOut, & (* yyRListOut), & VarNameSeqyyFP, & VarNameSeqyyIdL, & VarNameSeqyyNL, & VarNameSeqyyPos, & VarNameSeqyyCP, & VarNameSeqyyzsymlist);
/* line 1005 "z.ast" */

	(* yyLocs) = HideSymbols(SchemaExpyyLocs,VarNameSeqyyzsymlist);
/* line 694 "z.ast" */

	(* yyIsDesig) = false;
/* line 693 "z.ast" */

	(* yyIsSimple) = false;
/* line 545 "z.ast" */

	(* yySch) = mSchemaHiding(SchemaExpyySch,VarNameSeqyyNL);
/* line 492 "z.ast" */

	(* yyExp) = mPredExp(mNoExp(),mSchemaPred(mNoPred(),(* yySch)));
} break;
case kschemaQuant: {
tZSyms ZSchemaTextyyLocalsIn;
tZSyms ZSchemaTextyyEnv;
int ZSchemaTextyyvarkind;
tTree ZSchemaTextyyDeclsIn;
tTree ZSchemaTextyyDeclsOut;
tTree ZSchemaTextyyVisOut;
tTree ZSchemaTextyyPredOut;
tTree ZSchemaTextyyMListOut;
bool ZSchemaTextyyIsLocal;
tZSyms ZSchemaTextyyRListOut;
tPosition ZSchemaTextyyPos;
tZSyms SchemaExpyyLocalsOut;
tTree SchemaExpyyDeclsIn;
tTree SchemaExpyyExp;
tTree SchemaExpyySch;
bool SchemaExpyyIsSimple;
bool SchemaExpyyIsDesig;
tPosition SchemaExpyyPos;
/* line 550 "z.ast" */

	ZSchemaTextyyDeclsIn = mNoDecl();
/* line 549 "z.ast" */

	ZSchemaTextyyIsLocal = true;
/* line 548 "z.ast" */

	ZSchemaTextyyvarkind = Is_local_id;
/* line 918 "z.ast" */

	ZSchemaTextyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 919 "z.ast" */

	ZSchemaTextyyLocalsIn = mno_symbol();
yyVisit1ZSchemaText (yyt->schemaQuant.ZSchemaText, & ZSchemaTextyyLocalsIn, & (* yyLocalsOut), & ZSchemaTextyyEnv, & ZSchemaTextyyvarkind, & ZSchemaTextyyDeclsIn, & ZSchemaTextyyDeclsOut, & (* yyVisIn), & ZSchemaTextyyVisOut, & (* yyPredIn), & ZSchemaTextyyPredOut, & (* yyMListIn), & ZSchemaTextyyMListOut, & ZSchemaTextyyIsLocal, & (* yyRListIn), & ZSchemaTextyyRListOut, & ZSchemaTextyyPos, & (* yySch));
/* line 551 "z.ast" */

	SchemaExpyyDeclsIn = mNoDecl();
yyVisit1SchemaExp (yyt->schemaQuant.SchemaExp, & (* yyLocalsOut), & SchemaExpyyLocalsOut, & (* yyEnv), & (* yyvarkind), & SchemaExpyyDeclsIn, & (* yyDeclsOut), & ZSchemaTextyyVisOut, & (* yyVisOut), & ZSchemaTextyyPredOut, & (* yyPredOut), & ZSchemaTextyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ZSchemaTextyyRListOut, & (* yyRListOut), & SchemaExpyyExp, & SchemaExpyySch, & SchemaExpyyIsSimple, & SchemaExpyyIsDesig, & SchemaExpyyPos, & (* yyLocs));
/* line 709 "z.ast" */

	(* yyPos) = IdPosPos(yyt->schemaQuant.LogQuant);
/* line 694 "z.ast" */

	(* yyIsDesig) = false;
/* line 693 "z.ast" */

	(* yyIsSimple) = false;
/* line 492 "z.ast" */

	(* yyExp) = mPredExp(mNoExp(),mSchemaPred(mNoPred(),(* yySch)));
} break;
case kschemaComp: {
tZSyms LopyyLocalsOut;
tTree LopyyDeclsIn;
tTree LopyyDeclsOut;
tTree LopyyVisOut;
tTree LopyyPredOut;
tTree LopyyMListOut;
tZSyms LopyyRListOut;
tTree LopyyExp;
tTree LopyySch;
bool LopyyIsSimple;
bool LopyyIsDesig;
tZSyms LopyyLocs;
tTree RopyyDeclsIn;
tTree RopyyExp;
tTree RopyySch;
bool RopyyIsSimple;
bool RopyyIsDesig;
tPosition RopyyPos;
tZSyms RopyyLocs;
/* line 555 "z.ast" */

	LopyyDeclsIn = mNoDecl();
yyVisit1SchemaExp (yyt->schemaComp.Lop, & (* yyLocalsIn), & LopyyLocalsOut, & (* yyEnv), & (* yyvarkind), & LopyyDeclsIn, & LopyyDeclsOut, & (* yyVisIn), & LopyyVisOut, & (* yyPredIn), & LopyyPredOut, & (* yyMListIn), & LopyyMListOut, & (* yyIsLocal), & (* yyRListIn), & LopyyRListOut, & LopyyExp, & LopyySch, & LopyyIsSimple, & LopyyIsDesig, & (* yyPos), & LopyyLocs);
/* line 556 "z.ast" */

	RopyyDeclsIn = mNoDecl();
yyVisit1SchemaExp (yyt->schemaComp.Rop, & LopyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & RopyyDeclsIn, & (* yyDeclsOut), & LopyyVisOut, & (* yyVisOut), & LopyyPredOut, & (* yyPredOut), & LopyyMListOut, & (* yyMListOut), & (* yyIsLocal), & LopyyRListOut, & (* yyRListOut), & RopyyExp, & RopyySch, & RopyyIsSimple, & RopyyIsDesig, & RopyyPos, & RopyyLocs);
/* line 1007 "z.ast" */

	(* yyLocs) = ComposeSymbols(LopyyLocs,RopyyLocs);
/* line 694 "z.ast" */

	(* yyIsDesig) = false;
/* line 693 "z.ast" */

	(* yyIsSimple) = false;
/* line 557 "z.ast" */

	(* yySch) = mSchemaCompos(LopyySch,ZMakeIdPos("s_compose",NoPosition),RopyySch);
/* line 492 "z.ast" */

	(* yyExp) = mPredExp(mNoExp(),mSchemaPred(mNoPred(),(* yySch)));
} break;
case kschemaProject: {
tZSyms LopyyLocalsOut;
tTree LopyyDeclsIn;
tTree LopyyDeclsOut;
tTree LopyyVisOut;
tTree LopyyPredOut;
tTree LopyyMListOut;
tZSyms LopyyRListOut;
tTree LopyyExp;
tTree LopyySch;
bool LopyyIsSimple;
bool LopyyIsDesig;
tZSyms LopyyLocs;
tTree RopyyDeclsIn;
tTree RopyyExp;
tTree RopyySch;
bool RopyyIsSimple;
bool RopyyIsDesig;
tPosition RopyyPos;
/* line 559 "z.ast" */

	LopyyDeclsIn = mNoDecl();
yyVisit1SchemaExp (yyt->schemaProject.Lop, & (* yyLocalsIn), & LopyyLocalsOut, & (* yyEnv), & (* yyvarkind), & LopyyDeclsIn, & LopyyDeclsOut, & (* yyVisIn), & LopyyVisOut, & (* yyPredIn), & LopyyPredOut, & (* yyMListIn), & LopyyMListOut, & (* yyIsLocal), & (* yyRListIn), & LopyyRListOut, & LopyyExp, & LopyySch, & LopyyIsSimple, & LopyyIsDesig, & (* yyPos), & LopyyLocs);
/* line 560 "z.ast" */

	RopyyDeclsIn = mNoDecl();
yyVisit1SchemaExp (yyt->schemaProject.Rop, & LopyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & RopyyDeclsIn, & (* yyDeclsOut), & LopyyVisOut, & (* yyVisOut), & LopyyPredOut, & (* yyPredOut), & LopyyMListOut, & (* yyMListOut), & (* yyIsLocal), & LopyyRListOut, & (* yyRListOut), & RopyyExp, & RopyySch, & RopyyIsSimple, & RopyyIsDesig, & RopyyPos, & (* yyLocs));
/* line 694 "z.ast" */

	(* yyIsDesig) = false;
/* line 693 "z.ast" */

	(* yyIsSimple) = false;
/* line 561 "z.ast" */

	(* yySch) = mSchemaProj(LopyySch,ZMakeIdPos("zproj",NoPosition),RopyySch);
/* line 492 "z.ast" */

	(* yyExp) = mPredExp(mNoExp(),mSchemaPred(mNoPred(),(* yySch)));
} break;
case kschemaPipe: {
tZSyms LopyyLocalsOut;
tTree LopyyDeclsIn;
tTree LopyyDeclsOut;
tTree LopyyVisOut;
tTree LopyyPredOut;
tTree LopyyMListOut;
tZSyms LopyyRListOut;
tTree LopyyExp;
tTree LopyySch;
bool LopyyIsSimple;
bool LopyyIsDesig;
tZSyms LopyyLocs;
tTree RopyyDeclsIn;
tTree RopyyExp;
tTree RopyySch;
bool RopyyIsSimple;
bool RopyyIsDesig;
tPosition RopyyPos;
tZSyms RopyyLocs;
/* line 563 "z.ast" */

	LopyyDeclsIn = mNoDecl();
yyVisit1SchemaExp (yyt->schemaPipe.Lop, & (* yyLocalsIn), & LopyyLocalsOut, & (* yyEnv), & (* yyvarkind), & LopyyDeclsIn, & LopyyDeclsOut, & (* yyVisIn), & LopyyVisOut, & (* yyPredIn), & LopyyPredOut, & (* yyMListIn), & LopyyMListOut, & (* yyIsLocal), & (* yyRListIn), & LopyyRListOut, & LopyyExp, & LopyySch, & LopyyIsSimple, & LopyyIsDesig, & (* yyPos), & LopyyLocs);
/* line 564 "z.ast" */

	RopyyDeclsIn = mNoDecl();
yyVisit1SchemaExp (yyt->schemaPipe.Rop, & LopyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & RopyyDeclsIn, & (* yyDeclsOut), & LopyyVisOut, & (* yyVisOut), & LopyyPredOut, & (* yyPredOut), & LopyyMListOut, & (* yyMListOut), & (* yyIsLocal), & LopyyRListOut, & (* yyRListOut), & RopyyExp, & RopyySch, & RopyyIsSimple, & RopyyIsDesig, & RopyyPos, & RopyyLocs);
/* line 1009 "z.ast" */

	(* yyLocs) = PipeSymbols(LopyyLocs,RopyyLocs);
/* line 694 "z.ast" */

	(* yyIsDesig) = false;
/* line 693 "z.ast" */

	(* yyIsSimple) = false;
/* line 565 "z.ast" */

	(* yySch) = LopyySch;
	Message("no schema pipe",3,(* yyPos));
	ErrorsInTranslation++;
/* line 492 "z.ast" */

	(* yyExp) = mPredExp(mNoExp(),mSchemaPred(mNoPred(),(* yySch)));
} break;
case kschemaParen: {
tTree SchemaExpyyExp;
bool SchemaExpyyIsSimple;
bool SchemaExpyyIsDesig;
yyVisit1SchemaExp (yyt->schemaParen.SchemaExp, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & SchemaExpyyExp, & (* yySch), & SchemaExpyyIsSimple, & SchemaExpyyIsDesig, & (* yyPos), & (* yyLocs));
/* line 694 "z.ast" */

	(* yyIsDesig) = false;
/* line 693 "z.ast" */

	(* yyIsSimple) = false;
/* line 492 "z.ast" */

	(* yyExp) = mPredExp(mNoExp(),mSchemaPred(mNoPred(),(* yySch)));
} break;
 default: ;
 }
}

static void yyVisit1Designator
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tIdPos (* yyName) ,tIdPos (* yymodname) ,tTree (* yyParamList) ,tPosition (* yyPos) ,tTree (* yySch) ,tZTree (* yyDes) ,tTree (* yyEL) ,tTree (* yyDesEL) ,tZTree (* yyRS) ,tIdPos (* yyIdent) ,tIdPos (* yyId))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyName, yymodname, yyParamList, yyPos, yySch, yyDes, yyEL, yyDesEL, yyRS, yyIdent, yyId)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tIdPos (* yyName);
 tIdPos (* yymodname);
 tTree (* yyParamList);
 tPosition (* yyPos);
 tTree (* yySch);
 tZTree (* yyDes);
 tTree (* yyEL);
 tTree (* yyDesEL);
 tZTree (* yyRS);
 tIdPos (* yyIdent);
 tIdPos (* yyId);
# endif
{
 switch (yyt->Kind) {
case kDesignator: {
tZSyms ZNameyyLocalsOut;
tTree ZNameyyDeclsOut;
tTree ZNameyyVisOut;
tTree ZNameyyPredOut;
tTree ZNameyyMListOut;
tZSyms ZNameyyRListOut;
tIdPos ZNameyySumId;
tZSyms DecorationyyLocalsOut;
tTree DecorationyyDeclsOut;
tTree DecorationyyVisOut;
tTree DecorationyyPredOut;
tTree DecorationyyMListOut;
tZSyms DecorationyyRListOut;
tZSyms ExpressionSeqyyLocalsIn;
tZSyms ExpressionSeqyyLocalsOut;
tZSyms ExpressionSeqyyEnv;
tTree ExpressionSeqyyDeclsOut;
tTree ExpressionSeqyyVisOut;
tTree ExpressionSeqyyPredOut;
tTree ExpressionSeqyyMListOut;
tZSyms ExpressionSeqyyRListOut;
tZSyms RenameSeqyyLocalsOut;
tTree RenameSeqyyVisOut;
tTree RenameSeqyyRL;
tZSyms RenameSeqyyzsymlist;
yyVisit1ZName (yyt->Designator.ZName, & (* yyLocalsIn), & ZNameyyLocalsOut, & (* yyEnv), & (* yyDeclsIn), & ZNameyyDeclsOut, & (* yyVisIn), & ZNameyyVisOut, & (* yyPredIn), & ZNameyyPredOut, & (* yyMListIn), & ZNameyyMListOut, & (* yyRListIn), & ZNameyyRListOut, & (* yyId), & ZNameyySumId, & (* yyPos));
/* line 944 "z.ast" */

	ExpressionSeqyyLocalsIn = mno_symbol();
yyVisit1Decoration (yyt->Designator.Decoration, & ZNameyyLocalsOut, & DecorationyyLocalsOut, & (* yyEnv), & (* yyvarkind), & ZNameyyDeclsOut, & DecorationyyDeclsOut, & ZNameyyVisOut, & DecorationyyVisOut, & ZNameyyPredOut, & DecorationyyPredOut, & ZNameyyMListOut, & DecorationyyMListOut, & (* yyIsLocal), & ZNameyyRListOut, & DecorationyyRListOut);
/* line 943 "z.ast" */

	ExpressionSeqyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
yyVisit1ExpressionSeq (yyt->Designator.ExpressionSeq, & ExpressionSeqyyLocalsIn, & ExpressionSeqyyLocalsOut, & ExpressionSeqyyEnv, & (* yyvarkind), & DecorationyyDeclsOut, & ExpressionSeqyyDeclsOut, & DecorationyyVisOut, & ExpressionSeqyyVisOut, & DecorationyyPredOut, & ExpressionSeqyyPredOut, & DecorationyyMListOut, & ExpressionSeqyyMListOut, & (* yyIsLocal), & DecorationyyRListOut, & ExpressionSeqyyRListOut, & (* yyParamList));
yyVisit1RenameSeq (yyt->Designator.RenameSeq, & ExpressionSeqyyLocalsOut, & RenameSeqyyLocalsOut, & (* yyEnv), & (* yyvarkind), & ExpressionSeqyyDeclsOut, & (* yyDeclsOut), & ExpressionSeqyyVisOut, & RenameSeqyyVisOut, & ExpressionSeqyyPredOut, & (* yyPredOut), & ExpressionSeqyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ExpressionSeqyyRListOut, & (* yyRListOut), & RenameSeqyyRL, & RenameSeqyyzsymlist);
/* line 942 "z.ast" */

	(* yyIdent) = IdDecCat((* yyId),yyt->Designator.Decoration);
/* line 805 "z.ast" */

	(* yyRS) = yyt->Designator.RenameSeq;
/* line 807 "z.ast" */

	(* yyDes) = mDesignator(CopyZTree(yyt->Designator.ZName),CopyZTree(yyt->Designator.Decoration),CopyZTree(yyt->Designator.ExpressionSeq),mnoRename(),yyt->Designator.IsSchemaRef);
/* line 413 "z.ast" */
(* yyName) = (* yyIdent);
/* line 414 "z.ast" */

	if (ZSyms_IsType(TotalLookup((* yyIdent),(* yyLocalsIn),(* yyEnv)),kno_symbol))
		{if (IsDeltaOrXi((* yyIdent)))
			(* yymodname) = ModName(TotalLookup(IdFromDeltaOrXiName((* yyIdent)),(* yyLocalsIn),(* yyEnv)),currentMod);
		else (* yymodname) = ModName(TotalLookup((* yyId),(* yyLocalsIn),(* yyEnv)),currentMod);}
	else
		(* yymodname) = ModName(TotalLookup((* yyIdent),(* yyLocalsIn),(* yyEnv)),currentMod);
/* line 808 "z.ast" */

	(* yyDesEL) = ExpListFromDesignator((* yyDes),(* yyId),(* yyParamList),(* yymodname),currentMod);
/* line 806 "z.ast" */

	(* yyEL) = ExpListFromDesignator(SELF,(* yyId),(* yyParamList),(* yymodname),currentMod);
/* line 809 "z.ast" */

	if (ZTree_IsType(yyt->Designator.RenameSeq,krenames))
		(* yySch) = mSchemaSubst(mExpPred((* yyDesEL)),RenameSeqyyRL);
	else
		(* yySch) = mExpPred((* yyEL));
/* line 422 "z.ast" */

	(* yyVisOut) = (* yyVisIn);
	if (!SameIds((* yymodname),currentMod))
		if (!InImportList((* yymodname),(* yyVisIn)))
			if (InIdList((* yymodname),(* yyMListIn)))
				(* yyVisOut) = mVisibility((* yyVisIn),(* yymodname),mNoSelection());
			else
				(* yyVisOut) = mImport((* yyVisIn),(* yymodname),mNoExp(),mNoRename(),ZMakeIdPos("",NoPosition));
/* line 945 "z.ast" */
(* yyLocalsOut) = (* yyLocalsIn);
} break;
 default: ;
 }
}

static void yyVisit1VarNameSeq
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tTree (* yyFP) ,tTree (* yyIdL) ,tTree (* yyNL) ,tPosition (* yyPos) ,tTree (* yyCP) ,tZSyms (* yyzsymlist))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyFP, yyIdL, yyNL, yyPos, yyCP, yyzsymlist)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tTree (* yyFP);
 tTree (* yyIdL);
 tTree (* yyNL);
 tPosition (* yyPos);
 tTree (* yyCP);
 tZSyms (* yyzsymlist);
# endif
{
 switch (yyt->Kind) {
case kVarNameSeq: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 948 "z.ast" */

	(* yyzsymlist) = mnoZSym();
/* line 844 "z.ast" */

	(* yyCP) = mNoExp();
/* line 744 "z.ast" */

	(* yyPos) = NoPosition;
/* line 574 "z.ast" */

	(* yyNL) = mNoName();
/* line 454 "z.ast" */

	(* yyIdL) = mNoId();
/* line 295 "z.ast" */

	(* yyFP) = mNoParam();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case knoVarName: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 948 "z.ast" */

	(* yyzsymlist) = mnoZSym();
/* line 844 "z.ast" */

	(* yyCP) = mNoExp();
/* line 744 "z.ast" */

	(* yyPos) = NoPosition;
/* line 574 "z.ast" */

	(* yyNL) = mNoName();
/* line 454 "z.ast" */

	(* yyIdL) = mNoId();
/* line 295 "z.ast" */

	(* yyFP) = mNoParam();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kvarNames: {
tZSyms VarNameyyLocalsOut;
tTree VarNameyyDeclsOut;
tTree VarNameyyVisOut;
tTree VarNameyyPredOut;
tTree VarNameyyMListOut;
tZSyms VarNameyyRListOut;
tTree VarNameyyFP;
tIdPos VarNameyyId;
tIdPos VarNameyyVarDec;
tIdPos VarNameyySumId;
tTree NextyyFP;
tTree NextyyIdL;
tTree NextyyNL;
tPosition NextyyPos;
tTree NextyyCP;
tZSyms Nextyyzsymlist;
yyVisit1VarName (yyt->varNames.VarName, & (* yyLocalsIn), & VarNameyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & VarNameyyDeclsOut, & (* yyVisIn), & VarNameyyVisOut, & (* yyPredIn), & VarNameyyPredOut, & (* yyMListIn), & VarNameyyMListOut, & (* yyIsLocal), & (* yyRListIn), & VarNameyyRListOut, & VarNameyyFP, & VarNameyyId, & (* yyPos), & VarNameyyVarDec, & VarNameyySumId);
yyVisit1VarNameSeq (yyt->varNames.Next, & VarNameyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & VarNameyyDeclsOut, & (* yyDeclsOut), & VarNameyyVisOut, & (* yyVisOut), & VarNameyyPredOut, & (* yyPredOut), & VarNameyyMListOut, & (* yyMListOut), & (* yyIsLocal), & VarNameyyRListOut, & (* yyRListOut), & NextyyFP, & NextyyIdL, & NextyyNL, & NextyyPos, & NextyyCP, & Nextyyzsymlist);
/* line 950 "z.ast" */

	(* yyzsymlist) = mzSym(VarNameyyVarDec,Nextyyzsymlist);
/* line 846 "z.ast" */

	(* yyCP) = mCartProd(mNoExp(),CatExpressionList(NextyyCP,mVariable(mNoExp(),mId(mNoId(),VarNameyyId,ID))));
/* line 577 "z.ast" */

	if (ZTree_IsType(yyt->varNames.VarName,kZId))
		(* yyNL) = mName(NextyyNL,mId(mNoId(),VarNameyyId,ID));
	else
		(* yyNL) = mName(NextyyNL,mId(mNoId(),VarNameyyId,OPNAME));
/* line 456 "z.ast" */

	(* yyIdL) = mId(NextyyIdL,VarNameyyId,ID);
/* line 297 "z.ast" */

	(* yyFP) = mTyParam(NextyyFP,VarNameyyId,false);
} break;
 default: ;
 }
}

static void yyVisit1ExpressionSeq
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tTree (* yyEL))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyEL)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tTree (* yyEL);
# endif
{
 switch (yyt->Kind) {
case kExpressionSeq: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 821 "z.ast" */

	(* yyEL) = mNoExp();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case knoExpSeq: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 821 "z.ast" */

	(* yyEL) = mNoExp();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kexpSeq: {
tZSyms ExpressionyyLocalsOut;
tTree ExpressionyyDeclsOut;
tTree ExpressionyyVisOut;
tTree ExpressionyyPredOut;
tTree ExpressionyyMListOut;
tZSyms ExpressionyyRListOut;
tTree ExpressionyyEL;
tTree NextyyEL;
yyVisit1Expression (yyt->expSeq.Expression, & (* yyLocalsIn), & ExpressionyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & ExpressionyyDeclsOut, & (* yyVisIn), & ExpressionyyVisOut, & (* yyPredIn), & ExpressionyyPredOut, & (* yyMListIn), & ExpressionyyMListOut, & (* yyIsLocal), & (* yyRListIn), & ExpressionyyRListOut, & ExpressionyyEL);
yyVisit1ExpressionSeq (yyt->expSeq.Next, & ExpressionyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & ExpressionyyDeclsOut, & (* yyDeclsOut), & ExpressionyyVisOut, & (* yyVisOut), & ExpressionyyPredOut, & (* yyPredOut), & ExpressionyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ExpressionyyRListOut, & (* yyRListOut), & NextyyEL);
/* line 823 "z.ast" */

	(* yyEL) = CatExpressionList(NextyyEL,ExpressionyyEL);
} break;
 default: ;
 }
}

static void yyVisit1RenameSeq
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tTree (* yyRL) ,tZSyms (* yyzsymlist))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyRL, yyzsymlist)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tTree (* yyRL);
 tZSyms (* yyzsymlist);
# endif
{
 switch (yyt->Kind) {
case kRenameSeq: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 953 "z.ast" */

	(* yyzsymlist) = mnoZSym();
/* line 683 "z.ast" */

	(* yyRL) = mNoRename();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case knoRename: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 953 "z.ast" */

	(* yyzsymlist) = mnoZSym();
/* line 683 "z.ast" */

	(* yyRL) = mNoRename();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case krenames: {
tZSyms VarRenameyyLocalsOut;
tTree VarRenameyyDeclsOut;
tTree VarRenameyyVisOut;
tTree VarRenameyyPredOut;
tTree VarRenameyyMListOut;
tZSyms VarRenameyyRListOut;
tIdPos VarRenameyynew;
tIdPos VarRenameyyold;
tIdPos VarRenameyyIdent;
tTree NextyyRL;
tZSyms Nextyyzsymlist;
yyVisit1VarRename (yyt->renames.VarRename, & (* yyLocalsIn), & VarRenameyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & VarRenameyyDeclsOut, & (* yyVisIn), & VarRenameyyVisOut, & (* yyPredIn), & VarRenameyyPredOut, & (* yyMListIn), & VarRenameyyMListOut, & (* yyIsLocal), & (* yyRListIn), & VarRenameyyRListOut, & VarRenameyynew, & VarRenameyyold, & VarRenameyyIdent);
yyVisit1RenameSeq (yyt->renames.Next, & VarRenameyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & VarRenameyyDeclsOut, & (* yyDeclsOut), & VarRenameyyVisOut, & (* yyVisOut), & VarRenameyyPredOut, & (* yyPredOut), & VarRenameyyMListOut, & (* yyMListOut), & (* yyIsLocal), & VarRenameyyRListOut, & (* yyRListOut), & NextyyRL, & Nextyyzsymlist);
/* line 955 "z.ast" */

	(* yyzsymlist) = mzSym(VarRenameyyIdent,Nextyyzsymlist);
/* line 685 "z.ast" */

	(* yyRL) = mRename(NextyyRL,VarRenameyynew,mId(mNoId(),VarRenameyyold,ID));
} break;
 default: ;
 }
}

static void yyVisit1VarRename
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tIdPos (* yynew) ,tIdPos (* yyold) ,tIdPos (* yyIdent))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yynew, yyold, yyIdent)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tIdPos (* yynew);
 tIdPos (* yyold);
 tIdPos (* yyIdent);
# endif
{
 switch (yyt->Kind) {
case kVarRename: {
tZSyms NewyyLocalsOut;
tTree NewyyDeclsOut;
tTree NewyyVisOut;
tTree NewyyPredOut;
tTree NewyyMListOut;
tZSyms NewyyRListOut;
tTree NewyyFP;
tPosition NewyyPos;
tIdPos NewyySumId;
tTree OldyyFP;
tPosition OldyyPos;
tIdPos OldyyVarDec;
tIdPos OldyySumId;
yyVisit1VarName (yyt->VarRename.New, & (* yyLocalsIn), & NewyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & NewyyDeclsOut, & (* yyVisIn), & NewyyVisOut, & (* yyPredIn), & NewyyPredOut, & (* yyMListIn), & NewyyMListOut, & (* yyIsLocal), & (* yyRListIn), & NewyyRListOut, & NewyyFP, & (* yynew), & NewyyPos, & (* yyIdent), & NewyySumId);
yyVisit1VarName (yyt->VarRename.Old, & NewyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & NewyyDeclsOut, & (* yyDeclsOut), & NewyyVisOut, & (* yyVisOut), & NewyyPredOut, & (* yyPredOut), & NewyyMListOut, & (* yyMListOut), & (* yyIsLocal), & NewyyRListOut, & (* yyRListOut), & OldyyFP, & (* yyold), & OldyyPos, & OldyyVarDec, & OldyySumId);
} break;
 default: ;
 }
}

static void yyVisit1ZSchemaText
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tPosition (* yyPos) ,tTree (* yySch))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyPos, yySch)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tPosition (* yyPos);
 tTree (* yySch);
# endif
{
 switch (yyt->Kind) {
case kZSchemaText: {
tTree DeclarationyyVisOut;
tTree DeclarationyyPredOut;
tTree DeclarationyyMListOut;
tZSyms DeclarationyyRListOut;
tZSyms PredicateyyLocalsIn;
tZSyms PredicateyyLocalsOut;
tZSyms PredicateyyEnv;
tTree PredicateyyDeclsIn;
tTree PredicateyyDeclsOut;
tTree PredicateyyPredIn;
tTree PredicateyyPredOut;
/* line 963 "z.ast" */

	PredicateyyLocalsIn = mno_symbol();
yyVisit1Declaration (yyt->ZSchemaText.Declaration, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & DeclarationyyVisOut, & (* yyPredIn), & DeclarationyyPredOut, & (* yyMListIn), & DeclarationyyMListOut, & (* yyIsLocal), & (* yyRListIn), & DeclarationyyRListOut, & (* yyPos));
/* line 483 "z.ast" */

	if ((* yyvarkind)==Is_schema_field)
		PredicateyyPredIn = MergePredsFromSchematext((* yyLocalsOut),currentMod,false);
	else PredicateyyPredIn = mNoPred();
/* line 378 "z.ast" */

	PredicateyyDeclsIn = mNoDecl();
/* line 962 "z.ast" */

	PredicateyyEnv = mscope_env((* yyLocalsOut),(* yyEnv));
yyVisit1Predicate (yyt->ZSchemaText.Predicate, & PredicateyyLocalsIn, & PredicateyyLocalsOut, & PredicateyyEnv, & (* yyvarkind), & PredicateyyDeclsIn, & PredicateyyDeclsOut, & DeclarationyyVisOut, & (* yyVisOut), & PredicateyyPredIn, & PredicateyyPredOut, & DeclarationyyMListOut, & (* yyMListOut), & (* yyIsLocal), & DeclarationyyRListOut, & (* yyRListOut));
/* line 817 "z.ast" */

	(* yySch) = mSchemaText(ReverseTree(CopyTree((* yyDeclsOut))),PredicateyyPredOut,(* yyIsLocal));
/* line 487 "z.ast" */

	(* yyPredOut) = PredFromXi(yyt->ZSchemaText.Declaration,(* yyLocalsIn),(* yyEnv),currentMod,PredicateyyPredOut);
} break;
 default: ;
 }
}

static void yyVisit1Declaration
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tPosition (* yyPos))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyPos)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tPosition (* yyPos);
# endif
{
 switch (yyt->Kind) {
case kDeclaration: {
(* yyVisOut) =(* yyVisIn);
/* line 732 "z.ast" */

	(* yyPos) = NoPosition;
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyDeclsOut) =(* yyDeclsIn);
(* yyLocalsOut) =(* yyLocalsIn);
} break;
case knoDecl: {
(* yyVisOut) =(* yyVisIn);
/* line 732 "z.ast" */

	(* yyPos) = NoPosition;
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyDeclsOut) =(* yyDeclsIn);
(* yyLocalsOut) =(* yyLocalsIn);
} break;
case kdecl: {
tZSyms BasicDeclyyLocalsOut;
tTree BasicDeclyyDeclsOut;
tTree BasicDeclyyVisOut;
tTree BasicDeclyyPredOut;
tTree BasicDeclyyMListOut;
tZSyms BasicDeclyyRListOut;
tPosition NextyyPos;
yyVisit1BasicDecl (yyt->decl.BasicDecl, & (* yyLocalsIn), & BasicDeclyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & BasicDeclyyDeclsOut, & (* yyVisIn), & BasicDeclyyVisOut, & (* yyPredIn), & BasicDeclyyPredOut, & (* yyMListIn), & BasicDeclyyMListOut, & (* yyIsLocal), & (* yyRListIn), & BasicDeclyyRListOut, & (* yyPos));
yyVisit1Declaration (yyt->decl.Next, & BasicDeclyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & BasicDeclyyDeclsOut, & (* yyDeclsOut), & BasicDeclyyVisOut, & (* yyVisOut), & BasicDeclyyPredOut, & (* yyPredOut), & BasicDeclyyMListOut, & (* yyMListOut), & (* yyIsLocal), & BasicDeclyyRListOut, & (* yyRListOut), & NextyyPos);
} break;
 default: ;
 }
}

static void yyVisit1BasicDecl
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tPosition (* yyPos))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyPos)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tPosition (* yyPos);
# endif
{
 switch (yyt->Kind) {
case kBasicDecl: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 737 "z.ast" */

	(* yyPos) = NoPosition;
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kcolonDecl: {
tZSyms VarNameSeqyyLocalsOut;
tTree VarNameSeqyyDeclsOut;
tTree VarNameSeqyyVisOut;
tTree VarNameSeqyyPredOut;
tTree VarNameSeqyyMListOut;
tZSyms VarNameSeqyyRListOut;
tTree VarNameSeqyyFP;
tTree VarNameSeqyyIdL;
tTree VarNameSeqyyNL;
tTree VarNameSeqyyCP;
tZSyms VarNameSeqyyzsymlist;
tZSyms ExpressionyyLocalsIn;
tZSyms ExpressionyyLocalsOut;
tZSyms ExpressionyyEnv;
tTree ExpressionyyDeclsOut;
tTree ExpressionyyEL;
yyVisit1VarNameSeq (yyt->colonDecl.VarNameSeq, & (* yyLocalsIn), & VarNameSeqyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & VarNameSeqyyDeclsOut, & (* yyVisIn), & VarNameSeqyyVisOut, & (* yyPredIn), & VarNameSeqyyPredOut, & (* yyMListIn), & VarNameSeqyyMListOut, & (* yyIsLocal), & (* yyRListIn), & VarNameSeqyyRListOut, & VarNameSeqyyFP, & VarNameSeqyyIdL, & VarNameSeqyyNL, & (* yyPos), & VarNameSeqyyCP, & VarNameSeqyyzsymlist);
/* line 969 "z.ast" */

	(* yyLocalsOut) = AddVarSeq(VarNameSeqyyzsymlist,(* yyLocalsIn),currentMod);
/* line 967 "z.ast" */

	ExpressionyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 968 "z.ast" */

	ExpressionyyLocalsIn = mno_symbol();
yyVisit1Expression (yyt->colonDecl.Expression, & ExpressionyyLocalsIn, & ExpressionyyLocalsOut, & ExpressionyyEnv, & (* yyvarkind), & VarNameSeqyyDeclsOut, & ExpressionyyDeclsOut, & VarNameSeqyyVisOut, & (* yyVisOut), & VarNameSeqyyPredOut, & (* yyPredOut), & VarNameSeqyyMListOut, & (* yyMListOut), & (* yyIsLocal), & VarNameSeqyyRListOut, & (* yyRListOut), & ExpressionyyEL);
/* line 382 "z.ast" */

	(* yyDeclsOut) = mVarDecl((* yyDeclsIn),VarNameSeqyyIdL,ExpressionyyEL,(* yyvarkind));
} break;
case kschemaRef: {
tZSyms DesignatoryyLocalsOut;
tTree DesignatoryyDeclsOut;
tIdPos DesignatoryyName;
tIdPos Designatoryymodname;
tTree DesignatoryyParamList;
tTree DesignatoryySch;
tZTree DesignatoryyDes;
tTree DesignatoryyEL;
tTree DesignatoryyDesEL;
tZTree DesignatoryyRS;
tIdPos DesignatoryyIdent;
tIdPos DesignatoryyId;
yyVisit1Designator (yyt->schemaRef.Designator, & (* yyLocalsIn), & DesignatoryyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & DesignatoryyDeclsOut, & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & DesignatoryyName, & Designatoryymodname, & DesignatoryyParamList, & (* yyPos), & DesignatoryySch, & DesignatoryyDes, & DesignatoryyEL, & DesignatoryyDesEL, & DesignatoryyRS, & DesignatoryyIdent, & DesignatoryyId);
/* line 971 "z.ast" */

	(* yyLocalsOut) = AddIncludedLocals(DesignatoryyId,yyt->schemaRef.Designator->Designator.Decoration,(* yyLocalsIn),(* yyEnv));
/* line 386 "z.ast" */
if (! ( !IsRenamed(yyt->schemaRef.Designator) )) {Message("renaming of schema inclusion is lost",3,(* yyPos));ErrorsInTranslation++;; }
/* line 388 "z.ast" */


	if (!InTable(DesignatoryyName,(* yyLocalsIn),(* yyEnv)) && IsDeltaOrXi(DesignatoryyName)) 

		if (SameIds(Designatoryymodname,currentMod))
			(* yyDeclsOut) = mSchemaIncl(mSchemaIncl((* yyDeclsIn),mId(mNoId(),PrimeName(IdFromDeltaOrXiName(DesignatoryyName)),ID),DesignatoryyParamList),mId(mNoId(),IdFromDeltaOrXiName(DesignatoryyName),ID),DesignatoryyParamList);
		else
			(* yyDeclsOut) = mSchemaIncl(mSchemaIncl((* yyDeclsIn),mId(mId(mNoId(),PrimeName(IdFromDeltaOrXiName(DesignatoryyName)),ID),Designatoryymodname,ID),DesignatoryyParamList),mId(mId(mNoId(),IdFromDeltaOrXiName(DesignatoryyName),ID),Designatoryymodname,ID),DesignatoryyParamList);

	else if (IsDeltaOrXi(DesignatoryyName))
		if (SameIds(Designatoryymodname,currentMod))
			(* yyDeclsOut) = mSchemaIncl((* yyDeclsIn),mId(mNoId(),ReWriteDeltaOrXi(DesignatoryyName),ID),DesignatoryyParamList);
		else
		(* yyDeclsOut) = mSchemaIncl((* yyDeclsIn),mId(mId(mNoId(),ReWriteDeltaOrXi(DesignatoryyName),ID),Designatoryymodname,ID),DesignatoryyParamList);

	else if (SameIds(Designatoryymodname,currentMod))
		(* yyDeclsOut) = mSchemaIncl((* yyDeclsIn),mId(mNoId(),DesignatoryyName,ID),DesignatoryyParamList);
		else
		(* yyDeclsOut) = mSchemaIncl((* yyDeclsIn),mId(mId(mNoId(),DesignatoryyName,ID),Designatoryymodname,ID),DesignatoryyParamList);
} break;
 default: ;
 }
}

static void yyVisit1Predicate
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
# endif
{
 switch (yyt->Kind) {
case kPredicate: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case knoPred: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kpredNegate: {
tTree PredicateyyPredOut;
yyVisit1Predicate (yyt->predNegate.Predicate, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & PredicateyyPredOut, & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut));
/* line 757 "z.ast" */

	(* yyPredOut) = mLogicalNot((* yyPredIn),PredicateyyPredOut);
} break;
case kpredInfixRelSeq: {
tTree PredInfixRelSeqyyDeclsIn;
tTree PredInfixRelSeqyyDeclsOut;
tTree PredInfixRelSeqyyPredIn;
tTree PredInfixRelSeqyyPredOut;
/* line 759 "z.ast" */

	PredInfixRelSeqyyPredIn = mNoPred();
/* line 760 "z.ast" */

	PredInfixRelSeqyyDeclsIn = mNoDecl();
yyVisit1PredInfixRelSeq (yyt->predInfixRelSeq.PredInfixRelSeq, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & PredInfixRelSeqyyDeclsIn, & PredInfixRelSeqyyDeclsOut, & (* yyVisIn), & (* yyVisOut), & PredInfixRelSeqyyPredIn, & PredInfixRelSeqyyPredOut, & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut));
/* line 762 "z.ast" */

	(* yyPredOut) = CatPredList((* yyPredIn),ReverseTree(PredInfixRelSeqyyPredOut));
/* line 761 "z.ast" */
(* yyDeclsOut) = (* yyDeclsIn);
} break;
case kpredTrueOrFalse: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
/* line 764 "z.ast" */

	(* yyPredOut) = mBoolValue((* yyPredIn),ZMakeIdPos(DeMap(IdPosId(yyt->predTrueOrFalse.TrueFalse)),IdPosPos(yyt->predTrueOrFalse.TrueFalse)));
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kpredSchemaRef: {
tTree DesignatoryyPredOut;
tIdPos DesignatoryyName;
tIdPos Designatoryymodname;
tTree DesignatoryyParamList;
tPosition DesignatoryyPos;
tTree DesignatoryySch;
tZTree DesignatoryyDes;
tTree DesignatoryyEL;
tTree DesignatoryyDesEL;
tZTree DesignatoryyRS;
tIdPos DesignatoryyIdent;
tIdPos DesignatoryyId;
yyVisit1Designator (yyt->predSchemaRef.Designator, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & DesignatoryyPredOut, & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & DesignatoryyName, & Designatoryymodname, & DesignatoryyParamList, & DesignatoryyPos, & DesignatoryySch, & DesignatoryyDes, & DesignatoryyEL, & DesignatoryyDesEL, & DesignatoryyRS, & DesignatoryyIdent, & DesignatoryyId);
/* line 766 "z.ast" */

	if (IsPre(yyt->predSchemaRef.PredOrPre))
		(* yyPredOut) = mPreCondPred((* yyPredIn),mSchemaPred(mNoPred(),DesignatoryySch));
	else
		(* yyPredOut) = mSchemaPred((* yyPredIn),DesignatoryySch);
} break;
case kpredPreRel: {
tZSyms DecorationyyLocalsOut;
tTree DecorationyyDeclsOut;
tTree DecorationyyVisOut;
tTree DecorationyyPredOut;
tTree DecorationyyMListOut;
tZSyms DecorationyyRListOut;
tTree ExpressionyyPredOut;
tTree ExpressionyyEL;
yyVisit1Decoration (yyt->predPreRel.Decoration, & (* yyLocalsIn), & DecorationyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & DecorationyyDeclsOut, & (* yyVisIn), & DecorationyyVisOut, & (* yyPredIn), & DecorationyyPredOut, & (* yyMListIn), & DecorationyyMListOut, & (* yyIsLocal), & (* yyRListIn), & DecorationyyRListOut);
yyVisit1Expression (yyt->predPreRel.Expression, & DecorationyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & DecorationyyDeclsOut, & (* yyDeclsOut), & DecorationyyVisOut, & (* yyVisOut), & DecorationyyPredOut, & ExpressionyyPredOut, & DecorationyyMListOut, & (* yyMListOut), & (* yyIsLocal), & DecorationyyRListOut, & (* yyRListOut), & ExpressionyyEL);
/* line 772 "z.ast" */

	(* yyPredOut) = mRelPrePred((* yyPredIn),ZMakeIdPos(DeMap(IdPosId(IdDecCat(yyt->predPreRel.PreRel,yyt->predPreRel.Decoration))),IdPosPos(yyt->predPreRel.PreRel)),ExpressionyyEL);
} break;
case kpredCons: {
tZSyms LpredyyLocalsOut;
tTree LpredyyDeclsOut;
tTree LpredyyVisOut;
tTree LpredyyPredIn;
tTree LpredyyPredOut;
tTree LpredyyMListOut;
tZSyms LpredyyRListOut;
tTree RpredyyPredIn;
tTree RpredyyPredOut;
/* line 774 "z.ast" */

	LpredyyPredIn = mNoPred();
yyVisit1Predicate (yyt->predCons.Lpred, & (* yyLocalsIn), & LpredyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & LpredyyDeclsOut, & (* yyVisIn), & LpredyyVisOut, & LpredyyPredIn, & LpredyyPredOut, & (* yyMListIn), & LpredyyMListOut, & (* yyIsLocal), & (* yyRListIn), & LpredyyRListOut);
/* line 775 "z.ast" */

	RpredyyPredIn = mNoPred();
yyVisit1Predicate (yyt->predCons.Rpred, & LpredyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & LpredyyDeclsOut, & (* yyDeclsOut), & LpredyyVisOut, & (* yyVisOut), & RpredyyPredIn, & RpredyyPredOut, & LpredyyMListOut, & (* yyMListOut), & (* yyIsLocal), & LpredyyRListOut, & (* yyRListOut));
/* line 776 "z.ast" */

	if (IsEol(yyt->predCons.LogOp))

		(* yyPredOut) = mLogBinPred((* yyPredIn),LpredyyPredOut,mLogAnd(),RpredyyPredOut);
	else 
		(* yyPredOut) = mLogBinPred((* yyPredIn),LpredyyPredOut,LogBinOpFromLogOp(yyt->predCons.LogOp),RpredyyPredOut);
} break;
case kpredQuant: {
tZSyms ZSchemaTextyyLocalsOut;
int ZSchemaTextyyvarkind;
tTree ZSchemaTextyyDeclsIn;
tTree ZSchemaTextyyDeclsOut;
tTree ZSchemaTextyyVisOut;
tTree ZSchemaTextyyPredIn;
tTree ZSchemaTextyyPredOut;
tTree ZSchemaTextyyMListOut;
bool ZSchemaTextyyIsLocal;
tZSyms ZSchemaTextyyRListOut;
tPosition ZSchemaTextyyPos;
tTree ZSchemaTextyySch;
tTree PredicateyyDeclsIn;
tTree PredicateyyDeclsOut;
tTree PredicateyyPredIn;
tTree PredicateyyPredOut;
/* line 788 "z.ast" */

	ZSchemaTextyyDeclsIn = mNoDecl();
/* line 786 "z.ast" */

	ZSchemaTextyyIsLocal = true;
/* line 787 "z.ast" */

	ZSchemaTextyyPredIn = mNoPred();
/* line 785 "z.ast" */

	ZSchemaTextyyvarkind = Is_local_id;
yyVisit1ZSchemaText (yyt->predQuant.ZSchemaText, & (* yyLocalsIn), & ZSchemaTextyyLocalsOut, & (* yyEnv), & ZSchemaTextyyvarkind, & ZSchemaTextyyDeclsIn, & ZSchemaTextyyDeclsOut, & (* yyVisIn), & ZSchemaTextyyVisOut, & ZSchemaTextyyPredIn, & ZSchemaTextyyPredOut, & (* yyMListIn), & ZSchemaTextyyMListOut, & ZSchemaTextyyIsLocal, & (* yyRListIn), & ZSchemaTextyyRListOut, & ZSchemaTextyyPos, & ZSchemaTextyySch);
/* line 784 "z.ast" */

	PredicateyyPredIn = mNoPred();
/* line 789 "z.ast" */

	PredicateyyDeclsIn = mNoDecl();
yyVisit1Predicate (yyt->predQuant.Predicate, & ZSchemaTextyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & PredicateyyDeclsIn, & PredicateyyDeclsOut, & ZSchemaTextyyVisOut, & (* yyVisOut), & PredicateyyPredIn, & PredicateyyPredOut, & ZSchemaTextyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ZSchemaTextyyRListOut, & (* yyRListOut));
/* line 791 "z.ast" */

	(* yyPredOut) = mQuantPred((* yyPredIn),ZMakeIdPos(DeMap(IdPosId(yyt->predQuant.LogQuant)),IdPosPos(yyt->predQuant.LogQuant)),ZSchemaTextyySch,PredicateyyPredOut);
/* line 790 "z.ast" */
(* yyDeclsOut) = (* yyDeclsIn);
} break;
case kpredLet: {
tZSyms LetDefSeqyyLocalsOut;
tTree LetDefSeqyyDeclsIn;
tTree LetDefSeqyyDeclsOut;
tTree LetDefSeqyyVisOut;
tTree LetDefSeqyyPredOut;
tTree LetDefSeqyyMListOut;
tZSyms LetDefSeqyyRListOut;
tPosition LetDefSeqyyPos;
tTree PredicateyyDeclsOut;
tTree PredicateyyPredIn;
tTree PredicateyyPredOut;
/* line 794 "z.ast" */

	LetDefSeqyyDeclsIn = mNoDecl();
yyVisit1LetDefSeq (yyt->predLet.LetDefSeq, & (* yyLocalsIn), & LetDefSeqyyLocalsOut, & (* yyEnv), & (* yyvarkind), & LetDefSeqyyDeclsIn, & LetDefSeqyyDeclsOut, & (* yyVisIn), & LetDefSeqyyVisOut, & (* yyPredIn), & LetDefSeqyyPredOut, & (* yyMListIn), & LetDefSeqyyMListOut, & (* yyIsLocal), & (* yyRListIn), & LetDefSeqyyRListOut, & LetDefSeqyyPos);
/* line 793 "z.ast" */

	PredicateyyPredIn = mNoPred();
yyVisit1Predicate (yyt->predLet.Predicate, & LetDefSeqyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & LetDefSeqyyDeclsOut, & PredicateyyDeclsOut, & LetDefSeqyyVisOut, & (* yyVisOut), & PredicateyyPredIn, & PredicateyyPredOut, & LetDefSeqyyMListOut, & (* yyMListOut), & (* yyIsLocal), & LetDefSeqyyRListOut, & (* yyRListOut));
/* line 796 "z.ast" */

	(* yyPredOut) = (* yyPredIn);
	Message("let predicate is not handled in Sum",3,LetDefSeqyyPos);
	ErrorsInTranslation++;
/* line 795 "z.ast" */
(* yyDeclsOut) = (* yyDeclsIn);
} break;
case kpredParen: {
yyVisit1Predicate (yyt->predParen.Predicate, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut));
} break;
 default: ;
 }
}

static void yyVisit1PredInfixRelSeq
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
# endif
{
 switch (yyt->Kind) {
case kPredInfixRelSeq: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case knoInfixRel: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kinfixRels: {
tZSyms PredInfixRelyyLocalsOut;
tTree PredInfixRelyyDeclsOut;
tTree PredInfixRelyyVisOut;
tTree PredInfixRelyyPredOut;
tTree PredInfixRelyyMListOut;
tZSyms PredInfixRelyyRListOut;
tIdPos PredInfixRelyyId;
yyVisit1PredInfixRel (yyt->infixRels.PredInfixRel, & (* yyLocalsIn), & PredInfixRelyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & PredInfixRelyyDeclsOut, & (* yyVisIn), & PredInfixRelyyVisOut, & (* yyPredIn), & PredInfixRelyyPredOut, & (* yyMListIn), & PredInfixRelyyMListOut, & (* yyIsLocal), & (* yyRListIn), & PredInfixRelyyRListOut, & PredInfixRelyyId);
yyVisit1PredInfixRelSeq (yyt->infixRels.Next, & PredInfixRelyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & PredInfixRelyyDeclsOut, & (* yyDeclsOut), & PredInfixRelyyVisOut, & (* yyVisOut), & PredInfixRelyyPredOut, & (* yyPredOut), & PredInfixRelyyMListOut, & (* yyMListOut), & (* yyIsLocal), & PredInfixRelyyRListOut, & (* yyRListOut));
} break;
 default: ;
 }
}

static void yyVisit1PredInfixRel
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tIdPos (* yyId))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyId)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tIdPos (* yyId);
# endif
{
 switch (yyt->Kind) {
case kPredInfixRel: {
tZSyms LexpyyLocalsOut;
tTree LexpyyDeclsOut;
tTree LexpyyVisOut;
tTree LexpyyPredOut;
tTree LexpyyMListOut;
tZSyms LexpyyRListOut;
tTree LexpyyEL;
tZSyms InfixRelyyLocalsOut;
tTree InfixRelyyDeclsOut;
tTree InfixRelyyVisOut;
tTree InfixRelyyPredOut;
tTree InfixRelyyMListOut;
tZSyms InfixRelyyRListOut;
tTree RexpyyPredOut;
tTree RexpyyEL;
yyVisit1Expression (yyt->PredInfixRel.Lexp, & (* yyLocalsIn), & LexpyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & LexpyyDeclsOut, & (* yyVisIn), & LexpyyVisOut, & (* yyPredIn), & LexpyyPredOut, & (* yyMListIn), & LexpyyMListOut, & (* yyIsLocal), & (* yyRListIn), & LexpyyRListOut, & LexpyyEL);
yyVisit1InfixRel (yyt->PredInfixRel.InfixRel, & LexpyyLocalsOut, & InfixRelyyLocalsOut, & (* yyEnv), & (* yyvarkind), & LexpyyDeclsOut, & InfixRelyyDeclsOut, & LexpyyVisOut, & InfixRelyyVisOut, & LexpyyPredOut, & InfixRelyyPredOut, & LexpyyMListOut, & InfixRelyyMListOut, & (* yyIsLocal), & LexpyyRListOut, & InfixRelyyRListOut, & (* yyId));
yyVisit1Expression (yyt->PredInfixRel.Rexp, & InfixRelyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & InfixRelyyDeclsOut, & (* yyDeclsOut), & InfixRelyyVisOut, & (* yyVisOut), & InfixRelyyPredOut, & RexpyyPredOut, & InfixRelyyMListOut, & (* yyMListOut), & (* yyIsLocal), & InfixRelyyRListOut, & (* yyRListOut), & RexpyyEL);
/* line 827 "z.ast" */

	(* yyPredOut) = mRelBinPred((* yyPredIn),LexpyyEL,(* yyId),RexpyyEL);
} break;
 default: ;
 }
}

static void yyVisit1InfixRel
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tIdPos (* yyId))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyId)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tIdPos (* yyId);
# endif
{
 switch (yyt->Kind) {
case kInfixRel: {
yyVisit1Decoration (yyt->InfixRel.Decoration, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut));
/* line 830 "z.ast" */

	(* yyId) = ZMakeIdPos(DeMap(IdPosId(IdDecCat(yyt->InfixRel.InRel,yyt->InfixRel.Decoration))),IdPosPos(yyt->InfixRel.InRel));
} break;
 default: ;
 }
}

static void yyVisit1Expression
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tTree (* yyEL))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyEL)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tTree (* yyEL);
# endif
{
 switch (yyt->Kind) {
case kExpression: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 585 "z.ast" */

	(* yyEL) = mNoExp();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case knoExp: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 585 "z.ast" */

	(* yyEL) = mNoExp();
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kexpBinaryGen: {
tZSyms lexpyyLocalsOut;
tTree lexpyyDeclsIn;
tTree lexpyyDeclsOut;
tTree lexpyyVisOut;
tTree lexpyyPredOut;
tTree lexpyyMListOut;
tZSyms lexpyyRListOut;
tTree lexpyyEL;
tZSyms DecorationyyLocalsOut;
tTree DecorationyyDeclsOut;
tTree DecorationyyVisOut;
tTree DecorationyyPredOut;
tTree DecorationyyMListOut;
tZSyms DecorationyyRListOut;
tTree rexpyyDeclsIn;
tTree rexpyyEL;
/* line 587 "z.ast" */

	lexpyyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expBinaryGen.lexp, & (* yyLocalsIn), & lexpyyLocalsOut, & (* yyEnv), & (* yyvarkind), & lexpyyDeclsIn, & lexpyyDeclsOut, & (* yyVisIn), & lexpyyVisOut, & (* yyPredIn), & lexpyyPredOut, & (* yyMListIn), & lexpyyMListOut, & (* yyIsLocal), & (* yyRListIn), & lexpyyRListOut, & lexpyyEL);
yyVisit1Decoration (yyt->expBinaryGen.Decoration, & lexpyyLocalsOut, & DecorationyyLocalsOut, & (* yyEnv), & (* yyvarkind), & lexpyyDeclsOut, & DecorationyyDeclsOut, & lexpyyVisOut, & DecorationyyVisOut, & lexpyyPredOut, & DecorationyyPredOut, & lexpyyMListOut, & DecorationyyMListOut, & (* yyIsLocal), & lexpyyRListOut, & DecorationyyRListOut);
/* line 588 "z.ast" */

	rexpyyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expBinaryGen.rexp, & DecorationyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & rexpyyDeclsIn, & (* yyDeclsOut), & DecorationyyVisOut, & (* yyVisOut), & DecorationyyPredOut, & (* yyPredOut), & DecorationyyMListOut, & (* yyMListOut), & (* yyIsLocal), & DecorationyyRListOut, & (* yyRListOut), & rexpyyEL);
/* line 589 "z.ast" */

	(* yyEL) = mInfixOp(mNoExp(),lexpyyEL,ZMakeIdPos(DeMap(IdPosId(IdDecCat(yyt->expBinaryGen.InGen,yyt->expBinaryGen.Decoration))),IdPosPos(yyt->expBinaryGen.InGen)),rexpyyEL);
} break;
case kexpBinaryFun: {
tZSyms lexpyyLocalsOut;
tTree lexpyyDeclsIn;
tTree lexpyyDeclsOut;
tTree lexpyyVisOut;
tTree lexpyyPredOut;
tTree lexpyyMListOut;
tZSyms lexpyyRListOut;
tTree lexpyyEL;
tZSyms DecorationyyLocalsOut;
tTree DecorationyyDeclsOut;
tTree DecorationyyVisOut;
tTree DecorationyyPredOut;
tTree DecorationyyMListOut;
tZSyms DecorationyyRListOut;
tTree rexpyyDeclsIn;
tTree rexpyyEL;
/* line 591 "z.ast" */

	lexpyyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expBinaryFun.lexp, & (* yyLocalsIn), & lexpyyLocalsOut, & (* yyEnv), & (* yyvarkind), & lexpyyDeclsIn, & lexpyyDeclsOut, & (* yyVisIn), & lexpyyVisOut, & (* yyPredIn), & lexpyyPredOut, & (* yyMListIn), & lexpyyMListOut, & (* yyIsLocal), & (* yyRListIn), & lexpyyRListOut, & lexpyyEL);
yyVisit1Decoration (yyt->expBinaryFun.Decoration, & lexpyyLocalsOut, & DecorationyyLocalsOut, & (* yyEnv), & (* yyvarkind), & lexpyyDeclsOut, & DecorationyyDeclsOut, & lexpyyVisOut, & DecorationyyVisOut, & lexpyyPredOut, & DecorationyyPredOut, & lexpyyMListOut, & DecorationyyMListOut, & (* yyIsLocal), & lexpyyRListOut, & DecorationyyRListOut);
/* line 592 "z.ast" */

	rexpyyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expBinaryFun.rexp, & DecorationyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & rexpyyDeclsIn, & (* yyDeclsOut), & DecorationyyVisOut, & (* yyVisOut), & DecorationyyPredOut, & (* yyPredOut), & DecorationyyMListOut, & (* yyMListOut), & (* yyIsLocal), & DecorationyyRListOut, & (* yyRListOut), & rexpyyEL);
/* line 593 "z.ast" */

	(* yyEL) = mInfixOp(mNoExp(),lexpyyEL,ZMakeIdPos(DeMap(IdPosId(IdDecCat(yyt->expBinaryFun.InFun,yyt->expBinaryFun.Decoration))),IdPosPos(yyt->expBinaryFun.InFun)),rexpyyEL);
} break;
case kexpLiteral: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 595 "z.ast" */

	(* yyEL) = mLiteral(mNoExp(),yyt->expLiteral.Literal);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kexpOpname: {
tZSyms VarNameyyLocalsOut;
tTree VarNameyyDeclsOut;
tTree VarNameyyVisOut;
tTree VarNameyyPredOut;
tTree VarNameyyMListOut;
tZSyms VarNameyyRListOut;
tTree VarNameyyFP;
tIdPos VarNameyyId;
tPosition VarNameyyPos;
tIdPos VarNameyyVarDec;
tIdPos VarNameyySumId;
tTree ExpressionSeqyyEL;
yyVisit1VarName (yyt->expOpname.VarName, & (* yyLocalsIn), & VarNameyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & VarNameyyDeclsOut, & (* yyVisIn), & VarNameyyVisOut, & (* yyPredIn), & VarNameyyPredOut, & (* yyMListIn), & VarNameyyMListOut, & (* yyIsLocal), & (* yyRListIn), & VarNameyyRListOut, & VarNameyyFP, & VarNameyyId, & VarNameyyPos, & VarNameyyVarDec, & VarNameyySumId);
yyVisit1ExpressionSeq (yyt->expOpname.ExpressionSeq, & VarNameyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & VarNameyyDeclsOut, & (* yyDeclsOut), & VarNameyyVisOut, & (* yyVisOut), & VarNameyyPredOut, & (* yyPredOut), & VarNameyyMListOut, & (* yyMListOut), & (* yyIsLocal), & VarNameyyRListOut, & (* yyRListOut), & ExpressionSeqyyEL);
/* line 597 "z.ast" */

	(* yyEL) = mVariable(mNoExp(),mId(mNoId(),VarNameyyId,OPNAME));
	Message("any actual parameters may be lost",4,VarNameyyPos);
} break;
case kexpSetElab: {
tTree ExpressionSeqyyEL;
yyVisit1ExpressionSeq (yyt->expSetElab.ExpressionSeq, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & ExpressionSeqyyEL);
/* line 601 "z.ast" */

	(* yyEL) = mSetElab(mNoExp(),ExpressionSeqyyEL);
} break;
case kexpSeqElab: {
tTree ExpressionSeqyyEL;
yyVisit1ExpressionSeq (yyt->expSeqElab.ExpressionSeq, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & ExpressionSeqyyEL);
/* line 603 "z.ast" */

	(* yyEL) = mSequence(mNoExp(),ExpressionSeqyyEL);
} break;
case kexpBagElab: {
tTree ExpressionSeqyyEL;
yyVisit1ExpressionSeq (yyt->expBagElab.ExpressionSeq, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & ExpressionSeqyyEL);
/* line 605 "z.ast" */

	(* yyEL) = mBag(mNoExp(),ExpressionSeqyyEL);
} break;
case kexpSetComp: {
tZSyms ZSchemaTextyyLocalsOut;
int ZSchemaTextyyvarkind;
tTree ZSchemaTextyyDeclsIn;
tTree ZSchemaTextyyDeclsOut;
tTree ZSchemaTextyyVisOut;
tTree ZSchemaTextyyPredOut;
tTree ZSchemaTextyyMListOut;
bool ZSchemaTextyyIsLocal;
tZSyms ZSchemaTextyyRListOut;
tPosition ZSchemaTextyyPos;
tTree ZSchemaTextyySch;
tTree ExpressionyyDeclsIn;
tTree ExpressionyyEL;
/* line 609 "z.ast" */

	ZSchemaTextyyDeclsIn = mNoDecl();
/* line 612 "z.ast" */

	ZSchemaTextyyIsLocal = true;
/* line 611 "z.ast" */

	ZSchemaTextyyvarkind = Is_local_id;
yyVisit1ZSchemaText (yyt->expSetComp.ZSchemaText, & (* yyLocalsIn), & ZSchemaTextyyLocalsOut, & (* yyEnv), & ZSchemaTextyyvarkind, & ZSchemaTextyyDeclsIn, & ZSchemaTextyyDeclsOut, & (* yyVisIn), & ZSchemaTextyyVisOut, & (* yyPredIn), & ZSchemaTextyyPredOut, & (* yyMListIn), & ZSchemaTextyyMListOut, & ZSchemaTextyyIsLocal, & (* yyRListIn), & ZSchemaTextyyRListOut, & ZSchemaTextyyPos, & ZSchemaTextyySch);
/* line 610 "z.ast" */

	ExpressionyyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expSetComp.Expression, & ZSchemaTextyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & ExpressionyyDeclsIn, & (* yyDeclsOut), & ZSchemaTextyyVisOut, & (* yyVisOut), & ZSchemaTextyyPredOut, & (* yyPredOut), & ZSchemaTextyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ZSchemaTextyyRListOut, & (* yyRListOut), & ExpressionyyEL);
/* line 613 "z.ast" */

	(* yyEL) = mSetComp(mNoExp(),ZSchemaTextyySch,ExpressionyyEL);
} break;
case kexpPowerSet: {
tTree ExpressionyyEL;
yyVisit1Expression (yyt->expPowerSet.Expression, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & ExpressionyyEL);
/* line 615 "z.ast" */

	(* yyEL) = mPrefixOp(mNoExp(),ZMakeIdPos("power",NoPosition),ExpressionyyEL);
} break;
case kexpPreGen: {
tZSyms DecorationyyLocalsOut;
tTree DecorationyyDeclsOut;
tTree DecorationyyVisOut;
tTree DecorationyyPredOut;
tTree DecorationyyMListOut;
tZSyms DecorationyyRListOut;
tTree ExpressionyyEL;
yyVisit1Decoration (yyt->expPreGen.Decoration, & (* yyLocalsIn), & DecorationyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & DecorationyyDeclsOut, & (* yyVisIn), & DecorationyyVisOut, & (* yyPredIn), & DecorationyyPredOut, & (* yyMListIn), & DecorationyyMListOut, & (* yyIsLocal), & (* yyRListIn), & DecorationyyRListOut);
yyVisit1Expression (yyt->expPreGen.Expression, & DecorationyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & DecorationyyDeclsOut, & (* yyDeclsOut), & DecorationyyVisOut, & (* yyVisOut), & DecorationyyPredOut, & (* yyPredOut), & DecorationyyMListOut, & (* yyMListOut), & (* yyIsLocal), & DecorationyyRListOut, & (* yyRListOut), & ExpressionyyEL);
/* line 617 "z.ast" */

	(* yyEL) = mPrefixOp(mNoExp(),ZMakeIdPos(DeMap(IdPosId(IdDecCat(yyt->expPreGen.Pregen,yyt->expPreGen.Decoration))),IdPosPos(yyt->expPreGen.Pregen)),ExpressionyyEL);
} break;
case kexpPostFun: {
tZSyms ExpressionyyLocalsOut;
tTree ExpressionyyDeclsOut;
tTree ExpressionyyVisOut;
tTree ExpressionyyPredOut;
tTree ExpressionyyMListOut;
tZSyms ExpressionyyRListOut;
tTree ExpressionyyEL;
yyVisit1Expression (yyt->expPostFun.Expression, & (* yyLocalsIn), & ExpressionyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & ExpressionyyDeclsOut, & (* yyVisIn), & ExpressionyyVisOut, & (* yyPredIn), & ExpressionyyPredOut, & (* yyMListIn), & ExpressionyyMListOut, & (* yyIsLocal), & (* yyRListIn), & ExpressionyyRListOut, & ExpressionyyEL);
yyVisit1Decoration (yyt->expPostFun.Decoration, & ExpressionyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & ExpressionyyDeclsOut, & (* yyDeclsOut), & ExpressionyyVisOut, & (* yyVisOut), & ExpressionyyPredOut, & (* yyPredOut), & ExpressionyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ExpressionyyRListOut, & (* yyRListOut));
/* line 619 "z.ast" */

	(* yyEL) = mNoExp();
	Message("worth checking as this handling is most peculiar",3,IdPosPos(yyt->expPostFun.Postfun));
	ErrorsInTranslation++;
} break;
case kexpIter: {
tZSyms exp1yyLocalsOut;
tTree exp1yyDeclsIn;
tTree exp1yyDeclsOut;
tTree exp1yyVisOut;
tTree exp1yyPredOut;
tTree exp1yyMListOut;
tZSyms exp1yyRListOut;
tTree exp1yyEL;
tTree exp2yyDeclsIn;
tTree exp2yyEL;
/* line 624 "z.ast" */

	exp1yyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expIter.exp1, & (* yyLocalsIn), & exp1yyLocalsOut, & (* yyEnv), & (* yyvarkind), & exp1yyDeclsIn, & exp1yyDeclsOut, & (* yyVisIn), & exp1yyVisOut, & (* yyPredIn), & exp1yyPredOut, & (* yyMListIn), & exp1yyMListOut, & (* yyIsLocal), & (* yyRListIn), & exp1yyRListOut, & exp1yyEL);
/* line 625 "z.ast" */

	exp2yyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expIter.exp2, & exp1yyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & exp2yyDeclsIn, & (* yyDeclsOut), & exp1yyVisOut, & (* yyVisOut), & exp1yyPredOut, & (* yyPredOut), & exp1yyMListOut, & (* yyMListOut), & (* yyIsLocal), & exp1yyRListOut, & (* yyRListOut), & exp2yyEL);
/* line 626 "z.ast" */

	(* yyEL) = mInfixOp(mNoExp(),exp1yyEL,ZMakeIdPos("iter",NoPosition),exp2yyEL);
} break;
case kexpTuple: {
tTree ExpressionSeqyyEL;
yyVisit1ExpressionSeq (yyt->expTuple.ExpressionSeq, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & ExpressionSeqyyEL);
/* line 628 "z.ast" */

	(* yyEL) = mTuple(mNoExp(),ExpressionSeqyyEL);
} break;
case kexpCartProd: {
tTree ExpressionSeqyyEL;
yyVisit1ExpressionSeq (yyt->expCartProd.ExpressionSeq, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & ExpressionSeqyyEL);
/* line 630 "z.ast" */

	(* yyEL) = mCartProd(mNoExp(),ExpressionSeqyyEL);
} break;
case kexpTheta: {
tZSyms ZNameyyLocalsOut;
tTree ZNameyyDeclsOut;
tTree ZNameyyVisOut;
tTree ZNameyyPredOut;
tTree ZNameyyMListOut;
tZSyms ZNameyyRListOut;
tIdPos ZNameyyId;
tIdPos ZNameyySumId;
tPosition ZNameyyPos;
tZSyms DecorationyyLocalsOut;
tTree DecorationyyDeclsOut;
tTree DecorationyyVisOut;
tTree DecorationyyPredOut;
tTree DecorationyyMListOut;
tZSyms DecorationyyRListOut;
tTree RenameSeqyyRL;
tZSyms RenameSeqyyzsymlist;
yyVisit1ZName (yyt->expTheta.ZName, & (* yyLocalsIn), & ZNameyyLocalsOut, & (* yyEnv), & (* yyDeclsIn), & ZNameyyDeclsOut, & (* yyVisIn), & ZNameyyVisOut, & (* yyPredIn), & ZNameyyPredOut, & (* yyMListIn), & ZNameyyMListOut, & (* yyRListIn), & ZNameyyRListOut, & ZNameyyId, & ZNameyySumId, & ZNameyyPos);
yyVisit1Decoration (yyt->expTheta.Decoration, & ZNameyyLocalsOut, & DecorationyyLocalsOut, & (* yyEnv), & (* yyvarkind), & ZNameyyDeclsOut, & DecorationyyDeclsOut, & ZNameyyVisOut, & DecorationyyVisOut, & ZNameyyPredOut, & DecorationyyPredOut, & ZNameyyMListOut, & DecorationyyMListOut, & (* yyIsLocal), & ZNameyyRListOut, & DecorationyyRListOut);
yyVisit1RenameSeq (yyt->expTheta.RenameSeq, & DecorationyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & DecorationyyDeclsOut, & (* yyDeclsOut), & DecorationyyVisOut, & (* yyVisOut), & DecorationyyPredOut, & (* yyPredOut), & DecorationyyMListOut, & (* yyMListOut), & (* yyIsLocal), & DecorationyyRListOut, & (* yyRListOut), & RenameSeqyyRL, & RenameSeqyyzsymlist);
/* line 632 "z.ast" */
if (! ( ThetaNotRenamed(yyt->expTheta.RenameSeq) )) {
		Message("renaming is lost",4,ZNameyyPos); }
/* line 634 "z.ast" */

	(* yyEL) = mTheta(mNoExp(),mVariable(mNoExp(),mId(mNoId(),IdDecCat(yyt->expTheta.ZName->ZName.Ident,yyt->expTheta.Decoration),ID)));
} break;
case kexpSelectVar: {
tZSyms ExpressionyyLocalsOut;
tTree ExpressionyyDeclsOut;
tTree ExpressionyyVisOut;
tTree ExpressionyyPredOut;
tTree ExpressionyyMListOut;
tZSyms ExpressionyyRListOut;
tTree ExpressionyyEL;
tTree VarNameyyFP;
tIdPos VarNameyyId;
tPosition VarNameyyPos;
tIdPos VarNameyyVarDec;
tIdPos VarNameyySumId;
yyVisit1Expression (yyt->expSelectVar.Expression, & (* yyLocalsIn), & ExpressionyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & ExpressionyyDeclsOut, & (* yyVisIn), & ExpressionyyVisOut, & (* yyPredIn), & ExpressionyyPredOut, & (* yyMListIn), & ExpressionyyMListOut, & (* yyIsLocal), & (* yyRListIn), & ExpressionyyRListOut, & ExpressionyyEL);
yyVisit1VarName (yyt->expSelectVar.VarName, & ExpressionyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & ExpressionyyDeclsOut, & (* yyDeclsOut), & ExpressionyyVisOut, & (* yyVisOut), & ExpressionyyPredOut, & (* yyPredOut), & ExpressionyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ExpressionyyRListOut, & (* yyRListOut), & VarNameyyFP, & VarNameyyId, & VarNameyyPos, & VarNameyyVarDec, & VarNameyySumId);
/* line 636 "z.ast" */

	(* yyEL) = mVarSelection(mNoExp(),ExpressionyyEL,VarNameyyId);
} break;
case kexpFnApp: {
tZSyms FnNameyyLocalsOut;
tTree FnNameyyDeclsIn;
tTree FnNameyyDeclsOut;
tTree FnNameyyVisOut;
tTree FnNameyyPredOut;
tTree FnNameyyMListOut;
tZSyms FnNameyyRListOut;
tTree FnNameyyEL;
tTree ParamsyyDeclsIn;
tTree ParamsyyEL;
/* line 638 "z.ast" */

	FnNameyyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expFnApp.FnName, & (* yyLocalsIn), & FnNameyyLocalsOut, & (* yyEnv), & (* yyvarkind), & FnNameyyDeclsIn, & FnNameyyDeclsOut, & (* yyVisIn), & FnNameyyVisOut, & (* yyPredIn), & FnNameyyPredOut, & (* yyMListIn), & FnNameyyMListOut, & (* yyIsLocal), & (* yyRListIn), & FnNameyyRListOut, & FnNameyyEL);
/* line 639 "z.ast" */

	ParamsyyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expFnApp.Params, & FnNameyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & ParamsyyDeclsIn, & (* yyDeclsOut), & FnNameyyVisOut, & (* yyVisOut), & FnNameyyPredOut, & (* yyPredOut), & FnNameyyMListOut, & (* yyMListOut), & (* yyIsLocal), & FnNameyyRListOut, & (* yyRListOut), & ParamsyyEL);
/* line 640 "z.ast" */

	if (IsPrefixOp(FnNameyyEL))
		(* yyEL) = mPrefixOp(mNoExp(),IdPosFromFncApp(FnNameyyEL),ParamsyyEL);
	else (* yyEL) = mFncApplication(mNoExp(),FnNameyyEL,ParamsyyEL);
} break;
case kexpMu: {
tZSyms ZSchemaTextyyLocalsOut;
int ZSchemaTextyyvarkind;
tTree ZSchemaTextyyDeclsIn;
tTree ZSchemaTextyyDeclsOut;
tTree ZSchemaTextyyVisOut;
tTree ZSchemaTextyyPredOut;
tTree ZSchemaTextyyMListOut;
bool ZSchemaTextyyIsLocal;
tZSyms ZSchemaTextyyRListOut;
tPosition ZSchemaTextyyPos;
tTree ZSchemaTextyySch;
tTree ExpressionyyDeclsIn;
tTree ExpressionyyEL;
/* line 646 "z.ast" */

	ZSchemaTextyyDeclsIn = mNoDecl();
/* line 649 "z.ast" */

	ZSchemaTextyyIsLocal = true;
/* line 648 "z.ast" */

	ZSchemaTextyyvarkind = Is_local_id;
yyVisit1ZSchemaText (yyt->expMu.ZSchemaText, & (* yyLocalsIn), & ZSchemaTextyyLocalsOut, & (* yyEnv), & ZSchemaTextyyvarkind, & ZSchemaTextyyDeclsIn, & ZSchemaTextyyDeclsOut, & (* yyVisIn), & ZSchemaTextyyVisOut, & (* yyPredIn), & ZSchemaTextyyPredOut, & (* yyMListIn), & ZSchemaTextyyMListOut, & ZSchemaTextyyIsLocal, & (* yyRListIn), & ZSchemaTextyyRListOut, & ZSchemaTextyyPos, & ZSchemaTextyySch);
/* line 647 "z.ast" */

	ExpressionyyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expMu.Expression, & ZSchemaTextyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & ExpressionyyDeclsIn, & (* yyDeclsOut), & ZSchemaTextyyVisOut, & (* yyVisOut), & ZSchemaTextyyPredOut, & (* yyPredOut), & ZSchemaTextyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ZSchemaTextyyRListOut, & (* yyRListOut), & ExpressionyyEL);
/* line 650 "z.ast" */

	(* yyEL) = mMu(mNoExp(),ZSchemaTextyySch,ExpressionyyEL);
} break;
case kexpLambda: {
tZSyms ZSchemaTextyyLocalsOut;
int ZSchemaTextyyvarkind;
tTree ZSchemaTextyyDeclsIn;
tTree ZSchemaTextyyDeclsOut;
tTree ZSchemaTextyyVisOut;
tTree ZSchemaTextyyPredOut;
tTree ZSchemaTextyyMListOut;
bool ZSchemaTextyyIsLocal;
tZSyms ZSchemaTextyyRListOut;
tPosition ZSchemaTextyyPos;
tTree ZSchemaTextyySch;
tTree ExpressionyyDeclsIn;
tTree ExpressionyyEL;
/* line 655 "z.ast" */

	ZSchemaTextyyDeclsIn = mNoDecl();
/* line 654 "z.ast" */

	ZSchemaTextyyIsLocal = true;
/* line 653 "z.ast" */

	ZSchemaTextyyvarkind = Is_local_id;
yyVisit1ZSchemaText (yyt->expLambda.ZSchemaText, & (* yyLocalsIn), & ZSchemaTextyyLocalsOut, & (* yyEnv), & ZSchemaTextyyvarkind, & ZSchemaTextyyDeclsIn, & ZSchemaTextyyDeclsOut, & (* yyVisIn), & ZSchemaTextyyVisOut, & (* yyPredIn), & ZSchemaTextyyPredOut, & (* yyMListIn), & ZSchemaTextyyMListOut, & ZSchemaTextyyIsLocal, & (* yyRListIn), & ZSchemaTextyyRListOut, & ZSchemaTextyyPos, & ZSchemaTextyySch);
/* line 656 "z.ast" */

	ExpressionyyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expLambda.Expression, & ZSchemaTextyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & ExpressionyyDeclsIn, & (* yyDeclsOut), & ZSchemaTextyyVisOut, & (* yyVisOut), & ZSchemaTextyyPredOut, & (* yyPredOut), & ZSchemaTextyyMListOut, & (* yyMListOut), & (* yyIsLocal), & ZSchemaTextyyRListOut, & (* yyRListOut), & ExpressionyyEL);
/* line 657 "z.ast" */

	(* yyEL) = mLambda(mNoExp(),ZSchemaTextyySch,ExpressionyyEL);
} break;
case kexpLet: {
tZSyms LetDefSeqyyLocalsOut;
tTree LetDefSeqyyDeclsIn;
tTree LetDefSeqyyDeclsOut;
tTree LetDefSeqyyVisOut;
tTree LetDefSeqyyPredOut;
tTree LetDefSeqyyMListOut;
tZSyms LetDefSeqyyRListOut;
tPosition LetDefSeqyyPos;
tTree ExpressionyyDeclsIn;
tTree ExpressionyyEL;
/* line 659 "z.ast" */

	LetDefSeqyyDeclsIn = mNoDecl();
yyVisit1LetDefSeq (yyt->expLet.LetDefSeq, & (* yyLocalsIn), & LetDefSeqyyLocalsOut, & (* yyEnv), & (* yyvarkind), & LetDefSeqyyDeclsIn, & LetDefSeqyyDeclsOut, & (* yyVisIn), & LetDefSeqyyVisOut, & (* yyPredIn), & LetDefSeqyyPredOut, & (* yyMListIn), & LetDefSeqyyMListOut, & (* yyIsLocal), & (* yyRListIn), & LetDefSeqyyRListOut, & LetDefSeqyyPos);
/* line 660 "z.ast" */

	ExpressionyyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expLet.Expression, & LetDefSeqyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & ExpressionyyDeclsIn, & (* yyDeclsOut), & LetDefSeqyyVisOut, & (* yyVisOut), & LetDefSeqyyPredOut, & (* yyPredOut), & LetDefSeqyyMListOut, & (* yyMListOut), & (* yyIsLocal), & LetDefSeqyyRListOut, & (* yyRListOut), & ExpressionyyEL);
/* line 661 "z.ast" */

	(* yyEL) = mNoExp();
	Message("let expression is not handled",3,LetDefSeqyyPos);
	ErrorsInTranslation++;
} break;
case kexpIf: {
tZSyms PredicateyyLocalsOut;
tTree PredicateyyDeclsOut;
tTree PredicateyyVisOut;
tTree PredicateyyPredOut;
tTree PredicateyyMListOut;
tZSyms PredicateyyRListOut;
tZSyms Exp1yyLocalsOut;
tTree Exp1yyDeclsIn;
tTree Exp1yyDeclsOut;
tTree Exp1yyVisOut;
tTree Exp1yyPredOut;
tTree Exp1yyMListOut;
tZSyms Exp1yyRListOut;
tTree Exp1yyEL;
tTree Exp2yyDeclsIn;
tTree Exp2yyEL;
yyVisit1Predicate (yyt->expIf.Predicate, & (* yyLocalsIn), & PredicateyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & PredicateyyDeclsOut, & (* yyVisIn), & PredicateyyVisOut, & (* yyPredIn), & PredicateyyPredOut, & (* yyMListIn), & PredicateyyMListOut, & (* yyIsLocal), & (* yyRListIn), & PredicateyyRListOut);
/* line 666 "z.ast" */

	Exp1yyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expIf.Exp1, & PredicateyyLocalsOut, & Exp1yyLocalsOut, & (* yyEnv), & (* yyvarkind), & Exp1yyDeclsIn, & Exp1yyDeclsOut, & PredicateyyVisOut, & Exp1yyVisOut, & PredicateyyPredOut, & Exp1yyPredOut, & PredicateyyMListOut, & Exp1yyMListOut, & (* yyIsLocal), & PredicateyyRListOut, & Exp1yyRListOut, & Exp1yyEL);
/* line 667 "z.ast" */

	Exp2yyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expIf.Exp2, & Exp1yyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & Exp2yyDeclsIn, & (* yyDeclsOut), & Exp1yyVisOut, & (* yyVisOut), & Exp1yyPredOut, & (* yyPredOut), & Exp1yyMListOut, & (* yyMListOut), & (* yyIsLocal), & Exp1yyRListOut, & (* yyRListOut), & Exp2yyEL);
/* line 668 "z.ast" */

	(* yyEL) = mIfExp(mNoExp(),PredicateyyPredOut,Exp1yyEL,Exp2yyEL);
} break;
case kexpImage: {
tZSyms Exp1yyLocalsOut;
tTree Exp1yyDeclsIn;
tTree Exp1yyDeclsOut;
tTree Exp1yyVisOut;
tTree Exp1yyPredOut;
tTree Exp1yyMListOut;
tZSyms Exp1yyRListOut;
tTree Exp1yyEL;
tZSyms Exp2yyLocalsOut;
tTree Exp2yyDeclsIn;
tTree Exp2yyDeclsOut;
tTree Exp2yyVisOut;
tTree Exp2yyPredOut;
tTree Exp2yyMListOut;
tZSyms Exp2yyRListOut;
tTree Exp2yyEL;
/* line 670 "z.ast" */

	Exp1yyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expImage.Exp1, & (* yyLocalsIn), & Exp1yyLocalsOut, & (* yyEnv), & (* yyvarkind), & Exp1yyDeclsIn, & Exp1yyDeclsOut, & (* yyVisIn), & Exp1yyVisOut, & (* yyPredIn), & Exp1yyPredOut, & (* yyMListIn), & Exp1yyMListOut, & (* yyIsLocal), & (* yyRListIn), & Exp1yyRListOut, & Exp1yyEL);
/* line 671 "z.ast" */

	Exp2yyDeclsIn = mNoDecl();
yyVisit1Expression (yyt->expImage.Exp2, & Exp1yyLocalsOut, & Exp2yyLocalsOut, & (* yyEnv), & (* yyvarkind), & Exp2yyDeclsIn, & Exp2yyDeclsOut, & Exp1yyVisOut, & Exp2yyVisOut, & Exp1yyPredOut, & Exp2yyPredOut, & Exp1yyMListOut, & Exp2yyMListOut, & (* yyIsLocal), & Exp1yyRListOut, & Exp2yyRListOut, & Exp2yyEL);
yyVisit1Decoration (yyt->expImage.Decoration, & Exp2yyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & Exp2yyDeclsOut, & (* yyDeclsOut), & Exp2yyVisOut, & (* yyVisOut), & Exp2yyPredOut, & (* yyPredOut), & Exp2yyMListOut, & (* yyMListOut), & (* yyIsLocal), & Exp2yyRListOut, & (* yyRListOut));
/* line 672 "z.ast" */

	(* yyEL) = mNoExp();
	Message("image expression is not handled",3,IdPosPos(yyt->expImage.Image));
	ErrorsInTranslation++;
} break;
case kexpDesignator: {
tIdPos DesignatoryyName;
tIdPos Designatoryymodname;
tTree DesignatoryyParamList;
tPosition DesignatoryyPos;
tTree DesignatoryySch;
tZTree DesignatoryyDes;
tTree DesignatoryyDesEL;
tZTree DesignatoryyRS;
tIdPos DesignatoryyIdent;
tIdPos DesignatoryyId;
yyVisit1Designator (yyt->expDesignator.Designator, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & DesignatoryyName, & Designatoryymodname, & DesignatoryyParamList, & DesignatoryyPos, & DesignatoryySch, & DesignatoryyDes, & (* yyEL), & DesignatoryyDesEL, & DesignatoryyRS, & DesignatoryyIdent, & DesignatoryyId);
} break;
case kexpParen: {
yyVisit1Expression (yyt->expParen.Expression, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut), & (* yyEL));
} break;
 default: ;
 }
}

static void yyVisit1LetDefSeq
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tPosition (* yyPos))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyPos)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tPosition (* yyPos);
# endif
{
 switch (yyt->Kind) {
case kLetDefSeq: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 749 "z.ast" */

	(* yyPos) = NoPosition;
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case knoLetDef: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 749 "z.ast" */

	(* yyPos) = NoPosition;
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kletDefs: {
tZSyms LetDefyyLocalsOut;
tTree LetDefyyDeclsOut;
tTree LetDefyyVisOut;
tTree LetDefyyPredOut;
tTree LetDefyyMListOut;
tZSyms LetDefyyRListOut;
tPosition NextyyPos;
yyVisit1LetDef (yyt->letDefs.LetDef, & (* yyLocalsIn), & LetDefyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & LetDefyyDeclsOut, & (* yyVisIn), & LetDefyyVisOut, & (* yyPredIn), & LetDefyyPredOut, & (* yyMListIn), & LetDefyyMListOut, & (* yyIsLocal), & (* yyRListIn), & LetDefyyRListOut, & (* yyPos));
yyVisit1LetDefSeq (yyt->letDefs.Next, & LetDefyyLocalsOut, & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & LetDefyyDeclsOut, & (* yyDeclsOut), & LetDefyyVisOut, & (* yyVisOut), & LetDefyyPredOut, & (* yyPredOut), & LetDefyyMListOut, & (* yyMListOut), & (* yyIsLocal), & LetDefyyRListOut, & (* yyRListOut), & NextyyPos);
} break;
 default: ;
 }
}

static void yyVisit1LetDef
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tPosition (* yyPos))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyPos)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tPosition (* yyPos);
# endif
{
 switch (yyt->Kind) {
case kLetDef: {
tZSyms VarNameyyLocalsOut;
tTree VarNameyyDeclsOut;
tTree VarNameyyVisOut;
tTree VarNameyyPredOut;
tTree VarNameyyMListOut;
tZSyms VarNameyyRListOut;
tTree VarNameyyFP;
tIdPos VarNameyyId;
tIdPos VarNameyyVarDec;
tIdPos VarNameyySumId;
tZSyms ExpressionyyLocalsIn;
tZSyms ExpressionyyLocalsOut;
tZSyms ExpressionyyEnv;
tTree ExpressionyyEL;
yyVisit1VarName (yyt->LetDef.VarName, & (* yyLocalsIn), & VarNameyyLocalsOut, & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & VarNameyyDeclsOut, & (* yyVisIn), & VarNameyyVisOut, & (* yyPredIn), & VarNameyyPredOut, & (* yyMListIn), & VarNameyyMListOut, & (* yyIsLocal), & (* yyRListIn), & VarNameyyRListOut, & VarNameyyFP, & VarNameyyId, & (* yyPos), & VarNameyyVarDec, & VarNameyySumId);
/* line 976 "z.ast" */

	(* yyLocalsOut) = msymbol((* yyLocalsIn),mvar(),VarNameyyVarDec,NoIdPos,currentMod);
/* line 974 "z.ast" */

	ExpressionyyEnv = mscope_env((* yyLocalsIn),(* yyEnv));
/* line 975 "z.ast" */

	ExpressionyyLocalsIn = mno_symbol();
yyVisit1Expression (yyt->LetDef.Expression, & ExpressionyyLocalsIn, & ExpressionyyLocalsOut, & ExpressionyyEnv, & (* yyvarkind), & VarNameyyDeclsOut, & (* yyDeclsOut), & VarNameyyVisOut, & (* yyVisOut), & VarNameyyPredOut, & (* yyPredOut), & VarNameyyMListOut, & (* yyMListOut), & (* yyIsLocal), & VarNameyyRListOut, & (* yyRListOut), & ExpressionyyEL);
} break;
 default: ;
 }
}

static void yyVisit1VarName
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tTree (* yyFP) ,tIdPos (* yyId) ,tPosition (* yyPos) ,tIdPos (* yyVarDec) ,tIdPos (* yySumId))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut, yyFP, yyId, yyPos, yyVarDec, yySumId)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tTree (* yyFP);
 tIdPos (* yyId);
 tPosition (* yyPos);
 tIdPos (* yyVarDec);
 tIdPos (* yySumId);
# endif
{
 switch (yyt->Kind) {
case kVarName: {
tZSyms DecorationyyRListOut;
yyVisit1Decoration (yyt->VarName.Decoration, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & DecorationyyRListOut);
/* line 982 "z.ast" */

	if (!InPreDefs(yyt->VarName.Ident) && !InSumRenamesSum((* yyRListIn),yyt->VarName.Ident)) 
		(* yySumId) = yyt->VarName.Ident;
	else if (InSumRenamesZ((* yyRListIn),yyt->VarName.Ident))
		(* yySumId) = SumNameForZName((* yyRListIn),yyt->VarName.Ident);
	else (* yySumId) = AllocateName((* yyLocalsIn),(* yyEnv),yyt->VarName.Ident);
/* line 988 "z.ast" */

	if (InPreDefs(yyt->VarName.Ident) && !InSumRenamesZ((* yyRListIn),yyt->VarName.Ident))
		(* yyRListOut) = msumRename((* yyRListIn),yyt->VarName.Ident,(* yySumId));
	else (* yyRListOut) = (* yyRListIn);
/* line 992 "z.ast" */

	(* yyVarDec) = IdDecCat((* yySumId),yyt->VarName.Decoration);
/* line 720 "z.ast" */

	(* yyPos) = IdPosPos(yyt->VarName.Ident);
/* line 451 "z.ast" */

	(* yyId) = ZMakeIdPos(DeMap(IdPosId((* yyVarDec))),IdPosPos(yyt->VarName.Ident));
/* line 300 "z.ast" */

	(* yyFP) = mTyParam(mNoParam(),(* yyVarDec),false);
} break;
case kZId: {
tZSyms DecorationyyRListOut;
yyVisit1Decoration (yyt->ZId.Decoration, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & DecorationyyRListOut);
/* line 982 "z.ast" */

	if (!InPreDefs(yyt->ZId.Ident) && !InSumRenamesSum((* yyRListIn),yyt->ZId.Ident)) 
		(* yySumId) = yyt->ZId.Ident;
	else if (InSumRenamesZ((* yyRListIn),yyt->ZId.Ident))
		(* yySumId) = SumNameForZName((* yyRListIn),yyt->ZId.Ident);
	else (* yySumId) = AllocateName((* yyLocalsIn),(* yyEnv),yyt->ZId.Ident);
/* line 988 "z.ast" */

	if (InPreDefs(yyt->ZId.Ident) && !InSumRenamesZ((* yyRListIn),yyt->ZId.Ident))
		(* yyRListOut) = msumRename((* yyRListIn),yyt->ZId.Ident,(* yySumId));
	else (* yyRListOut) = (* yyRListIn);
/* line 992 "z.ast" */

	(* yyVarDec) = IdDecCat((* yySumId),yyt->ZId.Decoration);
/* line 720 "z.ast" */

	(* yyPos) = IdPosPos(yyt->ZId.Ident);
/* line 451 "z.ast" */

	(* yyId) = ZMakeIdPos(DeMap(IdPosId((* yyVarDec))),IdPosPos(yyt->ZId.Ident));
/* line 300 "z.ast" */

	(* yyFP) = mTyParam(mNoParam(),(* yyVarDec),false);
} break;
case kOpname: {
tZSyms DecorationyyRListOut;
yyVisit1Decoration (yyt->Opname.Decoration, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & DecorationyyRListOut);
/* line 982 "z.ast" */

	if (!InPreDefs(yyt->Opname.Ident) && !InSumRenamesSum((* yyRListIn),yyt->Opname.Ident)) 
		(* yySumId) = yyt->Opname.Ident;
	else if (InSumRenamesZ((* yyRListIn),yyt->Opname.Ident))
		(* yySumId) = SumNameForZName((* yyRListIn),yyt->Opname.Ident);
	else (* yySumId) = AllocateName((* yyLocalsIn),(* yyEnv),yyt->Opname.Ident);
/* line 988 "z.ast" */

	if (InPreDefs(yyt->Opname.Ident) && !InSumRenamesZ((* yyRListIn),yyt->Opname.Ident))
		(* yyRListOut) = msumRename((* yyRListIn),yyt->Opname.Ident,(* yySumId));
	else (* yyRListOut) = (* yyRListIn);
/* line 992 "z.ast" */

	(* yyVarDec) = IdDecCat((* yySumId),yyt->Opname.Decoration);
/* line 720 "z.ast" */

	(* yyPos) = IdPosPos(yyt->Opname.Ident);
/* line 451 "z.ast" */

	(* yyId) = ZMakeIdPos(DeMap(IdPosId((* yyVarDec))),IdPosPos(yyt->Opname.Ident));
/* line 300 "z.ast" */

	(* yyFP) = mTyParam(mNoParam(),(* yyVarDec),false);
} break;
 default: ;
 }
}

static void yyVisit1Decoration
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,int (* yyvarkind) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,bool (* yyIsLocal) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyvarkind, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyIsLocal, yyRListIn, yyRListOut)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 int (* yyvarkind);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 bool (* yyIsLocal);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
# endif
{
 switch (yyt->Kind) {
case kDecoration: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case knoDecoration: {
(* yyLocalsOut) =(* yyLocalsIn);
(* yyRListOut) =(* yyRListIn);
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
case kdecoration: {
yyVisit1Decoration (yyt->decoration.Next, & (* yyLocalsIn), & (* yyLocalsOut), & (* yyEnv), & (* yyvarkind), & (* yyDeclsIn), & (* yyDeclsOut), & (* yyVisIn), & (* yyVisOut), & (* yyPredIn), & (* yyPredOut), & (* yyMListIn), & (* yyMListOut), & (* yyIsLocal), & (* yyRListIn), & (* yyRListOut));
} break;
 default: ;
 }
}

static void yyVisit1ZName
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt ,tZSyms (* yyLocalsIn) ,tZSyms (* yyLocalsOut) ,tZSyms (* yyEnv) ,tTree (* yyDeclsIn) ,tTree (* yyDeclsOut) ,tTree (* yyVisIn) ,tTree (* yyVisOut) ,tTree (* yyPredIn) ,tTree (* yyPredOut) ,tTree (* yyMListIn) ,tTree (* yyMListOut) ,tZSyms (* yyRListIn) ,tZSyms (* yyRListOut) ,tIdPos (* yyId) ,tIdPos (* yySumId) ,tPosition (* yyPos))
# else
 (yyt, yyLocalsIn, yyLocalsOut, yyEnv, yyDeclsIn, yyDeclsOut, yyVisIn, yyVisOut, yyPredIn, yyPredOut, yyMListIn, yyMListOut, yyRListIn, yyRListOut, yyId, yySumId, yyPos)
 register tZTree yyt;
 tZSyms (* yyLocalsIn);
 tZSyms (* yyLocalsOut);
 tZSyms (* yyEnv);
 tTree (* yyDeclsIn);
 tTree (* yyDeclsOut);
 tTree (* yyVisIn);
 tTree (* yyVisOut);
 tTree (* yyPredIn);
 tTree (* yyPredOut);
 tTree (* yyMListIn);
 tTree (* yyMListOut);
 tZSyms (* yyRListIn);
 tZSyms (* yyRListOut);
 tIdPos (* yyId);
 tIdPos (* yySumId);
 tPosition (* yyPos);
# endif
{
 switch (yyt->Kind) {
case kZName: {
(* yyLocalsOut) =(* yyLocalsIn);
/* line 726 "z.ast" */

	(* yyPos) = IdPosPos(yyt->ZName.Ident);
/* line 438 "z.ast" */

	if (!InPreDefs(yyt->ZName.Ident) && !InSumRenamesSum((* yyRListIn),yyt->ZName.Ident)) 
		(* yySumId) = yyt->ZName.Ident;
	else if (InSumRenamesZ((* yyRListIn),yyt->ZName.Ident))
		(* yySumId) = SumNameForZName((* yyRListIn),yyt->ZName.Ident);
	else (* yySumId) = AllocateName((* yyLocalsIn),(* yyEnv),yyt->ZName.Ident);
/* line 444 "z.ast" */

	if (InPreDefs(yyt->ZName.Ident) && !InSumRenamesZ((* yyRListIn),yyt->ZName.Ident))
		(* yyRListOut) = msumRename((* yyRListIn),yyt->ZName.Ident,(* yySumId));
	else (* yyRListOut) = (* yyRListIn);
/* line 448 "z.ast" */

	(* yyId) = ZMakeIdPos(DeMap(IdPosId((* yySumId))),IdPosPos(yyt->ZName.Ident));
(* yyMListOut) =(* yyMListIn);
(* yyPredOut) =(* yyPredIn);
(* yyVisOut) =(* yyVisIn);
(* yyDeclsOut) =(* yyDeclsIn);
} break;
 default: ;
 }
}

void BeginBuildSymtab ()
{
/* line 257 "z.ast" */

	ErrorsInTranslation=0;
}

void CloseBuildSymtab ()
{
}
