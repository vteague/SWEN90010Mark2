/* $Id: Parser.c,v 2.9 1992/08/07 15:28:42 grosch rel $ */

# define bool		char
# define true		1
# define false		0

# include "Parser.h"
# include "Errors.h"

# ifdef __cplusplus
extern "C" {
#    include "Memory.h"
#    include "DynArray.h"
#    include "Sets.h"
#    ifndef BCOPY
#       include <memory.h>
#    endif
}
# else
#    include "Memory.h"
#    include "DynArray.h"
#    include "Sets.h"
#    ifndef BCOPY
#       include <memory.h>
#    endif
# endif

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifdef lex_interface
#    define GetToken	yylex
     extern int yylex ();
#    ifndef AttributeDef
#	include "Positions.h"
        typedef struct { tPosition Position; } tScanAttribute;
        static	tScanAttribute	Attribute = {{ 0, 0 }};
#    endif
#    ifndef ErrorAttributeDef
#	define ErrorAttribute(Token, RepairAttribute)
#    endif
#    ifndef yyGetAttribute
#	define yyGetAttribute(yyAttrStackPtr, Attribute) * yyAttrStackPtr = yylval
#    endif
# else
#    include "Scanner.h"
#    ifndef yyGetAttribute
#	define yyGetAttribute(yyAttrStackPtr, Attribute) (yyAttrStackPtr)->Scan = Attribute
#    endif
# endif

/* line 16 "Parser.lalr" */


/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
# include "Idents.h"
# include "Positions.h"
# include "Tree.h"
# include "ratc.h"
# include <string.h>
# include <stdio.h>
# include "global.h"
# include "Errors.h"

int CountErr = 0;

tIdPos MakeIdPos (Idstr, Pos) 
    char *Idstr;
    tPosition Pos;
{
    tIdPos idpos;

    idpos.Ident = MakeIdent(Idstr, strlen(Idstr));
    idpos.Pos = Pos;
    return idpos;
}


typedef struct { tTree Tree; } yyModuleItemList;
typedef struct { tTree Tree; } yyModuleItem;
typedef struct { tTree Tree; } yyFormalList;
typedef struct { tTree Tree; } yyFormal;
typedef struct { tTree Tree; } yyRename;
typedef struct { tTree Tree; } yySelection;
typedef struct { tTree Tree; } yyRenames;
typedef struct { tTree Tree; } yySelections;
typedef struct { tTree Tree; } yyDecl_List;
typedef struct { tTree Tree; } yyDeclList;
typedef struct { tTree Tree; } yyDeclaration;
typedef struct { tTree Tree; } yyVarDeclList;
typedef struct { tTree Tree; } yyVarDecl;
typedef struct { tTree Tree; } yyDeclNameList;
typedef struct { tIdPos Ident; int NameIdKind; } yyDeclName;
typedef struct { bool IsOp; } yyOper;
typedef struct { tTree Tree; } yySchFormal_List;
typedef struct { tTree Tree; } yySchFormalList;
typedef struct { tTree Tree; } yyBasicDecl;
typedef struct { tTree Tree; } yyBasicDeclList;
typedef struct { tTree Tree; } yySchDecl;
typedef struct { tTree Tree; } yySchPred;
typedef struct { tTree Tree; } yyAxiomDecl;
typedef struct { tTree Tree; } yyFunctionDecl;
typedef struct { tTree Tree; } yyBranch;
typedef struct { tTree Tree; } yyBranchList;
typedef struct { tTree Tree; } yyEnumList;
typedef struct { tTree Tree; } yyAndPredList;
typedef struct { tTree Tree; } yyExpList;
typedef struct { tTree Tree; } yyPredList;
typedef struct { tTree Tree; } yyPredicate;
typedef struct { tTree Tree; } yyLogPredEquivalence;
typedef struct { tTree Tree; } yyLogPredImplication;
typedef struct { tTree Tree; } yyLogPredOr;
typedef struct { tTree Tree; } yyLogPredAnd;
typedef struct { tTree Tree; } yyLogPredSeq;
typedef struct { tTree Tree; } yyBasicPredicate;
typedef struct { tIdPos Ident; } yyInRelOp_Ex;
typedef struct { tTree Tree; } yyInputBindList;
typedef struct { tTree Tree; } yyOutputBindList;
typedef struct { tTree Tree; } yyChanges_Onlys;
typedef struct { tTree Tree; } yySchVarList;
typedef struct { tTree Tree; } yyCmpndSch;
typedef struct { tTree Tree; } yyCmpndSch1;
typedef struct { tTree Tree; } yyCmpndSch2;
typedef struct { tTree Tree; } yyBasicSch;
typedef struct { tTree Tree; } yySchemaText;
typedef struct { tTree Tree; } yyExpression;
typedef struct { tTree Tree; } yyExpression0;
typedef struct { tTree Tree; } yyCartExp;
typedef struct { tTree Tree; } yyExpression1;
typedef struct { tIdPos Ident; } yyInfix;
typedef struct { tTree Tree; } yyExpression2;
typedef struct { tIdPos Ident; } yyPrefix_Id;
typedef struct { tTree Tree; } yyBasicExp;
typedef struct { tTree Tree; } yySetComp;
typedef struct { tTree Tree; } yySetElaboration;
typedef struct { tTree Tree; } yyNamed_array_agg;
typedef struct { tIdPos Ident; } yyArrow;
typedef struct { tTree Tree; } yySequence;
typedef struct { tTree Tree; } yyBag;
typedef struct { tTree Tree; } yyName;
typedef struct { tIdPos Ident; } yyOpname;
typedef struct { tIdPos Ident; } yyInfixOp;
typedef struct { tIdPos Ident; } yyPrefixOp;

typedef union {
 tScanAttribute Scan;
 yyModuleItemList ModuleItemList;
 yyModuleItem ModuleItem;
 yyFormalList FormalList;
 yyFormal Formal;
 yyRename Rename;
 yySelection Selection;
 yyRenames Renames;
 yySelections Selections;
 yyDecl_List Decl_List;
 yyDeclList DeclList;
 yyDeclaration Declaration;
 yyVarDeclList VarDeclList;
 yyVarDecl VarDecl;
 yyDeclNameList DeclNameList;
 yyDeclName DeclName;
 yyOper Oper;
 yySchFormal_List SchFormal_List;
 yySchFormalList SchFormalList;
 yyBasicDecl BasicDecl;
 yyBasicDeclList BasicDeclList;
 yySchDecl SchDecl;
 yySchPred SchPred;
 yyAxiomDecl AxiomDecl;
 yyFunctionDecl FunctionDecl;
 yyBranch Branch;
 yyBranchList BranchList;
 yyEnumList EnumList;
 yyAndPredList AndPredList;
 yyExpList ExpList;
 yyPredList PredList;
 yyPredicate Predicate;
 yyLogPredEquivalence LogPredEquivalence;
 yyLogPredImplication LogPredImplication;
 yyLogPredOr LogPredOr;
 yyLogPredAnd LogPredAnd;
 yyLogPredSeq LogPredSeq;
 yyBasicPredicate BasicPredicate;
 yyInRelOp_Ex InRelOp_Ex;
 yyInputBindList InputBindList;
 yyOutputBindList OutputBindList;
 yyChanges_Onlys Changes_Onlys;
 yySchVarList SchVarList;
 yyCmpndSch CmpndSch;
 yyCmpndSch1 CmpndSch1;
 yyCmpndSch2 CmpndSch2;
 yyBasicSch BasicSch;
 yySchemaText SchemaText;
 yyExpression Expression;
 yyExpression0 Expression0;
 yyCartExp CartExp;
 yyExpression1 Expression1;
 yyInfix Infix;
 yyExpression2 Expression2;
 yyPrefix_Id Prefix_Id;
 yyBasicExp BasicExp;
 yySetComp SetComp;
 yySetElaboration SetElaboration;
 yyNamed_array_agg Named_array_agg;
 yyArrow Arrow;
 yySequence Sequence;
 yyBag Bag;
 yyName Name;
 yyOpname Opname;
 yyInfixOp InfixOp;
 yyPrefixOp PrefixOp;
} tParsAttribute;


# if defined lex_interface & ! defined yylvalDef
     tParsAttribute yylval;
# endif

# ifndef yyInitStackSize
#    define yyInitStackSize	100
# endif
# define yyNoState		0

# define yyFirstTerminal	0
# define yyLastTerminal		122
# define yyTableMax		1355
# define yyNTableMax		1947
# define yyFirstReadState	1
# define yyLastReadState	269
# define yyFirstReadTermState	270
# define yyLastReadTermState	371
# define yyLastReadNontermState	444
# define yyFirstReduceState	445
# define yyLastReduceState	667
# define yyStartState		1
# define yyStopState		445

# define yyFirstFinalState	yyFirstReadTermState

typedef unsigned short	yyStateRange	;
typedef unsigned short	yySymbolRange	;
typedef struct	{ yyStateRange Check, Next; } yyTCombType ;

	char *		Parser_TokenName	[yyLastTerminal + 1] = {
"_EndOfFile",
"Id",
"Number",
"String",
"Char",
"Prefix",
"InGen",
"InRelOp",
"PreRelOp",
"Quantifier",
"BoolValue",
"module",
"is",
"import",
"as",
"(",
"if",
".",
"[",
"]",
"_",
"|-->",
"..",
"+",
"*",
"diff",
"^",
"div",
"mod",
"func_override",
"b_compose",
"f_compose",
"dom_restrict",
"ran_restrict",
"dom_subtract",
"ran_subtract",
"union",
"bag_union",
"inter",
"sym_diff",
"filter",
"**",
"-",
"subc",
"addc",
"multc",
"divc",
"modc",
"expc",
"uptoc",
"andc",
"orc",
"xorc",
"notc",
"<",
">",
"ltc",
"ltec",
"gtc",
"gtec",
"eqc",
"neqc",
"#",
",",
":",
";",
"|",
"@",
"<=>",
"exor",
"and",
"seqcomp",
"not",
"pre",
"let",
"changes_only",
"{",
"}",
"assign",
":=",
"ifc",
"then",
"else",
"fi",
"while",
"do",
"done",
"s_compose",
"BackSlash",
")",
"/",
"|^",
"call",
"=>",
"or",
"upd",
"SCBRACE",
"dec",
"|[",
"]|",
"lambda",
"mu",
"the",
"theta",
"cross",
"op",
"schema",
"pred",
"end",
"axiom",
"function",
"==",
"::=",
"<<",
">>",
"enum",
"visible",
"(-+",
"ergo",
"+-)",
"state_machine",
"PREDEXP",
"TUP",
};
static	yyTCombType	yyTComb		[yyTableMax + 1] = {
{268, 445},
{2, 3},
{54, 328},
{76, 73},
{83, 80},
{116, 7},
{177, 173},
{5, 660},
{5, 660},
{183, 184},
{185, 356},
{1, 2},
{3, 4},
{170, 351},
{189, 357},
{3, 254},
{5, 660},
{23, 24},
{5, 6},
{5, 660},
{15, 317},
{18, 321},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{16, 489},
{5, 491},
{5, 491},
{5, 660},
{21, 322},
{25, 26},
{5, 660},
{5, 660},
{5, 660},
{5, 660},
{29, 30},
{37, 326},
{52, 53},
{41, 42},
{5, 660},
{22, 323},
{42, 566},
{45, 327},
{47, 48},
{68, 69},
{70, 71},
{71, 72},
{77, 78},
{78, 79},
{88, 89},
{5, 660},
{5, 660},
{63, 329},
{72, 77},
{5, 660},
{73, 74},
{5, 660},
{5, 660},
{79, 84},
{27, 28},
{75, 76},
{31, 324},
{9, 155},
{9, 159},
{80, 81},
{84, 330},
{85, 86},
{5, 660},
{86, 331},
{16, 17},
{16, 489},
{5, 660},
{7, 660},
{7, 660},
{5, 8},
{5, 172},
{87, 88},
{89, 90},
{7, 660},
{90, 91},
{91, 332},
{7, 660},
{92, 93},
{7, 6},
{7, 660},
{7, 660},
{75, 562},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{93, 333},
{7, 660},
{82, 83},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{13, 6},
{13, 660},
{13, 491},
{94, 95},
{7, 660},
{7, 660},
{33, 579},
{7, 660},
{96, 334},
{7, 660},
{7, 660},
{7, 660},
{43, 44},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{7, 660},
{82, 564},
{7, 660},
{108, 36},
{7, 660},
{7, 660},
{111, 112},
{113, 335},
{115, 116},
{43, 568},
{7, 660},
{43, 568},
{117, 336},
{126, 127},
{130, 337},
{7, 660},
{128, 129},
{128, 338},
{7, 660},
{7, 660},
{131, 132},
{43, 568},
{132, 133},
{134, 135},
{137, 138},
{7, 660},
{141, 341},
{136, 55},
{139, 140},
{142, 143},
{144, 342},
{13, 660},
{13, 660},
{13, 660},
{137, 649},
{33, 34},
{33, 35},
{33, 579},
{139, 647},
{145, 55},
{146, 344},
{148, 149},
{134, 339},
{13, 660},
{150, 151},
{152, 153},
{154, 346},
{33, 579},
{146, 55},
{156, 157},
{158, 347},
{162, 348},
{163, 350},
{145, 343},
{166, 352},
{13, 660},
{171, 353},
{172, 176},
{175, 354},
{33, 579},
{133, 10},
{14, 275},
{133, 325},
{136, 340},
{176, 177},
{182, 667},
{186, 11},
{191, 192},
{192, 193},
{19, 20},
{19, 499},
{188, 189},
{193, 358},
{13, 660},
{13, 660},
{14, 276},
{14, 277},
{14, 278},
{14, 279},
{14, 280},
{14, 281},
{14, 282},
{14, 283},
{14, 284},
{14, 285},
{14, 286},
{14, 287},
{14, 288},
{14, 289},
{14, 290},
{14, 291},
{14, 292},
{14, 293},
{14, 294},
{14, 295},
{14, 296},
{14, 297},
{14, 298},
{14, 299},
{14, 300},
{14, 301},
{14, 302},
{14, 303},
{14, 304},
{14, 305},
{14, 306},
{14, 307},
{14, 308},
{14, 309},
{14, 310},
{14, 311},
{14, 312},
{14, 313},
{14, 314},
{14, 315},
{14, 316},
{19, 499},
{19, 499},
{19, 499},
{160, 161},
{168, 169},
{178, 179},
{196, 197},
{195, 114},
{133, 38},
{133, 39},
{133, 40},
{133, 41},
{19, 499},
{187, 55},
{133, 46},
{197, 359},
{133, 66},
{188, 190},
{198, 13},
{199, 360},
{133, 67},
{195, 196},
{203, 202},
{204, 362},
{19, 499},
{160, 349},
{205, 206},
{209, 320},
{133, 68},
{214, 363},
{168, 653},
{178, 355},
{50, 627},
{50, 627},
{215, 510},
{215, 510},
{217, 364},
{218, 219},
{50, 627},
{187, 188},
{223, 365},
{50, 627},
{19, 499},
{19, 499},
{50, 51},
{50, 627},
{147, 345},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{206, 207},
{50, 627},
{147, 55},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{206, 508},
{206, 508},
{224, 225},
{225, 226},
{50, 627},
{50, 627},
{221, 222},
{226, 227},
{227, 366},
{50, 627},
{50, 627},
{50, 627},
{228, 229},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{50, 627},
{229, 230},
{50, 627},
{221, 461},
{50, 627},
{50, 627},
{230, 231},
{231, 232},
{232, 233},
{233, 234},
{50, 627},
{53, 628},
{53, 628},
{234, 235},
{235, 236},
{50, 627},
{237, 238},
{53, 628},
{50, 627},
{50, 627},
{53, 628},
{238, 367},
{53, 54},
{202, 497},
{53, 628},
{50, 627},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{202, 203},
{53, 628},
{239, 240},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{180, 479},
{180, 181},
{208, 209},
{212, 213},
{53, 628},
{53, 628},
{240, 368},
{243, 244},
{244, 245},
{53, 628},
{53, 628},
{53, 628},
{219, 482},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{53, 628},
{241, 242},
{53, 628},
{245, 495},
{53, 628},
{53, 628},
{219, 220},
{56, 57},
{56, 584},
{245, 201},
{53, 628},
{246, 247},
{247, 248},
{56, 584},
{251, 252},
{53, 628},
{250, 211},
{250, 506},
{53, 628},
{53, 628},
{56, 584},
{252, 369},
{247, 504},
{247, 504},
{253, 666},
{53, 628},
{180, 479},
{208, 486},
{208, 486},
{212, 507},
{256, 257},
{260, 261},
{261, 370},
{57, 270},
{57, 271},
{57, 272},
{57, 273},
{249, 34},
{219, 482},
{255, 491},
{255, 491},
{255, 455},
{258, 259},
{262, 12},
{241, 464},
{263, 264},
{57, 9},
{264, 265},
{258, 262},
{265, 463},
{266, 267},
{267, 371},
{269, 447},
{0, 0},
{256, 258},
{56, 584},
{56, 584},
{56, 584},
{56, 584},
{56, 584},
{56, 584},
{56, 584},
{56, 584},
{0, 0},
{56, 584},
{255, 455},
{56, 584},
{56, 584},
{56, 584},
{56, 584},
{56, 584},
{56, 584},
{56, 584},
{57, 318},
{99, 525},
{0, 0},
{0, 0},
{56, 584},
{56, 584},
{249, 505},
{249, 505},
{0, 0},
{56, 584},
{56, 584},
{56, 584},
{57, 21},
{56, 584},
{56, 584},
{56, 584},
{56, 584},
{56, 584},
{263, 213},
{56, 584},
{57, 319},
{56, 584},
{56, 584},
{0, 0},
{58, 586},
{58, 586},
{0, 0},
{56, 584},
{0, 0},
{0, 0},
{58, 586},
{0, 0},
{0, 0},
{0, 0},
{57, 22},
{56, 584},
{56, 584},
{58, 586},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{56, 584},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{99, 525},
{0, 0},
{99, 525},
{99, 100},
{0, 0},
{0, 0},
{57, 23},
{57, 27},
{0, 0},
{57, 31},
{0, 0},
{0, 0},
{99, 525},
{57, 32},
{57, 49},
{0, 0},
{99, 525},
{99, 525},
{99, 525},
{0, 0},
{99, 525},
{99, 525},
{0, 0},
{0, 0},
{99, 525},
{58, 586},
{58, 586},
{58, 586},
{58, 586},
{58, 586},
{58, 586},
{58, 586},
{58, 586},
{0, 0},
{58, 586},
{0, 0},
{58, 586},
{58, 586},
{58, 586},
{58, 586},
{58, 586},
{58, 586},
{58, 586},
{99, 525},
{0, 0},
{0, 0},
{0, 0},
{58, 586},
{58, 586},
{0, 0},
{0, 0},
{0, 0},
{58, 586},
{58, 586},
{58, 586},
{0, 0},
{58, 586},
{58, 586},
{58, 586},
{58, 586},
{58, 586},
{0, 0},
{58, 586},
{0, 0},
{58, 586},
{58, 586},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{58, 586},
{61, 623},
{61, 623},
{0, 0},
{0, 0},
{58, 59},
{0, 0},
{61, 623},
{58, 586},
{58, 586},
{61, 62},
{0, 0},
{0, 0},
{0, 0},
{61, 623},
{58, 586},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{0, 0},
{61, 623},
{0, 0},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{65, 542},
{0, 0},
{0, 0},
{0, 0},
{61, 623},
{61, 623},
{184, 185},
{184, 186},
{0, 0},
{61, 623},
{61, 623},
{61, 623},
{0, 0},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{61, 623},
{0, 0},
{61, 623},
{0, 0},
{61, 623},
{61, 623},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{61, 623},
{173, 512},
{0, 0},
{173, 512},
{173, 512},
{61, 623},
{97, 275},
{0, 0},
{61, 623},
{61, 623},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{61, 623},
{0, 0},
{0, 0},
{97, 578},
{65, 542},
{0, 0},
{65, 542},
{65, 542},
{65, 542},
{65, 542},
{65, 542},
{0, 0},
{173, 512},
{0, 0},
{0, 0},
{184, 467},
{65, 542},
{0, 0},
{0, 0},
{0, 0},
{65, 542},
{65, 542},
{65, 542},
{0, 0},
{65, 542},
{65, 542},
{184, 194},
{0, 0},
{65, 542},
{0, 0},
{0, 0},
{173, 512},
{65, 542},
{65, 542},
{0, 0},
{101, 529},
{173, 174},
{0, 0},
{97, 309},
{97, 310},
{97, 311},
{97, 312},
{97, 313},
{97, 314},
{97, 315},
{97, 316},
{0, 0},
{65, 542},
{0, 0},
{97, 578},
{0, 0},
{97, 578},
{97, 578},
{97, 578},
{97, 578},
{97, 578},
{0, 0},
{0, 0},
{184, 467},
{0, 0},
{97, 578},
{97, 578},
{0, 0},
{0, 0},
{0, 0},
{97, 578},
{97, 578},
{97, 578},
{103, 530},
{97, 578},
{97, 578},
{97, 578},
{97, 578},
{97, 578},
{0, 0},
{97, 578},
{0, 0},
{97, 578},
{97, 578},
{0, 0},
{0, 0},
{101, 529},
{0, 0},
{101, 529},
{101, 529},
{101, 102},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{97, 578},
{101, 529},
{0, 0},
{0, 0},
{0, 0},
{101, 529},
{101, 529},
{101, 529},
{105, 533},
{101, 529},
{101, 529},
{0, 0},
{0, 0},
{101, 529},
{0, 0},
{0, 0},
{0, 0},
{101, 122},
{101, 124},
{0, 0},
{0, 0},
{0, 0},
{103, 530},
{0, 0},
{103, 530},
{103, 530},
{103, 530},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{101, 529},
{0, 0},
{103, 530},
{0, 0},
{0, 0},
{0, 0},
{103, 530},
{103, 530},
{103, 530},
{107, 548},
{103, 530},
{103, 530},
{0, 0},
{0, 0},
{103, 530},
{0, 0},
{0, 0},
{0, 0},
{103, 530},
{103, 530},
{0, 0},
{0, 0},
{105, 533},
{0, 0},
{105, 533},
{105, 533},
{105, 533},
{105, 533},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{103, 530},
{105, 533},
{0, 0},
{0, 0},
{0, 0},
{105, 533},
{105, 533},
{105, 533},
{109, 570},
{105, 533},
{105, 533},
{0, 0},
{254, 255},
{105, 533},
{0, 0},
{0, 0},
{254, 273},
{105, 533},
{105, 533},
{254, 274},
{0, 0},
{0, 0},
{107, 548},
{0, 0},
{107, 548},
{107, 548},
{107, 548},
{107, 548},
{107, 548},
{0, 0},
{0, 0},
{254, 14},
{105, 533},
{0, 0},
{107, 548},
{0, 0},
{0, 0},
{0, 0},
{107, 548},
{107, 548},
{107, 548},
{118, 574},
{107, 548},
{107, 548},
{107, 108},
{0, 0},
{107, 548},
{0, 0},
{0, 0},
{0, 0},
{107, 548},
{107, 548},
{0, 0},
{254, 318},
{109, 570},
{0, 0},
{109, 570},
{109, 570},
{109, 570},
{109, 570},
{109, 570},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{107, 548},
{109, 570},
{0, 0},
{0, 0},
{0, 0},
{109, 570},
{109, 570},
{109, 570},
{254, 319},
{109, 570},
{109, 570},
{109, 570},
{120, 571},
{109, 570},
{0, 0},
{0, 0},
{0, 0},
{109, 570},
{109, 570},
{0, 0},
{0, 0},
{0, 0},
{118, 574},
{0, 0},
{118, 574},
{118, 574},
{118, 574},
{118, 574},
{118, 574},
{0, 0},
{0, 0},
{0, 0},
{109, 570},
{118, 574},
{118, 574},
{0, 0},
{0, 0},
{0, 0},
{118, 574},
{118, 574},
{118, 574},
{0, 0},
{118, 574},
{118, 574},
{118, 574},
{118, 574},
{118, 574},
{121, 534},
{118, 119},
{0, 0},
{118, 574},
{118, 574},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{120, 571},
{0, 0},
{120, 571},
{120, 571},
{120, 571},
{120, 571},
{120, 571},
{118, 574},
{0, 0},
{0, 0},
{0, 0},
{120, 110},
{120, 571},
{0, 0},
{0, 0},
{0, 0},
{120, 571},
{120, 571},
{120, 571},
{123, 532},
{120, 571},
{120, 571},
{120, 571},
{120, 115},
{120, 571},
{0, 0},
{0, 0},
{0, 0},
{120, 571},
{120, 571},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{121, 534},
{0, 0},
{121, 534},
{121, 534},
{121, 534},
{121, 534},
{121, 106},
{0, 0},
{120, 571},
{0, 0},
{0, 0},
{0, 0},
{121, 534},
{0, 0},
{125, 531},
{0, 0},
{121, 534},
{121, 534},
{121, 534},
{0, 0},
{121, 534},
{121, 534},
{0, 0},
{0, 0},
{121, 534},
{0, 0},
{0, 0},
{0, 0},
{121, 534},
{121, 534},
{123, 532},
{0, 0},
{123, 532},
{123, 532},
{123, 532},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{123, 532},
{121, 534},
{164, 275},
{0, 0},
{123, 532},
{123, 532},
{123, 532},
{0, 0},
{123, 532},
{123, 532},
{0, 0},
{0, 0},
{123, 532},
{0, 0},
{0, 0},
{0, 0},
{123, 532},
{123, 532},
{125, 531},
{0, 0},
{125, 531},
{125, 531},
{125, 531},
{125, 104},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{125, 531},
{123, 532},
{0, 0},
{0, 0},
{125, 531},
{125, 531},
{125, 531},
{0, 0},
{125, 531},
{125, 531},
{0, 0},
{0, 0},
{125, 531},
{0, 0},
{0, 0},
{0, 0},
{125, 531},
{125, 531},
{0, 0},
{164, 309},
{164, 310},
{164, 311},
{164, 312},
{164, 313},
{164, 314},
{164, 315},
{164, 316},
{0, 0},
{164, 165},
{0, 0},
{242, 5},
{125, 531},
{0, 0},
{164, 578},
{164, 578},
{164, 578},
{164, 578},
{242, 182},
{0, 0},
{0, 0},
{242, 2},
{164, 578},
{242, 183},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{242, 198},
{0, 0},
{242, 14},
{0, 0},
{0, 0},
{164, 578},
{164, 578},
{164, 578},
{0, 0},
{164, 578},
{0, 0},
{164, 578},
{164, 578},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{242, 361},
{242, 493},
{0, 0},
{0, 0},
{242, 200},
{242, 215},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{0, 0},
{242, 218},
{242, 224},
{0, 0},
{0, 0},
{242, 228},
{0, 0},
{0, 0},
};
static	unsigned short	yyNComb		[yyNTableMax - yyLastTerminal] = {
442,
268,
269,
444,
434,
239,
443,
0,
0,
435,
16,
50,
372,
25,
383,
43,
241,
438,
70,
243,
82,
402,
205,
210,
214,
437,
29,
97,
50,
217,
180,
377,
178,
204,
422,
43,
398,
425,
423,
99,
408,
101,
123,
121,
421,
43,
373,
107,
45,
382,
120,
118,
406,
385,
56,
58,
374,
388,
253,
61,
391,
64,
87,
392,
393,
395,
15,
18,
50,
381,
385,
56,
58,
85,
388,
60,
61,
391,
396,
47,
392,
393,
163,
92,
164,
50,
98,
167,
43,
424,
426,
246,
111,
398,
404,
250,
99,
408,
101,
123,
121,
419,
251,
0,
107,
167,
0,
120,
118,
406,
385,
56,
58,
377,
388,
60,
61,
391,
171,
0,
392,
393,
117,
0,
0,
50,
0,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
150,
378,
97,
0,
50,
0,
0,
0,
0,
0,
18,
398,
0,
0,
99,
408,
101,
123,
121,
375,
16,
19,
107,
0,
16,
120,
118,
406,
385,
56,
58,
0,
388,
60,
61,
391,
29,
0,
392,
393,
376,
377,
50,
379,
33,
377,
0,
0,
148,
147,
389,
60,
61,
391,
50,
0,
392,
393,
390,
0,
0,
146,
0,
0,
0,
0,
50,
0,
378,
0,
390,
0,
378,
145,
0,
0,
0,
18,
0,
0,
0,
18,
390,
50,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
385,
56,
58,
142,
388,
60,
61,
391,
0,
50,
392,
393,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
375,
16,
19,
0,
0,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
29,
375,
16,
19,
0,
377,
0,
379,
33,
0,
0,
0,
139,
0,
394,
60,
61,
391,
29,
50,
392,
393,
0,
377,
0,
379,
33,
375,
16,
19,
137,
50,
378,
0,
0,
415,
141,
0,
136,
0,
0,
18,
0,
0,
29,
0,
0,
390,
50,
377,
378,
379,
33,
0,
0,
0,
131,
0,
0,
18,
0,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
385,
56,
58,
378,
388,
60,
61,
391,
0,
0,
392,
393,
18,
375,
16,
19,
0,
50,
387,
58,
16,
388,
60,
61,
391,
0,
0,
392,
393,
0,
29,
412,
0,
97,
0,
377,
237,
380,
50,
0,
0,
377,
398,
0,
0,
99,
408,
101,
123,
121,
375,
16,
19,
107,
384,
0,
120,
118,
406,
385,
56,
58,
378,
388,
60,
61,
391,
29,
378,
392,
393,
18,
377,
50,
379,
33,
0,
18,
0,
37,
385,
56,
58,
0,
388,
60,
61,
391,
0,
97,
392,
393,
0,
0,
0,
0,
0,
0,
411,
378,
0,
0,
50,
0,
0,
0,
0,
0,
18,
107,
0,
0,
120,
118,
406,
385,
56,
58,
97,
388,
60,
61,
391,
0,
0,
392,
393,
410,
0,
0,
0,
50,
0,
0,
0,
0,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
97,
388,
60,
61,
391,
50,
0,
392,
393,
409,
0,
0,
65,
0,
0,
0,
0,
0,
0,
0,
107,
390,
50,
120,
118,
406,
385,
56,
58,
52,
388,
60,
61,
391,
50,
0,
392,
393,
390,
0,
111,
0,
403,
0,
113,
0,
0,
385,
56,
58,
0,
388,
60,
61,
391,
0,
50,
392,
393,
0,
0,
377,
0,
63,
385,
56,
58,
0,
388,
60,
61,
391,
390,
0,
392,
393,
386,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
378,
0,
0,
0,
0,
0,
0,
0,
50,
18,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
126,
0,
97,
0,
0,
0,
0,
0,
0,
0,
0,
398,
0,
0,
99,
408,
101,
123,
121,
0,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
50,
388,
60,
61,
391,
0,
0,
392,
393,
0,
0,
0,
0,
0,
94,
0,
97,
50,
0,
0,
0,
0,
0,
0,
0,
398,
0,
0,
99,
408,
101,
123,
121,
75,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
111,
0,
403,
50,
191,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
96,
0,
97,
50,
377,
0,
0,
0,
0,
0,
0,
398,
0,
0,
99,
408,
101,
123,
121,
397,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
378,
388,
60,
61,
391,
0,
50,
392,
393,
18,
0,
0,
208,
16,
385,
56,
58,
0,
388,
60,
61,
391,
97,
0,
392,
393,
0,
0,
0,
29,
0,
398,
0,
428,
377,
399,
101,
123,
121,
0,
50,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
0,
388,
60,
61,
391,
97,
0,
392,
393,
0,
378,
0,
0,
0,
398,
0,
0,
0,
50,
18,
103,
121,
0,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
97,
388,
60,
61,
391,
0,
0,
392,
393,
398,
0,
0,
0,
50,
0,
0,
105,
0,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
97,
388,
60,
61,
391,
50,
0,
392,
393,
400,
0,
0,
0,
0,
0,
0,
0,
0,
50,
0,
107,
401,
0,
120,
118,
406,
385,
56,
58,
0,
388,
60,
61,
391,
401,
0,
392,
393,
0,
0,
0,
0,
0,
0,
109,
118,
406,
385,
56,
58,
0,
388,
60,
61,
391,
0,
50,
392,
393,
405,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
97,
0,
0,
0,
0,
0,
0,
0,
0,
398,
0,
0,
0,
407,
101,
123,
121,
0,
50,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
0,
388,
60,
61,
391,
97,
0,
392,
393,
0,
0,
0,
0,
0,
398,
0,
0,
0,
0,
0,
125,
121,
0,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
50,
388,
60,
61,
391,
208,
16,
392,
393,
0,
0,
0,
432,
0,
128,
221,
97,
223,
0,
0,
0,
0,
29,
0,
0,
398,
427,
377,
99,
408,
101,
123,
121,
377,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
50,
388,
60,
61,
391,
0,
0,
392,
393,
378,
0,
0,
0,
0,
130,
378,
97,
0,
18,
0,
0,
0,
0,
0,
18,
398,
0,
0,
99,
408,
101,
123,
121,
0,
50,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
0,
388,
60,
61,
391,
97,
0,
392,
393,
0,
0,
0,
0,
0,
413,
134,
0,
0,
50,
0,
0,
0,
0,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
97,
388,
60,
61,
391,
50,
0,
392,
393,
414,
0,
0,
0,
0,
0,
0,
0,
0,
50,
0,
107,
416,
0,
120,
118,
406,
385,
56,
58,
0,
388,
60,
61,
391,
417,
0,
392,
393,
0,
50,
0,
0,
111,
0,
403,
0,
195,
385,
56,
58,
0,
388,
60,
61,
391,
144,
0,
392,
393,
0,
385,
56,
58,
377,
388,
60,
61,
391,
0,
0,
392,
393,
0,
0,
0,
0,
0,
0,
0,
50,
0,
385,
56,
58,
0,
388,
60,
61,
391,
0,
378,
392,
393,
418,
0,
97,
50,
0,
0,
18,
0,
0,
0,
0,
398,
0,
0,
99,
408,
101,
123,
121,
152,
50,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
0,
388,
60,
61,
391,
154,
0,
392,
393,
256,
0,
441,
440,
16,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
375,
16,
19,
29,
50,
385,
56,
58,
377,
388,
60,
61,
391,
0,
0,
392,
393,
29,
0,
0,
158,
0,
377,
0,
379,
33,
50,
0,
0,
156,
0,
0,
0,
0,
0,
378,
0,
375,
16,
19,
0,
0,
162,
0,
18,
0,
385,
56,
58,
378,
388,
60,
61,
391,
29,
0,
392,
393,
18,
377,
50,
379,
33,
0,
0,
0,
160,
166,
385,
56,
58,
0,
388,
60,
61,
391,
390,
50,
392,
393,
0,
0,
0,
0,
0,
0,
378,
0,
0,
50,
0,
0,
0,
168,
0,
18,
0,
0,
0,
0,
0,
50,
385,
56,
58,
170,
388,
60,
61,
391,
0,
0,
392,
393,
0,
0,
0,
175,
0,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
385,
56,
58,
0,
388,
60,
61,
391,
420,
0,
392,
393,
385,
56,
58,
0,
388,
60,
61,
391,
50,
0,
392,
393,
0,
0,
0,
187,
375,
16,
19,
0,
0,
0,
0,
0,
390,
0,
0,
0,
0,
0,
0,
0,
0,
199,
0,
0,
0,
0,
377,
0,
379,
33,
0,
0,
212,
37,
0,
0,
50,
0,
385,
56,
58,
0,
388,
60,
61,
391,
0,
0,
392,
393,
430,
0,
97,
378,
0,
0,
0,
0,
0,
0,
0,
398,
18,
0,
99,
408,
101,
123,
121,
0,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
50,
388,
60,
61,
391,
208,
16,
392,
393,
0,
0,
0,
432,
0,
429,
221,
97,
433,
0,
0,
216,
0,
29,
0,
0,
398,
431,
377,
99,
408,
101,
123,
121,
377,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
0,
388,
60,
61,
391,
0,
434,
392,
393,
378,
0,
435,
16,
50,
0,
378,
0,
0,
18,
436,
0,
243,
0,
0,
18,
0,
0,
437,
29,
97,
0,
0,
0,
377,
0,
0,
0,
0,
398,
0,
0,
99,
408,
101,
123,
121,
375,
16,
19,
107,
0,
0,
120,
118,
406,
385,
56,
58,
0,
388,
253,
61,
391,
29,
0,
392,
393,
0,
377,
18,
379,
249,
0,
439,
440,
16,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
29,
0,
0,
0,
378,
377,
0,
0,
0,
0,
0,
0,
0,
18,
0,
434,
260,
0,
0,
0,
435,
16,
50,
0,
0,
0,
0,
241,
438,
0,
243,
0,
378,
0,
0,
0,
437,
29,
97,
0,
0,
18,
377,
0,
0,
0,
0,
398,
0,
0,
99,
408,
101,
123,
121,
0,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
0,
388,
253,
61,
391,
263,
0,
392,
393,
50,
0,
18,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
430,
0,
97,
0,
0,
0,
0,
0,
0,
0,
0,
398,
0,
0,
99,
408,
101,
123,
121,
0,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
0,
388,
60,
61,
391,
434,
266,
392,
393,
0,
435,
16,
50,
0,
0,
0,
0,
241,
438,
0,
243,
0,
0,
0,
0,
0,
437,
29,
97,
0,
0,
0,
377,
0,
0,
0,
0,
398,
0,
0,
99,
408,
101,
123,
121,
0,
0,
0,
107,
0,
0,
120,
118,
406,
385,
56,
58,
0,
388,
253,
61,
391,
0,
0,
392,
393,
0,
0,
18,
0,
};
static	yyTCombType *	yyTBasePtr	[yyLastReadState + 1] = {
& yyTComb [0],
& yyTComb [0],
& yyTComb [0],
& yyTComb [0],
& yyTComb [0],
& yyTComb [1],
& yyTComb [0],
& yyTComb [104],
& yyTComb [0],
& yyTComb [0],
& yyTComb [0],
& yyTComb [0],
& yyTComb [0],
& yyTComb [159],
& yyTComb [247],
& yyTComb [0],
& yyTComb [44],
& yyTComb [0],
& yyTComb [1],
& yyTComb [244],
& yyTComb [0],
& yyTComb [12],
& yyTComb [1],
& yyTComb [2],
& yyTComb [0],
& yyTComb [5],
& yyTComb [0],
& yyTComb [0],
& yyTComb [0],
& yyTComb [9],
& yyTComb [0],
& yyTComb [0],
& yyTComb [0],
& yyTComb [163],
& yyTComb [0],
& yyTComb [0],
& yyTComb [0],
& yyTComb [55],
& yyTComb [0],
& yyTComb [0],
& yyTComb [0],
& yyTComb [0],
& yyTComb [2],
& yyTComb [125],
& yyTComb [0],
& yyTComb [3],
& yyTComb [0],
& yyTComb [2],
& yyTComb [0],
& yyTComb [0],
& yyTComb [335],
& yyTComb [0],
& yyTComb [56],
& yyTComb [429],
& yyTComb [1],
& yyTComb [0],
& yyTComb [519],
& yyTComb [549],
& yyTComb [609],
& yyTComb [0],
& yyTComb [0],
& yyTComb [703],
& yyTComb [0],
& yyTComb [1],
& yyTComb [0],
& yyTComb [756],
& yyTComb [0],
& yyTComb [0],
& yyTComb [67],
& yyTComb [0],
& yyTComb [20],
& yyTComb [69],
& yyTComb [2],
& yyTComb [0],
& yyTComb [0],
& yyTComb [35],
& yyTComb [2],
& yyTComb [22],
& yyTComb [71],
& yyTComb [7],
& yyTComb [9],
& yyTComb [0],
& yyTComb [105],
& yyTComb [3],
& yyTComb [14],
& yyTComb [15],
& yyTComb [17],
& yyTComb [25],
& yyTComb [24],
& yyTComb [100],
& yyTComb [28],
& yyTComb [29],
& yyTComb [31],
& yyTComb [77],
& yyTComb [94],
& yyTComb [0],
& yyTComb [98],
& yyTComb [801],
& yyTComb [0],
& yyTComb [573],
& yyTComb [0],
& yyTComb [833],
& yyTComb [0],
& yyTComb [866],
& yyTComb [0],
& yyTComb [898],
& yyTComb [0],
& yyTComb [931],
& yyTComb [178],
& yyTComb [963],
& yyTComb [0],
& yyTComb [109],
& yyTComb [0],
& yyTComb [123],
& yyTComb [0],
& yyTComb [186],
& yyTComb [4],
& yyTComb [116],
& yyTComb [996],
& yyTComb [0],
& yyTComb [1032],
& yyTComb [1067],
& yyTComb [0],
& yyTComb [1097],
& yyTComb [0],
& yyTComb [1127],
& yyTComb [125],
& yyTComb [0],
& yyTComb [127],
& yyTComb [0],
& yyTComb [124],
& yyTComb [146],
& yyTComb [200],
& yyTComb [245],
& yyTComb [146],
& yyTComb [0],
& yyTComb [157],
& yyTComb [150],
& yyTComb [0],
& yyTComb [154],
& yyTComb [0],
& yyTComb [142],
& yyTComb [159],
& yyTComb [0],
& yyTComb [134],
& yyTComb [169],
& yyTComb [178],
& yyTComb [336],
& yyTComb [167],
& yyTComb [0],
& yyTComb [156],
& yyTComb [0],
& yyTComb [156],
& yyTComb [0],
& yyTComb [156],
& yyTComb [0],
& yyTComb [175],
& yyTComb [0],
& yyTComb [154],
& yyTComb [0],
& yyTComb [245],
& yyTComb [0],
& yyTComb [155],
& yyTComb [156],
& yyTComb [1169],
& yyTComb [0],
& yyTComb [158],
& yyTComb [0],
& yyTComb [250],
& yyTComb [0],
& yyTComb [1],
& yyTComb [160],
& yyTComb [135],
& yyTComb [740],
& yyTComb [0],
& yyTComb [137],
& yyTComb [242],
& yyTComb [5],
& yyTComb [251],
& yyTComb [0],
& yyTComb [436],
& yyTComb [0],
& yyTComb [238],
& yyTComb [8],
& yyTComb [767],
& yyTComb [9],
& yyTComb [243],
& yyTComb [259],
& yyTComb [250],
& yyTComb [13],
& yyTComb [0],
& yyTComb [183],
& yyTComb [247],
& yyTComb [264],
& yyTComb [0],
& yyTComb [253],
& yyTComb [301],
& yyTComb [323],
& yyTComb [326],
& yyTComb [309],
& yyTComb [0],
& yyTComb [0],
& yyTComb [428],
& yyTComb [330],
& yyTComb [313],
& yyTComb [323],
& yyTComb [300],
& yyTComb [0],
& yyTComb [438],
& yyTComb [335],
& yyTComb [0],
& yyTComb [0],
& yyTComb [439],
& yyTComb [0],
& yyTComb [230],
& yyTComb [236],
& yyTComb [0],
& yyTComb [237],
& yyTComb [345],
& yyTComb [448],
& yyTComb [0],
& yyTComb [350],
& yyTComb [0],
& yyTComb [272],
& yyTComb [291],
& yyTComb [301],
& yyTComb [413],
& yyTComb [296],
& yyTComb [308],
& yyTComb [414],
& yyTComb [415],
& yyTComb [430],
& yyTComb [369],
& yyTComb [432],
& yyTComb [374],
& yyTComb [420],
& yyTComb [0],
& yyTComb [421],
& yyTComb [356],
& yyTComb [385],
& yyTComb [506],
& yyTComb [454],
& yyTComb [1233],
& yyTComb [402],
& yyTComb [508],
& yyTComb [509],
& yyTComb [517],
& yyTComb [433],
& yyTComb [0],
& yyTComb [490],
& yyTComb [427],
& yyTComb [424],
& yyTComb [538],
& yyTComb [522],
& yyTComb [985],
& yyTComb [494],
& yyTComb [483],
& yyTComb [0],
& yyTComb [548],
& yyTComb [0],
& yyTComb [441],
& yyTComb [549],
& yyTComb [552],
& yyTComb [544],
& yyTComb [553],
& yyTComb [459],
& yyTComb [460],
& yyTComb [568],
& yyTComb [0],
& yyTComb [570],
};
static	unsigned short*	yyNBasePtr	[yyLastReadState + 1] = {
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-122],
& yyNComb [-123],
& yyNComb [-121],
& yyNComb [-123],
& yyNComb [-105],
& yyNComb [-65],
& yyNComb [-48],
& yyNComb [-8],
& yyNComb [27],
& yyNComb [-123],
& yyNComb [-122],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [31],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [48],
& yyNComb [60],
& yyNComb [72],
& yyNComb [-123],
& yyNComb [-120],
& yyNComb [-123],
& yyNComb [89],
& yyNComb [128],
& yyNComb [146],
& yyNComb [-123],
& yyNComb [162],
& yyNComb [174],
& yyNComb [172],
& yyNComb [-123],
& yyNComb [231],
& yyNComb [233],
& yyNComb [268],
& yyNComb [-123],
& yyNComb [289],
& yyNComb [318],
& yyNComb [347],
& yyNComb [-123],
& yyNComb [-118],
& yyNComb [-123],
& yyNComb [-98],
& yyNComb [-123],
& yyNComb [-88],
& yyNComb [-123],
& yyNComb [368],
& yyNComb [-119],
& yyNComb [-123],
& yyNComb [385],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [254],
& yyNComb [-123],
& yyNComb [397],
& yyNComb [-117],
& yyNComb [191],
& yyNComb [10],
& yyNComb [-123],
& yyNComb [419],
& yyNComb [-123],
& yyNComb [111],
& yyNComb [-123],
& yyNComb [459],
& yyNComb [504],
& yyNComb [-123],
& yyNComb [-115],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-108],
& yyNComb [-123],
& yyNComb [521],
& yyNComb [-123],
& yyNComb [-105],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-98],
& yyNComb [-123],
& yyNComb [-113],
& yyNComb [-123],
& yyNComb [-93],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-88],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [561],
& yyNComb [-123],
& yyNComb [-82],
& yyNComb [578],
& yyNComb [-123],
& yyNComb [612],
& yyNComb [-123],
& yyNComb [646],
& yyNComb [-123],
& yyNComb [675],
& yyNComb [-123],
& yyNComb [704],
& yyNComb [-123],
& yyNComb [725],
& yyNComb [-123],
& yyNComb [404],
& yyNComb [-123],
& yyNComb [-112],
& yyNComb [-123],
& yyNComb [-40],
& yyNComb [-123],
& yyNComb [-45],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [738],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [776],
& yyNComb [-123],
& yyNComb [810],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [855],
& yyNComb [-123],
& yyNComb [900],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [934],
& yyNComb [-123],
& yyNComb [963],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [984],
& yyNComb [-123],
& yyNComb [997],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [1018],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [1058],
& yyNComb [-123],
& yyNComb [1075],
& yyNComb [-123],
& yyNComb [1092],
& yyNComb [-123],
& yyNComb [1131],
& yyNComb [-123],
& yyNComb [1133],
& yyNComb [-123],
& yyNComb [1168],
& yyNComb [-123],
& yyNComb [1155],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-82],
& yyNComb [1189],
& yyNComb [-123],
& yyNComb [1206],
& yyNComb [-123],
& yyNComb [1218],
& yyNComb [-100],
& yyNComb [-123],
& yyNComb [-120],
& yyNComb [-123],
& yyNComb [1230],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-119],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-68],
& yyNComb [-48],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [1280],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [559],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [1022],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [1290],
& yyNComb [-123],
& yyNComb [-120],
& yyNComb [-121],
& yyNComb [-123],
& yyNComb [-64],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-122],
& yyNComb [620],
& yyNComb [-123],
& yyNComb [862],
& yyNComb [-120],
& yyNComb [1320],
& yyNComb [-123],
& yyNComb [1365],
& yyNComb [-123],
& yyNComb [1372],
& yyNComb [-115],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [868],
& yyNComb [-123],
& yyNComb [1378],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [237],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [1423],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-51],
& yyNComb [-123],
& yyNComb [-48],
& yyNComb [1458],
& yyNComb [-123],
& yyNComb [-42],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [10],
& yyNComb [1117],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [1486],
& yyNComb [-123],
& yyNComb [1523],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [1577],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [1634],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-123],
& yyNComb [-120],
};
static	unsigned short	yyDefault	[yyLastReadState + 1] = {
0,
0,
0,
0,
265,
0,
116,
0,
186,
262,
186,
262,
198,
255,
0,
0,
0,
209,
0,
0,
186,
186,
186,
0,
116,
0,
186,
198,
198,
0,
186,
186,
198,
0,
198,
262,
198,
0,
133,
133,
133,
0,
116,
0,
116,
0,
116,
0,
186,
116,
0,
186,
147,
0,
0,
186,
0,
116,
14,
57,
57,
0,
186,
187,
57,
147,
262,
262,
0,
116,
0,
0,
76,
0,
186,
0,
0,
0,
0,
83,
0,
116,
0,
0,
0,
0,
0,
0,
0,
0,
83,
0,
0,
0,
0,
262,
0,
0,
186,
0,
133,
0,
133,
125,
133,
121,
133,
0,
186,
120,
209,
0,
116,
195,
209,
0,
0,
0,
0,
108,
0,
0,
133,
125,
133,
0,
0,
262,
0,
262,
0,
0,
0,
108,
0,
133,
0,
0,
186,
0,
186,
0,
0,
186,
0,
0,
0,
0,
0,
262,
0,
186,
0,
186,
0,
198,
0,
186,
0,
198,
0,
186,
0,
0,
170,
186,
187,
186,
0,
186,
0,
0,
177,
0,
186,
0,
0,
0,
0,
177,
0,
177,
186,
0,
0,
0,
57,
0,
0,
0,
209,
195,
0,
0,
209,
0,
0,
0,
254,
29,
245,
203,
0,
0,
0,
0,
0,
209,
0,
254,
250,
262,
0,
262,
0,
209,
250,
0,
0,
0,
209,
0,
209,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
209,
0,
0,
0,
0,
0,
262,
0,
0,
0,
0,
0,
198,
0,
0,
0,
0,
57,
0,
0,
0,
254,
0,
265,
0,
0,
133,
0,
0,
242,
0,
0,
0,
1,
};
static	unsigned char	yyLength	[yyLastReduceState - yyFirstReduceState + 1] = {
2,
1,
1,
1,
2,
6,
9,
12,
1,
3,
1,
1,
3,
1,
1,
3,
1,
3,
0,
1,
1,
3,
2,
4,
7,
7,
10,
9,
6,
4,
1,
1,
3,
3,
3,
6,
1,
2,
5,
5,
12,
1,
3,
3,
1,
3,
1,
1,
0,
1,
0,
3,
1,
3,
1,
4,
1,
1,
3,
0,
2,
0,
2,
0,
2,
0,
1,
1,
4,
1,
3,
1,
3,
1,
3,
1,
3,
1,
3,
4,
1,
3,
1,
3,
1,
3,
3,
1,
3,
1,
3,
1,
1,
2,
2,
2,
4,
4,
3,
7,
5,
5,
2,
1,
10,
11,
11,
12,
1,
1,
1,
1,
1,
1,
1,
1,
1,
3,
5,
3,
5,
0,
1,
1,
3,
3,
1,
5,
4,
1,
3,
1,
3,
1,
1,
3,
7,
1,
3,
1,
3,
1,
3,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
1,
2,
1,
1,
1,
1,
1,
4,
1,
1,
1,
6,
4,
5,
1,
8,
3,
3,
1,
1,
3,
6,
4,
6,
6,
2,
1,
3,
2,
4,
2,
3,
3,
5,
1,
2,
3,
2,
3,
1,
3,
3,
2,
1,
1,
1,
1,
};
static	yySymbolRange	yyLeftHandSide	[yyLastReduceState - yyFirstReduceState + 1] = {
190,
124,
123,
125,
125,
126,
126,
126,
128,
128,
130,
130,
134,
135,
136,
136,
137,
137,
127,
127,
138,
138,
139,
139,
139,
139,
139,
139,
139,
139,
139,
139,
139,
139,
139,
139,
139,
139,
139,
139,
139,
152,
152,
131,
148,
148,
132,
132,
141,
141,
142,
142,
154,
154,
155,
155,
155,
156,
156,
143,
143,
144,
144,
145,
145,
146,
146,
157,
157,
150,
150,
151,
151,
159,
159,
140,
140,
129,
129,
147,
147,
161,
161,
162,
162,
163,
163,
163,
164,
164,
165,
165,
158,
158,
158,
158,
158,
158,
158,
158,
158,
158,
158,
158,
158,
158,
158,
158,
168,
168,
168,
168,
168,
168,
168,
168,
168,
170,
170,
171,
171,
166,
166,
167,
167,
169,
169,
172,
172,
172,
173,
173,
174,
174,
160,
160,
149,
149,
175,
175,
176,
176,
177,
177,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
178,
179,
179,
180,
180,
180,
181,
181,
181,
181,
181,
181,
181,
181,
181,
181,
181,
181,
181,
181,
181,
181,
181,
181,
181,
181,
184,
184,
184,
184,
182,
182,
183,
183,
187,
185,
185,
186,
186,
133,
133,
153,
153,
188,
188,
189,
189,
};
static	yySymbolRange	yyContinuation	[yyLastReadState + 1] = {
0,
11,
1,
12,
108,
6,
1,
6,
1,
10,
1,
10,
1,
18,
21,
20,
19,
1,
20,
19,
1,
55,
77,
15,
1,
63,
1,
1,
1,
64,
1,
99,
1,
19,
1,
10,
1,
19,
10,
10,
10,
76,
77,
77,
1,
77,
1,
79,
1,
1,
6,
1,
19,
6,
1,
1,
7,
1,
6,
1,
1,
6,
1,
89,
1,
19,
10,
10,
15,
1,
63,
15,
89,
93,
1,
89,
1,
63,
15,
89,
93,
1,
89,
1,
89,
89,
89,
89,
63,
15,
89,
89,
89,
89,
85,
10,
86,
19,
1,
19,
10,
19,
10,
19,
10,
19,
10,
19,
1,
19,
1,
90,
1,
77,
1,
15,
1,
89,
19,
1,
19,
19,
10,
19,
10,
19,
81,
10,
83,
10,
83,
67,
15,
10,
89,
10,
99,
77,
1,
77,
1,
77,
63,
1,
89,
77,
55,
19,
67,
10,
81,
1,
82,
1,
83,
1,
67,
1,
89,
1,
89,
1,
89,
89,
68,
1,
89,
1,
89,
1,
12,
89,
1,
63,
1,
114,
15,
1,
89,
1,
65,
1,
1,
1,
65,
1,
1,
89,
14,
1,
1,
77,
14,
1,
1,
77,
14,
1,
1,
64,
12,
1,
19,
1,
19,
12,
107,
1,
107,
1,
108,
10,
108,
10,
108,
107,
108,
108,
1,
65,
1,
77,
1,
77,
118,
109,
1,
119,
111,
11,
15,
1,
63,
1,
63,
18,
1,
19,
89,
108,
1,
108,
10,
106,
1,
12,
12,
107,
1,
107,
108,
108,
1,
1,
1,
65,
89,
1,
12,
108,
108,
1,
10,
19,
12,
108,
108,
1,
0,
0,
};
static	unsigned short	yyFinalToProd	[yyLastReadNontermState - yyFirstReadTermState + 1] = {
631,
629,
630,
624,
667,
553,
589,
590,
591,
592,
593,
594,
595,
596,
597,
598,
599,
600,
601,
602,
603,
604,
605,
606,
607,
608,
609,
610,
611,
612,
613,
614,
615,
616,
617,
618,
619,
620,
621,
554,
555,
556,
557,
558,
559,
560,
561,
662,
625,
626,
491,
663,
656,
651,
658,
537,
577,
541,
632,
633,
549,
551,
550,
552,
546,
573,
572,
544,
545,
645,
659,
638,
636,
652,
657,
500,
581,
642,
644,
643,
641,
655,
634,
637,
513,
480,
468,
469,
471,
470,
477,
494,
496,
473,
474,
483,
484,
485,
450,
472,
451,
452,
661,
665,
664,
501,
490,
492,
666,
502,
503,
569,
567,
646,
521,
582,
583,
585,
588,
622,
520,
635,
639,
640,
587,
563,
565,
543,
536,
526,
535,
578,
457,
459,
460,
575,
576,
528,
527,
540,
539,
538,
580,
518,
519,
488,
650,
648,
524,
547,
654,
478,
517,
516,
515,
514,
498,
487,
509,
523,
522,
511,
458,
462,
475,
481,
466,
476,
465,
454,
456,
453,
446,
449,
448,
};

static	void	yyErrorRecovery		ARGS((yySymbolRange * yyTerminal, yyStateRange * yyStateStack, unsigned long yyStackSize, short yyStackPtr));
static	void	yyComputeContinuation	ARGS((yyStateRange * yyStack, unsigned long yyStackSize, short yyStackPtr, tSet * yyContinueSet));
static	bool	yyIsContinuation	ARGS((yySymbolRange yyTerminal, yyStateRange * yyStateStack, unsigned long yyStackSize, short yyStackPtr));
static	void	yyComputeRestartPoints	ARGS((yyStateRange * yyStateStack, unsigned long yyStackSize, short yyStackPtr, tSet * yyRestartSet));
static	yyStateRange yyNext		ARGS((yyStateRange yyState, yySymbolRange yySymbol));
static	void	BeginParser		();

int Parser ()
   {
      register	yyStateRange	yyState		;
      register	long		yyTerminal	;
      register	yyStateRange *	yyStateStackPtr ;
      register	tParsAttribute *yyAttrStackPtr	;
      register	bool		yyIsRepairing	;
		unsigned long	yyStateStackSize= yyInitStackSize;
		unsigned long	yyAttrStackSize = yyInitStackSize;
		yyStateRange *	yyStateStack	;
		tParsAttribute* yyAttributeStack;
		tParsAttribute	yySynAttribute	;	/* synthesized attribute */
      register	yyStateRange *	yyEndOfStack	;
		int		yyErrorCount	= 0;
   
/* line 182 "Parser.lalr" */



      BeginParser ();
      yyState		= yyStartState;
      yyTerminal	= GetToken ();
      MakeArray ((char * *) & yyStateStack, & yyStateStackSize, sizeof (yyStateRange));
      MakeArray ((char * *) & yyAttributeStack, & yyAttrStackSize, sizeof (tParsAttribute));
      yyEndOfStack	= & yyStateStack [yyStateStackSize];
      yyStateStackPtr	= yyStateStack;
      yyAttrStackPtr	= yyAttributeStack;
      yyIsRepairing	= false;

   ParseLoop:
      for (;;) {
	 if (yyStateStackPtr >= yyEndOfStack) {
	    int yyyStateStackPtr= yyStateStackPtr - yyStateStack;
	    int yyyAttrStackPtr	= yyAttrStackPtr - yyAttributeStack;
	    ExtendArray ((char * *) & yyStateStack, & yyStateStackSize, sizeof (yyStateRange));
	    ExtendArray ((char * *) & yyAttributeStack, & yyAttrStackSize, sizeof (tParsAttribute));
	    yyStateStackPtr	= yyStateStack + yyyStateStackPtr;
	    yyAttrStackPtr	= yyAttributeStack + yyyAttrStackPtr;
	    yyEndOfStack	= & yyStateStack [yyStateStackSize];
	 }
	 * yyStateStackPtr = yyState;

   TermTrans:
	 for (;;) {	/* SPEC State = Next (State, Terminal); terminal transition */
	    register short * yyTCombPtr;

	    yyTCombPtr = (short *) (yyTBasePtr [yyState] + yyTerminal);
	    if (* yyTCombPtr ++ == yyState) { yyState = * yyTCombPtr; break; }
	    if ((yyState = yyDefault [yyState]) != yyNoState) goto TermTrans;

							/* syntax error */
	    if (! yyIsRepairing) {			/* report and recover */
	       yySymbolRange yyyTerminal = yyTerminal;

	       yyErrorCount ++;
	       yyErrorRecovery (& yyyTerminal, yyStateStack, yyStateStackSize, yyStateStackPtr - yyStateStack);
	       yyTerminal = yyyTerminal;
	       yyIsRepairing = true;
	    }
	    yyState = * yyStateStackPtr;
	    for (;;) {
	       if (yyNext (yyState, (yySymbolRange) yyTerminal) == yyNoState) { /* repair */
		  yySymbolRange		yyRepairToken;
		  tScanAttribute	yyRepairAttribute;
	    
		  yyRepairToken = yyContinuation [yyState];
		  yyState = yyNext (yyState, yyRepairToken);
		  if (yyState <= yyLastReadTermState) { /* read or read terminal reduce ? */
		     ErrorAttribute ((int) yyRepairToken, & yyRepairAttribute);
		     ErrorMessageI (xxTokenInserted, xxRepair, Attribute.Position,
			xxString, Parser_TokenName [yyRepairToken]);
		     if (yyState >= yyFirstFinalState) {	/* avoid second push */
			yyState = yyFinalToProd [yyState - yyFirstReadTermState];
		     }
		     yyGetAttribute (yyAttrStackPtr ++, yyRepairAttribute);
		     * ++ yyStateStackPtr = yyState;
		  }
		  if (yyState >= yyFirstFinalState) goto Final; /* final state ? */
	       } else {
		  yyState = yyNext (yyState, (yySymbolRange) yyTerminal);
		  goto Final;
	       }
	    }
	 }

   Final:
	 if (yyState >= yyFirstFinalState) {		/* final state ? */
	    if (yyState <= yyLastReadTermState) {	/* read terminal reduce ? */
	       yyStateStackPtr ++;
	       yyGetAttribute (yyAttrStackPtr ++, Attribute);
	       yyTerminal = GetToken ();
	       yyIsRepairing = false;
	    }

	    for (;;) {
	       /* register long yyNonterminal;		/* left-hand side */
# define yyNonterminal yyState

switch (yyState) {
case 445: /* _0000_ : START _EndOfFile .*/
  ReleaseArray ((char * *) & yyStateStack, & yyStateStackSize, sizeof (yyStateRange));
  ReleaseArray ((char * *) & yyAttributeStack, & yyAttrStackSize, sizeof (tParsAttribute));
  return yyErrorCount;

case 446:
case 442: /* START : Spec .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 124; {

} break;
case 447: /* Spec : ModuleItemList .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 123; {
/* line 330 "Parser.lalr" */

    ;
{  TreeRoot = mSum(ReverseTree(yyAttrStackPtr [1-1].ModuleItemList.Tree));  }
;

} break;
case 448:
case 444: /* ModuleItemList : ModuleItem .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 125; {
/* line 335 "Parser.lalr" */

            yyAttrStackPtr [1-1].ModuleItem.Tree->Module.Next = mNoModule();
            yySynAttribute.ModuleItemList.Tree = yyAttrStackPtr [1-1].ModuleItem.Tree;
        ;

    ;

} break;
case 449:
case 443: /* ModuleItemList : ModuleItemList ModuleItem .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 125; {
/* line 342 "Parser.lalr" */

            yyAttrStackPtr [2-1].ModuleItem.Tree->Module.Next = yyAttrStackPtr [1-1].ModuleItemList.Tree;
            yySynAttribute.ModuleItemList.Tree = yyAttrStackPtr [2-1].ModuleItem.Tree;
        ;

    ;

} break;
case 450:
case 368: /* ModuleItem : module Id is Decl_List end Id .*/
  yyStateStackPtr -=6; yyAttrStackPtr -=6; yyNonterminal = 126; {
/* line 349 "Parser.lalr" */

			if (yyAttrStackPtr [2-1].Scan.Id.Ident.Ident != yyAttrStackPtr [6-1].Scan.Id.Ident.Ident) {
				ErrorMessageI (xxSyntaxError, xxError, 
					yyAttrStackPtr [6-1].Scan.Id.Ident.Pos, xxString, error10);
				CountErr++;
			}
			yySynAttribute.ModuleItem.Tree = mModule (NoTree, yyAttrStackPtr [2-1].Scan.Id.Ident, mNoParam(), mNoPred(),
				ReverseTree(yyAttrStackPtr [4-1].Decl_List.Tree), 0);
		;

	;

} break;
case 451:
case 370: /* ModuleItem : module Id '(' FormalList ')' is Decl_List end Id .*/
  yyStateStackPtr -=9; yyAttrStackPtr -=9; yyNonterminal = 126; {
/* line 361 "Parser.lalr" */

			if (yyAttrStackPtr [2-1].Scan.Id.Ident.Ident != yyAttrStackPtr [9-1].Scan.Id.Ident.Ident) {
				ErrorMessageI (xxSyntaxError, xxError, 
					yyAttrStackPtr [9-1].Scan.Id.Ident.Pos, xxString, error10);
				CountErr++;
			}
			yySynAttribute.ModuleItem.Tree = mModule (NoTree, yyAttrStackPtr [2-1].Scan.Id.Ident, ReverseTree(yyAttrStackPtr [4-1].FormalList.Tree), mNoPred(),
				ReverseTree(yyAttrStackPtr [7-1].Decl_List.Tree), 0);
		;

	;

} break;
case 452:
case 371: /* ModuleItem : module Id '(' FormalList ')' '[' PredList ']' is Decl_List end Id .*/
  yyStateStackPtr -=12; yyAttrStackPtr -=12; yyNonterminal = 126; {
/* line 373 "Parser.lalr" */

			if (yyAttrStackPtr [2-1].Scan.Id.Ident.Ident != yyAttrStackPtr [12-1].Scan.Id.Ident.Ident) {
				ErrorMessageI (xxSyntaxError, xxError, 
					yyAttrStackPtr [12-1].Scan.Id.Ident.Pos, xxString, error10);
				CountErr++;
			}
			yySynAttribute.ModuleItem.Tree = mModule (NoTree, yyAttrStackPtr [2-1].Scan.Id.Ident, ReverseTree(yyAttrStackPtr [4-1].FormalList.Tree),
				ReverseTree(yyAttrStackPtr [7-1].PredList.Tree), 
				ReverseTree(yyAttrStackPtr [10-1].Decl_List.Tree), 0);
		;

	;

} break;
case 453:
case 441: /* FormalList : Formal .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 128; {
/* line 386 "Parser.lalr" */

            yyAttrStackPtr [1-1].Formal.Tree->Param.Next = mNoParam();
            yySynAttribute.FormalList.Tree = yyAttrStackPtr [1-1].Formal.Tree;
        ;

    ;

} break;
case 454:
case 439: /* FormalList : FormalList ';' Formal .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 128; {
/* line 393 "Parser.lalr" */

            yyAttrStackPtr [3-1].Formal.Tree->Param.Next = yyAttrStackPtr [1-1].FormalList.Tree;
            yySynAttribute.FormalList.Tree = yyAttrStackPtr [3-1].Formal.Tree;
        ;

    ;

} break;
case 455: /* Formal : Id .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 130; {
/* line 400 "Parser.lalr" */

        yySynAttribute.Formal.Tree = mTyParam(NoTree, yyAttrStackPtr [1-1].Scan.Id.Ident, false);

    ;

} break;
case 456:
case 440: /* Formal : VarDecl .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 130; {
/* line 405 "Parser.lalr" */

            yyAttrStackPtr [1-1].VarDecl.Tree->Decl.Next = mNoDecl();
            yyAttrStackPtr [1-1].VarDecl.Tree->VarDecl.VarDeclKind = Is_param; 
            yySynAttribute.Formal.Tree = mFncParam(NoTree, yyAttrStackPtr [1-1].VarDecl.Tree); 
        ;

    ;

} break;
case 457:
case 402: /* Rename : DeclName '/' Name .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 134; {
/* line 413 "Parser.lalr" */

    yySynAttribute.Rename.Tree = mRename(NoTree, yyAttrStackPtr [1-1].DeclName.Ident, yyAttrStackPtr [3-1].Name.Tree);
 
;

} break;
case 458:
case 432: /* Selection : DeclName .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 135; {
/* line 418 "Parser.lalr" */
 
    yySynAttribute.Selection.Tree = mSelection(NoTree, yyAttrStackPtr [1-1].DeclName.Ident);

;

} break;
case 459:
case 403: /* Renames : Rename .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 136; {
/* line 423 "Parser.lalr" */

            yyAttrStackPtr [1-1].Rename.Tree->Rename.Next = mNoRename();
            yySynAttribute.Renames.Tree = yyAttrStackPtr [1-1].Rename.Tree;
        ;

    ;

} break;
case 460:
case 404: /* Renames : Renames ',' Rename .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 136; {
/* line 430 "Parser.lalr" */

            yyAttrStackPtr [3-1].Rename.Tree->Rename.Next = yyAttrStackPtr [1-1].Renames.Tree;
            yySynAttribute.Renames.Tree = yyAttrStackPtr [3-1].Rename.Tree;
        ;

    ;

} break;
case 461: /* Selections : Selection .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 137; {
/* line 437 "Parser.lalr" */

            yyAttrStackPtr [1-1].Selection.Tree->Selection.Next = mNoSelection();
            yySynAttribute.Selections.Tree = yyAttrStackPtr [1-1].Selection.Tree;
        ;

    ;

} break;
case 462:
case 433: /* Selections : Selection ',' Selections .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 137; {
/* line 444 "Parser.lalr" */

            yyAttrStackPtr [1-1].Selection.Tree->Selection.Next = yyAttrStackPtr [3-1].Selections.Tree;
            yySynAttribute.Selections.Tree = yyAttrStackPtr [1-1].Selection.Tree;
        ;

    ;

} break;
case 463: /* Decl_List : .*/
  yyStateStackPtr -=0; yyAttrStackPtr -=0; yyNonterminal = 127; {
/* line 451 "Parser.lalr" */

        yySynAttribute.Decl_List.Tree = mNoDecl();

    ;

} break;
case 464: /* Decl_List : DeclList .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 127; {
/* line 456 "Parser.lalr" */

        yySynAttribute.Decl_List.Tree  =  yyAttrStackPtr [1-1].DeclList.Tree;

    ;

} break;
case 465:
case 438: /* DeclList : Declaration .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 138; {
/* line 461 "Parser.lalr" */

            yyAttrStackPtr [1-1].Declaration.Tree->Decl.Next = mNoDecl();
            yySynAttribute.DeclList.Tree = yyAttrStackPtr [1-1].Declaration.Tree;
        ;

    ;

} break;
case 466:
case 436: /* DeclList : DeclList ';' Declaration .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 138; {
/* line 468 "Parser.lalr" */

            yyAttrStackPtr [3-1].Declaration.Tree->Decl.Next = yyAttrStackPtr [1-1].DeclList.Tree;    
            yySynAttribute.DeclList.Tree = yyAttrStackPtr [3-1].Declaration.Tree;
        ;

    ;

} break;
case 467: /* Declaration : import Id .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 139; {
/* line 475 "Parser.lalr" */

            yySynAttribute.Declaration.Tree = mImport (NoTree, yyAttrStackPtr [2-1].Scan.Id.Ident, mNoExp(),
                mNoRename(), yyAttrStackPtr [2-1].Scan.Id.Ident);

        ;

} break;
case 468:
case 356: /* Declaration : import Id as Id .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 139; {
/* line 481 "Parser.lalr" */

            yySynAttribute.Declaration.Tree = mImport (NoTree, yyAttrStackPtr [2-1].Scan.Id.Ident, mNoExp(),
                mNoRename(), yyAttrStackPtr [4-1].Scan.Id.Ident);

        ;

} break;
case 469:
case 357: /* Declaration : import Id '(' ExpList ')' as Id .*/
  yyStateStackPtr -=7; yyAttrStackPtr -=7; yyNonterminal = 139; {
/* line 487 "Parser.lalr" */

            yySynAttribute.Declaration.Tree = mImport (NoTree, yyAttrStackPtr [2-1].Scan.Id.Ident,
                ReverseTree (yyAttrStackPtr [4-1].ExpList.Tree),
                mNoRename(), yyAttrStackPtr [7-1].Scan.Id.Ident);

        ;

} break;
case 470:
case 359: /* Declaration : import Id '{' Renames '}' as Id .*/
  yyStateStackPtr -=7; yyAttrStackPtr -=7; yyNonterminal = 139; {
/* line 494 "Parser.lalr" */

            yySynAttribute.Declaration.Tree = mImport (NoTree, yyAttrStackPtr [2-1].Scan.Id.Ident, mNoExp(),
                ReverseTree(yyAttrStackPtr [4-1].Renames.Tree), yyAttrStackPtr [7-1].Scan.Id.Ident);

        ;

} break;
case 471:
case 358: /* Declaration : import Id '(' ExpList ')' '{' Renames '}' as Id .*/
  yyStateStackPtr -=10; yyAttrStackPtr -=10; yyNonterminal = 139; {
/* line 500 "Parser.lalr" */

            yySynAttribute.Declaration.Tree = mImport (NoTree, yyAttrStackPtr [2-1].Scan.Id.Ident,
                ReverseTree (yyAttrStackPtr [4-1].ExpList.Tree),
                ReverseTree(yyAttrStackPtr [7-1].Renames.Tree), yyAttrStackPtr [10-1].Scan.Id.Ident);

        ;

} break;
case 472:
case 369: /* Declaration : Oper schema Id SchFormal_List is SchDecl SchPred end Id .*/
  yyStateStackPtr -=9; yyAttrStackPtr -=9; yyNonterminal = 139; {
/* line 507 "Parser.lalr" */

            if (yyAttrStackPtr [3-1].Scan.Id.Ident.Ident == Ident_state && (yyAttrStackPtr [1-1].Oper.IsOp || yyAttrStackPtr [4-1].SchFormal_List.Tree->Kind != kNoParam)) {
                ErrorMessageI (xxSyntaxError, xxError, yyAttrStackPtr [3-1].Scan.Id.Ident.Pos, xxString, error19);
                CountErr++;
            }
            if (yyAttrStackPtr [3-1].Scan.Id.Ident.Ident != yyAttrStackPtr [9-1].Scan.Id.Ident.Ident) {
                ErrorMessageI (xxSyntaxError, xxError, 
                    yyAttrStackPtr [9-1].Scan.Id.Ident.Pos, xxString, error10);
                CountErr++;
            }
            if (yyAttrStackPtr [3-1].Scan.Id.Ident.Ident == Ident_init)
                yyAttrStackPtr [1-1].Oper.IsOp = 1;
            yySynAttribute.Declaration.Tree = mSchemaDef(NoTree, yyAttrStackPtr [3-1].Scan.Id.Ident, yyAttrStackPtr [4-1].SchFormal_List.Tree,
            ReverseTree(yyAttrStackPtr [6-1].SchDecl.Tree), ReverseTree(yyAttrStackPtr [7-1].SchPred.Tree), yyAttrStackPtr [1-1].Oper.IsOp);
        ;

    ;

} break;
case 473:
case 363: /* Declaration : axiom SchFormal_List is AxiomDecl SchPred end .*/
  yyStateStackPtr -=6; yyAttrStackPtr -=6; yyNonterminal = 139; {
/* line 525 "Parser.lalr" */

        yySynAttribute.Declaration.Tree = mAxiomDecl (NoTree, yyAttrStackPtr [2-1].SchFormal_List.Tree, yyAttrStackPtr [4-1].AxiomDecl.Tree,
                ReverseTree(yyAttrStackPtr [5-1].SchPred.Tree));

    ;

} break;
case 474:
case 364: /* Declaration : function FunctionDecl SchPred end .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 139; {
/* line 531 "Parser.lalr" */

        yySynAttribute.Declaration.Tree = mFunctionDecl (NoTree, yyAttrStackPtr [2-1].FunctionDecl.Tree,
                ReverseTree(yyAttrStackPtr [3-1].SchPred.Tree));

    ;

} break;
case 475:
case 434: /* Declaration : ModuleItem .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 139; {
/* line 537 "Parser.lalr" */

            yyAttrStackPtr [1-1].ModuleItem.Tree->Module.Next = mNoModule();
            yyAttrStackPtr [1-1].ModuleItem.Tree->Module.IsNested = 1;
            yySynAttribute.Declaration.Tree = mModuleDecl (NoTree, yyAttrStackPtr [1-1].ModuleItem.Tree);
        ;

    ;

} break;
case 476:
case 437: /* Declaration : Predicate .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 139; {
/* line 545 "Parser.lalr" */

        yySynAttribute.Declaration.Tree = mConstraint(NoTree, yyAttrStackPtr [1-1].Predicate.Tree);

    ;

} break;
case 477:
case 360: /* Declaration : '[' DeclNameList ']' .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 139; {
/* line 550 "Parser.lalr" */

        yySynAttribute.Declaration.Tree = mGivenSet(NoTree, yyAttrStackPtr [2-1].DeclNameList.Tree);

    ;

} break;
case 478:
case 421: /* Declaration : Id '==' Expression .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 139; {
/* line 555 "Parser.lalr" */

        yySynAttribute.Declaration.Tree = mAbbreviation(NoTree, yyAttrStackPtr [1-1].Scan.Id.Ident, yyAttrStackPtr [3-1].Expression.Tree);
 
    ;

} break;
case 479: /* Declaration : Id '::=' BranchList .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 139; {
/* line 560 "Parser.lalr" */

               { tTree list=yyAttrStackPtr [3-1].BranchList.Tree;
                 for (; list->Kind != kNoBranch; list=list->Branch.Next)
                    list->Branch.FTIdent = yyAttrStackPtr [1-1].Scan.Id.Ident.Ident;
               }
               yySynAttribute.Declaration.Tree = mFreeType(NoTree, yyAttrStackPtr [1-1].Scan.Id.Ident, ReverseTree(yyAttrStackPtr [3-1].BranchList.Tree));
             ;

          ;

} break;
case 480:
case 355: /* Declaration : Id '::=' enum '(' EnumList ')' .*/
  yyStateStackPtr -=6; yyAttrStackPtr -=6; yyNonterminal = 139; {
/* line 570 "Parser.lalr" */

               { tTree list=yyAttrStackPtr [5-1].EnumList.Tree;
                 for (; list->Kind != kNoBranch; list=list->Branch.Next)
                    list->Branch.FTIdent = yyAttrStackPtr [1-1].Scan.Id.Ident.Ident;

               }
               yySynAttribute.Declaration.Tree = mEnum (NoTree, yyAttrStackPtr [1-1].Scan.Id.Ident, ReverseTree(yyAttrStackPtr [5-1].EnumList.Tree));
             ;

        ;

} break;
case 481:
case 435: /* Declaration : VarDecl .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 139; {
/* line 581 "Parser.lalr" */

        yySynAttribute.Declaration.Tree  =  yyAttrStackPtr [1-1].VarDecl.Tree;

    ;

} break;
case 482: /* Declaration : visible Id .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 139; {
/* line 586 "Parser.lalr" */

            yySynAttribute.Declaration.Tree = mVisibility (NoTree, yyAttrStackPtr [2-1].Scan.Id.Ident, mNoSelection());

        ;

} break;
case 483:
case 365: /* Declaration : visible Id '{' Selections '}' .*/
  yyStateStackPtr -=5; yyAttrStackPtr -=5; yyNonterminal = 139; {
/* line 591 "Parser.lalr" */

            yySynAttribute.Declaration.Tree = mVisibility (NoTree, yyAttrStackPtr [2-1].Scan.Id.Ident, yyAttrStackPtr [4-1].Selections.Tree);

        ;

} break;
case 484:
case 366: /* Declaration : '(-+' ergo axiom Id '+-)' .*/
  yyStateStackPtr -=5; yyAttrStackPtr -=5; yyNonterminal = 139; {
/* line 596 "Parser.lalr" */

        yySynAttribute.Declaration.Tree = mErgoAnno (NoTree, yyAttrStackPtr [4-1].Scan.Id.Ident);

    ;

} break;
case 485:
case 367: /* Declaration : state_machine '==' module '(' Id ',' Id ',' '[' DeclNameList ']' ')' .*/
  yyStateStackPtr -=12; yyAttrStackPtr -=12; yyNonterminal = 139; {
/* line 601 "Parser.lalr" */

        yySynAttribute.Declaration.Tree = mStateMachine (NoTree, yyAttrStackPtr [10-1].DeclNameList.Tree);

    ;

} break;
case 486: /* VarDeclList : VarDecl .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 152; {
/* line 606 "Parser.lalr" */

            yyAttrStackPtr [1-1].VarDecl.Tree->Decl.Next = mNoDecl();
            yySynAttribute.VarDeclList.Tree = yyAttrStackPtr [1-1].VarDecl.Tree;
        ;

    ;

} break;
case 487:
case 427: /* VarDeclList : VarDecl ';' VarDeclList .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 152; {
/* line 613 "Parser.lalr" */

            yyAttrStackPtr [1-1].VarDecl.Tree->Decl.Next = yyAttrStackPtr [3-1].VarDeclList.Tree;
            yySynAttribute.VarDeclList.Tree = yyAttrStackPtr [1-1].VarDecl.Tree;
        ;

    ;

} break;
case 488:
case 415: /* VarDecl : DeclNameList ':' Expression .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 131; {
/* line 620 "Parser.lalr" */

    yySynAttribute.VarDecl.Tree = mVarDecl(NoTree, yyAttrStackPtr [1-1].DeclNameList.Tree, yyAttrStackPtr [3-1].Expression.Tree, Is_decl_id);
 
;

} break;
case 489: /* DeclNameList : DeclName .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 148; {
/* line 625 "Parser.lalr" */

        yySynAttribute.DeclNameList.Tree = mId(mNoId(), yyAttrStackPtr [1-1].DeclName.Ident, yyAttrStackPtr [1-1].DeclName.NameIdKind);

    ;

} break;
case 490:
case 376: /* DeclNameList : DeclName ',' DeclNameList .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 148; {
/* line 630 "Parser.lalr" */

        yySynAttribute.DeclNameList.Tree = mId(yyAttrStackPtr [3-1].DeclNameList.Tree, yyAttrStackPtr [1-1].DeclName.Ident, yyAttrStackPtr [1-1].DeclName.NameIdKind);

    ;

} break;
case 491:
case 320: /* DeclName : Id .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 132; {
/* line 635 "Parser.lalr" */

        yySynAttribute.DeclName.Ident  =  yyAttrStackPtr [1-1].Scan.Id.Ident;

        yySynAttribute.DeclName.NameIdKind = ID;

    ;

} break;
case 492:
case 377: /* DeclName : Opname .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 132; {
/* line 642 "Parser.lalr" */

        yySynAttribute.DeclName.Ident  =  yyAttrStackPtr [1-1].Opname.Ident;

        yySynAttribute.DeclName.NameIdKind = OPNAME;

    ;

} break;
case 493: /* Oper : .*/
  yyStateStackPtr -=0; yyAttrStackPtr -=0; yyNonterminal = 141; {
/* line 649 "Parser.lalr" */
 yySynAttribute.Oper.IsOp = 0;
 ;

} break;
case 494:
case 361: /* Oper : op .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 141; {
/* line 652 "Parser.lalr" */
 yySynAttribute.Oper.IsOp = 1;
 ;

} break;
case 495: /* SchFormal_List : .*/
  yyStateStackPtr -=0; yyAttrStackPtr -=0; yyNonterminal = 142; {
/* line 655 "Parser.lalr" */

        yySynAttribute.SchFormal_List.Tree = mNoParam();

    ;

} break;
case 496:
case 362: /* SchFormal_List : '[' SchFormalList ']' .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 142; {
/* line 660 "Parser.lalr" */

        yySynAttribute.SchFormal_List.Tree  =  yyAttrStackPtr [2-1].SchFormalList.Tree;

    ;

} break;
case 497: /* SchFormalList : Id .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 154; {
/* line 665 "Parser.lalr" */

        yySynAttribute.SchFormalList.Tree = mTyParam (mNoParam(), yyAttrStackPtr [1-1].Scan.Id.Ident, false);

    ;

} break;
case 498:
case 426: /* SchFormalList : Id ',' SchFormalList .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 154; {
/* line 670 "Parser.lalr" */

        yySynAttribute.SchFormalList.Tree = mTyParam (yyAttrStackPtr [3-1].SchFormalList.Tree, yyAttrStackPtr [1-1].Scan.Id.Ident, false);

    ;

} break;
case 499: /* BasicDecl : Name .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 155; {
/* line 675 "Parser.lalr" */

        yySynAttribute.BasicDecl.Tree = mSchemaIncl (NoTree, yyAttrStackPtr [1-1].Name.Tree, mNoExp());

    ;

} break;
case 500:
case 345: /* BasicDecl : Name '[' ExpList ']' .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 155; {
/* line 680 "Parser.lalr" */

        yySynAttribute.BasicDecl.Tree = mSchemaIncl (NoTree, yyAttrStackPtr [1-1].Name.Tree, ReverseTree (yyAttrStackPtr [3-1].ExpList.Tree));

    ;

} break;
case 501:
case 375: /* BasicDecl : VarDecl .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 155; {
/* line 685 "Parser.lalr" */
yySynAttribute.BasicDecl.Tree = yyAttrStackPtr [1-1].VarDecl.Tree;

        ;
{ 
            yyAttrStackPtr [1-1].VarDecl.Tree->VarDecl.VarDeclKind = Is_schema_field; 
         }
    ;

} break;
case 502:
case 379: /* BasicDeclList : BasicDecl .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 156; {
/* line 693 "Parser.lalr" */

            yyAttrStackPtr [1-1].BasicDecl.Tree->Decl.Next = mNoDecl();
            yySynAttribute.BasicDeclList.Tree = yyAttrStackPtr [1-1].BasicDecl.Tree;
        ;

    ;

} break;
case 503:
case 380: /* BasicDeclList : BasicDeclList ';' BasicDecl .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 156; {
/* line 700 "Parser.lalr" */

            yyAttrStackPtr [3-1].BasicDecl.Tree->Decl.Next = yyAttrStackPtr [1-1].BasicDeclList.Tree;
            yySynAttribute.BasicDeclList.Tree = yyAttrStackPtr [3-1].BasicDecl.Tree;
        ;

    ;

} break;
case 504: /* SchDecl : .*/
  yyStateStackPtr -=0; yyAttrStackPtr -=0; yyNonterminal = 143; {
/* line 707 "Parser.lalr" */

        yySynAttribute.SchDecl.Tree = mNoDecl();

    ;

} break;
case 505: /* SchDecl : dec BasicDeclList .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 143; {
/* line 712 "Parser.lalr" */

        yySynAttribute.SchDecl.Tree  =  yyAttrStackPtr [2-1].BasicDeclList.Tree;

    ;

} break;
case 506: /* SchPred : .*/
  yyStateStackPtr -=0; yyAttrStackPtr -=0; yyNonterminal = 144; {
/* line 717 "Parser.lalr" */
 
        yySynAttribute.SchPred.Tree = mNoPred();

    ;

} break;
case 507: /* SchPred : pred PredList .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 144; {
/* line 722 "Parser.lalr" */

        yySynAttribute.SchPred.Tree  =  yyAttrStackPtr [2-1].PredList.Tree;

    ;

} break;
case 508: /* AxiomDecl : .*/
  yyStateStackPtr -=0; yyAttrStackPtr -=0; yyNonterminal = 145; {
/* line 727 "Parser.lalr" */

        yySynAttribute.AxiomDecl.Tree = mNoDecl();

    ;

} break;
case 509:
case 428: /* AxiomDecl : dec VarDeclList .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 145; {
/* line 732 "Parser.lalr" */

            { tTree list=yyAttrStackPtr [2-1].VarDeclList.Tree;
                for (; list->Kind != kNoDecl; list=list->VarDecl.Next)
                    list->VarDecl.VarDeclKind = Is_axiom_id;
            }
            yySynAttribute.AxiomDecl.Tree = yyAttrStackPtr [2-1].VarDeclList.Tree;
        ;

    ;

} break;
case 510: /* FunctionDecl : .*/
  yyStateStackPtr -=0; yyAttrStackPtr -=0; yyNonterminal = 146; {
/* line 742 "Parser.lalr" */

        yySynAttribute.FunctionDecl.Tree = mNoDecl();

    ;

} break;
case 511:
case 431: /* FunctionDecl : VarDeclList .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 146; {
/* line 747 "Parser.lalr" */

            { tTree list=yyAttrStackPtr [1-1].VarDeclList.Tree;
                for (; list->Kind != kNoDecl; list=list->VarDecl.Next)
                    list->VarDecl.VarDeclKind = Is_axiom_id;
            }
            yySynAttribute.FunctionDecl.Tree = yyAttrStackPtr [1-1].VarDeclList.Tree;
        ;

    ;

} break;
case 512: /* Branch : Id .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 157; {
/* line 757 "Parser.lalr" */

        yySynAttribute.Branch.Tree = mFTConstant (NoTree, NoIdent, yyAttrStackPtr [1-1].Scan.Id.Ident);
 
    ;

} break;
case 513:
case 354: /* Branch : Id '<<' Expression '>>' .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 157; {
/* line 762 "Parser.lalr" */

        yySynAttribute.Branch.Tree = mFTConstructor (NoTree, NoIdent, yyAttrStackPtr [1-1].Scan.Id.Ident, yyAttrStackPtr [3-1].Expression.Tree);
 
    ;

} break;
case 514:
case 425: /* BranchList : Branch .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 150; {
/* line 767 "Parser.lalr" */

            yyAttrStackPtr [1-1].Branch.Tree->Branch.Next = mNoBranch();
            yySynAttribute.BranchList.Tree = yyAttrStackPtr [1-1].Branch.Tree; 
        ;

    ;

} break;
case 515:
case 424: /* BranchList : BranchList '|' Branch .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 150; {
/* line 774 "Parser.lalr" */

            yyAttrStackPtr [3-1].Branch.Tree->Branch.Next = yyAttrStackPtr [1-1].BranchList.Tree;
            yySynAttribute.BranchList.Tree = yyAttrStackPtr [3-1].Branch.Tree; 
        ;

    ;

} break;
case 516:
case 423: /* EnumList : Branch .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 151; {
/* line 781 "Parser.lalr" */

            yyAttrStackPtr [1-1].Branch.Tree->Branch.Next = mNoBranch();
            yySynAttribute.EnumList.Tree = yyAttrStackPtr [1-1].Branch.Tree; 
        ;

    ;

} break;
case 517:
case 422: /* EnumList : EnumList ',' Branch .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 151; {
/* line 788 "Parser.lalr" */

            yyAttrStackPtr [3-1].Branch.Tree->Branch.Next = yyAttrStackPtr [1-1].EnumList.Tree;
            yySynAttribute.EnumList.Tree = yyAttrStackPtr [3-1].Branch.Tree; 
        ;

    ;

} break;
case 518:
case 413: /* AndPredList : BasicPredicate .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 159; {
/* line 795 "Parser.lalr" */
yySynAttribute.AndPredList.Tree = yyAttrStackPtr [1-1].BasicPredicate.Tree;

} break;
case 519:
case 414: /* AndPredList : AndPredList 'and' BasicPredicate .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 159; {
/* line 797 "Parser.lalr" */

            yyAttrStackPtr [3-1].BasicPredicate.Tree->Pred.Next = yyAttrStackPtr [1-1].AndPredList.Tree;
            yySynAttribute.AndPredList.Tree = yyAttrStackPtr [3-1].BasicPredicate.Tree;
        ;

    ;

} break;
case 520:
case 390: /* ExpList : Expression .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 140; {
/* line 804 "Parser.lalr" */
yySynAttribute.ExpList.Tree = yyAttrStackPtr [1-1].Expression.Tree;

} break;
case 521:
case 384: /* ExpList : ExpList ',' Expression .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 140; {
/* line 806 "Parser.lalr" */

            yyAttrStackPtr [3-1].Expression.Tree->Exp.Next = yyAttrStackPtr [1-1].ExpList.Tree;
            yySynAttribute.ExpList.Tree = yyAttrStackPtr [3-1].Expression.Tree;
        ;

    ;

} break;
case 522:
case 430: /* PredList : Predicate .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 129; {
/* line 813 "Parser.lalr" */

        yySynAttribute.PredList.Tree  =  yyAttrStackPtr [1-1].Predicate.Tree;

    ;

} break;
case 523:
case 429: /* PredList : PredList ';' Predicate .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 129; {
/* line 818 "Parser.lalr" */

            yyAttrStackPtr [3-1].Predicate.Tree->Pred.Next = yyAttrStackPtr [1-1].PredList.Tree; 
            yySynAttribute.PredList.Tree = yyAttrStackPtr [3-1].Predicate.Tree;
        ;

    ;

} break;
case 524:
case 418: /* Predicate : Quantifier SchemaText '@' Predicate .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 147; {
/* line 825 "Parser.lalr" */

            {  
               
               yyAttrStackPtr [2-1].SchemaText.Tree->SchemaText.Is_local_dec = true;
            }
            yySynAttribute.Predicate.Tree = mQuantPred(mNoPred(), yyAttrStackPtr [1-1].Scan.Quantifier.Ident,
                yyAttrStackPtr [2-1].SchemaText.Tree, yyAttrStackPtr [4-1].Predicate.Tree);
        ;

    ;

} break;
case 525: /* Predicate : LogPredEquivalence .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 147; {
/* line 836 "Parser.lalr" */
yySynAttribute.Predicate.Tree = yyAttrStackPtr [1-1].LogPredEquivalence.Tree;

} break;
case 526:
case 399: /* LogPredEquivalence : LogPredEquivalence '<=>' LogPredImplication .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 161; {
/* line 838 "Parser.lalr" */

        yySynAttribute.LogPredEquivalence.Tree = mLogBinPred(mNoPred(), yyAttrStackPtr [1-1].LogPredEquivalence.Tree, mLogEquiv(), yyAttrStackPtr [3-1].LogPredImplication.Tree);

    ;

} break;
case 527:
case 408: /* LogPredEquivalence : LogPredImplication .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 161; {
/* line 843 "Parser.lalr" */
yySynAttribute.LogPredEquivalence.Tree = yyAttrStackPtr [1-1].LogPredImplication.Tree;

} break;
case 528:
case 407: /* LogPredImplication : LogPredOr '=>' LogPredImplication .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 162; {
/* line 845 "Parser.lalr" */
 
        yySynAttribute.LogPredImplication.Tree = mLogBinPred(mNoPred(), yyAttrStackPtr [1-1].LogPredOr.Tree, mLogImply(), yyAttrStackPtr [3-1].LogPredImplication.Tree);

    ;

} break;
case 529: /* LogPredImplication : LogPredOr .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 162; {
/* line 850 "Parser.lalr" */
yySynAttribute.LogPredImplication.Tree = yyAttrStackPtr [1-1].LogPredOr.Tree;

} break;
case 530: /* LogPredOr : LogPredOr 'exor' LogPredAnd .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 163; {
/* line 852 "Parser.lalr" */

        yySynAttribute.LogPredOr.Tree = mLogBinPred(mNoPred(), yyAttrStackPtr [1-1].LogPredOr.Tree, mLogExor(), yyAttrStackPtr [3-1].LogPredAnd.Tree);

    ;

} break;
case 531: /* LogPredOr : LogPredOr 'or' LogPredAnd .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 163; {
/* line 857 "Parser.lalr" */

        yySynAttribute.LogPredOr.Tree = mLogBinPred(mNoPred(), yyAttrStackPtr [1-1].LogPredOr.Tree, mLogOr(), yyAttrStackPtr [3-1].LogPredAnd.Tree);

    ;

} break;
case 532: /* LogPredOr : LogPredAnd .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 163; {
/* line 862 "Parser.lalr" */
yySynAttribute.LogPredOr.Tree = yyAttrStackPtr [1-1].LogPredAnd.Tree;

} break;
case 533: /* LogPredAnd : LogPredAnd 'and' LogPredSeq .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 164; {
/* line 864 "Parser.lalr" */

        yySynAttribute.LogPredAnd.Tree = mLogBinPred(mNoPred(), yyAttrStackPtr [1-1].LogPredAnd.Tree, mLogAnd(), yyAttrStackPtr [3-1].LogPredSeq.Tree);

    ;

} break;
case 534: /* LogPredAnd : LogPredSeq .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 164; {
/* line 869 "Parser.lalr" */
yySynAttribute.LogPredAnd.Tree = yyAttrStackPtr [1-1].LogPredSeq.Tree;

} break;
case 535:
case 400: /* LogPredSeq : LogPredSeq seqcomp BasicPredicate .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 165; {
/* line 871 "Parser.lalr" */

        yySynAttribute.LogPredSeq.Tree = mLogBinPred(mNoPred(), yyAttrStackPtr [1-1].LogPredSeq.Tree, mLogSeq(), yyAttrStackPtr [3-1].BasicPredicate.Tree);

    ;

} break;
case 536:
case 398: /* LogPredSeq : BasicPredicate .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 165; {
/* line 876 "Parser.lalr" */
yySynAttribute.LogPredSeq.Tree = yyAttrStackPtr [1-1].BasicPredicate.Tree;

} break;
case 537:
case 325: /* BasicPredicate : BoolValue .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 158; {
/* line 878 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mBoolValue (mNoPred(), yyAttrStackPtr [1-1].Scan.BoolValue.Ident);

    ;

} break;
case 538:
case 411: /* BasicPredicate : 'not' BasicPredicate .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 158; {
/* line 883 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mLogicalNot(mNoPred(), yyAttrStackPtr [2-1].BasicPredicate.Tree);

    ;

} break;
case 539:
case 410: /* BasicPredicate : 'pre' BasicPredicate .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 158; {
/* line 888 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mPreCondPred(mNoPred(), yyAttrStackPtr [2-1].BasicPredicate.Tree);

    ;

} break;
case 540:
case 409: /* BasicPredicate : 'let' BasicPredicate .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 158; {
/* line 893 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree  =  yyAttrStackPtr [2-1].BasicPredicate.Tree;

    ;

} break;
case 541:
case 327: /* BasicPredicate : 'changes_only' '{' Changes_Onlys '}' .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 158; {
/* line 898 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mChgOnly (mNoPred(), yyAttrStackPtr [3-1].Changes_Onlys.Tree);

    ;

} break;
case 542: /* BasicPredicate : 'assign' SchVarList ':=' ExpList .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 158; {
/* line 903 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mAssign(mNoPred(), ReverseTree(yyAttrStackPtr [2-1].SchVarList.Tree), ReverseTree(yyAttrStackPtr [4-1].ExpList.Tree));

    ;

} break;
case 543:
case 397: /* BasicPredicate : Expression InRelOp_Ex Expression .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 158; {
/* line 908 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mRelBinPred(mNoPred(), yyAttrStackPtr [1-1].Expression.Tree, yyAttrStackPtr [2-1].InRelOp_Ex.Ident, yyAttrStackPtr [3-1].Expression.Tree);

    ;

} break;
case 544:
case 337: /* BasicPredicate : ifc Predicate then Predicate else Predicate fi .*/
  yyStateStackPtr -=7; yyAttrStackPtr -=7; yyNonterminal = 158; {
/* line 913 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mIfPred (mNoPred(), yyAttrStackPtr [2-1].Predicate.Tree, yyAttrStackPtr [4-1].Predicate.Tree, yyAttrStackPtr [6-1].Predicate.Tree);
 
    ;

} break;
case 545:
case 338: /* BasicPredicate : ifc Predicate then Predicate fi .*/
  yyStateStackPtr -=5; yyAttrStackPtr -=5; yyNonterminal = 158; {
/* line 918 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mIfPred (mNoPred(), yyAttrStackPtr [2-1].Predicate.Tree, yyAttrStackPtr [4-1].Predicate.Tree, mNoPred());
 
    ;

} break;
case 546:
case 334: /* BasicPredicate : while Predicate do Predicate done .*/
  yyStateStackPtr -=5; yyAttrStackPtr -=5; yyNonterminal = 158; {
/* line 923 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mWhilePred (mNoPred(), yyAttrStackPtr [2-1].Predicate.Tree, yyAttrStackPtr [4-1].Predicate.Tree);
 
    ;

} break;
case 547:
case 419: /* BasicPredicate : PreRelOp Expression .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 158; {
/* line 928 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mRelPrePred(mNoPred(), yyAttrStackPtr [1-1].Scan.PreRelOp.Ident, yyAttrStackPtr [2-1].Expression.Tree);

    ;

} break;
case 548: /* BasicPredicate : CmpndSch .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 158; {
/* line 933 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mSchemaPred(mNoPred(), yyAttrStackPtr [1-1].CmpndSch.Tree);

    ;

} break;
case 549:
case 330: /* BasicPredicate : call '(' Name ',' '(' ')' ',' '(' ')' ')' .*/
  yyStateStackPtr -=10; yyAttrStackPtr -=10; yyNonterminal = 158; {
/* line 938 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mCallPred(mNoPred(), yyAttrStackPtr [3-1].Name.Tree, mNoInputBind(), mNoOutputBind());

    ;

} break;
case 550:
case 332: /* BasicPredicate : call '(' Name ',' '(' InputBindList ')' ',' '(' ')' ')' .*/
  yyStateStackPtr -=11; yyAttrStackPtr -=11; yyNonterminal = 158; {
/* line 943 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mCallPred(mNoPred(), yyAttrStackPtr [3-1].Name.Tree, ReverseTree(yyAttrStackPtr [6-1].InputBindList.Tree), mNoOutputBind());

    ;

} break;
case 551:
case 331: /* BasicPredicate : call '(' Name ',' '(' ')' ',' '(' OutputBindList ')' ')' .*/
  yyStateStackPtr -=11; yyAttrStackPtr -=11; yyNonterminal = 158; {
/* line 948 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mCallPred(mNoPred(), yyAttrStackPtr [3-1].Name.Tree, mNoInputBind(), ReverseTree(yyAttrStackPtr [9-1].OutputBindList.Tree));

    ;

} break;
case 552:
case 333: /* BasicPredicate : call '(' Name ',' '(' InputBindList ')' ',' '(' OutputBindList ')' ')' .*/
  yyStateStackPtr -=12; yyAttrStackPtr -=12; yyNonterminal = 158; {
/* line 953 "Parser.lalr" */

        yySynAttribute.BasicPredicate.Tree = mCallPred(mNoPred(), yyAttrStackPtr [3-1].Name.Tree, ReverseTree(yyAttrStackPtr [6-1].InputBindList.Tree), ReverseTree(yyAttrStackPtr [10-1].OutputBindList.Tree));

    ;

} break;
case 553:
case 275: /* InRelOp_Ex : InRelOp .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 168; {
/* line 958 "Parser.lalr" */

        yySynAttribute.InRelOp_Ex.Ident  =  yyAttrStackPtr [1-1].Scan.InRelOp.Ident;

    ;

} break;
case 554:
case 309: /* InRelOp_Ex : '<' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 168; {
/* line 964 "Parser.lalr" */

            yySynAttribute.InRelOp_Ex.Ident.Ident = MakeIdent ("<", 1);
            yySynAttribute.InRelOp_Ex.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 555:
case 310: /* InRelOp_Ex : '>' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 168; {
/* line 971 "Parser.lalr" */

            yySynAttribute.InRelOp_Ex.Ident.Ident = MakeIdent (">", 1);
            yySynAttribute.InRelOp_Ex.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 556:
case 311: /* InRelOp_Ex : 'ltc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 168; {
/* line 978 "Parser.lalr" */

            yySynAttribute.InRelOp_Ex.Ident.Ident = MakeIdent ("ltc", 3);
            yySynAttribute.InRelOp_Ex.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 557:
case 312: /* InRelOp_Ex : 'ltec' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 168; {
/* line 985 "Parser.lalr" */

            yySynAttribute.InRelOp_Ex.Ident.Ident = MakeIdent ("ltec", 4);
            yySynAttribute.InRelOp_Ex.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 558:
case 313: /* InRelOp_Ex : 'gtc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 168; {
/* line 992 "Parser.lalr" */

            yySynAttribute.InRelOp_Ex.Ident.Ident = MakeIdent ("gtc", 3);
            yySynAttribute.InRelOp_Ex.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 559:
case 314: /* InRelOp_Ex : 'gtec' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 168; {
/* line 999 "Parser.lalr" */

            yySynAttribute.InRelOp_Ex.Ident.Ident = MakeIdent ("gtec", 4);
            yySynAttribute.InRelOp_Ex.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 560:
case 315: /* InRelOp_Ex : 'eqc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 168; {
/* line 1006 "Parser.lalr" */

            yySynAttribute.InRelOp_Ex.Ident.Ident = MakeIdent ("eqc", 3);
            yySynAttribute.InRelOp_Ex.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 561:
case 316: /* InRelOp_Ex : 'neqc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 168; {
/* line 1013 "Parser.lalr" */

            yySynAttribute.InRelOp_Ex.Ident.Ident = MakeIdent ("neqc", 4);
            yySynAttribute.InRelOp_Ex.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 562: /* InputBindList : Id '=>' Expression .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 170; {
/* line 1019 "Parser.lalr" */

         yySynAttribute.InputBindList.Tree = mInputBind(mNoInputBind(), yyAttrStackPtr [1-1].Scan.Id.Ident, yyAttrStackPtr [3-1].Expression.Tree);

    ;

} break;
case 563:
case 395: /* InputBindList : Id '=>' Expression ',' InputBindList .*/
  yyStateStackPtr -=5; yyAttrStackPtr -=5; yyNonterminal = 170; {
/* line 1024 "Parser.lalr" */

         yySynAttribute.InputBindList.Tree = mInputBind(yyAttrStackPtr [5-1].InputBindList.Tree, yyAttrStackPtr [1-1].Scan.Id.Ident, yyAttrStackPtr [3-1].Expression.Tree);

    ;

} break;
case 564: /* OutputBindList : Id '=>' Name .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 171; {
/* line 1029 "Parser.lalr" */

         yySynAttribute.OutputBindList.Tree = mOutputBind(mNoOutputBind(), yyAttrStackPtr [1-1].Scan.Id.Ident, yyAttrStackPtr [3-1].Name.Tree);

    ;

} break;
case 565:
case 396: /* OutputBindList : Id '=>' Name ',' OutputBindList .*/
  yyStateStackPtr -=5; yyAttrStackPtr -=5; yyNonterminal = 171; {
/* line 1034 "Parser.lalr" */

         yySynAttribute.OutputBindList.Tree = mOutputBind(yyAttrStackPtr [5-1].OutputBindList.Tree, yyAttrStackPtr [1-1].Scan.Id.Ident, yyAttrStackPtr [3-1].Name.Tree);

    ;

} break;
case 566: /* Changes_Onlys : .*/
  yyStateStackPtr -=0; yyAttrStackPtr -=0; yyNonterminal = 166; {
/* line 1039 "Parser.lalr" */

        yySynAttribute.Changes_Onlys.Tree = mNoName();

    ;

} break;
case 567:
case 382: /* Changes_Onlys : SchVarList .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 166; {
/* line 1044 "Parser.lalr" */
yySynAttribute.Changes_Onlys.Tree = yyAttrStackPtr [1-1].SchVarList.Tree;

} break;
case 568: /* SchVarList : Name .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 167; {
/* line 1046 "Parser.lalr" */

        yySynAttribute.SchVarList.Tree = mName (mNoName(), yyAttrStackPtr [1-1].Name.Tree);

    ;

} break;
case 569:
case 381: /* SchVarList : Name ',' SchVarList .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 167; {
/* line 1051 "Parser.lalr" */
 
        yySynAttribute.SchVarList.Tree = mName (yyAttrStackPtr [3-1].SchVarList.Tree, yyAttrStackPtr [1-1].Name.Tree);

    ;

} break;
case 570: /* CmpndSch : CmpndSch 's_compose' CmpndSch1 .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 169; {
/* line 1057 "Parser.lalr" */

        yySynAttribute.CmpndSch.Tree = mSchemaCompos (yyAttrStackPtr [1-1].CmpndSch.Tree, MakeIdPos("s_compose", yyAttrStackPtr [2-1].Scan.Position), yyAttrStackPtr [3-1].CmpndSch1.Tree);

    ;

} break;
case 571: /* CmpndSch : CmpndSch1 .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 169; {
/* line 1061 "Parser.lalr" */
yySynAttribute.CmpndSch.Tree = yyAttrStackPtr [1-1].CmpndSch1.Tree;

} break;
case 572:
case 336: /* CmpndSch1 : CmpndSch1 BackSlash '(' SchVarList ')' .*/
  yyStateStackPtr -=5; yyAttrStackPtr -=5; yyNonterminal = 172; {
/* line 1063 "Parser.lalr" */

        yySynAttribute.CmpndSch1.Tree = mSchemaHiding (yyAttrStackPtr [1-1].CmpndSch1.Tree, yyAttrStackPtr [4-1].SchVarList.Tree);

    ;

} break;
case 573:
case 335: /* CmpndSch1 : CmpndSch1 '{' Renames '}' .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 172; {
/* line 1068 "Parser.lalr" */

        yySynAttribute.CmpndSch1.Tree = mSchemaSubst(yyAttrStackPtr [1-1].CmpndSch1.Tree, ReverseTree(yyAttrStackPtr [3-1].Renames.Tree));

    ;

} break;
case 574: /* CmpndSch1 : CmpndSch2 .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 172; {
/* line 1073 "Parser.lalr" */
yySynAttribute.CmpndSch1.Tree = yyAttrStackPtr [1-1].CmpndSch2.Tree;

} break;
case 575:
case 405: /* CmpndSch2 : CmpndSch2 '|^' BasicSch .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 173; {
/* line 1076 "Parser.lalr" */

        yySynAttribute.CmpndSch2.Tree = mSchemaProj (yyAttrStackPtr [1-1].CmpndSch2.Tree, MakeIdPos("|^", yyAttrStackPtr [2-1].Scan.Position), yyAttrStackPtr [3-1].BasicSch.Tree);

    ;

} break;
case 576:
case 406: /* CmpndSch2 : BasicSch .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 173; {
/* line 1080 "Parser.lalr" */
yySynAttribute.CmpndSch2.Tree = yyAttrStackPtr [1-1].BasicSch.Tree;

} break;
case 577:
case 326: /* BasicSch : '[' SchemaText ']' .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 174; {
/* line 1082 "Parser.lalr" */
yySynAttribute.BasicSch.Tree = yyAttrStackPtr [2-1].SchemaText.Tree;

} break;
case 578:
case 401: /* BasicSch : Expression .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 174; {
/* line 1084 "Parser.lalr" */

        yySynAttribute.BasicSch.Tree = mExpPred (yyAttrStackPtr [1-1].Expression.Tree);

    ;

} break;
case 579: /* SchemaText : BasicDeclList .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 160; {
/* line 1089 "Parser.lalr" */

            { tTree list=yyAttrStackPtr [1-1].BasicDeclList.Tree;
                for (; list->Kind != kNoDecl; list=list->Decl.Next) 
					if (list->Kind == kVarDecl)
						list->VarDecl.VarDeclKind = Is_local_id;
            }
            yySynAttribute.SchemaText.Tree=mSchemaText(ReverseTree(yyAttrStackPtr [1-1].BasicDeclList.Tree),mNoPred(),false);
            
        ;

    ;

} break;
case 580:
case 412: /* SchemaText : BasicDeclList '|' Predicate .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 160; {
/* line 1101 "Parser.lalr" */

            { tTree list=yyAttrStackPtr [1-1].BasicDeclList.Tree;
                for (; list->Kind != kNoDecl; list=list->Decl.Next)
			if (list->Kind == kVarDecl)
				list->VarDecl.VarDeclKind = Is_local_id;
            }
        yySynAttribute.SchemaText.Tree=mSchemaText(ReverseTree(yyAttrStackPtr [1-1].BasicDeclList.Tree),yyAttrStackPtr [3-1].Predicate.Tree,false);
        ;

    ;

} break;
case 581:
case 346: /* Expression : if Predicate then Expression else Expression fi .*/
  yyStateStackPtr -=7; yyAttrStackPtr -=7; yyNonterminal = 149; {
/* line 1112 "Parser.lalr" */

        yySynAttribute.Expression.Tree = mIfExp (mNoExp(), yyAttrStackPtr [2-1].Predicate.Tree, yyAttrStackPtr [4-1].Expression.Tree, yyAttrStackPtr [6-1].Expression.Tree);
 
    ;

} break;
case 582:
case 385: /* Expression : Expression0 .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 149; {
/* line 1117 "Parser.lalr" */

	yySynAttribute.Expression.Tree  =  yyAttrStackPtr [1-1].Expression0.Tree;

	;

} break;
case 583:
case 386: /* Expression0 : CartExp InGen Expression0 .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 175; {
/* line 1122 "Parser.lalr" */

 
	yySynAttribute.Expression0.Tree = mInfixOp (mNoExp(),yyAttrStackPtr [1-1].CartExp.Tree, yyAttrStackPtr [2-1].Scan.InGen.Ident, yyAttrStackPtr [3-1].Expression0.Tree);

    ;

} break;
case 584: /* Expression0 : CartExp .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 175; {
/* line 1128 "Parser.lalr" */


	yySynAttribute.Expression0.Tree  =  yyAttrStackPtr [1-1].CartExp.Tree;

    ;

} break;
case 585:
case 387: /* CartExp : Expression1 'cross' CartExp .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 176; {
/* line 1134 "Parser.lalr" */

	    if (Tree_IsType(yyAttrStackPtr [3-1].CartExp.Tree,kCartProd))
		yyAttrStackPtr [1-1].Expression1.Tree->Exp.Next = yyAttrStackPtr [3-1].CartExp.Tree->CartProd.ExpressionList;
	    else 
		yyAttrStackPtr [1-1].Expression1.Tree->Exp.Next = yyAttrStackPtr [3-1].CartExp.Tree;
	    yySynAttribute.CartExp.Tree = mCartProd(mNoExp(), yyAttrStackPtr [1-1].Expression1.Tree);
              
        ;

    ;

} break;
case 586: /* CartExp : Expression1 .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 176; {
/* line 1145 "Parser.lalr" */

	yySynAttribute.CartExp.Tree  =  yyAttrStackPtr [1-1].Expression1.Tree;
 
	;

} break;
case 587:
case 394: /* Expression1 : Expression1 Infix Expression2 .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 177; {
/* line 1150 "Parser.lalr" */
 
        yySynAttribute.Expression1.Tree = mInfixOp (mNoExp(), yyAttrStackPtr [1-1].Expression1.Tree, yyAttrStackPtr [2-1].Infix.Ident, yyAttrStackPtr [3-1].Expression2.Tree);

    ;

} break;
case 588:
case 388: /* Expression1 : Expression2 .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 177; {
/* line 1155 "Parser.lalr" */
yySynAttribute.Expression1.Tree = yyAttrStackPtr [1-1].Expression2.Tree;

} break;
case 589:
case 276: /* Infix : '|-->' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1158 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("|-->", 4);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 590:
case 277: /* Infix : '..' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1165 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("..", 2);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 591:
case 278: /* Infix : '+' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1172 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("+", 1);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 592:
case 279: /* Infix : '*' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1179 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("*", 1);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 593:
case 280: /* Infix : 'diff' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1186 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("diff", 4);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 594:
case 281: /* Infix : '^' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1193 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("^", 1);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 595:
case 282: /* Infix : 'div' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1200 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("div", 3);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 596:
case 283: /* Infix : 'mod' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1207 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("mod", 3);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 597:
case 284: /* Infix : 'func_override' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1214 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("func_override", 13);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 598:
case 285: /* Infix : 'b_compose' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1221 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("b_compose", 9);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 599:
case 286: /* Infix : 'f_compose' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1228 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("f_compose", 9);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 600:
case 287: /* Infix : 'dom_restrict' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1235 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("dom_restrict", 12);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 601:
case 288: /* Infix : 'ran_restrict' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1242 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("ran_restrict", 12);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 602:
case 289: /* Infix : 'dom_subtract' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1249 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("dom_subtract", 12);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 603:
case 290: /* Infix : 'ran_subtract' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1256 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("ran_subtract", 12);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 604:
case 291: /* Infix : 'union' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1263 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("union", 5);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 605:
case 292: /* Infix : 'bag_union' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1270 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("bag_union", 9);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 606:
case 293: /* Infix : 'inter' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1277 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("inter", 5);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 607:
case 294: /* Infix : 'sym_diff' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1284 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("sym_diff", 8);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 608:
case 295: /* Infix : 'filter' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1291 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("filter", 6);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 609:
case 296: /* Infix : '**' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1298 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("**", 2);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 610:
case 297: /* Infix : '-' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1305 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("-", 1);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 611:
case 298: /* Infix : 'subc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1312 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("subc", 4);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 612:
case 299: /* Infix : 'addc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1319 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("addc", 4);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 613:
case 300: /* Infix : 'multc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1326 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("multc", 5);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 614:
case 301: /* Infix : 'divc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1333 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("divc", 4);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 615:
case 302: /* Infix : 'modc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1340 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("modc", 4);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 616:
case 303: /* Infix : 'expc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1347 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("expc", 4);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 617:
case 304: /* Infix : 'uptoc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1354 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("uptoc", 5);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 618:
case 305: /* Infix : 'andc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1361 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("andc", 4);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 619:
case 306: /* Infix : 'orc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1368 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("orc", 3);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 620:
case 307: /* Infix : 'xorc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1375 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("xorc", 4);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 621:
case 308: /* Infix : 'notc' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 178; {
/* line 1382 "Parser.lalr" */

            yySynAttribute.Infix.Ident.Ident = MakeIdent ("notc", 4);
            yySynAttribute.Infix.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 622:
case 389: /* Expression2 : Prefix_Id Expression2 .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 179; {
/* line 1388 "Parser.lalr" */

        yySynAttribute.Expression2.Tree = mPrefixOp(mNoExp(), yyAttrStackPtr [1-1].Prefix_Id.Ident, yyAttrStackPtr [2-1].Expression2.Tree);

    ;

} break;
case 623: /* Expression2 : BasicExp .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 179; {
/* line 1393 "Parser.lalr" */
yySynAttribute.Expression2.Tree = yyAttrStackPtr [1-1].BasicExp.Tree;

} break;
case 624:
case 273: /* Prefix_Id : Prefix .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 180; {
/* line 1395 "Parser.lalr" */

        yySynAttribute.Prefix_Id.Ident  =  yyAttrStackPtr [1-1].Scan.Prefix.Ident;

    ;

} break;
case 625:
case 318: /* Prefix_Id : '-' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 180; {
/* line 1401 "Parser.lalr" */

            yySynAttribute.Prefix_Id.Ident.Ident = MakeIdent ("-", 1);
            yySynAttribute.Prefix_Id.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 626:
case 319: /* Prefix_Id : '#' .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 180; {
/* line 1408 "Parser.lalr" */

            yySynAttribute.Prefix_Id.Ident.Ident = MakeIdent ("#", 1);
            yySynAttribute.Prefix_Id.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

    ;

} break;
case 627: /* BasicExp : Name .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 181; {
/* line 1414 "Parser.lalr" */

        yySynAttribute.BasicExp.Tree = mVariable (mNoExp(), yyAttrStackPtr [1-1].Name.Tree);

    ;

} break;
case 628: /* BasicExp : Name '[' ExpList ']' .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 181; {
/* line 1419 "Parser.lalr" */

        yySynAttribute.BasicExp.Tree = mExp_SchemaRef (mNoExp(), yyAttrStackPtr [1-1].Name.Tree, ReverseTree(yyAttrStackPtr [3-1].ExpList.Tree));

    ;

} break;
case 629:
case 271: /* BasicExp : String .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 181; {
/* line 1424 "Parser.lalr" */

        yySynAttribute.BasicExp.Tree = mString (mNoExp(), yyAttrStackPtr [1-1].Scan.String.Ident);

    ;

} break;
case 630:
case 272: /* BasicExp : Char .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 181; {
/* line 1429 "Parser.lalr" */
 
        yySynAttribute.BasicExp.Tree = mChar (mNoExp(), yyAttrStackPtr [1-1].Scan.Char.Ident);

    ;

} break;
case 631:
case 270: /* BasicExp : Number .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 181; {
/* line 1434 "Parser.lalr" */

        yySynAttribute.BasicExp.Tree = mLiteral (mNoExp(), yyAttrStackPtr [1-1].Scan.Number.Ident);

    ;

} break;
case 632:
case 328: /* BasicExp : Name '[' ExpList ']' '.' Id .*/
  yyStateStackPtr -=6; yyAttrStackPtr -=6; yyNonterminal = 181; {
/* line 1439 "Parser.lalr" */
 

        yySynAttribute.BasicExp.Tree = mVarSelection (mNoExp(),
            mExp_SchemaRef (mNoExp(), yyAttrStackPtr [1-1].Name.Tree, ReverseTree (yyAttrStackPtr [3-1].ExpList.Tree)), yyAttrStackPtr [6-1].Scan.Id.Ident);
 
    ;

} break;
case 633:
case 329: /* BasicExp : BasicExp '(' ExpList ')' .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 181; {
/* line 1446 "Parser.lalr" */

        yySynAttribute.BasicExp.Tree = mFncApplication(mNoExp(), yyAttrStackPtr [1-1].BasicExp.Tree, ReverseTree (yyAttrStackPtr [3-1].ExpList.Tree));

    ;

} break;
case 634:
case 352: /* BasicExp : '(' Expression ',' ExpList ')' .*/
  yyStateStackPtr -=5; yyAttrStackPtr -=5; yyNonterminal = 181; {
/* line 1451 "Parser.lalr" */

            yyAttrStackPtr [2-1].Expression.Tree->Exp.Next = ReverseTree(yyAttrStackPtr [4-1].ExpList.Tree);
            yySynAttribute.BasicExp.Tree = mTuple (mNoExp(), yyAttrStackPtr [2-1].Expression.Tree);
        ;

    ;

} break;
case 635:
case 391: /* BasicExp : SetElaboration .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 181; {
/* line 1458 "Parser.lalr" */
yySynAttribute.BasicExp.Tree = yyAttrStackPtr [1-1].SetElaboration.Tree;

} break;
case 636:
case 342: /* BasicExp : 'upd' '(' Name ',' Expression ',' Expression ')' .*/
  yyStateStackPtr -=8; yyAttrStackPtr -=8; yyNonterminal = 181; {
/* line 1460 "Parser.lalr" */

         yySynAttribute.BasicExp.Tree = mArrayUpd(mNoExp(), yyAttrStackPtr [3-1].Name.Tree, yyAttrStackPtr [5-1].Expression.Tree, yyAttrStackPtr [7-1].Expression.Tree);

    ;

} break;
case 637:
case 353: /* BasicExp : '(' Named_array_agg ')' .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 181; {
/* line 1465 "Parser.lalr" */
    
        yySynAttribute.BasicExp.Tree = mNamedArrayAgg(mNoExp(), ReverseTree(yyAttrStackPtr [2-1].Named_array_agg.Tree));

    ;

} break;
case 638:
case 341: /* BasicExp : SCBRACE SetComp '}' .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 181; {
/* line 1470 "Parser.lalr" */
yySynAttribute.BasicExp.Tree = yyAttrStackPtr [2-1].SetComp.Tree;

} break;
case 639:
case 392: /* BasicExp : Sequence .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 181; {
/* line 1472 "Parser.lalr" */
yySynAttribute.BasicExp.Tree = yyAttrStackPtr [1-1].Sequence.Tree;

} break;
case 640:
case 393: /* BasicExp : Bag .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 181; {
/* line 1474 "Parser.lalr" */
yySynAttribute.BasicExp.Tree = yyAttrStackPtr [1-1].Bag.Tree;

} break;
case 641:
case 350: /* BasicExp : '(' Predicate ')' .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 181; {
/* line 1476 "Parser.lalr" */

        yySynAttribute.BasicExp.Tree = mPredExp (mNoExp(), yyAttrStackPtr [2-1].Predicate.Tree);

    ;

} break;
case 642:
case 347: /* BasicExp : '(' 'lambda' SchemaText '@' Expression ')' .*/
  yyStateStackPtr -=6; yyAttrStackPtr -=6; yyNonterminal = 181; {
/* line 1481 "Parser.lalr" */

            { 
               yyAttrStackPtr [3-1].SchemaText.Tree->SchemaText.Is_local_dec = true;
            }
            yySynAttribute.BasicExp.Tree = mLambda (mNoExp(), yyAttrStackPtr [3-1].SchemaText.Tree, yyAttrStackPtr [5-1].Expression.Tree);
        ;

    ;

} break;
case 643:
case 349: /* BasicExp : '(' 'mu' SchemaText ')' .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 181; {
/* line 1490 "Parser.lalr" */

            { 
               yyAttrStackPtr [3-1].SchemaText.Tree->SchemaText.Is_local_dec = true;
            }
            yySynAttribute.BasicExp.Tree = mMu (mNoExp(), yyAttrStackPtr [3-1].SchemaText.Tree, mNoExp());
          ;

        ;

} break;
case 644:
case 348: /* BasicExp : '(' 'mu' SchemaText '@' Expression ')' .*/
  yyStateStackPtr -=6; yyAttrStackPtr -=6; yyNonterminal = 181; {
/* line 1499 "Parser.lalr" */

            { 
              yyAttrStackPtr [3-1].SchemaText.Tree->SchemaText.Is_local_dec = true;
            }
            yySynAttribute.BasicExp.Tree = mMu (mNoExp(), yyAttrStackPtr [3-1].SchemaText.Tree, yyAttrStackPtr [5-1].Expression.Tree);
        ;

    ;

} break;
case 645:
case 339: /* BasicExp : 'the' SchemaText '@' '(' AndPredList ')' .*/
  yyStateStackPtr -=6; yyAttrStackPtr -=6; yyNonterminal = 181; {
/* line 1508 "Parser.lalr" */

            { 
             yyAttrStackPtr [2-1].SchemaText.Tree->SchemaText.Is_local_dec = true;
            }
        yySynAttribute.BasicExp.Tree = mRecDisp (mNoExp(), yyAttrStackPtr [2-1].SchemaText.Tree, ReverseTree(yyAttrStackPtr [5-1].AndPredList.Tree));
        ;

    ;

} break;
case 646:
case 383: /* BasicExp : theta Name .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 181; {
/* line 1517 "Parser.lalr" */


        yySynAttribute.BasicExp.Tree = mTheta(mNoExp(), mVariable (mNoExp(), yyAttrStackPtr [2-1].Name.Tree));

    ;

} break;
case 647: /* SetComp : SchemaText .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 184; {
/* line 1523 "Parser.lalr" */

            { if ((yyAttrStackPtr [1-1].SchemaText.Tree->SchemaText.DeclList->Kind == kSchemaIncl)&&
                  (yyAttrStackPtr [1-1].SchemaText.Tree->SchemaText.DeclList->Decl.Next->Kind == kNoDecl) &&
                  (yyAttrStackPtr [1-1].SchemaText.Tree->SchemaText.PredList->Kind == kNoPred)) {
                  if (yyAttrStackPtr [1-1].SchemaText.Tree->SchemaText.DeclList->SchemaIncl.ExpressionList->Kind == kNoExp)
                  yySynAttribute.SetComp.Tree = mSetElab(mNoExp(), mVariable(mNoExp(), yyAttrStackPtr [1-1].SchemaText.Tree->SchemaText.DeclList->SchemaIncl.IdList));
                  else
                  yySynAttribute.SetComp.Tree = mSetElab(mNoExp(), mExp_SchemaRef(mNoExp(), yyAttrStackPtr [1-1].SchemaText.Tree->SchemaText.DeclList->SchemaIncl.IdList, yyAttrStackPtr [1-1].SchemaText.Tree->SchemaText.DeclList->SchemaIncl.ExpressionList));
              } else {
               yyAttrStackPtr [1-1].SchemaText.Tree->SchemaText.Is_local_dec = true;
               yySynAttribute.SetComp.Tree = mSetComp (mNoExp(), yyAttrStackPtr [1-1].SchemaText.Tree, mNoExp());
              }
           }  
        ;

    ;

} break;
case 648:
case 417: /* SetComp : SchemaText '@' Expression .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 184; {
/* line 1540 "Parser.lalr" */

            { 
               yyAttrStackPtr [1-1].SchemaText.Tree->SchemaText.Is_local_dec = true;
            }
            yySynAttribute.SetComp.Tree = mSetComp (mNoExp(), yyAttrStackPtr [1-1].SchemaText.Tree, yyAttrStackPtr [3-1].Expression.Tree);
        ;

    ;

} break;
case 649: /* SetComp : dec SchemaText .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 184; {
/* line 1549 "Parser.lalr" */

            { 
               yyAttrStackPtr [2-1].SchemaText.Tree->SchemaText.Is_local_dec = true;
            }
            yySynAttribute.SetComp.Tree = mSetComp (mNoExp(), yyAttrStackPtr [2-1].SchemaText.Tree, mNoExp());
        ;

    ;

} break;
case 650:
case 416: /* SetComp : dec SchemaText '@' Expression .*/
  yyStateStackPtr -=4; yyAttrStackPtr -=4; yyNonterminal = 184; {
/* line 1558 "Parser.lalr" */

            { 
               yyAttrStackPtr [2-1].SchemaText.Tree->SchemaText.Is_local_dec = true;
            }
            yySynAttribute.SetComp.Tree = mSetComp (mNoExp(), yyAttrStackPtr [2-1].SchemaText.Tree, yyAttrStackPtr [4-1].Expression.Tree);
        ;

    ;

} break;
case 651:
case 323: /* SetElaboration : '{' '}' .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 182; {
/* line 1567 "Parser.lalr" */

        yySynAttribute.SetElaboration.Tree = mSetElab (mNoExp(), mNoExp());
 
    ;

} break;
case 652:
case 343: /* SetElaboration : '{' ExpList '}' .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 182; {
/* line 1572 "Parser.lalr" */
 
        yySynAttribute.SetElaboration.Tree = mSetElab (mNoExp(), ReverseTree(yyAttrStackPtr [2-1].ExpList.Tree));

    ;

} break;
case 653: /* Named_array_agg : Expression Arrow Expression .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 183; {
/* line 1577 "Parser.lalr" */

         yySynAttribute.Named_array_agg.Tree = mInfixOp(mNoExp(), yyAttrStackPtr [1-1].Expression.Tree, yyAttrStackPtr [2-1].Arrow.Ident, yyAttrStackPtr [3-1].Expression.Tree);

    ;

} break;
case 654:
case 420: /* Named_array_agg : Expression Arrow Expression ',' Named_array_agg .*/
  yyStateStackPtr -=5; yyAttrStackPtr -=5; yyNonterminal = 183; {
/* line 1582 "Parser.lalr" */

         yySynAttribute.Named_array_agg.Tree = mInfixOp(yyAttrStackPtr [5-1].Named_array_agg.Tree, yyAttrStackPtr [1-1].Expression.Tree, yyAttrStackPtr [2-1].Arrow.Ident, yyAttrStackPtr [3-1].Expression.Tree);

    ;

} break;
case 655:
case 351: /* Arrow : is .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 187; {
/* line 1588 "Parser.lalr" */

            yySynAttribute.Arrow.Ident.Ident = MakeIdent ("|-->", 4);
            yySynAttribute.Arrow.Ident.Pos = yyAttrStackPtr [1-1].Scan.Position;
        ;

;

} break;
case 656:
case 322: /* Sequence : '<' '>' .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 185; {
/* line 1594 "Parser.lalr" */

        yySynAttribute.Sequence.Tree = mSequence (mNoExp(), mNoExp());

    ;

} break;
case 657:
case 344: /* Sequence : '<' ExpList '>' .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 185; {
/* line 1599 "Parser.lalr" */

        yySynAttribute.Sequence.Tree = mSequence (mNoExp(), ReverseTree(yyAttrStackPtr [2-1].ExpList.Tree));

    ;

} break;
case 658:
case 324: /* Bag : '|[' ']|' .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 186; {
/* line 1604 "Parser.lalr" */

        yySynAttribute.Bag.Tree = mBag (mNoExp(), mNoExp());

    ;

} break;
case 659:
case 340: /* Bag : '|[' ExpList ']|' .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 186; {
/* line 1609 "Parser.lalr" */

        yySynAttribute.Bag.Tree = mBag (mNoExp(), ReverseTree(yyAttrStackPtr [2-1].ExpList.Tree));

    ;

} break;
case 660: /* Name : Id .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 133; {
/* line 1614 "Parser.lalr" */

        yySynAttribute.Name.Tree = mId(mNoId(), yyAttrStackPtr [1-1].Scan.Id.Ident, ID);

    ;

} break;
case 661:
case 372: /* Name : Id '.' Name .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 133; {
/* line 1619 "Parser.lalr" */

        yySynAttribute.Name.Tree = mId(yyAttrStackPtr [3-1].Name.Tree, yyAttrStackPtr [1-1].Scan.Id.Ident, ID);

    ;

} break;
case 662:
case 317: /* Opname : '_' InfixOp '_' .*/
  yyStateStackPtr -=3; yyAttrStackPtr -=3; yyNonterminal = 153; {
/* line 1624 "Parser.lalr" */

        yySynAttribute.Opname.Ident  =  yyAttrStackPtr [2-1].InfixOp.Ident;

    ;

} break;
case 663:
case 321: /* Opname : PrefixOp '_' .*/
  yyStateStackPtr -=2; yyAttrStackPtr -=2; yyNonterminal = 153; {
/* line 1629 "Parser.lalr" */

        yySynAttribute.Opname.Ident  =  yyAttrStackPtr [1-1].PrefixOp.Ident;

    ;

} break;
case 664:
case 374: /* InfixOp : Infix .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 188; {

} break;
case 665:
case 373: /* InfixOp : InRelOp_Ex .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 188; {

} break;
case 666:
case 378: /* PrefixOp : Prefix_Id .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 189; {
/* line 1636 "Parser.lalr" */

        yySynAttribute.PrefixOp.Ident  =  yyAttrStackPtr [1-1].Prefix_Id.Ident;

    ;

} break;
case 667:
case 274: /* PrefixOp : PreRelOp .*/
  yyStateStackPtr -=1; yyAttrStackPtr -=1; yyNonterminal = 189; {
/* line 1641 "Parser.lalr" */

        yySynAttribute.PrefixOp.Ident  =  yyAttrStackPtr [1-1].Scan.PreRelOp.Ident;

    ;

} break;
}

	       /* SPEC State = Next (Top (), Nonterminal); nonterminal transition */
	       yyState = * (yyNBasePtr [* yyStateStackPtr ++] + yyNonterminal);
	       * yyAttrStackPtr ++ = yySynAttribute;
	       if (yyState < yyFirstFinalState) goto ParseLoop; /* read nonterminal reduce ? */
	    } 

	 } else {					/* read */
	    yyStateStackPtr ++;
	    yyGetAttribute (yyAttrStackPtr ++, Attribute);
	    yyTerminal = GetToken ();
	    yyIsRepairing = false;
	 }
      }
   }

static void yyErrorRecovery
# if defined __STDC__ | defined __cplusplus
   (yySymbolRange * yyTerminal, yyStateRange * yyStateStack, unsigned long yyStackSize, short yyStackPtr)
# else
   (yyTerminal, yyStateStack, yyStackSize, yyStackPtr)
   yySymbolRange *	yyTerminal	;
   yyStateRange *	yyStateStack	;
   unsigned long	yyStackSize	;
   short		yyStackPtr	;
# endif
   {
      bool	yyTokensSkipped	;
      tSet	yyContinueSet	;
      tSet	yyRestartSet	;
      int	yyLength = 0	;
      char	yyContinueString [256];

   /* 1. report an error */
      ErrorMessage (xxSyntaxError, xxError, Attribute.Position);

   /* 2. report the set of expected terminal symbols */
      MakeSet (& yyContinueSet, (short) yyLastTerminal);
      yyComputeContinuation (yyStateStack, yyStackSize, yyStackPtr, & yyContinueSet);
      yyContinueString [0] = '\0';
      while (! IsEmpty (& yyContinueSet)) {
	 char * yyTokenString = Parser_TokenName [Extract (& yyContinueSet)];
	 if ((yyLength += strlen (yyTokenString) + 1) >= 256) break;
	 (void) strcat (yyContinueString, yyTokenString);
	 (void) strcat (yyContinueString, " ");
      }
      ErrorMessageI (xxExpectedTokens, xxInformation, Attribute.Position,
	 xxString, yyContinueString);
      ReleaseSet (& yyContinueSet);

   /* 3. compute the set of terminal symbols for restart of the parse */
      MakeSet (& yyRestartSet, (short) yyLastTerminal);
      yyComputeRestartPoints (yyStateStack, yyStackSize, yyStackPtr, & yyRestartSet);

   /* 4. skip terminal symbols until a restart point is reached */
      yyTokensSkipped = false;
      while (! IsElement (* yyTerminal, & yyRestartSet)) {
	 * yyTerminal = GetToken ();
	 yyTokensSkipped = true;
      }
      ReleaseSet (& yyRestartSet);

   /* 5. report the restart point */
      if (yyTokensSkipped) {
	 ErrorMessage (xxRestartPoint, xxInformation, Attribute.Position);
      }
   }

/*
   compute the set of terminal symbols that can be accepted (read)
   in a given stack configuration (eventually after reduce actions)
*/

static void yyComputeContinuation
# if defined __STDC__ | defined __cplusplus
   (yyStateRange * yyStack, unsigned long yyStackSize, short yyStackPtr, tSet * yyContinueSet)
# else
   (yyStack, yyStackSize, yyStackPtr, yyContinueSet)
   yyStateRange *	yyStack		;
   unsigned long	yyStackSize	;
   short		yyStackPtr	;
   tSet *		yyContinueSet	;
# endif
   {
      register yySymbolRange	yyTerminal;
      register yyStateRange	yyState = yyStack [yyStackPtr];

      AssignEmpty (yyContinueSet);
      for (yyTerminal = yyFirstTerminal; yyTerminal <= yyLastTerminal; yyTerminal ++) {
	 if (yyNext (yyState, yyTerminal) != yyNoState &&
	    yyIsContinuation (yyTerminal, yyStack, yyStackSize, yyStackPtr)) {
	    Include (yyContinueSet, (short) yyTerminal);
	 }
      }
   }

/*
   check whether a given terminal symbol can be accepted (read)
   in a certain stack configuration (eventually after reduce actions)
*/

static bool yyIsContinuation
# if defined __STDC__ | defined __cplusplus
   (yySymbolRange yyTerminal, yyStateRange * yyStateStack, unsigned long yyStackSize, short yyStackPtr)
# else
   (yyTerminal, yyStateStack, yyStackSize, yyStackPtr)
   yySymbolRange	yyTerminal	;
   yyStateRange *	yyStateStack	;
   unsigned long	yyStackSize	;
   short		yyStackPtr	;
# endif
   {
      register yyStateRange	yState		;
      register yySymbolRange	yyNonterminal	;
	       yyStateRange *	yyStack		;
   
      MakeArray ((char * *) & yyStack, & yyStackSize, sizeof (yyStateRange));	/* pass Stack by value */
# ifdef BCOPY
      bcopy ((char *) yyStateStack, (char *) yyStack, (int) sizeof (yyStateRange) * (yyStackPtr + 1));
# else
      (void) memcpy ((char *) yyStack, (char *) yyStateStack, (int) sizeof (yyStateRange) * (yyStackPtr + 1));
# endif

      yState = yyStack [yyStackPtr];
      for (;;) {
	 yyStack [yyStackPtr] = yState;
	 yState = yyNext (yState, yyTerminal);
	 if (yState == yyNoState) {
	    ReleaseArray ((char * *) & yyStack, & yyStackSize, sizeof (yyStateRange));
	    return false;
	 }
	 if (yState <= yyLastReadTermState) {		/* read or read terminal reduce ? */
	    ReleaseArray ((char * *) & yyStack, & yyStackSize, sizeof (yyStateRange));
	    return true;
	 }

	 for (;;) {					/* reduce */
	    if (yState == yyStopState) {
	       ReleaseArray ((char * *) & yyStack, & yyStackSize, sizeof (yyStateRange));
	       return true;
	    } else { 
	       yyStackPtr -= yyLength [yState - yyFirstReduceState];
	       yyNonterminal = yyLeftHandSide [yState - yyFirstReduceState];
	    }

	    yState = yyNext (yyStack [yyStackPtr], yyNonterminal);
	    if (yyStackPtr >= yyStackSize) {
	       ExtendArray ((char * *) & yyStack, & yyStackSize, sizeof (yyStateRange));
	    }
	    yyStackPtr ++;
	    if (yState < yyFirstFinalState) break;	/* read nonterminal ? */
	    yState = yyFinalToProd [yState - yyFirstReadTermState];	/* read nonterminal reduce */
	 }
      }
   }

/*
   compute a set of terminal symbols that can be used to restart
   parsing in a given stack configuration. we simulate parsing until
   end of file using a suffix program synthesized by the function
   Continuation. All symbols acceptable in the states reached during
   the simulation can be used to restart parsing.
*/

static void yyComputeRestartPoints
# if defined __STDC__ | defined __cplusplus
   (yyStateRange * yyStateStack, unsigned long yyStackSize, short yyStackPtr, tSet * yyRestartSet)
# else
   (yyStateStack, yyStackSize, yyStackPtr, yyRestartSet)
   yyStateRange *	yyStateStack	;
   unsigned long	yyStackSize	;
   short		yyStackPtr	;
   tSet *		yyRestartSet	;
# endif
   {
      register yyStateRange	yState		;
      register yySymbolRange	yyNonterminal	;
	       yyStateRange *	yyStack		;
	       tSet		yyContinueSet	;
   
      MakeArray ((char * *) & yyStack, & yyStackSize, sizeof (yyStateRange)); /* pass Stack by value */
# ifdef BCOPY
      bcopy ((char *) yyStateStack, (char *) yyStack, (int) sizeof (yyStateRange) * (yyStackPtr + 1));
# else
      (void) memcpy ((char *) yyStack, (char *) yyStateStack, (int) sizeof (yyStateRange) * (yyStackPtr + 1));
# endif

      MakeSet (& yyContinueSet, (short) yyLastTerminal);
      AssignEmpty (yyRestartSet);
      yState = yyStack [yyStackPtr];

      for (;;) {
	 if (yyStackPtr >= yyStackSize) {
	    ExtendArray ((char * *) & yyStack, & yyStackSize, sizeof (yyStateRange));
	 }
	 yyStack [yyStackPtr] = yState;
	 yyComputeContinuation (yyStack, yyStackSize, yyStackPtr, & yyContinueSet);
	 Union (yyRestartSet, & yyContinueSet);
	 yState = yyNext (yState, yyContinuation [yState]);

	 if (yState >= yyFirstFinalState) {		/* final state ? */
	    if (yState <= yyLastReadTermState) {	/* read terminal reduce ? */
	       yyStackPtr ++;
	       yState = yyFinalToProd [yState - yyFirstReadTermState];
	    }

	    for (;;) {					/* reduce */
	       if (yState == yyStopState) {
		  ReleaseSet (& yyContinueSet);
		  ReleaseArray ((char * *) & yyStack, & yyStackSize, sizeof (yyStateRange));
		  return;
	       } else { 
		  yyStackPtr -= yyLength [yState - yyFirstReduceState];
		  yyNonterminal = yyLeftHandSide [yState - yyFirstReduceState];
	       }

	       yState = yyNext (yyStack [yyStackPtr], yyNonterminal);
	       yyStackPtr ++;
	       if (yState < yyFirstFinalState) break;	/* read nonterminal ? */
	       yState = yyFinalToProd [yState - yyFirstReadTermState]; /* read nonterminal reduce */
	    }
	 } else {					/* read */
	    yyStackPtr ++;
	 }
      }
   }

/* access the parse table:   Next : State x Symbol -> Action */

static yyStateRange yyNext
# if defined __STDC__ | defined __cplusplus
   (yyStateRange yyState, yySymbolRange yySymbol)
# else
   (yyState, yySymbol) yyStateRange yyState; yySymbolRange yySymbol;
# endif
   {
      register yyTCombType * yyTCombPtr;

      if (yySymbol <= yyLastTerminal) {
	 for (;;) {
	    yyTCombPtr = yyTBasePtr [yyState] + yySymbol;
	    if (yyTCombPtr->Check != yyState) {
	       if ((yyState = yyDefault [yyState]) == yyNoState) return yyNoState;
	    } else {
	       return yyTCombPtr->Next;
	    }
	 }
      } else {
	return * (yyNBasePtr [yyState] + yySymbol);
      }
   }

static void BeginParser ()
   {
/* line 185 "Parser.lalr" */


   }

void CloseParser ()
   {
/* line 188 "Parser.lalr" */


   }
