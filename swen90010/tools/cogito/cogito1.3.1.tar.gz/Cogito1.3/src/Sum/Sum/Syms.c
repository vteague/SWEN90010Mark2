# include "Syms.h"
# define yyALLOC(ptr, size)	if ((ptr = (tSyms) Syms_PoolFreePtr) >= (tSyms) Syms_PoolMaxPtr) \
  ptr = Syms_Alloc (); \
  Syms_PoolFreePtr += size;
# define yyFREE(ptr, size)	
# ifdef __cplusplus
extern "C" {
# include <stdio.h>
# include "yySyms.w"
# include "System.h"
# include "General.h"
# include "Memory.h"
# include "DynArray.h"
# include "StringMem.h"
# include "Idents.h"
# include "Sets.h"
# include "Positions.h"
}
# else
# include <stdio.h>
# include "yySyms.w"
# include "System.h"
# include "General.h"
# include "Memory.h"
# include "DynArray.h"
# include "StringMem.h"
# include "Idents.h"
# include "Sets.h"
# include "Positions.h"
# endif

/* line 53 "Objects.cg" */


/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/

#include <string.h>
#include <stdlib.h> 
#include "Idents.h"
#include "Tree.h"
#include "Type.h"
#include "Positions.h"
#include "ratc.h"

/* WIN32 defines for Windows version
   We must choose a size for object and type structure
   because the WIN32 compiler makes bad optimisations for malloc
   inside case statements.
   We also use a different read in WIN32 to check if reads and writes
   work.
*/

#ifdef WIN32
#define SizeofSP sizeof(yObj_Inn)
#define SizeofTy sizeof(yTp_Infix)
#endif


int mywrite(fd, ptr, n)
  int fd;
  char * ptr;
  int n;
{ 
#ifdef WIN32
    if (_rtl_write(fd, ptr, n) != n)
#else
    if (write (fd, ptr, n) != n)
#endif
       InterErr(Ierror6);
}

int myread(fd, ptr, n)
  int fd;
  char * ptr;
  int n;
{ 
#ifdef WIN32
    if (_rtl_read(fd, ptr, n) != n)
#else
    if (read (fd, ptr, n) != n)
#endif
       InterErr(Ierror7);
}

#define indent 4
int no_indent=0;

#define nNoObj mNoObject()

int Argc = 0;
char *Argv[10];


/* list for keeping track of types allocated in a module */
/* - init by readmodule and write module */

struct ty_allo_str {
    tType ty_addr;
    struct ty_allo_str *next;
} *allo_head=NULL, *allo_tail=NULL; 

int TyNoCounter=0;


/* only to include "state" which has been declared in the current module, then,
 * schema "init" and operational schemas will automatically
 * have inclusions of "state" and "state'". 
 */ 
tObjects StateIncl (DeclsIn, Option, HasState)
    tObjects DeclsIn;
    int Option;
    bool *HasState;
    /* DeclsIn points to the last param. or the Schema itself.
       Option: 
       1) state only
       2) state-prime only
       3) both
     */
{
    tObjects sym_ptr = DeclsIn; 
    tObjects decls_in = NoSym;

    if (sym_ptr->Kind != kObj_Inn) /* has params */
        for (; sym_ptr && sym_ptr->Kind != kNoObject; sym_ptr = sym_ptr->Object.Pre)
            if (sym_ptr->Object.Pre->Kind == kObj_Inn &&
                sym_ptr->Object.Pre->Obj_Inn.Inner == sym_ptr) {
                sym_ptr = sym_ptr->Object.Pre;
                break;
            }
    for (; sym_ptr && sym_ptr->Kind != kNoObject; sym_ptr = sym_ptr->Object.Pre) {
        if (sym_ptr->Object.Ident == Ident_state) {
	    *HasState = true;
            if (sym_ptr->Kind == kObj_Inn && sym_ptr->Obj_Inn.Inner &&
                sym_ptr->Obj_Inn.Inner->Kind != kObj_PTyId) {
                decls_in = DeclsIn;
                if (Option == 1 || Option == 3)
                    decls_in = SchIncl (decls_in, sym_ptr->Object.Type, NoPosition, 0, NoIdent);
                if (Option == 2 || Option == 3)
                    decls_in = SchInclD (decls_in, sym_ptr->Object.Type, "'", NoPosition, 0, NoIdent);
                return decls_in;
            }
            else if (sym_ptr->Object.Type && sym_ptr->Object.Type->Kind == kTp_Schema) {
                decls_in = DeclsIn;
                if (Option == 1 || Option == 3)
                    decls_in = SchIncl (decls_in, sym_ptr->Object.Type, NoPosition, 0, NoIdent);
                if (Option == 2 || Option == 3)
                    decls_in = SchInclD (decls_in, sym_ptr->Object.Type, "'", NoPosition, 0, NoIdent);
                return decls_in;
            }
            else return DeclsIn;
        }
        /* looking is restricted in the current scope */
        if (sym_ptr->Object.Pre->Kind == kObj_Inn &&
            sym_ptr->Object.Pre->Obj_Inn.ObjKind == Obj_module)
            return DeclsIn;
    }
    return DeclsIn;
}

/* debugging --- wj 26/8/98 */
/* to print out the type of the object BTvalues */
/*void PrintBTvalues(Obj)
   tObjects Obj;
{
  tObjects obj=Obj;
  char str[256];

  while (obj&&obj->Kind!=kNoObject){
    GetString(obj->Object.Ident,str);
    if (strcmp("BTvalues",str)==0){
	  WriteType(stdout,obj->Object.Type);
	  printf("\n--------------\n");}
    if (obj->Kind==kObj_Inn) PrintBTvalues(obj->Obj_Inn.Inner);
    obj = obj->Object.Next;}
}*/



/* Options: 
   0: no type information
   1: with type
 */
void ObjPrint (Obj, Option)
    tObjects Obj;
    bool Option;
{
    char *s;
    tTree tr;
    tObjects cObj = Obj;
    int i;

    s = (char *) my_malloc (IDENT_LENGTH);
    while (cObj && cObj->Kind != kNoObject) {
        s[0] = '\0';
        switch (cObj->Kind) {
            case kObj_Id:
                GetString (cObj->Obj_Id.Ident, s);
                for (i=no_indent; i>0; i--)
                    printf ("    ");
                printf ("%s", s);
                if (cObj->Obj_Id.QuId != NoIdent) {
                    s[0] = '\0';
                    GetString (cObj->Obj_Id.QuId, s);
                    printf ("(%s)", s);
                }
                break;
            case kObj_TyId: 
                GetString (cObj->Obj_TyId.Ident, s);
                for (i=no_indent; i>0; i--)
                    printf ("    ");
                printf ("%s", s);
                break;
            case kObj_PTyId: 
                GetString (cObj->Obj_PTyId.Ident, s);
                for (i=no_indent; i>0; i--)
                    printf ("    ");
                printf ("%s", s);
                break;
            case kObj_PId: 
                GetString (cObj->Obj_PId.Ident, s);
                for (i=no_indent; i>0; i--)
                    printf ("    ");
                printf ("%s", s);
                break;
            case kObj_Inn: 
                GetString (cObj->Obj_Inn.Ident, s);
                for (i=no_indent; i>0; i--)
                    printf ("    ");
                printf ("%s", s);

				GetString (cObj->Object.ModId, s);
				printf ("(%s)", s); 
                if (Option) {
                    printf (", Type= ");
                    if (cObj->Object.Type)
                        PrintTy(cObj->Object.Type);
                    else
                        printf ("NIL");
                }
                printf ("\n");

                if (cObj->Obj_Inn.Inner) {
                    no_indent++; 
                    ObjPrint (cObj->Obj_Inn.Inner, Option);
                    no_indent--;
                }
                break;
            case kObj_Tmp:
                break;
        }
        if (cObj->Kind != kObj_Inn) {
			GetString (cObj->Object.ModId, s);
			printf ("(%s)", s); 
            if (Option) {
                printf (": ");
                if (cObj->Object.Type)
                    PrintTy(cObj->Object.Type);
                else
                    printf ("NIL");
            }
            printf ("\n");
        }
        cObj = cObj->Object.Next; 
    }
}

void PrintSymTab(Option)
    bool Option;
{
    ObjPrint(SymsRoot, Option);
}

tObjects mObj_IdList (DeclsIn, Type, IdList, VarDeclKind, ModId)
    tObjects DeclsIn;
    tTree IdList;
    tType Type;
    int VarDeclKind;
	tIdent ModId;
{
    /* adding declared identifiers into the symbol table.
     */
    tTree id_list = IdList;
    tObjects last=NoSym;
    tType ty=Type;
    bool Select=true;

    for (; id_list && id_list->Kind != kNoId; 
           id_list = id_list->Id.Next) {
        if (last==NoSym) { /* first one on the list */
            switch (VarDeclKind) {
            case Is_param:
                if (IsDeclared (DeclsIn, id_list->Id.Ident.Ident, ty)) 
                    Error (id_list->Id.Ident.Pos, error22);
                else 
                    last = mObj_PId (NoSym, DeclsIn, ModId, ty, 
                        id_list->Id.Ident.Ident, Select);
                break;
            case Is_axiom_id:
                if (IsAxiomDeclared (DeclsIn, id_list->Id.Ident.Ident, ty))
                    Error (id_list->Id.Ident.Pos, error22);
                else
                    last = mObj_Id (NoSym, DeclsIn, ModId, ty,
                        id_list->Id.Ident.Ident, Select, NoIdent, Is_obj);
                break;
            case Is_decl_id:
                if (IsDeclared (DeclsIn, id_list->Id.Ident.Ident, ty))
                    Error (id_list->Id.Ident.Pos, error22);
                else
                    last = mObj_Id (NoSym, DeclsIn, ModId, ty,
                        id_list->Id.Ident.Ident, Select, NoIdent, Is_obj);
                break;
            case Is_local_id:
                if (IsDeclared (DeclsIn, id_list->Id.Ident.Ident, ty))
                    Error (id_list->Id.Ident.Pos, error22);
                else
                    last = mObj_Id (NoSym, DeclsIn, ModId, ty,
                        id_list->Id.Ident.Ident, Select, NoIdent, Is_local);
                break;
            case Is_schema_field:
                if (SchFldIsDeclared (DeclsIn, id_list->Id.Ident.Ident, ty))
                    Error (id_list->Id.Ident.Pos, error22);
                else {
                    last = mObj_Id (NoSym, DeclsIn, ModId, ty, 
                        id_list->Id.Ident.Ident, Select, NoIdent, Is_zvar);
				}
                break;
            default:
                break;
            }
            if (DeclsIn->Kind == kObj_Inn && !DeclsIn->Obj_Inn.Inner) 
                DeclsIn->Obj_Inn.Inner = last;
            else if (DeclsIn->Kind == kObj_Tmp && !DeclsIn->Obj_Tmp.Inner)
                DeclsIn->Obj_Tmp.Inner = last;
            else
                DeclsIn->Object.Next = last;
        }
        else 
            switch (VarDeclKind) {
            case Is_param:
                if (IsDeclared (last, id_list->Id.Ident.Ident, ty))
                    Error (id_list->Id.Ident.Pos, error22);
                else {
                    last->Object.Next = mObj_PId (NoSym, last, ModId, ty,
                        id_list->Id.Ident.Ident, Select);
                    last = last->Object.Next;
                }
                break;
            case Is_axiom_id:
                if (IsAxiomDeclared (last, id_list->Id.Ident.Ident, ty))
                    Error (id_list->Id.Ident.Pos, error22);
                else {
                    last->Object.Next = mObj_Id (NoSym, last, ModId, ty,
                        id_list->Id.Ident.Ident, Select, NoIdent, Is_obj);
                    last = last->Object.Next;
                }
                break;
            case Is_decl_id:
                if (IsDeclared (last, id_list->Id.Ident.Ident, ty)) 
                    Error (id_list->Id.Ident.Pos, error22);
                else {
                    last->Object.Next = mObj_Id (NoSym, last, ModId, ty,
                        id_list->Id.Ident.Ident, Select, NoIdent, Is_obj);
                    last = last->Object.Next;
                }
                break;
            case Is_local_id:
                if (IsDeclared (last, id_list->Id.Ident.Ident, ty)) 
                    Error (id_list->Id.Ident.Pos, error22);
                else {
                    last->Object.Next = mObj_Id (NoSym, last, ModId, ty,
                        id_list->Id.Ident.Ident, Select, NoIdent, Is_local);
                    last = last->Object.Next;
                }
                break;
            case Is_schema_field:
                if (SchFldIsDeclared (last, id_list->Id.Ident.Ident, ty))
                    Error (id_list->Id.Ident.Pos, error22);
                else {
                    last->Object.Next = mObj_Id (NoSym, last, ModId, ty,
                        id_list->Id.Ident.Ident, Select, NoIdent, Is_zvar);
                    last = last->Object.Next;
                }
                break;
            default:
                break;
            }
    }
    if (last==NoSym)
        return DeclsIn;
    else
        return last;
}

/* DeclsIn points to the symbol of NewIdent
 */
void ImportHandler (DeclsIn, ActualParams, formalparams) 
    tObjects DeclsIn;
  /*  tIdPos Ident; */
    tTree ActualParams;
  /* IML_List *iml; */
    tObjects *formalparams;
  /*  tIdPos NewId; */
{
    tObjects fml_params=NoSym;
    tTree act_params=ActualParams;
    tObjects sym=NoSym;
    tObjects declsin = DeclsIn;

    /* 29/6/98 moved read module and CopySyms into sum.cg
       Import Handler now does Instantiation only

       Check if import is of a module already in current file 
       if it is make a new copy of it before instantiation 
       NewId must be embedded within it as the ModId for types and objects
     
    sym = LookUp(DeclsIn, Ident.Ident, NoSym);
    if (sym != NoSym) {
        declsin->Obj_Inn.Inner = CopySyms(sym);
        * TraverseSyms to substiture in ModId *
    }
    else {
      * import is from a another file *
      * read ident.mod as an object - use new name - update import list*

      if (Ident.Ident == NewId.Ident)
	declsin->Obj_Inn.Inner = ReadModule (Ident, iml, NoIdent);
      else 
	declsin->Obj_Inn.Inner = ReadModule (Ident, iml, NewId.Ident);
    }

    * previous symtab of new module  is declsin  - return if failed*

    if (declsin->Obj_Inn.Inner->Kind != kNoObject)
        declsin->Obj_Inn.Inner->Object.Pre = declsin;
    else
        return;

    */
    /* first object of decls in is formals  */
    /* check equal number of params and compatible */
    /*- return if no actuals or actuals not compatible (set formals to noObj */
/*wj -- debugging PrintBTvalues(declsin);*/
    fml_params = declsin->Obj_Inn.Inner;

            /*    printf("ImportHandler\n");
                ObjPrint(fml_params, 1); */

    *formalparams = fml_params;
    if (!ParamComp(fml_params, act_params)) {
        Error (ActualParams->Exp.Pos, error3);
        declsin->Obj_Inn.Inner = nNoObj;
        return;
    }
    else if (act_params->Kind == kNoExp)
        return;

    /* the rest is for param instantiation */
    /* formals are objects, actuals are syntax */
    /* seems to be done by changing the value of the formals object type */
    /*  (type params only) to equal the value of the actuals by copying */

    /* depending on whether the actuals IsTypeExp? or a power set */

    for (; act_params->Kind != kNoExp; act_params=act_params->Exp.Next) {
        
       /* if the parameter is a type parameter */
       if (fml_params && fml_params->Kind == kObj_PTyId)
           if (act_params->Exp.IsTypeExp) {

		if (Type_IsType(act_params->Exp.Type,kTp_Exp));
		else
			{printf("\nimport handler actual param not a type exp\n");
			WriteType(stdout,act_params->Exp.Type);
			exit(1);}

       /*       printf("Type");
              PrintTy(fml_params->Object.Type);
              printf("\n"); */

              *(fml_params->Object.Type) = *(act_params->Exp.Type);
              /* set the pointer to the copy of it */
	      fml_params->Object.Type->Tp_Exp.PtrToCopy = act_params->Exp.Type;
           }
           else if (act_params->Exp.Type && act_params->Exp.Type->Kind == kTp_Power) {
                *(fml_params->Object.Type) = *(act_params->Exp.Type->Tp_Power.Tp_Exp); 
		fml_params->Object.Type->Tp_Exp.PtrToCopy = act_params->Exp.Type->Tp_Power.Tp_Exp;
	        }
                else {
                  Error (act_params->Exp.Pos, error3);
                  return;
                }
       /* otherwise its a fncparam so actparam must not be a type */
       else if (act_params->Exp.IsTypeExp ||
                (!Compatible (fml_params->Object.Type, act_params->Exp.Type))) {

                Error (act_params->Exp.Pos, error3);
                declsin->Obj_Inn.Inner = nNoObj;
                return;
        }
        fml_params = fml_params->Object.Next;
    }
    /* if other things in module then leave otherwise set to no object */
    if (fml_params) {

          /*      printf("ImportHandler 2\n");
                ObjPrint(fml_params, 1); */

        declsin->Obj_Inn.Inner = fml_params;
        if (fml_params->Kind != kNoObject)
            fml_params->Object.Pre = DeclsIn;
    }
    else
        declsin->Obj_Inn.Inner = nNoObj;
    return;
} 

void RenameHandler (DeclsIn, RenameList)
    tObjects DeclsIn;
    tTree RenameList;
{
    tTree rename_ptr=RenameList;
    tObjects sym_ptr=NoSym;
    tIdent OldIdent;
    tPosition pos;
    tTree idlist=NoTree;

    if (rename_ptr->Kind == kNoRename)
        return;
    for (; rename_ptr && rename_ptr->Kind != kNoRename;
        rename_ptr = rename_ptr->Rename.Next) {

        pos = rename_ptr->Rename.OldIdent->Id.Ident.Pos;
        idlist=rename_ptr->Rename.OldIdent;
	if (idlist->Id.Next->Kind != kNoId && 
			idlist->Id.Next->Id.Next->Kind != kNoId) 
            Error (pos, error37);
	else if (idlist->Id.Next->Kind != kNoId &&
			idlist->Id.Next->Id.Next->Kind == kNoId &&
			idlist->Id.Ident.Ident != ModIdent)

                 Error (pos, error37);
	     else {
		if (idlist->Id.Next->Kind != kNoId)
			OldIdent = idlist->Id.Next->Id.Ident.Ident;
		else
			OldIdent = idlist->Id.Ident.Ident;
		sym_ptr = DeclsIn;
		for (;sym_ptr && sym_ptr->Kind != kNoObject;
		      sym_ptr = sym_ptr->Object.Next) 

		   if (OldIdent == sym_ptr->Object.Ident) {
		      sym_ptr->Object.Ident = rename_ptr->Rename.NewIdent.Ident;
		      break;
		   }
		   if (!sym_ptr || sym_ptr->Kind == kNoObject) 
			Error (pos, error11);
	     }
    }
}

/* to find out if the schema field with name "Ident" has been declared.
 * 1) check current scope
 * 2) check outer scope
 * 3) if meeting a schema definition in outer scope, go into it.
 *    (it is ok if the "Ident" has compatible type with one of those fields,
 *    otherwise it gives an error.)      
 */
bool SchFldIsDeclared (DeclsIn, Ident, IdType)
    tObjects DeclsIn;
    tIdent Ident;
    tType IdType;
{
    tObjects sym_ptr = DeclsIn, sch_inn = NoSym;

    if (sym_ptr->Kind == kObj_Inn && !sym_ptr->Obj_Inn.Inner)
        ;
    else {
        /* not the first field */
        for (; sym_ptr && sym_ptr->Kind != kNoObject;
            sym_ptr = sym_ptr->Object.Pre) { /* current schema scope */
            if (sym_ptr->Object.Ident == Ident && 
				sym_ptr->Kind == kObj_Id &&
				sym_ptr->Obj_Id.QuId == NoIdent &&
				sym_ptr->Obj_Id.VarKind == Is_zvar)
                return true;
            if (sym_ptr->Object.Pre->Kind == kObj_Inn 
                && sym_ptr->Object.Pre->Obj_Inn.Inner == sym_ptr)
                break;
        }
        sym_ptr = sym_ptr->Object.Pre;
    }
    if (sym_ptr->Object.Pre->Kind == kObj_Inn 
        && sym_ptr->Object.Pre->Obj_Inn.Inner == sym_ptr) 
    /* first declaration in the outer module */
        return false;
    sym_ptr = sym_ptr->Object.Pre;
    for (; sym_ptr && sym_ptr->Kind != kNoObject; sym_ptr = sym_ptr->Object.Pre) { /* outer module scope */
        if (sym_ptr->Object.Ident == Ident)
            return true;

/* look inside other nested scopes for other occurences 
   now disabled to allow more Z like schemas lpw 1/6/98 
        if (sym_ptr->Kind == kObj_Inn && sym_ptr->Obj_Inn.ObjKind == Obj_schema) {
            sch_inn = LookUpInn (sym_ptr->Obj_Inn.Inner, Ident);
            if (sch_inn)
                if (!TypeStructEq (sch_inn->Object.Type, IdType))
                    return true;
        } */
        if (sym_ptr->Object.Pre->Kind == kObj_Inn 
            && sym_ptr->Object.Pre->Obj_Inn.Inner == sym_ptr)
            break;
    }
    return false;
}

/* to find out if the module-range "Ident" has been declared in the scope,
 * if meeting a schema definition in the module scope, check if it is 
 * already declared as a signature variable.
 */

bool IsDeclared (DeclsIn, Ident, Ty)
    tObjects DeclsIn;
    tIdent Ident;
    tType Ty;
{
    tObjects sym_ptr = DeclsIn;
    tType t1=Ty, t2=NoType;

    if ((sym_ptr->Kind == kObj_Inn && !sym_ptr->Obj_Inn.Inner) ||
        (sym_ptr->Kind == kObj_Tmp && !sym_ptr->Obj_Tmp.Inner))
        /* first declaration in the current scope */
        return false;
    for (; sym_ptr && sym_ptr->Kind != kNoObject; sym_ptr = sym_ptr->Object.Pre) { 
/* lpw 1/6/98 looks in schemas to see if names used before- stop it
        if(sym_ptr->Kind == kObj_Inn && sym_ptr->Obj_Inn.ObjKind == Obj_schema)
            if (LookUpInn (sym_ptr->Obj_Inn.Inner, Ident))
                return true; */

        if (sym_ptr->Object.Ident == Ident) {
            t2 = sym_ptr->Object.Type;
            if (t1 && t1->Kind == kTp_Infix && t2 && t2->Kind == kTp_Infix)
                if (Compatible (t1, t2))
                    return true;
                else
                    ; /* continuing to search for the next one */
            else
                return true;
        }
        if ((sym_ptr->Object.Pre->Kind == kObj_Inn 
            && sym_ptr->Object.Pre->Obj_Inn.Inner == sym_ptr) ||
            (sym_ptr->Object.Pre->Kind == kObj_Tmp 
            && sym_ptr->Object.Pre->Obj_Tmp.Inner == sym_ptr))
            break;
    }
    return false;
}

bool IsAxiomDeclared (DeclsIn, Ident, Ty)
    tObjects DeclsIn;
    tIdent Ident;
    tType Ty;
{
    tObjects sym_ptr = DeclsIn;
    tType t1=Ty, t2=NoType;

    if (sym_ptr->Kind == kObj_Tmp && !sym_ptr->Obj_Tmp.Inner)
        /* first declaration in the current scope */
        sym_ptr = sym_ptr->Object.Pre;
    else {
        for (; sym_ptr && sym_ptr->Kind != kNoObject; sym_ptr = sym_ptr->Object.Pre) { 
            if(sym_ptr->Kind == kObj_Inn && sym_ptr->Obj_Inn.ObjKind == Obj_schema)
                if (LookUpInn (sym_ptr->Obj_Inn.Inner, Ident))
                    return true;
            if (sym_ptr->Object.Ident == Ident) {
                t2 = sym_ptr->Object.Type;
                if (t1 && t1->Kind == kTp_Infix && t2 && t2->Kind == kTp_Infix)
                    if (Compatible (t1, t2))
                        return true;
                    else 
                        ; /* continuing to search for the next one */
                else
                    return true;
            }
            if ((sym_ptr->Object.Pre->Kind == kObj_Inn 
                && sym_ptr->Object.Pre->Obj_Inn.Inner == sym_ptr) ||
                (sym_ptr->Object.Pre->Kind == kObj_Tmp 
                && sym_ptr->Object.Pre->Obj_Tmp.Inner == sym_ptr)) {
                    sym_ptr = sym_ptr->Object.Pre;
                    if (sym_ptr && sym_ptr->Kind != kNoObject)
                        sym_ptr = sym_ptr->Object.Pre;
                    break;
                }
        }
    }
    if (sym_ptr && sym_ptr->Kind == kObj_Inn) 
        return false;
    else 
        for (; sym_ptr && sym_ptr->Kind != kNoObject; sym_ptr = sym_ptr->Object.Pre) { 
            if(sym_ptr->Kind == kObj_Inn && sym_ptr->Obj_Inn.ObjKind == Obj_schema)
                if (LookUpInn (sym_ptr->Obj_Inn.Inner, Ident))
                    return true;
            if (sym_ptr->Object.Ident == Ident) {
                t2 = sym_ptr->Object.Type;
                if (t1 && t1->Kind == kTp_Infix && t2 && t2->Kind == kTp_Infix)
                    if (Compatible (t1, t2))
                        return true;
                    else 
                        ; /* continuing to search for the next one */
                else
                    return true;
            }
            if ((sym_ptr->Object.Pre->Kind == kObj_Inn 
                && sym_ptr->Object.Pre->Obj_Inn.Inner == sym_ptr) ||
                (sym_ptr->Object.Pre->Kind == kObj_Tmp 
                && sym_ptr->Object.Pre->Obj_Tmp.Inner == sym_ptr)) 
                    break;
        }
    return false;
}

/* to find the "Ident" in the symbol table and return the entry of it.
 * if not found, return NoSym.
 */
tObjects LookUp (DeclsIn, Ident, LastDeclsIn)
  tIdent Ident;
  tObjects DeclsIn, LastDeclsIn;
{
  tObjects sym_ptr=NoSym, inn_ptr=NoSym;
  char str1[IDENT_LENGTH], str2[IDENT_LENGTH];

  GetString(Ident, str1);

  sym_ptr = DeclsIn;
  for (;;) {
     if (sym_ptr==NoSym || sym_ptr->Kind == kNoObject) 
 	return NoSym;

     if (sym_ptr->Object.Ident == Ident) {
        return sym_ptr;
     }

     GetString(sym_ptr->Object.Ident, str2);
     if (sym_ptr->Kind == kObj_Inn && 
 	 ((sym_ptr->Obj_Inn.ObjKind == Obj_import ||
	   sym_ptr->Obj_Inn.ObjKind == Obj_module) &&
	 sym_ptr->Obj_Inn.Visible)) {
       
         /* lpw 23/10/96 - bugfix this test is to prevent looking into
            a scope looked into previously but reexamined because pre points
            back up to parent in child. Changed && to ||  allow lookupinn
            when lastdeclsin is not nosym
         */

         if (LastDeclsIn == NoSym || sym_ptr->Obj_Inn.Inner != LastDeclsIn) {
            inn_ptr = LookUpInn (sym_ptr->Obj_Inn.Inner, Ident);
	    if (inn_ptr != NoSym)
		return inn_ptr;
         }

     }

     /* what does this do?
         sym_ptr->Object.Pre->Obj_Inn.Inner == sym_ptr) 
        fixes it!
     */

     if (sym_ptr->Object.Pre->Kind == kObj_Inn &&
          sym_ptr->Object.Pre->Obj_Inn.Inner == sym_ptr) { 

         sym_ptr = sym_ptr->Object.Pre;
	 if (sym_ptr->Object.Ident == Ident)
	     return sym_ptr;
	 sym_ptr = sym_ptr->Object.Pre;
     }
     else 
        sym_ptr = sym_ptr->Object.Pre;
  } /* for */
}   /* LookUp */

/* to find the "Ident" in an inner scope, and return the entry of it.
 * if not found, return NoSym(NULL).
 */
tObjects LookUpInn (Inner, Ident)
    tIdent Ident;
    tSyms Inner;
{
    tSyms sym_ptr=Inner;
    tSyms inn_ptr=NoSym;

    if (sym_ptr==NoSym || sym_ptr->Kind == kNoObject)
		return NoSym;

    /* get to the last element of the Inner */
    for (; sym_ptr && sym_ptr->Kind != kNoObject;
             sym_ptr = sym_ptr->Object.Next) 
	if (sym_ptr && 
	       (sym_ptr->Object.Next == NoSym ||
                sym_ptr->Object.Next->Kind == kNoObject))
	   break;
	
    /* start the search from the last element of the Inner */
    for (; sym_ptr && sym_ptr->Kind != kNoObject;
		sym_ptr = sym_ptr->Object.Pre) {

        if (sym_ptr->Object.IsSelected && sym_ptr->Object.Ident == Ident)
            return sym_ptr;
        else if (sym_ptr->Kind == kObj_Inn && 
                 (sym_ptr->Obj_Inn.ObjKind == Obj_import ||
                  sym_ptr->Obj_Inn.ObjKind == Obj_module) &&
	         sym_ptr->Obj_Inn.Visible)

            if (inn_ptr = LookUpInn (sym_ptr->Obj_Inn.Inner, Ident)) 
		return inn_ptr;

	if (sym_ptr->Object.Pre->Kind == kObj_Inn && 
	    sym_ptr->Object.Pre->Obj_Inn.Inner == sym_ptr)
		break;
	}
    return NoSym;
}

/* to find the qualified Ident in the symbol table (from the current scope
 * to the outermost), return the entry of it, if failed, return
 * NoSym. 
 */
tObjects LookUpName (DeclsIn, Name, LastDeclsIn)
    tObjects DeclsIn;
    tTree Name;
    tObjects LastDeclsIn;
{
    tTree id_list = Name, last=NoTree;
    tObjects sym_ptr = NoSym;
    tSyms hold = NoSym;
    tIdent stem = NoIdent;
    int i=0;

    char str[IDENT_LENGTH], str1[IDENT_LENGTH], str2[IDENT_LENGTH];

    GetString(id_list->Id.Ident.Ident, str1);
    sym_ptr = LookUp (DeclsIn, id_list->Id.Ident.Ident, LastDeclsIn);
    if (sym_ptr == NoSym) 
        return NoSym;
    else {
      id_list = id_list->Id.Next;
      for (; id_list && id_list->Kind != kNoId; id_list = id_list->Id.Next) 
          if (sym_ptr->Kind == kObj_Inn &&
	      sym_ptr->Obj_Inn.ObjKind != Obj_schema) {

	     if (sym_ptr->Obj_Inn.Inner && 
                 sym_ptr->Obj_Inn.Inner->Kind == kObj_Param) {
		   Error (Name->Id.Ident.Pos, error20);
		   return NoSym;
	     }

/* wj --- 9/9/99 remember the inner */
	     hold = sym_ptr->Obj_Inn.Inner;
             sym_ptr = LookUpInn (sym_ptr->Obj_Inn.Inner,
                                  id_list->Id.Ident.Ident);
             if (sym_ptr == NoSym) 
/* wj --- 9/9/99 
   try importmod.a to be interpreted as importmod.state.a */
		{
/*printf("state try\n");*/
		sym_ptr = LookUpInn (hold,MakeIdent("state",5));
		if (sym_ptr == NoSym) 
                 return NoSym;
		else {
/*printf("state try must have found a state\n");*/
/* get the stem name i.e. without primes */
			GetString(id_list->Id.Ident.Ident,str);
			stem = id_list->Id.Ident.Ident;
			for ( i=0; i<strlen(str); i++) 
				if (str[i] == '\'') {
				   str[i] = '\0';
				   stem = MakeIdent(str,strlen(str));
				   }
			sym_ptr = LookUpInn (sym_ptr->Obj_Inn.Inner,stem);
			}
		}
          }
          else
             return NoSym;
      return sym_ptr;
    }
}

#define FILE_PERM 0644

/* WriteModule starts writing out the imported modules information
 * from the command line(name with version number) first, then the 
 * current module.
 */
void WriteModule (SymEntry, Ident)
    tObjects SymEntry;
    tIdent Ident;
{
    char str[IDENT_LENGTH], modstr[IDENT_LENGTH];
    int fd;
    int len;
    int i;
	IML_List iml;

    str[0] = '\0'; 
/* wj --- debugging PrintBTvalues(SymEntry);*/
    GetString (Ident, modstr);
    /*strcat (str, SumPathName);*/
    strcat (str, modstr);
    strcat (str, ".mod");

    fd = creat (str, FILE_PERM);
    if (fd == -1)
        fprintf (stderr, "Can't write to file: %s\n", str);
        
	/* write out the version number for imported module */
    mywrite (fd, &Argc, sizeof (int));
    for (i=0; i < Argc; i++) {
        len = strlen (Argv[i]);
        mywrite (fd, &len, sizeof(int));
        mywrite (fd, Argv[i], len);
    }

	/* write out new module names from import-as statement for the
	 * translation to Ergo.
	 */
	for(i=0, iml=cur_mod_imllist_hd; iml != NULL; i++, iml=iml->next)
		;
    mywrite (fd, &i, sizeof (int));
	for (iml=cur_mod_imllist_hd; iml != NULL; iml=iml->next) {
		char parentmodstr[IDENT_LENGTH];

		mygetstr (iml->ParentModId, parentmodstr);
		len = strlen (parentmodstr);
        mywrite (fd, &len, sizeof(int));
        mywrite (fd, parentmodstr, len);

		len = strlen (iml->subthyid);
        mywrite (fd, &len, sizeof(int));
        mywrite (fd, iml->subthyid, len);
	}

    TyNoCounter = 0;
    allo_head = NULL;
    allo_tail = NULL;


    WriteObj (SymEntry, fd);

    { 
      struct ty_allo_str *allo_ptr=allo_head;

      for (; allo_ptr; allo_ptr=allo_ptr->next)
            allo_ptr->ty_addr->Tp_Exp.TyNo = 0; 
    }

    close (fd);
}

void WriteId (Ident, fd)
    tIdent Ident;
    int fd;
{
    char str[IDENT_LENGTH];
    int len=0;

    str[0] = '\0';
    if (Ident != NoIdent) 
        GetString (Ident, str);
    len = strlen (str);
    mywrite (fd, &len, sizeof (int));
    if (len != 0)
        mywrite (fd, str, len);
}

tIdent ReadId (fd)
    int fd;
{
    char str[IDENT_LENGTH];
    int len=0;

    str[0] = '\0';
    myread (fd, (char *)&len, sizeof (int));
    if (len > 0) {
        myread (fd, (char *)str, len);
        str[len] = '\0';
    }
    if (len == 0)
        return NoIdent;
    else
        return MakeIdent (str, len);
}

void WriteObj (SymEntry, fd)
    tObjects SymEntry;
    int fd;

{
    tObjects sym_ptr= SymEntry;
    char idstr[IDENT_LENGTH];
    char modstr[IDENT_LENGTH];

    if (!sym_ptr) 
        sym_ptr = mNoObject();
    while (sym_ptr) {
        mywrite (fd, &(sym_ptr->Kind), sizeof (Syms_tKind));
        switch (sym_ptr->Kind) {
            case kNoObject:
                return;
            case kObj_Id:
#ifdef WIN32
                mywrite (fd, sym_ptr, SizeofSP);
#else
                mywrite (fd, sym_ptr, sizeof(yObj_Id));
#endif
                WriteId (sym_ptr->Object.Ident, fd);
                WriteId (sym_ptr->Obj_Id.QuId, fd);
                WriteId (sym_ptr->Object.ModId, fd);
                break;
            case kObj_PId:
#ifdef WIN32
                mywrite (fd, sym_ptr, SizeofSP);
#else
                mywrite (fd, sym_ptr, sizeof(yObj_PId));
#endif
                WriteId (sym_ptr->Object.Ident, fd);
                WriteId (sym_ptr->Object.ModId, fd);
                break;
            case kObj_TyId:
#ifdef WIN32
                mywrite (fd, sym_ptr, SizeofSP);
#else
                mywrite (fd, sym_ptr, sizeof(yObj_TyId));
#endif
                WriteId (sym_ptr->Object.Ident, fd);
                WriteId (sym_ptr->Object.ModId, fd);
                break;
            case kObj_PTyId:
#ifdef WIN32
                mywrite (fd, sym_ptr, SizeofSP);
#else
                mywrite (fd, sym_ptr, sizeof(yObj_PTyId));
#endif
                WriteId (sym_ptr->Object.Ident, fd);
                WriteId (sym_ptr->Object.ModId, fd);
                break;
            case kObj_Inn: 
#ifdef WIN32
                mywrite (fd, sym_ptr, SizeofSP);
#else
                mywrite (fd, sym_ptr, sizeof(yObj_Inn));
#endif
                WriteId (sym_ptr->Object.Ident, fd);
                WriteId (sym_ptr->Object.ModId, fd);
                break;
        }
        idstr[0] = '\0';
        modstr[0] = '\0';
        GetString (sym_ptr->Object.Ident, idstr);
        GetString (sym_ptr->Object.ModId, modstr);

        /* if the type exists ie for all cases except obj_Inn for imports */

        if (sym_ptr->Object.Type) 
            WriteTy (sym_ptr->Object.Type, fd);
        if (sym_ptr->Kind == kObj_Inn) 
	{
/* wj --- debugging 26/8/98
printf("\n------%s %s---------------\n",modstr,idstr);
if (strcmp(idstr,"BTVALUES")==0)
   ObjPrint(sym_ptr->Obj_Inn.Inner,1);
	PrintBTvalues(sym_ptr->Obj_Inn.Inner);*/

            WriteObj (sym_ptr->Obj_Inn.Inner, fd);
	}


        sym_ptr = sym_ptr->Object.Next;
    }
}

tObjects ReadModule (Ident, iml, NewId)
    tIdPos Ident;
	IML_List *iml;
    tIdent NewId;
{
    char filestr[IDENT_LENGTH];
    int fd;
    tObjects rtn_obj=nNoObj; 
    int argu=0, end=0, filestart=0;
    int len=0, i=0;
    int num=0;
    IML_List imllist=NULL;

    filestr[0] = '\0';
    GetString (Ident.Ident, filestr);

    for (argu=0; argu < Argc; argu++) {
        len = strlen (Argv[argu]);
        for (i=0; i < len; i++) 
            if (Argv[argu][i] == '=') {
                end = i-1;
                filestart = i+1;
                break;
            }
        if (i < len-1) {
            if (strncmp(filestr, Argv[argu], end+1) == 0) {
                filestr[0] = '\0';
                strcpy (filestr, Argv[argu]+filestart); 
                break;
            }
        }
    }
    if (argu == Argc) 
        strcat (filestr, ".mod"); 

    fd = open (filestr, O_RDONLY);

    if (fd == -1) {
        /*
        fprintf (stderr,
          "Can't find file \"%s\" for the imported module!\n", filestr);
        */
        char *errstr;

        errstr = (char *) my_malloc (IDENT_LENGTH);
        errstr [0] = '\0';
        strcpy (errstr, "Can't find file \""); 
        strcat (errstr, filestr); 
        strcat (errstr, "\" for the imported module."); 
        Error (Ident.Pos, errstr);
        return rtn_obj; 
    }

    /* read the head info. of the file. */
    myread (fd, &num, sizeof (int));
    for (i=1; i<=num; i++) {
        myread (fd, &len, sizeof (int));
        myread (fd, filestr, len);
    }

	/* ?? free the old list
	 * read IML list of this module
	 */
    myread (fd, &num, sizeof (int));
    for (i=1; i<=num; i++) {
	char parentmodstr[IDENT_LENGTH];

	if (imllist == NULL) {
	   imllist = (IML_List) my_malloc (sizeof (struct IMLstruct));
	   *iml = imllist;
	}
	else {
	   imllist->next = (IML_List) my_malloc (sizeof (struct IMLstruct));
	   imllist = imllist->next;
	}
	imllist->next = NULL;

        myread (fd, &len, sizeof (int));
        myread (fd, parentmodstr, len);
	parentmodstr[len] = '\0';
	imllist->ParentModId = MakeIdent (parentmodstr, strlen(parentmodstr));

        myread (fd, &len, sizeof (int));
        myread (fd, imllist->subthyid, len);
	imllist->subthyid[len] = '\0';
    }

    if (num == 0) *iml = NULL;

    allo_head = NULL;
    allo_tail = NULL;
    rtn_obj = ReadObj (fd, NewId);
    close (fd);

    { 
      struct ty_allo_str *allo_ptr=allo_head;

      for (; allo_ptr; allo_ptr=allo_ptr->next)
            allo_ptr->ty_addr->Tp_Exp.TyNo = 0; 
    }

    return rtn_obj;
}

void PrintMod (Name)
    char *Name;
{
    tObjects rtn_obj=nNoObj; 
    int fd;
    int len=0, i=0;
    int num=0;
    char wastestr [IDENT_LENGTH], 
         subthyid[IDENT_LENGTH], 
         parentmodstr[IDENT_LENGTH];

    fd = open (Name, O_RDONLY);

    if (fd == -1) {
       fprintf (stderr, "Can't find file \"%s\" for the named module!\n", Name);
       exit(1);
    }

    /* read the head info. of the file. */
    myread (fd, &num, sizeof (int));
    for (i=1; i<=num; i++) {
        myread (fd, &len, sizeof (int));
        if (len > IDENT_LENGTH)
            InterErr (Ierror4);
        myread (fd, wastestr, len);
    }

	/* reading IML list */
    printf ("%s, IML = ", Name); 
    myread (fd, &num, sizeof (int));
    for (i=1; i<=num; i++) {
	myread (fd, &len, sizeof (int));
	myread (fd, parentmodstr, len);
	parentmodstr[len] = '\0';

	myread (fd, &len, sizeof (int));
	myread (fd, subthyid, len);
	subthyid[len] = '\0';
	printf ("(%s,%s) ", parentmodstr, subthyid);
    }
    printf ("\n");

    allo_head = NULL;
    allo_tail = NULL;
    rtn_obj = ReadObj (fd, NoIdent);
    close (fd);
    { struct ty_allo_str *allo_ptr=allo_head;
        for (; allo_ptr; allo_ptr=allo_ptr->next)
            allo_ptr->ty_addr->Tp_Exp.TyNo = 0; 
    }
    ObjPrint (rtn_obj, 1); /* print module with type info. */
}

tSyms ReadObj (fd, Ident)
    int fd;
    tIdent Ident;
{
    Syms_tKind tag;
    tSyms fst=NoSym, last=NoSym;
		  char str[IDENT_LENGTH], str2[IDENT_LENGTH];

    while (1) {
        myread (fd, (char *)&tag, sizeof (Syms_tKind));
        switch (tag) {
        case kNoObject:
            if (!fst) 
                fst = mNoObject();
            else 
                last->Object.Next = mNoObject();
            return fst;
        case kObj_Id:
            if (!fst) {
#ifdef WIN32
                fst = (tSyms) my_malloc (SizeofSP);
                myread (fd, (char *)fst, SizeofSP);
#else
                fst = (tSyms) my_malloc (sizeof (yObj_Id));
                myread (fd, (char *)fst, sizeof(yObj_Id));
#endif
                fst->Object.Ident = ReadId (fd);
                fst->Obj_Id.QuId = ReadId (fd);
                fst->Object.ModId = ReadId (fd);
                last = fst;
            }
            else {
#ifdef WIN32
                last->Object.Next = (tSyms) my_malloc (SizeofSP);
                myread (fd, (char *)last->Object.Next, SizeofSP);
#else
                last->Object.Next = (tSyms) my_malloc (sizeof (yObj_Id));  
                myread (fd, (char *)last->Object.Next, sizeof(yObj_Id));
#endif
                last->Object.Next->Object.Pre = last;
                last = last->Object.Next;
                last->Object.Ident = ReadId (fd);
                last->Obj_Id.QuId = ReadId (fd);
                last->Object.ModId = ReadId (fd);
            }
            break;
        case kObj_TyId:
            if (!fst) {
#ifdef WIN32
                fst = (tSyms) my_malloc (SizeofSP);
                myread (fd, (char *)fst, SizeofSP);
#else
                fst = (tSyms) my_malloc (sizeof (yObj_TyId));
                myread (fd, (char *)fst, sizeof(yObj_TyId));
#endif
                fst->Object.Ident = ReadId (fd);
                fst->Object.ModId = ReadId (fd);
                last = fst;
            }
            else {
#ifdef WIN32
                last->Object.Next = (tSyms) my_malloc (SizeofSP);
                myread (fd, (char *)last->Object.Next, SizeofSP);
#else
                last->Object.Next = (tSyms) my_malloc (sizeof (yObj_TyId));  
                myread (fd, (char *)last->Object.Next, sizeof(yObj_TyId));
#endif
                last->Object.Next->Object.Pre = last;
                last = last->Object.Next;
                last->Object.Ident = ReadId (fd);
                last->Object.ModId = ReadId (fd);
            }
            break;
        case kObj_PId:
            if (!fst) {
#ifdef WIN32
                fst = (tSyms) my_malloc (SizeofSP);
                myread (fd, (char *)fst, SizeofSP);
#else
                fst = (tSyms) my_malloc (sizeof (yObj_PId));
                myread (fd, (char *)fst, sizeof(yObj_PId));
#endif
                fst->Object.Ident = ReadId (fd);
                fst->Object.ModId = ReadId (fd);
                last = fst;
            }
            else {
#ifdef WIN32
                last->Object.Next = (tSyms) my_malloc (SizeofSP);
                myread (fd, (char *)last->Object.Next, SizeofSP);
#else
                last->Object.Next = (tSyms) my_malloc (sizeof (yObj_PId));  
                myread (fd, (char *)last->Object.Next, sizeof(yObj_PId));
#endif
                last->Object.Next->Object.Pre = last;
                last = last->Object.Next;
                last->Object.Ident = ReadId (fd);
                last->Object.ModId = ReadId (fd);
            }
            break;
        case kObj_PTyId:
            if (!fst) {
#ifdef WIN32
                fst = (tSyms) my_malloc (SizeofSP);
                myread (fd, (char *)fst, SizeofSP);
#else
                fst = (tSyms) my_malloc (sizeof (yObj_PTyId));
                myread (fd, (char *)fst, sizeof(yObj_PTyId));
#endif
                fst->Object.Ident = ReadId (fd);
                fst->Object.ModId = ReadId (fd);
                last = fst;
            }
            else {
#ifdef WIN32
                last->Object.Next = (tSyms) my_malloc (SizeofSP);
                myread (fd, (char *)last->Object.Next, SizeofSP);
#else
                last->Object.Next = (tSyms) my_malloc (sizeof (yObj_PTyId));  
                myread (fd, (char *)last->Object.Next, sizeof(yObj_PTyId));
#endif
                last->Object.Next->Object.Pre = last;
                last = last->Object.Next;
                last->Object.Ident = ReadId (fd);
                last->Object.ModId = ReadId (fd);
            }
            break;
        case kObj_Inn:
            if (!fst) {
#ifdef WIN32
                fst = (tSyms) my_malloc (SizeofSP);
                myread (fd, (char *)fst, SizeofSP);
#else
                fst = (tSyms) my_malloc (sizeof (yObj_Inn));
                myread (fd, (char *)fst, sizeof(yObj_Inn));
#endif
                fst->Object.Ident = ReadId (fd);
                fst->Object.ModId = ReadId (fd);
                last = fst;
            }
            else {
#ifdef WIN32
                last->Object.Next = (tSyms) my_malloc (SizeofSP);
                myread (fd, (char *)last->Object.Next, SizeofSP);
#else
                last->Object.Next = (tSyms) my_malloc (sizeof (yObj_Inn));  
                myread (fd, (char *)last->Object.Next, sizeof(yObj_Inn));
#endif
                last->Object.Next->Object.Pre = last;
                last = last->Object.Next;
                last->Object.Ident = ReadId (fd);
                last->Object.ModId = ReadId (fd);
            }
            break;
        }
         /* debug */
		   str[0] = '\0';
		   str2[0] = '\0';
		   GetString (last->Object.Ident, str);
		   GetString (last->Object.ModId, str2);
                   
        last->Object.Type = ReadType(last->Object.Type, fd);
/*if (strcmp(str,"BTvalues")==0) WriteType(stdout,last->Object.Type);*/

	if (Ident != NoIdent) {
 	   if (last->Object.Type) {
		if (last->Object.Type->Tp_Exp.ModId == last->Object.ModId)
			last->Object.Type->Tp_Exp.ModId = Ident;
		if (last->Object.Type->Kind == kTp_Schema) {

		   tType fld=last->Object.Type->Tp_Schema.Tp_SchFieldList;

		   for (; fld; fld = fld->Tp_SchField.Next)
			if (fld->Tp_SchField.ModId == last->Object.ModId)
				fld->Tp_SchField.ModId = Ident;
		}
	   }
	   last->Object.ModId = Ident;
	}

        if (tag == kObj_Inn) {
            last->Obj_Inn.Inner = ReadObj (fd, Ident);
            if (last->Obj_Inn.Inner && last->Obj_Inn.Inner->Kind != kNoObject)
                last->Obj_Inn.Inner->Object.Pre = last;
        }

        if (!(last->Object.Next))
            return fst;
    }
}

void WriteTy (Ty, fd)
    tType Ty;
    int fd;
{
    tType ty=Ty;
    bool booltag=false;
    char idstr[IDENT_LENGTH];
    char modstr[IDENT_LENGTH];
    tType tmp;
    bool istmptype=false;
/*    char cpstr[IDENT_LENGTH];*/

    /* why would this get called with an empty type */
    /* remove it and see what happens 

    if (!ty)
        return;
    */
/* check that it is a type expression */
   if (Type_IsType(ty,kTp_Exp));
   else {
	printf("\nWriteTy ty is not a type expression %%%%%%%%%%%%%\n");
	WriteType(stdout,ty);
	exit(1);}

        idstr[0] = '\0';
        modstr[0] = '\0';
        GetString (ty->Tp_Exp.Ident, idstr);
        GetString (ty->Tp_Exp.ModId, modstr);

    /* if TyNo == 0 then it hasnt been met before so it can be written out
        unless it is a parameter (ptrtocopy is not null)       
    */

    if (ty->Tp_Exp.TyNo == 0) {


/* check that PtrToCopy is a type expression */
	if (ty->Tp_Exp.PtrToCopy==NoType) {
		TyNoCounter++;
		ty->Tp_Exp.TyNo = TyNoCounter;
		}
	else
	   if (!Type_IsType(ty->Tp_Exp.PtrToCopy,kTp_Exp))
		{printf("\nNot a type expression\n");
		WriteType(stdout,ty);
		exit(1);}
	else {
		if (ty->Tp_Exp.PtrToCopy->Tp_Exp.TyNo != 0) {
/*      cpstr[0] = '\0';
        GetString (ty->Tp_Exp.PtrToCopy->Tp_Exp.Ident, cpstr);*/
			ty->Tp_Exp.TyNo = ty->Tp_Exp.PtrToCopy->Tp_Exp.TyNo;
			booltag = false; 
			mywrite (fd, &booltag, sizeof (bool));
			mywrite (fd, &(ty->Tp_Exp.TyNo), sizeof (int));
			return;
		}
		else {
			TyNoCounter++;
			ty->Tp_Exp.TyNo = TyNoCounter;
			ty->Tp_Exp.PtrToCopy->Tp_Exp.TyNo = TyNoCounter;
		}

/* ?bug fix --- wj --- the ptrtocopy when written out is causing problems when being read back in -- so make it NoType temporarily */
		tmp = ty->Tp_Exp.PtrToCopy;
		ty->Tp_Exp.PtrToCopy=NoType;
		istmptype = true;
	}

        /* type not visited yet, so write out type record */
        /* first keep a record of address of Tp_Exp so that */
        /* it can have its TyNo reset to zero later */ 
 
        if (!allo_head) {
            allo_head = (struct ty_allo_str *) 
                            my_malloc (sizeof (struct ty_allo_str));
            allo_head->ty_addr = ty;
            allo_head->next = NULL;
            allo_tail = allo_head;
        }
        else {
            allo_tail->next = (struct ty_allo_str *) 
                             my_malloc (sizeof (struct ty_allo_str));
            allo_tail = allo_tail->next;
            allo_tail->ty_addr = ty; 
            allo_tail->next = NULL;
        }

	booltag = true;            
	mywrite (fd, &booltag, sizeof (bool));
        mywrite (fd, (char *)&(ty->Kind), sizeof (Type_tKind));
        switch (ty->Kind) {
            case kTp_Poly:
#ifdef WIN32
                mywrite (fd, ty, SizeofTy);
#else
                mywrite (fd, ty, sizeof (yTp_Poly));
#endif
                WriteId (ty->Tp_Exp.ModId, fd);
                WriteId (ty->Tp_Exp.Ident, fd);
                break;
            case kTp_Exp:
#ifdef WIN32
                mywrite (fd, ty, SizeofTy);
#else
                mywrite (fd, ty, sizeof (yTp_Exp));
#endif
                WriteId (ty->Tp_Exp.ModId, fd);
                WriteId (ty->Tp_Exp.Ident, fd);
                break;
            case kTp_Any:
#ifdef WIN32
                mywrite (fd, ty, SizeofTy);
#else
                mywrite (fd, ty, sizeof (yTp_Any));
#endif
                WriteId (ty->Tp_Exp.ModId, fd);
                WriteId (ty->Tp_Exp.Ident, fd);
                break;
            case kTp_Err:
#ifdef WIN32
                mywrite (fd, ty, SizeofTy);
#else
                mywrite (fd, ty, sizeof (yTp_Err));
#endif
                WriteId (ty->Tp_Exp.ModId, fd);
                WriteId (ty->Tp_Exp.Ident, fd);
                break;
            case kTp_Base:
#ifdef WIN32
                mywrite (fd, ty, SizeofTy);
#else
                mywrite (fd, ty, sizeof (yTp_Base));
#endif
                WriteId (ty->Tp_Exp.ModId, fd);
                WriteId (ty->Tp_Exp.Ident, fd);
                break;
            case kTp_Power:
#ifdef WIN32
                mywrite (fd, ty, SizeofTy);
#else
                mywrite (fd, ty, sizeof (yTp_Power));
#endif
                WriteId (ty->Tp_Exp.ModId, fd);
                WriteId (ty->Tp_Exp.Ident, fd);
                WriteTy (ty->Tp_Power.Tp_Exp, fd);
                break;
            case kTp_Seq:
#ifdef WIN32
                mywrite (fd, ty, SizeofTy);
#else
                mywrite (fd, ty, sizeof (yTp_Seq));
#endif
                WriteId (ty->Tp_Exp.ModId, fd);
                WriteId (ty->Tp_Exp.Ident, fd);
                WriteTy (ty->Tp_Seq.Tp_Exp, fd);
                break;
            case kTp_Prefix:
#ifdef WIN32
                mywrite (fd, ty, SizeofTy);
#else
                mywrite (fd, ty, sizeof (yTp_Prefix));
#endif
                WriteId (ty->Tp_Exp.ModId, fd);
                WriteId (ty->Tp_Exp.Ident, fd);
                WriteTy (ty->Tp_Prefix.Tp_Exp, fd);
                break;
            case kTp_Infix:
#ifdef WIN32
                mywrite (fd, ty, SizeofTy);
#else
                mywrite (fd, ty, sizeof (yTp_Infix));
#endif
                WriteId (ty->Tp_Exp.ModId, fd);
                WriteId (ty->Tp_Exp.Ident, fd);
                WriteTy (ty->Tp_Infix.Fst, fd);
                WriteTy (ty->Tp_Infix.Snd, fd);
                break;
            case kTp_CartProd:
#ifdef WIN32
                mywrite (fd, ty, SizeofTy);
#else
                mywrite (fd, ty, sizeof (yTp_CartProd));
#endif
                WriteId (ty->Tp_Exp.ModId, fd);
                WriteId (ty->Tp_Exp.Ident, fd);
                if (ty->Tp_CartProd.Tp_CartList) {
                    tType cartlist = ty->Tp_CartProd.Tp_CartList;
                    for (; cartlist; cartlist = cartlist->Tp_Cart.Next) {
                        mywrite (fd, cartlist, sizeof (yTp_Cart)); 
                        WriteTy (cartlist->Tp_Cart.Tp_Exp, fd);
                    }
                }
                break;
            case kTp_Schema:
#ifdef WIN32
                mywrite (fd, ty, SizeofTy);
#else
                mywrite (fd, ty, sizeof (yTp_Schema));
#endif
                WriteId (ty->Tp_Exp.ModId, fd);
                WriteId (ty->Tp_Exp.Ident, fd);
                if (Type_IsType(ty->Tp_Schema.Tp_SchFieldList,kTp_SchField)) {
                    tType fldlist = ty->Tp_Schema.Tp_SchFieldList;  
                    for (; Type_IsType(fldlist,kTp_SchField); fldlist=fldlist->Tp_SchField.Next) {
                        mywrite (fd, fldlist, sizeof (yTp_SchField)); 
                        WriteId (fldlist->Tp_SchField.ModId, fd);
                        WriteId (fldlist->Tp_SchField.Ident, fd);
                        WriteTy (fldlist->Tp_SchField.Tp_Exp, fd);
                        WriteId (fldlist->Tp_SchField.QuId, fd);
                    }
                }
                break;
        }
/* wj --- restore PtrToCopy */
    if (istmptype) {
	ty->Tp_Exp.PtrToCopy = tmp;
	istmptype=false;}
    }

    else {
        booltag = false;            
        mywrite (fd, &booltag, sizeof (bool));
        mywrite (fd, &(ty->Tp_Exp.TyNo), sizeof (int));
    }
}

tType ReadType (otype, fd)
    tType otype;
    int fd;
{
    Type_tKind ty_tag;
    tType rtnty=NoType;
    bool booltag=false;
    struct ty_allo_str *allo_ptr=allo_head;
    int tyno=0;

    if (otype == NoType)
        return otype;

    /* booltag at beginning of type  - is it a "first occurence" or a ptr */

    myread (fd, (char *)&booltag, sizeof (bool)); 
    if (booltag) {  /* first occurence */

        myread (fd, (char *)&ty_tag, sizeof (Type_tKind));
        switch (ty_tag) {
            case kTp_Poly:
#ifdef WIN32
                rtnty = (tType) my_malloc (SizeofTy);
                myread (fd, (char *)rtnty, SizeofTy );
#else
                rtnty = (tType) my_malloc (sizeof (yTp_Poly));
                myread (fd, (char *)rtnty, sizeof (yTp_Poly));
#endif
                rtnty->Tp_Poly.ModId = ReadId(fd);
                rtnty->Tp_Poly.Ident = ReadId(fd);
                break;
            case kTp_Exp:
#ifdef WIN32
                rtnty = (tType) my_malloc (SizeofTy);
                myread (fd, (char *)rtnty, SizeofTy );
#else
                rtnty = (tType) my_malloc (sizeof (yTp_Exp));
                myread (fd, (char *)rtnty, sizeof (yTp_Exp));
#endif
                rtnty->Tp_Exp.ModId = ReadId(fd);
                rtnty->Tp_Exp.Ident = ReadId(fd);
                break;
            case kTp_Err:
#ifdef WIN32
                rtnty = (tType) my_malloc (SizeofTy);
                myread (fd, (char *)rtnty, SizeofTy );
#else
                rtnty = (tType) my_malloc (sizeof (yTp_Err));
                myread (fd, (char *)rtnty, sizeof (yTp_Err));
#endif
                rtnty->Tp_Exp.ModId = ReadId(fd);
                rtnty->Tp_Exp.Ident = ReadId(fd);
                break;
            case kTp_Any: 
#ifdef WIN32
                rtnty = (tType) my_malloc (SizeofTy);
                myread (fd, (char *)rtnty, SizeofTy );
#else
                rtnty = (tType) my_malloc (sizeof (yTp_Any));
                myread (fd, (char *)rtnty, sizeof (yTp_Any));
#endif
                rtnty->Tp_Exp.ModId = ReadId(fd);
                rtnty->Tp_Exp.Ident = ReadId(fd);
                break;
            case kTp_Base:
#ifdef WIN32
                rtnty = (tType) my_malloc (SizeofTy);
                myread (fd, (char *)rtnty, SizeofTy );
#else
                rtnty = (tType) my_malloc (sizeof (yTp_Base));
                myread (fd, (char *)rtnty, sizeof (yTp_Base));
#endif
                rtnty->Tp_Exp.ModId = ReadId(fd);
                rtnty->Tp_Exp.Ident = ReadId(fd);
                break;
            case kTp_Power:
#ifdef WIN32
                rtnty = (tType) my_malloc (SizeofTy);
                myread (fd, (char *)rtnty, SizeofTy );
#else
                rtnty = (tType) my_malloc (sizeof (yTp_Power));
                myread (fd, (char *)rtnty, sizeof (yTp_Power));
#endif
                rtnty->Tp_Exp.ModId = ReadId(fd);
                rtnty->Tp_Exp.Ident = ReadId(fd);
                break;
            case kTp_Seq:
#ifdef WIN32
                rtnty = (tType) my_malloc (SizeofTy);
                myread (fd, (char *)rtnty, SizeofTy );
#else
                rtnty = (tType) my_malloc (sizeof (yTp_Seq));
                myread (fd, (char *)rtnty, sizeof (yTp_Seq));
#endif
                rtnty->Tp_Exp.ModId = ReadId(fd);
                rtnty->Tp_Exp.Ident = ReadId(fd);
                break;
            case kTp_Prefix:
#ifdef WIN32
                rtnty = (tType) my_malloc (SizeofTy);
                myread (fd, (char *)rtnty, SizeofTy );
#else
                rtnty = (tType) my_malloc (sizeof (yTp_Prefix));
                myread (fd, (char *)rtnty, sizeof (yTp_Prefix));
#endif
                rtnty->Tp_Exp.ModId = ReadId(fd);
                rtnty->Tp_Exp.Ident = ReadId(fd);
                break;
            case kTp_Infix:
#ifdef WIN32
                rtnty = (tType) my_malloc (SizeofTy);
                myread (fd, (char *)rtnty, SizeofTy );
#else
                rtnty = (tType) my_malloc (sizeof (yTp_Infix));
                myread (fd, (char *)rtnty, sizeof (yTp_Infix));
#endif
                rtnty->Tp_Exp.ModId = ReadId(fd);
                rtnty->Tp_Exp.Ident = ReadId(fd);
                break;
            case kTp_CartProd:
#ifdef WIN32
                rtnty = (tType) my_malloc (SizeofTy);
                myread (fd, (char *)rtnty, SizeofTy );
#else
                rtnty = (tType) my_malloc (sizeof (yTp_CartProd));
                myread (fd, (char *)rtnty, sizeof (yTp_CartProd));
#endif
                rtnty->Tp_Exp.ModId = ReadId(fd);
                rtnty->Tp_Exp.Ident = ReadId(fd);
                break;
            case kTp_Schema:
#ifdef WIN32
                rtnty = (tType) my_malloc (SizeofTy);
                myread (fd, (char *)rtnty, SizeofTy );
#else
                rtnty = (tType) my_malloc (sizeof (yTp_Schema));
                myread (fd, (char *)rtnty, sizeof (yTp_Schema));
#endif
                rtnty->Tp_Exp.ModId = ReadId(fd);
                rtnty->Tp_Exp.Ident = ReadId(fd);
                break;
            default:
                break;
        }

        rtnty->Kind = ty_tag;

        /* keep a list of the type structures being allocated so that we
           can set TyNo to zero later. do it now as memory has been allocated
           but recursive calls have not been made */

        if (!allo_head) {
            allo_head = (struct ty_allo_str *) 
                            my_malloc (sizeof (struct ty_allo_str));
            allo_head->ty_addr = rtnty;
            allo_head->next = NULL;
            allo_tail = allo_head;
        }
        else {
            allo_tail->next = (struct ty_allo_str *) 
                             my_malloc (sizeof (struct ty_allo_str));
            allo_tail = allo_tail->next;
            allo_tail->ty_addr = rtnty; 
            allo_tail->next = NULL;
        }

        switch (ty_tag) {
            case kTp_Power:
                rtnty->Tp_Power.Tp_Exp = ReadType(rtnty->Tp_Power.Tp_Exp,fd); 
                break;
            case kTp_Seq:
                rtnty->Tp_Seq.Tp_Exp = ReadType(rtnty->Tp_Seq.Tp_Exp,fd); 
                break;
            case kTp_Prefix:
                rtnty->Tp_Prefix.Tp_Exp = ReadType(rtnty->Tp_Prefix.Tp_Exp,fd); 
                break;
            case kTp_Infix:
                rtnty->Tp_Infix.Fst = ReadType(rtnty->Tp_Infix.Fst,fd); 
                rtnty->Tp_Infix.Snd = ReadType(rtnty->Tp_Infix.Snd,fd); 
                break;
            case kTp_CartProd:
                if (rtnty->Tp_CartProd.Tp_CartList) {
                    tType cart=NoType;  

                    cart = (tType) my_malloc (sizeof (yTp_Cart));
                    myread (fd, (char *)cart, sizeof(yTp_Cart)); 
                    rtnty->Tp_CartProd.Tp_CartList = cart;

                    cart->Tp_Cart.Tp_Exp = ReadType (cart->Tp_Cart.Tp_Exp, fd);

                    while (cart->Tp_Cart.Next) {
                        cart->Tp_Cart.Next = 
                            (tType) my_malloc (sizeof (yTp_Cart));
                        cart = cart->Tp_Cart.Next;
                        myread (fd, (char *)cart, sizeof(yTp_Cart)); 
                        cart->Tp_Cart.Tp_Exp = ReadType (cart->Tp_Cart.Tp_Exp,fd);
                    }
                }
                break;
            case kTp_Schema:
                if (rtnty->Tp_Schema.Tp_SchFieldList) {
                    tType fld = NoType;

                    fld = (tType) my_malloc (sizeof (yTp_SchField));
                    myread (fd, (char *)fld, sizeof(yTp_SchField)); 
	/* this line added by OT */
                    fld->Tp_SchField.ModId = ReadId (fd);
	/* I think it iss missing an allocation of the ModI */
                    fld->Tp_SchField.Ident = ReadId (fd);
                    fld->Tp_SchField.Tp_Exp = ReadType (fld->Tp_SchField.Tp_Exp, fd);
                    fld->Tp_SchField.QuId = ReadId (fd);
                    rtnty->Tp_Schema.Tp_SchFieldList = fld;

                    while (fld->Tp_SchField.Next) {
                        fld->Tp_SchField.Next = 
                            (tType) my_malloc (sizeof (yTp_SchField));
                        fld = fld->Tp_SchField.Next;
                        myread (fd, (char *)fld, sizeof(yTp_SchField)); 
                        fld->Tp_SchField.ModId = ReadId (fd);
                        fld->Tp_SchField.Ident = ReadId (fd);
                        fld->Tp_SchField.Tp_Exp = ReadType (fld->Tp_SchField.Tp_Exp, fd);
                        fld->Tp_SchField.QuId = ReadId (fd);
                    }
                }
                break;
            default:
                break;
        }
    }
    else {  /* otherwise read a tyno - a pointer to a type declared elswhere */
            /* search through allo_ptr list for a type with that TyNo        */


        myread (fd, (char *)&tyno, sizeof (int)); 

        for (; allo_ptr; allo_ptr=allo_ptr->next)
            if ((allo_ptr->ty_addr)->Tp_Exp.TyNo == tyno) {
                rtnty = allo_ptr->ty_addr;
                break;
            }
        if (allo_ptr==NULL) {
            InterErr(Ierror3); 
            rtnty = ErrTy;
        }
    }
    return rtnty;
}

void VisibleH (DeclsIn, Ident, SeleList)
    tObjects DeclsIn;
    tIdPos Ident;
    tTree SeleList;
{
    tObjects sym = NoSym;
    tObjects sym_ptr=NoSym;
    tTree select=SeleList;

    /* find the named inner scope */
    /* Set Visible flag to true */
    /* if no select list then make everything visible */
    /* otherwise initialise all to unselected and */
    /*    go through select list and select them  */

    sym = LookUp(DeclsIn, Ident.Ident, NoSym);
    if (sym && sym->Kind == kObj_Inn && 
        (sym->Obj_Inn.ObjKind == Obj_module || 
         sym->Obj_Inn.ObjKind == Obj_import)) {

        sym->Obj_Inn.Visible = true;        
        sym_ptr = sym->Obj_Inn.Inner;

        if (select->Kind == kNoSelection) {
            for (; sym_ptr && sym_ptr->Kind != kNoObject;
                sym_ptr = sym_ptr->Object.Next)
                sym_ptr->Object.IsSelected = 1;
            return;
        }

        for (; sym_ptr && sym_ptr->Kind != kNoObject;
            sym_ptr = sym_ptr->Object.Next)
            sym_ptr->Object.IsSelected = 0;
            /*
            if (sym_ptr->Object.IsSelected)
                sym_ptr->Object.IsSelected = 0;
            else
                sym_ptr->Object.IsSelected = 1;
            */
        sym_ptr = sym->Obj_Inn.Inner;

        for (; select->Kind != kNoSelection; select=select->Selection.Next) {
            for (; sym_ptr && sym_ptr->Kind != kNoObject;
                    sym_ptr = sym_ptr->Object.Next)

                if (select->Selection.Ident.Ident == sym_ptr->Object.Ident) {
                    sym_ptr->Object.IsSelected = 1;
                    break;
                }
            if (sym_ptr == NoSym || sym_ptr->Kind == kNoObject)
                Error (select->Selection.Ident.Pos, error11);
        }
    }
    else 
        Error (Ident.Pos, error11);
    return;
}

     /* returns a declsin corresponding to the included schemas */

tObjects SchIncl (DeclsIn, SchTy, Pos, HTtag, QuId)
    tObjects DeclsIn;    /* scope in which schema found */
    tType SchTy;         /* type of schema */
    tPosition Pos;       /* position for error messages */
    bool HTtag;       
    tIdent QuId;         /* Qualified ID */
	/* The tag to specify returning the head or the tail of the list. */
{
    tType fldlist;
    tObjects declsin=DeclsIn;
    tObjects sym=NoSym;

    if (SchTy && (SchTy->Kind == kTp_Schema) && Type_IsType(SchTy->Tp_Schema.Tp_SchFieldList,kTp_SchField)) {
        /* for included schema, it is not checked for redeclaration. ??
        if (declsin->Kind != kObj_Inn)
            for (fldlist=SchTy->Tp_Schema.Tp_SchFieldList; fldlist;
                fldlist=fldlist->Tp_SchField.Next) 

                if (IsDeclared (declsin, fldlist->Tp_SchField.Ident, NoType)) {
                    sym = LookUp (declsin, fldlist->Tp_SchField.Ident, NoSym);
                    if (sym==NoSym)
                        InterErr(Ierror1);
                    if(!TypeStructEq (sym->Object.Type, fldlist->Tp_SchField.Tp_Exp)) {
                        Error(Pos, error34);
                        return declsin;
                    }
                }
        */

        for (fldlist=SchTy->Tp_Schema.Tp_SchFieldList; Type_IsType(fldlist,kTp_SchField);
            fldlist=fldlist->Tp_SchField.Next) {

           /*  debug  printf("PrintTy1 start\n");
              PrintTy(fldlist->Tp_SchField.Tp_Exp);
              printf("PrintTy1 end\n");  */

           if ((declsin->Kind == kObj_Inn && declsin->Obj_Inn.Inner == NoSym) ||
	     (declsin->Kind == kObj_Tmp && declsin->Obj_Tmp.Inner == NoSym)) {
                if (QuId != NoIdent) 
	 	  if (fldlist->Tp_SchField.QuId == NoIdent) {
                        /*no qualified id - use QuId*/
 
			if (declsin->Kind == kObj_Inn)
		 	 declsin->Obj_Inn.Inner = 
                          mObj_Id (NoSym, declsin, 
				fldlist->Tp_SchField.ModId,
				fldlist->Tp_SchField.Tp_Exp,
				fldlist->Tp_SchField.Ident, 1, QuId, 3);
			if (declsin->Kind == kObj_Tmp)
			 declsin->Obj_Tmp.Inner = 
                          mObj_Id (NoSym, declsin, 
				fldlist->Tp_SchField.ModId,
				fldlist->Tp_SchField.Tp_Exp,
				fldlist->Tp_SchField.Ident, 1, QuId, 3);
		  } /* a qualified id */
		  else {
			char str[IDENT_LENGTH], fldstr[IDENT_LENGTH];

			str[0] = '\0';
			GetString (QuId, str);
			GetString (fldlist->Tp_SchField.QuId, fldstr);
			strcat (str, ".");
			strcat (str, fldstr);

			if (declsin->Kind == kObj_Inn)
 			 declsin->Obj_Inn.Inner = 
                          mObj_Id (NoSym, declsin,
			   fldlist->Tp_SchField.ModId,
			   fldlist->Tp_SchField.Tp_Exp,
			   fldlist->Tp_SchField.Ident,
			   1, MakeIdent (str, strlen(str)), 3);
			if (declsin->Kind == kObj_Tmp)
			 declsin->Obj_Tmp.Inner =  
                          mObj_Id (NoSym, declsin,
			   fldlist->Tp_SchField.ModId,
			   fldlist->Tp_SchField.Tp_Exp,
			   fldlist->Tp_SchField.Ident,
			   1, MakeIdent (str, strlen(str)), 3);
			}
                else { /* no QuId use fldlist one */
                      if (declsin->Kind == kObj_Inn)
	               declsin->Obj_Inn.Inner = 
                        mObj_Id (NoSym, declsin, 
		         fldlist->Tp_SchField.ModId,
		         fldlist->Tp_SchField.Tp_Exp,
		         fldlist->Tp_SchField.Ident, 
		         1, fldlist->Tp_SchField.QuId, 3);
	              if (declsin->Kind == kObj_Tmp)
	               declsin->Obj_Tmp.Inner = 
                        mObj_Id (NoSym, declsin, 
		         fldlist->Tp_SchField.ModId,
		         fldlist->Tp_SchField.Tp_Exp,
		         fldlist->Tp_SchField.Ident, 
		         1, fldlist->Tp_SchField.QuId, 3);
		 }
	         if (declsin->Kind == kObj_Inn)
		        declsin = declsin->Obj_Inn.Inner;
	         if (declsin->Kind == kObj_Tmp)
			declsin = declsin->Obj_Tmp.Inner;
            }
            else {
               if (QuId != NoIdent) 
		if (fldlist->Tp_SchField.QuId == NoIdent) {
	 	 declsin->Object.Next = 
                  mObj_Id (NoSym, declsin, 
		   fldlist->Tp_SchField.ModId,
		   fldlist->Tp_SchField.Tp_Exp,
		   fldlist->Tp_SchField.Ident, 1, QuId, 3);
		}
		else {
		   char str[IDENT_LENGTH], fldstr[IDENT_LENGTH];

		   str[0] = '\0';
		   GetString (QuId, str);
		   GetString (fldlist->Tp_SchField.QuId, fldstr);
		   strcat (str, ".");
		   strcat (str, fldstr);

		   declsin->Object.Next = 
                    mObj_Id (NoSym, declsin, 
		     fldlist->Tp_SchField.ModId,
		     fldlist->Tp_SchField.Tp_Exp,
		     fldlist->Tp_SchField.Ident,
		     1, MakeIdent (str, strlen(str)), 3);
		}
              else {
                declsin->Object.Next = 
                 mObj_Id (NoSym, declsin, 
		   fldlist->Tp_SchField.ModId,
                   fldlist->Tp_SchField.Tp_Exp,
		   fldlist->Tp_SchField.Ident, 1,
		   fldlist->Tp_SchField.QuId, 3);
	      }
              /* debug printf("objprint2 start\n");
              ObjPrint(declsin,1);
              printf("objprint2 end\n"); */
              declsin = declsin->Object.Next;
            }
       } /* for */
    }
    if (HTtag) /* the head */
        if (declsin == DeclsIn)
            return declsin;
        else if (DeclsIn->Kind == kObj_Inn)
            return DeclsIn->Obj_Inn.Inner;
        else return DeclsIn->Object.Next;
    else /* tail */
        return declsin; 
} /*SchIncl*/

tObjects SchInclD(DeclsIn, SchTy, Strokes, Pos, HTtag, QuId)
    tObjects DeclsIn;
    tType SchTy;
    char *Strokes;
    tPosition Pos;
    bool HTtag;  
    tIdent QuId;
        /* The tag to specify returning the head or the tail of the list. */
{
    tType fldlist;
    tObjects declsin=DeclsIn;
    tObjects sym=NoSym;
    char *str;

    str = (char *) my_malloc (IDENT_LENGTH);
    if (SchTy && (SchTy->Kind == kTp_Schema) && Type_IsType(SchTy->Tp_Schema.Tp_SchFieldList,kTp_SchField)) {
        /* for included schema, it is not checked for redeclaration. ??
        if (declsin->Kind != kObj_Inn)
            for (fldlist=SchTy->Tp_Schema.Tp_SchFieldList; Type_IsType(fldlist,kSchField);
                fldlist=fldlist->Tp_SchField.Next) {

                str[0] = '\0';
                GetString (fldlist->Tp_SchField.Ident, str);
                strcat (str, Strokes);
                if (IsDeclared (declsin, MakeIdent(str, strlen(str)), NoType)) {
                    sym = LookUp (declsin, MakeIdent(str, strlen(str)), NoSym);
                    if (sym==NoSym)
                        InterErr(Ierror1);
                    if(!TypeStructEq (sym->Object.Type, fldlist->Tp_SchField.Tp_Exp)) {
                        Error(Pos, error34);
                        return declsin;
                    }
                }
            }
        */

        for (fldlist=SchTy->Tp_Schema.Tp_SchFieldList; Type_IsType(fldlist,kTp_SchField);
           fldlist=fldlist->Tp_SchField.Next) {

           str[0] = '\0';
           GetString (fldlist->Tp_SchField.Ident, str);
           strcat (str, Strokes);
           if ((declsin->Kind == kObj_Inn && declsin->Obj_Inn.Inner == NoSym) ||
	       (declsin->Kind == kObj_Tmp && declsin->Obj_Tmp.Inner == NoSym)) {
                if (QuId != NoIdent) 
	 	  if (fldlist->Tp_SchField.QuId == NoIdent) {
		    if (declsin->Kind == kObj_Inn)
			declsin->Obj_Inn.Inner = 
                         mObj_Id (NoSym, declsin, 
			   fldlist->Tp_SchField.ModId,
			   fldlist->Tp_SchField.Tp_Exp, 
			   MakeIdent(str, strlen(str)), 1, QuId, 3);
		    if (declsin->Kind == kObj_Tmp)
			declsin->Obj_Tmp.Inner = 
                         mObj_Id (NoSym, declsin, 
			   fldlist->Tp_SchField.ModId,
			   fldlist->Tp_SchField.Tp_Exp, 
			   MakeIdent(str, strlen(str)), 1, QuId, 3);
		  }
		  else {
		    char str[IDENT_LENGTH], fldstr[IDENT_LENGTH];

		    str[0] = '\0';
		    GetString (QuId, str);
		    GetString (fldlist->Tp_SchField.QuId, fldstr);
		    strcat (str, ".");
		    strcat (str, fldstr);

		    if (declsin->Kind == kObj_Inn)
			declsin->Obj_Inn.Inner = 
                         mObj_Id (NoSym, declsin, 
			   fldlist->Tp_SchField.ModId,
			   fldlist->Tp_SchField.Tp_Exp, 
			   MakeIdent(str, strlen(str)), 1,
			   MakeIdent (str, strlen(str)), 3);
		    if (declsin->Kind == kObj_Tmp)
			declsin->Obj_Tmp.Inner = 
                         mObj_Id (NoSym, declsin, 
			   fldlist->Tp_SchField.ModId,
			   fldlist->Tp_SchField.Tp_Exp, 
			   MakeIdent(str, strlen(str)), 1,
			   MakeIdent (str, strlen(str)), 3);
		  }
                else {
		  if (declsin->Kind == kObj_Inn)
		      declsin->Obj_Inn.Inner = 
                       mObj_Id (NoSym, declsin, 
		         fldlist->Tp_SchField.ModId,
			 fldlist->Tp_SchField.Tp_Exp, 
			 MakeIdent(str, strlen(str)), 1, 
			 fldlist->Tp_SchField.QuId, 3);
		  if (declsin->Kind == kObj_Tmp)
		      declsin->Obj_Tmp.Inner = 
                       mObj_Id (NoSym, declsin, 
			 fldlist->Tp_SchField.ModId,
			 fldlist->Tp_SchField.Tp_Exp, 
			 MakeIdent(str, strlen(str)), 1, 
			 fldlist->Tp_SchField.QuId, 3);
	        }
	   if (declsin->Kind == kObj_Inn)
		declsin = declsin->Obj_Inn.Inner;
	   if (declsin->Kind == kObj_Tmp)
		declsin = declsin->Obj_Tmp.Inner;
        }
        else {
           if (QuId != NoIdent)
	      if (fldlist->Tp_SchField.QuId == NoIdent) {
		declsin->Object.Next = 
                 mObj_Id (NoSym, declsin,
		fldlist->Tp_SchField.ModId,
		fldlist->Tp_SchField.Tp_Exp,
		MakeIdent(str, strlen(str)), 1, QuId, 3);
	}
	else {
		char str[IDENT_LENGTH], fldstr[IDENT_LENGTH];

		str[0] = '\0';
		GetString (QuId, str);
		GetString (fldlist->Tp_SchField.QuId, fldstr);
		strcat (str, ".");
		strcat (str, fldstr);

		declsin->Object.Next = mObj_Id (NoSym, declsin, 
			fldlist->Tp_SchField.ModId,
			fldlist->Tp_SchField.Tp_Exp,
			fldlist->Tp_SchField.Ident,
			1, MakeIdent (str, strlen(str)), 3);
	}
        else {
            declsin->Object.Next = mObj_Id (NoSym, declsin, 
			fldlist->Tp_SchField.ModId,
                       fldlist->Tp_SchField.Tp_Exp, 
			MakeIdent(str, strlen(str)), 1, 
			fldlist->Tp_SchField.QuId, 3);
	}
        declsin = declsin->Object.Next;
       }
      }
    }
    if (HTtag) /* the head */
        if (declsin == DeclsIn)
            return declsin;
        else
            return DeclsIn->Object.Next;
    else /* tail */
        return declsin; 
} /*SchInclD*/

/* This is to check if the module name appeared as a new name in an 
 * import-as statement. If this is the case, the translating it into
 * Ergo would have a different subtheory name instead.
 */
tIdent ImportAsMod (ModId)
	tIdent ModId;
{
	IML_List iml;
		 
	for (iml=cur_mod_imllist_hd; iml != NULL; iml=iml->next) {
		if (ModId == MakeIdent (iml->subthyid, strlen(iml->subthyid)))
			return iml->ParentModId;
	}
	return NoIdent;
} 



static void yyExit () { Exit (1); }

void (* Syms_Exit) () = yyExit;

# define yyBlockSize 20480

typedef struct yysBlock {
 char yyBlock [yyBlockSize];
 struct yysBlock * yySuccessor;
} yytBlock, * yytBlockPtr;

tSyms SymsRoot;
unsigned long Syms_HeapUsed = 0;

static yytBlockPtr yyBlockList	= (yytBlockPtr) NoSyms;
char * Syms_PoolFreePtr	= (char *) NoSyms;
char * Syms_PoolMaxPtr	= (char *) NoSyms;
static unsigned short yyMaxSize	= 0;
unsigned short Syms_NodeSize [10 + 1] = { 0,
 sizeof (yObjects),
 sizeof (yNoObject),
 sizeof (yObject),
 sizeof (yObj_Inn),
 sizeof (yObj_TyId),
 sizeof (yObj_Id),
 sizeof (yObj_Tmp),
 sizeof (yObj_Param),
 sizeof (yObj_PTyId),
 sizeof (yObj_PId),
};
char * Syms_NodeName [10 + 1] = {
 "NoSyms",
 "Objects",
 "NoObject",
 "Object",
 "Obj_Inn",
 "Obj_TyId",
 "Obj_Id",
 "Obj_Tmp",
 "Obj_Param",
 "Obj_PTyId",
 "Obj_PId",
};
static Syms_tKind yyTypeRange [10 + 1] = { 0,
 kObj_PId,
 kNoObject,
 kObj_PId,
 kObj_Inn,
 kObj_TyId,
 kObj_Id,
 kObj_Tmp,
 kObj_PId,
 kObj_PTyId,
 kObj_PId,
};

tSyms Syms_Alloc ()
{
 register yytBlockPtr yyBlockPtr = yyBlockList;
 register int i;

 if (yyMaxSize == 0)
  for (i = 1; i <= 10; i ++) {
   Syms_NodeSize [i] = (Syms_NodeSize [i] + yyMaxAlign - 1) & yyAlignMasks [yyMaxAlign];
   yyMaxSize = Max (Syms_NodeSize [i], yyMaxSize);
  }
 yyBlockList = (yytBlockPtr) Alloc (sizeof (yytBlock));
 yyBlockList->yySuccessor = yyBlockPtr;
 Syms_PoolFreePtr = yyBlockList->yyBlock;
 Syms_PoolMaxPtr = Syms_PoolFreePtr + yyBlockSize - yyMaxSize + 1;
 Syms_HeapUsed += yyBlockSize;
 return (tSyms) Syms_PoolFreePtr;
}

tSyms MakeSyms
# if defined __STDC__ | defined __cplusplus
 (Syms_tKind yyKind)
# else
 (yyKind) Syms_tKind yyKind;
# endif
{
 register tSyms yyt;
 yyALLOC (yyt, Syms_NodeSize [yyKind])
 yyt->Kind = yyKind;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

bool Syms_IsType
# if defined __STDC__ | defined __cplusplus
 (register tSyms yyt, register Syms_tKind yyKind)
# else
 (yyt, yyKind) register tSyms yyt; register Syms_tKind yyKind;
# endif
{
 return yyt != NoSyms && yyKind <= yyt->Kind && yyt->Kind <= yyTypeRange [yyKind];
}


tSyms mObjects
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tSyms yyt;
 yyALLOC (yyt, Syms_NodeSize [kObjects])
 yyt->Kind = kObjects;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tSyms mNoObject
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tSyms yyt;
 yyALLOC (yyt, Syms_NodeSize [kNoObject])
 yyt->Kind = kNoObject;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tSyms mObject
# if defined __STDC__ | defined __cplusplus
(tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected)
# else
(pNext, pPre, pModId, pType, pIdent, pIsSelected)
tSyms pNext;
tSyms pPre;
tIdent pModId;
tType pType;
tIdent pIdent;
bool pIsSelected;
# endif
{
 register tSyms yyt;
 yyALLOC (yyt, Syms_NodeSize [kObject])
 yyt->Kind = kObject;
 yyt->yyHead.yyMark = 0;
 yyt->Object.Next = pNext;
 yyt->Object.Pre = pPre;
 yyt->Object.ModId = pModId;
 yyt->Object.Type = pType;
 yyt->Object.Ident = pIdent;
 yyt->Object.IsSelected = pIsSelected;
 beginbool(yyt->Object.Tag)
 return yyt;
}

tSyms mObj_Inn
# if defined __STDC__ | defined __cplusplus
(tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected, tSyms pInner, int pObjKind, bool pVisible)
# else
(pNext, pPre, pModId, pType, pIdent, pIsSelected, pInner, pObjKind, pVisible)
tSyms pNext;
tSyms pPre;
tIdent pModId;
tType pType;
tIdent pIdent;
bool pIsSelected;
tSyms pInner;
int pObjKind;
bool pVisible;
# endif
{
 register tSyms yyt;
 yyALLOC (yyt, Syms_NodeSize [kObj_Inn])
 yyt->Kind = kObj_Inn;
 yyt->yyHead.yyMark = 0;
 yyt->Obj_Inn.Next = pNext;
 yyt->Obj_Inn.Pre = pPre;
 yyt->Obj_Inn.ModId = pModId;
 yyt->Obj_Inn.Type = pType;
 yyt->Obj_Inn.Ident = pIdent;
 yyt->Obj_Inn.IsSelected = pIsSelected;
 beginbool(yyt->Obj_Inn.Tag)
 yyt->Obj_Inn.Inner = pInner;
 yyt->Obj_Inn.ObjKind = pObjKind;
 yyt->Obj_Inn.Visible = pVisible;
 beginbool(yyt->Obj_Inn.ImportHasAsPart)
 return yyt;
}

tSyms mObj_TyId
# if defined __STDC__ | defined __cplusplus
(tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected)
# else
(pNext, pPre, pModId, pType, pIdent, pIsSelected)
tSyms pNext;
tSyms pPre;
tIdent pModId;
tType pType;
tIdent pIdent;
bool pIsSelected;
# endif
{
 register tSyms yyt;
 yyALLOC (yyt, Syms_NodeSize [kObj_TyId])
 yyt->Kind = kObj_TyId;
 yyt->yyHead.yyMark = 0;
 yyt->Obj_TyId.Next = pNext;
 yyt->Obj_TyId.Pre = pPre;
 yyt->Obj_TyId.ModId = pModId;
 yyt->Obj_TyId.Type = pType;
 yyt->Obj_TyId.Ident = pIdent;
 yyt->Obj_TyId.IsSelected = pIsSelected;
 beginbool(yyt->Obj_TyId.Tag)
 return yyt;
}

tSyms mObj_Id
# if defined __STDC__ | defined __cplusplus
(tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected, tIdent pQuId, int pVarKind)
# else
(pNext, pPre, pModId, pType, pIdent, pIsSelected, pQuId, pVarKind)
tSyms pNext;
tSyms pPre;
tIdent pModId;
tType pType;
tIdent pIdent;
bool pIsSelected;
tIdent pQuId;
int pVarKind;
# endif
{
 register tSyms yyt;
 yyALLOC (yyt, Syms_NodeSize [kObj_Id])
 yyt->Kind = kObj_Id;
 yyt->yyHead.yyMark = 0;
 yyt->Obj_Id.Next = pNext;
 yyt->Obj_Id.Pre = pPre;
 yyt->Obj_Id.ModId = pModId;
 yyt->Obj_Id.Type = pType;
 yyt->Obj_Id.Ident = pIdent;
 yyt->Obj_Id.IsSelected = pIsSelected;
 beginbool(yyt->Obj_Id.Tag)
 yyt->Obj_Id.QuId = pQuId;
 yyt->Obj_Id.VarKind = pVarKind;
 return yyt;
}

tSyms mObj_Tmp
# if defined __STDC__ | defined __cplusplus
(tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected, tSyms pInner)
# else
(pNext, pPre, pModId, pType, pIdent, pIsSelected, pInner)
tSyms pNext;
tSyms pPre;
tIdent pModId;
tType pType;
tIdent pIdent;
bool pIsSelected;
tSyms pInner;
# endif
{
 register tSyms yyt;
 yyALLOC (yyt, Syms_NodeSize [kObj_Tmp])
 yyt->Kind = kObj_Tmp;
 yyt->yyHead.yyMark = 0;
 yyt->Obj_Tmp.Next = pNext;
 yyt->Obj_Tmp.Pre = pPre;
 yyt->Obj_Tmp.ModId = pModId;
 yyt->Obj_Tmp.Type = pType;
 yyt->Obj_Tmp.Ident = pIdent;
 yyt->Obj_Tmp.IsSelected = pIsSelected;
 beginbool(yyt->Obj_Tmp.Tag)
 yyt->Obj_Tmp.Inner = pInner;
 return yyt;
}

tSyms mObj_Param
# if defined __STDC__ | defined __cplusplus
(tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected)
# else
(pNext, pPre, pModId, pType, pIdent, pIsSelected)
tSyms pNext;
tSyms pPre;
tIdent pModId;
tType pType;
tIdent pIdent;
bool pIsSelected;
# endif
{
 register tSyms yyt;
 yyALLOC (yyt, Syms_NodeSize [kObj_Param])
 yyt->Kind = kObj_Param;
 yyt->yyHead.yyMark = 0;
 yyt->Obj_Param.Next = pNext;
 yyt->Obj_Param.Pre = pPre;
 yyt->Obj_Param.ModId = pModId;
 yyt->Obj_Param.Type = pType;
 yyt->Obj_Param.Ident = pIdent;
 yyt->Obj_Param.IsSelected = pIsSelected;
 beginbool(yyt->Obj_Param.Tag)
 return yyt;
}

tSyms mObj_PTyId
# if defined __STDC__ | defined __cplusplus
(tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected)
# else
(pNext, pPre, pModId, pType, pIdent, pIsSelected)
tSyms pNext;
tSyms pPre;
tIdent pModId;
tType pType;
tIdent pIdent;
bool pIsSelected;
# endif
{
 register tSyms yyt;
 yyALLOC (yyt, Syms_NodeSize [kObj_PTyId])
 yyt->Kind = kObj_PTyId;
 yyt->yyHead.yyMark = 0;
 yyt->Obj_PTyId.Next = pNext;
 yyt->Obj_PTyId.Pre = pPre;
 yyt->Obj_PTyId.ModId = pModId;
 yyt->Obj_PTyId.Type = pType;
 yyt->Obj_PTyId.Ident = pIdent;
 yyt->Obj_PTyId.IsSelected = pIsSelected;
 beginbool(yyt->Obj_PTyId.Tag)
 return yyt;
}

tSyms mObj_PId
# if defined __STDC__ | defined __cplusplus
(tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected)
# else
(pNext, pPre, pModId, pType, pIdent, pIsSelected)
tSyms pNext;
tSyms pPre;
tIdent pModId;
tType pType;
tIdent pIdent;
bool pIsSelected;
# endif
{
 register tSyms yyt;
 yyALLOC (yyt, Syms_NodeSize [kObj_PId])
 yyt->Kind = kObj_PId;
 yyt->yyHead.yyMark = 0;
 yyt->Obj_PId.Next = pNext;
 yyt->Obj_PId.Pre = pPre;
 yyt->Obj_PId.ModId = pModId;
 yyt->Obj_PId.Type = pType;
 yyt->Obj_PId.Ident = pIdent;
 yyt->Obj_PId.IsSelected = pIsSelected;
 beginbool(yyt->Obj_PId.Tag)
 return yyt;
}

typedef tSyms * yyPtrtTree;

static FILE * yyf;

static void yyMark
# if defined __STDC__ | defined __cplusplus
 (register tSyms yyt)
# else
 (yyt) register tSyms yyt;
# endif
{
 for (;;) {
  if (yyt == NoSyms || ++ yyt->yyHead.yyMark > 1) return;

  switch (yyt->Kind) {
case kObject:
yyMark (yyt->Object.Next);
yyt = yyt->Object.Pre; break;
case kObj_Inn:
yyMark (yyt->Obj_Inn.Next);
yyMark (yyt->Obj_Inn.Pre);
yyt = yyt->Obj_Inn.Inner; break;
case kObj_TyId:
yyMark (yyt->Obj_TyId.Next);
yyt = yyt->Obj_TyId.Pre; break;
case kObj_Id:
yyMark (yyt->Obj_Id.Next);
yyt = yyt->Obj_Id.Pre; break;
case kObj_Tmp:
yyMark (yyt->Obj_Tmp.Next);
yyMark (yyt->Obj_Tmp.Pre);
yyt = yyt->Obj_Tmp.Inner; break;
case kObj_Param:
yyMark (yyt->Obj_Param.Next);
yyt = yyt->Obj_Param.Pre; break;
case kObj_PTyId:
yyMark (yyt->Obj_PTyId.Next);
yyt = yyt->Obj_PTyId.Pre; break;
case kObj_PId:
yyMark (yyt->Obj_PId.Next);
yyt = yyt->Obj_PId.Pre; break;
  default: return;
  }
 }
}

# define yyInitTreeStoreSize 32
# define yyMapToTree(yyLabel) yyTreeStorePtr [yyLabel]

static unsigned long yyTreeStoreSize = yyInitTreeStoreSize;
static tSyms yyTreeStore [yyInitTreeStoreSize];
static tSyms * yyTreeStorePtr = yyTreeStore;
static int yyLabelCount;
static short yyRecursionLevel = 0;

static Syms_tLabel yyMapToLabel
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyLabelCount; yyi ++) if (yyTreeStorePtr [yyi] == yyt) return yyi;
 if (++ yyLabelCount == yyTreeStoreSize)
  ExtendArray ((char * *) & yyTreeStorePtr, & yyTreeStoreSize, sizeof (tSyms));
 yyTreeStorePtr [yyLabelCount] = yyt;
 return yyLabelCount;
}

static void yyWriteSyms ();

static void yyWriteNl () { (void) putc ('\n', yyf); }

static void yyWriteSelector
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyi = 16 - strlen (yys);
 (void) fputs (yys, yyf);
 while (yyi -- > 0) (void) putc (' ', yyf);
 (void) fputs (" = ", yyf);
}

static void yyWriteHex
# if defined __STDC__ | defined __cplusplus
 (unsigned char * yyx, int yysize)
# else
 (yyx, yysize) unsigned char * yyx; int yysize;
# endif
{ register int yyi; for (yyi = 0; yyi < yysize; yyi ++) (void) fprintf (yyf, "%02x ", yyx [yyi]); }

static short yyIndentLevel;

void WriteSyms
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf, tSyms yyt)
# else
 (yyyf, yyt) FILE * yyyf; tSyms yyt;
# endif
{
 short yySaveLevel = yyIndentLevel;
 yyf = yyyf;
 if (yyRecursionLevel ++ == 0) yyLabelCount = 0;
 yyMark (yyt);
 yyIndentLevel = 0;
 yyWriteSyms (yyt);
 yyIndentLevel = yySaveLevel;
 yyRecursionLevel --;
}

static void yyIndentSelector
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyIndentLevel; yyi ++) (void) putc (' ', yyf);
 yyWriteSelector (yys);
}

static void yyIndentSelectorTree
# if defined __STDC__ | defined __cplusplus
 (char * yys, tSyms yyt)
# else
 (yys, yyt) char * yys; tSyms yyt;
# endif
{ yyIndentSelector (yys); writetSyms (yyt) }

static void yWriteObject
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{
 (void) fputs (Syms_NodeName [kObject], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Next", yyt->Object.Next);
 yyIndentSelector ("ModId"); writetIdent (yyt->Object.ModId) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Object.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Object.Ident) yyWriteNl ();
 yyIndentSelector ("IsSelected"); writebool (yyt->Object.IsSelected) yyWriteNl ();
 yyIndentSelector ("Tag"); writebool (yyt->Object.Tag) yyWriteNl ();
}

static void yWriteObj_Inn
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{
 (void) fputs (Syms_NodeName [kObj_Inn], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Next", yyt->Obj_Inn.Next);
 yyIndentSelectorTree ("Pre", yyt->Obj_Inn.Pre);
 yyIndentSelector ("ModId"); writetIdent (yyt->Obj_Inn.ModId) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Obj_Inn.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Obj_Inn.Ident) yyWriteNl ();
 yyIndentSelector ("IsSelected"); writebool (yyt->Obj_Inn.IsSelected) yyWriteNl ();
 yyIndentSelector ("Tag"); writebool (yyt->Obj_Inn.Tag) yyWriteNl ();
 yyIndentSelector ("ObjKind"); writeint (yyt->Obj_Inn.ObjKind) yyWriteNl ();
 yyIndentSelector ("Visible"); writebool (yyt->Obj_Inn.Visible) yyWriteNl ();
 yyIndentSelector ("ImportHasAsPart"); writebool (yyt->Obj_Inn.ImportHasAsPart) yyWriteNl ();
}

static void yWriteObj_TyId
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{
 (void) fputs (Syms_NodeName [kObj_TyId], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Next", yyt->Obj_TyId.Next);
 yyIndentSelector ("ModId"); writetIdent (yyt->Obj_TyId.ModId) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Obj_TyId.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Obj_TyId.Ident) yyWriteNl ();
 yyIndentSelector ("IsSelected"); writebool (yyt->Obj_TyId.IsSelected) yyWriteNl ();
 yyIndentSelector ("Tag"); writebool (yyt->Obj_TyId.Tag) yyWriteNl ();
}

static void yWriteObj_Id
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{
 (void) fputs (Syms_NodeName [kObj_Id], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Next", yyt->Obj_Id.Next);
 yyIndentSelector ("ModId"); writetIdent (yyt->Obj_Id.ModId) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Obj_Id.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Obj_Id.Ident) yyWriteNl ();
 yyIndentSelector ("IsSelected"); writebool (yyt->Obj_Id.IsSelected) yyWriteNl ();
 yyIndentSelector ("Tag"); writebool (yyt->Obj_Id.Tag) yyWriteNl ();
 yyIndentSelector ("QuId"); writetIdent (yyt->Obj_Id.QuId) yyWriteNl ();
 yyIndentSelector ("VarKind"); writeint (yyt->Obj_Id.VarKind) yyWriteNl ();
}

static void yWriteObj_Tmp
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{
 (void) fputs (Syms_NodeName [kObj_Tmp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Next", yyt->Obj_Tmp.Next);
 yyIndentSelectorTree ("Pre", yyt->Obj_Tmp.Pre);
 yyIndentSelector ("ModId"); writetIdent (yyt->Obj_Tmp.ModId) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Obj_Tmp.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Obj_Tmp.Ident) yyWriteNl ();
 yyIndentSelector ("IsSelected"); writebool (yyt->Obj_Tmp.IsSelected) yyWriteNl ();
 yyIndentSelector ("Tag"); writebool (yyt->Obj_Tmp.Tag) yyWriteNl ();
}

static void yWriteObj_Param
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{
 (void) fputs (Syms_NodeName [kObj_Param], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Next", yyt->Obj_Param.Next);
 yyIndentSelector ("ModId"); writetIdent (yyt->Obj_Param.ModId) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Obj_Param.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Obj_Param.Ident) yyWriteNl ();
 yyIndentSelector ("IsSelected"); writebool (yyt->Obj_Param.IsSelected) yyWriteNl ();
 yyIndentSelector ("Tag"); writebool (yyt->Obj_Param.Tag) yyWriteNl ();
}

static void yWriteObj_PTyId
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{
 (void) fputs (Syms_NodeName [kObj_PTyId], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Next", yyt->Obj_PTyId.Next);
 yyIndentSelector ("ModId"); writetIdent (yyt->Obj_PTyId.ModId) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Obj_PTyId.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Obj_PTyId.Ident) yyWriteNl ();
 yyIndentSelector ("IsSelected"); writebool (yyt->Obj_PTyId.IsSelected) yyWriteNl ();
 yyIndentSelector ("Tag"); writebool (yyt->Obj_PTyId.Tag) yyWriteNl ();
}

static void yWriteObj_PId
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{
 (void) fputs (Syms_NodeName [kObj_PId], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Next", yyt->Obj_PId.Next);
 yyIndentSelector ("ModId"); writetIdent (yyt->Obj_PId.ModId) yyWriteNl ();
 yyIndentSelector ("Type"); writetType (yyt->Obj_PId.Type) yyWriteNl ();
 yyIndentSelector ("Ident"); writetIdent (yyt->Obj_PId.Ident) yyWriteNl ();
 yyIndentSelector ("IsSelected"); writebool (yyt->Obj_PId.IsSelected) yyWriteNl ();
 yyIndentSelector ("Tag"); writebool (yyt->Obj_PId.Tag) yyWriteNl ();
}

static void yyWriteSyms
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{ unsigned short yyLevel = yyIndentLevel;
 for (;;) {
  if (yyt == NoSyms) { (void) fputs (" NoSyms\n", yyf); goto yyExit;
  } else if (yyt->yyHead.yyMark == 0) { (void) fprintf (yyf, "^%d\n", yyMapToLabel (yyt)); goto yyExit;
  } else if (yyt->yyHead.yyMark > 1) {
   register int yyi;
   (void) fprintf (yyf, "\n%06d:", yyMapToLabel (yyt));
   for (yyi = 8; yyi <= yyIndentLevel; yyi ++) (void) putc (' ', yyf);
  } else (void) putc (' ', yyf);
  yyt->yyHead.yyMark = 0;
  yyIndentLevel += 2;

  switch (yyt->Kind) {
case kObjects: (void) fputs (Syms_NodeName [kObjects], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kNoObject: (void) fputs (Syms_NodeName [kNoObject], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kObject: yWriteObject (yyt); yyIndentSelector ("Pre"); yyt = yyt->Object.Pre; break;
case kObj_Inn: yWriteObj_Inn (yyt); yyIndentSelector ("Inner"); yyt = yyt->Obj_Inn.Inner; break;
case kObj_TyId: yWriteObj_TyId (yyt); yyIndentSelector ("Pre"); yyt = yyt->Obj_TyId.Pre; break;
case kObj_Id: yWriteObj_Id (yyt); yyIndentSelector ("Pre"); yyt = yyt->Obj_Id.Pre; break;
case kObj_Tmp: yWriteObj_Tmp (yyt); yyIndentSelector ("Inner"); yyt = yyt->Obj_Tmp.Inner; break;
case kObj_Param: yWriteObj_Param (yyt); yyIndentSelector ("Pre"); yyt = yyt->Obj_Param.Pre; break;
case kObj_PTyId: yWriteObj_PTyId (yyt); yyIndentSelector ("Pre"); yyt = yyt->Obj_PTyId.Pre; break;
case kObj_PId: yWriteObj_PId (yyt); yyIndentSelector ("Pre"); yyt = yyt->Obj_PId.Pre; break;
  default: goto yyExit;
  }
 }
yyExit:
 yyIndentLevel = yyLevel;
}

# define yyNil	0374
# define yyNoLabel	0375
# define yyLabelDef	0376
# define yyLabelUse	0377

static Syms_tProcTree yyProc;

static void yyTraverseSymsTD
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{
 for (;;) {
  if (yyt == NoSyms || yyt->yyHead.yyMark == 0) return;
  yyt->yyHead.yyMark = 0;
  yyProc (yyt);

  switch (yyt->Kind) {
case kObject:
yyTraverseSymsTD (yyt->Object.Next);
yyt = yyt->Object.Pre; break;
case kObj_Inn:
yyTraverseSymsTD (yyt->Obj_Inn.Next);
yyTraverseSymsTD (yyt->Obj_Inn.Pre);
yyt = yyt->Obj_Inn.Inner; break;
case kObj_TyId:
yyTraverseSymsTD (yyt->Obj_TyId.Next);
yyt = yyt->Obj_TyId.Pre; break;
case kObj_Id:
yyTraverseSymsTD (yyt->Obj_Id.Next);
yyt = yyt->Obj_Id.Pre; break;
case kObj_Tmp:
yyTraverseSymsTD (yyt->Obj_Tmp.Next);
yyTraverseSymsTD (yyt->Obj_Tmp.Pre);
yyt = yyt->Obj_Tmp.Inner; break;
case kObj_Param:
yyTraverseSymsTD (yyt->Obj_Param.Next);
yyt = yyt->Obj_Param.Pre; break;
case kObj_PTyId:
yyTraverseSymsTD (yyt->Obj_PTyId.Next);
yyt = yyt->Obj_PTyId.Pre; break;
case kObj_PId:
yyTraverseSymsTD (yyt->Obj_PId.Next);
yyt = yyt->Obj_PId.Pre; break;
  default: return;
  }
 }
}

void TraverseSymsTD
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt, Syms_tProcTree yyyProc)
# else
 (yyt, yyyProc) tSyms yyt; Syms_tProcTree yyyProc;
# endif
{
 yyMark (yyt);
 yyProc = yyyProc;
 yyTraverseSymsTD (yyt);
}

tSyms ReverseSyms
# if defined __STDC__ | defined __cplusplus
 (tSyms yyOld)
# else
 (yyOld) tSyms yyOld;
# endif
{
 register tSyms yyNew, yyNext, yyTail;
 yyNew = yyOld;
 yyTail = yyOld;
 for (;;) {
  switch (yyOld->Kind) {
  default: goto yyExit;
  }
  yyNew = yyOld;
  yyOld = yyNext;
 }
yyExit:
 switch (yyTail->Kind) {
 default: ;
 }
 return yyNew;
}

# define yyInitOldToNewStoreSize 32

typedef struct { tSyms yyOld, yyNew; } yytOldToNew;
static unsigned long yyOldToNewStoreSize = yyInitOldToNewStoreSize;
static yytOldToNew yyOldToNewStore [yyInitOldToNewStoreSize];
static yytOldToNew * yyOldToNewStorePtr = yyOldToNewStore;
static int yyOldToNewCount;

static void yyStoreOldToNew
# if defined __STDC__ | defined __cplusplus
 (tSyms yyOld, tSyms yyNew)
# else
 (yyOld, yyNew) tSyms yyOld, yyNew;
# endif
{
 if (++ yyOldToNewCount == yyOldToNewStoreSize)
  ExtendArray ((char * *) & yyOldToNewStorePtr, & yyOldToNewStoreSize, sizeof (yytOldToNew));
 yyOldToNewStorePtr [yyOldToNewCount].yyOld = yyOld;
 yyOldToNewStorePtr [yyOldToNewCount].yyNew = yyNew;
}

static tSyms yyMapOldToNew
# if defined __STDC__ | defined __cplusplus
 (tSyms yyOld)
# else
 (yyOld) tSyms yyOld;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyOldToNewCount; yyi ++)
  if (yyOldToNewStorePtr [yyi].yyOld == yyOld) return yyOldToNewStorePtr [yyi].yyNew;
}

static tSyms yyCopySyms
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt, yyPtrtTree yyNew)
# else
 (yyt, yyNew) tSyms yyt; yyPtrtTree yyNew;
# endif
{
 for (;;) {
  if (yyt == NoSyms) { * yyNew = NoSyms; return; }
  if (yyt->yyHead.yyMark == 0) { * yyNew = yyMapOldToNew (yyt); return; }
  yyALLOC (* yyNew, Syms_NodeSize [yyt->Kind])
  if (yyt->yyHead.yyMark > 1) { yyStoreOldToNew (yyt, * yyNew); }
  yyt->yyHead.yyMark = 0;

  switch (yyt->Kind) {
case kObjects: (* yyNew)->Objects = yyt->Objects;
return;
case kNoObject: (* yyNew)->NoObject = yyt->NoObject;
return;
case kObject: (* yyNew)->Object = yyt->Object;
copytSyms ((* yyNew)->Object.Next, yyt->Object.Next)
copytIdent ((* yyNew)->Object.ModId, yyt->Object.ModId)
copytType ((* yyNew)->Object.Type, yyt->Object.Type)
copytIdent ((* yyNew)->Object.Ident, yyt->Object.Ident)
copybool ((* yyNew)->Object.IsSelected, yyt->Object.IsSelected)
copybool ((* yyNew)->Object.Tag, yyt->Object.Tag)
yyt = yyt->Object.Pre;
yyNew = & (* yyNew)->Object.Pre; break;
case kObj_Inn: (* yyNew)->Obj_Inn = yyt->Obj_Inn;
copytSyms ((* yyNew)->Obj_Inn.Next, yyt->Obj_Inn.Next)
copytSyms ((* yyNew)->Obj_Inn.Pre, yyt->Obj_Inn.Pre)
copytIdent ((* yyNew)->Obj_Inn.ModId, yyt->Obj_Inn.ModId)
copytType ((* yyNew)->Obj_Inn.Type, yyt->Obj_Inn.Type)
copytIdent ((* yyNew)->Obj_Inn.Ident, yyt->Obj_Inn.Ident)
copybool ((* yyNew)->Obj_Inn.IsSelected, yyt->Obj_Inn.IsSelected)
copybool ((* yyNew)->Obj_Inn.Tag, yyt->Obj_Inn.Tag)
copyint ((* yyNew)->Obj_Inn.ObjKind, yyt->Obj_Inn.ObjKind)
copybool ((* yyNew)->Obj_Inn.Visible, yyt->Obj_Inn.Visible)
copybool ((* yyNew)->Obj_Inn.ImportHasAsPart, yyt->Obj_Inn.ImportHasAsPart)
yyt = yyt->Obj_Inn.Inner;
yyNew = & (* yyNew)->Obj_Inn.Inner; break;
case kObj_TyId: (* yyNew)->Obj_TyId = yyt->Obj_TyId;
copytSyms ((* yyNew)->Obj_TyId.Next, yyt->Obj_TyId.Next)
copytIdent ((* yyNew)->Obj_TyId.ModId, yyt->Obj_TyId.ModId)
copytType ((* yyNew)->Obj_TyId.Type, yyt->Obj_TyId.Type)
copytIdent ((* yyNew)->Obj_TyId.Ident, yyt->Obj_TyId.Ident)
copybool ((* yyNew)->Obj_TyId.IsSelected, yyt->Obj_TyId.IsSelected)
copybool ((* yyNew)->Obj_TyId.Tag, yyt->Obj_TyId.Tag)
yyt = yyt->Obj_TyId.Pre;
yyNew = & (* yyNew)->Obj_TyId.Pre; break;
case kObj_Id: (* yyNew)->Obj_Id = yyt->Obj_Id;
copytSyms ((* yyNew)->Obj_Id.Next, yyt->Obj_Id.Next)
copytIdent ((* yyNew)->Obj_Id.ModId, yyt->Obj_Id.ModId)
copytType ((* yyNew)->Obj_Id.Type, yyt->Obj_Id.Type)
copytIdent ((* yyNew)->Obj_Id.Ident, yyt->Obj_Id.Ident)
copybool ((* yyNew)->Obj_Id.IsSelected, yyt->Obj_Id.IsSelected)
copybool ((* yyNew)->Obj_Id.Tag, yyt->Obj_Id.Tag)
copytIdent ((* yyNew)->Obj_Id.QuId, yyt->Obj_Id.QuId)
copyint ((* yyNew)->Obj_Id.VarKind, yyt->Obj_Id.VarKind)
yyt = yyt->Obj_Id.Pre;
yyNew = & (* yyNew)->Obj_Id.Pre; break;
case kObj_Tmp: (* yyNew)->Obj_Tmp = yyt->Obj_Tmp;
copytSyms ((* yyNew)->Obj_Tmp.Next, yyt->Obj_Tmp.Next)
copytSyms ((* yyNew)->Obj_Tmp.Pre, yyt->Obj_Tmp.Pre)
copytIdent ((* yyNew)->Obj_Tmp.ModId, yyt->Obj_Tmp.ModId)
copytType ((* yyNew)->Obj_Tmp.Type, yyt->Obj_Tmp.Type)
copytIdent ((* yyNew)->Obj_Tmp.Ident, yyt->Obj_Tmp.Ident)
copybool ((* yyNew)->Obj_Tmp.IsSelected, yyt->Obj_Tmp.IsSelected)
copybool ((* yyNew)->Obj_Tmp.Tag, yyt->Obj_Tmp.Tag)
yyt = yyt->Obj_Tmp.Inner;
yyNew = & (* yyNew)->Obj_Tmp.Inner; break;
case kObj_Param: (* yyNew)->Obj_Param = yyt->Obj_Param;
copytSyms ((* yyNew)->Obj_Param.Next, yyt->Obj_Param.Next)
copytIdent ((* yyNew)->Obj_Param.ModId, yyt->Obj_Param.ModId)
copytType ((* yyNew)->Obj_Param.Type, yyt->Obj_Param.Type)
copytIdent ((* yyNew)->Obj_Param.Ident, yyt->Obj_Param.Ident)
copybool ((* yyNew)->Obj_Param.IsSelected, yyt->Obj_Param.IsSelected)
copybool ((* yyNew)->Obj_Param.Tag, yyt->Obj_Param.Tag)
yyt = yyt->Obj_Param.Pre;
yyNew = & (* yyNew)->Obj_Param.Pre; break;
case kObj_PTyId: (* yyNew)->Obj_PTyId = yyt->Obj_PTyId;
copytSyms ((* yyNew)->Obj_PTyId.Next, yyt->Obj_PTyId.Next)
copytIdent ((* yyNew)->Obj_PTyId.ModId, yyt->Obj_PTyId.ModId)
copytType ((* yyNew)->Obj_PTyId.Type, yyt->Obj_PTyId.Type)
copytIdent ((* yyNew)->Obj_PTyId.Ident, yyt->Obj_PTyId.Ident)
copybool ((* yyNew)->Obj_PTyId.IsSelected, yyt->Obj_PTyId.IsSelected)
copybool ((* yyNew)->Obj_PTyId.Tag, yyt->Obj_PTyId.Tag)
yyt = yyt->Obj_PTyId.Pre;
yyNew = & (* yyNew)->Obj_PTyId.Pre; break;
case kObj_PId: (* yyNew)->Obj_PId = yyt->Obj_PId;
copytSyms ((* yyNew)->Obj_PId.Next, yyt->Obj_PId.Next)
copytIdent ((* yyNew)->Obj_PId.ModId, yyt->Obj_PId.ModId)
copytType ((* yyNew)->Obj_PId.Type, yyt->Obj_PId.Type)
copytIdent ((* yyNew)->Obj_PId.Ident, yyt->Obj_PId.Ident)
copybool ((* yyNew)->Obj_PId.IsSelected, yyt->Obj_PId.IsSelected)
copybool ((* yyNew)->Obj_PId.Tag, yyt->Obj_PId.Tag)
yyt = yyt->Obj_PId.Pre;
yyNew = & (* yyNew)->Obj_PId.Pre; break;
  default: ;
  }
 }
}

tSyms CopySyms
# if defined __STDC__ | defined __cplusplus
 (tSyms yyt)
# else
 (yyt) tSyms yyt;
# endif
{
 tSyms yyNew;
 yyMark (yyt);
 yyOldToNewCount = 0;
 yyCopySyms (yyt, & yyNew);
 return yyNew;
}

void BeginSyms ()
{
}

void CloseSyms ()
{
}
