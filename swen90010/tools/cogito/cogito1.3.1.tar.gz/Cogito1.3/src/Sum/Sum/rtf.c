# include "rtf.h"
# include "yyrtf.w"
# include "System.h"
# include <stdio.h>
# include "Tree.h"
# include "Type.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 11 "rtf.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
# include "Tree.h"
# include "Syms.h"
# include "Type.h"
# include "global.h"
# include "Scanner.h"
# include "Idents.h"
# include "Positions.h"
# include "ratc.h"
# include <string.h>
# include <stdio.h>
# include <stdarg.h>
# include <ctype.h>

#define DASHMAX   40
#define PrintIt(str)  fprintf(wfp, "{\\i %s}", str)
#define PrintB(str)   fprintf(wfp, "{\\b %s}", str)
#define PrintEndBox   fprintf(wfp, "{\\f45 {\\field{\\*\\fldinst SYMBOL 208}");\
        fprintf(wfp, "{\\fldrslt\\f45\\fs24}}}");\
        WF_PrintDash(schemalevel, 0)
/*          fprintf(wfp, "{\\f45 ________________________________________}") */
/*        "{\\f45\\cchs256 \\'d0}{\\f45 ____________________}")         */
#define PrintST       fprintf(wfp, \
        "{\\f45\\cchs256 \\'c7}");\
        WF_PrintDash(schemalevel, 0)
        /*"{\\f45 ________________________________________}") */
#define PrintBoxS     fprintf(wfp, \
        "\\pard \\qj\\keep\\widctlpar\\tx1880 {\\f45\\cchs256 \\'c8}")
#define PrintBoxE(strlen)  WF_PrintDash(schemalevel, strlen)
/*        "{\\f45\\cchs256 ____________________}") */
#define PrintGendefS  fprintf(wfp, \
        "{\\f45\\cchs256 \\'bd}")
#define PrintGendefE(strlen) WF_PrintGenDash(schemalevel, strlen)
/*        "{\\f45\\cchs256 \\'be\\'be\\'be\\'be\\'be\\'be\\'be\\'be\\'be}") */
#define PrintIndent   fprintf(wfp, \
   "{\\f45\\cchs256 \\'ae  }")
#define PrintNewline  fprintf(wfp, "{\\f45\\cchs256\n\\par } ")



/* global variables within the file */
/* The list of comments extracted by the scanner to be re-inserted by
   Graphical generators
*/

extern CppCommLink cpp_comm_head;
CppCommLink WFComm;

/* The input Position of the last symbol printed
   Used to detect line breaks and indenting of input
   Symbols for formatting of the output

   Note the starting Position for larger abstract constructs
   is synthesised from the closest identifier. So it isnt
   accurate.
*/

tPosition  WFPos;

/* static FILE *fp; */
FILE *wfp;
# ifdef WIN32
extern char *SumFileName, *SumPathName, *SumSpecFile;
# endif
int schemalevel = 0;
bool indenttag = false;
bool setBaseIndent = false;
int lastLine = 0;
int baseIndent = 0;
int incIndent = 0;  /* extra forced indentation */

/*
char *wordheader="WordHead.rtf";

void WF_CreateHeader()
{
   FILE *tmpfp;
   char str[IDENT_LENGTH];
   tmpfp = fopen(wordheader, "r");

   if (tmpfp == NULL) {
      fprintf (stderr, "Can't read word header file: %s\n", wordheader);
      exit(1);
   }
   while (!feof(tmpfp)) {
      fgets(str, IDENT_LENGTH - 1, tmpfp);
      fputs(str, wfp);
   }
   fclose(tmpfp);
}
*/

void WF_CreateHeader()
{

fprintf(wfp, "{\\rtf1\\ansi\n");
fprintf(wfp, "\n");
fprintf(wfp, "\\deff8\\deflang1033{\\fonttbl\n");
fprintf(wfp, "   {\\f8\\froman\\fcharset0\\fprq2 Times;}\n");
fprintf(wfp, "   {\\f12\\froman\\fcharset0\\fprq2 New York;}\n");
fprintf(wfp, "   {\\f45\\fnil\\fcharset2\\fprq2 Zed;}\n");
fprintf(wfp, "}\n");
fprintf(wfp, "\n");
fprintf(wfp, "{\\stylesheet\n");
fprintf(wfp, "{\\qj\\sb120\\keep\\widctlpar\\tx1880 \\f8 \\snext0 Normal;}\n");
fprintf(wfp, "{\\s1\\qc\\sb240\\keep\\keepn\\widctlpar\\tx1880 \\b\\scaps\\caps\\f12\\fs36 \\sbasedon2\\snext2 heading 1;}\n");
fprintf(wfp, "{\\s2\\qj\\sb240\\keep\\keepn\\widctlpar\\tx1880 \\b\\scaps\\f12\\fs26 \\sbasedon3\\snext0 heading 2;}\n");
fprintf(wfp, "{\\s3\\qj\\sb240\\keep\\keepn\\widctlpar\\tx1880 \\b\\f12 \\sbasedon4\\snext0 heading 3;}\n");
fprintf(wfp, "{\\s4\\qj\\sb120\\keep\\keepn\\widctlpar\\tx1880 \\scaps\\f8 \\sbasedon0\\snext0 heading 4;}\n");
fprintf(wfp, "{\\*\\cs10 \\additive Default Paragraph Font;}\n");
fprintf(wfp, "}\n");
fprintf(wfp, "\n");
fprintf(wfp, "\\paperw11880\\paperh16820\n");
fprintf(wfp, "\\pard\\plain \\qj\\keep\\widctlpar\\tx1880 \\f8\n ");

}


void WF_CreateFile()
{
    char wf_file[IDENT_LENGTH];


    wf_file[0] = '\0';
    strcat (wf_file, SumSpecFile);
    strcat (wf_file, ".rtf");

    wfp = fopen (wf_file, "w");
    if (wfp == NULL) {
        fprintf (stderr, "Can't write to file: %s\n", wf_file);
        exit(1);
    }
	/* add preamble part */
    WF_CreateHeader();
    WFComm = cpp_comm_head;
}

void WF_CloseFile ()
{
    fprintf (wfp, "\\pard \\qj\\sb120\\keep\\widctlpar\\tx1880\n\\par");
    PrintNewline;
    fprintf (wfp, "}\n");
    fclose (wfp);
}

void WF_Indent(level)
        int level;
{
   int i;

   for (i=0;i < level;i++) {
       PrintIndent;
   }
}

void WF_PrintNewline(level)
        int level;
{
   PrintNewline;
   WF_Indent(level);
}

/* Write out any comments occuring up to Pos
   that havnt been printed already

   Further work: return flag for success to get line breaks correct.
*/

void WF_Comment (Pos)
    tPosition Pos;
{
    /* While comments exist before Pos, print them */
    for (;WFComm && (lastLine > WFComm->pos.Line); WFComm=WFComm->next) {
        fprintf (wfp, "// %s", WFComm->comm);
        WF_PrintNewline(schemalevel);
    }
}

void WF_CommentEnd ()
{
    /* While comments exist before Pos, print them */
    for (; WFComm; WFComm=WFComm->next) {
        fprintf (wfp, "%s", WFComm->comm);
        PrintNewline;
    }
}

void WF_SetPos(Pos)
    tPosition Pos;
{
   if (Pos.Line > lastLine) {
       lastLine = Pos.Line;
   }
}



void extern WF_ExpList();
void extern WF_IdList();
void extern WF_DeclList();
void extern WF_PredList();
int extern WF_FormalParams();
void extern WF_SemicolonDeclList();
void extern WF_SemicolonPredList();
void extern WF_VarDecl();
void extern WF_CreateFile();
void extern WF_CloseFile();
void SumWForm (tTree t);
void WF_IncIndent();
void WF_DecIndent();
void WF_ForcePrintIndent();

void WF_PrintDash(level, len)
   int level;
   int len;
{
   int i, count = DASHMAX;

   fprintf(wfp, "{\\f45 ");
   for (i=0; i<level; i++) count -= 3;
   count -= len;
   for (i=0; i<count; i++) fprintf(wfp, "_");
   fprintf(wfp, "}");
}

void WF_PrintGenDash(level, len)
   int level;
   int len;
{
   int i, count = DASHMAX;

   fprintf(wfp, "{\\f45\\cchs256 ");
   for (i=0; i<level; i++) count -= 3;
   count -= len;
   for (i=0; i<count; i++) fprintf(wfp, "\\'be");
   fprintf(wfp, "}");
}

void WF_PrintIndent(posi)
	tPosition posi;
{
    int i;

    if (indenttag && (posi.Line > lastLine)) {
        if (setBaseIndent) {
            setBaseIndent = false;
            baseIndent = posi.Column;
        }
        WF_PrintNewline(schemalevel);
        for (i = baseIndent; i < posi.Column; i++) {
            fprintf(wfp, " ");
	}
	for (i=0; i<incIndent; i++) {  /* allow for forced indentation */
            fprintf(wfp, " ");
        }
    }
    WF_SetPos(posi);
/* if (posi.Line > lastLine) {
        lastLine = posi.Line;
    } */
}

/* force a new line and indent it  -- wj*/
void WF_ForcePrintIndent(posi)
	tPosition posi;
{
	int i;
	WF_PrintNewline(schemalevel);
	for (i=0; i<incIndent; i++) {  /* allow for forced indentation */
            fprintf(wfp, " ");
        }
    WF_SetPos(posi);
}

/* increment incIndent -- wj */
void WF_IncIndent()
{
	incIndent = incIndent + 3;
}

/* decrement incIndent -- wj */
void WF_DecIndent()
{
	if (incIndent >= 3)
		incIndent = incIndent - 3;
}



void WF_Spaces(spaces)
	int spaces;
{
   int i;
   for (i=0; i < spaces; i++) {
       fputc(' ', wfp);
   }
}



void WF_Module (Ident, FormalParams, DeclList)
    tIdPos Ident;
    tTree FormalParams;
    tTree DeclList;
{
    char idstr[IDENT_LENGTH];
    int len=0;

    WF_SetPos(Ident.Pos);
    mygetstr (Ident.Ident, idstr);
    if (FormalParams->Kind == kNoParam) {
        PrintBoxS;
        fprintf (wfp, "{\\i %s}", idstr);
        len += strlen(idstr);
    }
    else {
        PrintBoxS;
        fprintf (wfp, "{\\i %s[}", idstr);
        len += WF_FormalParams(FormalParams, 1);
        fprintf (wfp, "{\\i ]}");
        len += strlen(idstr);
    }
    WF_SetPos(DeclList->Decl.Pos);
    schemalevel++;
    PrintBoxE(len);
    WF_PrintNewline(schemalevel);
    WF_DeclList(DeclList);
    PrintEndBox;
    schemalevel--;
    WF_PrintNewline(schemalevel);
}

void WF_ModList (ModuleList)
	tTree ModuleList;
{
	tTree modlist=ModuleList;

	WF_CreateFile();

	for (; modlist && modlist->Kind != kNoModule;
		modlist=modlist->Module.Next) {

            WF_Comment(modlist->Module.Pos);
		SumWForm (modlist);
		/* ?? any space between modules */
	}
   WF_CommentEnd();
	WF_CloseFile();
}

int WF_FormalParams (FormalParams, Tag)
    tTree FormalParams;
	bool Tag;
/*
 * 1: module formal parameters
 * 0: schema and axiom formal parameters
 */
{
    char idstr[IDENT_LENGTH];
    tTree paramlist=FormalParams;
    int len = 0;

    for (; paramlist && paramlist->Kind != kNoParam;
        paramlist=paramlist->Param.Next) {

        if (paramlist->Kind == kTyParam) {
            mygetstr (paramlist->TyParam.Ident.Ident, idstr);
            fprintf (wfp, "{\\i %s}", idstr);
            len += strlen(idstr);
        }
        else /* kFncParam = VarDecl */
            SumWForm (paramlist->FncParam.VarDecl);

        if (paramlist->Param.Next->Kind != kNoParam) {

			if (Tag)
				fprintf (wfp, "{\\i ; }");
			else
				fprintf (wfp, "{\\i , }");
           len += 2;
		}
    }
    return len;
}

/* to unparse the List (DeclList and PredList which might be in
 * Module, SchemaDef, etc) to Graphical form separated by carriage-return.
 */
void WF_DeclList (List)
    tTree List;
{
    tTree list=List;

    for (; list && list->Kind != kNoDecl;
        list=list->Decl.Next) {

        WF_SetPos(list->Decl.Pos);
        WF_Comment(list->Decl.Pos);
        SumWForm (list);
        if (list->Decl.Next->Kind != kNoDecl) {
             WF_Comment(list->Decl.Pos);
	     WF_PrintNewline(schemalevel);
	} else {
             WF_Comment(list->Decl.Pos);
	     WF_PrintNewline(schemalevel - 1);
        }
    }
}

void WF_PredList (List)
    tTree List;
{
    tTree list=List;

    indenttag = true;
    for (; list && list->Kind != kNoPred;
        list=list->Pred.Next) {

        setBaseIndent = true;
        WF_SetPos(list->Pred.Pos);
        WF_Comment(list->Pred.Pos);
        SumWForm (list);
        if (list->Pred.Next->Kind != kNoPred)  {
            WF_Comment(list->Pred.Pos);
            WF_PrintNewline(schemalevel);
            lastLine++;
        } else {
            WF_Comment(list->Pred.Pos);
	    WF_PrintNewline(schemalevel - 1);
        }
    }
    indenttag = false;
}

/* to unparse the list (DeclList and PredList which might be in
 * QuantPred, SchemaText, SetComp, etc) to L1; L2; ...
 */
void WF_SemicolonDeclList (List)
    tTree List;
{
    tTree list=List;

    for (; list && list->Kind != kNoDecl;
        list=list->Decl.Next) {

        WF_Comment(list->Decl.Pos);
        SumWForm (list);
        if (list->Decl.Next->Kind != kNoDecl)  {
            WF_PrintIndent(list->Decl.Pos);
            fprintf (wfp, "{\\i ; }");
        }
    }
}

void WF_SemicolonPredList (List)
    tTree List;
{
    tTree list=List;

    for (; list && list->Kind != kNoPred;
        list=list->Pred.Next) {

        WF_Comment(list->Pred.Pos);
        SumWForm (list);
        if (list->Pred.Next->Kind != kNoPred) {
            WF_PrintIndent(list->Decl.Pos);
            fprintf (wfp, "{\\i ; }");
        }
    }
}

/* to unparse IdList to the form of id1, id2, ... */
void WF_IdList (IdList)
    tTree IdList;
{
    char idstr[IDENT_LENGTH];

    tTree idlist=IdList;
    for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) {
        mygetstr (idlist->Id.Ident.Ident, idstr);
        WF_PrintIndent(idlist->Id.Ident.Pos);
        fprintf (wfp, "{\\i %s}", idstr);
        if (idlist->Id.Next->Kind != kNoId)
            fprintf (wfp, "{\\i , }");
    }
}

void WF_RenameList (RenameList)
    tTree RenameList;
{
    tTree renamelist=RenameList;
    char oldstr[IDENT_LENGTH], newstr[IDENT_LENGTH];

    fprintf (wfp, "{\\f45\\cchs256 \\'7b}");
    for (; renamelist && renamelist->Kind != kNoRename;
        renamelist=renamelist->Rename.Next) {

    mygetstr (renamelist->Rename.NewIdent.Ident, newstr);
    Unparse_Name (renamelist->Rename.OldIdent, oldstr);
    WF_PrintIndent(renamelist->Rename.NewIdent.Pos);
    fprintf (wfp, "{\\i %s / %s}", newstr, oldstr);

    if (renamelist->Rename.Next->Kind != kNoRename)
            fprintf (wfp, "{\\i , }");
    }
    fprintf(wfp, "{\\f45\\cchs256 \\'7d}");
}

void WF_ExpList (ExpList)
    tTree ExpList;
{
    tTree explist=ExpList;

    for (; explist && explist->Kind != kNoExp;
        explist=explist->Exp.Next) {
	WF_PrintIndent(explist->Exp.Pos);
        SumWForm (explist);
        if (explist->Exp.Next->Kind != kNoExp)
            fprintf (wfp, "{\\i , }");
    }
}

void WF_VarDecl (IdList, Exp)
    tTree IdList, Exp;
{
    WF_SetPos(IdList->Id.Pos);
    WF_IdList (IdList);
    fprintf (wfp, "{\\i : }");
    SumWForm (Exp);
}

void WF_GivenSet (IdList)
    tTree IdList;
{
    WF_SetPos(IdList->Id.Pos);
    fprintf (wfp, "[");
    WF_IdList (IdList);
    fprintf (wfp, "]");
}

void WF_AxiomDecl (FormalParams, DeclList, PredList)
    tTree FormalParams, DeclList, PredList;
{
    int len = 0;

    if (FormalParams->Kind != kNoParam) {
	PrintGendefS;
        len += WF_FormalParams (FormalParams, 0);
        PrintGendefE(len + 2);
        schemalevel++;
	WF_PrintNewline(schemalevel);
    }
    else {
        WF_PrintNewline(schemalevel);
        PrintIndent;
        schemalevel++;
    }
    WF_SetPos(DeclList->Decl.Pos);
    WF_DeclList (DeclList);
    WF_Comment(DeclList->Decl.Pos);
    if (PredList->Kind != kNoPred) {
        WF_Comment(PredList->Pred.Pos);
        PrintST;
	WF_PrintNewline(schemalevel);
        WF_SetPos(PredList->Pred.Pos);
	WF_PredList (PredList);
    }
    if (FormalParams->Kind != kNoParam)  {
        PrintEndBox;
        schemalevel--;
        WF_PrintNewline(schemalevel);
    } else {
        schemalevel--;
        /* WF_PrintNewline(schemalevel); */
    }
}

void WF_SchemaDef (Ident, FormalParams, DeclList, PredList, IsOp)
    tIdPos Ident;
    tTree FormalParams, DeclList, PredList;
	bool IsOp;
{
    char idstr[IDENT_LENGTH];
    int len;

    mygetstr (Ident.Ident, idstr);
	 if (IsOp && Ident.Ident != Ident_init) {
		PrintBoxS;
		fprintf (wfp, "{\\i op %s}", idstr);
      len = strlen(idstr) + 3;
	 } else {
		PrintBoxS;
		fprintf (wfp, "{\\i %s}", idstr);
      len = strlen(idstr);
    }
    if (FormalParams->Kind != kNoParam) {
        fprintf (wfp, "{\\i [}");
        len += WF_FormalParams (FormalParams, 0);
        fprintf (wfp, "{\\i ]}");
    }
    PrintBoxE(len);
    schemalevel++;
    WF_PrintNewline(schemalevel);
    WF_SetPos(DeclList->Decl.Pos);
    WF_DeclList(DeclList);
    if (DeclList->Kind != kNoDecl && PredList->Kind != kNoPred) {
        WF_Comment(PredList->Pred.Pos);
        PrintST;
	WF_PrintNewline(schemalevel);
    }
    WF_SetPos(PredList->Pred.Pos);
/*    if (PredList->Pred.Pos.Line > lastLine) {
        lastLine = PredList->Pred.Pos.Line;
    } */
    WF_PredList(PredList);
    PrintEndBox;
    schemalevel--;
    WF_PrintNewline(schemalevel);
}

void WF_Abbr (Ident, Exp)
    tIdPos Ident;
    tTree Exp;
{
    char idstr[IDENT_LENGTH];

    mygetstr (Ident.Ident, idstr);
    WF_PrintIndent(Ident.Pos);
    fprintf (wfp, "{\\i %s }{\\f45\\cchs256 \\'3d\\'3d} ", idstr);
    SumWForm (Exp);
}

void WF_Import (Ident, ExpressionList, RenameList, NewIdent)
    tIdPos Ident, NewIdent;
    tTree ExpressionList, RenameList;
{
    char idstr[IDENT_LENGTH], newidstr[IDENT_LENGTH];

    mygetstr (Ident.Ident, idstr);
    fprintf (wfp, "{\\i import %s}", idstr);
    if (ExpressionList->Kind != kNoExp) {
        fprintf (wfp, "(");
        WF_ExpList (ExpressionList);
        fprintf (wfp, ")");
    }
    if (RenameList->Kind != kNoRename) {
        WF_RenameList (RenameList);
    }
    if (Ident.Ident != NewIdent.Ident) {
        mygetstr (NewIdent.Ident, newidstr);
        fprintf (wfp, " {\\i as %s}", newidstr);
    }
}

void WF_FreeType (Ident, BranchList)
    tIdPos Ident;
    tTree BranchList;
{
    char idstr[IDENT_LENGTH];
    tTree blist=BranchList;

    WF_SetPos(Ident.Pos);
    mygetstr (Ident.Ident, idstr);
    WF_PrintIndent(Ident.Pos);
    fprintf (wfp, "{\\i %s ::= }", idstr);
/* wj -- allow for user-forced line breaks */
	indenttag = true;
    for (; blist && blist->Kind != kNoBranch; blist=blist->Branch.Next) {

        if (blist->Kind == kFTConstant) {
            mygetstr (blist->FTConstant.Ident.Ident, idstr);
            WF_PrintIndent(blist->FTConstant.Ident.Pos);
            fprintf (wfp, "{\\i %s} ", idstr);
        }
        else { /* FTConstructor */
            mygetstr (blist->FTConstructor.Ident.Ident, idstr);
            WF_PrintIndent(blist->FTConstant.Ident.Pos);
            fprintf (wfp, "{\\i %s} {\\f45\\cchs256 \\'cf} ", idstr);
            SumWForm (blist->FTConstructor.Exp);
            fprintf (wfp, "{\\f45\\cchs256 \\'b7} ");
        }
        if (blist->Branch.Next->Kind != kNoBranch)
            fprintf (wfp, " {\\f45\\cchs256 \\'ae} ");
    }
/* wj -- remove indenttag */
	indenttag = false;
}

/* schema instantiation */
void WF_Exp_SchemaRef (IdList, ExpressionList)
    tTree IdList, ExpressionList;
{
    char idstr[IDENT_LENGTH];

    Unparse_Name (IdList, idstr);
	 fprintf (wfp, "{\\i %s[}", idstr);
	 WF_ExpList (ExpressionList);
	 fprintf (wfp, "{\\i ]}");
}

void WF_PredExp (Pred)
	tTree Pred;
{
	fprintf (wfp, "(");
	SumWForm (Pred);
	fprintf (wfp, ")");
}

void WF_Visible (Ident, SelectionList)
    tIdPos Ident;
    tTree SelectionList;
{
    char idstr[IDENT_LENGTH];
    tTree slist=SelectionList;

    mygetstr (Ident.Ident, idstr);
	 if (slist->Kind == kNoSelection)
	    fprintf (wfp, "{\\i visible %s}", idstr);
	 else {
	    fprintf (wfp, "{\\i visible %s} {\\f45\\cchs256 \\'7b}", idstr);
		 for (; slist && slist->Kind != kNoSelection;
			slist=slist->Selection.Next) {
			mygetstr (slist->Selection.Ident.Ident, idstr);
			if (slist->Selection.Next->Kind != kNoSelection)
				fprintf (wfp, "{\\i %s,}", idstr);
			else
				fprintf (wfp, "{\\i %s}", idstr);
		 }
		 fprintf (wfp, "{\\f45\\cchs256 \\'7d}");
	}
}

void WF_QuantPred (LogQuant, SchemaText, Pred)
    tIdPos LogQuant;
    tTree SchemaText;
    tTree Pred;
{
    WF_PrintIndent(LogQuant.Pos);
    if (LogQuant.Ident == Ident_forall)
        fprintf (wfp, "{\\f45\\cchs256 \\'41} ");
    else if (LogQuant.Ident == Ident_exists)
        fprintf (wfp, "{\\f45\\cchs256 \\'45} ");
    else if (LogQuant.Ident == Ident_exists_1)
        fprintf (wfp, "{\\f45\\cchs256 \\'45}{\\sub 1} ");
    else if (LogQuant.Ident == Ident_let)
        fprintf (wfp, "{\\b let} ");
    SumWForm (SchemaText);
    fprintf (wfp, " {\\f45\\cchs256 \\'a5} ");
    /* fprintf (wfp, "{\\f45  {\\field{\\*\\fldinst SYMBOL 165}{\\fldrslt\\f45\\fs24}}} ");*/
    SumWForm (Pred);
}

void WF_RelBinPred (L, RelBinOp, R)
    tTree L, R;
    tIdPos RelBinOp;
{
	 SumWForm (L);
    WF_PrintIndent(RelBinOp.Pos);
    if (RelBinOp.Ident == Ident_equal)
        fprintf (wfp, " {\\f45\\cchs256 \\'3d} ");
    else if (RelBinOp.Ident == Ident_notequ)
        fprintf (wfp, " {\\f45\\cchs256 \\'eb} ");
    else if (RelBinOp.Ident == Ident_less)
        fprintf (wfp, " {\\f45\\cchs256 \\'3c} ");
    else if (RelBinOp.Ident == Ident_grt)
        fprintf (wfp, " {\\f45\\cchs256 \\'3e} ");
    else if (RelBinOp.Ident == Ident_notless)
        fprintf (wfp, " {\\f45\\cchs256 \\'f9} ");
    else if (RelBinOp.Ident == Ident_notgrt)
        fprintf (wfp, " {\\f45\\cchs256 \\'f8} ");
    else if (RelBinOp.Ident == Ident_subset)
        fprintf (wfp, " {\\f45\\cchs256 \\'7a} ");
    else if (RelBinOp.Ident == Ident_p_subset)
        fprintf (wfp, " {\\f45\\cchs256 \\'63} ");
    else if (RelBinOp.Ident == Ident_in)
        fprintf (wfp, " {\\f45\\cchs256 \\'65} ");
    else if (RelBinOp.Ident == Ident_not_in)
        fprintf (wfp, " {\\f45\\cchs256 \\'e4} ");
    else if (RelBinOp.Ident == Ident_in_bag)
        fprintf (wfp, " in ");
    else if (RelBinOp.Ident == Ident_partitions)
        fprintf (wfp, " partitions ");

	SumWForm (R);
}

void WF_RelPrePred (RelPreOp, Exp)
    tIdPos RelPreOp;
    tTree Exp;
{
    if (RelPreOp.Ident == Ident_disjoint) {
        WF_PrintIndent(RelPreOp.Pos);
        fprintf (wfp, " disjoint ");
    }
    SumWForm (Exp);
}

void WF_LogBinPred (L, LogBinOp, R)
    tTree L, R;
    tTree LogBinOp;
{
    SumWForm (L);
    switch (LogBinOp->Kind) {
    case kLogEquiv:
        fprintf (wfp, " {\\f45\\cchs256 \\'db} ");
        break;
    case kLogImply:
        fprintf (wfp, " {\\f45\\cchs256 \\'de} ");
        break;
    case kLogAnd:
        fprintf (wfp, " {\\f45\\cchs256 \\'a6} ");
        break;
    case kLogOr:
        fprintf (wfp, " {\\f45\\cchs256 \\'76} ");
        break;
    case kLogExor:
        fprintf (wfp, " exor ");
        break;
    case kLogSeq:
        fprintf (wfp, " logseq ");
        break;
    }
/* wj -- allow for user-forced new line */
	WF_PrintIndent(R->Pred.Pos);
    SumWForm (R);
}

void WF_LogicalNot (Pred)
    tTree Pred;
{
    fprintf (wfp, "{\\f45\\cchs256 \\'21} ");
    SumWForm (Pred);
}

void WF_PreCondPred (Pred)
    tTree Pred;
{
    fprintf (wfp, "pre ");
    WF_SetPos(Pred->Pred.Pos);
    SumWForm (Pred);
}

void WF_ChgOnly (NameList)
    tTree NameList;
{
    tTree namelist;
    char idstr[IDENT_LENGTH];

    fprintf (wfp, "{\\i changes_only}{\\f45\\cchs256 \\'7b}");

    for (namelist=NameList; namelist && namelist->Kind != kNoName;
        namelist=namelist->Name.Next) {

        Unparse_Name (namelist->Name.IdList, idstr);
        WF_PrintIndent(namelist->Name.Pos);
        if (namelist->Name.Next->Kind != kNoName)
            fprintf (wfp, "{\\i %s, }", idstr);
        else
            fprintf (wfp, "{\\i %s}", idstr);
    }
	fprintf (wfp, "{\\f45\\cchs256 \\'7d}");
}

void WF_BoolValue (Ident)
    tIdPos Ident;
{
    WF_PrintIndent(Ident.Pos);
    if (Ident.Ident == Ident_true)
        fprintf (wfp, " {\\b true} ");
    else if (Ident.Ident == Ident_false)
        fprintf (wfp, " {\\b false} ");
}

void WF_SchemaText (DeclList, PredList, ild)
    tTree DeclList, PredList;
    bool ild;
{
    if (!ild) fprintf (wfp, " {\\f45\\cchs256 \\'5b} ");
    WF_SemicolonDeclList (DeclList);
    if (PredList->Kind != kNoPred) {
/* wrj --- fix to print | instead of dot in schema text */
      if (ild) fprintf (wfp, "{\\f45\\cchs256 \\'ae} ");
/*       if (ild) fprintf (wfp, "{\\f45  {\\field{\\*\\fldinst SYMBOL 165}{\\fldrslt\\f45\\fs24}}} ");*/
       else  fprintf (wfp, " {\\f45\\cchs256 \\'7c} ");
       WF_SemicolonPredList (PredList);
    }
    if (!ild) fprintf (wfp, " {\\f45\\cchs256 \\'5d} ");
}

void WF_SchemaCompos(Sch1, Sch2)
    tTree Sch1, Sch2;
{
    SumWForm (Sch1);
    fprintf (wfp, " {\\f45\\cchs256 \\'3b} ");
    SumWForm (Sch2);
}

void WF_SchemaHiding (Schema, NameList)
    tTree Schema, NameList;
{
    tTree namelist;
    char idstr[IDENT_LENGTH];

    SumWForm (Schema);
    fprintf (wfp, " {\\f45\\cchs256 \\'5c} (");

    for (namelist=NameList; namelist && namelist->Kind != kNoName;
        namelist=namelist->Name.Next) {

        Unparse_Name (namelist->Name.IdList, idstr);
        if (namelist->Name.Next->Kind != kNoName)
            fprintf (wfp, "{\\i %s, }", idstr);
        else
            fprintf (wfp, "{\\i %s)}", idstr);
    }
}

void WF_SchemaProj (Sch1, Sch2)
    tTree Sch1, Sch2;
{
    SumWForm (Sch1);
    fprintf (wfp, " {\\f45\\cchs256 \\'c1} ");
    SumWForm (Sch2);
}

void WF_SchemaSubst (Schema, RenameList)
    tTree Schema, RenameList;
{
    SumWForm (Schema);
	WF_RenameList (RenameList);
}

void WF_Variable (IdList)
	tTree IdList;
{
	char idstr[IDENT_LENGTH];

	Unparse_Name (IdList, idstr);

   WF_PrintIndent(IdList->Id.Ident.Pos);
	/* predefined constants and functions */
	if (IdList->Id.Next->Kind == kNoId) {
		if (IdList->Id.Ident.Ident == Ident_int)
			fprintf (wfp, " {\\f45\\cchs256 \\'5a} ");
		else if (IdList->Id.Ident.Ident == Ident_nat)
			fprintf (wfp, " {\\f45\\cchs256 \\'4e} ");
		else if (IdList->Id.Ident.Ident == Ident_nat_1)
			fprintf (wfp, " {\\f45\\cchs256 \\'4e}{\\sub 1} ");
		else if (IdList->Id.Ident.Ident == Ident_bool)
			fprintf (wfp, " {\\b bool} ");
		else if (IdList->Id.Ident.Ident == Ident_inverse)
			fprintf (wfp, "{\\super {\\f45\\cchs256 \\'7e}} ");
		else if (IdList->Id.Ident.Ident == Ident_iter)
			fprintf (wfp, "{\\super } ");  /* super next token ? */
		else if (IdList->Id.Ident.Ident == Ident_t_closure)
			fprintf (wfp, "{\\super {\\f45\\cchs256 \\'2b}} ");
		else if (IdList->Id.Ident.Ident == Ident_rt_closure)
			fprintf (wfp, "{\\super {\\f45\\cchs256 \\'2a}} ");
		else if (IdList->Id.Ident.Ident == Ident_count)
			fprintf (wfp, "{\\i bagcount} ");
		else
			fprintf (wfp, "{\\i %s}", idstr);
	}
	else
		fprintf (wfp, "{\\i %s}", idstr);
}

void WF_Literal (Ident)
    tIdPos Ident;
{
    char idstr[IDENT_LENGTH];

    mygetstr (Ident.Ident, idstr);
    WF_PrintIndent(Ident.Pos);
    fprintf (wfp, "{\\i %s}", idstr);
}

void WF_PrefixOp (Prefix, Exp)
    tIdPos Prefix;
    tTree Exp;
{
    WF_PrintIndent(Prefix.Pos);
    if (Prefix.Ident == Ident_sub)
        fprintf (wfp, "{\\f45\\cchs256 \\'2d} ");
    else if (Prefix.Ident == Ident_card)
        fprintf (wfp, "{\\f45\\cchs256 \\'23} ");
    else if (Prefix.Ident == Ident_power)
        fprintf (wfp, "{\\f45\\cchs256 \\'50} ");
    else if (Prefix.Ident == Ident_power_1)
        fprintf (wfp, "{\\f45\\cchs256 \\'50}{\\sub 1} ");
    else if (Prefix.Ident == Ident_finite)
        fprintf (wfp, "{\\f45\\cchs256 \\'46} ");
    else if (Prefix.Ident == Ident_finite_1)
        fprintf (wfp, "{\\f45\\cchs256 \\'46}{\\sub 1} ");
    else if (Prefix.Ident == Ident_seq)
        fprintf (wfp, "seq ");
    else if (Prefix.Ident == Ident_seq_1)
        fprintf (wfp, "seq{\\sub 1} ");
        /* not found in oz.sty
    else if (Prefix.Ident == Ident_iseq)
        fprintf (wfp, " \\?? ");
        */
    else if (Prefix.Ident == Ident_id)
        fprintf (wfp, "id ");
    else if (Prefix.Ident == Ident_bag)
        fprintf (wfp, "bag ");
    else if (Prefix.Ident == Ident_dom)
        fprintf (wfp, "dom ");
    else if (Prefix.Ident == Ident_ran)
        fprintf (wfp, "ran ");
    else if (Prefix.Ident == Ident_gen_union)
        fprintf (wfp, "{\\f45\\fs28 U} "); /* change font size */
    else if (Prefix.Ident == Ident_gen_inter)
        fprintf (wfp, "{\\f45\\fs28 I} ");

    SumWForm (Exp);
}

void WF_InfixOp (Op1, Infix, Op2)
    tTree Op1, Op2;
    tIdPos Infix;
{
    SumWForm (Op1);
    WF_PrintIndent(Infix.Pos);
    if (Infix.Ident == Ident_relation)
        fprintf (wfp, " {\\f45\\cchs256 \\'6a} ");
    else if (Infix.Ident == Ident_partfunc)
        fprintf (wfp, " {\\f45\\cchs256 \\'a7} ");
    else if (Infix.Ident == Ident_totalfunc)
        fprintf (wfp, " {\\f45\\cchs256 \\'66} ");
    else if (Infix.Ident == Ident_partinj)
        fprintf (wfp, " {\\f45\\cchs256 \\'a9} ");
    else if (Infix.Ident == Ident_totalinj)
        fprintf (wfp, " {\\f45\\cchs256 \\'c4} ");
    else if (Infix.Ident == Ident_partsur)
        fprintf (wfp, " {\\f45\\cchs256 \\'fb} ");
    else if (Infix.Ident == Ident_totalsur)
        fprintf (wfp, " {\\f45\\cchs256 \\'c6} ");
    else if (Infix.Ident == Ident_bij)
        fprintf (wfp, " {\\f45\\cchs256 \\'c2} ");
    else if (Infix.Ident == Ident_fpartfunc)
        fprintf (wfp, " {\\f45\\cchs256 \\'b6} ");
    else if (Infix.Ident == Ident_fpartinj)
        fprintf (wfp, " {\\f45\\cchs256 \\'fa} ");
    else if (Infix.Ident == Ident_upto)
        fprintf (wfp, " .. ");
    else if (Infix.Ident == Ident_concat)
        fprintf (wfp, " {\\f45\\cchs256 \\'5e} ");
    else if (Infix.Ident == Ident_func_override)
        fprintf (wfp, " {\\f45\\cchs256 \\'b1} ");
    else if (Infix.Ident == Ident_maplet)
        fprintf (wfp, " {\\f45\\cchs256 \\'8c} ");
    else if (Infix.Ident == Ident_add)
        fprintf (wfp, " {\\f45\\cchs256 \\'2b} ");
    else if (Infix.Ident == Ident_sub)
        fprintf (wfp, " {\\f45\\cchs256 \\'2d} ");
    else if (Infix.Ident == Ident_mult)
        fprintf (wfp, " {\\f45\\cchs256 \\'2a} ");
    else if (Infix.Ident == Ident_div)
        fprintf (wfp, " div ");
    else if (Infix.Ident == Ident_mod)
        fprintf (wfp, " mod ");
    else if (Infix.Ident == Ident_expo)
        fprintf (wfp, "{\\super } ");  /* super next token ??? */
    else if (Infix.Ident == Ident_diff)
        fprintf (wfp, " {\\f45\\cchs256 \\'5c} ");
    else if (Infix.Ident == Ident_b_compose)
        fprintf (wfp, " {\\f45\\cchs256 \\'3b} ");
    else if (Infix.Ident == Ident_dom_restrict)
        fprintf (wfp, " {\\f45\\cchs256 \\'72} ");
    else if (Infix.Ident == Ident_ran_restrict)
        fprintf (wfp, " {\\f45\\cchs256 \\'74} ");
    else if (Infix.Ident == Ident_dom_subtract)
        fprintf (wfp, " {\\f45\\cchs256 \\'79} ");
    else if (Infix.Ident == Ident_ran_subtract)
        fprintf (wfp, " {\\f45\\cchs256 \\'75} ");
    else if (Infix.Ident == Ident_union)
        fprintf (wfp, " {\\f45\\cchs256 \\'55} ");
    else if (Infix.Ident == Ident_inter)
        fprintf (wfp, " {\\f45\\cchs256 \\'49} ");
    else if (Infix.Ident == Ident_bag_union)
        fprintf (wfp, " {\\f45\\cchs256 \\'c5} ");
/* wj -- include sym_diff */
    else if (Infix.Ident == Ident_sym_diff)
	fprintf(wfp," ~ ");  

    SumWForm (Op2);
}

void WF_FncApplication(Fnc, Arg)
    tTree Fnc, Arg;
{
	if (Fnc->Kind == kVariable &&
		Fnc->Variable.IdList->Id.Next->Kind == kNoId) {

		if (Fnc->Variable.IdList->Id.Ident.Ident == Ident_inverse ||
			Fnc->Variable.IdList->Id.Ident.Ident == Ident_iter ||
			Fnc->Variable.IdList->Id.Ident.Ident == Ident_t_closure ||
			Fnc->Variable.IdList->Id.Ident.Ident == Ident_rt_closure) {

			WF_ExpList (Arg);
			SumWForm (Fnc);
			return;
		}
	}

	SumWForm (Fnc);
	fprintf (wfp, "(");
	WF_ExpList (Arg);
	fprintf (wfp, ")");
}

void WF_SetComp (SchemaText, Exp)
    tTree SchemaText, Exp;
{
    fprintf (wfp, "{\\f45\\cchs256 \\'7b}");
    SumWForm (SchemaText);
/*    if (PredList->Kind != kNoPred) {
  *        WF_PrintIndent(PredList->Id.Ident.Pos); *
        fprintf (wfp, "{\\f45\\cchs256 \\'7c} ");
        WF_SemicolonPredList (PredList);
    } */
    if (Exp->Kind != kNoExp) {
       fprintf (wfp, " {\\f45\\cchs256 \\'a5} ");
       SumWForm(Exp);
    }
    fprintf (wfp, "{\\f45\\cchs256 \\'7d}");
}

void WF_SetElab (ExpressionList)
    tTree ExpressionList;
{
    if (ExpressionList->Kind == kNoExp)
        fprintf (wfp, "{\\f45\\cchs256 \\'7b \\'7d}");
    else {
        fprintf (wfp, "{\\f45\\cchs256 \\'7b}");
        WF_ExpList (ExpressionList);
        fprintf (wfp, "{\\f45\\cchs256 \\'7d}");
    }
}

void WF_Sequence (ExpressionList)
    tTree ExpressionList;
{
    if (ExpressionList->Kind == kNoExp)
        fprintf (wfp, "{\\f45\\cchs256 \\'e3\\'f1} ");
    else {
        fprintf (wfp, "{\\f45\\cchs256 \\'e3} ");
        WF_ExpList (ExpressionList);
        fprintf (wfp, "{\\f45\\cchs256 \\'f1} ");
    }
}

void WF_Tuple (ExpressionList)
    tTree ExpressionList;
{
    fprintf (wfp, "(");
    WF_ExpList (ExpressionList);
    fprintf (wfp, ")");
}

void WF_Bag (ExpressionList)
    tTree ExpressionList;
{
    if (ExpressionList->Kind == kNoExp)
        fprintf (wfp, "{\\f45\\cchs256 \\'d2\\'d4} ");
    else {
        fprintf (wfp, "{\\f45\\cchs256 \\'d2} ");
        WF_ExpList (ExpressionList);
        fprintf (wfp, "{\\f45\\cchs256 \\'d4} ");
    }
}

void WF_IfExp (Con, Then, Else)
    tTree Con, Then, Else;
{
/* wj -- attempt to break up long lines in if expressions */
     fprintf(wfp,"if ");
     	WF_IncIndent();
     	SumWForm (Con);
     	WF_DecIndent();
     WF_ForcePrintIndent(Con->Pred.Pos);
     fprintf(wfp,"then ");
     	WF_IncIndent();
     	WF_ForcePrintIndent(Then->Exp.Pos);
     	SumWForm(Then);
     	WF_DecIndent();
     	WF_ForcePrintIndent(Then->Exp.Pos);
     fprintf(wfp,"else");
     	WF_IncIndent();
     	WF_ForcePrintIndent(Else->Exp.Pos);
     	SumWForm(Else);
     	WF_DecIndent();
     	WF_ForcePrintIndent(Else->Exp.Pos);
     fprintf(wfp,"fi");
}

void WF_CartProd (ExpressionList)
    tTree ExpressionList;
{
    tTree explist=ExpressionList;

    for (; explist && explist->Kind != kNoExp; explist=explist->Exp.Next) {
        SumWForm (explist);
        if (explist->Exp.Next->Kind != kNoExp)
            fprintf (wfp, " {\\f45\\cchs256 \\'78} ");
    }
}

void WF_VarSelection (Exp, Ident)
    tTree Exp;
    tIdPos Ident;
{
    char idstr[IDENT_LENGTH];

    mygetstr (Ident.Ident, idstr);
    SumWForm (Exp);
    WF_PrintIndent(Ident.Pos);
    fprintf (wfp, "{\\i .%s}", idstr);
}

void WF_Lambda (SchemaText, Exp)
	tTree SchemaText, Exp;
{
	fprintf (wfp, " {\\f45\\cchs256 \\'6c} ");
	SumWForm (SchemaText);
	fprintf (wfp, " {\\f45\\cchs256 \\'a5} ");
	SumWForm  (Exp);
}

void WF_Mu (SchemaText, Exp)
	tTree SchemaText, Exp;
{
	fprintf (wfp, " {\\f45\\cchs256 \\'6d} ");
	SumWForm (SchemaText);
	if (Exp->Kind != kNoExp){
           fprintf (wfp, " {\\f45\\cchs256 \\'a5} ");
	   SumWForm (Exp);
        }
}

void WF_RecDisp (SchemaText, PredList)
	tTree SchemaText, PredList;
{
	/* fprintf (wfp, " {\\f45\\cchs256 \\'6d} "); */
        fprintf(wfp, " record ");
	SumWForm (SchemaText);
	fprintf (wfp, " {\\f45\\cchs256 \\'a5} ");
	WF_PredList (PredList);
}



static void yyExit () { Exit (1); }

void (* rtf_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module rtf, routine %s failed\n", yyFunction);
 rtf_Exit ();
}

void SumWForm ARGS((tTree t));

void SumWForm
# if defined __STDC__ | defined __cplusplus
(register tTree t)
# else
(t)
 register tTree t;
# endif
{

  switch (t->Kind) {
  case kSum:
/* line 1272 "rtf.puma" */
  {
/* line 1273 "rtf.puma" */
   WF_ModList (t->Sum.ModuleList);
  }
   return;

  case kModule:
/* line 1276 "rtf.puma" */
  {
/* line 1277 "rtf.puma" */
   WF_Module (t->Module.Ident, t->Module.FormalParams, t->Module.DeclList);
  }
   return;

  case kVarDecl:
/* line 1280 "rtf.puma" */
  {
/* line 1281 "rtf.puma" */
   WF_VarDecl (t->VarDecl.IdList, t->VarDecl.Exp);
  }
   return;

  case kGivenSet:
/* line 1283 "rtf.puma" */
  {
/* line 1284 "rtf.puma" */
   WF_GivenSet (t->GivenSet.IdList);
  }
   return;

  case kAxiomDecl:
/* line 1286 "rtf.puma" */
  {
/* line 1287 "rtf.puma" */
   WF_AxiomDecl (t->AxiomDecl.FormalParams, t->AxiomDecl.DeclList, t->AxiomDecl.PredList);
  }
   return;

  case kSchemaDef:
/* line 1289 "rtf.puma" */
  {
/* line 1290 "rtf.puma" */
   WF_SchemaDef (t->SchemaDef.Ident, t->SchemaDef.FormalParams, t->SchemaDef.DeclList, t->SchemaDef.PredList, t->SchemaDef.IsOp);
  }
   return;

  case kAbbreviation:
/* line 1292 "rtf.puma" */
  {
/* line 1293 "rtf.puma" */
   WF_Abbr (t->Abbreviation.Ident, t->Abbreviation.Exp);
  }
   return;

  case kImport:
/* line 1295 "rtf.puma" */
  {
/* line 1296 "rtf.puma" */
   WF_Import (t->Import.Ident, t->Import.ExpressionList, t->Import.RenameList, t->Import.NewIdent);
  }
   return;

  case kModuleDecl:
/* line 1298 "rtf.puma" */
  {
/* line 1299 "rtf.puma" */
   SumWForm (t->ModuleDecl.Module);
  }
   return;

  case kFreeType:
/* line 1301 "rtf.puma" */
  {
/* line 1302 "rtf.puma" */
   WF_FreeType (t->FreeType.Ident, t->FreeType.BranchList);
  }
   return;

  case kConstraint:
/* line 1304 "rtf.puma" */
  {
/* line 1305 "rtf.puma" */
   SumWForm (t->Constraint.Pred);
  }
   return;

  case kSchemaIncl:
/* line 1307 "rtf.puma" */
  {
/* line 1307 "rtf.puma" */

        if (t->SchemaIncl.ExpressionList->Kind != kNoExp)
            WF_Exp_SchemaRef (t->SchemaIncl.IdList, t->SchemaIncl.ExpressionList);
        else {
            char idstr[IDENT_LENGTH]; 

            Unparse_Name (t->SchemaIncl.IdList, idstr);
            fprintf (wfp, "%s", idstr);
        }
    
  }
   return;

  case kVisibility:
/* line 1318 "rtf.puma" */
  {
/* line 1319 "rtf.puma" */
   WF_Visible (t->Visibility.Ident, t->Visibility.SelectionList);
  }
   return;

  case kErgoAnno:
/* line 1321 "rtf.puma" */
   return;

  case kNoPred:
/* line 1324 "rtf.puma" */
   return;

  case kQuantPred:
/* line 1326 "rtf.puma" */
  {
/* line 1327 "rtf.puma" */
   WF_QuantPred (t->QuantPred.LogQuant, t->QuantPred.SchemaText, t->QuantPred.Pred);
  }
   return;

  case kRelBinPred:
/* line 1329 "rtf.puma" */
  {
/* line 1330 "rtf.puma" */
   WF_RelBinPred (t->RelBinPred.L, t->RelBinPred.RelBinOp, t->RelBinPred.R);
  }
   return;

  case kRelPrePred:
/* line 1332 "rtf.puma" */
  {
/* line 1333 "rtf.puma" */
   WF_RelPrePred (t->RelPrePred.RelPreOp, t->RelPrePred.Exp);
  }
   return;

  case kLogBinPred:
/* line 1335 "rtf.puma" */
  {
/* line 1336 "rtf.puma" */
   WF_LogBinPred (t->LogBinPred.L, t->LogBinPred.LogBinOp, t->LogBinPred.R);
  }
   return;

  case kLogicalNot:
/* line 1338 "rtf.puma" */
  {
/* line 1339 "rtf.puma" */
   WF_PrintIndent (t->LogicalNot.Pos);
/* line 1340 "rtf.puma" */
   WF_LogicalNot (t->LogicalNot.Pred);
  }
   return;

  case kPreCondPred:
/* line 1342 "rtf.puma" */
  {
/* line 1343 "rtf.puma" */
   WF_PrintIndent (t->PreCondPred.Pos);
/* line 1344 "rtf.puma" */
   WF_PreCondPred (t->PreCondPred.Pred);
  }
   return;

  case kChgOnly:
/* line 1346 "rtf.puma" */
  {
/* line 1347 "rtf.puma" */
   WF_PrintIndent (t->ChgOnly.Pos);
/* line 1348 "rtf.puma" */
   WF_ChgOnly (t->ChgOnly.NameList);
  }
   return;

  case kSchemaPred:
/* line 1350 "rtf.puma" */
  {
/* line 1351 "rtf.puma" */
   SumWForm (t->SchemaPred.Schema);
  }
   return;

  case kBoolValue:
/* line 1353 "rtf.puma" */
  {
/* line 1354 "rtf.puma" */
   WF_BoolValue (t->BoolValue.Ident);
  }
   return;

  case kExpPred:
/* line 1357 "rtf.puma" */
  {
/* line 1358 "rtf.puma" */
   SumWForm (t->ExpPred.Exp);
  }
   return;

  case kSchemaText:
/* line 1360 "rtf.puma" */
  {
/* line 1361 "rtf.puma" */
   WF_SchemaText (t->SchemaText.DeclList, t->SchemaText.PredList, t->SchemaText.Is_local_dec);
  }
   return;

  case kSchemaCompos:
/* line 1363 "rtf.puma" */
  {
/* line 1364 "rtf.puma" */
   WF_SchemaCompos (t->SchemaCompos.Sch1, t->SchemaCompos.Sch2);
  }
   return;

  case kSchemaHiding:
/* line 1366 "rtf.puma" */
  {
/* line 1367 "rtf.puma" */
   WF_SchemaHiding (t->SchemaHiding.Schema, t->SchemaHiding.NameList);
  }
   return;

  case kSchemaProj:
/* line 1369 "rtf.puma" */
  {
/* line 1370 "rtf.puma" */
   WF_SchemaProj (t->SchemaProj.Sch1, t->SchemaProj.Proj, t->SchemaProj.Sch2);
  }
   return;

  case kSchemaSubst:
/* line 1372 "rtf.puma" */
  {
/* line 1373 "rtf.puma" */
   WF_SchemaSubst (t->SchemaSubst.Schema, t->SchemaSubst.RenameList);
  }
   return;

  case kVariable:
/* line 1376 "rtf.puma" */
  {
/* line 1377 "rtf.puma" */
   WF_Variable (t->Variable.IdList);
  }
   return;

  case kLiteral:
/* line 1379 "rtf.puma" */
  {
/* line 1380 "rtf.puma" */
   WF_Literal (t->Literal.Literal);
  }
   return;

  case kString:
/* line 1382 "rtf.puma" */
  {
/* line 1383 "rtf.puma" */
   WF_Literal (t->String.String);
  }
   return;

  case kChar:
/* line 1385 "rtf.puma" */
  {
/* line 1386 "rtf.puma" */
   WF_Literal (t->Char.Char);
  }
   return;

  case kPrefixOp:
/* line 1388 "rtf.puma" */
  {
/* line 1389 "rtf.puma" */
   WF_PrefixOp (t->PrefixOp.Prefix, t->PrefixOp.Exp);
  }
   return;

  case kInfixOp:
/* line 1391 "rtf.puma" */
  {
/* line 1392 "rtf.puma" */
   WF_InfixOp (t->InfixOp.Op1, t->InfixOp.Infix, t->InfixOp.Op2);
  }
   return;

  case kFncApplication:
/* line 1395 "rtf.puma" */
  {
/* line 1396 "rtf.puma" */
   WF_FncApplication (t->FncApplication.Fnc, t->FncApplication.Arg);
  }
   return;

  case kSetComp:
/* line 1398 "rtf.puma" */
  {
/* line 1399 "rtf.puma" */
   WF_PrintIndent (t->SetComp.Pos);
/* line 1400 "rtf.puma" */
   WF_SetComp (t->SetComp.SchemaText, t->SetComp.ExpressionList);
  }
   return;

  case kSetElab:
/* line 1402 "rtf.puma" */
  {
/* line 1403 "rtf.puma" */
   WF_PrintIndent (t->SetElab.Pos);
/* line 1404 "rtf.puma" */
   WF_SetElab (t->SetElab.ExpressionList);
  }
   return;

  case kSequence:
/* line 1406 "rtf.puma" */
  {
/* line 1407 "rtf.puma" */
   WF_PrintIndent (t->Sequence.Pos);
/* line 1408 "rtf.puma" */
   WF_Sequence (t->Sequence.ExpressionList);
  }
   return;

  case kTuple:
/* line 1410 "rtf.puma" */
  {
/* line 1411 "rtf.puma" */
   WF_PrintIndent (t->Tuple.Pos);
/* line 1412 "rtf.puma" */
   WF_Tuple (t->Tuple.ExpressionList);
  }
   return;

  case kBag:
/* line 1414 "rtf.puma" */
  {
/* line 1415 "rtf.puma" */
   WF_PrintIndent (t->Bag.Pos);
/* line 1416 "rtf.puma" */
   WF_Bag (t->Bag.ExpressionList);
  }
   return;

  case kIfExp:
/* line 1418 "rtf.puma" */
  {
/* line 1420 "rtf.puma" */
   WF_IfExp (t->IfExp.Con, t->IfExp.Then, t->IfExp.Else);
  }
   return;

  case kCartProd:
/* line 1422 "rtf.puma" */
  {
/* line 1423 "rtf.puma" */
   WF_PrintIndent (t->CartProd.Pos);
/* line 1424 "rtf.puma" */
   WF_CartProd (t->CartProd.ExpressionList);
  }
   return;

  case kVarSelection:
/* line 1426 "rtf.puma" */
  {
/* line 1427 "rtf.puma" */
   WF_VarSelection (t->VarSelection.Exp, t->VarSelection.Ident);
  }
   return;

  case kTupSelection:
/* line 1429 "rtf.puma" */
  {
/* line 1430 "rtf.puma" */
   WF_VarSelection (t->TupSelection.Exp, t->TupSelection.Number);
  }
   return;

  case kExp_SchemaRef:
/* line 1432 "rtf.puma" */
  {
/* line 1433 "rtf.puma" */
   WF_Exp_SchemaRef (t->Exp_SchemaRef.IdList, t->Exp_SchemaRef.ExpressionList);
  }
   return;

  case kPredExp:
/* line 1435 "rtf.puma" */
  {
/* line 1436 "rtf.puma" */
   WF_PredExp (t->PredExp.Pred);
  }
   return;

  case kLambda:
/* line 1438 "rtf.puma" */
  {
/* line 1439 "rtf.puma" */
   WF_PrintIndent (t->Lambda.Pos);
/* line 1440 "rtf.puma" */
   WF_Lambda (t->Lambda.SchemaText, t->Lambda.Exp);
  }
   return;

  case kMu:
/* line 1442 "rtf.puma" */
  {
/* line 1443 "rtf.puma" */
   WF_PrintIndent (t->Mu.Pos);
/* line 1444 "rtf.puma" */
   WF_Mu (t->Mu.SchemaText, t->Mu.ExpressionList);
  }
   return;

  case kRecDisp:
/* line 1446 "rtf.puma" */
  {
/* line 1447 "rtf.puma" */
   WF_PrintIndent (t->RecDisp.Pos);
/* line 1448 "rtf.puma" */
   WF_RecDisp (t->RecDisp.SchemaText, t->RecDisp.PredList);
  }
   return;

  }

;
}

void Beginrtf ()
{
/* line 7 "rtf.puma" */



}

void Closertf ()
{
}
