# ifndef yySumAbs2SumAscii
# define yySumAbs2SumAscii

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "Tree.h"

/* line 9 "sumabs2sum.puma" */

#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "SumTreeAccess.h"
#include "env.h"


extern void (* SumAbs2SumAscii_Exit) ();

extern void UnparseSum ARGS((tTree yyP1, tString str, tString str2));
extern void UnparseIdList ARGS((tTree yyP6));

extern void BeginSumAbs2SumAscii ();
extern void CloseSumAbs2SumAscii ();

# endif
