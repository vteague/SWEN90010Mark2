# ifndef yyZScanner
# define yyZScanner

/* $Id: Scanner.h,v 2.6 1992/08/07 15:29:41 grosch rel $ */

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

/* line 3 "ZScanner.rex" */

#include "Positions.h"
#include "Idents.h"
#include "global.h"
#include "env.h"
#define Debug
#define maxlen 50 /* limit of word size */

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

typedef struct { tPosition yyPos; tIdPos IdPos; } yyInFun1;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyInFun2;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyInFun3;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyInFun4;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyInFun5;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyInFun6;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyInRel;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyInGen;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyInGenL;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyPreRel;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyPreGen;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyPostFun;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyWord;
typedef struct { tPosition yyPos; tIdPos IdPos; } yyNumber;

typedef union {
 tPosition Position;
 yyInFun1 InFun1;
 yyInFun2 InFun2;
 yyInFun3 InFun3;
 yyInFun4 InFun4;
 yyInFun5 InFun5;
 yyInFun6 InFun6;
 yyInRel InRel;
 yyInGen InGen;
 yyInGenL InGenL;
 yyPreRel PreRel;
 yyPreGen PreGen;
 yyPostFun PostFun;
 yyWord Word;
 yyNumber Number;
} ZScanner_tScanAttribute;

extern void ZScanner_ErrorAttribute ARGS((int Token, ZScanner_tScanAttribute * pAttribute));


 
# define ZScanner_EofToken	0
 
# ifdef lex_interface
#    define ZScanner_GetToken	yylex
#    define ZScanner_TokenLength	yyleng
# endif

extern	char *		ZScanner_TokenPtr	;
extern	short		ZScanner_TokenLength	;
extern	ZScanner_tScanAttribute	ZScanner_Attribute	;
extern	void		(* ZScanner_Exit) ()	;
 
extern	void		ZScanner_BeginScanner	();
extern	void		ZScanner_BeginFile	ARGS ((char * yyFileName));
extern	int		ZScanner_GetToken	();
extern	int		ZScanner_GetWord		ARGS ((char * yyWord));
extern	int		ZScanner_GetLower	ARGS ((char * yyWord));
extern	int		ZScanner_GetUpper	ARGS ((char * yyWord));
extern	void		ZScanner_CloseFile	();
extern	void		ZScanner_CloseScanner	();

# endif
