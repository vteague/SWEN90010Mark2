# include "DecodeType.h"
# include "yyDecodeType.w"
# include "System.h"
# include <stdio.h>
# include "Type.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 17 "decodetype.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "env.h"
#include "Type.h"
#ifdef TKGUI
  #define fileptr stdout
#else
  #define fileptr stderr
#endif


static void yyExit () { Exit (1); }

void (* DecodeType_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module DecodeType, routine %s failed\n", yyFunction);
 DecodeType_Exit ();
}

void DecodeType ARGS((tType t));
static void DecodeTpExp ARGS((tType t));
static void DecodeTpSchFieldList ARGS((tType s));
void DecodeTpCartList ARGS((tType c, char ch));
void DecodeTpCartListOver ARGS((tType c));
static bool IsInfun ARGS((tIdent id));
static bool IsIngen ARGS((tIdent id));
static bool NeedsPrefixBrackets ARGS((tType yyP1));
static bool NeedsInFunBrackets ARGS((tType yyP2));
static bool NeedsCrossBrackets ARGS((tType yyP3));
static bool NeedsInGenBrackets ARGS((tType yyP4));

void DecodeType
# if defined __STDC__ | defined __cplusplus
(register tType t)
# else
(t)
 register tType t;
# endif
{
  if (Type_IsType (t, kTp_Exp)) {
/* line 38 "decodetype.puma" */
  {
/* line 39 "decodetype.puma" */
DecodeTpExp(t);
		fprintf(fileptr," ");
  }
   return;

  }
  if (Type_IsType (t, kTp_SchFieldList)) {
/* line 41 "decodetype.puma" */
  {
/* line 42 "decodetype.puma" */
DecodeTpSchFieldList(t);
		fprintf(fileptr," ");
  }
   return;

  }
  if (Type_IsType (t, kTp_CartList)) {
/* line 44 "decodetype.puma" */
  {
/* line 45 "decodetype.puma" */
DecodeTpCartList(t,'X');
		fprintf(fileptr," ");
  }
   return;

  }
/* line 47 "decodetype.puma" */
   return;

;
}

static void DecodeTpExp
# if defined __STDC__ | defined __cplusplus
(register tType t)
# else
(t)
 register tType t;
# endif
{

  switch (t->Kind) {
  case kTp_Poly:
/* line 51 "decodetype.puma" */
  {
/* line 52 "decodetype.puma" */
fprintf(fileptr,"poly ");
		WriteIdent(fileptr,t->Tp_Poly.Ident);
  }
   return;

  case kTp_Base:
/* line 54 "decodetype.puma" */
  {
/* line 55 "decodetype.puma" */
WriteIdent(fileptr,t->Tp_Base.Ident);
  }
   return;

  case kTp_Power:
/* line 56 "decodetype.puma" */
  {
/* line 57 "decodetype.puma" */
fprintf(fileptr,"power ");
		if (NeedsPrefixBrackets(t->Tp_Power.Tp_Exp))
			{fprintf(fileptr,"( ");
			DecodeTpExp(t->Tp_Power.Tp_Exp);
			fprintf(fileptr," ) ");}
		else
			DecodeTpExp(t->Tp_Power.Tp_Exp);
  }
   return;

  case kTp_Seq:
/* line 64 "decodetype.puma" */
  {
/* line 65 "decodetype.puma" */
fprintf(fileptr,"sequence of ");
		if (NeedsPrefixBrackets(t->Tp_Seq.Tp_Exp))
			{fprintf(fileptr,"( ");
			DecodeTpExp(t->Tp_Seq.Tp_Exp);
			fprintf(fileptr," ) ");}
		else
			DecodeTpExp(t->Tp_Seq.Tp_Exp);
  }
   return;

  case kTp_Prefix:
/* line 72 "decodetype.puma" */
  {
/* line 73 "decodetype.puma" */
WriteIdent(fileptr,t->Tp_Prefix.Ident);
		if (NeedsPrefixBrackets(t->Tp_Prefix.Tp_Exp))
			{fprintf(fileptr," ( ");
			DecodeTpExp(t->Tp_Prefix.Tp_Exp);
			fprintf(fileptr," ) ");}
		else
			DecodeTpExp(t->Tp_Prefix.Tp_Exp);
  }
   return;

  case kTp_Infix:
/* line 80 "decodetype.puma" */
  {
/* line 81 "decodetype.puma" */
if (IsInfun(t->Tp_Infix.Ident))
			if (NeedsInFunBrackets(t->Tp_Infix.Fst))
				{fprintf(fileptr," ( ");
				DecodeTpExp(t->Tp_Infix.Fst);
				fprintf(fileptr," ) ");}
			else
				DecodeTpExp(t->Tp_Infix.Fst);
		else if (IsIngen(t->Tp_Infix.Ident))
			if (NeedsInGenBrackets(t->Tp_Infix.Fst))
				{fprintf(fileptr," ( ");
				DecodeTpExp(t->Tp_Infix.Fst);
				fprintf(fileptr," ) ");}
			else
				DecodeTpExp(t->Tp_Infix.Fst);
		else DecodeTpExp(t->Tp_Infix.Fst);
		fprintf(fileptr," ");
		WriteIdent(fileptr,t->Tp_Infix.Ident);
		fprintf(fileptr," ");
		if (IsInfun(t->Tp_Infix.Ident))
			if (NeedsInFunBrackets(t->Tp_Infix.Snd))
				{fprintf(fileptr,"( ");
				DecodeTpExp(t->Tp_Infix.Snd);
				fprintf(fileptr," ) ");}
			else
				DecodeTpExp(t->Tp_Infix.Snd);
		else if (IsIngen(t->Tp_Infix.Ident))
			if (NeedsInGenBrackets(t->Tp_Infix.Snd))
				{fprintf(fileptr,"( ");
				DecodeTpExp(t->Tp_Infix.Snd);
				fprintf(fileptr," ) ");}
			else
				DecodeTpExp(t->Tp_Infix.Snd);
		else DecodeTpExp(t->Tp_Infix.Snd);
  }
   return;

  case kTp_CartProd:
/* line 114 "decodetype.puma" */
  {
/* line 115 "decodetype.puma" */
DecodeTpCartList(t->Tp_CartProd.Tp_CartList,'X');
  }
   return;

  case kTp_Schema:
/* line 116 "decodetype.puma" */
  {
/* line 117 "decodetype.puma" */
DecodeTpSchFieldList(t->Tp_Schema.Tp_SchFieldList);
  }
   return;

  case kTp_Err:
/* line 118 "decodetype.puma" */
  {
/* line 118 "decodetype.puma" */
fprintf(fileptr," ill-typed");
  }
   return;

  case kTp_Any:
/* line 119 "decodetype.puma" */
  {
/* line 119 "decodetype.puma" */
fprintf(fileptr," any type");
  }
   return;

  }

/* line 120 "decodetype.puma" */
  {
/* line 121 "decodetype.puma" */
WriteIdent(fileptr,t->Tp_Exp.Ident);
  }
   return;

;
}

static void DecodeTpSchFieldList
# if defined __STDC__ | defined __cplusplus
(register tType s)
# else
(s)
 register tType s;
# endif
{
  if (s->Kind == kTp_NoSchField) {
/* line 125 "decodetype.puma" */
   return;

  }
  if (s->Kind == kTp_SchField) {
/* line 126 "decodetype.puma" */
  {
/* line 127 "decodetype.puma" */
WriteIdent(fileptr,s->Tp_SchField.Ident);
		fprintf(fileptr,":");
		DecodeTpExp(s->Tp_SchField.Tp_Exp);
		if (Type_IsType(s->Tp_SchField.Next,kTp_SchField))
			{fprintf(fileptr,"; ");
			DecodeTpSchFieldList(s->Tp_SchField.Next);}
  }
   return;

  }
;
}

void DecodeTpCartList
# if defined __STDC__ | defined __cplusplus
(register tType c, char ch)
# else
(c, ch)
 register tType c;
 char ch;
# endif
{
  if (c->Kind == kTp_NoCart) {
/* line 136 "decodetype.puma" */
   return;

  }
  if (c->Kind == kTp_Cart) {
/* line 137 "decodetype.puma" */
  {
/* line 138 "decodetype.puma" */
if (NeedsCrossBrackets(c->Tp_Cart.Tp_Exp))
			{fprintf(fileptr," ( ");
			DecodeTpExp(c->Tp_Cart.Tp_Exp);
			fprintf(fileptr," ) ");}
		else
			DecodeTpExp(c->Tp_Cart.Tp_Exp);
		if (Type_IsType(c->Tp_Cart.Next,kTp_Cart))
			{if (ch=='X')
				fprintf(fileptr," cross ");
			else fprintf(fileptr," %c ",ch);
			DecodeTpCartList(c->Tp_Cart.Next,ch);}
  }
   return;

  }
;
}

void DecodeTpCartListOver
# if defined __STDC__ | defined __cplusplus
(register tType c)
# else
(c)
 register tType c;
# endif
{
  if (c->Kind == kTp_NoCart) {
/* line 152 "decodetype.puma" */
   return;

  }
  if (c->Kind == kTp_Cart) {
/* line 153 "decodetype.puma" */
  {
/* line 154 "decodetype.puma" */
DecodeTpExp(c->Tp_Cart.Tp_Exp);
		if (Type_IsType(c->Tp_Cart.Next,kTp_Cart))
			{fprintf(fileptr," OR\n                     ");
			DecodeTpCartListOver(c->Tp_Cart.Next);}
  }
   return;

  }
;
}

static bool IsInfun
# if defined __STDC__ | defined __cplusplus
(tIdent id)
# else
(id)
 tIdent id;
# endif
{
/* line 166 "decodetype.puma" */
int ok=0;
/* line 167 "decodetype.puma" */
  {
/* line 168 "decodetype.puma" */
char str[IDENT_LENGTH];
	GetString(id,str);
	if (strcmp(str,"..")) ok=1;
	else if (strcmp(str,"^")) ok=1;
	else if (strcmp(str,"|-->")) ok=1;
	else if (strcmp(str,"bag_union")) ok=1;
	else if (strcmp(str,"inter")) ok=1;
	else if (strcmp(str,"union")) ok=1;
	else if (strcmp(str,"diff")) ok=1;
	else if (strcmp(str,"f_compose")) ok=1;
        else if (strcmp(str,"b_compose")) ok=1;
	else if (strcmp(str,"func_override")) ok=1;
	else if (strcmp(str,"dom_restrict")) ok=1;
	else if (strcmp(str,"ran_restrict")) ok=1;
	else if (strcmp(str,"dom_subtract")) ok=1;
	else if (strcmp(str,"ran_subtract")) ok=1;
/* line 184 "decodetype.puma" */
   if (! ((ok == 1))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

static bool IsIngen
# if defined __STDC__ | defined __cplusplus
(tIdent id)
# else
(id)
 tIdent id;
# endif
{
/* line 188 "decodetype.puma" */
int ok=0;
/* line 189 "decodetype.puma" */
  {
/* line 190 "decodetype.puma" */
char str[IDENT_LENGTH];
	GetString(id,str);
	if (strcmp(str,"<-->")) ok=1;
	else if (strcmp(str,"-|->")) ok=1;
	else if (strcmp(str,"-->")) ok=1;
	else if (strcmp(str,">-|->")) ok=1;
	else if (strcmp(str,">-->")) ok=1;
	else if (strcmp(str,"-|->>")) ok=1;
	else if (strcmp(str,"-->>")) ok=1;
	else if (strcmp(str,">-->>")) ok=1;
	else if (strcmp(str,"-||->")) ok=1;
	else if (strcmp(str,">-||->")) ok=1;
/* line 202 "decodetype.puma" */
   if (! ((ok == 1))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

static bool NeedsPrefixBrackets
# if defined __STDC__ | defined __cplusplus
(register tType yyP1)
# else
(yyP1)
 register tType yyP1;
# endif
{
  if (yyP1->Kind == kTp_Infix) {
/* line 208 "decodetype.puma" */
   return true;

  }
  if (yyP1->Kind == kTp_CartProd) {
/* line 209 "decodetype.puma" */
   return true;

  }
  return false;
}

static bool NeedsInFunBrackets
# if defined __STDC__ | defined __cplusplus
(register tType yyP2)
# else
(yyP2)
 register tType yyP2;
# endif
{
  if (yyP2->Kind == kTp_Infix) {
/* line 214 "decodetype.puma" */
  {
/* line 214 "decodetype.puma" */
   if (! (IsIngen (yyP2->Tp_Infix.Ident))) goto yyL1;
  }
   return true;
yyL1:;

  }
  if (yyP2->Kind == kTp_CartProd) {
/* line 215 "decodetype.puma" */
   return true;

  }
  return false;
}

static bool NeedsCrossBrackets
# if defined __STDC__ | defined __cplusplus
(register tType yyP3)
# else
(yyP3)
 register tType yyP3;
# endif
{
  if (yyP3->Kind == kTp_Infix) {
/* line 220 "decodetype.puma" */
  {
/* line 220 "decodetype.puma" */
   if (! (IsIngen (yyP3->Tp_Infix.Ident))) goto yyL1;
  }
   return true;
yyL1:;

  }
  if (yyP3->Kind == kTp_CartProd) {
/* line 221 "decodetype.puma" */
   return true;

  }
  return false;
}

static bool NeedsInGenBrackets
# if defined __STDC__ | defined __cplusplus
(register tType yyP4)
# else
(yyP4)
 register tType yyP4;
# endif
{
  if (yyP4->Kind == kTp_Infix) {
/* line 225 "decodetype.puma" */
  {
/* line 225 "decodetype.puma" */
   if (! (IsIngen (yyP4->Tp_Infix.Ident))) goto yyL1;
  }
   return true;
yyL1:;

  }
  return false;
}

void BeginDecodeType ()
{
}

void CloseDecodeType ()
{
}
