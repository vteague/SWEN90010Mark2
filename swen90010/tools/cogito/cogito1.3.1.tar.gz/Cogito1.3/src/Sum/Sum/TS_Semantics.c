# define DEP(a, b) a
# define SELF yyt
# include "TS_Semantics.h"

/* line 3581 "Type.cg" */

#include "Type.h"


static char yyb;

static void yyVisit1Tp_Exp ARGS((register tType yyt));
static void yyVisit1Tp_SchFieldList ARGS((register tType yyt));
static void yyVisit1Tp_CartList ARGS((register tType yyt));

void TS_Semantics
# if defined __STDC__ | defined __cplusplus
 (tType yyt)
# else
 (yyt) tType yyt;
# endif
{
 yyVisit1Tp_Exp (yyt); }

static void yyVisit1Tp_Exp
# if defined __STDC__ | defined __cplusplus
 (register tType yyt)
# else
 (yyt)
 register tType yyt;
# endif
{
 switch (yyt->Kind) {
case kTp_Exp: {
/* line 3648 "Type.cg" */
yyt->Tp_Exp.TyNo = 0;
/* line 3648 "Type.cg" */
 yyt->Tp_Exp.PtrToCopy = NoType;
/* line 3648 "Type.cg" */
 yyt->Tp_Exp.IsTypeExp = false;
} break;
case kTp_Poly: {
/* line 3648 "Type.cg" */
yyt->Tp_Poly.TyNo = 0;
/* line 3648 "Type.cg" */
 yyt->Tp_Poly.PtrToCopy = NoType;
/* line 3648 "Type.cg" */
 yyt->Tp_Poly.IsTypeExp = false;
} break;
case kTp_Err: {
/* line 3648 "Type.cg" */
yyt->Tp_Err.TyNo = 0;
/* line 3648 "Type.cg" */
 yyt->Tp_Err.PtrToCopy = NoType;
/* line 3648 "Type.cg" */
 yyt->Tp_Err.IsTypeExp = false;
} break;
case kTp_Any: {
/* line 3648 "Type.cg" */
yyt->Tp_Any.TyNo = 0;
/* line 3648 "Type.cg" */
 yyt->Tp_Any.PtrToCopy = NoType;
/* line 3648 "Type.cg" */
 yyt->Tp_Any.IsTypeExp = false;
} break;
case kTp_Base: {
/* line 3648 "Type.cg" */
yyt->Tp_Base.TyNo = 0;
/* line 3648 "Type.cg" */
 yyt->Tp_Base.PtrToCopy = NoType;
/* line 3648 "Type.cg" */
 yyt->Tp_Base.IsTypeExp = false;
} break;
case kTp_Power: {
/* line 3648 "Type.cg" */
yyt->Tp_Power.TyNo = 0;
yyVisit1Tp_Exp (yyt->Tp_Power.Tp_Exp);
/* line 3648 "Type.cg" */
 yyt->Tp_Power.PtrToCopy = NoType;
/* line 3648 "Type.cg" */
 yyt->Tp_Power.IsTypeExp = false;
} break;
case kTp_Seq: {
/* line 3648 "Type.cg" */
yyt->Tp_Seq.TyNo = 0;
yyVisit1Tp_Exp (yyt->Tp_Seq.Tp_Exp);
/* line 3648 "Type.cg" */
 yyt->Tp_Seq.PtrToCopy = NoType;
/* line 3648 "Type.cg" */
 yyt->Tp_Seq.IsTypeExp = false;
} break;
case kTp_Prefix: {
/* line 3648 "Type.cg" */
yyt->Tp_Prefix.TyNo = 0;
yyVisit1Tp_Exp (yyt->Tp_Prefix.Tp_Exp);
/* line 3648 "Type.cg" */
 yyt->Tp_Prefix.PtrToCopy = NoType;
/* line 3648 "Type.cg" */
 yyt->Tp_Prefix.IsTypeExp = false;
} break;
case kTp_Infix: {
/* line 3648 "Type.cg" */
yyt->Tp_Infix.TyNo = 0;
yyVisit1Tp_Exp (yyt->Tp_Infix.Snd);
yyVisit1Tp_Exp (yyt->Tp_Infix.Fst);
/* line 3648 "Type.cg" */
 yyt->Tp_Infix.PtrToCopy = NoType;
/* line 3648 "Type.cg" */
 yyt->Tp_Infix.IsTypeExp = false;
} break;
case kTp_CartProd: {
/* line 3648 "Type.cg" */
yyt->Tp_CartProd.TyNo = 0;
yyVisit1Tp_CartList (yyt->Tp_CartProd.Tp_CartList);
/* line 3648 "Type.cg" */
 yyt->Tp_CartProd.PtrToCopy = NoType;
/* line 3648 "Type.cg" */
 yyt->Tp_CartProd.IsTypeExp = false;
} break;
case kTp_Schema: {
/* line 3648 "Type.cg" */
yyt->Tp_Schema.TyNo = 0;
yyVisit1Tp_SchFieldList (yyt->Tp_Schema.Tp_SchFieldList);
/* line 3648 "Type.cg" */
 yyt->Tp_Schema.PtrToCopy = NoType;
/* line 3648 "Type.cg" */
 yyt->Tp_Schema.IsTypeExp = false;
} break;
 default: ;
 }
}

static void yyVisit1Tp_SchFieldList
# if defined __STDC__ | defined __cplusplus
 (register tType yyt)
# else
 (yyt)
 register tType yyt;
# endif
{
 switch (yyt->Kind) {
case kTp_SchFieldList: {
} break;
case kTp_NoSchField: {
} break;
case kTp_SchField: {
/* line 3650 "Type.cg" */
yyt->Tp_SchField.Tag = false;
yyVisit1Tp_Exp (yyt->Tp_SchField.Tp_Exp);
yyVisit1Tp_SchFieldList (yyt->Tp_SchField.Next);
} break;
 default: ;
 }
}

static void yyVisit1Tp_CartList
# if defined __STDC__ | defined __cplusplus
 (register tType yyt)
# else
 (yyt)
 register tType yyt;
# endif
{
 switch (yyt->Kind) {
case kTp_CartList: {
} break;
case kTp_NoCart: {
} break;
case kTp_Cart: {
yyVisit1Tp_CartList (yyt->Tp_Cart.Next);
yyVisit1Tp_Exp (yyt->Tp_Cart.Tp_Exp);
} break;
 default: ;
 }
}

void BeginTS_Semantics ()
{
}

void CloseTS_Semantics ()
{
}
