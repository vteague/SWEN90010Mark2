# ifndef yyTrans
# define yyTrans

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "Tree.h"
# include "Type.h"

/* line 10 "Trans.puma" */

	extern void mygetstr();
	extern void Unparse_Name();


extern void (* Trans_Exit) ();

extern void CkPreCond ARGS((tTree t));
extern void TransErgo ARGS((tTree t));
extern void TransTpExp ARGS((tType t));

extern void BeginTrans ();
extern void CloseTrans ();

# endif
