# include "ZTreeAccess.h"
# include "yyZTreeAccess.w"
# include "System.h"
# include <stdio.h>
# include "ZTree.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 15 "ztree.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "env.h"


static void yyExit () { Exit (1); }

void (* ZTreeAccess_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module ZTreeAccess, routine %s failed\n", yyFunction);
 ZTreeAccess_Exit ();
}

void StrokeCat ARGS((tZTree dec, tString str));
void VarDecCat ARGS((tZTree * dec, tIdPos * id));
tIdPos IdDecCat ARGS((tIdPos id, tZTree dec));
void CatSubscriptWord ARGS((tIdPos * id1, tIdPos id2));
tPosition VarPos ARGS((tZTree yyP1));
tPosition NamePos ARGS((tZTree yyP2));
void AddDeltaDes ARGS((tZTree * d));
void AddDeltaWord ARGS((tIdPos * id));
void AddXiDes ARGS((tZTree * d));
void AddXiWord ARGS((tIdPos * id));
bool IsPre ARGS((tIdPos id));
void AddSchemaRef ARGS((tZTree * d));
bool IsEmptySet ARGS((tIdPos id));
bool IsEol ARGS((tIdPos id));
bool ThetaNotRenamed ARGS((tZTree yyP3));

void StrokeCat
# if defined __STDC__ | defined __cplusplus
(register tZTree dec, tString str)
# else
(dec, str)
 register tZTree dec;
 tString str;
# endif
{
  if (dec->Kind == knoDecoration) {
/* line 29 "ztree.puma" */
  {
/* line 29 "ztree.puma" */
*str = '\0';
  }
   return;

  }
  if (dec->Kind == kdecoration) {
/* line 30 "ztree.puma" */
  {
/* line 31 "ztree.puma" */
char s[256],s1[256];
		GetString(dec->decoration.Stroke.Ident,s);
		StrokeCat(dec->decoration.Next,s1);
		strcat(s,s1);
		strcpy(str,s);
  }
   return;

  }
;
}

void VarDecCat
# if defined __STDC__ | defined __cplusplus
(register tZTree * dec, tIdPos * id)
# else
(dec, id)
 register tZTree * dec;
 tIdPos * id;
# endif
{
  if ((* dec)->Kind == knoDecoration) {
/* line 39 "ztree.puma" */
   return;

  }
  if ((* dec)->Kind == kdecoration) {
/* line 40 "ztree.puma" */
  {
/* line 41 "ztree.puma" */
char s[256], s1[256];
		 GetString((* id).Ident,s);
		 StrokeCat((* dec),s1);
		 strcat(s,s1);
		 (* id) = ZMakeIdPos(s,(* id).Pos);
		 (* dec) = mnoDecoration(); 
  }
   return;

  }
;
}

tIdPos IdDecCat
# if defined __STDC__ | defined __cplusplus
(tIdPos id, register tZTree dec)
# else
(id, dec)
 tIdPos id;
 register tZTree dec;
# endif
{
/* line 49 "ztree.puma" */
tIdPos i;
  if (dec->Kind == kdecoration) {
/* line 50 "ztree.puma" */
  {
/* line 51 "ztree.puma" */
char s[256],s1[256];
		GetString(id.Ident,s);
		StrokeCat(dec,s1);
		strcat(s,s1);
		i = ZMakeIdPos(s,id.Pos);
  }
   return i;

  }
  if (dec->Kind == knoDecoration) {
/* line 56 "ztree.puma" */
   return id;

  }
 yyAbort ("IdDecCat");
}

void CatSubscriptWord
# if defined __STDC__ | defined __cplusplus
(tIdPos * id1, tIdPos id2)
# else
(id1, id2)
 tIdPos * id1;
 tIdPos id2;
# endif
{
/* line 61 "ztree.puma" */
  {
/* line 62 "ztree.puma" */
char str1[256],str2[256];
	GetString((* id1).Ident,str1);
	strcat(str1,"_");
	GetString(id2.Ident,str2);
	strcat(str1,str2);
	(* id1) = ZMakeIdPos(str1,(* id1).Pos);
  }
   return;

;
}

tPosition VarPos
# if defined __STDC__ | defined __cplusplus
(register tZTree yyP1)
# else
(yyP1)
 register tZTree yyP1;
# endif
{
/* line 71 "ztree.puma" */
   return yyP1->VarName.Ident . Pos;

}

tPosition NamePos
# if defined __STDC__ | defined __cplusplus
(register tZTree yyP2)
# else
(yyP2)
 register tZTree yyP2;
# endif
{
/* line 76 "ztree.puma" */
   return yyP2->ZName.Ident . Pos;

}

void AddDeltaDes
# if defined __STDC__ | defined __cplusplus
(register tZTree * d)
# else
(d)
 register tZTree * d;
# endif
{
/* line 82 "ztree.puma" */
  {
/* line 83 "ztree.puma" */
AddDeltaWord(&(* d)->Designator.ZName->ZName.Ident);
  }
   return;

;
}

void AddDeltaWord
# if defined __STDC__ | defined __cplusplus
(tIdPos * id)
# else
(id)
 tIdPos * id;
# endif
{
/* line 88 "ztree.puma" */
  {
/* line 89 "ztree.puma" */
char str1[256],str2[256];
	 str1[0] = '\0';
	 strcat(str1,"_Delta ");
	 GetString((* id).Ident,str2);
	 strcat(str1,str2);
	 (* id) = ZMakeIdPos(str1,(* id).Pos);
  }
   return;

;
}

void AddXiDes
# if defined __STDC__ | defined __cplusplus
(register tZTree * d)
# else
(d)
 register tZTree * d;
# endif
{
/* line 98 "ztree.puma" */
  {
/* line 99 "ztree.puma" */
AddXiWord(&(* d)->Designator.ZName->ZName.Ident);
  }
   return;

;
}

void AddXiWord
# if defined __STDC__ | defined __cplusplus
(tIdPos * id)
# else
(id)
 tIdPos * id;
# endif
{
/* line 104 "ztree.puma" */
  {
/* line 105 "ztree.puma" */
char str1[256],str2[256];
	 str1[0] = '\0';
	 strcat(str1,"_Xi ");
	 GetString((* id).Ident,str2);
	 strcat(str1,str2);
	 (* id) = ZMakeIdPos(str1,(* id).Pos);
  }
   return;

;
}

bool IsPre
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 113 "ztree.puma" */
int found;
/* line 114 "ztree.puma" */
  {
/* line 115 "ztree.puma" */
char str[256];
	found = 1;
	GetString(id.Ident,str);
	if (strcmp(str,"_PRE")==0)
		found = 0;
/* line 120 "ztree.puma" */
   if (! ((found == 0))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

void AddSchemaRef
# if defined __STDC__ | defined __cplusplus
(register tZTree * d)
# else
(d)
 register tZTree * d;
# endif
{
/* line 124 "ztree.puma" */
  {
/* line 125 "ztree.puma" */
(* d)->Designator.IsSchemaRef = true;
  }
   return;

;
}

bool IsEmptySet
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 128 "ztree.puma" */
int found;
/* line 129 "ztree.puma" */
  {
/* line 130 "ztree.puma" */
char str[256];
	found = 1;
	GetString(id.Ident,str);
	if (strcmp(str,"{}")==0)
		found = 0;
/* line 135 "ztree.puma" */
   if (! ((found == 0))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

bool IsEol
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 138 "ztree.puma" */
int found;
/* line 139 "ztree.puma" */
  {
/* line 140 "ztree.puma" */
char str[256];
	found = 1;
	GetString(id.Ident,str);
	if (strcmp(str,"_EOL")==0)
		found = 0;
/* line 145 "ztree.puma" */
   if (! ((found == 0))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

bool ThetaNotRenamed
# if defined __STDC__ | defined __cplusplus
(register tZTree yyP3)
# else
(yyP3)
 register tZTree yyP3;
# endif
{
  if (yyP3->Kind == knoRename) {
/* line 149 "ztree.puma" */
   return true;

  }
  return false;
}

void BeginZTreeAccess ()
{
}

void CloseZTreeAccess ()
{
}
