# include "tex.h"
# include "yytex.w"
# include "System.h"
# include <stdio.h>
# include "Tree.h"
# include "Type.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 16 "tex.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
# include "Tree.h"
# include "Syms.h"
# include "Type.h"
# include "Scanner.h"
# include "global.h"

# include "Idents.h"
# include "Positions.h"
# include "ratc.h"
# include <string.h>
# include <stdio.h>
# include <stdarg.h>
# include <ctype.h>
/* global variables within the file */



/* The list of comments extracted by the scanner to be re-inserted by 
   Graphical generators
*/

extern CppCommLink cpp_comm_head;
CppCommLink GFComm;

/* the list of tabs extracted from the input to be re-inserted
   when ever a fold is detected
*/

extern tabbing_link tabbing_head;
tabbing_link GFtabs;

/* The input Position of the last symbol printed
   Used to detect line breaks and indenting of input
   Symbols for formatting of the output

   Note the starting Position for larger abstract constructs 
   is synthesised from the closest identifier. So it isnt 
   accurate.
*/

tPosition  GFPos;


FILE *gfp;

#ifdef WIN32
extern char *SumFileName, *SumPathName, *SumSpecFile;
static FILE *fp;
static char cur_mod_name[IDENT_LENGTH];
#else
FILE *fp;
char cur_mod_name[IDENT_LENGTH];
#endif
/* Graphical Output To Latex File */

void GF_CreateFile()
{
    char gf_file[IDENT_LENGTH];


    gf_file[0] = '\0';
    /*strcat (gf_file, SumFileName); */
    strcat (gf_file, SumSpecFile);
    strcat (gf_file, ".tex"); 

    gfp = fopen (gf_file, "w");
    if (gfp == NULL) {
        fprintf (stderr, "Can't write to file: %s\n", gf_file); 
        exit(1);
    }
	/* add preamble part */
	fprintf (gfp, "\\documentstyle[11pt,oz]{article}\n");
	fprintf (gfp, "\\begin{document}\n");
        GFComm = cpp_comm_head;
        GFtabs = tabbing_head;
        GFPos = NoPosition;
}

void GF_CloseFile ()
{
	fprintf (gfp, " \n\\end{document}\n");
    fclose (gfp);
}

/* Write out any comments occuring up to Pos
   that havnt been printed already

   Further work: return flag for success to get line breaks correct.
*/ 

void GF_Comment (Pos)
    tPosition Pos;
{
    /* While comments exist before Pos, print them */
    for (;GFComm && (Compare(Pos, GFComm->pos) == 1); GFComm=GFComm->next)
        fprintf (gfp, "%s\\\\\n", GFComm->comm);
}

void GF_MathComment (Pos)
    tPosition Pos;
{
    /* While comments exist before Pos, print them */
    for (;GFComm && (Compare(Pos, GFComm->pos) == 1); GFComm=GFComm->next)
        fprintf (gfp, "\\t1\\mbox{%s}\\\\\n", GFComm->comm);
}
void GF_CommentEnd ()
{
    /* While comments exist , print them */
    for (; GFComm; GFComm=GFComm->next)
        fprintf (gfp, "%s\\\\\n", GFComm->comm);
}

/* Sets the Position of GFPos 
   Only if it is greater than it because
   some Positions are incorrectly zero
*/

void SetGFPos(Pos)
   tPosition Pos;
{
   if (Compare(Pos, GFPos) == 1)
       GFPos = Pos;
}

/* 
To be called before printing each symbol
If the line number of the next symbol is greater than the
last symbol GFPos then print a line break and 
insert any tabs found for that position in GFtabs
NOT ---up to the column of the next symbol? 
*/

void GF_tab(Pos)
    tPosition Pos;
{ 
    for (;GFtabs &&(Compare(Pos, GFtabs->pos) == 1);GFtabs = GFtabs->next)
      if (Pos.Line == GFtabs->pos.Line){
       fprintf(gfp,"%s ", GFtabs->tab); break;}
}

void GF_OptFold(Pos)
    tPosition Pos;
{
    int n = 0;

    if (Pos.Line > GFPos.Line) {
       fprintf(gfp, "\\\\ \n");
       GF_tab(Pos);
       /* for (n = Pos.Column; n > 0; n--)
         fprintf(gfp, " ");
       */
    }
    SetGFPos(Pos);
}




void extern GF_ExpList();
void extern GF_IdList();
void extern GF_DeclList();
void extern GF_PredList();
void extern GF_FormalParams();
void extern GF_SemicolonDeclList();
void extern GF_SemicolonPredList();
void extern GF_VarDecl();
void extern GF_CreateFile();
void extern GF_CloseFile();

void Latex_Name (str)
	char *str;
{
	int i, j;
	char idstr[IDENT_LENGTH]; 

	idstr[0] = '\0';
	for (i=0, j=0; i < strlen(str); i++) {
		if (str[i] == '_') {
			strncat (idstr, str+j, i-j);
			strcat (idstr, "\\_");
			j = i+1;
		}
		if (str[i] == ' ') {
			strncat (idstr, str+j, i-j);
			strcat (idstr, "\\ ");
			j = i+1;
		}
	}
	strcat (idstr, str+j); 
	str[0]='\0';
	strcat (str, idstr);
}
	
void GF_Module (Ident, FormalParams, PredList, DeclList)
    tIdPos Ident;
    tTree FormalParams;
    tTree PredList;
    tTree DeclList;
{
    char idstr[IDENT_LENGTH];

    SetGFPos(Ident.Pos);
    mygetstr (Ident.Ident, idstr);
    Latex_Name (idstr);
    if (FormalParams->Kind == kNoParam) {
        fprintf (gfp, "\\begin{class}{%s}\n\\also\n", idstr);
    }
    else {
        fprintf(gfp, "\\begin{class}{%s\\left[", idstr);
        fprintf(gfp, "\\begin{array}{@{}l@{}}");
        GF_FormalParams(FormalParams, 1);
        if (PredList->Kind != kNoPred){
           fprintf(gfp, " \\cbar ");
           GF_OptFold(PredList->Pred.Pos);
           GF_PredList(PredList);
        }
        fprintf(gfp, "\\end{array}");
        fprintf (gfp, "\\right]}\n\\also\n");
    }
    SetGFPos(DeclList->Decl.Pos);
    GF_DeclList(DeclList);
    fprintf (gfp, "\\end{class}");
}

void GF_ModList (ModuleList)
	tTree ModuleList;
{
	tTree modlist=ModuleList;

	GF_CreateFile();

	for (; modlist && modlist->Kind != kNoModule; 
		modlist=modlist->Module.Next) {

                GF_Comment(modlist->Module.Pos);
		SumGForm (modlist);
		/* ?? any space between modules */
	}
        GF_CommentEnd();
	GF_CloseFile();    
}

void GF_FormalParams (FormalParams, Tag)
    tTree FormalParams;
	bool Tag;
/* 
 * 1: module formal parameters 
 * 0: schema and axiom formal parameters
 */
{
    char idstr[IDENT_LENGTH];
    tTree paramlist=FormalParams;

    for (; paramlist && paramlist->Kind != kNoParam;
        paramlist=paramlist->Param.Next) {
        
        GF_MathComment(paramlist->Param.Pos);
        GF_OptFold(paramlist->Param.Pos);
        if (paramlist->Kind == kTyParam) {
            mygetstr (paramlist->TyParam.Ident.Ident, idstr);
			Latex_Name (idstr);
            fprintf (gfp, "%s", idstr);
        }
        else /* kFncParam = VarDecl */
            SumGForm (paramlist->FncParam.VarDecl);

        if (paramlist->Param.Next->Kind != kNoParam) {

			if (Tag)
				fprintf (gfp, "; ");
			else 
				fprintf (gfp, ", ");
		}
    }
}

/* to unparse the List (DeclList and PredList which might be in
 * Moudle, SchemaDef, etc) to Latex form separated by carriage-return.  
 */
void GF_DeclList (List)
    tTree List;
{
    tTree list=List;

    for (; list && list->Kind != kNoDecl;
        list=list->Decl.Next) {
    
        SetGFPos(list->Decl.Pos);
        GF_MathComment(list->Decl.Pos);
        SumGForm (list);
        if (list->Decl.Next->Kind != kNoDecl) {
                GF_MathComment(list->Decl.Pos);
		fprintf (gfp, " \\zbreak \n");
           }
	else {
                GF_MathComment(list->Decl.Pos);
		fprintf (gfp, " \n");
        }
    }
}

void GF_PredList (List)
    tTree List;
{
    tTree list=List;

    for (; list && list->Kind != kNoPred;
        list=list->Pred.Next) {
    
        SetGFPos(list->Pred.Pos);
        GF_MathComment(list->Pred.Pos);
        SumGForm (list);
        if (list->Pred.Next->Kind != kNoPred) {
            GF_MathComment(list->Pred.Pos);
            fprintf (gfp, " \\\\ \n");
        }
	else {
            GF_MathComment(list->Pred.Pos);
	    /* fprintf (gfp, " \n");*/
        }
    }
}

/* to unparse the list (DeclList and PredList which might be in
 * QuantPred, SchemaText, SetComp, etc) to L1; L2; ...
 */
void GF_SemicolonDeclList (List)
    tTree List;
{
    tTree list=List;

    for (; list && list->Kind != kNoDecl;
        list=list->Decl.Next) {
    
        GF_OptFold(list->Decl.Pos);
        GF_MathComment(list->Decl.Pos);
        SumGForm (list);
        if (list->Decl.Next->Kind != kNoDecl) 
            fprintf (gfp, "; ");
        
    }
}

void GF_SemicolonPredList (List)
    tTree List;
{
    tTree list=List;

    for (; list && list->Kind != kNoPred;
        list=list->Pred.Next) {
    
        GF_OptFold(list->Pred.Pos);
        GF_MathComment(list->Pred.Pos);
        SumGForm (list);
        if (list->Pred.Next->Kind != kNoPred) 
            fprintf (gfp, "; ");
    }
}

/* to print out latex names */

void GF_Name(IdList)
   tTree IdList;
{
    char idstr[IDENT_LENGTH];

    tTree idlist=IdList;
    for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) {
        mygetstr (idlist->Id.Ident.Ident, idstr);
        Latex_Name (idstr);
        fprintf (gfp, "%s", idstr); 
        if (idlist->Id.Next->Kind != kNoId)
            fprintf (gfp, ".");
    }
}


/* to unparse IdList to the form of id1, id2, ... */
void GF_IdList (IdList)
    tTree IdList;
{
    char idstr[IDENT_LENGTH];

    tTree idlist=IdList;
    for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) {
        mygetstr (idlist->Id.Ident.Ident, idstr);
	Latex_Name (idstr);
        GF_OptFold(idlist->Id.Pos);
        fprintf (gfp, "%s", idstr);
        if (idlist->Id.Next->Kind != kNoId)
            fprintf (gfp, ", ");
    }
}

void GF_RenameList (RenameList)
    tTree RenameList;
{
    tTree renamelist=RenameList;
    char oldstr[IDENT_LENGTH], newstr[IDENT_LENGTH]; 

    fprintf (gfp, "\\{");
    for (; renamelist && renamelist->Kind != kNoRename;
        renamelist=renamelist->Rename.Next) {

        mygetstr (renamelist->Rename.NewIdent.Ident, newstr);
	Latex_Name (newstr);
        Unparse_Name (renamelist->Rename.OldIdent, oldstr);
	Latex_Name (oldstr);
        GF_OptFold(renamelist->Rename.NewIdent.Pos);
        fprintf (gfp, "%s / %s", newstr, oldstr);
        if (renamelist->Rename.Next->Kind != kNoRename)
            fprintf (gfp, ", ");
    }
	fprintf (gfp, "\\}");
}

void GF_ExpList (ExpList)
    tTree ExpList;
{
    tTree explist=ExpList;

    for (; explist && explist->Kind != kNoExp;
        explist=explist->Exp.Next) {

        GF_OptFold(explist->Exp.Pos);
        SumGForm (explist);
        if (explist->Exp.Next->Kind != kNoExp)
            fprintf (gfp, ", ");
    }
}

void GF_VarDecl (IdList, Exp)
    tTree IdList, Exp;
{
    SetGFPos(IdList->Id.Pos);
    GF_IdList (IdList);
    fprintf (gfp, ": ");
    SumGForm (Exp);
}

void GF_GivenSet (IdList)
    tTree IdList;
{
    SetGFPos(IdList->Id.Pos);
    fprintf (gfp, "[");
    GF_IdList (IdList);
    fprintf (gfp, "]");
}

void GF_AxiomDecl (FormalParams, DeclList, PredList)
    tTree FormalParams, DeclList, PredList;
{
    if (FormalParams->Kind != kNoParam) {
        fprintf (gfp, "\\begin{gendef}{");
        GF_FormalParams (FormalParams, 0);
        fprintf (gfp, "}\n");
    }
    else {
        fprintf (gfp, "\\begin{axdef}\n");
    }
    SetGFPos(DeclList->Decl.Pos);
    GF_DeclList (DeclList);
    GF_MathComment(DeclList->Decl.Pos);
    if (PredList->Kind != kNoPred) {
          GF_MathComment(PredList->Pred.Pos);
 	  fprintf (gfp, "\\ST\n");
          SetGFPos(PredList->Pred.Pos);
	  GF_PredList (PredList);
    }
    if (FormalParams->Kind != kNoParam)
        fprintf (gfp, "\\end{gendef}");
    else
        fprintf (gfp, "\\end{axdef}");
}

void GF_SchemaDef (Ident, FormalParams, DeclList, PredList, IsOp)
    tIdPos Ident;
    tTree FormalParams, DeclList, PredList;
	bool IsOp;
{
    char idstr[IDENT_LENGTH];

    mygetstr (Ident.Ident, idstr);
	Latex_Name (idstr);
	if (IsOp && Ident.Ident != Ident_init)
		fprintf (gfp, "\\begin{schema}{op\\ %s", idstr); 
	else
		fprintf (gfp, "\\begin{schema}{%s", idstr); 
    if (FormalParams->Kind != kNoParam) {
        fprintf (gfp, "[");
        GF_FormalParams (FormalParams, 0);
        fprintf (gfp, "]"); 
    }
    fprintf (gfp, "}\n");
    SetGFPos(DeclList->Decl.Pos);
    GF_DeclList(DeclList);
    if (DeclList->Kind != kNoDecl && PredList->Kind != kNoPred) {
        GF_MathComment(PredList->Pred.Pos);
        fprintf (gfp, "\\ST\n");
    }
    SetGFPos(PredList->Pred.Pos);
    GF_PredList(PredList);
    fprintf (gfp, "\\end{schema}");
}

void GF_Abbr (Ident, Exp) 
    tIdPos Ident;
    tTree Exp;
{
    char idstr[IDENT_LENGTH];

    mygetstr (Ident.Ident, idstr);
	Latex_Name (idstr);
    fprintf (gfp, "%s \\defs ", idstr);
    SumGForm (Exp);
}

void GF_Import (Ident, ExpressionList, RenameList, NewIdent)
    tIdPos Ident, NewIdent;
    tTree ExpressionList, RenameList;
{
    char idstr[IDENT_LENGTH], newidstr[IDENT_LENGTH];

    mygetstr (Ident.Ident, idstr);
	Latex_Name (idstr);
    fprintf (gfp, "import\\ %s", idstr);
    if (ExpressionList->Kind != kNoExp) {
        fprintf (gfp, "(");
        GF_ExpList (ExpressionList);
        fprintf (gfp, ")");
    }
    if (RenameList->Kind != kNoRename) {
        GF_RenameList (RenameList);
    }
    if (Ident.Ident != NewIdent.Ident) {
        mygetstr (NewIdent.Ident, newidstr);
		Latex_Name (newidstr);
        fprintf (gfp, "\\ as\\ %s", newidstr);
    }
}

void GF_FreeType (Ident, BranchList) 
    tIdPos Ident;
    tTree BranchList;
{
    char idstr[IDENT_LENGTH];
    tTree blist=BranchList;
 
    SetGFPos(Ident.Pos);
    mygetstr (Ident.Ident, idstr);
	Latex_Name (idstr);
    fprintf (gfp, "%s \\ddef ", idstr);
    for (; blist && blist->Kind != kNoBranch; blist=blist->Branch.Next) {

        if (blist->Kind == kFTConstant) {
            GF_OptFold(blist->FTConstant.Ident.Pos);
            mygetstr (blist->FTConstant.Ident.Ident, idstr); 
			Latex_Name (idstr);
            fprintf (gfp, "%s", idstr);
        }
        else { /* FTConstructor */
            mygetstr (blist->FTConstructor.Ident.Ident, idstr);
			Latex_Name (idstr);
            fprintf (gfp, "%s \\lang ", idstr);
            SumGForm (blist->FTConstructor.Exp);
            fprintf (gfp, "\\rang ");
        }
        if (blist->Branch.Next->Kind != kNoBranch)
            fprintf (gfp, "\\bbar ");
    }
}


void GF_Enum (Ident, BranchList)
    tIdPos Ident;
    tTree BranchList;
{
    char idstr[IDENT_LENGTH];
    tTree blist=BranchList;
 
    SetGFPos(Ident.Pos);
    mygetstr (Ident.Ident, idstr);
	Latex_Name (idstr);
    fprintf (gfp, "%s \\ddef enum(", idstr);
    for (; blist && blist->Kind != kNoBranch; blist=blist->Branch.Next) {

        if (blist->Kind == kFTConstant) {
            GF_OptFold(blist->FTConstant.Ident.Pos);
            mygetstr (blist->FTConstant.Ident.Ident, idstr); 
			Latex_Name (idstr);
            fprintf (gfp, "%s", idstr);
        }
        else { /* FTConstructor */
            mygetstr (blist->FTConstructor.Ident.Ident, idstr);
			Latex_Name (idstr);
            fprintf (gfp, "%s \\lang ", idstr);
            SumGForm (blist->FTConstructor.Exp);
            fprintf (gfp, "\\rang ");
        }
        if (blist->Branch.Next->Kind != kNoBranch)
            fprintf (gfp, ", ");
    }
    fprintf (gfp, ")");
}

/* schema instantiation */
void GF_Exp_SchemaRef (IdList, ExpressionList)
    tTree IdList, ExpressionList;
{
    char idstr[IDENT_LENGTH]; 

    Unparse_Name (IdList, idstr);
    Latex_Name (idstr);
	fprintf (gfp, "%s[", idstr);
	GF_ExpList (ExpressionList);
	fprintf (gfp, "]");
}

void GF_PredExp (Pred)
	tTree Pred;
{
	fprintf (gfp, "(");
	SumGForm (Pred);
	fprintf (gfp, ")");
}

void GF_Visible (Ident, SelectionList)
    tIdPos Ident;
    tTree SelectionList;
{
    char idstr[IDENT_LENGTH]; 
    tTree slist=SelectionList;

    mygetstr (Ident.Ident, idstr);
	Latex_Name (idstr);
	if (slist->Kind == kNoSelection)
		fprintf (gfp, "visible\\ %s", idstr);   
	else {
		fprintf (gfp, "visible\\ %s \\{", idstr);   
		for (; slist && slist->Kind != kNoSelection; 
			slist=slist->Selection.Next) {
			mygetstr (slist->Selection.Ident.Ident, idstr);
			Latex_Name (idstr);
			if (slist->Selection.Next->Kind != kNoSelection)
				fprintf (gfp, "%s,", idstr); 
			else
				fprintf (gfp, "%s", idstr); 
		}
		fprintf (gfp, "\\}"); 
	}
}

void GF_QuantPred (LogQuant, SchemaText, Pred)
    tIdPos LogQuant;
    tTree SchemaText;
    tTree Pred;
{
    GF_OptFold(SchemaText->SchemaText.Pos);
    if (LogQuant.Ident == Ident_forall)
        fprintf (gfp, "\\forall ");
    else if (LogQuant.Ident == Ident_exists)
        fprintf (gfp, "\\exists ");
    else if (LogQuant.Ident == Ident_exists_1)
        fprintf (gfp, "\\exione ");
    else if (LogQuant.Ident == Ident_let)
        fprintf (gfp, "\\zlet ");
    else if (LogQuant.Ident == Ident_var)
        fprintf (gfp, "{\\bf var}\\ ");
    else if (LogQuant.Ident == Ident_sm_1)
        fprintf (gfp, "{\\bf sm_1}\\ ");
 /*   fprintf (gfp, "\\M "); */
    SumGForm(SchemaText);
/*  
    GF_SemicolonDeclList (SchemaText->SchemaText.DeclList);
    if (SchemaText->SchemaText.PredList->Kind != kNoPred) {
       fprintf(gfp, "\\cbar ");
       GF_OptFold(SchemaText->SchemaText.PredList->Pred.Pos);
       SumGForm(SchemaText->SchemaText.PredList);
    } */
    fprintf (gfp, "\\dot ");
    GF_OptFold(Pred->Pred.Pos);
    SumGForm (Pred);
 /*   fprintf (gfp, "\\O "); */
}

void GF_RelBinPred (L, RelBinOp, R)
    tTree L, R;
    tIdPos RelBinOp;
{
    GF_OptFold(L->Pred.Pos);
    SumGForm (L);
    if (RelBinOp.Ident == Ident_equal)
        fprintf (gfp, " = ");
    else if (RelBinOp.Ident == Ident_notequ)
        fprintf (gfp, " \\neq ");
    else if (RelBinOp.Ident == Ident_less)
        fprintf (gfp, " < ");
    else if (RelBinOp.Ident == Ident_grt)
        fprintf (gfp, " > ");
    else if (RelBinOp.Ident == Ident_notless)
        fprintf (gfp, " \\geq ");
    else if (RelBinOp.Ident == Ident_notgrt)
        fprintf (gfp, " \\leq ");
    else if (RelBinOp.Ident == Ident_subset)
        fprintf (gfp, " \\subs ");
    else if (RelBinOp.Ident == Ident_p_subset)
        fprintf (gfp, " \\psubs ");
    else if (RelBinOp.Ident == Ident_in)
        fprintf (gfp, " \\in ");
    else if (RelBinOp.Ident == Ident_not_in)
        fprintf (gfp, " \\notin ");
    else if (RelBinOp.Ident == Ident_in_bag)
        fprintf (gfp, " {\\rm in_bag} ");
    else if (RelBinOp.Ident == Ident_partitions)
        fprintf (gfp, " \\partitions ");
    else if (RelBinOp.Ident == Ident_eqc)
        fprintf (gfp, " =_c ");
    else if (RelBinOp.Ident == Ident_neqc)
        fprintf (gfp, " \\neq_c ");
    else if (RelBinOp.Ident == Ident_ltc)
        fprintf (gfp, " <_c ");
    else if (RelBinOp.Ident == Ident_gtc)
        fprintf (gfp, " >_c ");
    else if (RelBinOp.Ident == Ident_ltec)
        fprintf (gfp, " \\leq_c ");
    else if (RelBinOp.Ident == Ident_gtec)
        fprintf (gfp, " \\geq_c ");

    GF_OptFold(R->Pred.Pos);
    SumGForm (R);
}

void GF_RelPrePred (RelPreOp, Exp)
    tIdPos RelPreOp;
    tTree Exp;
{
    if (RelPreOp.Ident == Ident_disjoint)
        fprintf (gfp, " \\disjoint ");
    SumGForm (Exp);
}

void GF_LogBinPred (L, LogBinOp, R)
    tTree L, R;
    tTree LogBinOp; 
{
    GF_OptFold(L->Pred.Pos);
    SumGForm (L);
    switch (LogBinOp->Kind) {
    case kLogEquiv:
        fprintf (gfp, " \\iff ");
        break;
    case kLogImply:
        fprintf (gfp, " \\imp ");
        break;
    case kLogAnd:
        fprintf (gfp, " \\land ");
        break;
    case kLogOr:
        fprintf (gfp, " \\lor ");
        break;
    case kLogExor:
        fprintf (gfp, " xor ");
        break;
    case kLogSeq:
        fprintf (gfp, " {\\bf \\,;\\!\\!;} ");
        break;
    }
    GF_OptFold(R->Pred.Pos);
    SumGForm (R);
}

void GF_LogicalNot (Pred)
    tTree Pred;
{
    fprintf (gfp, " \\lnot ");
    SumGForm (Pred);
}

void GF_PreCondPred (Pred)
    tTree Pred;
{
    fprintf (gfp, " \\pre ");
    SetGFPos(Pred->Pred.Pos);
    SumGForm (Pred);
}

void GF_IfPred (Con, Then, Else)
    tTree Con, Then, Else;
{
    GF_OptFold(Con->Pred.Pos);
    fprintf (gfp, "{\\bf if}\\ ");
    SumGForm (Con);
    GF_OptFold(Then->Pred.Pos);
    fprintf (gfp, "\\ {\\bf then}\\ ");
    SumGForm (Then);
    if (Else->Kind != kNoPred) {
       GF_OptFold(Else->Pred.Pos);
       fprintf (gfp, "\\ {\\bf else}\\ ");
       SumGForm (Else);
    }
    fprintf (gfp, "\\ {\bf fi}\\ ");
}

void GF_WhilePred (Con, Do)
    tTree Con, Do;
{
    GF_OptFold(Con->Pred.Pos);
    fprintf (gfp, "{\\bf while}\\ ");
    SumGForm (Con);
    fprintf (gfp, "\\ {\\bf do}\\ ");
    GF_OptFold(Do->Pred.Pos);
    SumGForm (Do);
    fprintf (gfp, "\\ {\\bf done} \\ ");
}

void GF_IBL(InputBindList)
    tTree InputBindList;
{
    tTree ibl=InputBindList;
    char idstr[IDENT_LENGTH]; 

    for (;ibl&&ibl->Kind!=kNoInputBind; ibl=ibl->InputBind.Next){
        mygetstr (ibl->InputBind.Ident.Ident, idstr);
	Latex_Name (idstr);
        fprintf (gfp, "%s\\ => \\ ",idstr);
        GF_ExpList (ibl->InputBind.ExpressionList);
        if (ibl->InputBind.Next->Kind != kNoInputBind)
           fprintf(gfp, ",\\ ");
    }
}

void GF_OBL(OutputBindList)
    tTree OutputBindList;
{
    tTree obl=OutputBindList;
    char idstr[IDENT_LENGTH]; 

    for (;obl&&obl->Kind!=kNoOutputBind; obl=obl->OutputBind.Next){
        mygetstr (obl->OutputBind.Ident.Ident, idstr);
	Latex_Name (idstr);
        fprintf (gfp, "%s\\ => \\ ",idstr);
        GF_IdList (obl->OutputBind.IdList);
        if (obl->OutputBind.Next->Kind != kNoOutputBind)
           fprintf(gfp, ",\\ ");
    }
}

void GF_CallPred(IdList, InputBindList, OutputBindList)
    tTree IdList, InputBindList, OutputBindList;
{
    char idstr[IDENT_LENGTH]; 

    fprintf (gfp, "{\\bf call}\\ (");
    Unparse_Name (IdList, idstr);
    Latex_Name (idstr);
    fprintf (gfp, "%s\\ ,(", idstr);
    GF_IBL(InputBindList);
    fprintf (gfp, "),\\ (");
    GF_OBL(OutputBindList);
    fprintf (gfp, "))");
    
}

void GF_NameList(NameList)
    tTree NameList;
{
    tTree namelist;
    char idstr[IDENT_LENGTH]; 

    for (namelist=NameList; namelist && namelist->Kind != kNoName; 
        namelist=namelist->Name.Next) {

        Unparse_Name (namelist->Name.IdList, idstr);
        Latex_Name (idstr);
        GF_OptFold(namelist->Name.Pos);
        if (namelist->Name.Next->Kind != kNoName)
            fprintf (gfp, "%s, ", idstr);
        else
            fprintf (gfp, "%s", idstr);
    }
}

void GF_Assign(L,R)
    tTree L,R;
{
    fprintf (gfp, "{\\bf assign}\\ ");
    GF_NameList(L);
    fprintf (gfp, "\\ {\\bf :=} \\ ");
    GF_ExpList(R);
}

void GF_ChgOnly (NameList)
    tTree NameList;
{
/*    tTree namelist;
    char idstr[IDENT_LENGTH];  */

    fprintf (gfp, " changes\\_only \\{");

    GF_NameList(NameList);

    /* for (namelist=NameList; namelist && namelist->Kind != kNoName; 
        namelist=namelist->Name.Next) {

        Unparse_Name (namelist->Name.IdList, idstr);
        Latex_Name (idstr);
        GF_OptFold(namelist->Name.Pos);
        if (namelist->Name.Next->Kind != kNoName)
            fprintf (gfp, "%s, ", idstr);
        else
            fprintf (gfp, "%s", idstr);
    } */

	fprintf (gfp, "\\}");
}

void GF_BoolValue (Ident)
    tIdPos Ident;
{
    if (Ident.Ident == Ident_true)
        fprintf (gfp, " \\true ");
    else if (Ident.Ident == Ident_false)
        fprintf (gfp, " \\false ");
}


void GF_SchemaCompos(Sch1, Sch2)
    tTree Sch1, Sch2;
{
    SumGForm (Sch1);
    fprintf (gfp, " \\zcmp ");
    SumGForm (Sch2);
}

void GF_SchemaHiding (Schema, NameList)
    tTree Schema, NameList;
{
    tTree namelist;
    char idstr[IDENT_LENGTH]; 

    SumGForm (Schema);
    fprintf (gfp, " \\zhide (");

    for (namelist=NameList; namelist && namelist->Kind != kNoName; 
        namelist=namelist->Name.Next) {

        Unparse_Name (namelist->Name.IdList, idstr);
        Latex_Name (idstr);
        if (namelist->Name.Next->Kind != kNoName)
            fprintf (gfp, "%s, ", idstr);
        else
            fprintf (gfp, "%s)", idstr);
    }
}

void GF_SchemaProj (Sch1, Sch2)
    tTree Sch1, Sch2;
{
    SumGForm (Sch1);
    fprintf (gfp, " \\zproject ");
    SumGForm (Sch2);
}

void GF_SchemaSubst (Schema, RenameList)
    tTree Schema, RenameList;
{
    SumGForm (Schema);
	GF_RenameList (RenameList);
}
    
void GF_Variable (IdList)
	tTree IdList;
{
	char idstr[IDENT_LENGTH]; 

	Unparse_Name (IdList, idstr);
	Latex_Name (idstr);

	/* predefined constants and functions */
	if (IdList->Id.Next->Kind == kNoId) {
		if (IdList->Id.Ident.Ident == Ident_int)
			fprintf (gfp, " \\integer "); 
		else if (IdList->Id.Ident.Ident == Ident_nat)
			fprintf (gfp, " \\nat "); 
		else if (IdList->Id.Ident.Ident == Ident_nat_1)
			fprintf (gfp, " \\natone "); 
		else if (IdList->Id.Ident.Ident == Ident_bool)
			fprintf (gfp, " \\bool "); 
		else if (IdList->Id.Ident.Ident == Ident_inverse)
			fprintf (gfp, "\\inv "); 
		else if (IdList->Id.Ident.Ident == Ident_iter)
			fprintf (gfp, "\\iter "); 
		else if (IdList->Id.Ident.Ident == Ident_t_closure)
			fprintf (gfp, "\\tcl "); 
		else if (IdList->Id.Ident.Ident == Ident_rt_closure)
			fprintf (gfp, "\\rtcl "); 
		else if (IdList->Id.Ident.Ident == Ident_count)
			fprintf (gfp, "\\bagcount "); 
		else 
			fprintf (gfp, "%s", idstr); 
	}
	else
		fprintf (gfp, "%s", idstr); 
}
    
void GF_Literal (Ident)
    tIdPos Ident;
{
    char idstr[IDENT_LENGTH]; 

    mygetstr (Ident.Ident, idstr);
	Latex_Name (idstr);
    fprintf (gfp, "%s", idstr);
}

void GF_PrefixOp (Prefix, Exp)
    tIdPos Prefix;
    tTree Exp;
{
    if (Prefix.Ident == Ident_sub)
        fprintf (gfp, " - ");
    else if (Prefix.Ident == Ident_card)
        fprintf (gfp, " \\# ");
    else if (Prefix.Ident == Ident_power)
        fprintf (gfp, " \\pset ");
    else if (Prefix.Ident == Ident_power_1)
        fprintf (gfp, " \\psetone ");
    else if (Prefix.Ident == Ident_finite)
        fprintf (gfp, " \\fset ");
    else if (Prefix.Ident == Ident_finite_1)
        fprintf (gfp, " \\fsetone ");
    else if (Prefix.Ident == Ident_seq)
        fprintf (gfp, " \\seq ");
    else if (Prefix.Ident == Ident_seq_1)
        fprintf (gfp, " \\seqone ");
    else if (Prefix.Ident == Ident_iseq)
        fprintf (gfp, " \\iseq ");
    else if (Prefix.Ident == Ident_id)
        fprintf (gfp, " \\id ");
    else if (Prefix.Ident == Ident_bag)
        fprintf (gfp, " \\bag ");
    else if (Prefix.Ident == Ident_dom)
        fprintf (gfp, " \\dom ");
    else if (Prefix.Ident == Ident_ran)
        fprintf (gfp, " \\ran ");
    else if (Prefix.Ident == Ident_gen_union)
        fprintf (gfp, " \\dunion ");
    else if (Prefix.Ident == Ident_gen_inter)
        fprintf (gfp, " \\dinter ");
    
    SumGForm (Exp);
}

void GF_InfixOp (Op1, Infix, Op2)
    tTree Op1, Op2;
    tIdPos Infix;
{
    GF_OptFold(Op1->Exp.Pos);
    SumGForm (Op1);
    if (Infix.Ident == Ident_relation)
        fprintf (gfp, " \\rel ");
    else if (Infix.Ident == Ident_partfunc)
        fprintf (gfp, " \\pfun ");
    else if (Infix.Ident == Ident_totalfunc)
        fprintf (gfp, " \\tfun ");
    else if (Infix.Ident == Ident_partinj)
        fprintf (gfp, " \\pinj ");
    else if (Infix.Ident == Ident_totalinj)
        fprintf (gfp, " \\tinj ");
    else if (Infix.Ident == Ident_partsur)
        fprintf (gfp, " \\psur ");
    else if (Infix.Ident == Ident_totalsur)
        fprintf (gfp, " \\tsur ");
    else if (Infix.Ident == Ident_bij)
        fprintf (gfp, " \\bij ");
    else if (Infix.Ident == Ident_fpartfunc)
        fprintf (gfp, " \\ffun ");
    else if (Infix.Ident == Ident_fpartinj)
        fprintf (gfp, " \\finj ");
    else if (Infix.Ident == Ident_upto)
        fprintf (gfp, " \\upto ");
    else if (Infix.Ident == Ident_uptoc)
        fprintf (gfp, " \\upto_c ");
    else if (Infix.Ident == Ident_concat)
        fprintf (gfp, " \\cat ");
    else if (Infix.Ident == Ident_func_override)
        fprintf (gfp, " \\fovr ");
    else if (Infix.Ident == Ident_maplet)
        fprintf (gfp, " \\map ");
    else if (Infix.Ident == Ident_addc)
        fprintf (gfp, " +_c ");
    else if (Infix.Ident == Ident_add)
        fprintf (gfp, " + ");
    else if (Infix.Ident == Ident_sub)
        fprintf (gfp, " - ");
    else if (Infix.Ident == Ident_subc)
        fprintf (gfp, " -_c ");
    else if (Infix.Ident == Ident_mult)
        fprintf (gfp, " * ");
    else if (Infix.Ident == Ident_multc)
        fprintf (gfp, " *_c ");
    else if (Infix.Ident == Ident_div)
        fprintf (gfp, " \\div ");
    else if (Infix.Ident == Ident_divc)
        fprintf (gfp, " \\div_c ");
    else if (Infix.Ident == Ident_mod)
        fprintf (gfp, " \\mod ");
    else if (Infix.Ident == Ident_modc)
        fprintf (gfp, " \\mod_c ");
    else if (Infix.Ident == Ident_expo)
        fprintf (gfp, "\\expon ");
    else if (Infix.Ident == Ident_expc)
        fprintf (gfp, "\\expon_c ");
    else if (Infix.Ident == Ident_diff)
        fprintf (gfp, " \\zhide ");
    else if (Infix.Ident == Ident_b_compose)
        fprintf (gfp, " \\cmp ");
    else if (Infix.Ident == Ident_f_compose)
        fprintf (gfp, " \\fcmp ");
    else if (Infix.Ident == Ident_dom_restrict)
        fprintf (gfp, " \\dres ");
    else if (Infix.Ident == Ident_ran_restrict)
        fprintf (gfp, " \\rres ");
    else if (Infix.Ident == Ident_dom_subtract)
        fprintf (gfp, " \\dsub ");
    else if (Infix.Ident == Ident_ran_subtract)
        fprintf (gfp, " \\rsub ");
    else if (Infix.Ident == Ident_union)
        fprintf (gfp, " \\uni ");
    else if (Infix.Ident == Ident_inter)
        fprintf (gfp, " \\int ");
    else if (Infix.Ident == Ident_bag_union)
        fprintf (gfp, " \\buni ");
    else if (Infix.Ident == Ident_andc)
        fprintf (gfp, " \\land_c ");
    else if (Infix.Ident == Ident_orc)
        fprintf (gfp, " \\lor_c ");
    else if (Infix.Ident == Ident_xorc)
        fprintf (gfp, " \\xor_c ");

    GF_OptFold(Op2->Exp.Pos);
    SumGForm (Op2);
}

void GF_FncApplication(Fnc, Arg)
    tTree Fnc, Arg;
{
    if (Fnc->Kind == kVariable && 
	Fnc->Variable.IdList->Id.Next->Kind == kNoId) {

	if (Fnc->Variable.IdList->Id.Ident.Ident == Ident_inverse ||
 	    Fnc->Variable.IdList->Id.Ident.Ident == Ident_iter ||
	    Fnc->Variable.IdList->Id.Ident.Ident == Ident_t_closure ||
	    Fnc->Variable.IdList->Id.Ident.Ident == Ident_rt_closure) { 
                
                GF_ExpList (Arg);
		SumGForm (Fnc);
		return;
	}
    }

    GF_OptFold(Fnc->Exp.Pos);
    SumGForm (Fnc);
    fprintf (gfp, "(");
    GF_ExpList (Arg);
    fprintf (gfp, ")");
}

void GF_SetComp (SchemaText, Exp)
    tTree SchemaText, Exp;
{
    GF_OptFold(SchemaText->SchemaText.Pos);
    fprintf (gfp, "\\{");
    SumGForm(SchemaText);
    /*
    GF_SemicolonDeclList (VarDecl);
    if (PredList->Kind != kNoPred) {
        fprintf (gfp, "\\cbar ");
        GF_SemicolonPredList (PredList);
    }
    */
    if (Exp->Kind != kNoExp) {
        fprintf(gfp, " \\dot ");
        SumGForm(Exp);
    }
    fprintf (gfp, "\\}");
}

void GF_SetElab (ExpressionList)
    tTree ExpressionList;
{
    GF_OptFold(ExpressionList->Exp.Pos);
    if (ExpressionList->Kind == kNoExp)
        fprintf (gfp, "\\varemptyset");
    else {
        fprintf (gfp, "\\{");
        GF_ExpList (ExpressionList);
        fprintf (gfp, "\\}");
    }
}

void GF_ArrayUpd (Array, Index, Value)
    tTree Array, Index, Value;
{
    char idstr[IDENT_LENGTH];

    Unparse_Name (Array, idstr);
    Latex_Name (idstr);
    fprintf (gfp, "{\\bf upd}(%s, ", idstr);
    SumGForm(Index);
    fprintf(gfp, ", ");
    SumGForm(Value);
    fprintf(gfp, ")");
}

void GF_Sequence (ExpressionList)
    tTree ExpressionList;
{
    GF_OptFold(ExpressionList->Exp.Pos);
    if (ExpressionList->Kind == kNoExp)
        fprintf (gfp, "\\emptyseq ");
    else {
        fprintf (gfp, "\\lseq ");
        GF_ExpList (ExpressionList);
        fprintf (gfp, "\\rseq ");
    }
}
    
void GF_Tuple (ExpressionList)
    tTree ExpressionList;
{
    GF_OptFold(ExpressionList->Exp.Pos);
    fprintf (gfp, "(");
    GF_ExpList (ExpressionList);
    fprintf (gfp, ")");
}

void GF_Bag (ExpressionList)
    tTree ExpressionList;
{
    GF_OptFold(ExpressionList->Exp.Pos);
    if (ExpressionList->Kind == kNoExp)
        fprintf (gfp, "\\emptybag ");
    else {
        fprintf (gfp, "\\lbag ");
        GF_ExpList (ExpressionList);
        fprintf (gfp, "\\rbag ");
    }
}

void GF_IfExp (Con, Then, Else)
    tTree Con, Then, Else;
{
    GF_OptFold(Con->Pred.Pos);
    fprintf (gfp, "if\\ ");
    SumGForm (Con);
    GF_OptFold(Then->Exp.Pos);
    fprintf (gfp, "\\ then\\ ");
    SumGForm (Then);
    GF_OptFold(Else->Exp.Pos);
    fprintf (gfp, "\\ else\\ ");
    SumGForm (Else);
    fprintf (gfp, "\\ fi\\ ");
}

void GF_CartProd (ExpressionList)
    tTree ExpressionList;
{
    tTree explist=ExpressionList;

    for (; explist && explist->Kind != kNoExp; explist=explist->Exp.Next) {
        GF_OptFold(explist->Exp.Pos);
        SumGForm (explist);
        if (explist->Exp.Next->Kind != kNoExp)  
            fprintf (gfp, " \\cross ");
    }
}
    
void GF_VarSelection (Exp, Ident)
    tTree Exp;
    tIdPos Ident;
{
    char idstr[IDENT_LENGTH]; 

    mygetstr (Ident.Ident, idstr);
	Latex_Name (idstr);
    SumGForm (Exp);
    fprintf (gfp, ".%s", idstr);
}

void GF_Lambda (SchemaText, Exp)
	tTree SchemaText, Exp;
{
        GF_OptFold(SchemaText->SchemaText.Pos);
	fprintf (gfp, " \\lambda ");
	SumGForm (SchemaText);
	fprintf (gfp, " \\dot ");
	SumGForm  (Exp);
}

void GF_Mu (SchemaText, Exp)
	tTree SchemaText, Exp;
{
        GF_OptFold(SchemaText->SchemaText.Pos);
	fprintf (gfp, " \\mu ");
	SumGForm (SchemaText);
	if (Exp->Kind != kNoExp){
          fprintf (gfp, " \\dot ");
	  SumGForm (Exp);
        }
}

void GF_RecDisp (SchemaText, PredList)
	tTree SchemaText, PredList;
{
        GF_OptFold(SchemaText->SchemaText.Pos);
	fprintf (gfp, " record ");
	SumGForm (SchemaText);
	fprintf (gfp, " \\dot ");
	GF_PredList (PredList);
}




static void yyExit () { Exit (1); }

void (* tex_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module tex, routine %s failed\n", yyFunction);
 tex_Exit ();
}

void SumGForm ARGS((tTree t));

void SumGForm
# if defined __STDC__ | defined __cplusplus
(register tTree t)
# else
(t)
 register tTree t;
# endif
{

  switch (t->Kind) {
  case kSum:
/* line 1363 "tex.puma" */
  {
/* line 1364 "tex.puma" */
   GF_ModList (t->Sum.ModuleList);
  }
   return;

  case kModule:
/* line 1367 "tex.puma" */
  {
/* line 1368 "tex.puma" */
   GF_Module (t->Module.Ident, t->Module.FormalParams, t->Module.PredList, t->Module.DeclList);
  }
   return;

  case kVarDecl:
/* line 1371 "tex.puma" */
  {
/* line 1372 "tex.puma" */
   GF_VarDecl (t->VarDecl.IdList, t->VarDecl.Exp);
  }
   return;

  case kGivenSet:
/* line 1374 "tex.puma" */
  {
/* line 1375 "tex.puma" */
   GF_GivenSet (t->GivenSet.IdList);
  }
   return;

  case kAxiomDecl:
/* line 1377 "tex.puma" */
  {
/* line 1378 "tex.puma" */
   GF_AxiomDecl (t->AxiomDecl.FormalParams, t->AxiomDecl.DeclList, t->AxiomDecl.PredList);
  }
   return;

  case kSchemaDef:
/* line 1380 "tex.puma" */
  {
/* line 1381 "tex.puma" */
   GF_SchemaDef (t->SchemaDef.Ident, t->SchemaDef.FormalParams, t->SchemaDef.DeclList, t->SchemaDef.PredList, t->SchemaDef.IsOp);
  }
   return;

  case kAbbreviation:
/* line 1383 "tex.puma" */
  {
/* line 1384 "tex.puma" */
   GF_Abbr (t->Abbreviation.Ident, t->Abbreviation.Exp);
  }
   return;

  case kImport:
/* line 1386 "tex.puma" */
  {
/* line 1387 "tex.puma" */
   GF_Import (t->Import.Ident, t->Import.ExpressionList, t->Import.RenameList, t->Import.NewIdent);
  }
   return;

  case kModuleDecl:
/* line 1389 "tex.puma" */
  {
/* line 1390 "tex.puma" */
   SumGForm (t->ModuleDecl.Module);
  }
   return;

  case kFreeType:
/* line 1392 "tex.puma" */
  {
/* line 1393 "tex.puma" */
   GF_FreeType (t->FreeType.Ident, t->FreeType.BranchList);
  }
   return;

  case kEnum:
/* line 1395 "tex.puma" */
  {
/* line 1396 "tex.puma" */
   GF_Enum (t->Enum.Ident, t->Enum.BranchList);
  }
   return;

  case kConstraint:
/* line 1398 "tex.puma" */
  {
/* line 1399 "tex.puma" */
   SumGForm (t->Constraint.Pred);
  }
   return;

  case kSchemaIncl:
/* line 1401 "tex.puma" */
  {
/* line 1401 "tex.puma" */

        if (t->SchemaIncl.ExpressionList->Kind != kNoExp)
            GF_Exp_SchemaRef (t->SchemaIncl.IdList, t->SchemaIncl.ExpressionList);
        else 
            GF_Name(t->SchemaIncl.IdList);
    
  }
   return;

  case kVisibility:
/* line 1408 "tex.puma" */
  {
/* line 1409 "tex.puma" */
   GF_Visible (t->Visibility.Ident, t->Visibility.SelectionList);
  }
   return;

  case kErgoAnno:
/* line 1411 "tex.puma" */
   return;

  case kNoPred:
/* line 1414 "tex.puma" */
   return;

  case kQuantPred:
/* line 1416 "tex.puma" */
  {
/* line 1417 "tex.puma" */
   GF_QuantPred (t->QuantPred.LogQuant, t->QuantPred.SchemaText, t->QuantPred.Pred);
  }
   return;

  case kRelBinPred:
/* line 1419 "tex.puma" */
  {
/* line 1420 "tex.puma" */
   GF_RelBinPred (t->RelBinPred.L, t->RelBinPred.RelBinOp, t->RelBinPred.R);
  }
   return;

  case kRelPrePred:
/* line 1422 "tex.puma" */
  {
/* line 1423 "tex.puma" */
   GF_RelPrePred (t->RelPrePred.RelPreOp, t->RelPrePred.Exp);
  }
   return;

  case kLogBinPred:
/* line 1425 "tex.puma" */
  {
/* line 1426 "tex.puma" */
   GF_LogBinPred (t->LogBinPred.L, t->LogBinPred.LogBinOp, t->LogBinPred.R);
  }
   return;

  case kLogicalNot:
/* line 1428 "tex.puma" */
  {
/* line 1429 "tex.puma" */
   GF_LogicalNot (t->LogicalNot.Pred);
  }
   return;

  case kPreCondPred:
/* line 1431 "tex.puma" */
  {
/* line 1432 "tex.puma" */
   GF_PreCondPred (t->PreCondPred.Pred);
  }
   return;

  case kIfPred:
/* line 1434 "tex.puma" */
  {
/* line 1435 "tex.puma" */
   GF_IfPred (t->IfPred.Con, t->IfPred.Then, t->IfPred.Else);
  }
   return;

  case kWhilePred:
/* line 1437 "tex.puma" */
  {
/* line 1438 "tex.puma" */
   GF_WhilePred (t->WhilePred.Con, t->WhilePred.Do);
  }
   return;

  case kAssign:
/* line 1440 "tex.puma" */
  {
/* line 1441 "tex.puma" */
   GF_Assign (t->Assign.L, t->Assign.R);
  }
   return;

  case kCallPred:
/* line 1443 "tex.puma" */
  {
/* line 1444 "tex.puma" */
   GF_CallPred (t->CallPred.IdList, t->CallPred.InputBindList, t->CallPred.OutputBindList);
  }
   return;

  case kChgOnly:
/* line 1446 "tex.puma" */
  {
/* line 1447 "tex.puma" */
   GF_ChgOnly (t->ChgOnly.NameList);
  }
   return;

  case kSchemaPred:
/* line 1449 "tex.puma" */
  {
/* line 1450 "tex.puma" */
   SumGForm (t->SchemaPred.Schema);
  }
   return;

  case kBoolValue:
/* line 1452 "tex.puma" */
  {
/* line 1453 "tex.puma" */
   GF_BoolValue (t->BoolValue.Ident);
  }
   return;

  case kExpPred:
/* line 1456 "tex.puma" */
  {
/* line 1457 "tex.puma" */
   SumGForm (t->ExpPred.Exp);
  }
   return;

  case kSchemaText:
/* line 1459 "tex.puma" */
  {
/* line 1460 "tex.puma" */

        if (!t->SchemaText.Is_local_dec) fprintf (gfp, " \\lsch ");
        GF_SemicolonDeclList (t->SchemaText.DeclList);
        if (t->SchemaText.PredList->Kind != kNoPred) {
	   if (!t->SchemaText.Is_local_dec) fprintf (gfp, " \\zbar ");
	   else  fprintf (gfp, " \\cbar ");
           GF_OptFold(t->SchemaText.PredList->Pred.Pos);
	   GF_PredList (t->SchemaText.PredList);    
        }
        if (!t->SchemaText.Is_local_dec) fprintf (gfp, " \\rsch ");
    
  }
   return;

  case kSchemaCompos:
/* line 1472 "tex.puma" */
  {
/* line 1473 "tex.puma" */
   GF_SchemaCompos (t->SchemaCompos.Sch1, t->SchemaCompos.Sch2);
  }
   return;

  case kSchemaHiding:
/* line 1475 "tex.puma" */
  {
/* line 1476 "tex.puma" */
   GF_SchemaHiding (t->SchemaHiding.Schema, t->SchemaHiding.NameList);
  }
   return;

  case kSchemaProj:
/* line 1478 "tex.puma" */
  {
/* line 1479 "tex.puma" */
   GF_SchemaProj (t->SchemaProj.Sch1, t->SchemaProj.Proj, t->SchemaProj.Sch2);
  }
   return;

  case kSchemaSubst:
/* line 1481 "tex.puma" */
  {
/* line 1482 "tex.puma" */
   GF_SchemaSubst (t->SchemaSubst.Schema, t->SchemaSubst.RenameList);
  }
   return;

  case kVariable:
/* line 1485 "tex.puma" */
  {
/* line 1486 "tex.puma" */
   GF_Variable (t->Variable.IdList);
  }
   return;

  case kLiteral:
/* line 1488 "tex.puma" */
  {
/* line 1489 "tex.puma" */
   GF_Literal (t->Literal.Literal);
  }
   return;

  case kString:
/* line 1491 "tex.puma" */
  {
/* line 1492 "tex.puma" */
   GF_Literal (t->String.String);
  }
   return;

  case kChar:
/* line 1494 "tex.puma" */
  {
/* line 1495 "tex.puma" */
   GF_Literal (t->Char.Char);
  }
   return;

  case kPrefixOp:
/* line 1497 "tex.puma" */
  {
/* line 1498 "tex.puma" */
   GF_PrefixOp (t->PrefixOp.Prefix, t->PrefixOp.Exp);
  }
   return;

  case kInfixOp:
/* line 1500 "tex.puma" */
  {
/* line 1501 "tex.puma" */
   GF_InfixOp (t->InfixOp.Op1, t->InfixOp.Infix, t->InfixOp.Op2);
  }
   return;

  case kFncApplication:
/* line 1503 "tex.puma" */
  {
/* line 1504 "tex.puma" */
   GF_FncApplication (t->FncApplication.Fnc, t->FncApplication.Arg);
  }
   return;

  case kSetComp:
/* line 1506 "tex.puma" */
  {
/* line 1507 "tex.puma" */
   GF_SetComp (t->SetComp.SchemaText, t->SetComp.ExpressionList);
  }
   return;

  case kSetElab:
/* line 1509 "tex.puma" */
  {
/* line 1510 "tex.puma" */
   GF_SetElab (t->SetElab.ExpressionList);
  }
   return;

  case kArrayUpd:
/* line 1512 "tex.puma" */
  {
/* line 1513 "tex.puma" */
   GF_ArrayUpd (t->ArrayUpd.Array, t->ArrayUpd.Index, t->ArrayUpd.Value);
  }
   return;

  case kSequence:
/* line 1515 "tex.puma" */
  {
/* line 1516 "tex.puma" */
   GF_Sequence (t->Sequence.ExpressionList);
  }
   return;

  case kTuple:
/* line 1518 "tex.puma" */
  {
/* line 1519 "tex.puma" */
   GF_Tuple (t->Tuple.ExpressionList);
  }
   return;

  case kBag:
/* line 1521 "tex.puma" */
  {
/* line 1522 "tex.puma" */
   GF_Bag (t->Bag.ExpressionList);
  }
   return;

  case kIfExp:
/* line 1524 "tex.puma" */
  {
/* line 1525 "tex.puma" */
   GF_IfExp (t->IfExp.Con, t->IfExp.Then, t->IfExp.Else);
  }
   return;

  case kCartProd:
/* line 1527 "tex.puma" */
  {
/* line 1528 "tex.puma" */
   GF_CartProd (t->CartProd.ExpressionList);
  }
   return;

  case kVarSelection:
/* line 1530 "tex.puma" */
  {
/* line 1531 "tex.puma" */
   GF_VarSelection (t->VarSelection.Exp, t->VarSelection.Ident);
  }
   return;

  case kTupSelection:
/* line 1533 "tex.puma" */
  {
/* line 1534 "tex.puma" */
   GF_VarSelection (t->TupSelection.Exp, t->TupSelection.Number);
  }
   return;

  case kExp_SchemaRef:
/* line 1536 "tex.puma" */
  {
/* line 1537 "tex.puma" */
   GF_Exp_SchemaRef (t->Exp_SchemaRef.IdList, t->Exp_SchemaRef.ExpressionList);
  }
   return;

  case kPredExp:
/* line 1539 "tex.puma" */
  {
/* line 1540 "tex.puma" */
   GF_PredExp (t->PredExp.Pred);
  }
   return;

  case kLambda:
/* line 1542 "tex.puma" */
  {
/* line 1543 "tex.puma" */
   GF_Lambda (t->Lambda.SchemaText, t->Lambda.Exp);
  }
   return;

  case kMu:
/* line 1545 "tex.puma" */
  {
/* line 1546 "tex.puma" */
   GF_Mu (t->Mu.SchemaText, t->Mu.ExpressionList);
  }
   return;

  case kRecDisp:
/* line 1548 "tex.puma" */
  {
/* line 1549 "tex.puma" */
   GF_RecDisp (t->RecDisp.SchemaText, t->RecDisp.PredList);
  }
   return;

  }

;
}

void Begintex ()
{
/* line 7 "tex.puma" */

    extern int indenttabs;
    extern bool has_state;
    extern bool has_init;
    indenttabs = 0;
    has_state=false;
    has_init=false;

}

void Closetex ()
{
}
