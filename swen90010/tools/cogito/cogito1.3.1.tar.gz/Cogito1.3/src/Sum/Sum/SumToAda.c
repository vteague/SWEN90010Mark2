# include "SumToAda.h"
# include "yySumToAda.w"
# include "System.h"
# include <stdio.h>
# include "Tree.h"
# include "Type.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 38 "SumToAda.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
# include "Tree.h"
# include "Syms.h"
# include "Type.h"
# include "Scanner.h"
# include "global.h"

# include "Idents.h"
# include "Positions.h"
# include "ratc.h"
# include <string.h>
# include <stdio.h>
# include <stdarg.h>
# include <ctype.h>

#define SINDENT {int i=0; for(i=indenttabs; i>0; i--) {fprintf(fps,"\t");} }
#define BINDENT {int i=0; for(i=indenttabs; i>0; i--) {fprintf(fpb,"\t");} }
#define GSINDENT {int i=0; for(i=indenttabs; i>0; i--) {fprintf(fpgs,"\t");} }
#define GBINDENT {int i=0; for(i=indenttabs; i>0; i--) {fprintf(fpgb,"\t");} }

#define mysfprintf SINDENT; fprintf
#define mybfprintf BINDENT; fprintf
#define mygsfprintf GSINDENT; fprintf
#define mygbfprintf GBINDENT; fprintf
#define myfprintf INDENT; fprintf

/* global variables within the file */



/* The list of comments extracted by the scanner to be re-inserted by 
   Graphical generators
*/

extern CppCommLink cpp_comm_head;
CppCommLink GFComm;

/* The input Position of the last symbol printed
   Used to detect line breaks and indenting of input
   Symbols for formatting of the output

   Note the starting Position for larger abstract constructs 
   is synthesised from the closest identifier. So it isnt 
   accurate.
*/

tPosition  AdaPos;

FILE *fps, *fpgs, *fpb, *fpgb; 


#ifdef WIN32
extern char *SumFileName, *SumPathName, *SumSpecFile;
static FILE *fp;
static char cur_mod_name[IDENT_LENGTH];
#else
FILE *fp;
char cur_mod_name[IDENT_LENGTH];
#endif

bool is_parameterised_mod = false;

tTree OpList = NULL;

bool InOpList();
bool IsPrimed();
void Unparse_InfixOp();
void Unparse_DeclList ();
void Unparse_Id ();
void Unparse_IdList ();
void Unparse_PredList ();
void ATr_PredList ();
void ATr_DeclList();
void ATr_FormalParams ();
void ATr_ArrayUpd();

void has_state_and_init();

/* close the written Ada file. */
void ATransClose ()
{
    if (!is_parameterised_mod) {
        fclose (fps);
        fclose (fpb);
    }
    fclose (fpgs);
    fclose (fpgb);
}

/* a formatted print to the ada specification files
   conditional on parameterisation */

/* DONT USE THIS - very slow */

void specprint(char *fmt, ...)
{
    va_list ap;
    char *sval;
    char *p;

    va_start(ap, fmt);

    for (p=fmt; *p; p++) {
      if (*p != '%') {
         putc((*p), fpgs);
         if (!is_parameterised_mod) 
            putc((*p), fps);
         continue;
      }
      switch (*++p) {
      case 's':
         for (sval= va_arg(ap, char *); *sval; sval++)
             putc ((*sval), fpgs);
             if (!is_parameterised_mod) 
                 putc ((*sval), fps);
         break;
      default:
         putc((*p), fpgs);
         if (!is_parameterised_mod) 
             putc((*p), fps);
         break;
      }
    }
   
    va_end(ap);
}

      


/* old simple body of specprint
    fprintf(fpgs,"%s", str);
    if (!is_parameterised_mod) 
        fprintf(fps,"%s" ,str);

 *old bodprint*
void bodyprint(str)
    char  str[IDENT_LENGTH];
{
    fprintf(fpgb,"%s", str);
    if (!is_parameterised_mod) 
        fprintf(fpb,"%s", str);
}

*/

/* a formatted print to the ada body files
   conditional on parameterisation */

void bodyprint(char *fmt, ...)
{
    va_list ap;
    char *sval;
    char *p;

    va_start(ap, fmt);

    for (p=fmt; *p; p++) {
      if (*p != '%') {
         putc((*p), fpgb);
         if (!is_parameterised_mod) 
            putc((*p), fpb);
         continue;
      }
      switch (*++p) {
      case 's':
         for (sval= va_arg(ap, char *); *sval; sval++) {
             putc ((*sval), fpgb);
             if (!is_parameterised_mod) 
                 putc ((*sval), fpb);
         }
         break;
      default:
         putc((*p), fpgb);
         if (!is_parameterised_mod) 
             putc((*p), fpb);
         break;
      }
    }
   
    va_end(ap);
}

/* 1. open a file for writting Ada code. 
 * 2. assign the current module name into cur_mod_name.
 * 3. convert upper case letters into lower case.
 */
void CreateAdaFile (Ident)
    tIdPos Ident;
{
    char gen_specfile[IDENT_LENGTH], gen_bodyfile[IDENT_LENGTH];
    char specfile[IDENT_LENGTH], bodyfile[IDENT_LENGTH];
    int i;


    cur_mod_name[0] = '\0';
    GetString (Ident.Ident, cur_mod_name);
    gen_specfile[0] = '\0';
/*	strcat (gen_specfile, SumPathName); */
    strcat (gen_specfile, "gen_"); 
    strcat (gen_specfile, cur_mod_name); 

    /* convert upper case letters into lower case. */
    for (i=0; i < strlen(gen_specfile); i++)
        if (isupper(gen_specfile[i]))
            gen_specfile[i] = gen_specfile[i] + 32;

    gen_bodyfile[0] = '\0';
    strcat (gen_bodyfile, gen_specfile);
    strcat (gen_specfile, ".ads");
    strcat (gen_bodyfile, ".adb");
    fpgs = fopen (gen_specfile, "w");
    fpgb = fopen (gen_bodyfile, "w");
    if (fpgs == NULL) {
        fprintf (stderr, "Can't write to file: %s\n", gen_specfile); 
        exit(1);
    }
    if (fpgb == NULL) {
        fprintf (stderr, "Can't write to file: %s\n", gen_bodyfile); 
        exit(1);
    }

    if (!is_parameterised_mod) {
        specfile[0] = '\0';
        bodyfile[0] = '\0';
        /* strcat(specfile, SumPathName); */
        strcat(specfile, cur_mod_name);
        /* turn upper case letters to lower case */
        /*for (i=strlen(SumPathName); i < strlen(specfile); i++)*/
        for (i=0; i < strlen(specfile); i++)
            if (isupper(specfile[i]))
                specfile[i] = specfile[i] + 32;

        strcat(bodyfile, specfile);
        strcat(specfile, ".ads");
        strcat(bodyfile, ".adb");
        fps = fopen (specfile, "w");
        if (fps == NULL) {
            fprintf (stderr, "Can't write to file: %s\n", specfile); 
            exit(1);
        }
        fpb = fopen (bodyfile, "w");
        if (fpb == NULL) {
            fprintf (stderr, "Can't write to file: %s\n", bodyfile); 
            exit(1);
        }
    }
}

/* if it is the case of x:TYPE, TYPE is a base type of 
 * int, nat, nat_1, bool, char, and string, which could be 
 * translated into x:TYPE. Otherwise, it will be refined and
 * handled later on.
*/
void ATr_VarDecl (IdList, Exp)
    tTree IdList;
    tTree Exp;
{
    tType ty=Exp->Exp.Type;
    tTree idlist=IdList;
    tTree tyidlist;
    char idstr[IDENT_LENGTH];
    tIdent tyident;
    int i;

/*    if (ty && ty->Kind == kTp_Base)   
    if (Exp && Exp->Kind == kVariable) { */ 

        GSINDENT;
        if (!is_parameterised_mod)
            SINDENT;

        for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) {
            mygetstr (idlist->Id.Ident.Ident, idstr);   
            for (i=0; i < strlen(idstr); i++)
                if (idstr[i] == '!' || idstr[i] == '\'' || idstr[i] == '?') {
                    idstr[i] = '\0';
                    break;
                }
            if (!is_parameterised_mod)
                fprintf (fps, "%s", idstr);

            fprintf (fpgs, "%s", idstr);
            if (idlist->Id.Next->Kind != kNoId) {
                if (!is_parameterised_mod)
                    fprintf (fps, ", ");
                fprintf (fpgs, ", ");
            }
        }


        fprintf(fpgs," : ");
        fp = fpgs;
        TransAda(Exp);
        fprintf(fpgs,";\n");
        if (!is_parameterised_mod)  {
            fprintf(fps," : ");
            fp = fpgs;
            TransAda(Exp);
            fprintf(fps,";\n");
        }

        /* 
        tyidlist = Exp->Variable.IdList;
        if (tyidlist->Id.Next->Kind == kNoId) {


        * if (ty->Tp_Base.Ident == Ident_int) *
            if (tyidlist->Id.Ident.Ident == Ident_int) {
                if (!is_parameterised_mod) 
                    fprintf (fps, ": INTEGER;\n");
                fprintf (fpgs, ": INTEGER;\n");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_nat) {
                if (!is_parameterised_mod)
                    fprintf (fps, ": NATURAL;\n");
                fprintf (fpgs, ": NATURAL;\n");
                *fprintf (fpgs, ": INTEGER range 0..INTEGER'LAST;\n");*
            }
            else if (tyidlist->Id.Ident.Ident == Ident_nat_1) {
                if (!is_parameterised_mod)
                    fprintf (fps, ": POSITIVE;\n");
                fprintf (fpgs, ": POSITIVE;\n");
                *fprintf (fps, ": INTEGER range 1..INTEGER'LAST;\n");*
            }
            else if (tyidlist->Id.Ident.Ident == Ident_bool) {
                if (!is_parameterised_mod)
                    fprintf (fps, ": BOOLEAN;\n");
                fprintf (fpgs, ": BOOLEAN;\n");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_string) {
                if (!is_parameterised_mod)
                    fprintf (fps, ": STRING;\n");
                fprintf (fpgs, ": STRING;\n");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_char) {
                if (!is_parameterised_mod)
                    fprintf (fps, ": CHARACTER;\n");
                fprintf (fpgs, ": CHARACTER;\n");
            }
            else {
                mygetstr (tyidlist->Id.Ident.Ident, idstr);
                if (!is_parameterised_mod)
                    fprintf (fps, ": %s;\n", idstr);
                fprintf (fpgs, ": %s;\n", idstr);
            }
        }
        else {
            if (!is_parameterised_mod)
                fprintf (fps, ": ");
            fprintf (fpgs, ": ");
            for (; tyidlist && tyidlist->Kind != kNoId; tyidlist=tyidlist->Id.Next) {
                mygetstr (tyidlist->Id.Ident.Ident, idstr);
                if (tyidlist->Id.Next->Kind == kNoId) {
                    fprintf (fpgs, "%s;\n", idstr);
                    if (!is_parameterised_mod)
                        fprintf (fps, "%s;\n", idstr);
                }
                else {
                    fprintf (fpgs, "%s.", idstr);
                    if (!is_parameterised_mod) 
                        fprintf (fps, "%s.", idstr);
                }
            }
        }

    }
       */
}

void Fix_decor (idstr)
    char idstr[IDENT_LENGTH];
{
    int n;

    n = strlen (idstr) - 1;
    if (idstr[n] == '!' ) {
        idstr[n] = '\0';
        strcat(idstr, "_out");
    }
    else if (idstr[n] == '\'') {
        idstr[n] = '\0';
        strcat(idstr, "_dash");
    }
    else if (idstr[n] == '?') {
        idstr[n] = '\0';
        strcat(idstr, "_in");
    }
}

/* Translate an expression consisting of a single variable referenceLPW 5/9/97*/

void ATr_VarExp(IdList)
    tTree IdList;
{
    tTree tyidlist = IdList;
    char idstr[IDENT_LENGTH];

        if (tyidlist->Id.Next->Kind == kNoId) {
            if (tyidlist->Id.Ident.Ident == Ident_int) {
                fprintf (fp, "INTEGER");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_nat) {
                fprintf (fp, "NATURAL");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_nat_1) {
                fprintf (fp, "POSITIVE");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_bool) {
                fprintf (fp, "BOOLEAN");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_string) {
                fprintf (fp, "STRING");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_char) {
                fprintf (fp, "CHARACTER");
            }
            else {
                mygetstr (tyidlist->Id.Ident.Ident, idstr);
                Fix_decor(idstr);
                fprintf (fp, "%s", idstr);
            }
        }
        else {
            /* print out qualified names */
            for (; tyidlist && tyidlist->Kind != kNoId;
                   tyidlist=tyidlist->Id.Next) {
                mygetstr (tyidlist->Id.Ident.Ident, idstr);
                if (tyidlist->Id.Next->Kind == kNoId) {
                    fprintf (fp, "%s", idstr);
                }
                else {
                    fprintf (fp, "%s.", idstr);
                }
            }
        }
}



/* LUKE 3/12/96 this version for translating VarDecls in inner scopes */
/* the difference being that the destination file is fp only          */

/* if it is the case of x:TYPE, TYPE is a base type of 
 * int, nat, nat_1, bool, char, and string, which could be 
 * translated into x:TYPE. Otherwise, it will be refined and
 * handled later on.
*/
/* NOT USED ANYMORE */
void ATr_QVarDecl (IdList, Exp)
    tTree IdList;
    tTree Exp;
{
    tType ty=Exp->Exp.Type;
    tTree idlist=IdList;
    tTree list=IdList;
    tTree tyidlist;
    char idstr[IDENT_LENGTH];
    char varstr[IDENT_LENGTH];
    tIdent tyident;
    tIdent newid;
    int i;

        INDENT;

        /* strip pling and bang  - should be _in and _out*/

        for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) {
            mygetstr (idlist->Id.Ident.Ident, varstr);   
            mygetstr (idlist->Id.Ident.Ident, idstr);   
            for (i=0; i < strlen(idstr); i++)
                if (idstr[i] == '!' || idstr[i] == '\'' || idstr[i] == '?') {
                    idstr[i] = '\0';
                    break;
                }

                /* if primed and unprimed exists then ignore primed */
                /* otherwise fix_decor and print */
                     
            if (IsPrimed(varstr))
                       continue;

            fprintf (fp, "%s", idstr);
            if (idlist->Id.Next->Kind != kNoId) {
                fprintf (fp, ", ");
            }

        }

        fprintf(fp," : ");

        TransAda(Exp);

        fprintf(fp,";\n");

        /*

        tyidlist = Exp->Variable.IdList;
        if (tyidlist->Id.Next->Kind == kNoId) {
            if (tyidlist->Id.Ident.Ident == Ident_int) {
                fprintf (fp, ": INTEGER;\n");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_nat) {
                fprintf (fp, ": NATURAL;\n");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_nat_1) {
                fprintf (fp, ": POSITIVE;\n");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_bool) {
                fprintf (fp, ": BOOLEAN;\n");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_string) {
                fprintf (fp, ": STRING;\n");
            }
            else if (tyidlist->Id.Ident.Ident == Ident_char) {
                fprintf (fp, ": CHARACTER;\n");
            }
            else {
                mygetstr (tyidlist->Id.Ident.Ident, idstr);
                fprintf (fp, ": %s;\n", idstr);
            }
        }
        else {
            fprintf (fp, ": ");
            for (; tyidlist && tyidlist->Kind != kNoId;
                   tyidlist=tyidlist->Id.Next) {
                mygetstr (tyidlist->Id.Ident.Ident, idstr);
                if (tyidlist->Id.Next->Kind == kNoId) {
                    fprintf (fp, "%s;\n", idstr);
                }
                else {
                    fprintf (fp, "%s.", idstr);
                }
            }
        }
 
       */
}

 
bool IsGenericMod(ModId)
    tIdent ModId;
{
    tObjects obj;
    /* lookup the module, return whether it was generic */
    obj = LookUpInn(SymsRoot, ModId, NoSym);
    if (obj->Kind == kObj_Inn &&
        obj->Obj_Inn.ObjKind == Obj_import &&
        obj->Obj_Inn.ImportHasAsPart) return true;
    return false;
}

void ATr_Module (Ident, FormalParams, DeclList) 
    tIdPos Ident;
    tTree FormalParams;
    tTree DeclList;
{
    char idstr[IDENT_LENGTH];
    char withstr[IDENT_LENGTH];
    tTree decllist=DeclList;
    extern int indenttabs;

    /* placing WITH statements by searching IMPORTs in the current
     * module. 
     * (to eliminate replicas of placing the same package, not done yet, 
     * it seems not matter)  
     */
    for (; decllist && decllist->Kind != kNoDecl; 
        decllist=decllist->Decl.Next) {

        if (decllist->Kind == kImport) {
            mygetstr (decllist->Import.Ident.Ident, idstr);
            if (decllist->Import.Ident.Ident != Ident_INTIO){
             if ((decllist->Import.ExpressionList->Kind == kNoExp)&&
                (decllist->Import.Ident.Ident == decllist->Import.NewIdent.Ident) ) {
                if (!is_parameterised_mod) {
                    mysfprintf (fps, "with %s;\n", idstr);
                }
                mygsfprintf (fpgs, "with %s;\n", idstr);
             }
             else {
                 if (!is_parameterised_mod) {
                    mysfprintf (fps, "with gen_%s;\n", idstr);
                  }
                  mygsfprintf (fpgs, "with gen_%s;\n", idstr);
             }
          }
        }
    }

    mygetstr (Ident.Ident, idstr);

    mygsfprintf (fpgs, "generic\n");
    ++indenttabs;
    ATr_FormalParams (FormalParams);
    --indenttabs;
        
    mygsfprintf (fpgs, "package gen_%s is\n", idstr);
    mygbfprintf (fpgb, "package body gen_%s is\n", idstr);
    if (!is_parameterised_mod) {
        mysfprintf (fps, "package %s is\n", idstr);
        mybfprintf (fpb, "package body %s is\n", idstr);
    }
    ++indenttabs;
    TransAda (DeclList);

    if (has_init)  {
    /* Add Initialisation statement to body*/
    mygbfprintf (fpgb, "begin\n");
    mygbfprintf (fpgb, "\tinit;\n");
    if (!is_parameterised_mod) {
        mybfprintf (fpb, "begin\n");
        mybfprintf (fpb, "\tinit;\n");
    }
    }

    --indenttabs;
    mygsfprintf (fpgs, "end gen_%s;\n", idstr);
    mygbfprintf (fpgb, "end gen_%s;\n", idstr);
    if (!is_parameterised_mod) {
        mysfprintf (fps, "end %s;\n", idstr);
        mybfprintf (fpb, "end %s;\n", idstr);
    }
}

void ATr_FormalParams (FormalParams)
    tTree FormalParams;
{
    tTree fmllist=FormalParams;
    char idstr[IDENT_LENGTH];

    for (; fmllist && fmllist->Kind != kNoParam; fmllist=fmllist->Param.Next) {
        if (fmllist->Kind == kTyParam) { /*type param.*/
            mygetstr (fmllist->TyParam.Ident.Ident, idstr); 
            if (!is_parameterised_mod) {
                mysfprintf (fps, "type %s is private;\n", idstr); 
            }
            mygsfprintf (fpgs, "type %s is private;\n", idstr); 
        }
        else { /* constant param */
            /*
            if it is a function which should be translated into
            with function func_name (f1:T1, f2:T2, ...) return T;
            */
            ATr_VarDecl(fmllist->FncParam.VarDecl->VarDecl.IdList, 
                       fmllist->FncParam.VarDecl->VarDecl.Exp);
        }
    }
}

/* translate the parameters to the module 
   if no params print nothing
 */
void ATr_ActExpList(ExpList)
    tTree ExpList;
{
    tTree act_params = ExpList;

    if (act_params->Kind == kNoExp)
        return;
    else {   
      fprintf (fp, "(");
      for (; act_params->Kind != kNoExp; act_params=act_params->Exp.Next) {
         TransAda (act_params);
         if (act_params->Exp.Next->Kind != kNoExp)
            fprintf (fp, ", ");
      } 
      fprintf (fp, ")");
    }
}


void ATr_Import (Ident, ExpList, NewIdent, RenameList)
    tIdPos Ident;
    tTree ExpList;
    tIdPos NewIdent;

{
    char idstr[IDENT_LENGTH], newidstr[IDENT_LENGTH];

    mygetstr (Ident.Ident, idstr);  
    mygetstr (NewIdent.Ident, newidstr);    

    if (Ident.Ident != NewIdent.Ident) {
      if (Ident.Ident != Ident_INTIO){
        if (!is_parameterised_mod) {
            mysfprintf (fps, "package %s is new gen_%s", newidstr, idstr);
            fp = fps;
            ATr_ActExpList (ExpList); 
            fprintf (fps, ";\n");
        }
        mygsfprintf (fpgs, "package %s is new gen_%s", newidstr, idstr);
        fp = fpgs;
        ATr_ActExpList (ExpList); 
        fprintf (fpgs, ";\n");
      } else {
        if (!is_parameterised_mod) {
            mysfprintf (fps, "package %s is new %s", newidstr, idstr);
            fp = fps;
            ATr_ActExpList (ExpList); 
            fprintf (fps, ";\n");
        }
        mygsfprintf (fpgs, "package %s is new %s", newidstr, idstr);
        fp = fpgs;
        ATr_ActExpList (ExpList); 
        fprintf (fpgs, ";\n");

        /*
        ATr_RenameList (RenameList); ??
        */
     }
   }
}

bool IsBang(idstr)
    char idstr[IDENT_LENGTH];      /* tTree IdList; */
{
 /*   tTree idlist = IdList;
    char str[IDENT_LENGTH];
    tIdPos Ident;
  */
    int n = 0;


 /* for (; idlist->Kind != kNoId; idlist=idlist->Id.Next)
        if (idlist->Id.Next->Kind == kNoId)
            break;
    Ident = idlist->Id.Ident;
    str[0] = '\0';
    GetString (Ident.Ident, str);
 */
    n = strlen (idstr) - 1;
    if (idstr[n] == '!') return true;
    else return false;

}



bool IsPling(idstr)
    char idstr[IDENT_LENGTH];           /* tTree IdList; */
{
 /* tTree idlist = IdList;
    char str[IDENT_LENGTH];
    tIdPos Ident;
  */
    int n = 0;


 /*
    for (; idlist->Kind != kNoId; idlist=idlist->Id.Next)
        if (idlist->Id.Next->Kind == kNoId)
            break;
    Ident = idlist->Id.Ident;
    str[0] = '\0';
    GetString (Ident.Ident, str);
 */
    n = strlen (idstr) - 1;
    if (idstr[n] == '?') return true;
    else return false;

}

bool IsPrimed(idstr)
    char idstr[IDENT_LENGTH];        
{
    int n = 0;


    n = strlen (idstr) - 1;
    if (idstr[n] == '\'') return true;
    else return false;

}


void ATr_SchemaDef (DeclsIn, Ident, DeclList, PredList, SymPtr, IsOp) 
    tObjects DeclsIn;
    tObjects SymPtr;     /* Object with decls includes */
    tIdPos Ident;
    tTree DeclList;
    tTree PredList;
    bool IsOp;
{
    char idstr[IDENT_LENGTH], modstr[IDENT_LENGTH];
    char varstr[IDENT_LENGTH];
    tTree idlist=NoTree;
    tTree decllist;
    tTree predlist;
    bool first = true;
    bool brackets = false;
    extern int indenttabs;
    tObjects state_sym=NoSym;
    tObjects sym=NoSym;
    tIdent newid;

    int n = 0;


    /* translates schemas        */
    /* ops & init => procedures */
    /* state => global var decl  */
    /* other => records          */

    /* LpW 2/12/96 introduce normal procedure in/out parameters by    */
    /* extracting input (?) and output (!) variables from the schema  */
    /* signature.                                                     */
    /* ie  						 	      */
    /* op schema lookup is dec s? : SYM; v! : VAL pred ... end lookup */
    /* =>                                                             */
    /* procedure lookup (s: in SYM; v :out VAL) begin end             */
    /* why name change? - ?! not in ADA and to capture meaning        */
    /* what about inclusion? dont worry probably state               */
    /* added 13/2/97 extra parameters are "in out"                    */

    /* no longer translates sig and pred to comments                  */
    /* sig becomes parameters and pred becomes translated code        */

    mygetstr(Ident.Ident, idstr);

    if (IsOp || (OpList && InOpList(Ident.Ident)) || Ident.Ident == Ident_init) {
        /* translated into procedure 
         * parameterised schemas could be translated into generic procedures,
         * which has not been handled by Ergo. So at the moment, I only
         * handle the unparameterised schemas.
         */


           mygsfprintf (fpgs, "procedure %s", idstr);
           mygbfprintf (fpgb, "procedure %s", idstr);
           if (!is_parameterised_mod) {
               mysfprintf (fps, "procedure %s", idstr);
               mybfprintf (fpb, "procedure %s", idstr);
           }

           /* ?? generate formal params for the procedure according to the
	    * formal part of the schema.
	    * with T is (limited) private;
	    */ 

           /* assumes declarations are not qualified */

           /* extract in and out parameters from schema signature */
           /* search through decllist for !,? generate in or out params */
           /* make others unprimed variables in out params        */
           /* for primed vars if unprimed exists then ignore      */
           /* what about others? are there any?                   */
           /* Check that Decl is not a re-decl of a state variable*/
           /* primed or unprimed - if so ignore it.               */
           /* creat a global object which contains all the state variables */
           /* primed and unprimed for lookup when generating procedures    */

           /* generate comments?                                  */

           state_sym = LookUp(DeclsIn, Ident_state, NoSym);

           /* this should an Inner - schema 
           if (state_sym->Kind != kObj_Inn  ||
               state_sym->Obj_Inn.ObjKind != Obj_schema)
                 DError(decllist->Decl.Pos, ada_error17); 
           */


	   for (decllist = DeclList;decllist->Kind != kNoDecl;decllist=decllist->Decl.Next) {
               if (decllist->Kind == kVarDecl) {
                   for (idlist = decllist->VarDecl.IdList; idlist->Kind != kNoId; idlist = idlist->Id.Next) {

                    /* check that the var is not a state variable */
                    /* and check that the var is not a primed state variable */

                     mygetstr (idlist->Id.Ident.Ident, varstr);   
                     n = strlen(varstr) - 1;
                     if (varstr[n] == '\'') {  
                        varstr[n]='\0';
                        newid = MakeIdent(varstr, n);
                        varstr[n]='\'';
                     } else
                        newid = idlist->Id.Ident.Ident;

                   if ((state_sym == NoSym) || ((sym = LookUpInn(state_sym->Obj_Inn.Inner, newid, NoSym))
                        == NoSym)) 

                     /* if primed and unprimed exists then ignore primed */
                     /* otherwise fix_decor and print */
                     
                   if ((!(IsPrimed(varstr)) &&
                   ((sym = LookUp(SymPtr, newid, NoSym)) != NoSym))) {

                     /* print brackets if vars will be printed - first */
                        
                     if (first) {
             
                       fprintf (fpgs, "(");
                       fprintf (fpgb, "(");
                       if (!is_parameterised_mod) {
                        fprintf (fps, "(");
                        fprintf (fpb, "(");
                       }
                       first = false;
                       brackets = true;
                     }
                     else { /* print semis - */
                         fprintf (fpgs, "; ");
                         fprintf (fpgb, "; ");
                         if (!is_parameterised_mod) {
                           fprintf (fps, "; ");
                           fprintf (fpb, "; ");
                         }
                     }

                     if (IsBang(varstr)) {
                         Fix_decor(varstr);
                         fprintf (fpgs, "%s : out ", varstr);
                         fprintf (fpgb, "%s : out ", varstr);
                         if (!is_parameterised_mod) {
                             fprintf (fps, "%s : out ", varstr);
                             fprintf (fpb, "%s : out ", varstr);
                         }
    
                     }
                     else if (IsPling(varstr)) {
                         Fix_decor(varstr);
                         fprintf (fpgs, "%s : in ", varstr);
                         fprintf (fpgb, "%s : in ", varstr);
                         if (!is_parameterised_mod) {
                             fprintf (fps, "%s : in ", varstr);
                             fprintf (fpb, "%s : in ", varstr);
                         }
                     }
                     else {  
           /* Error(decllist->Decl.Pos, "Non-inout parameter in sig"); */
           /* outdated by in out params                                */
                         Fix_decor(varstr);
                         fprintf (fpgs, "%s : in out ", varstr);
                         fprintf (fpgb, "%s : in out ", varstr);
                         if (!is_parameterised_mod) {
                             fprintf (fps, "%s : in out ", varstr);
                             fprintf (fpb, "%s : in out ", varstr);
                         }
                     }

                   
                   /* translate declared type */

	             fp = fpgs;
                     TransAda(decllist->VarDecl.Exp);
	             fp = fpgb;
                     TransAda(decllist->VarDecl.Exp);
                     if (!is_parameterised_mod) {
	                 fp = fps;
                         TransAda(decllist->VarDecl.Exp);
	                 fp = fpb;
                         TransAda(decllist->VarDecl.Exp);
                     }
               /*    if (idlist->Id.Next->Kind != kNoId){
                       fprintf (fpgs, "; ");
                       fprintf (fpgb, "; ");
                       if (!is_parameterised_mod) {
                           fprintf (fps, "; ");
                           fprintf (fpb, "; ");
                       } 

                   }*/

                  }/* non state vars */

                 }  /* for idlist */
               } /* non var decl */
               else
                   Error(decllist->Decl.Pos, ada_error1);
	   }

           if (brackets) {
               fprintf (fpgs, ");\n");
               fprintf (fpgb, ") is\n");
           } else {
               fprintf (fpgs, ";\n");
               fprintf (fpgb, " is\n");
           }
           if (!is_parameterised_mod) {
             if (brackets) {
               fprintf (fps, ");\n");
               fprintf (fpb, ") is\n");
             } else {
               fprintf (fps, ";\n");
               fprintf (fpb, " is\n");
             }
           }

        /* OLD CODE lpw 2/12/96
	 * add schema sig. part as comments *
	if (DeclList->Kind != kNoDecl) {
	    fprintf (fpgb, "-- ");
	    fp = fpgb;
	    Unparse_DeclList (DeclList);
	    fprintf (fpgb, "\n");
	}
        mygbfprintf (fpgb, "begin\n");

        if (!is_parameterised_mod) {
	 * add schema sig. part as comments * 
	    if (DeclList->Kind != kNoDecl) {
		fprintf (fpb, "-- ");
		fp = fpb;
		Unparse_DeclList (DeclList);
		fprintf (fpb, "\n");
	    }
            mybfprintf (fpb, "begin\n");
        }

        END OLD CODE */

        /* do body */
        /* note for an empty predlist a null is generated */
        /* however for a non-empty predlist with no translatable predicates */
        /* no body will be generated and it wont compile */

        mygbfprintf (fpgb, "begin\n");
        if (!is_parameterised_mod) {
            mybfprintf (fpb, "begin\n");
        }
        indenttabs++;
	/* translate schema Predicate part to code */
        if (PredList->Kind != kNoPred) {
            fp = fpgb;
	    ATr_PredList (PredList);
            fprintf(fpgb, ";\n");
        } else {
            mygbfprintf (fpgb, "null;\n");
        }
        if (!is_parameterised_mod) {
	/* translate schema Predicate part to code */
            if (PredList->Kind != kNoPred) {
	      fp = fpb;
	      ATr_PredList (PredList);
              fprintf(fpb, ";\n");
            } else {
              mybfprintf (fpb, "null;\n");
            }
        }

        indenttabs--;
        mygbfprintf (fpgb, "end;\n");
        if (!is_parameterised_mod) {
            mybfprintf (fpb, "end;\n");
        }
    }

    else if (Ident.Ident == Ident_state) {
        /* unfold the state signature into a list of global objects.    */

        fp=fpgs;
        ATr_DeclList (DeclList);
        for (predlist=PredList; predlist && predlist->Kind != kNoPred;
            predlist=predlist->Pred.Next) {

	    myfprintf (fp, "-- "); 
            Unparse_PredList(predlist);
	    fprintf (fp, ";\n"); 
        }
        if (!is_parameterised_mod) {
          fp=fps;
          ATr_DeclList (DeclList);
          for (predlist=PredList; predlist && predlist->Kind != kNoPred;
              predlist=predlist->Pred.Next) {

	      myfprintf (fp, "-- "); 
              Unparse_PredList(predlist);
	      fprintf (fp, ";\n"); 
          }
        }

    }

    else {
        /* translated into a record type */
        mygsfprintf (fpgs, "type %s is \n", idstr);
        mygsfprintf (fpgs, "record \n");
        if (!is_parameterised_mod) {
            mysfprintf (fps, "type %s is \n", idstr);
            mysfprintf (fps, "record \n");
        }
        indenttabs++;
        TransAda (DeclList);
        indenttabs--;
        mygsfprintf (fpgs, "end record;\n");
        if (!is_parameterised_mod) {
            mysfprintf (fps, "end record;\n");
        }
    }
}

void ATr_Abbrev(Ident, Exp)
    tIdPos Ident;
    tTree  Exp;
{
    char idstr[IDENT_LENGTH];

    /* type abbreviations */
    /* (integer) range types, and maybe array types */

    /* get ident */
    mygetstr(Ident.Ident, idstr);

    if (Exp->Kind == kVariable ){
	mygsfprintf (fpgs, "type %s is range ", idstr);
        fp = fpgs;
	TransAda(Exp);
	fprintf (fpgs, ";\n");
	if (!is_parameterised_mod) {
	    mysfprintf (fps, "type %s is range ", idstr);
            fp = fps;
	    TransAda(Exp);
	    fprintf (fps, ";\n");
        }
    } 
    else
       /* range */
    if (Exp->Kind == kInfixOp && Exp->InfixOp.Infix.Ident == Ident_uptoc){
	mygsfprintf (fpgs, "type %s is range ", idstr);
        fp = fpgs;
	TransAda(Exp);
	fprintf (fpgs, ";\n");
	if (!is_parameterised_mod) {
	    mysfprintf (fps, "type %s is range ", idstr);
            fp = fps;
	    TransAda(Exp);
	    fprintf (fps, ";\n");
        }
    }
    else 
      /* arrays */
    if (Exp->Kind == kFncApplication && Exp->FncApplication.Fnc->Kind == kVariable && Exp->FncApplication.Fnc->Variable.IdList->Id.Ident.Ident == Ident_array) {
	mygsfprintf (fpgs, "type %s is ", idstr);
        fp = fpgs;
	TransAda(Exp);
	fprintf (fpgs, ";\n");
	if (!is_parameterised_mod) {
	    mysfprintf (fps, "type %s is ", idstr);
            fp = fps;
	    TransAda(Exp);
	    fprintf (fps, ";\n");
        }



    }
    else
      Error(Exp->Exp.Pos, ada_error2);
}


void ATr_StateMachine(IdList)
    tTree IdList;
{
    /* The Id List contains the names of the state operations that
        must be turned into procedures. Assuming that this declaration
        occurs at the front of a file - it would do to just assign a global
        variable to the list and then search this list later when translating 
        schemas. An alternative would be to use inheritance to assign the
        op attribute but I forsee this being difficult.
    */

    OpList = IdList;
}

bool InOpList(Ident)
    tIdent Ident;
{
  /* Search for Ident in OpList
   */
  tTree op;


  for (op=OpList; op->Kind !=kNoId; op=op->Id.Next)
      if (op->Id.Ident.Ident == Ident)
          return true;
  return false;
}


void ATr_FunctionDecl (DeclList, PredList)
    tTree DeclList, PredList;
{
    char idstr[IDENT_LENGTH], modstr[IDENT_LENGTH], varstr[IDENT_LENGTH];
         /* ftypestr[IDENT_LENGTH]; */
    tTree idlist=NoTree;
    tTree decllist=DeclList;
    tTree predlist=PredList;
    tTree exp=NoTree;
    tTree fargexp=NoTree;
    tTree rtnexp=NoTree;
    tTree fdef=NoTree;
    tTree fapp=NoTree;
    tTree fexp=NoTree;
    tTree aargexp=NoTree;
    tTree fname=NoTree;
    tTree arg=NoTree;
    tTree ftypes=NoTree;
    /* tTree ftype=NoTree; */
    extern int indenttabs;

        /* translated into a function of form  			*/
        /* declaration in sig file 				*/
        /* function Dot_Prod(L,R : Vector) return Real;  	*/
        /* body in bdy file 					*/
        /* function Dot_Prod(L,R : Vector) return Real is  	*/
        /* begin 						*/
        /* stmts 						*/
        /* return Sum; 						*/
        /* end Dot_Prod; 					*/

        /* need to remember that in IL there are no stmts in    */
        /* functions so as not to have side effects, so we      */
        /* just have the return stmt. HOWEVER we will have to   */
        /* do something to translate if-expressions in functions*/
        /* by introducing a return value and pushing the        */
        /* assignment into the if. 				*/
        /* This would work for lists of if-elses                */

        /* to get function definition have to unfold decl like  */
        /* unparse_Decl but also need to work out names of      */
        /* formal parameters from the start of predlist         */
        /* which must be given to the function                  */
        /* ie  f(x,y) = exp                                     */

        /* NOTE: must be a universal quantifier which declares  */
        /* variables of the right number and order as the       */
        /* parameter types NOT TRUE - need not be in order      */


    /* Get function id */

    if (decllist->Kind != kVarDecl) {
       Error(decllist->Decl.Pos, ada_error3);
       return;
    }  /* could continue in comment mode */
    else {
       idlist = decllist->VarDecl.IdList;
       Unparse_IdList (decllist->VarDecl.IdList, idstr);
    }

    mygsfprintf (fpgs, "function %s(", idstr);
    mygbfprintf (fpgb, "function %s(", idstr);
    if (!is_parameterised_mod) {
        mysfprintf (fps, "function %s(", idstr);
        mybfprintf (fpb, "function %s(", idstr);
    }

        
    /* get function declaration  */

    exp=decllist->VarDecl.Exp;
    if (exp->Kind != kInfixOp){
       Error(exp->Exp.Pos, ada_error4);
       return;
    }
    else {
       fargexp = exp->InfixOp.Op1;
       rtnexp = exp->InfixOp.Op2;
    }

    /* find Function Definition in the body of a quantifer */
    /* should be the first one but is it possibly to have other stuff ?*/

    for (;predlist->Kind != kNoPred; predlist = predlist->Pred.Next)
        if (predlist->Kind == kQuantPred) 
           break;

    if (predlist->Kind != kQuantPred)  {
        Error (predlist->Pred.Pos, ada_error5);
        return;
    }
    else
        fdef = predlist->QuantPred.Pred;

    /* fdef should be first RelBinPred based on equality */
    /* could search further if lets involved etc         */
    /* the function application should be the left hand side */
    /* the function definition should be the right hand side */

    if (fdef->Kind != kRelBinPred) {
       Error(fdef->Pred.Pos, ada_error6);
       return;
    }
    else {
        fapp = fdef->RelBinPred.L;
        fexp = fdef->RelBinPred.R;
    }

    /* check left handside is a function application of the defined func */

    if (fapp->Kind != kFncApplication) {
       Error(fapp->Exp.Pos, ada_error6);
       return;
    }
    else {
       fname = fapp->FncApplication.Fnc;
       aargexp = fapp->FncApplication.Arg;
    }
    
    /* check fname is right function */

    if (fname->Kind != kVariable) {
       Error (fname->Exp.Pos, ada_error7);
       return;
    }
    else if (fname->Variable.IdList->Id.Ident.Ident != idlist->Id.Ident.Ident) {
       Error(fname->Exp.Pos, ada_error8);
       return;
    }

    /* formal arguments must be cartprod or simple id */

    if (fargexp->Kind == kCartProd)
       ftypes = fargexp->CartProd.ExpressionList;
    else if (fargexp->Kind == kVariable)
       ftypes = fargexp;
    else {
       Error (fargexp->Exp.Pos, ada_error9);
       return;
    }
           
    /* check arguments are all simple variable references */
    /* print out name and declared type of each variable  */
    /* could count argument and give number in error message */
  
    /* ftype = ftypes->Variable.IdList; */

    for (arg = aargexp; arg->Kind != kNoExp; arg = arg->Exp.Next) {
        if (arg->Kind != kVariable) {
           Error(arg->Exp.Pos, ada_error10);
           return;
        }
        else {
           fp = fpgs;
           TransAda(arg);
           fp = fpgb;
           TransAda(arg);
           if (!is_parameterised_mod) {
               fp = fps;
               TransAda(arg);
               fp = fpb;
               TransAda(arg);
           }
           /* Unparse_Name(arg->Variable.IdList, varstr); */

           fprintf (fpgs, ":");
           fprintf (fpgb, ":");
           if (!is_parameterised_mod) {
              fprintf (fps, ":");
              fprintf (fpb, ":");
           }
           /* print declared type */
           /* need they be simply variables ? */

           fp = fpgs;
           TransAda(ftypes);
           fp = fpgb;
           TransAda(ftypes);
           if (!is_parameterised_mod) {
               fp = fps;
               TransAda(ftypes);
               fp = fpb;
               TransAda(ftypes);
           }

      /*
           Unparse_Name (ftype, ftypestr);
           fprintf (fpgs, "%s", ftypestr);
           fprintf (fpgb, "%s", ftypestr);
           if (!is_parameterised_mod) {
              fprintf (fps, "%s", ftypestr);
              fprintf (fpb, "%s", ftypestr);
           }
       */
        }

        if (arg->Exp.Next->Kind != kNoExp) {
           fprintf (fpgs, "; ");
           fprintf (fpgb, "; ");
           if (!is_parameterised_mod) {
              fprintf (fps, "; ");
              fprintf (fpb, "; ");
           }
           if (ftypes->Exp.Next->Kind != kVariable) {
              Error (ftypes->Exp.Next->Exp.Pos, ada_error11);
              return;
           }
           else {
              ftypes = ftypes->Exp.Next;
      /*        ftype = ftypes->Variable.IdList; */
           }
        }
    }

    /* finish declaration */

    fprintf (fpgs, ") return ");
    fprintf (fpgb, ") return ");
    if (!is_parameterised_mod) {
       fprintf (fps, ") return");
       fprintf (fpb, ") return");
    }

    fp = fpgs;
    TransAda(rtnexp);
    fp = fpgb;
    TransAda(rtnexp);
    if (!is_parameterised_mod) {
       fp = fps;
       TransAda(rtnexp);
       fp = fpb;
       TransAda(rtnexp);
    }

    fprintf (fpgs, ";\n");
    fprintf (fpgb, " is\n");
    if (!is_parameterised_mod) {
       fprintf (fps, ";\n");
       fprintf (fpb, " is\n");
    }

    /* print body        */

    mygbfprintf (fpgb, "begin\n");
    if (!is_parameterised_mod) {
       mybfprintf (fpb, "begin\n");
    }

    indenttabs++;
        
    mygbfprintf (fpgb, "return ");
    if (!is_parameterised_mod) {
       mybfprintf (fpb, "return ");
    }

    fp = fpgb;
    TransAda(fexp);
    if (!is_parameterised_mod) {
       fp = fpb;
       TransAda(fexp);
    }

    fprintf (fpgb, ";\n");
    if (!is_parameterised_mod) {
       fprintf (fpb, ";\n");
    }

    indenttabs--;

    mygbfprintf (fpgb, "end %s;\n", idstr);
    if (!is_parameterised_mod) {
       mybfprintf (fpb, "end %s;\n", idstr);
    }
}

void ATr_Visible (Ident)
    tIdPos Ident;
{
    char idstr[IDENT_LENGTH];

    mygetstr(Ident.Ident, idstr);
    mygsfprintf (fpgs, "use %s;\n", idstr);
    if (!is_parameterised_mod) {
        mysfprintf (fps, "use %s;\n", idstr);
    }
}

void ATr_Enum(Ident, BranchList)
    tIdPos Ident;
    tTree BranchList;
{
    char idstr[IDENT_LENGTH];
    char bridstr[IDENT_LENGTH];
    tTree branchlist=BranchList;

    mygetstr(Ident.Ident, idstr);
    mygsfprintf (fpgs, "type %s is (", idstr);
    if (!is_parameterised_mod) {
        mysfprintf (fps, "type %s is (", idstr);
    }
    for (; branchlist && branchlist->Kind != kNoBranch; 
           branchlist=branchlist->Branch.Next) {
        if (branchlist->Kind == kFTConstant) {
            mygetstr (branchlist->FTConstant.Ident.Ident, bridstr); 
            fprintf (fpgs, "%s", bridstr);
            if (!is_parameterised_mod) {
               fprintf (fps, "%s", bridstr);
            }
        }
        if (branchlist->Branch.Next->Kind != kNoBranch) {
            fprintf (fpgs, ", ");
            if (!is_parameterised_mod) {
               fprintf (fps, ", ");
            }
        }
    }
    /* fprintf(fpgs, ")\n");
    if (!is_parameterised_mod) {
        fprintf(fps, ")\n"); 
    } */
    specprint(");\n");
}


/* Added to allow LogSeq to be printed to Ada */
/* allows LogSeq to be printed without comments if at top level */
/* uses comments for other LogBinOps */


void ATr_LogBinPred (L, LogBinOp, R)
    tTree L, R;
    tTree LogBinOp; 
{
    switch (LogBinOp->Kind) {
    case kLogEquiv:
	fprintf (fp, "-- ");
        Unparse (L);
        fprintf (fp, " <=> ");
        Unparse (R);
	fprintf (fp, ";\n"); 
        break;
    case kLogImply:
	fprintf (fp, "-- ");
        Unparse (L);
        fprintf (fp, " => ");
        Unparse (R);
	fprintf (fp, ";\n"); 
        break;
    case kLogAnd:
	fprintf (fp, "-- ");
        Unparse (L);
        fprintf (fp, " and ");
        Unparse (R);
	fprintf (fp, ";\n"); 
        break;
    case kLogOr:
	fprintf (fp, "-- ");
        Unparse (L);
        fprintf (fp, " or ");
        Unparse (R);
	fprintf (fp, ";\n");
        break;
    case kLogExor:
	fprintf (fp, "-- ");
        Unparse (L);
        fprintf (fp, " exor ");
        Unparse (R);
	fprintf (fp, ";\n"); 
        break;
    case kLogSeq:
        TransAda (L);
        fprintf (fp, ";\n ");
        TransAda (R);
        break;
    }
}

void ATr_Assign (DeclsIn, NameList, ExpList)
    tObjects DeclsIn;
    tTree NameList, ExpList;
{
    tTree namelist, explist;
    char idstr[IDENT_LENGTH];
    extern int indenttabs;
    tObjects sym;

    /* translate x,y,z := y+z,x+y,z+1 to                            */
    /*                                                              */
    /* declare                                                      */
    /*    x_temp : basetypeof x;                                    */
    /*    y_temp : basetypeof y;                                    */
    /*    z_temp : basetypeof z;                                    */
    /* begin                                                        */
    /*    x_temp := y+z;                                            */
    /*    y_temp := x+y;                                            */
    /*    z_temp := z+1;                                            */
    /*    x := x_temp;                                              */
    /*    y := z_temp;                                              */
    /*    z := z_temp;                                              */
    /* end                                                          */
    /* NOTE Special case if single assignment                       */
    /* NOTE Special case if array assignment                        */

    /* Check WF of LHS - no duplicates                              */
    /* Check WF of RHS - no primed vars  (comment out)              */
    /* Need to get actual types of vars and create temp variables   */
    /* must generate full ada names of each variable ??             */
    /* must translate the expressions on the rhs -                  */
    /* for IL expressions just translate to the ada equivalents     */
    /* for sum expressions use Unparse within comments              */
    /* to be tidy it would be best to only have one comment per line*/
    /* dont forget indentation */

    /* note special case of translating if-expressions on rhs       */


    if (NameList->Name.Next->Kind == kNoName) {
       if (ExpList->Kind == kArrayUpd) 
          ATr_ArrayUpd(ExpList->ArrayUpd.Array, ExpList->ArrayUpd.Index,
                                                ExpList->ArrayUpd.Value);
       else {
          Unparse_IdList (NameList->Name.IdList, idstr); 
          myfprintf(fp,  "%s := ", idstr);             
          TransAda(ExpList);
          return;
       }
    }

    myfprintf(fp,  "declare\n");

    /* do not forget WF constraints */


    /* print out temp variable declations */
    
    indenttabs++;
    explist = ExpList;
    for (namelist=NameList; namelist && namelist->Kind != kNoName; 
        namelist=namelist->Name.Next) {

        if (explist->Kind == kArrayUpd) {
          Unparse_IdList (explist->ArrayUpd.Array, idstr);
          if ((sym = LookUpName(DeclsIn, explist->ArrayUpd.Array, NoSym)) != NoSym){
            myfprintf(fp, "%s_ind: ", idstr);
            TransAdaType(sym->Object.Type->Tp_Infix.Fst);
            fprintf(fp, ";\n"); 
            myfprintf(fp, "%s_temp: ", idstr);
            TransAdaType(sym->Object.Type->Tp_Infix.Snd);
            fprintf(fp, ";\n"); 
          }
        }
        else {
          Unparse_IdList (namelist->Name.IdList, idstr);
          myfprintf(fp, "%s_temp: ", idstr);

          /* myfprintf(fp, "%s_temp: type_of(%s);\n", idstr, idstr); */
          /* No type Attribute                                       */
          /*  *** going to have to store declared type in symtab     */

          /*  lookup basetype */

         if ((sym = LookUpName(DeclsIn, namelist->Name.IdList, NoSym)) != NoSym)
              TransAdaType(sym->Object.Type); 
         else
              DError(namelist->Name.Pos, ada_error12); 

        fprintf(fp, ";\n"); 
  
        }


        explist=explist->Exp.Next;
    }

    indenttabs--;
    myfprintf(fp,  "begin\n");

    /* print out temporary assignments */
    indenttabs++;
    explist = ExpList;
    for (namelist=NameList; namelist && namelist->Kind != kNoName; 
        namelist=namelist->Name.Next) {

        if (explist->Kind == kArrayUpd) {

          Unparse_IdList (explist->ArrayUpd.Array, idstr);
          myfprintf(fp, "%s_ind := ", idstr); 
          TransAda(explist->ArrayUpd.Index);
          fprintf(fp, ";\n"); 
          myfprintf(fp, "%s_temp := ", idstr); 
          TransAda(explist->ArrayUpd.Value);
          fprintf(fp, ";\n"); 

        }
        else {

          Unparse_IdList (namelist->Name.IdList, idstr);

          myfprintf(fp, "%s_temp := ", idstr); 

          /* call unparse to get textual translation of expression */
          /* this is dangerous as expressions escape to predicates */

          TransAda(explist);
          fprintf(fp, ";\n"); 

        }

        explist=explist->Exp.Next;

    }

    explist = ExpList;
    for (namelist=NameList; namelist && namelist->Kind != kNoName; 
        namelist=namelist->Name.Next) {

        if (explist->Kind == kArrayUpd) {
          Unparse_IdList (explist->ArrayUpd.Array, idstr);
          myfprintf(fp, "%s(%s_ind) := %s_temp;\n", idstr, idstr, idstr); 
        }
        else {
          Unparse_IdList (namelist->Name.IdList, idstr);
          myfprintf(fp, "%s := %s_temp;\n", idstr, idstr);
        }

        explist=explist->Exp.Next;
    }

    indenttabs--;
    myfprintf(fp,  "end");
}


void ATr_ArrayUpd(Array, Index, Value)
    tTree Array;
    tTree Index, Value;
{
    char idstr[IDENT_LENGTH];

    myfprintf(fp, "");
    Unparse_IdList(Array, idstr);
    fprintf(fp, "%s", idstr);
    fprintf(fp, "(");
    TransAda(Index);
    fprintf(fp, ") := ");
    TransAda(Value);
}

/* Generating if statements -   */
/*  syntax, what if no else, formatting  */ 
/* must do Unparse and GF as well and ergo*/
/* add an elseif ?*/


void ATr_IfPred(Con, Then, Else)
    tTree Con, Then, Else;
{

   myfprintf(fp, "if ");
   TransAda(Con);
   fprintf(fp, " then\n");
   indenttabs++;
   TransAda(Then);
   fprintf(fp,";\n");
   indenttabs--;
   if (Else->Kind != kNoPred) {
     myfprintf(fp, "else\n");
     indenttabs++;
     TransAda(Else);
     fprintf(fp,";\n");
     indenttabs--;
   }
   myfprintf(fp, "end if");
   
}

void ATr_WhilePred(Con, Do)
    tTree Con, Do;
{
   myfprintf(fp, "while ");
   TransAda(Con);
   myfprintf(fp, "loop\n");
   indenttabs++;
   TransAda(Do);
   fprintf(fp,";\n");
   indenttabs--;
   myfprintf(fp, "end loop");
}

void ATr_CallPred (IdList, InputBindList, OutputBindList)
    tTree IdList, InputBindList, OutputBindList;
{
    tTree idlist=IdList;
    tTree ibl=InputBindList;
    tTree obl=OutputBindList;

    char idstr[IDENT_LENGTH];
    char namestr[IDENT_LENGTH];
    bool brackets=false;


    /* write to form */
    /* idlist(first ibl1 => second ibl1, ... first obl1 => second obl1 ...) */


    Unparse_IdList (idlist, idstr);
    myfprintf(fp, "%s", idstr);
    if (ibl->Kind != kNoInputBind) {brackets=true; fprintf(fp, "(");}
    for (;ibl->Kind != kNoInputBind; ibl= ibl->InputBind.Next) {
         Unparse_Id (ibl->InputBind.Ident, idstr);
         fprintf(fp, "%s => ", idstr);
         TransAda(ibl->InputBind.ExpressionList);
         if (!(ibl->InputBind.Next->Kind == kNoInputBind &&
             obl->Kind == kNoOutputBind))
            fprintf (fp, ", ");
    }
    if (!brackets && obl->Kind != kNoOutputBind){brackets = true; fprintf(fp, "(");}
    for (;obl->Kind != kNoOutputBind; obl= obl->OutputBind.Next) {
         Unparse_Id (obl->OutputBind.Ident, idstr);
         fprintf(fp, "%s => ", idstr);
         Unparse_IdList (obl->OutputBind.IdList, namestr);
         fprintf(fp, "%s", namestr);
         if (obl->OutputBind.Next->Kind != kNoOutputBind)
            fprintf (fp, ", ");
    }
    if (brackets) fprintf(fp, ")");
}

bool InDeclList(DeclList, Id)
    tTree DeclList;
    tIdent Id;
{
    tTree decllist = DeclList;
    tTree idlist;

    for (;decllist && decllist->Kind !=kNoDecl; decllist=decllist->Decl.Next) 
      for (idlist=decllist->VarDecl.IdList; idlist && idlist->Kind != kNoId;
                                                     idlist=idlist->Id.Next)
         if (Id == idlist->Id.Ident.Ident)
           return true;
    return false;
}

void ATr_DeclList(DeclList)
    tTree DeclList;
{
    tTree decllist = DeclList;
    tTree idlist;
    char idstr[IDENT_LENGTH];
    char varstr[IDENT_LENGTH];
    tIdent newid;
    int printtype;                   /* counter to see if any vars printed */
    int i,n;


    for (; decllist->Kind != kNoDecl; decllist= decllist->Decl.Next) 

        if (decllist->Kind == kVarDecl) {
            idlist = decllist->VarDecl.IdList;
        
            INDENT;
            printtype = 0;

            /* strip pling and bang  - should be _in and _out*/
        
            for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) {
                mygetstr (idlist->Id.Ident.Ident, varstr);   
                mygetstr (idlist->Id.Ident.Ident, idstr);   
                n = strlen(idstr);
                for (i=0; i < n; i++)
                  if (idstr[i] == '!' || idstr[i] == '\'' || idstr[i] == '?') {
                       idstr[i] = '\0';
                       break;
                  }
        
                  /* if primed and unprimed exists then ignore primed */
                  /* otherwise fix_decor and print */
                             
                  newid = MakeIdent(idstr, i);
                  if (IsPrimed(varstr) && InDeclList(DeclList, newid)) {
                               continue;
                   } else {
                      ++printtype; 
                      fprintf (fp, "%s", idstr);
                      if (idlist->Id.Next->Kind != kNoId) {
                         fprintf (fp, ", ");
                      }
                   }

            }

            if (printtype > 0){
                fprintf(fp," : ");
                TransAda(decllist->VarDecl.Exp);
                fprintf(fp,";\n");
            }
        }
}

void ATr_QuantPred (LogQuant, SchemaText, Pred)
    tIdPos LogQuant;
    tTree SchemaText;
    tTree Pred;
{
    char quantifier[IDENT_LENGTH];
    int printtype;                   /* counter to see if any vars printed */
    tTree decllist=SchemaText->SchemaText.DeclList;

/* if the quantifier is "var" then generate block structure */
/* else print quantifier in comments and use Unparse        */

/* GOING TO HAVE to unfold to search for duplicate definitions */


    if (LogQuant.Ident == Ident_var) { 
        /* mygetstr (LogQuant.Ident, quantifier); */
        myfprintf (fp, "declare\n");
        indenttabs++;
        for (; decllist->Kind != kNoDecl; 
                                 decllist= decllist->Decl.Next) {
            tTree idlist=decllist->VarDecl.IdList;
            char idstr[IDENT_LENGTH];
            char varstr[IDENT_LENGTH];
            tIdent newid;
            int i,n;
        
                INDENT;
                printtype = 0;

                /* strip pling and bang  - should be _in and _out*/
        
                for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) {
                    mygetstr (idlist->Id.Ident.Ident, varstr);   
                    mygetstr (idlist->Id.Ident.Ident, idstr);   
                    n = strlen(idstr);
                    for (i=0; i < n; i++)
                        if (idstr[i] == '!' || idstr[i] == '\'' || idstr[i] == '?') {
                            idstr[i] = '\0';
                            break;
                        }
        
                        /* if primed and unprimed exists then ignore primed */
                        /* otherwise fix_decor and print */
                             
                    newid = MakeIdent(idstr, i);
                    if (IsPrimed(varstr) && InDeclList(SchemaText->SchemaText.DeclList, newid)) {
                               continue;
                    } else {
                        if (printtype++>0) fprintf (fp, ", ");
                        fprintf (fp, "%s", idstr);
                    }

                }

                if (printtype > 0){
                  fprintf(fp," : ");
                  TransAda(decllist->VarDecl.Exp);
                  fprintf(fp,";\n");
                }
        }
        fprintf (fp, "\n"); 
        indenttabs--;
        myfprintf (fp, "begin\n");
        indenttabs++;
        TransAda (Pred);
        fprintf (fp, ";\n"); 
        indenttabs--;
        myfprintf (fp, "end"); 
    }
    else {
        fprintf(fp, "-- ");
        mygetstr (LogQuant.Ident, quantifier);
        fprintf (fp, "%s ", quantifier);
        Unparse(SchemaText);
        fprintf (fp, " @ ");
        Unparse (Pred);
        fprintf (fp, "\n"); 
    }
        
}

/* 
   to really do this right we should be checking the types of the operators
   can this be done ? is it stored in tree?
   mostly a problem for overloaded ops ! 
 */

void ATr_RelBinPred (L, RelBinOp, R)
   tTree L, R;
   tIdPos RelBinOp;
{
    char relbinop[IDENT_LENGTH];

    TransAda (L);
    mygetstr (RelBinOp.Ident, relbinop);
    if (RelBinOp.Ident == Ident_ltc)
        fprintf (fp, " < ");
    else if (RelBinOp.Ident == Ident_ltec)
        fprintf (fp, " <= ");
    else if (RelBinOp.Ident == Ident_gtc)
        fprintf (fp, " > ");
    else if (RelBinOp.Ident == Ident_gtec)
        fprintf (fp, " >= ");
    else if (RelBinOp.Ident == Ident_eqc)
        fprintf (fp, " = ");
    else if (RelBinOp.Ident == Ident_neqc)
        fprintf (fp, " /= ");
    /* put equals in any way and probably anything else from enum */
    else if (RelBinOp.Ident == Ident_equal)
        fprintf (fp, " = ");
    else if (RelBinOp.Ident == Ident_less)
        fprintf (fp, " < ");
    else if (RelBinOp.Ident == Ident_notgrt)
        fprintf (fp, " <= ");
    else if (RelBinOp.Ident == Ident_grt)
        fprintf (fp, " > ");
    else if (RelBinOp.Ident == Ident_notless)
        fprintf (fp, " >= ");
    else if (RelBinOp.Ident == Ident_notequ)
        fprintf (fp, " /= ");
    else {
       /* NOT from IL */
        fprintf(fp, "-- ");
        fprintf (fp, " %s ", relbinop); 
    }
    TransAda (R);
}


void ATr_RelPrePred (RelPreOp, Exp) 
    tIdPos RelPreOp;
    tTree Exp;
{
    char relpreop[IDENT_LENGTH];

    mygetstr (RelPreOp.Ident, relpreop);
    fprintf (fp, "%s ", relpreop);
    TransAda (Exp);
}

void ATr_BoolValue (Ident)
    tIdPos Ident;
{
    char idstr[IDENT_LENGTH];

    mygetstr(Ident.Ident, idstr);
    fprintf (fp, "%s", idstr);
}


void ATr_PredList (PredList)
    tTree PredList;
{
    tTree predlist;

    for (predlist=PredList; predlist && predlist->Kind != kNoPred;
        predlist=predlist->Pred.Next) {

         /* lw 14/10/96 moved commenting to TransAda as some 
            predicates are not commented out */
	 /*	fprintf (fp, "-- "); */
        TransAda (predlist);
	 /*	fprintf (fp, ";\n"); */
    }
}

void ATr_ExpList (ExpList)
    tTree ExpList;
{
    tTree explist;

    for (explist=ExpList; explist && explist->Kind != kNoExp;
        explist=explist->Exp.Next) {

        TransAda (explist);
        if (explist->Exp.Next->Kind != kNoExp)
            fprintf (fp, ", ");
    }
}

void ATr_Literal (Literal)
    tIdPos Literal;
{
    char idstr[IDENT_LENGTH];

    mygetstr (Literal.Ident, idstr);
    fprintf (fp, "%s", idstr);
}

void ATr_PrefixOp (Prefix, Exp)
    tIdPos Prefix;
    tTree Exp;
{
    char prefix[IDENT_LENGTH];

    mygetstr (Prefix.Ident, prefix);
    if (Exp->Kind == kInfixOp || Exp->Kind == kCartProd)
        fprintf (fp, "%s (", prefix);
    else
        fprintf (fp, "%s ", prefix);

    TransAda (Exp);

    if (Exp->Kind == kInfixOp || Exp->Kind == kCartProd)
        fprintf (fp, ")");
}

void ATr_InfixOp (Op1, Infix, Op2)
    tTree Op1, Op2;
    tIdPos Infix;
{


      if (Infix.Ident == Ident_subc){ 
           TransAda (Op1);
           fprintf (fp, " - ");
           TransAda (Op2);
      }
      else if (Infix.Ident == Ident_addc){ 
           TransAda (Op1);
           fprintf (fp, " + ");
           TransAda (Op2);
      }
      else if (Infix.Ident == Ident_multc){ 
           TransAda (Op1);
           fprintf (fp, " * ");
           TransAda (Op2);
      }
      else if (Infix.Ident == Ident_divc){ 
           TransAda (Op1);
           fprintf (fp, " / ");
           TransAda (Op2);
      }
      else if (Infix.Ident == Ident_modc){ 
           TransAda (Op1);
           fprintf (fp, " mod ");
           TransAda (Op2);
      }
      else if (Infix.Ident == Ident_expc){ 
           TransAda (Op1);
           fprintf (fp, "**");
           TransAda (Op2);
      }
      else if (Infix.Ident == Ident_andc){ 
           TransAda (Op1);
           fprintf (fp, " and ");
           TransAda (Op2);
      }
      else if (Infix.Ident == Ident_orc){ 
           TransAda (Op1);
           fprintf (fp, " or ");
           TransAda (Op2);
      }
      else if (Infix.Ident == Ident_xorc){ 
           TransAda (Op1);
           fprintf (fp, " xor ");
           TransAda (Op2);
      }
      else if (Infix.Ident == Ident_uptoc){ 
           fprintf(fp, "integer range ");
           TransAda (Op1);
           fprintf (fp, " .. ");
           TransAda (Op2);
      }
      else { 

          /* not a IL construct */
          fprintf (fp, "-- ");
          Unparse_InfixOp(Op1, Infix, Op2);
      }
}

/* Extend translation of Fnc Application to handle arrays          */
/* caught at puma level                                            */

void ATr_ArrayDef(Arg)
    tTree Arg;
{
    fprintf(fp, "array (");
    TransAda(Arg);
    fprintf(fp, ") of ");
    if (Arg->Exp.Next && Arg->Exp.Next->Kind != kNoExp)
        TransAda(Arg->Exp.Next);   /*Check exists */
    else
        Error(Arg->Exp.Pos, ada_error13); 
}

void ATr_FncApplication(Fnc, Arg)
    tTree Fnc, Arg;
{
    TransAda (Fnc);
    fprintf (fp, " (");
    ATr_ExpList (Arg);
    fprintf (fp, ")");
}



void ATr_NamedArrayAgg (ExpList)
    tTree ExpList;
{
    tTree explist;

    /* the expressionlist is a list of Expression maplet Expression */
    /* we want to output Expression => Expression                   */

    fprintf (fp, "(");

    for (explist=ExpList; explist && explist->Kind != kNoExp;
        explist=explist->Exp.Next) {

        if (explist->Kind == kInfixOp) {
          TransAda (explist->InfixOp.Op1);
          fprintf (fp, " => ");
          TransAda(explist->InfixOp.Op2);
        } else
          Error (explist->Exp.Pos, ada_error14);
    
        if (explist->Exp.Next->Kind != kNoExp)
            fprintf (fp, ", ");
    }

    fprintf (fp, ")");
}

void ATr_Sequence (ExpressionList)
    tTree ExpressionList;
{
    fprintf (fp, "<");
    ATr_ExpList (ExpressionList);
    fprintf (fp, ">");
}

void ATr_Tuple (ExpressionList)
    tTree ExpressionList;
{
    fprintf (fp, "(");
    ATr_ExpList (ExpressionList);
    fprintf (fp, ")");
}

void ATr_Bag (ExpressionList)
    tTree ExpressionList;
{
    fprintf (fp, "|[");
    ATr_ExpList (ExpressionList);
    fprintf (fp, "]|");
}

void ATr_IfExp (Con, Then, Else)
    tTree Con, Then, Else;
{
    fprintf (fp, "if ");
    TransAda (Con);
    fprintf (fp, " then ");
    TransAda (Then);
    fprintf (fp, " else ");
    TransAda (Else);
    fprintf (fp, " fi");
}

void ATr_CartProd (ExpressionList)
    tTree ExpressionList;
{
    tTree explist=ExpressionList;

    for (; explist && explist->Kind != kNoExp; explist=explist->Exp.Next) {
        TransAda (explist);
        if (explist->Exp.Next->Kind != kNoExp)
            fprintf (fp, " cross ");
    }
}

void ATr_VarSelection (Exp, Ident)
    tTree Exp;
    tIdPos Ident;
{
    char idstr[IDENT_LENGTH];

    Unparse (Exp);
    mygetstr (Ident.Ident, idstr);
    fprintf (fp, ".%s", idstr);
}


void ATr_RecDisp (SchemaText, PredList)
    tTree SchemaText, PredList;
{
    tTree plist=PredList;
    tTree p1;

    /* forget VarDecl not used */
    /* go through predicate list and translate each predicatre  */
    /* as (x => y, .. )  */
    /* check each predicate is x = y */


    fprintf (fp, " (");
    for (; plist && plist->Kind != kNoPred; plist=plist->Pred.Next) {
        if (plist->Kind != kRelBinPred) 
         Error (plist->Pred.Pos, ada_error15);
        else
          if (plist->RelBinPred.RelBinOp.Ident != Ident_equal) 
            Error (plist->Pred.Pos, ada_error15);
          else {
            /* also check that first expression is an Ident */
            p1 = plist->RelBinPred.L;
            if (p1->Kind != kVariable)
               Error (plist->Pred.Pos, ada_error16);
            else {
              TransAda(plist->RelBinPred.L);
              fprintf (fp, "=> ");
              TransAda(plist->RelBinPred.R);
            }
          }

        if (plist->Pred.Next->Kind != kNoPred)
            fprintf (fp, ", ");
    }
    fprintf (fp, ") ");
 
}

void ATr_TupSelection (Exp, Number)
    tTree Exp;
    tIdPos Number;
{
    char number[IDENT_LENGTH];

    Unparse (Exp);
    mygetstr (Number.Ident, number);
    fprintf (fp, ".%s", number);
}

void ATr_Exp_SchemaRef (IdList, ExpressionList)
    tTree IdList, ExpressionList;
{
    char idstr[IDENT_LENGTH]; 

    Unparse_Name (IdList, idstr);
    fprintf (fp, "%s[", idstr);
    ATr_ExpList (ExpressionList);
    fprintf (fp, "]");
}

void ATr_PredExp (Pred)
	tTree Pred;
{
/* wj -- 2/9/99 Ada does not understand these brackets */
/*	fprintf (fp, "("); */
	TransAda (Pred);
/*	fprintf (fp, ")"); */
}

/*  UNPARSE */

void Unparse_DeclList (DeclList)
    tTree DeclList;
{
    tTree decllist;

    for (decllist=DeclList; decllist && decllist->Kind != kNoDecl;
        decllist=decllist->Decl.Next) {

        Unparse (decllist);
        if (decllist->Decl.Next->Kind != kNoDecl)
            fprintf (fp, "; ");
    }
}

void Unparse_Id (Ident, str)
    tIdPos Ident;
    char *str;
{
    tIdPos id=Ident;
    char idstr[IDENT_LENGTH];
    int n;

    str[0] = '\0';
    mygetstr (id.Ident, idstr);
    n = strlen(idstr) - 1;
    if (idstr[n] == '?') {
        idstr[n] = '\0';
        strcat(idstr, "_in");
    } else if(idstr[n] == '!') {
        idstr[n] = '\0';
        strcat(idstr, "_out");
    }
/* what about multiple dashes etc */
    else if (idstr[n] == '\'') {
        idstr[n] = '\0';
        strcat(idstr, "_dash");
    }
    strcat (str, idstr);
}

void Unparse_IdList (IdList, str)  /* lpw? */
    tTree IdList;
    char *str;
{
    tTree idlist=IdList;
    char idstr[IDENT_LENGTH];

    str[0] = '\0';
    for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) {
        Unparse_Id (idlist->Id.Ident, idstr);
        strcat (str, idstr);
        if (idlist->Id.Next->Kind != kNoId)
            strcat (str, ".");
    }
}

void Unparse_VarDecl (IdList, Exp)
    tTree IdList;
    tTree Exp;
{
    tTree idlist=IdList;
    char idstr[IDENT_LENGTH];

    for (; idlist && idlist->Kind != kNoId; idlist=idlist->Id.Next) {
        mygetstr (idlist->Id.Ident.Ident, idstr);
        if (idlist->Id.Next->Kind != kNoId)
            fprintf (fp, "%s, ", idstr);
        else
            fprintf (fp, "%s:", idstr);
    }
    Unparse (Exp);
/*  fprintf (fp, "\n"); */
}

void Unparse_PredList (PredList)
    tTree PredList;
{
    tTree predlist;

    for (predlist=PredList; predlist && predlist->Kind != kNoPred;
        predlist=predlist->Pred.Next) {

        Unparse (predlist);
        if (predlist->Pred.Next->Kind != kNoPred)
            fprintf (fp, ";");
    }
}



void Unparse_RelBinPred (L, RelBinOp, R)
   tTree L, R;
   tIdPos RelBinOp;
{
    char relbinop[IDENT_LENGTH];

    Unparse (L);
    mygetstr (RelBinOp.Ident, relbinop);
    fprintf (fp, " %s ", relbinop); 
    Unparse (R);
}

void Unparse_RelPrePred (RelPreOp, Exp) 
    tIdPos RelPreOp;
    tTree Exp;
{
    char relpreop[IDENT_LENGTH];

    mygetstr (RelPreOp.Ident, relpreop);
    fprintf (fp, "%s ", relpreop);
    Unparse (Exp);
}

void Unparse_LogBinPred (L, LogBinOp, R)
    tTree L, R;
    tTree LogBinOp; 
{
    Unparse (L);
    switch (LogBinOp->Kind) {
    case kLogEquiv:
        fprintf (fp, " <=> ");
        break;
    case kLogImply:
        fprintf (fp, " => ");
        break;
    case kLogAnd:
        fprintf (fp, " and ");
        break;
    case kLogOr:
        fprintf (fp, " or ");
        break;
    case kLogExor:
        fprintf (fp, " exor ");
        break;
    case kLogSeq:
        fprintf (fp, " ;; ");  /* lpw added for il 16/10/96 */
        break;
    }
    Unparse (R);
}

void Unparse_LogicalNot (Pred) 
    tTree Pred;
{
    fprintf (fp, "not ");
    Unparse (Pred);
}

void Unparse_PreCondPred (Pred)
    tTree Pred;
{
    fprintf (fp, "pre ");
    Unparse (Pred);
}

void Unparse_ChgOnly (NameList)
    tTree NameList;
{
    tTree namelist;
    char idstr[IDENT_LENGTH]; 

    fprintf (fp, "changes_only {");

    for (namelist=NameList; namelist && namelist->Kind != kNoName; 
        namelist=namelist->Name.Next) {

        Unparse_Name (namelist->Name.IdList, idstr);
        if (namelist->Name.Next->Kind != kNoName)
            fprintf (fp, "%s, ", idstr);
        else
            fprintf (fp, "%s}", idstr);
    }
}

void Unparse_BoolValue (Ident)
    tIdPos Ident;
{
    char idstr[IDENT_LENGTH];

    mygetstr(Ident.Ident, idstr);
    fprintf (fp, "%s", idstr);
}

void Unparse_SchemaText (DeclList, PredList, ild)
    tTree DeclList, PredList;
    bool ild;
{
    if (!ild) fprintf (fp, "[ ");
    Unparse (DeclList);
    if (PredList->Kind != kNoPred) {
        fprintf (fp, " | ");
        Unparse_PredList (PredList);
    }
    if (!ild) fprintf (fp, " ]");
}

void Unparse_SchemaCompos (Sch1, Sch2)
    tTree Sch1, Sch2;
{
    Unparse (Sch1);
    fprintf (fp, " s_compose ");
    Unparse (Sch2);
}

void Unparse_SchemaHiding (Schema, NameList)
    tTree Schema, NameList;
{
    tTree namelist;
    char idstr[IDENT_LENGTH]; 

    Unparse (Schema);
    fprintf (fp, "\\ ( ");

    for (namelist=NameList; namelist && namelist->Kind != kNoName; 
        namelist=namelist->Name.Next) {

        Unparse_Name (namelist->Name.IdList, idstr);
        if (namelist->Name.Next->Kind != kNoName)
            fprintf (fp, "%s, ", idstr);
        else
            fprintf (fp, "%s )", idstr);
    }
}

void Unparse_SchemaProj (Sch1, Sch2)
    tTree Sch1, Sch2;
{
    Unparse (Sch1);
    fprintf (fp, " |^ ");
    Unparse (Sch2);
}

void Unparse_SchemaSubst (Schema, RenameList)
    tTree Schema, RenameList;
{
    char idstr[IDENT_LENGTH]; 
    char newidstr[IDENT_LENGTH];
    tTree renamelist;

    Unparse (Schema);
    fprintf (fp, " { ");

    for (renamelist=RenameList; renamelist && renamelist->Kind != kNoRename;
        renamelist=renamelist->Rename.Next) {

        Unparse_Id (renamelist->Rename.NewIdent, newidstr); 
        fprintf (fp, "/");

        Unparse_IdList (renamelist->Rename.OldIdent, idstr);
        if (renamelist->Rename.Next->Kind != kNoRename)
            fprintf (fp, "%s, ", idstr);
        else
            fprintf (fp, "%s }", idstr);
    }
}

void Unparse_ExpList (ExpList)
    tTree ExpList;
{
    tTree explist;

    for (explist=ExpList; explist && explist->Kind != kNoExp;
        explist=explist->Exp.Next) {

        Unparse (explist);
        if (explist->Exp.Next->Kind != kNoExp)
            fprintf (fp, ", ");
    }
}

void Unparse_Literal (Literal)
    tIdPos Literal;
{
    char idstr[IDENT_LENGTH];

    mygetstr (Literal.Ident, idstr);
    fprintf (fp, "%s", idstr);
}

void Unparse_PrefixOp (Prefix, Exp)
    tIdPos Prefix;
    tTree Exp;
{
    char prefix[IDENT_LENGTH];

    mygetstr (Prefix.Ident, prefix);
    if (Exp->Kind == kInfixOp || Exp->Kind == kCartProd)
        fprintf (fp, "%s (", prefix);
    else
        fprintf (fp, "%s ", prefix);

    Unparse (Exp);

    if (Exp->Kind == kInfixOp || Exp->Kind == kCartProd)
        fprintf (fp, ")");
}

void Unparse_InfixOp (Op1, Infix, Op2)
    tTree Op1, Op2;
    tIdPos Infix;
{
    char infix[IDENT_LENGTH];

    mygetstr (Infix.Ident, infix);
    Unparse (Op1);
    fprintf (fp, " %s ", infix);
    Unparse (Op2);
}

void Unparse_FncApplication(Fnc, Arg)
    tTree Fnc, Arg;
{
    Unparse (Fnc);
    fprintf (fp, " (");
    Unparse_ExpList (Arg);
    fprintf (fp, ")");
}

void Unparse_SetComp (SchemaText, Exp)
    tTree SchemaText, Exp;
{
    fprintf (fp, "{ dec");
    Unparse(SchemaText);
    if (Exp->Kind != kNoExp){
      fprintf(fp, " @ ");
      Unparse(Exp);
    }
    fprintf (fp, "}");
}

void Unparse_SetElab (ExpressionList)
    tTree ExpressionList;
{
    fprintf (fp, "{");
    Unparse_ExpList (ExpressionList);
    fprintf (fp, "}");
}

void Unparse_Sequence (ExpressionList)
    tTree ExpressionList;
{
    fprintf (fp, "<");
    Unparse_ExpList (ExpressionList);
    fprintf (fp, ">");
}

void Unparse_Tuple (ExpressionList)
    tTree ExpressionList;
{
    fprintf (fp, "(");
    Unparse_ExpList (ExpressionList);
    fprintf (fp, ")");
}

void Unparse_Bag (ExpressionList)
    tTree ExpressionList;
{
    fprintf (fp, "|[");
    Unparse_ExpList (ExpressionList);
    fprintf (fp, "]|");
}

void Unparse_IfExp (Con, Then, Else)
    tTree Con, Then, Else;
{
    fprintf (fp, "if ");
    Unparse (Con);
    fprintf (fp, " then ");
    Unparse (Then);
    fprintf (fp, " else ");
    Unparse (Else);
    fprintf (fp, " fi");
}

void Unparse_CartProd (ExpressionList)
    tTree ExpressionList;
{
    tTree explist=ExpressionList;

    for (; explist && explist->Kind != kNoExp; explist=explist->Exp.Next) {
        Unparse (explist);
        if (explist->Exp.Next->Kind != kNoExp)
            fprintf (fp, " cross ");
    }
}

void Unparse_VarSelection (Exp, Ident)
    tTree Exp;
    tIdPos Ident;
{
    char idstr[IDENT_LENGTH];

    Unparse (Exp);
    mygetstr (Ident.Ident, idstr);
    fprintf (fp, ".%s", idstr);
}

void Unparse_TupSelection (Exp, Number)
    tTree Exp;
    tIdPos Number;
{
    char number[IDENT_LENGTH];

    Unparse (Exp);
    mygetstr (Number.Ident, number);
    fprintf (fp, ".%s", number);
}

void Unparse_Exp_SchemaRef (IdList, ExpressionList)
    tTree IdList, ExpressionList;
{
    char idstr[IDENT_LENGTH]; 

    Unparse_Name (IdList, idstr);
    fprintf (fp, "%s[", idstr);
    Unparse_ExpList (ExpressionList);
    fprintf (fp, "]");
}

void Unparse_PredExp (Pred)
	tTree Pred;
{
/* wj -- 2/9/99 Ada does not understand these brackets so need to be ignored */
	fprintf (fp, "("); 
	Unparse (Pred);
	fprintf (fp, ")"); 
}





static void yyExit () { Exit (1); }

void (* SumToAda_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module SumToAda, routine %s failed\n", yyFunction);
 SumToAda_Exit ();
}

void TransAda ARGS((tTree t));
void TransAdaType ARGS((tType t));
static void Unparse_QuantPred ARGS((tIdPos LogQuant, tTree SchemaText, tTree Pred));
static void Unparse_Lambda ARGS((tTree SchemaText, tTree Exp));
static void Unparse_Mu ARGS((tTree SchemaText, tTree ExpressionList));
static void Unparse_RecDisp ARGS((tTree SchemaText, tTree PredList));
void Unparse ARGS((tTree t));

void TransAda
# if defined __STDC__ | defined __cplusplus
(register tTree t)
# else
(t)
 register tTree t;
# endif
{

  switch (t->Kind) {
  case kSum:
/* line 2815 "SumToAda.puma" */
  {
/* line 2816 "SumToAda.puma" */
   TransAda (t->Sum.ModuleList);
  }
   return;

  case kModule:
/* line 2819 "SumToAda.puma" */
  {
/* line 2819 "SumToAda.puma" */

        if (t->Module.FormalParams->Kind == kNoParam)
            is_parameterised_mod = false;
        else
            is_parameterised_mod = true;

        CreateAdaFile (t->Module.Ident);
        has_state_and_init (t->Module.Next->Module.DeclsIn);
        ATr_Module (t->Module.Ident, t->Module.FormalParams, t->Module.DeclList); 
        ATransClose();    
    
/* line 2830 "SumToAda.puma" */
   TransAda (t->Module.Next);
  }
   return;

  case kGivenSet:
/* line 2833 "SumToAda.puma" */
  {
/* line 2834 "SumToAda.puma" */
   TransAda (t->GivenSet.Next);
  }
   return;

  case kErgoAnno:
/* line 2836 "SumToAda.puma" */
  {
/* line 2837 "SumToAda.puma" */
   TransAda (t->ErgoAnno.Next);
  }
   return;

  case kVarDecl:
/* line 2839 "SumToAda.puma" */
  {
/* line 2840 "SumToAda.puma" */
   ATr_VarDecl (t->VarDecl.IdList, t->VarDecl.Exp);
/* line 2841 "SumToAda.puma" */
   TransAda (t->VarDecl.Next);
  }
   return;

  case kAxiomDecl:
/* line 2843 "SumToAda.puma" */
  {
/* line 2844 "SumToAda.puma" */
   TransAda (t->AxiomDecl.Next);
  }
   return;

  case kFunctionDecl:
/* line 2846 "SumToAda.puma" */
  {
/* line 2847 "SumToAda.puma" */
   ATr_FunctionDecl (t->FunctionDecl.DeclList, t->FunctionDecl.PredList);
/* line 2848 "SumToAda.puma" */
   TransAda (t->FunctionDecl.Next);
  }
   return;

  case kSchemaDef:
/* line 2850 "SumToAda.puma" */
  {
/* line 2851 "SumToAda.puma" */
   ATr_SchemaDef (t->SchemaDef.DeclsIn, t->SchemaDef.Ident, t->SchemaDef.DeclList, t->SchemaDef.PredList, t->SchemaDef.DeclList -> Decl . DeclsOut, t->SchemaDef.IsOp);
/* line 2852 "SumToAda.puma" */
   TransAda (t->SchemaDef.Next);
  }
   return;

  case kAbbreviation:
/* line 2854 "SumToAda.puma" */
  {
/* line 2855 "SumToAda.puma" */
   ATr_Abbrev (t->Abbreviation.Ident, t->Abbreviation.Exp);
/* line 2856 "SumToAda.puma" */
   TransAda (t->Abbreviation.Next);
  }
   return;

  case kStateMachine:
/* line 2858 "SumToAda.puma" */
  {
/* line 2859 "SumToAda.puma" */
   ATr_StateMachine (t->StateMachine.IdList);
/* line 2860 "SumToAda.puma" */
   TransAda (t->StateMachine.Next);
  }
   return;

  case kImport:
/* line 2862 "SumToAda.puma" */
  {
/* line 2863 "SumToAda.puma" */
   ATr_Import (t->Import.Ident, t->Import.ExpressionList, t->Import.NewIdent, t->Import.RenameList);
/* line 2864 "SumToAda.puma" */
   TransAda (t->Import.Next);
  }
   return;

  case kVisibility:
/* line 2866 "SumToAda.puma" */
  {
/* line 2867 "SumToAda.puma" */
   ATr_Visible (t->Visibility.Ident);
/* line 2868 "SumToAda.puma" */
   TransAda (t->Visibility.Next);
  }
   return;

  case kModuleDecl:
/* line 2870 "SumToAda.puma" */
  {
/* line 2871 "SumToAda.puma" */
   TransAda (t->ModuleDecl.Next);
  }
   return;

  case kSchemaIncl:
/* line 2873 "SumToAda.puma" */
  {
/* line 2874 "SumToAda.puma" */
   TransAda (t->SchemaIncl.Next);
  }
   return;

  case kFreeType:
/* line 2876 "SumToAda.puma" */
  {
/* line 2877 "SumToAda.puma" */
   TransAda (t->FreeType.Next);
  }
   return;

  case kEnum:
/* line 2879 "SumToAda.puma" */
  {
/* line 2880 "SumToAda.puma" */
   ATr_Enum (t->Enum.Ident, t->Enum.BranchList);
/* line 2881 "SumToAda.puma" */
   TransAda (t->Enum.Next);
  }
   return;

  case kQuantPred:
/* line 2885 "SumToAda.puma" */
  {
/* line 2886 "SumToAda.puma" */
   ATr_QuantPred (t->QuantPred.LogQuant, t->QuantPred.SchemaText, t->QuantPred.Pred);
  }
   return;

  case kRelBinPred:
/* line 2888 "SumToAda.puma" */
  {
/* line 2889 "SumToAda.puma" */
   ATr_RelBinPred (t->RelBinPred.L, t->RelBinPred.RelBinOp, t->RelBinPred.R);
  }
   return;

  case kRelPrePred:
/* line 2891 "SumToAda.puma" */
  {
/* line 2892 "SumToAda.puma" */
   ATr_RelPrePred (t->RelPrePred.RelPreOp, t->RelPrePred.Exp);
  }
   return;

  case kLogBinPred:
/* line 2894 "SumToAda.puma" */
  {
/* line 2895 "SumToAda.puma" */
   ATr_LogBinPred (t->LogBinPred.L, t->LogBinPred.LogBinOp, t->LogBinPred.R);
  }
   return;

  case kLogicalNot:
/* line 2897 "SumToAda.puma" */
  {
/* line 2898 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 2899 "SumToAda.puma" */
   Unparse_LogicalNot (t->LogicalNot.Pred);
/* line 2900 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kPreCondPred:
/* line 2902 "SumToAda.puma" */
  {
/* line 2903 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 2904 "SumToAda.puma" */
   Unparse_PreCondPred (t->PreCondPred.Pred);
/* line 2905 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kChgOnly:
/* line 2907 "SumToAda.puma" */
  {
/* line 2908 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 2909 "SumToAda.puma" */
   Unparse_ChgOnly (t->ChgOnly.NameList);
/* line 2910 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kSchemaPred:
  if (t->SchemaPred.Schema->Kind == kExpPred) {
  if (t->SchemaPred.Schema->ExpPred.Exp->Kind == kPredExp) {
  if (t->SchemaPred.Schema->ExpPred.Exp->PredExp.Pred->Kind == kQuantPred) {
/* line 2913 "SumToAda.puma" */
  {
/* line 2914 "SumToAda.puma" */
   ATr_QuantPred (t->SchemaPred.Schema->ExpPred.Exp->PredExp.Pred->QuantPred.LogQuant, t->SchemaPred.Schema->ExpPred.Exp->PredExp.Pred->QuantPred.SchemaText, t->SchemaPred.Schema->ExpPred.Exp->PredExp.Pred->QuantPred.Pred);
  }
   return;

  }
  }
/* line 2917 "SumToAda.puma" */
  {
/* line 2918 "SumToAda.puma" */
   TransAda (t->SchemaPred.Schema->ExpPred.Exp);
/* line 2919 "SumToAda.puma" */
   fprintf (fp, "\n");
  }
   return;

  }
/* line 2921 "SumToAda.puma" */
  {
/* line 2924 "SumToAda.puma" */
   Unparse (t->SchemaPred.Schema);
/* line 2925 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kAssign:
/* line 2927 "SumToAda.puma" */
  {
/* line 2928 "SumToAda.puma" */
   ATr_Assign (t->Assign.DeclsIn, t->Assign.L, t->Assign.R);
  }
   return;

  case kIfPred:
/* line 2935 "SumToAda.puma" */
  {
/* line 2936 "SumToAda.puma" */
   ATr_IfPred (t->IfPred.Con, t->IfPred.Then, t->IfPred.Else);
  }
   return;

  case kWhilePred:
/* line 2938 "SumToAda.puma" */
  {
/* line 2939 "SumToAda.puma" */
   ATr_WhilePred (t->WhilePred.Con, t->WhilePred.Do);
  }
   return;

  case kCallPred:
/* line 2941 "SumToAda.puma" */
  {
/* line 2943 "SumToAda.puma" */
   ATr_CallPred (t->CallPred.IdList, t->CallPred.InputBindList, t->CallPred.OutputBindList);
  }
   return;

  case kBoolValue:
/* line 2945 "SumToAda.puma" */
  {
/* line 2946 "SumToAda.puma" */
   ATr_BoolValue (t->BoolValue.Ident);
  }
   return;

  case kDefined:
/* line 2949 "SumToAda.puma" */
  {
/* line 2950 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 2951 "SumToAda.puma" */
   Unparse (t->Defined.Exp);
/* line 2952 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kVariable:
/* line 2958 "SumToAda.puma" */
  {
/* line 2959 "SumToAda.puma" */
   ATr_VarExp (t->Variable.IdList);
  }
   return;

  case kLiteral:
/* line 2961 "SumToAda.puma" */
  {
/* line 2962 "SumToAda.puma" */
   ATr_Literal (t->Literal.Literal);
  }
   return;

  case kString:
/* line 2964 "SumToAda.puma" */
  {
/* line 2965 "SumToAda.puma" */
   ATr_Literal (t->String.String);
  }
   return;

  case kChar:
/* line 2967 "SumToAda.puma" */
  {
/* line 2968 "SumToAda.puma" */
   ATr_Literal (t->Char.Char);
  }
   return;

  case kPrefixOp:
/* line 2970 "SumToAda.puma" */
  {
/* line 2971 "SumToAda.puma" */
   ATr_PrefixOp (t->PrefixOp.Prefix, t->PrefixOp.Exp);
  }
   return;

  case kInfixOp:
/* line 2973 "SumToAda.puma" */
  {
/* line 2974 "SumToAda.puma" */
   ATr_InfixOp (t->InfixOp.Op1, t->InfixOp.Infix, t->InfixOp.Op2);
  }
   return;

  case kFncApplication:
/* line 2976 "SumToAda.puma" */
  {
/* line 2976 "SumToAda.puma" */

        if (t->FncApplication.Fnc->Kind == kVariable &&
            t->FncApplication.Fnc->Variable.IdList->Id.Ident.Ident == Ident_array)
              ATr_ArrayDef(t->FncApplication.Arg);
        else
              ATr_FncApplication(t->FncApplication.Fnc, t->FncApplication.Arg);
        
  }
   return;

  case kSetComp:
/* line 2984 "SumToAda.puma" */
  {
/* line 2985 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 2986 "SumToAda.puma" */
   Unparse_SetComp (t->SetComp.SchemaText, t->SetComp.ExpressionList);
/* line 2987 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kSetElab:
/* line 2989 "SumToAda.puma" */
  {
/* line 2990 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 2991 "SumToAda.puma" */
   Unparse_SetElab (t->SetElab.ExpressionList);
/* line 2992 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kNamedArrayAgg:
/* line 2994 "SumToAda.puma" */
  {
/* line 2995 "SumToAda.puma" */
   ATr_NamedArrayAgg (t->NamedArrayAgg.ExpressionList);
  }
   return;

  case kSequence:
/* line 2997 "SumToAda.puma" */
  {
/* line 2998 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 2999 "SumToAda.puma" */
   Unparse_Sequence (t->Sequence.ExpressionList);
/* line 3000 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kTuple:
/* line 3002 "SumToAda.puma" */
  {
/* line 3003 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 3004 "SumToAda.puma" */
   Unparse_Tuple (t->Tuple.ExpressionList);
/* line 3005 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kBag:
/* line 3007 "SumToAda.puma" */
  {
/* line 3008 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 3009 "SumToAda.puma" */
   Unparse_Bag (t->Bag.ExpressionList);
/* line 3010 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kIfExp:
/* line 3012 "SumToAda.puma" */
  {
/* line 3013 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 3014 "SumToAda.puma" */
   Unparse_IfExp (t->IfExp.Con, t->IfExp.Then, t->IfExp.Else);
/* line 3015 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kCartProd:
/* line 3017 "SumToAda.puma" */
  {
/* line 3018 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 3019 "SumToAda.puma" */
   Unparse_CartProd (t->CartProd.ExpressionList);
/* line 3020 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kVarSelection:
/* line 3022 "SumToAda.puma" */
  {
/* line 3023 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 3024 "SumToAda.puma" */
   Unparse_VarSelection (t->VarSelection.Exp, t->VarSelection.Ident);
/* line 3025 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kLambda:
/* line 3027 "SumToAda.puma" */
  {
/* line 3028 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 3029 "SumToAda.puma" */
   Unparse_Lambda (t->Lambda.SchemaText, t->Lambda.Exp);
/* line 3030 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kMu:
/* line 3032 "SumToAda.puma" */
  {
/* line 3033 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 3034 "SumToAda.puma" */
   Unparse_Mu (t->Mu.SchemaText, t->Mu.ExpressionList);
/* line 3035 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kRecDisp:
/* line 3037 "SumToAda.puma" */
  {
/* line 3038 "SumToAda.puma" */
   ATr_RecDisp (t->RecDisp.SchemaText, t->RecDisp.PredList);
  }
   return;

  case kTupSelection:
/* line 3040 "SumToAda.puma" */
  {
/* line 3041 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 3042 "SumToAda.puma" */
   Unparse_TupSelection (t->TupSelection.Exp, t->TupSelection.Number);
/* line 3043 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kExp_SchemaRef:
/* line 3045 "SumToAda.puma" */
  {
/* line 3046 "SumToAda.puma" */
   fprintf (fp, "-- ");
/* line 3047 "SumToAda.puma" */
   Unparse_Exp_SchemaRef (t->Exp_SchemaRef.IdList, t->Exp_SchemaRef.ExpressionList);
/* line 3048 "SumToAda.puma" */
   fprintf (fp, ";\n");
  }
   return;

  case kPredExp:
/* line 3050 "SumToAda.puma" */
  {
/* line 3051 "SumToAda.puma" */
   ATr_PredExp (t->PredExp.Pred);
  }
   return;

  case kName:
/* line 3056 "SumToAda.puma" */
  {
/* line 3056 "SumToAda.puma" */
 
	char idstr[IDENT_LENGTH];

        Unparse_IdList(t->Name.IdList, idstr);
        fprintf(fp, "%s", idstr);
         
  }
   return;

  }

;
}

void TransAdaType
# if defined __STDC__ | defined __cplusplus
(register tType t)
# else
(t)
 register tType t;
# endif
{
  if (Type_IsType (t, kTp_Exp)) {
/* line 3068 "SumToAda.puma" */
  {
/* line 3068 "SumToAda.puma" */

	char idstr[IDENT_LENGTH];
	char modstr[IDENT_LENGTH];
        tIdent ParentModId;
 
            if (t->Tp_Exp.Ident == Ident_int) {
                fprintf (fp, "INTEGER");
            }
            else if (t->Tp_Exp.Ident == Ident_nat) {
                fprintf (fp, "NATURAL");
            }
            else if (t->Tp_Exp.Ident == Ident_nat_1) {
                fprintf (fp, "POSITIVE");
            }
            else if (t->Tp_Exp.Ident == Ident_bool) {
                fprintf (fp, "BOOLEAN");
            }
            else if (t->Tp_Exp.Ident == Ident_string) {
                fprintf (fp, "STRING");
            }
            else if (t->Tp_Exp.Ident == Ident_char) {
                fprintf (fp, "CHARACTER");
            }
            else {
                mygetstr (t->Tp_Exp.Ident, idstr);
                mygetstr (t->Tp_Exp.ModId, modstr);
                if ((strcmp(cur_mod_name, modstr) == 0) &&
                     (fp == fpgs) || (fp == fpgb))
                 fprintf (fp, "gen_%s.%s", modstr, idstr);
                else
                 fprintf (fp, "%s.%s", modstr, idstr); 
            }
        
    
  }
   return;

  }
;
}

static void Unparse_QuantPred
# if defined __STDC__ | defined __cplusplus
(tIdPos LogQuant, register tTree SchemaText, register tTree Pred)
# else
(LogQuant, SchemaText, Pred)
 tIdPos LogQuant;
 register tTree SchemaText;
 register tTree Pred;
# endif
{
/* line 3104 "SumToAda.puma" */
  {
/* line 3105 "SumToAda.puma" */

    char quantifier[IDENT_LENGTH];

    mygetstr (LogQuant.Ident, quantifier);
    fprintf (fp, "%s ", quantifier);
    Unparse(SchemaText);
    fprintf (fp, " @ ");
    Unparse (Pred);


  }
   return;

;
}

static void Unparse_Lambda
# if defined __STDC__ | defined __cplusplus
(register tTree SchemaText, register tTree Exp)
# else
(SchemaText, Exp)
 register tTree SchemaText;
 register tTree Exp;
# endif
{
/* line 3117 "SumToAda.puma" */
  {
/* line 3117 "SumToAda.puma" */
 
        fprintf(fp, "lambda");
        Unparse(SchemaText);
        fprintf(fp, " @ ");
        Unparse(Exp);
     
  }
   return;

;
}

static void Unparse_Mu
# if defined __STDC__ | defined __cplusplus
(register tTree SchemaText, register tTree ExpressionList)
# else
(SchemaText, ExpressionList)
 register tTree SchemaText;
 register tTree ExpressionList;
# endif
{
/* line 3125 "SumToAda.puma" */
  {
/* line 3125 "SumToAda.puma" */
 
        fprintf(fp, "mu ");
        Unparse(SchemaText);
     
  }
   return;

;
}

static void Unparse_RecDisp
# if defined __STDC__ | defined __cplusplus
(register tTree SchemaText, register tTree PredList)
# else
(SchemaText, PredList)
 register tTree SchemaText;
 register tTree PredList;
# endif
{
/* line 3137 "SumToAda.puma" */
  {
/* line 3137 "SumToAda.puma" */
 
        fprintf(fp, "record ");
        Unparse(SchemaText);
        fprintf(fp, " @ ");
        Unparse_PredList(PredList);
     
  }
   return;

;
}

void Unparse
# if defined __STDC__ | defined __cplusplus
(register tTree t)
# else
(t)
 register tTree t;
# endif
{

  switch (t->Kind) {
  case kVarDecl:
/* line 3164 "SumToAda.puma" */
  {
/* line 3165 "SumToAda.puma" */
   Unparse_VarDecl (t->VarDecl.IdList, t->VarDecl.Exp);
  }
   return;

  case kSchemaIncl:
/* line 3167 "SumToAda.puma" */
  {
/* line 3167 "SumToAda.puma" */

        if (t->SchemaIncl.ExpressionList->Kind != kNoExp)
            Unparse_Exp_SchemaRef (t->SchemaIncl.IdList, t->SchemaIncl.ExpressionList);
        else {
            char idstr[IDENT_LENGTH]; 

            
            Unparse_Name (t->SchemaIncl.IdList, idstr);
            fprintf (fp, "%s", idstr);
        };
    
  }
   return;

  case kNoPred:
/* line 3236 "SumToAda.puma" */
   return;

  case kQuantPred:
/* line 3238 "SumToAda.puma" */
  {
/* line 3239 "SumToAda.puma" */
   Unparse_QuantPred (t->QuantPred.LogQuant, t->QuantPred.SchemaText, t->QuantPred.Pred);
  }
   return;

  case kRelBinPred:
/* line 3241 "SumToAda.puma" */
  {
/* line 3242 "SumToAda.puma" */
   Unparse_RelBinPred (t->RelBinPred.L, t->RelBinPred.RelBinOp, t->RelBinPred.R);
  }
   return;

  case kRelPrePred:
/* line 3244 "SumToAda.puma" */
  {
/* line 3245 "SumToAda.puma" */
   Unparse_RelPrePred (t->RelPrePred.RelPreOp, t->RelPrePred.Exp);
  }
   return;

  case kLogBinPred:
/* line 3247 "SumToAda.puma" */
  {
/* line 3248 "SumToAda.puma" */
   Unparse_LogBinPred (t->LogBinPred.L, t->LogBinPred.LogBinOp, t->LogBinPred.R);
  }
   return;

  case kLogicalNot:
/* line 3250 "SumToAda.puma" */
  {
/* line 3251 "SumToAda.puma" */
   Unparse_LogicalNot (t->LogicalNot.Pred);
  }
   return;

  case kPreCondPred:
/* line 3253 "SumToAda.puma" */
  {
/* line 3254 "SumToAda.puma" */
   Unparse_PreCondPred (t->PreCondPred.Pred);
  }
   return;

  case kChgOnly:
/* line 3256 "SumToAda.puma" */
  {
/* line 3257 "SumToAda.puma" */
   Unparse_ChgOnly (t->ChgOnly.NameList);
  }
   return;

  case kSchemaPred:
/* line 3259 "SumToAda.puma" */
  {
/* line 3260 "SumToAda.puma" */
   Unparse (t->SchemaPred.Schema);
  }
   return;

  case kBoolValue:
/* line 3262 "SumToAda.puma" */
  {
/* line 3263 "SumToAda.puma" */
   Unparse_BoolValue (t->BoolValue.Ident);
  }
   return;

  case kExpPred:
/* line 3266 "SumToAda.puma" */
  {
/* line 3267 "SumToAda.puma" */
   Unparse (t->ExpPred.Exp);
  }
   return;

  case kSchemaText:
/* line 3269 "SumToAda.puma" */
  {
/* line 3270 "SumToAda.puma" */
fprintf (fp, "-- ");
        Unparse_SchemaText (t->SchemaText.DeclList, t->SchemaText.PredList, t->SchemaText.Is_local_dec);
  }
   return;

  case kSchemaCompos:
/* line 3273 "SumToAda.puma" */
  {
/* line 3274 "SumToAda.puma" */
fprintf (fp, "-- ");
        Unparse_SchemaCompos(t->SchemaCompos.Sch1, t->SchemaCompos.Compos, t->SchemaCompos.Sch2);
  }
   return;

  case kSchemaHiding:
/* line 3277 "SumToAda.puma" */
  {
/* line 3278 "SumToAda.puma" */
fprintf (fp, "-- ");
        Unparse_SchemaHiding (t->SchemaHiding.Schema, t->SchemaHiding.NameList);
  }
   return;

  case kSchemaProj:
/* line 3281 "SumToAda.puma" */
  {
/* line 3282 "SumToAda.puma" */
fprintf (fp, "-- ");
        Unparse_SchemaProj (t->SchemaProj.Sch1, t->SchemaProj.Proj, t->SchemaProj.Sch2);
  }
   return;

  case kSchemaSubst:
/* line 3285 "SumToAda.puma" */
  {
/* line 3286 "SumToAda.puma" */
fprintf (fp, "-- ");
        Unparse_SchemaSubst (t->SchemaSubst.Schema, t->SchemaSubst.RenameList);
  }
   return;

  case kVariable:
/* line 3290 "SumToAda.puma" */
  {
/* line 3290 "SumToAda.puma" */

		char idstr[IDENT_LENGTH];

        Unparse_Name (t->Variable.IdList, idstr);  
		fprintf (fp, "%s", idstr);
	
  }
   return;

  case kLiteral:
/* line 3297 "SumToAda.puma" */
  {
/* line 3298 "SumToAda.puma" */
   Unparse_Literal (t->Literal.Literal);
  }
   return;

  case kString:
/* line 3300 "SumToAda.puma" */
  {
/* line 3301 "SumToAda.puma" */
   Unparse_Literal (t->String.String);
  }
   return;

  case kChar:
/* line 3303 "SumToAda.puma" */
  {
/* line 3304 "SumToAda.puma" */
   Unparse_Literal (t->Char.Char);
  }
   return;

  case kPrefixOp:
/* line 3306 "SumToAda.puma" */
  {
/* line 3307 "SumToAda.puma" */
   Unparse_PrefixOp (t->PrefixOp.Prefix, t->PrefixOp.Exp);
  }
   return;

  case kInfixOp:
/* line 3309 "SumToAda.puma" */
  {
/* line 3310 "SumToAda.puma" */
   Unparse_InfixOp (t->InfixOp.Op1, t->InfixOp.Infix, t->InfixOp.Op2);
  }
   return;

  case kFncApplication:
/* line 3312 "SumToAda.puma" */
  {
/* line 3313 "SumToAda.puma" */
   Unparse_FncApplication (t->FncApplication.Fnc, t->FncApplication.Arg);
  }
   return;

  case kSetComp:
/* line 3315 "SumToAda.puma" */
  {
/* line 3316 "SumToAda.puma" */
   Unparse_SetComp (t->SetComp.SchemaText, t->SetComp.ExpressionList);
  }
   return;

  case kSetElab:
/* line 3318 "SumToAda.puma" */
  {
/* line 3319 "SumToAda.puma" */
   Unparse_SetElab (t->SetElab.ExpressionList);
  }
   return;

  case kSequence:
/* line 3321 "SumToAda.puma" */
  {
/* line 3322 "SumToAda.puma" */
   Unparse_Sequence (t->Sequence.ExpressionList);
  }
   return;

  case kTuple:
/* line 3324 "SumToAda.puma" */
  {
/* line 3325 "SumToAda.puma" */
   Unparse_Tuple (t->Tuple.ExpressionList);
  }
   return;

  case kBag:
/* line 3327 "SumToAda.puma" */
  {
/* line 3328 "SumToAda.puma" */
   Unparse_Bag (t->Bag.ExpressionList);
  }
   return;

  case kIfExp:
/* line 3330 "SumToAda.puma" */
  {
/* line 3331 "SumToAda.puma" */
   Unparse_IfExp (t->IfExp.Con, t->IfExp.Then, t->IfExp.Else);
  }
   return;

  case kCartProd:
/* line 3333 "SumToAda.puma" */
  {
/* line 3334 "SumToAda.puma" */
   Unparse_CartProd (t->CartProd.ExpressionList);
  }
   return;

  case kVarSelection:
/* line 3336 "SumToAda.puma" */
  {
/* line 3337 "SumToAda.puma" */
   Unparse_VarSelection (t->VarSelection.Exp, t->VarSelection.Ident);
  }
   return;

  case kLambda:
/* line 3340 "SumToAda.puma" */
  {
/* line 3341 "SumToAda.puma" */
   Unparse_Lambda (t->Lambda.SchemaText, t->Lambda.Exp);
  }
   return;

  case kMu:
/* line 3343 "SumToAda.puma" */
  {
/* line 3344 "SumToAda.puma" */
   Unparse_Mu (t->Mu.SchemaText, t->Mu.ExpressionList);
  }
   return;

  case kRecDisp:
/* line 3346 "SumToAda.puma" */
  {
/* line 3347 "SumToAda.puma" */
   Unparse_RecDisp (t->RecDisp.SchemaText, t->RecDisp.PredList);
  }
   return;

  case kTupSelection:
/* line 3349 "SumToAda.puma" */
  {
/* line 3350 "SumToAda.puma" */
   Unparse_TupSelection (t->TupSelection.Exp, t->TupSelection.Number);
  }
   return;

  case kExp_SchemaRef:
/* line 3352 "SumToAda.puma" */
  {
/* line 3353 "SumToAda.puma" */
   Unparse_Exp_SchemaRef (t->Exp_SchemaRef.IdList, t->Exp_SchemaRef.ExpressionList);
  }
   return;

  case kPredExp:
/* line 3355 "SumToAda.puma" */
  {
/* line 3356 "SumToAda.puma" */
   Unparse_PredExp (t->PredExp.Pred);
  }
   return;

  }

;
}

void BeginSumToAda ()
{
/* line 29 "SumToAda.puma" */

    extern int indenttabs;
    extern bool has_state;
    extern bool has_init;
    indenttabs = 0;
    has_state=false;
    has_init=false;

}

void CloseSumToAda ()
{
}
