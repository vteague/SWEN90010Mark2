/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
/* 
Version: $Id: global.c,v 1.2 2000/03/22 04:06:29 cogito Exp $
*/

#include <stddef.h>
#include <stdio.h>
#include "global.h"

void* mymy_malloc (n, line, file)
	size_t n;
	long int line;
	char *file;
{
	void *p = (void *) malloc (n);
	
	if (p==NULL) {
		fprintf (stderr, "Internal error: malloc failure: ");
		fprintf (stderr, "line %ld, file `%s'\n", line, file);
		exit (1); /* EXIT_FAILURE > 0 */ 
	}
	return p;
}

/* another preprocessing trick for malloc failure 
static void *malloc_tmp;
#undef malloc
#define malloc(n) \
	((malloc_tmp = malloc(n) ? malloc_tmp: \
	(void*) malloc_error((long)__LINE__, __FILE__))

void* malloc_error(long int line, char *file)
{ see above "my_malloc"
}
*/

/* read a Position structure from an ascii tree write */


void ReadPosition(file,pos)
  FILE *file;
  tPosition *pos;
{
  int i,j;
  fscanf(file,"%*c"); /* extra space for ReadTree algorithm */
  fscanf(file,"%3d,%3d",&i,&j);
  pos->Line = i;
  pos->Column = j;
}

/* write an IdPos to an ascii tree file */

void WriteIdPos(file,id)
     FILE * file;
     tIdPos id;
{
  fprintf(file," "); /* extra space for ReadTree algorithm */
  if (id.Ident > 0)
    {WriteIdent(file,id.Ident);
    WritePosition(file,id.Pos);
    }
  else
    fprintf(file,"NoIdent");
}

/* read an IdPos from an ascii tree file */

void ReadIdPos(file,id)
     FILE * file;
     tIdPos *id;
{
  char str[256];
  fscanf(file,"%s",str);
  if (strcmp("NoIdent",str) != 0)
    {id->Ident = MakeIdent((tString)str,strlen(str));
    ReadPosition(file,&id->Pos);}
  else
    {id->Ident = NoIdent;
    id->Pos = NoPosition;}
}

