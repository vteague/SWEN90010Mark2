# ifndef yyZTree
# define yyZTree

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

/* line 9 "z.ast" */

#include "Idents.h" 
#include "Positions.h"
#include "global.h" 
#include "env.h"
#include "ZSyms.h"


# ifndef bool
# define bool char
# endif
# define NoZTree (tZTree) 0L
# define kSpecification 1
# define kGlobalParagraphSeq 2
# define knoGlobalParagraph 3
# define kglobalParagraphs 4
# define kGlobalParagraph 5
# define kaxiomaticDef 6
# define khorizPar 7
# define kgenericDef 8
# define kschemaboxDef 9
# define kHorizParagraphs 10
# define knoHorizParagraph 11
# define khorizParagraphs 12
# define kHorizParagraph 13
# define ktypeDef 14
# define kglobalPredicate 15
# define kschemaDef 16
# define kTypeDef 17
# define kgivenSet 18
# define kfreeType 19
# define ktypeDef1 20
# define ktypeDefPregen 21
# define ktypeDefIngen 22
# define kNameFormals 23
# define knoFormals 24
# define knameFormals 25
# define kBranchSeq 26
# define knoBranch 27
# define kbranch 28
# define kZFormalParams 29
# define knoFormalParams 30
# define kformalParams 31
# define kZBranch 32
# define ksimpleBranch 33
# define kcompoundBranch 34
# define kSchemaExp 35
# define kschemaSimple 36
# define kschemaDes 37
# define kschemaPreop 38
# define kschemaCons 39
# define kschemaHide 40
# define kschemaQuant 41
# define kschemaComp 42
# define kschemaProject 43
# define kschemaPipe 44
# define kschemaParen 45
# define kDesignator 46
# define kVarNameSeq 47
# define knoVarName 48
# define kvarNames 49
# define kExpressionSeq 50
# define knoExpSeq 51
# define kexpSeq 52
# define kRenameSeq 53
# define knoRename 54
# define krenames 55
# define kVarRename 56
# define kZSchemaText 57
# define kDeclaration 58
# define knoDecl 59
# define kdecl 60
# define kBasicDecl 61
# define kcolonDecl 62
# define kschemaRef 63
# define kPredicate 64
# define knoPred 65
# define kpredNegate 66
# define kpredInfixRelSeq 67
# define kpredTrueOrFalse 68
# define kpredSchemaRef 69
# define kpredPreRel 70
# define kpredCons 71
# define kpredQuant 72
# define kpredLet 73
# define kpredParen 74
# define kPredInfixRelSeq 75
# define knoInfixRel 76
# define kinfixRels 77
# define kPredInfixRel 78
# define kInfixRel 79
# define kExpression 80
# define knoExp 81
# define kexpBinaryGen 82
# define kexpBinaryFun 83
# define kexpLiteral 84
# define kexpOpname 85
# define kexpSetElab 86
# define kexpSeqElab 87
# define kexpBagElab 88
# define kexpSetComp 89
# define kexpPowerSet 90
# define kexpPreGen 91
# define kexpPostFun 92
# define kexpIter 93
# define kexpTuple 94
# define kexpCartProd 95
# define kexpTheta 96
# define kexpSelectVar 97
# define kexpFnApp 98
# define kexpMu 99
# define kexpLambda 100
# define kexpLet 101
# define kexpIf 102
# define kexpImage 103
# define kexpDesignator 104
# define kexpParen 105
# define kLetDefSeq 106
# define knoLetDef 107
# define kletDefs 108
# define kLetDef 109
# define kVarName 110
# define kZId 111
# define kOpname 112
# define kDecoration 113
# define knoDecoration 114
# define kdecoration 115
# define kZName 116

typedef unsigned char ZTree_tKind;
typedef unsigned short ZTree_tMark;
typedef unsigned short ZTree_tLabel;
typedef union ZTree_Node * tZTree;
typedef void (* ZTree_tProcTree) ();

# ifndef ZTree_NodeHead
# define ZTree_NodeHead
# endif
typedef struct { ZTree_tKind yyKind; ZTree_tMark yyMark; ZTree_NodeHead } ZTree_tNodeHead;
typedef struct { ZTree_tNodeHead yyHead; tZTree GlobalParagraphSeq; } ySpecification;
typedef struct { ZTree_tNodeHead yyHead; } yGlobalParagraphSeq;
typedef struct { ZTree_tNodeHead yyHead; } ynoGlobalParagraph;
typedef struct { ZTree_tNodeHead yyHead; tZTree GlobalParagraph; tZTree Next; } yglobalParagraphs;
typedef struct { ZTree_tNodeHead yyHead; } yGlobalParagraph;
typedef struct { ZTree_tNodeHead yyHead; tZTree ZSchemaText; } yaxiomaticDef;
typedef struct { ZTree_tNodeHead yyHead; tZTree HorizParagraphs; } yhorizPar;
typedef struct { ZTree_tNodeHead yyHead; tZTree ZFormalParams; tZTree ZSchemaText; } ygenericDef;
typedef struct { ZTree_tNodeHead yyHead; tZTree ZName; tZTree ZFormalParams; tZTree ZSchemaText; } yschemaboxDef;
typedef struct { ZTree_tNodeHead yyHead; } yHorizParagraphs;
typedef struct { ZTree_tNodeHead yyHead; } ynoHorizParagraph;
typedef struct { ZTree_tNodeHead yyHead; tZTree HorizParagraph; tZTree Next; } yhorizParagraphs;
typedef struct { ZTree_tNodeHead yyHead; } yHorizParagraph;
typedef struct { ZTree_tNodeHead yyHead; tZTree TypeDef; } ytypeDef;
typedef struct { ZTree_tNodeHead yyHead; tZTree Predicate; } yglobalPredicate;
typedef struct { ZTree_tNodeHead yyHead; tZTree NameFormals; tZTree SchemaExp; } yschemaDef;
typedef struct { ZTree_tNodeHead yyHead; } yTypeDef;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarNameSeq; } ygivenSet;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarName; tZTree BranchSeq; } yfreeType;
typedef struct { ZTree_tNodeHead yyHead; tZTree NameFormals; tZTree Expression; } ytypeDef1;
typedef struct { ZTree_tNodeHead yyHead; tIdPos PreGen; tZTree Decoration; tZTree VarName; tZTree Expression; } ytypeDefPregen;
typedef struct { ZTree_tNodeHead yyHead; tZTree Var1; tIdPos InGen; tZTree Decoration; tZTree Var2; tZTree Expression; } ytypeDefIngen;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarName; } yNameFormals;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarName; } ynoFormals;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarName; tZTree ZFormalParams; } ynameFormals;
typedef struct { ZTree_tNodeHead yyHead; } yBranchSeq;
typedef struct { ZTree_tNodeHead yyHead; } ynoBranch;
typedef struct { ZTree_tNodeHead yyHead; tZTree ZBranch; tZTree Next; } ybranch;
typedef struct { ZTree_tNodeHead yyHead; } yZFormalParams;
typedef struct { ZTree_tNodeHead yyHead; } ynoFormalParams;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarNameSeq; } yformalParams;
typedef struct { ZTree_tNodeHead yyHead; } yZBranch;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarName; } ysimpleBranch;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarName; tZTree Expression; } ycompoundBranch;
typedef struct { ZTree_tNodeHead yyHead; } ySchemaExp;
typedef struct { ZTree_tNodeHead yyHead; tZTree ZSchemaText; } yschemaSimple;
typedef struct { ZTree_tNodeHead yyHead; tZTree Designator; } yschemaDes;
typedef struct { ZTree_tNodeHead yyHead; tIdPos PreOp; tZTree SchemaExp; } yschemaPreop;
typedef struct { ZTree_tNodeHead yyHead; tZTree Lop; tIdPos SchemaOp; tZTree Rop; } yschemaCons;
typedef struct { ZTree_tNodeHead yyHead; tZTree SchemaExp; tZTree VarNameSeq; } yschemaHide;
typedef struct { ZTree_tNodeHead yyHead; tIdPos LogQuant; tZTree ZSchemaText; tZTree SchemaExp; } yschemaQuant;
typedef struct { ZTree_tNodeHead yyHead; tZTree Lop; tZTree Rop; } yschemaComp;
typedef struct { ZTree_tNodeHead yyHead; tZTree Lop; tZTree Rop; } yschemaProject;
typedef struct { ZTree_tNodeHead yyHead; tZTree Lop; tZTree Rop; } yschemaPipe;
typedef struct { ZTree_tNodeHead yyHead; tZTree SchemaExp; } yschemaParen;
typedef struct { ZTree_tNodeHead yyHead; tZTree ZName; tZTree Decoration; tZTree ExpressionSeq; tZTree RenameSeq; bool IsSchemaRef; } yDesignator;
typedef struct { ZTree_tNodeHead yyHead; } yVarNameSeq;
typedef struct { ZTree_tNodeHead yyHead; } ynoVarName;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarName; tZTree Next; } yvarNames;
typedef struct { ZTree_tNodeHead yyHead; } yExpressionSeq;
typedef struct { ZTree_tNodeHead yyHead; } ynoExpSeq;
typedef struct { ZTree_tNodeHead yyHead; tZTree Expression; tZTree Next; } yexpSeq;
typedef struct { ZTree_tNodeHead yyHead; } yRenameSeq;
typedef struct { ZTree_tNodeHead yyHead; } ynoRename;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarRename; tZTree Next; } yrenames;
typedef struct { ZTree_tNodeHead yyHead; tZTree New; tZTree Old; } yVarRename;
typedef struct { ZTree_tNodeHead yyHead; tZTree Declaration; tZTree Predicate; } yZSchemaText;
typedef struct { ZTree_tNodeHead yyHead; } yDeclaration;
typedef struct { ZTree_tNodeHead yyHead; } ynoDecl;
typedef struct { ZTree_tNodeHead yyHead; tZTree BasicDecl; tZTree Next; } ydecl;
typedef struct { ZTree_tNodeHead yyHead; } yBasicDecl;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarNameSeq; tZTree Expression; } ycolonDecl;
typedef struct { ZTree_tNodeHead yyHead; tZTree Designator; } yschemaRef;
typedef struct { ZTree_tNodeHead yyHead; } yPredicate;
typedef struct { ZTree_tNodeHead yyHead; } ynoPred;
typedef struct { ZTree_tNodeHead yyHead; tZTree Predicate; } ypredNegate;
typedef struct { ZTree_tNodeHead yyHead; tZTree PredInfixRelSeq; } ypredInfixRelSeq;
typedef struct { ZTree_tNodeHead yyHead; tIdPos TrueFalse; } ypredTrueOrFalse;
typedef struct { ZTree_tNodeHead yyHead; tIdPos PredOrPre; tZTree Designator; } ypredSchemaRef;
typedef struct { ZTree_tNodeHead yyHead; tIdPos PreRel; tZTree Decoration; tZTree Expression; } ypredPreRel;
typedef struct { ZTree_tNodeHead yyHead; tZTree Lpred; tIdPos LogOp; tZTree Rpred; } ypredCons;
typedef struct { ZTree_tNodeHead yyHead; tIdPos LogQuant; tZTree ZSchemaText; tZTree Predicate; } ypredQuant;
typedef struct { ZTree_tNodeHead yyHead; tZTree LetDefSeq; tZTree Predicate; } ypredLet;
typedef struct { ZTree_tNodeHead yyHead; tZTree Predicate; } ypredParen;
typedef struct { ZTree_tNodeHead yyHead; } yPredInfixRelSeq;
typedef struct { ZTree_tNodeHead yyHead; } ynoInfixRel;
typedef struct { ZTree_tNodeHead yyHead; tZTree PredInfixRel; tZTree Next; } yinfixRels;
typedef struct { ZTree_tNodeHead yyHead; tZTree Lexp; tZTree InfixRel; tZTree Rexp; } yPredInfixRel;
typedef struct { ZTree_tNodeHead yyHead; tIdPos InRel; tZTree Decoration; } yInfixRel;
typedef struct { ZTree_tNodeHead yyHead; } yExpression;
typedef struct { ZTree_tNodeHead yyHead; } ynoExp;
typedef struct { ZTree_tNodeHead yyHead; tZTree lexp; tIdPos InGen; tZTree Decoration; tZTree rexp; } yexpBinaryGen;
typedef struct { ZTree_tNodeHead yyHead; tZTree lexp; tIdPos InFun; tZTree Decoration; tZTree rexp; } yexpBinaryFun;
typedef struct { ZTree_tNodeHead yyHead; tIdPos Literal; } yexpLiteral;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarName; tZTree ExpressionSeq; } yexpOpname;
typedef struct { ZTree_tNodeHead yyHead; tZTree ExpressionSeq; } yexpSetElab;
typedef struct { ZTree_tNodeHead yyHead; tZTree ExpressionSeq; } yexpSeqElab;
typedef struct { ZTree_tNodeHead yyHead; tZTree ExpressionSeq; } yexpBagElab;
typedef struct { ZTree_tNodeHead yyHead; tZTree ZSchemaText; tZTree Expression; } yexpSetComp;
typedef struct { ZTree_tNodeHead yyHead; tZTree Expression; } yexpPowerSet;
typedef struct { ZTree_tNodeHead yyHead; tIdPos Pregen; tZTree Decoration; tZTree Expression; } yexpPreGen;
typedef struct { ZTree_tNodeHead yyHead; tZTree Expression; tIdPos Postfun; tZTree Decoration; } yexpPostFun;
typedef struct { ZTree_tNodeHead yyHead; tZTree exp1; tZTree exp2; } yexpIter;
typedef struct { ZTree_tNodeHead yyHead; tZTree ExpressionSeq; } yexpTuple;
typedef struct { ZTree_tNodeHead yyHead; tZTree ExpressionSeq; } yexpCartProd;
typedef struct { ZTree_tNodeHead yyHead; tZTree ZName; tZTree Decoration; tZTree RenameSeq; } yexpTheta;
typedef struct { ZTree_tNodeHead yyHead; tZTree Expression; tZTree VarName; } yexpSelectVar;
typedef struct { ZTree_tNodeHead yyHead; tZTree FnName; tZTree Params; } yexpFnApp;
typedef struct { ZTree_tNodeHead yyHead; tZTree ZSchemaText; tZTree Expression; } yexpMu;
typedef struct { ZTree_tNodeHead yyHead; tZTree ZSchemaText; tZTree Expression; } yexpLambda;
typedef struct { ZTree_tNodeHead yyHead; tZTree LetDefSeq; tZTree Expression; } yexpLet;
typedef struct { ZTree_tNodeHead yyHead; tZTree Predicate; tZTree Exp1; tZTree Exp2; } yexpIf;
typedef struct { ZTree_tNodeHead yyHead; tZTree Exp1; tZTree Exp2; tIdPos Image; tZTree Decoration; } yexpImage;
typedef struct { ZTree_tNodeHead yyHead; tZTree Designator; } yexpDesignator;
typedef struct { ZTree_tNodeHead yyHead; tZTree Expression; } yexpParen;
typedef struct { ZTree_tNodeHead yyHead; } yLetDefSeq;
typedef struct { ZTree_tNodeHead yyHead; } ynoLetDef;
typedef struct { ZTree_tNodeHead yyHead; tZTree LetDef; tZTree Next; } yletDefs;
typedef struct { ZTree_tNodeHead yyHead; tZTree VarName; tZTree Expression; } yLetDef;
typedef struct { ZTree_tNodeHead yyHead; tIdPos Ident; tZTree Decoration; } yVarName;
typedef struct { ZTree_tNodeHead yyHead; tIdPos Ident; tZTree Decoration; } yZId;
typedef struct { ZTree_tNodeHead yyHead; tIdPos Ident; tZTree Decoration; } yOpname;
typedef struct { ZTree_tNodeHead yyHead; } yDecoration;
typedef struct { ZTree_tNodeHead yyHead; } ynoDecoration;
typedef struct { ZTree_tNodeHead yyHead; tIdPos Stroke; tZTree Next; } ydecoration;
typedef struct { ZTree_tNodeHead yyHead; tIdPos Ident; } yZName;

union ZTree_Node {
 ZTree_tKind Kind;
 ZTree_tNodeHead yyHead;
 ySpecification Specification;
 yGlobalParagraphSeq GlobalParagraphSeq;
 ynoGlobalParagraph noGlobalParagraph;
 yglobalParagraphs globalParagraphs;
 yGlobalParagraph GlobalParagraph;
 yaxiomaticDef axiomaticDef;
 yhorizPar horizPar;
 ygenericDef genericDef;
 yschemaboxDef schemaboxDef;
 yHorizParagraphs HorizParagraphs;
 ynoHorizParagraph noHorizParagraph;
 yhorizParagraphs horizParagraphs;
 yHorizParagraph HorizParagraph;
 ytypeDef typeDef;
 yglobalPredicate globalPredicate;
 yschemaDef schemaDef;
 yTypeDef TypeDef;
 ygivenSet givenSet;
 yfreeType freeType;
 ytypeDef1 typeDef1;
 ytypeDefPregen typeDefPregen;
 ytypeDefIngen typeDefIngen;
 yNameFormals NameFormals;
 ynoFormals noFormals;
 ynameFormals nameFormals;
 yBranchSeq BranchSeq;
 ynoBranch noBranch;
 ybranch branch;
 yZFormalParams ZFormalParams;
 ynoFormalParams noFormalParams;
 yformalParams formalParams;
 yZBranch ZBranch;
 ysimpleBranch simpleBranch;
 ycompoundBranch compoundBranch;
 ySchemaExp SchemaExp;
 yschemaSimple schemaSimple;
 yschemaDes schemaDes;
 yschemaPreop schemaPreop;
 yschemaCons schemaCons;
 yschemaHide schemaHide;
 yschemaQuant schemaQuant;
 yschemaComp schemaComp;
 yschemaProject schemaProject;
 yschemaPipe schemaPipe;
 yschemaParen schemaParen;
 yDesignator Designator;
 yVarNameSeq VarNameSeq;
 ynoVarName noVarName;
 yvarNames varNames;
 yExpressionSeq ExpressionSeq;
 ynoExpSeq noExpSeq;
 yexpSeq expSeq;
 yRenameSeq RenameSeq;
 ynoRename noRename;
 yrenames renames;
 yVarRename VarRename;
 yZSchemaText ZSchemaText;
 yDeclaration Declaration;
 ynoDecl noDecl;
 ydecl decl;
 yBasicDecl BasicDecl;
 ycolonDecl colonDecl;
 yschemaRef schemaRef;
 yPredicate Predicate;
 ynoPred noPred;
 ypredNegate predNegate;
 ypredInfixRelSeq predInfixRelSeq;
 ypredTrueOrFalse predTrueOrFalse;
 ypredSchemaRef predSchemaRef;
 ypredPreRel predPreRel;
 ypredCons predCons;
 ypredQuant predQuant;
 ypredLet predLet;
 ypredParen predParen;
 yPredInfixRelSeq PredInfixRelSeq;
 ynoInfixRel noInfixRel;
 yinfixRels infixRels;
 yPredInfixRel PredInfixRel;
 yInfixRel InfixRel;
 yExpression Expression;
 ynoExp noExp;
 yexpBinaryGen expBinaryGen;
 yexpBinaryFun expBinaryFun;
 yexpLiteral expLiteral;
 yexpOpname expOpname;
 yexpSetElab expSetElab;
 yexpSeqElab expSeqElab;
 yexpBagElab expBagElab;
 yexpSetComp expSetComp;
 yexpPowerSet expPowerSet;
 yexpPreGen expPreGen;
 yexpPostFun expPostFun;
 yexpIter expIter;
 yexpTuple expTuple;
 yexpCartProd expCartProd;
 yexpTheta expTheta;
 yexpSelectVar expSelectVar;
 yexpFnApp expFnApp;
 yexpMu expMu;
 yexpLambda expLambda;
 yexpLet expLet;
 yexpIf expIf;
 yexpImage expImage;
 yexpDesignator expDesignator;
 yexpParen expParen;
 yLetDefSeq LetDefSeq;
 ynoLetDef noLetDef;
 yletDefs letDefs;
 yLetDef LetDef;
 yVarName VarName;
 yZId ZId;
 yOpname Opname;
 yDecoration Decoration;
 ynoDecoration noDecoration;
 ydecoration decoration;
 yZName ZName;
};

extern tZTree ZTreeRoot;
extern unsigned long ZTree_HeapUsed;
extern char * ZTree_PoolFreePtr, * ZTree_PoolMaxPtr;
extern unsigned short ZTree_NodeSize [116 + 1];
extern char * ZTree_NodeName [116 + 1];

extern void (* ZTree_Exit) ();
extern tZTree ZTree_Alloc ();
extern tZTree MakeZTree ARGS((ZTree_tKind yyKind));
extern bool ZTree_IsType ARGS((register tZTree yyt, register ZTree_tKind yyKind));

extern tZTree nSpecification ();
extern tZTree nGlobalParagraphSeq ();
extern tZTree nnoGlobalParagraph ();
extern tZTree nglobalParagraphs ();
extern tZTree nGlobalParagraph ();
extern tZTree naxiomaticDef ();
extern tZTree nhorizPar ();
extern tZTree ngenericDef ();
extern tZTree nschemaboxDef ();
extern tZTree nHorizParagraphs ();
extern tZTree nnoHorizParagraph ();
extern tZTree nhorizParagraphs ();
extern tZTree nHorizParagraph ();
extern tZTree ntypeDef ();
extern tZTree nglobalPredicate ();
extern tZTree nschemaDef ();
extern tZTree nTypeDef ();
extern tZTree ngivenSet ();
extern tZTree nfreeType ();
extern tZTree ntypeDef1 ();
extern tZTree ntypeDefPregen ();
extern tZTree ntypeDefIngen ();
extern tZTree nNameFormals ();
extern tZTree nnoFormals ();
extern tZTree nnameFormals ();
extern tZTree nBranchSeq ();
extern tZTree nnoBranch ();
extern tZTree nbranch ();
extern tZTree nZFormalParams ();
extern tZTree nnoFormalParams ();
extern tZTree nformalParams ();
extern tZTree nZBranch ();
extern tZTree nsimpleBranch ();
extern tZTree ncompoundBranch ();
extern tZTree nSchemaExp ();
extern tZTree nschemaSimple ();
extern tZTree nschemaDes ();
extern tZTree nschemaPreop ();
extern tZTree nschemaCons ();
extern tZTree nschemaHide ();
extern tZTree nschemaQuant ();
extern tZTree nschemaComp ();
extern tZTree nschemaProject ();
extern tZTree nschemaPipe ();
extern tZTree nschemaParen ();
extern tZTree nDesignator ();
extern tZTree nVarNameSeq ();
extern tZTree nnoVarName ();
extern tZTree nvarNames ();
extern tZTree nExpressionSeq ();
extern tZTree nnoExpSeq ();
extern tZTree nexpSeq ();
extern tZTree nRenameSeq ();
extern tZTree nnoRename ();
extern tZTree nrenames ();
extern tZTree nVarRename ();
extern tZTree nZSchemaText ();
extern tZTree nDeclaration ();
extern tZTree nnoDecl ();
extern tZTree ndecl ();
extern tZTree nBasicDecl ();
extern tZTree ncolonDecl ();
extern tZTree nschemaRef ();
extern tZTree nPredicate ();
extern tZTree nnoPred ();
extern tZTree npredNegate ();
extern tZTree npredInfixRelSeq ();
extern tZTree npredTrueOrFalse ();
extern tZTree npredSchemaRef ();
extern tZTree npredPreRel ();
extern tZTree npredCons ();
extern tZTree npredQuant ();
extern tZTree npredLet ();
extern tZTree npredParen ();
extern tZTree nPredInfixRelSeq ();
extern tZTree nnoInfixRel ();
extern tZTree ninfixRels ();
extern tZTree nPredInfixRel ();
extern tZTree nInfixRel ();
extern tZTree nExpression ();
extern tZTree nnoExp ();
extern tZTree nexpBinaryGen ();
extern tZTree nexpBinaryFun ();
extern tZTree nexpLiteral ();
extern tZTree nexpOpname ();
extern tZTree nexpSetElab ();
extern tZTree nexpSeqElab ();
extern tZTree nexpBagElab ();
extern tZTree nexpSetComp ();
extern tZTree nexpPowerSet ();
extern tZTree nexpPreGen ();
extern tZTree nexpPostFun ();
extern tZTree nexpIter ();
extern tZTree nexpTuple ();
extern tZTree nexpCartProd ();
extern tZTree nexpTheta ();
extern tZTree nexpSelectVar ();
extern tZTree nexpFnApp ();
extern tZTree nexpMu ();
extern tZTree nexpLambda ();
extern tZTree nexpLet ();
extern tZTree nexpIf ();
extern tZTree nexpImage ();
extern tZTree nexpDesignator ();
extern tZTree nexpParen ();
extern tZTree nLetDefSeq ();
extern tZTree nnoLetDef ();
extern tZTree nletDefs ();
extern tZTree nLetDef ();
extern tZTree nVarName ();
extern tZTree nZId ();
extern tZTree nOpname ();
extern tZTree nDecoration ();
extern tZTree nnoDecoration ();
extern tZTree ndecoration ();
extern tZTree nZName ();

extern tZTree mSpecification ARGS((tZTree pGlobalParagraphSeq));
extern tZTree mGlobalParagraphSeq ARGS(());
extern tZTree mnoGlobalParagraph ARGS(());
extern tZTree mglobalParagraphs ARGS((tZTree pGlobalParagraph, tZTree pNext));
extern tZTree mGlobalParagraph ARGS(());
extern tZTree maxiomaticDef ARGS((tZTree pZSchemaText));
extern tZTree mhorizPar ARGS((tZTree pHorizParagraphs));
extern tZTree mgenericDef ARGS((tZTree pZFormalParams, tZTree pZSchemaText));
extern tZTree mschemaboxDef ARGS((tZTree pZName, tZTree pZFormalParams, tZTree pZSchemaText));
extern tZTree mHorizParagraphs ARGS(());
extern tZTree mnoHorizParagraph ARGS(());
extern tZTree mhorizParagraphs ARGS((tZTree pHorizParagraph, tZTree pNext));
extern tZTree mHorizParagraph ARGS(());
extern tZTree mtypeDef ARGS((tZTree pTypeDef));
extern tZTree mglobalPredicate ARGS((tZTree pPredicate));
extern tZTree mschemaDef ARGS((tZTree pNameFormals, tZTree pSchemaExp));
extern tZTree mTypeDef ARGS(());
extern tZTree mgivenSet ARGS((tZTree pVarNameSeq));
extern tZTree mfreeType ARGS((tZTree pVarName, tZTree pBranchSeq));
extern tZTree mtypeDef1 ARGS((tZTree pNameFormals, tZTree pExpression));
extern tZTree mtypeDefPregen ARGS((tIdPos pPreGen, tZTree pDecoration, tZTree pVarName, tZTree pExpression));
extern tZTree mtypeDefIngen ARGS((tZTree pVar1, tIdPos pInGen, tZTree pDecoration, tZTree pVar2, tZTree pExpression));
extern tZTree mNameFormals ARGS((tZTree pVarName));
extern tZTree mnoFormals ARGS((tZTree pVarName));
extern tZTree mnameFormals ARGS((tZTree pVarName, tZTree pZFormalParams));
extern tZTree mBranchSeq ARGS(());
extern tZTree mnoBranch ARGS(());
extern tZTree mbranch ARGS((tZTree pZBranch, tZTree pNext));
extern tZTree mZFormalParams ARGS(());
extern tZTree mnoFormalParams ARGS(());
extern tZTree mformalParams ARGS((tZTree pVarNameSeq));
extern tZTree mZBranch ARGS(());
extern tZTree msimpleBranch ARGS((tZTree pVarName));
extern tZTree mcompoundBranch ARGS((tZTree pVarName, tZTree pExpression));
extern tZTree mSchemaExp ARGS(());
extern tZTree mschemaSimple ARGS((tZTree pZSchemaText));
extern tZTree mschemaDes ARGS((tZTree pDesignator));
extern tZTree mschemaPreop ARGS((tIdPos pPreOp, tZTree pSchemaExp));
extern tZTree mschemaCons ARGS((tZTree pLop, tIdPos pSchemaOp, tZTree pRop));
extern tZTree mschemaHide ARGS((tZTree pSchemaExp, tZTree pVarNameSeq));
extern tZTree mschemaQuant ARGS((tIdPos pLogQuant, tZTree pZSchemaText, tZTree pSchemaExp));
extern tZTree mschemaComp ARGS((tZTree pLop, tZTree pRop));
extern tZTree mschemaProject ARGS((tZTree pLop, tZTree pRop));
extern tZTree mschemaPipe ARGS((tZTree pLop, tZTree pRop));
extern tZTree mschemaParen ARGS((tZTree pSchemaExp));
extern tZTree mDesignator ARGS((tZTree pZName, tZTree pDecoration, tZTree pExpressionSeq, tZTree pRenameSeq, bool pIsSchemaRef));
extern tZTree mVarNameSeq ARGS(());
extern tZTree mnoVarName ARGS(());
extern tZTree mvarNames ARGS((tZTree pVarName, tZTree pNext));
extern tZTree mExpressionSeq ARGS(());
extern tZTree mnoExpSeq ARGS(());
extern tZTree mexpSeq ARGS((tZTree pExpression, tZTree pNext));
extern tZTree mRenameSeq ARGS(());
extern tZTree mnoRename ARGS(());
extern tZTree mrenames ARGS((tZTree pVarRename, tZTree pNext));
extern tZTree mVarRename ARGS((tZTree pNew, tZTree pOld));
extern tZTree mZSchemaText ARGS((tZTree pDeclaration, tZTree pPredicate));
extern tZTree mDeclaration ARGS(());
extern tZTree mnoDecl ARGS(());
extern tZTree mdecl ARGS((tZTree pBasicDecl, tZTree pNext));
extern tZTree mBasicDecl ARGS(());
extern tZTree mcolonDecl ARGS((tZTree pVarNameSeq, tZTree pExpression));
extern tZTree mschemaRef ARGS((tZTree pDesignator));
extern tZTree mPredicate ARGS(());
extern tZTree mnoPred ARGS(());
extern tZTree mpredNegate ARGS((tZTree pPredicate));
extern tZTree mpredInfixRelSeq ARGS((tZTree pPredInfixRelSeq));
extern tZTree mpredTrueOrFalse ARGS((tIdPos pTrueFalse));
extern tZTree mpredSchemaRef ARGS((tIdPos pPredOrPre, tZTree pDesignator));
extern tZTree mpredPreRel ARGS((tIdPos pPreRel, tZTree pDecoration, tZTree pExpression));
extern tZTree mpredCons ARGS((tZTree pLpred, tIdPos pLogOp, tZTree pRpred));
extern tZTree mpredQuant ARGS((tIdPos pLogQuant, tZTree pZSchemaText, tZTree pPredicate));
extern tZTree mpredLet ARGS((tZTree pLetDefSeq, tZTree pPredicate));
extern tZTree mpredParen ARGS((tZTree pPredicate));
extern tZTree mPredInfixRelSeq ARGS(());
extern tZTree mnoInfixRel ARGS(());
extern tZTree minfixRels ARGS((tZTree pPredInfixRel, tZTree pNext));
extern tZTree mPredInfixRel ARGS((tZTree pLexp, tZTree pInfixRel, tZTree pRexp));
extern tZTree mInfixRel ARGS((tIdPos pInRel, tZTree pDecoration));
extern tZTree mExpression ARGS(());
extern tZTree mnoExp ARGS(());
extern tZTree mexpBinaryGen ARGS((tZTree plexp, tIdPos pInGen, tZTree pDecoration, tZTree prexp));
extern tZTree mexpBinaryFun ARGS((tZTree plexp, tIdPos pInFun, tZTree pDecoration, tZTree prexp));
extern tZTree mexpLiteral ARGS((tIdPos pLiteral));
extern tZTree mexpOpname ARGS((tZTree pVarName, tZTree pExpressionSeq));
extern tZTree mexpSetElab ARGS((tZTree pExpressionSeq));
extern tZTree mexpSeqElab ARGS((tZTree pExpressionSeq));
extern tZTree mexpBagElab ARGS((tZTree pExpressionSeq));
extern tZTree mexpSetComp ARGS((tZTree pZSchemaText, tZTree pExpression));
extern tZTree mexpPowerSet ARGS((tZTree pExpression));
extern tZTree mexpPreGen ARGS((tIdPos pPregen, tZTree pDecoration, tZTree pExpression));
extern tZTree mexpPostFun ARGS((tZTree pExpression, tIdPos pPostfun, tZTree pDecoration));
extern tZTree mexpIter ARGS((tZTree pexp1, tZTree pexp2));
extern tZTree mexpTuple ARGS((tZTree pExpressionSeq));
extern tZTree mexpCartProd ARGS((tZTree pExpressionSeq));
extern tZTree mexpTheta ARGS((tZTree pZName, tZTree pDecoration, tZTree pRenameSeq));
extern tZTree mexpSelectVar ARGS((tZTree pExpression, tZTree pVarName));
extern tZTree mexpFnApp ARGS((tZTree pFnName, tZTree pParams));
extern tZTree mexpMu ARGS((tZTree pZSchemaText, tZTree pExpression));
extern tZTree mexpLambda ARGS((tZTree pZSchemaText, tZTree pExpression));
extern tZTree mexpLet ARGS((tZTree pLetDefSeq, tZTree pExpression));
extern tZTree mexpIf ARGS((tZTree pPredicate, tZTree pExp1, tZTree pExp2));
extern tZTree mexpImage ARGS((tZTree pExp1, tZTree pExp2, tIdPos pImage, tZTree pDecoration));
extern tZTree mexpDesignator ARGS((tZTree pDesignator));
extern tZTree mexpParen ARGS((tZTree pExpression));
extern tZTree mLetDefSeq ARGS(());
extern tZTree mnoLetDef ARGS(());
extern tZTree mletDefs ARGS((tZTree pLetDef, tZTree pNext));
extern tZTree mLetDef ARGS((tZTree pVarName, tZTree pExpression));
extern tZTree mVarName ARGS((tIdPos pIdent, tZTree pDecoration));
extern tZTree mZId ARGS((tIdPos pIdent, tZTree pDecoration));
extern tZTree mOpname ARGS((tIdPos pIdent, tZTree pDecoration));
extern tZTree mDecoration ARGS(());
extern tZTree mnoDecoration ARGS(());
extern tZTree mdecoration ARGS((tIdPos pStroke, tZTree pNext));
extern tZTree mZName ARGS((tIdPos pIdent));

extern void ReleaseZTree ARGS((tZTree yyt));
extern void ReleaseZTreeModule ();
extern void WriteZTreeNode ARGS((FILE * yyyf, tZTree yyt));
extern void WriteZTree ARGS((FILE * yyyf, tZTree yyt));
extern tZTree ReadZTree ARGS((FILE * yyyf));
extern void PutZTree ARGS((FILE * yyyf, tZTree yyt));
extern tZTree GetZTree ARGS((FILE * yyyf));
extern void TraverseZTreeTD ARGS((tZTree yyt, ZTree_tProcTree yyyProc));
extern void TraverseZTreeBU ARGS((tZTree yyt, ZTree_tProcTree yyyProc));
extern tZTree ReverseZTree ARGS((tZTree yyOld));
extern tZTree CopyZTree ARGS((tZTree yyt));
extern bool CheckZTree ARGS((tZTree yyt));
extern void QueryZTree ARGS((tZTree yyt));
extern bool IsEqualZTree ARGS((tZTree yyt1, tZTree yyt2));
extern void BeginZTree ();
extern void CloseZTree ();

# endif
