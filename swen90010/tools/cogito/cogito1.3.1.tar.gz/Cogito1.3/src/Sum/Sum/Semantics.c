# define DEP(a, b) a
# define SELF yyt
# include "Semantics.h"

/* line 87 "sum.cg" */

# include "Tree.h"
# include "global.h"
# include "Idents.h"
# include "Positions.h"
# include "ratc.h"
# include "Syms.h"
# include "Type.h"
# include "SymAccess.h"
#include <stdlib.h>

#define nnNoObj mNoObject()


/* empty expression list (ExpressionList = NoExp): return NoType;
 * otherwise: return Tp_CartList; 
 */
tType TyExtract (ExpressionList)
    tTree ExpressionList;
{
    tTree explink = ExpressionList;
    tType fst=NoType, last=NoType;


    for (; explink && explink->Kind != kNoExp;
        explink = explink->Exp.Next) {
        if (explink->Exp.Type == NoType || explink->Exp.Type->Kind == kTp_Err)
            return ErrTy;
        if (!last) {
            if (explink->Exp.IsTypeExp) /* type exps used as instance */ 
                last = mTp_Cart (NoType, mTp_Power(NoIdent, Ident_power, explink->Exp.Type));
            else
                last = mTp_Cart (NoType, explink->Exp.Type);
            fst = last;
        }
        else {
            if (explink->Exp.IsTypeExp)
                last->Tp_Cart.Next = mTp_Cart (NoType, mTp_Power(NoIdent, Ident_power, explink->Exp.Type));
            else
                last->Tp_Cart.Next = mTp_Cart (NoType, explink->Exp.Type);
            last = last->Tp_Cart.Next;
        }
    }
    return fst;    
}

tIdent GenScopeIdent (ModId, Ident)
    tIdent ModId, Ident;
{
    char modstr[IDENT_LENGTH], idstr[IDENT_LENGTH];

	if (Ident == Ident_math)
		return NoIdent;

    if (ModId == NoIdent)
        return Ident;
    else {
        GetString (ModId, modstr);
        GetString (Ident, idstr);
	if ((strlen(modstr)+strlen(idstr)+1)>=IDENT_LENGTH)
		{printf("\nname too long: %s.%s\n",modstr,idstr);
		exit(1);}
        sprintf (modstr, "%s.%s", modstr, idstr);
        return MakeIdent (modstr, strlen(modstr));
    }
}

tIdent DeGenScopeIdent (ModId)
    tIdent ModId;
{
    char modstr[IDENT_LENGTH];
    int i=0;
    if (ModId == NoIdent)
        return ModId;

    GetString (ModId, modstr);
    i = strlen (modstr) - 1;

    for (; i >= 0; i--)
        if (modstr[i] == '.') {
            modstr[i] = '\0';
            return MakeIdent (modstr, strlen(modstr));
        }

    return NoIdent;
}



static char yyb;

static void yyVisit1Sum ARGS((register tTree yyt));
static void yyVisit1ModuleList ARGS((register tTree yyt));
static void yyVisit1Module ARGS((register tTree yyt));
static void yyVisit1FormalParams ARGS((register tTree yyt));
static void yyVisit1RenameList ARGS((register tTree yyt));
static void yyVisit1SelectionList ARGS((register tTree yyt));
static void yyVisit1IdList ARGS((register tTree yyt));
static void yyVisit1NameList ARGS((register tTree yyt));
static void yyVisit1ExpressionList ARGS((register tTree yyt));
static void yyVisit1Exp ARGS((register tTree yyt));
static void yyVisit1PredList ARGS((register tTree yyt));
static void yyVisit1Pred ARGS((register tTree yyt));
static void yyVisit1InputBindList ARGS((register tTree yyt));
static void yyVisit1OutputBindList ARGS((register tTree yyt));
static void yyVisit1LogBinOp ARGS((register tTree yyt));
static void yyVisit1DeclList ARGS((register tTree yyt));
static void yyVisit1Decl ARGS((register tTree yyt));
static void yyVisit1VarDecl ARGS((register tTree yyt));
static void yyVisit1BranchList ARGS((register tTree yyt));
static void yyVisit1Schema ARGS((register tTree yyt));
static void yyVisit1SchemaText ARGS((register tTree yyt));
static void yyVisit1LogOp ARGS((register tTree yyt));

void Semantics
# if defined __STDC__ | defined __cplusplus
 (tTree yyt)
# else
 (yyt) tTree yyt;
# endif
{
 yyVisit1Sum (yyt); }

static void yyVisit1Sum
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kSum: {
/* line 663 "sum.cg" */

        yyt->Sum.ModuleList->ModuleList.DeclsIn = InitSymTab(yyt->Sum.ModuleList);
    
yyVisit1ModuleList (yyt->Sum.ModuleList);
} break;
 default: ;
 }
}

static void yyVisit1ModuleList
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kModuleList: {
/* line 359 "sum.cg" */
yyt->ModuleList.Pos = NoPosition;
yyt->ModuleList.DeclsOut=yyt->ModuleList.DeclsIn;
} break;
case kNoModule: {
/* line 359 "sum.cg" */
yyt->NoModule.Pos = NoPosition;
yyt->NoModule.DeclsOut=yyt->NoModule.DeclsIn;
} break;
case kModule: {
/* line 387 "sum.cg" */

    yyt->Module.Pos = yyt->Module.Ident.Pos;
/* line 670 "sum.cg" */

        if (IsDeclared (yyt->Module.DeclsIn, yyt->Module.Ident.Ident, NoType))
            Error (yyt->Module.Ident.Pos, error22); 
	cur_mod_imllist_hd = NULL;
	cur_mod_imllist = NULL;
        ModIdent = GenScopeIdent (ModIdent, yyt->Module.Ident.Ident);
        yyt->Module.FormalParams->FormalParams.DeclsIn = mObj_Inn(NoSym, yyt->Module.DeclsIn, ModIdent, NoType, yyt->Module.Ident.Ident, 1, NoSym, Obj_module, false);
        if (yyt->Module.DeclsIn->Kind == kObj_Inn && !yyt->Module.DeclsIn->Obj_Inn.Inner) 
            yyt->Module.DeclsIn->Obj_Inn.Inner = yyt->Module.FormalParams->FormalParams.DeclsIn;
        else if (yyt->Module.DeclsIn->Kind != kNoObject)
            yyt->Module.DeclsIn->Object.Next = yyt->Module.FormalParams->FormalParams.DeclsIn;
    
yyVisit1FormalParams (yyt->Module.FormalParams);
/* line 683 "sum.cg" */


	SetModGenParameters(yyt->Module.FormalParams->FormalParams.DeclsIn);
	yyt->Module.DeclList->DeclList.DeclsIn = yyt->Module.FormalParams->FormalParams.DeclsOut;
yyVisit1DeclList (yyt->Module.DeclList);
/* line 682 "sum.cg" */

    yyt->Module.PredList->PredList.DeclsIn = yyt->Module.FormalParams->FormalParams.DeclsOut;
yyVisit1PredList (yyt->Module.PredList);
/* line 687 "sum.cg" */
 
        if (yyt->Module.DeclList->DeclList.DeclsOut == yyt->Module.FormalParams->FormalParams.DeclsIn)
            yyt->Module.FormalParams->FormalParams.DeclsIn->Obj_Inn.Inner = nnNoObj;
        yyt->Module.Next->ModuleList.DeclsIn = yyt->Module.FormalParams->FormalParams.DeclsIn;
        
        if (SymsRoot == NoSym)
            SymsRoot = yyt->Module.FormalParams->FormalParams.DeclsIn;
        if (!yyt->Module.IsNested && CountSemErr == 0) { 
            WriteModule ((yyt->Module.FormalParams->FormalParams.DeclsIn)->Obj_Inn.Inner, yyt->Module.Ident.Ident);
        }
	ResetModGenParameters();
        ModIdent = DeGenScopeIdent (ModIdent);
    
yyVisit1ModuleList (yyt->Module.Next);
/* line 1412 "sum.cg" */
if (! ( PredIsBool(yyt->Module.PredList) )) { Error(NonBoolPredPos(yyt->Module.PredList),error33); }
/* line 700 "sum.cg" */

    yyt->Module.DeclsOut = yyt->Module.Next->ModuleList.DeclsOut;
} break;
 default: ;
 }
}

static void yyVisit1Module
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kModule: {
/* line 387 "sum.cg" */

    yyt->Module.Pos = yyt->Module.Ident.Pos;
/* line 670 "sum.cg" */

        if (IsDeclared (yyt->Module.DeclsIn, yyt->Module.Ident.Ident, NoType))
            Error (yyt->Module.Ident.Pos, error22); 
	cur_mod_imllist_hd = NULL;
	cur_mod_imllist = NULL;
        ModIdent = GenScopeIdent (ModIdent, yyt->Module.Ident.Ident);
        yyt->Module.FormalParams->FormalParams.DeclsIn = mObj_Inn(NoSym, yyt->Module.DeclsIn, ModIdent, NoType, yyt->Module.Ident.Ident, 1, NoSym, Obj_module, false);
        if (yyt->Module.DeclsIn->Kind == kObj_Inn && !yyt->Module.DeclsIn->Obj_Inn.Inner) 
            yyt->Module.DeclsIn->Obj_Inn.Inner = yyt->Module.FormalParams->FormalParams.DeclsIn;
        else if (yyt->Module.DeclsIn->Kind != kNoObject)
            yyt->Module.DeclsIn->Object.Next = yyt->Module.FormalParams->FormalParams.DeclsIn;
    
yyVisit1FormalParams (yyt->Module.FormalParams);
/* line 683 "sum.cg" */


	SetModGenParameters(yyt->Module.FormalParams->FormalParams.DeclsIn);
	yyt->Module.DeclList->DeclList.DeclsIn = yyt->Module.FormalParams->FormalParams.DeclsOut;
yyVisit1DeclList (yyt->Module.DeclList);
/* line 682 "sum.cg" */

    yyt->Module.PredList->PredList.DeclsIn = yyt->Module.FormalParams->FormalParams.DeclsOut;
yyVisit1PredList (yyt->Module.PredList);
/* line 687 "sum.cg" */
 
        if (yyt->Module.DeclList->DeclList.DeclsOut == yyt->Module.FormalParams->FormalParams.DeclsIn)
            yyt->Module.FormalParams->FormalParams.DeclsIn->Obj_Inn.Inner = nnNoObj;
        yyt->Module.Next->ModuleList.DeclsIn = yyt->Module.FormalParams->FormalParams.DeclsIn;
        
        if (SymsRoot == NoSym)
            SymsRoot = yyt->Module.FormalParams->FormalParams.DeclsIn;
        if (!yyt->Module.IsNested && CountSemErr == 0) { 
            WriteModule ((yyt->Module.FormalParams->FormalParams.DeclsIn)->Obj_Inn.Inner, yyt->Module.Ident.Ident);
        }
	ResetModGenParameters();
        ModIdent = DeGenScopeIdent (ModIdent);
    
yyVisit1ModuleList (yyt->Module.Next);
/* line 1412 "sum.cg" */
if (! ( PredIsBool(yyt->Module.PredList) )) { Error(NonBoolPredPos(yyt->Module.PredList),error33); }
/* line 700 "sum.cg" */

    yyt->Module.DeclsOut = yyt->Module.Next->ModuleList.DeclsOut;
} break;
 default: ;
 }
}

static void yyVisit1FormalParams
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kFormalParams: {
/* line 359 "sum.cg" */
yyt->FormalParams.Pos = NoPosition;
yyt->FormalParams.DeclsOut=yyt->FormalParams.DeclsIn;
} break;
case kNoParam: {
/* line 359 "sum.cg" */
yyt->NoParam.Pos = NoPosition;
yyt->NoParam.DeclsOut=yyt->NoParam.DeclsIn;
} break;
case kParam: {
/* line 359 "sum.cg" */
yyt->Param.Pos = NoPosition;
yyt->Param.Next->FormalParams.DeclsIn=yyt->Param.DeclsIn;
yyVisit1FormalParams (yyt->Param.Next);
/* line 704 "sum.cg" */

    yyt->Param.DeclsOut = yyt->Param.Next->FormalParams.DeclsOut;
} break;
case kTyParam: {
/* line 395 "sum.cg" */
 
    yyt->TyParam.Pos = yyt->TyParam.Ident.Pos;
/* line 708 "sum.cg" */

        if (IsDeclared (yyt->TyParam.DeclsIn, yyt->TyParam.Ident.Ident, NoType))
            Error (yyt->TyParam.Ident.Pos, error22);
        if (yyt->TyParam.IsPolyTy)
            yyt->TyParam.Next->FormalParams.DeclsIn = mObj_PTyId (NoSym, yyt->TyParam.DeclsIn, ModIdent, 
                mTp_Poly(ModIdent, yyt->TyParam.Ident.Ident), yyt->TyParam.Ident.Ident, 1);
        else
            yyt->TyParam.Next->FormalParams.DeclsIn = mObj_PTyId (NoSym, yyt->TyParam.DeclsIn, ModIdent, 
                mTp_Exp(ModIdent, yyt->TyParam.Ident.Ident), yyt->TyParam.Ident.Ident, 1);
    
yyVisit1FormalParams (yyt->TyParam.Next);

        
        if (yyt->TyParam.DeclsIn->Kind == kObj_Inn && !yyt->TyParam.DeclsIn->Obj_Inn.Inner) 
            yyt->TyParam.DeclsIn->Obj_Inn.Inner = yyt->TyParam.Next->FormalParams.DeclsIn;
        else if (yyt->TyParam.DeclsIn->Kind == kObj_Tmp && !yyt->TyParam.DeclsIn->Obj_Tmp.Inner) 
            yyt->TyParam.DeclsIn->Obj_Tmp.Inner = yyt->TyParam.Next->FormalParams.DeclsIn;
        else
            yyt->TyParam.DeclsIn->Object.Next = yyt->TyParam.Next->FormalParams.DeclsIn;
    ;
/* line 704 "sum.cg" */

    yyt->TyParam.DeclsOut = yyt->TyParam.Next->FormalParams.DeclsOut;
} break;
case kFncParam: {
/* line 731 "sum.cg" */

    yyt->FncParam.VarDecl->VarDecl.DeclsIn = yyt->FncParam.DeclsIn;
yyVisit1VarDecl (yyt->FncParam.VarDecl);
/* line 399 "sum.cg" */

    yyt->FncParam.Pos = yyt->FncParam.VarDecl->VarDecl.Pos;
/* line 732 "sum.cg" */

    yyt->FncParam.Next->FormalParams.DeclsIn = yyt->FncParam.VarDecl->VarDecl.DeclsOut;
yyVisit1FormalParams (yyt->FncParam.Next);
/* line 704 "sum.cg" */

    yyt->FncParam.DeclsOut = yyt->FncParam.Next->FormalParams.DeclsOut;
} break;
 default: ;
 }
}

static void yyVisit1RenameList
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kRenameList: {
yyt->RenameList.DeclsOut=yyt->RenameList.DeclsIn;
} break;
case kNoRename: {
yyt->NoRename.DeclsOut=yyt->NoRename.DeclsIn;
} break;
case kRename: {
yyt->Rename.Next->RenameList.DeclsIn=yyt->Rename.DeclsIn;
yyVisit1RenameList (yyt->Rename.Next);
yyt->Rename.OldIdent->IdList.DeclsIn=yyt->Rename.Next->RenameList.DeclsOut;
yyVisit1IdList (yyt->Rename.OldIdent);
yyt->Rename.DeclsOut=yyt->Rename.OldIdent->IdList.DeclsOut;
} break;
 default: ;
 }
}

static void yyVisit1SelectionList
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kSelectionList: {
} break;
case kNoSelection: {
} break;
case kSelection: {
yyVisit1SelectionList (yyt->Selection.Next);
} break;
 default: ;
 }
}

static void yyVisit1IdList
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kIdList: {
/* line 359 "sum.cg" */
yyt->IdList.Pos = NoPosition;
yyt->IdList.DeclsOut=yyt->IdList.DeclsIn;
} break;
case kNoId: {
/* line 359 "sum.cg" */
yyt->NoId.Pos = NoPosition;
yyt->NoId.DeclsOut=yyt->NoId.DeclsIn;
} break;
case kId: {
/* line 403 "sum.cg" */

    yyt->Id.Pos = yyt->Id.Ident.Pos;
yyt->Id.Next->IdList.DeclsIn=yyt->Id.DeclsIn;
yyVisit1IdList (yyt->Id.Next);
yyt->Id.DeclsOut=yyt->Id.Next->IdList.DeclsOut;
} break;
 default: ;
 }
}

static void yyVisit1NameList
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kNameList: {
/* line 359 "sum.cg" */
yyt->NameList.Pos = NoPosition;
yyt->NameList.DeclsOut=yyt->NameList.DeclsIn;
} break;
case kNoName: {
/* line 359 "sum.cg" */
yyt->NoName.Pos = NoPosition;
yyt->NoName.DeclsOut=yyt->NoName.DeclsIn;
} break;
case kName: {
yyt->Name.Next->NameList.DeclsIn=yyt->Name.DeclsIn;
yyVisit1NameList (yyt->Name.Next);
yyt->Name.IdList->IdList.DeclsIn=yyt->Name.Next->NameList.DeclsOut;
yyVisit1IdList (yyt->Name.IdList);
/* line 391 "sum.cg" */

    yyt->Name.Pos = yyt->Name.IdList->IdList.Pos;
yyt->Name.DeclsOut=yyt->Name.IdList->IdList.DeclsOut;
} break;
 default: ;
 }
}

static void yyVisit1ExpressionList
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kExpressionList: {
/* line 359 "sum.cg" */
yyt->ExpressionList.Pos = NoPosition;
/* line 366 "sum.cg" */
yyt->ExpressionList.Type = NoType;
yyt->ExpressionList.DeclsOut=yyt->ExpressionList.DeclsIn;
/* line 362 "sum.cg" */
yyt->ExpressionList.IsTypeExp = false;
} break;
case kNoExp: {
/* line 359 "sum.cg" */
yyt->NoExp.Pos = NoPosition;
/* line 366 "sum.cg" */
yyt->NoExp.Type = NoType;
yyt->NoExp.DeclsOut=yyt->NoExp.DeclsIn;
/* line 362 "sum.cg" */
yyt->NoExp.IsTypeExp = false;
} break;
case kExp: {
/* line 359 "sum.cg" */
yyt->Exp.Pos = NoPosition;
yyt->Exp.Next->ExpressionList.DeclsIn=yyt->Exp.DeclsIn;
yyVisit1ExpressionList (yyt->Exp.Next);
/* line 366 "sum.cg" */
yyt->Exp.Type = NoType;
/* line 737 "sum.cg" */

    yyt->Exp.DeclsOut = yyt->Exp.DeclsIn;
/* line 362 "sum.cg" */
yyt->Exp.IsTypeExp = false;
} break;
case kVariable: {
yyt->Variable.Next->ExpressionList.DeclsIn=yyt->Variable.DeclsIn;
yyVisit1ExpressionList (yyt->Variable.Next);
yyt->Variable.IdList->IdList.DeclsIn=yyt->Variable.Next->ExpressionList.DeclsOut;
yyVisit1IdList (yyt->Variable.IdList);
/* line 408 "sum.cg" */

    yyt->Variable.Pos = yyt->Variable.IdList->IdList.Pos;
/* line 371 "sum.cg" */
yyt->Variable.IsBinding=false;
/* line 370 "sum.cg" */
yyt->Variable.SymPtr=NoSym;
/* line 1431 "sum.cg" */

  {
    tObjects sym_ptr;
    bool isbinding;

    yyt->Variable.Type = Tyof_Variable (yyt->Variable.DeclsIn, yyt->Variable.IdList, &sym_ptr, &isbinding, 1); 
    
    
    
    yyt->Variable.SymPtr = sym_ptr;
    yyt->Variable.IsBinding = isbinding;
  }
  
/* line 737 "sum.cg" */

    yyt->Variable.DeclsOut = yyt->Variable.DeclsIn;
/* line 1444 "sum.cg" */

  yyt->Variable.IsTypeExp = yyt->Variable.Type->Tp_Exp.IsTypeExp;
} break;
case kLiteral: {
/* line 412 "sum.cg" */

    yyt->Literal.Pos = yyt->Literal.Literal.Pos;
yyt->Literal.Next->ExpressionList.DeclsIn=yyt->Literal.DeclsIn;
yyVisit1ExpressionList (yyt->Literal.Next);
/* line 1448 "sum.cg" */
  
  yyt->Literal.Type = Tyof_Literal (yyt->Literal.Literal.Ident);
/* line 737 "sum.cg" */

    yyt->Literal.DeclsOut = yyt->Literal.DeclsIn;
/* line 362 "sum.cg" */
yyt->Literal.IsTypeExp = false;
} break;
case kString: {
/* line 416 "sum.cg" */

    yyt->String.Pos = yyt->String.String.Pos;
yyt->String.Next->ExpressionList.DeclsIn=yyt->String.DeclsIn;
yyVisit1ExpressionList (yyt->String.Next);
/* line 1452 "sum.cg" */

    yyt->String.Type = StringTy;
/* line 737 "sum.cg" */

    yyt->String.DeclsOut = yyt->String.DeclsIn;
/* line 362 "sum.cg" */
yyt->String.IsTypeExp = false;
} break;
case kChar: {
/* line 420 "sum.cg" */

    yyt->Char.Pos = yyt->Char.Char.Pos;
yyt->Char.Next->ExpressionList.DeclsIn=yyt->Char.DeclsIn;
yyVisit1ExpressionList (yyt->Char.Next);
/* line 1456 "sum.cg" */

    yyt->Char.Type = CharTy;
/* line 737 "sum.cg" */

    yyt->Char.DeclsOut = yyt->Char.DeclsIn;
/* line 362 "sum.cg" */
yyt->Char.IsTypeExp = false;
} break;
case kPrefixOp: {
yyt->PrefixOp.Next->ExpressionList.DeclsIn=yyt->PrefixOp.DeclsIn;
yyVisit1ExpressionList (yyt->PrefixOp.Next);
yyt->PrefixOp.Exp->Exp.DeclsIn=yyt->PrefixOp.Next->ExpressionList.DeclsOut;
yyVisit1Exp (yyt->PrefixOp.Exp);
/* line 424 "sum.cg" */

    yyt->PrefixOp.Pos = yyt->PrefixOp.Exp->Exp.Pos;
/* line 1460 "sum.cg" */
 
  yyt->PrefixOp.Type = Tyof_PrefixExp (yyt->PrefixOp.DeclsIn, yyt->PrefixOp.Prefix, yyt->PrefixOp.Exp);
/* line 737 "sum.cg" */

    yyt->PrefixOp.DeclsOut = yyt->PrefixOp.DeclsIn;
/* line 1461 "sum.cg" */
 
  yyt->PrefixOp.IsTypeExp = yyt->PrefixOp.Type->Tp_Exp.IsTypeExp;
} break;
case kLambda: {
/* line 741 "sum.cg" */
 
    yyt->Lambda.SchemaText->SchemaText.DeclsIn = yyt->Lambda.DeclsIn;
yyVisit1SchemaText (yyt->Lambda.SchemaText);
/* line 428 "sum.cg" */

    yyt->Lambda.Pos = yyt->Lambda.SchemaText->SchemaText.Pos;
yyt->Lambda.Exp->Exp.DeclsIn=yyt->Lambda.SchemaText->SchemaText.DeclsOut;
yyVisit1Exp (yyt->Lambda.Exp);
/* line 743 "sum.cg" */
 
    
    yyt->Lambda.Next->ExpressionList.DeclsIn = yyt->Lambda.DeclsIn;
yyVisit1ExpressionList (yyt->Lambda.Next);
/* line 1469 "sum.cg" */
 
  yyt->Lambda.Type = Tyof_Lambda (yyt->Lambda.SchemaText->SchemaText.DeclList->DeclList.DeclsIn->Obj_Tmp.Inner, yyt->Lambda.Exp->Exp.Type);
/* line 737 "sum.cg" */

    yyt->Lambda.DeclsOut = yyt->Lambda.DeclsIn;
/* line 362 "sum.cg" */
yyt->Lambda.IsTypeExp = false;
} break;
case kRecDisp: {
/* line 747 "sum.cg" */
 
    yyt->RecDisp.SchemaText->SchemaText.DeclsIn = yyt->RecDisp.DeclsIn;
yyVisit1SchemaText (yyt->RecDisp.SchemaText);
/* line 452 "sum.cg" */

    yyt->RecDisp.Pos = yyt->RecDisp.SchemaText->SchemaText.Pos;
yyt->RecDisp.PredList->PredList.DeclsIn=yyt->RecDisp.SchemaText->SchemaText.DeclsOut;
yyVisit1PredList (yyt->RecDisp.PredList);
/* line 749 "sum.cg" */

    
    yyt->RecDisp.Next->ExpressionList.DeclsIn = yyt->RecDisp.DeclsIn;
yyVisit1ExpressionList (yyt->RecDisp.Next);
/* line 1414 "sum.cg" */
if (! ( PredIsBool(yyt->RecDisp.PredList) )) { Error(NonBoolPredPos(yyt->RecDisp.PredList),error33); }
/* line 1473 "sum.cg" */
 
  yyt->RecDisp.Type = yyt->RecDisp.SchemaText->SchemaText.Type;
/* line 737 "sum.cg" */

    yyt->RecDisp.DeclsOut = yyt->RecDisp.DeclsIn;
/* line 362 "sum.cg" */
yyt->RecDisp.IsTypeExp = false;
} break;
case kMu: {
/* line 753 "sum.cg" */
 
    yyt->Mu.SchemaText->SchemaText.DeclsIn = yyt->Mu.DeclsIn;
yyVisit1SchemaText (yyt->Mu.SchemaText);
/* line 448 "sum.cg" */

    yyt->Mu.Pos = yyt->Mu.SchemaText->SchemaText.Pos;
yyt->Mu.ExpressionList->ExpressionList.DeclsIn=yyt->Mu.SchemaText->SchemaText.DeclsOut;
yyVisit1ExpressionList (yyt->Mu.ExpressionList);
/* line 755 "sum.cg" */

    
    yyt->Mu.Next->ExpressionList.DeclsIn = yyt->Mu.DeclsIn;
yyVisit1ExpressionList (yyt->Mu.Next);
/* line 1478 "sum.cg" */

        yyt->Mu.Type = Tyof_Mu (yyt->Mu.SchemaText->SchemaText.DeclList->DeclList.DeclsIn->Obj_Tmp.Inner, yyt->Mu.ExpressionList->ExpressionList.Type);
	
  
/* line 737 "sum.cg" */

    yyt->Mu.DeclsOut = yyt->Mu.DeclsIn;
/* line 362 "sum.cg" */
yyt->Mu.IsTypeExp = false;
} break;
case kTupSelection: {
yyt->TupSelection.Next->ExpressionList.DeclsIn=yyt->TupSelection.DeclsIn;
yyVisit1ExpressionList (yyt->TupSelection.Next);
yyt->TupSelection.Exp->Exp.DeclsIn=yyt->TupSelection.Next->ExpressionList.DeclsOut;
yyVisit1Exp (yyt->TupSelection.Exp);
/* line 432 "sum.cg" */

    yyt->TupSelection.Pos = yyt->TupSelection.Exp->Exp.Pos;
/* line 1485 "sum.cg" */
 
  yyt->TupSelection.Type = TupSelectType (yyt->TupSelection.Exp->Exp.Type, yyt->TupSelection.Exp->Exp.Pos, yyt->TupSelection.Number);
/* line 737 "sum.cg" */

    yyt->TupSelection.DeclsOut = yyt->TupSelection.DeclsIn;
/* line 362 "sum.cg" */
yyt->TupSelection.IsTypeExp = false;
} break;
case kVarSelection: {
yyt->VarSelection.Next->ExpressionList.DeclsIn=yyt->VarSelection.DeclsIn;
yyVisit1ExpressionList (yyt->VarSelection.Next);
yyt->VarSelection.Exp->Exp.DeclsIn=yyt->VarSelection.Next->ExpressionList.DeclsOut;
yyVisit1Exp (yyt->VarSelection.Exp);
/* line 436 "sum.cg" */

    yyt->VarSelection.Pos = yyt->VarSelection.Exp->Exp.Pos;
/* line 1490 "sum.cg" */
 

  yyt->VarSelection.Type = Tyof_SchemaBind (yyt->VarSelection.Exp->Exp.Type, yyt->VarSelection.Exp->Exp.Pos, yyt->VarSelection.Ident);
/* line 737 "sum.cg" */

    yyt->VarSelection.DeclsOut = yyt->VarSelection.DeclsIn;
/* line 362 "sum.cg" */
yyt->VarSelection.IsTypeExp = false;
} break;
case kIfExp: {
yyt->IfExp.Next->ExpressionList.DeclsIn=yyt->IfExp.DeclsIn;
yyVisit1ExpressionList (yyt->IfExp.Next);
yyt->IfExp.Con->Pred.DeclsIn=yyt->IfExp.Next->ExpressionList.DeclsOut;
yyVisit1Pred (yyt->IfExp.Con);
/* line 440 "sum.cg" */

    yyt->IfExp.Pos = yyt->IfExp.Con->Pred.Pos;
yyt->IfExp.Then->Exp.DeclsIn=yyt->IfExp.Con->Pred.DeclsOut;
yyVisit1Exp (yyt->IfExp.Then);
yyt->IfExp.Else->Exp.DeclsIn=yyt->IfExp.Then->Exp.DeclsOut;
yyVisit1Exp (yyt->IfExp.Else);
/* line 1416 "sum.cg" */
if (! ( PredIsBool(yyt->IfExp.Con) )) { Error(NonBoolPredPos(yyt->IfExp.Con),error33); }
/* line 1494 "sum.cg" */

	yyt->IfExp.Type = Tyof_IfExp (yyt->IfExp.Con->Pred.Type, yyt->IfExp.Con->Pred.Pos, yyt->IfExp.Then->Exp.Type, yyt->IfExp.Then->Exp.Pos, yyt->IfExp.Else->Exp.Type);
	CkPredListAIEnv (yyt->IfExp.Con);
  
/* line 737 "sum.cg" */

    yyt->IfExp.DeclsOut = yyt->IfExp.DeclsIn;
/* line 362 "sum.cg" */
yyt->IfExp.IsTypeExp = false;
} break;
case kFncApplication: {
yyt->FncApplication.Next->ExpressionList.DeclsIn=yyt->FncApplication.DeclsIn;
yyVisit1ExpressionList (yyt->FncApplication.Next);
yyt->FncApplication.Fnc->Exp.DeclsIn=yyt->FncApplication.Next->ExpressionList.DeclsOut;
yyVisit1Exp (yyt->FncApplication.Fnc);
/* line 444 "sum.cg" */

    yyt->FncApplication.Pos = yyt->FncApplication.Fnc->Exp.Pos;
yyt->FncApplication.Arg->ExpressionList.DeclsIn=yyt->FncApplication.Fnc->Exp.DeclsOut;
yyVisit1ExpressionList (yyt->FncApplication.Arg);
/* line 1501 "sum.cg" */
 
  yyt->FncApplication.Type = Tyof_FncApp (yyt->FncApplication.DeclsIn, yyt->FncApplication.Fnc, TyExtract(yyt->FncApplication.Arg));
/* line 737 "sum.cg" */

    yyt->FncApplication.DeclsOut = yyt->FncApplication.DeclsIn;
/* line 362 "sum.cg" */
yyt->FncApplication.IsTypeExp = false;
} break;
case kSetComp: {
/* line 759 "sum.cg" */
 
    yyt->SetComp.SchemaText->SchemaText.DeclsIn = yyt->SetComp.DeclsIn;
yyVisit1SchemaText (yyt->SetComp.SchemaText);
/* line 457 "sum.cg" */

    yyt->SetComp.Pos = yyt->SetComp.SchemaText->SchemaText.Pos;
yyt->SetComp.ExpressionList->ExpressionList.DeclsIn=yyt->SetComp.SchemaText->SchemaText.DeclsOut;
yyVisit1ExpressionList (yyt->SetComp.ExpressionList);
/* line 761 "sum.cg" */

		yyt->SetComp.Next->ExpressionList.DeclsIn = yyt->SetComp.DeclsIn;
		
	
yyVisit1ExpressionList (yyt->SetComp.Next);
/* line 1465 "sum.cg" */
 
  yyt->SetComp.Type = Tyof_SetComp (yyt->SetComp.SchemaText->SchemaText.DeclList->DeclList.DeclsIn->Obj_Tmp.Inner, yyt->SetComp.ExpressionList->ExpressionList.Type);
/* line 737 "sum.cg" */

    yyt->SetComp.DeclsOut = yyt->SetComp.DeclsIn;
/* line 362 "sum.cg" */
yyt->SetComp.IsTypeExp = false;
} break;
case kSetElab: {
/* line 768 "sum.cg" */
 
    yyt->SetElab.ExpressionList->ExpressionList.DeclsIn = yyt->SetElab.DeclsIn;
yyVisit1ExpressionList (yyt->SetElab.ExpressionList);
/* line 461 "sum.cg" */

    yyt->SetElab.Pos = yyt->SetElab.ExpressionList->ExpressionList.Pos;
yyt->SetElab.Next->ExpressionList.DeclsIn=yyt->SetElab.DeclsIn;
yyVisit1ExpressionList (yyt->SetElab.Next);
/* line 1505 "sum.cg" */
 
  yyt->SetElab.Type = Tyof_SetElab (TyExtract(yyt->SetElab.ExpressionList), yyt->SetElab.ExpressionList->ExpressionList.Pos);
/* line 737 "sum.cg" */

    yyt->SetElab.DeclsOut = yyt->SetElab.DeclsIn;
/* line 362 "sum.cg" */
yyt->SetElab.IsTypeExp = false;
} break;
case kArrayUpd: {
/* line 772 "sum.cg" */
   
    yyt->ArrayUpd.Array->IdList.DeclsIn = yyt->ArrayUpd.DeclsIn;
yyVisit1IdList (yyt->ArrayUpd.Array);
/* line 465 "sum.cg" */

    yyt->ArrayUpd.Pos = yyt->ArrayUpd.Array->IdList.Pos;
/* line 774 "sum.cg" */

    yyt->ArrayUpd.Value->Exp.DeclsIn = yyt->ArrayUpd.DeclsIn;
yyVisit1Exp (yyt->ArrayUpd.Value);
/* line 773 "sum.cg" */

    yyt->ArrayUpd.Index->Exp.DeclsIn = yyt->ArrayUpd.DeclsIn;
yyVisit1Exp (yyt->ArrayUpd.Index);
yyt->ArrayUpd.Next->ExpressionList.DeclsIn=yyt->ArrayUpd.DeclsIn;
yyVisit1ExpressionList (yyt->ArrayUpd.Next);
/* line 1509 "sum.cg" */

    yyt->ArrayUpd.Type = Tyof_ArrayUpd(yyt->ArrayUpd.DeclsIn,yyt->ArrayUpd.Array,yyt->ArrayUpd.Index,yyt->ArrayUpd.Value);
/* line 737 "sum.cg" */

    yyt->ArrayUpd.DeclsOut = yyt->ArrayUpd.DeclsIn;
/* line 362 "sum.cg" */
yyt->ArrayUpd.IsTypeExp = false;
} break;
case kNamedArrayAgg: {
/* line 778 "sum.cg" */

    yyt->NamedArrayAgg.ExpressionList->ExpressionList.DeclsIn = yyt->NamedArrayAgg.DeclsIn;
yyVisit1ExpressionList (yyt->NamedArrayAgg.ExpressionList);
/* line 469 "sum.cg" */

    yyt->NamedArrayAgg.Pos = yyt->NamedArrayAgg.ExpressionList->ExpressionList.Pos;
yyt->NamedArrayAgg.Next->ExpressionList.DeclsIn=yyt->NamedArrayAgg.DeclsIn;
yyVisit1ExpressionList (yyt->NamedArrayAgg.Next);
/* line 1513 "sum.cg" */
 
  yyt->NamedArrayAgg.Type = Tyof_SetElab(TyExtract(yyt->NamedArrayAgg.ExpressionList), yyt->NamedArrayAgg.ExpressionList->ExpressionList.Pos);
/* line 737 "sum.cg" */

    yyt->NamedArrayAgg.DeclsOut = yyt->NamedArrayAgg.DeclsIn;
/* line 362 "sum.cg" */
yyt->NamedArrayAgg.IsTypeExp = false;
} break;
case kSequence: {
/* line 782 "sum.cg" */
 
    yyt->Sequence.ExpressionList->ExpressionList.DeclsIn = yyt->Sequence.DeclsIn;
yyVisit1ExpressionList (yyt->Sequence.ExpressionList);
/* line 473 "sum.cg" */

    yyt->Sequence.Pos = yyt->Sequence.ExpressionList->ExpressionList.Pos;
yyt->Sequence.Next->ExpressionList.DeclsIn=yyt->Sequence.DeclsIn;
yyVisit1ExpressionList (yyt->Sequence.Next);
/* line 1517 "sum.cg" */
 
  yyt->Sequence.Type = Tyof_Seq (TyExtract(yyt->Sequence.ExpressionList), yyt->Sequence.ExpressionList->ExpressionList.Pos);
/* line 737 "sum.cg" */

    yyt->Sequence.DeclsOut = yyt->Sequence.DeclsIn;
/* line 362 "sum.cg" */
yyt->Sequence.IsTypeExp = false;
} break;
case kBag: {
/* line 786 "sum.cg" */
 
    yyt->Bag.ExpressionList->ExpressionList.DeclsIn = yyt->Bag.DeclsIn;
yyVisit1ExpressionList (yyt->Bag.ExpressionList);
/* line 477 "sum.cg" */

    yyt->Bag.Pos = yyt->Bag.ExpressionList->ExpressionList.Pos;
yyt->Bag.Next->ExpressionList.DeclsIn=yyt->Bag.DeclsIn;
yyVisit1ExpressionList (yyt->Bag.Next);
/* line 1521 "sum.cg" */
 
  yyt->Bag.Type = Tyof_Bag (TyExtract(yyt->Bag.ExpressionList), yyt->Bag.ExpressionList->ExpressionList.Pos);
/* line 737 "sum.cg" */

    yyt->Bag.DeclsOut = yyt->Bag.DeclsIn;
/* line 362 "sum.cg" */
yyt->Bag.IsTypeExp = false;
} break;
case kCartProd: {
/* line 790 "sum.cg" */
 
    yyt->CartProd.ExpressionList->ExpressionList.DeclsIn = yyt->CartProd.DeclsIn;
yyVisit1ExpressionList (yyt->CartProd.ExpressionList);
/* line 481 "sum.cg" */

    yyt->CartProd.Pos = yyt->CartProd.ExpressionList->ExpressionList.Pos;
yyt->CartProd.Next->ExpressionList.DeclsIn=yyt->CartProd.DeclsIn;
yyVisit1ExpressionList (yyt->CartProd.Next);
/* line 1525 "sum.cg" */
 
    yyt->CartProd.Type = Tyof_CartProd (yyt->CartProd.ExpressionList);
/* line 737 "sum.cg" */

    yyt->CartProd.DeclsOut = yyt->CartProd.DeclsIn;
/* line 1526 "sum.cg" */

    yyt->CartProd.IsTypeExp = yyt->CartProd.Type->Tp_Exp.IsTypeExp;
} break;
case kTuple: {
/* line 794 "sum.cg" */
 
    yyt->Tuple.ExpressionList->ExpressionList.DeclsIn = yyt->Tuple.DeclsIn;
yyVisit1ExpressionList (yyt->Tuple.ExpressionList);
/* line 485 "sum.cg" */

    yyt->Tuple.Pos = yyt->Tuple.ExpressionList->ExpressionList.Pos;
yyt->Tuple.Next->ExpressionList.DeclsIn=yyt->Tuple.DeclsIn;
yyVisit1ExpressionList (yyt->Tuple.Next);
/* line 1530 "sum.cg" */
 
  yyt->Tuple.Type = Tyof_Tuple (TyExtract(yyt->Tuple.ExpressionList));
/* line 737 "sum.cg" */

    yyt->Tuple.DeclsOut = yyt->Tuple.DeclsIn;
/* line 362 "sum.cg" */
yyt->Tuple.IsTypeExp = false;
} break;
case kExp_SchemaRef: {
/* line 798 "sum.cg" */
 
    yyt->Exp_SchemaRef.IdList->IdList.DeclsIn = yyt->Exp_SchemaRef.DeclsIn;
yyVisit1IdList (yyt->Exp_SchemaRef.IdList);
/* line 489 "sum.cg" */

    yyt->Exp_SchemaRef.Pos = yyt->Exp_SchemaRef.IdList->IdList.Pos;
/* line 799 "sum.cg" */

    yyt->Exp_SchemaRef.ExpressionList->ExpressionList.DeclsIn = yyt->Exp_SchemaRef.DeclsIn;
yyVisit1ExpressionList (yyt->Exp_SchemaRef.ExpressionList);
yyt->Exp_SchemaRef.Next->ExpressionList.DeclsIn=yyt->Exp_SchemaRef.DeclsIn;
yyVisit1ExpressionList (yyt->Exp_SchemaRef.Next);
/* line 1534 "sum.cg" */
 
  yyt->Exp_SchemaRef.Type = Tyof_Exp_SchemaRef (yyt->Exp_SchemaRef.DeclsIn, yyt->Exp_SchemaRef.IdList, yyt->Exp_SchemaRef.ExpressionList);
/* line 737 "sum.cg" */

    yyt->Exp_SchemaRef.DeclsOut = yyt->Exp_SchemaRef.DeclsIn;
/* line 1535 "sum.cg" */

  yyt->Exp_SchemaRef.IsTypeExp = true;
} break;
case kTheta: {
/* line 803 "sum.cg" */
  
    yyt->Theta.Exp->Exp.DeclsIn = yyt->Theta.DeclsIn;
yyVisit1Exp (yyt->Theta.Exp);
/* line 493 "sum.cg" */

    yyt->Theta.Pos = yyt->Theta.Exp->Exp.Pos;
yyt->Theta.Next->ExpressionList.DeclsIn=yyt->Theta.DeclsIn;
yyVisit1ExpressionList (yyt->Theta.Next);
/* line 1539 "sum.cg" */

 
     CkThetaAIEnv(yyt->Theta.Exp);
     yyt->Theta.Type = ThetaType(yyt->Theta.Exp->Exp.Type,yyt->Theta.DeclsIn);
  
/* line 737 "sum.cg" */

    yyt->Theta.DeclsOut = yyt->Theta.DeclsIn;
/* line 362 "sum.cg" */
yyt->Theta.IsTypeExp = false;
} break;
case kInfixOp: {
yyt->InfixOp.Next->ExpressionList.DeclsIn=yyt->InfixOp.DeclsIn;
yyVisit1ExpressionList (yyt->InfixOp.Next);
yyt->InfixOp.Op1->Exp.DeclsIn=yyt->InfixOp.Next->ExpressionList.DeclsOut;
yyVisit1Exp (yyt->InfixOp.Op1);
/* line 497 "sum.cg" */

    yyt->InfixOp.Pos = yyt->InfixOp.Op1->Exp.Pos;
yyt->InfixOp.Op2->Exp.DeclsIn=yyt->InfixOp.Op1->Exp.DeclsOut;
yyVisit1Exp (yyt->InfixOp.Op2);
/* line 1548 "sum.cg" */
 
  
  yyt->InfixOp.Type = Tyof_InfixExp (yyt->InfixOp.DeclsIn, yyt->InfixOp.Infix, yyt->InfixOp.Op1, yyt->InfixOp.Op2);
/* line 737 "sum.cg" */

    yyt->InfixOp.DeclsOut = yyt->InfixOp.DeclsIn;
/* line 1549 "sum.cg" */

  yyt->InfixOp.IsTypeExp = yyt->InfixOp.Type->Tp_Exp.IsTypeExp;
} break;
case kPredExp: {
/* line 1553 "sum.cg" */

    yyt->PredExp.Pred->Pred.DeclsIn = yyt->PredExp.DeclsIn;
yyVisit1Pred (yyt->PredExp.Pred);
/* line 501 "sum.cg" */

    yyt->PredExp.Pos = yyt->PredExp.Pred->Pred.Pos;
yyt->PredExp.Next->ExpressionList.DeclsIn=yyt->PredExp.DeclsIn;
yyVisit1ExpressionList (yyt->PredExp.Next);
/* line 1554 "sum.cg" */

    yyt->PredExp.Type = yyt->PredExp.Pred->Pred.Type;
/* line 737 "sum.cg" */

    yyt->PredExp.DeclsOut = yyt->PredExp.DeclsIn;
/* line 1555 "sum.cg" */

    yyt->PredExp.IsTypeExp = yyt->PredExp.Type->Tp_Exp.IsTypeExp;
} break;
 default: ;
 }
}

static void yyVisit1Exp
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kExp: {
/* line 359 "sum.cg" */
yyt->Exp.Pos = NoPosition;
yyt->Exp.Next->ExpressionList.DeclsIn=yyt->Exp.DeclsIn;
yyVisit1ExpressionList (yyt->Exp.Next);
/* line 366 "sum.cg" */
yyt->Exp.Type = NoType;
/* line 737 "sum.cg" */

    yyt->Exp.DeclsOut = yyt->Exp.DeclsIn;
/* line 362 "sum.cg" */
yyt->Exp.IsTypeExp = false;
} break;
case kVariable: {
yyt->Variable.Next->ExpressionList.DeclsIn=yyt->Variable.DeclsIn;
yyVisit1ExpressionList (yyt->Variable.Next);
yyt->Variable.IdList->IdList.DeclsIn=yyt->Variable.Next->ExpressionList.DeclsOut;
yyVisit1IdList (yyt->Variable.IdList);
/* line 408 "sum.cg" */

    yyt->Variable.Pos = yyt->Variable.IdList->IdList.Pos;
/* line 371 "sum.cg" */
yyt->Variable.IsBinding=false;
/* line 370 "sum.cg" */
yyt->Variable.SymPtr=NoSym;
/* line 1431 "sum.cg" */

  {
    tObjects sym_ptr;
    bool isbinding;

    yyt->Variable.Type = Tyof_Variable (yyt->Variable.DeclsIn, yyt->Variable.IdList, &sym_ptr, &isbinding, 1); 
    
    
    
    yyt->Variable.SymPtr = sym_ptr;
    yyt->Variable.IsBinding = isbinding;
  }
  
/* line 737 "sum.cg" */

    yyt->Variable.DeclsOut = yyt->Variable.DeclsIn;
/* line 1444 "sum.cg" */

  yyt->Variable.IsTypeExp = yyt->Variable.Type->Tp_Exp.IsTypeExp;
} break;
case kLiteral: {
/* line 412 "sum.cg" */

    yyt->Literal.Pos = yyt->Literal.Literal.Pos;
yyt->Literal.Next->ExpressionList.DeclsIn=yyt->Literal.DeclsIn;
yyVisit1ExpressionList (yyt->Literal.Next);
/* line 1448 "sum.cg" */
  
  yyt->Literal.Type = Tyof_Literal (yyt->Literal.Literal.Ident);
/* line 737 "sum.cg" */

    yyt->Literal.DeclsOut = yyt->Literal.DeclsIn;
/* line 362 "sum.cg" */
yyt->Literal.IsTypeExp = false;
} break;
case kString: {
/* line 416 "sum.cg" */

    yyt->String.Pos = yyt->String.String.Pos;
yyt->String.Next->ExpressionList.DeclsIn=yyt->String.DeclsIn;
yyVisit1ExpressionList (yyt->String.Next);
/* line 1452 "sum.cg" */

    yyt->String.Type = StringTy;
/* line 737 "sum.cg" */

    yyt->String.DeclsOut = yyt->String.DeclsIn;
/* line 362 "sum.cg" */
yyt->String.IsTypeExp = false;
} break;
case kChar: {
/* line 420 "sum.cg" */

    yyt->Char.Pos = yyt->Char.Char.Pos;
yyt->Char.Next->ExpressionList.DeclsIn=yyt->Char.DeclsIn;
yyVisit1ExpressionList (yyt->Char.Next);
/* line 1456 "sum.cg" */

    yyt->Char.Type = CharTy;
/* line 737 "sum.cg" */

    yyt->Char.DeclsOut = yyt->Char.DeclsIn;
/* line 362 "sum.cg" */
yyt->Char.IsTypeExp = false;
} break;
case kPrefixOp: {
yyt->PrefixOp.Next->ExpressionList.DeclsIn=yyt->PrefixOp.DeclsIn;
yyVisit1ExpressionList (yyt->PrefixOp.Next);
yyt->PrefixOp.Exp->Exp.DeclsIn=yyt->PrefixOp.Next->ExpressionList.DeclsOut;
yyVisit1Exp (yyt->PrefixOp.Exp);
/* line 424 "sum.cg" */

    yyt->PrefixOp.Pos = yyt->PrefixOp.Exp->Exp.Pos;
/* line 1460 "sum.cg" */
 
  yyt->PrefixOp.Type = Tyof_PrefixExp (yyt->PrefixOp.DeclsIn, yyt->PrefixOp.Prefix, yyt->PrefixOp.Exp);
/* line 737 "sum.cg" */

    yyt->PrefixOp.DeclsOut = yyt->PrefixOp.DeclsIn;
/* line 1461 "sum.cg" */
 
  yyt->PrefixOp.IsTypeExp = yyt->PrefixOp.Type->Tp_Exp.IsTypeExp;
} break;
case kLambda: {
/* line 741 "sum.cg" */
 
    yyt->Lambda.SchemaText->SchemaText.DeclsIn = yyt->Lambda.DeclsIn;
yyVisit1SchemaText (yyt->Lambda.SchemaText);
/* line 428 "sum.cg" */

    yyt->Lambda.Pos = yyt->Lambda.SchemaText->SchemaText.Pos;
yyt->Lambda.Exp->Exp.DeclsIn=yyt->Lambda.SchemaText->SchemaText.DeclsOut;
yyVisit1Exp (yyt->Lambda.Exp);
/* line 743 "sum.cg" */
 
    
    yyt->Lambda.Next->ExpressionList.DeclsIn = yyt->Lambda.DeclsIn;
yyVisit1ExpressionList (yyt->Lambda.Next);
/* line 1469 "sum.cg" */
 
  yyt->Lambda.Type = Tyof_Lambda (yyt->Lambda.SchemaText->SchemaText.DeclList->DeclList.DeclsIn->Obj_Tmp.Inner, yyt->Lambda.Exp->Exp.Type);
/* line 737 "sum.cg" */

    yyt->Lambda.DeclsOut = yyt->Lambda.DeclsIn;
/* line 362 "sum.cg" */
yyt->Lambda.IsTypeExp = false;
} break;
case kRecDisp: {
/* line 747 "sum.cg" */
 
    yyt->RecDisp.SchemaText->SchemaText.DeclsIn = yyt->RecDisp.DeclsIn;
yyVisit1SchemaText (yyt->RecDisp.SchemaText);
/* line 452 "sum.cg" */

    yyt->RecDisp.Pos = yyt->RecDisp.SchemaText->SchemaText.Pos;
yyt->RecDisp.PredList->PredList.DeclsIn=yyt->RecDisp.SchemaText->SchemaText.DeclsOut;
yyVisit1PredList (yyt->RecDisp.PredList);
/* line 749 "sum.cg" */

    
    yyt->RecDisp.Next->ExpressionList.DeclsIn = yyt->RecDisp.DeclsIn;
yyVisit1ExpressionList (yyt->RecDisp.Next);
/* line 1414 "sum.cg" */
if (! ( PredIsBool(yyt->RecDisp.PredList) )) { Error(NonBoolPredPos(yyt->RecDisp.PredList),error33); }
/* line 1473 "sum.cg" */
 
  yyt->RecDisp.Type = yyt->RecDisp.SchemaText->SchemaText.Type;
/* line 737 "sum.cg" */

    yyt->RecDisp.DeclsOut = yyt->RecDisp.DeclsIn;
/* line 362 "sum.cg" */
yyt->RecDisp.IsTypeExp = false;
} break;
case kMu: {
/* line 753 "sum.cg" */
 
    yyt->Mu.SchemaText->SchemaText.DeclsIn = yyt->Mu.DeclsIn;
yyVisit1SchemaText (yyt->Mu.SchemaText);
/* line 448 "sum.cg" */

    yyt->Mu.Pos = yyt->Mu.SchemaText->SchemaText.Pos;
yyt->Mu.ExpressionList->ExpressionList.DeclsIn=yyt->Mu.SchemaText->SchemaText.DeclsOut;
yyVisit1ExpressionList (yyt->Mu.ExpressionList);
/* line 755 "sum.cg" */

    
    yyt->Mu.Next->ExpressionList.DeclsIn = yyt->Mu.DeclsIn;
yyVisit1ExpressionList (yyt->Mu.Next);
/* line 1478 "sum.cg" */

        yyt->Mu.Type = Tyof_Mu (yyt->Mu.SchemaText->SchemaText.DeclList->DeclList.DeclsIn->Obj_Tmp.Inner, yyt->Mu.ExpressionList->ExpressionList.Type);
	
  
/* line 737 "sum.cg" */

    yyt->Mu.DeclsOut = yyt->Mu.DeclsIn;
/* line 362 "sum.cg" */
yyt->Mu.IsTypeExp = false;
} break;
case kTupSelection: {
yyt->TupSelection.Next->ExpressionList.DeclsIn=yyt->TupSelection.DeclsIn;
yyVisit1ExpressionList (yyt->TupSelection.Next);
yyt->TupSelection.Exp->Exp.DeclsIn=yyt->TupSelection.Next->ExpressionList.DeclsOut;
yyVisit1Exp (yyt->TupSelection.Exp);
/* line 432 "sum.cg" */

    yyt->TupSelection.Pos = yyt->TupSelection.Exp->Exp.Pos;
/* line 1485 "sum.cg" */
 
  yyt->TupSelection.Type = TupSelectType (yyt->TupSelection.Exp->Exp.Type, yyt->TupSelection.Exp->Exp.Pos, yyt->TupSelection.Number);
/* line 737 "sum.cg" */

    yyt->TupSelection.DeclsOut = yyt->TupSelection.DeclsIn;
/* line 362 "sum.cg" */
yyt->TupSelection.IsTypeExp = false;
} break;
case kVarSelection: {
yyt->VarSelection.Next->ExpressionList.DeclsIn=yyt->VarSelection.DeclsIn;
yyVisit1ExpressionList (yyt->VarSelection.Next);
yyt->VarSelection.Exp->Exp.DeclsIn=yyt->VarSelection.Next->ExpressionList.DeclsOut;
yyVisit1Exp (yyt->VarSelection.Exp);
/* line 436 "sum.cg" */

    yyt->VarSelection.Pos = yyt->VarSelection.Exp->Exp.Pos;
/* line 1490 "sum.cg" */
 

  yyt->VarSelection.Type = Tyof_SchemaBind (yyt->VarSelection.Exp->Exp.Type, yyt->VarSelection.Exp->Exp.Pos, yyt->VarSelection.Ident);
/* line 737 "sum.cg" */

    yyt->VarSelection.DeclsOut = yyt->VarSelection.DeclsIn;
/* line 362 "sum.cg" */
yyt->VarSelection.IsTypeExp = false;
} break;
case kIfExp: {
yyt->IfExp.Next->ExpressionList.DeclsIn=yyt->IfExp.DeclsIn;
yyVisit1ExpressionList (yyt->IfExp.Next);
yyt->IfExp.Con->Pred.DeclsIn=yyt->IfExp.Next->ExpressionList.DeclsOut;
yyVisit1Pred (yyt->IfExp.Con);
/* line 440 "sum.cg" */

    yyt->IfExp.Pos = yyt->IfExp.Con->Pred.Pos;
yyt->IfExp.Then->Exp.DeclsIn=yyt->IfExp.Con->Pred.DeclsOut;
yyVisit1Exp (yyt->IfExp.Then);
yyt->IfExp.Else->Exp.DeclsIn=yyt->IfExp.Then->Exp.DeclsOut;
yyVisit1Exp (yyt->IfExp.Else);
/* line 1416 "sum.cg" */
if (! ( PredIsBool(yyt->IfExp.Con) )) { Error(NonBoolPredPos(yyt->IfExp.Con),error33); }
/* line 1494 "sum.cg" */

	yyt->IfExp.Type = Tyof_IfExp (yyt->IfExp.Con->Pred.Type, yyt->IfExp.Con->Pred.Pos, yyt->IfExp.Then->Exp.Type, yyt->IfExp.Then->Exp.Pos, yyt->IfExp.Else->Exp.Type);
	CkPredListAIEnv (yyt->IfExp.Con);
  
/* line 737 "sum.cg" */

    yyt->IfExp.DeclsOut = yyt->IfExp.DeclsIn;
/* line 362 "sum.cg" */
yyt->IfExp.IsTypeExp = false;
} break;
case kFncApplication: {
yyt->FncApplication.Next->ExpressionList.DeclsIn=yyt->FncApplication.DeclsIn;
yyVisit1ExpressionList (yyt->FncApplication.Next);
yyt->FncApplication.Fnc->Exp.DeclsIn=yyt->FncApplication.Next->ExpressionList.DeclsOut;
yyVisit1Exp (yyt->FncApplication.Fnc);
/* line 444 "sum.cg" */

    yyt->FncApplication.Pos = yyt->FncApplication.Fnc->Exp.Pos;
yyt->FncApplication.Arg->ExpressionList.DeclsIn=yyt->FncApplication.Fnc->Exp.DeclsOut;
yyVisit1ExpressionList (yyt->FncApplication.Arg);
/* line 1501 "sum.cg" */
 
  yyt->FncApplication.Type = Tyof_FncApp (yyt->FncApplication.DeclsIn, yyt->FncApplication.Fnc, TyExtract(yyt->FncApplication.Arg));
/* line 737 "sum.cg" */

    yyt->FncApplication.DeclsOut = yyt->FncApplication.DeclsIn;
/* line 362 "sum.cg" */
yyt->FncApplication.IsTypeExp = false;
} break;
case kSetComp: {
/* line 759 "sum.cg" */
 
    yyt->SetComp.SchemaText->SchemaText.DeclsIn = yyt->SetComp.DeclsIn;
yyVisit1SchemaText (yyt->SetComp.SchemaText);
/* line 457 "sum.cg" */

    yyt->SetComp.Pos = yyt->SetComp.SchemaText->SchemaText.Pos;
yyt->SetComp.ExpressionList->ExpressionList.DeclsIn=yyt->SetComp.SchemaText->SchemaText.DeclsOut;
yyVisit1ExpressionList (yyt->SetComp.ExpressionList);
/* line 761 "sum.cg" */

		yyt->SetComp.Next->ExpressionList.DeclsIn = yyt->SetComp.DeclsIn;
		
	
yyVisit1ExpressionList (yyt->SetComp.Next);
/* line 1465 "sum.cg" */
 
  yyt->SetComp.Type = Tyof_SetComp (yyt->SetComp.SchemaText->SchemaText.DeclList->DeclList.DeclsIn->Obj_Tmp.Inner, yyt->SetComp.ExpressionList->ExpressionList.Type);
/* line 737 "sum.cg" */

    yyt->SetComp.DeclsOut = yyt->SetComp.DeclsIn;
/* line 362 "sum.cg" */
yyt->SetComp.IsTypeExp = false;
} break;
case kSetElab: {
/* line 768 "sum.cg" */
 
    yyt->SetElab.ExpressionList->ExpressionList.DeclsIn = yyt->SetElab.DeclsIn;
yyVisit1ExpressionList (yyt->SetElab.ExpressionList);
/* line 461 "sum.cg" */

    yyt->SetElab.Pos = yyt->SetElab.ExpressionList->ExpressionList.Pos;
yyt->SetElab.Next->ExpressionList.DeclsIn=yyt->SetElab.DeclsIn;
yyVisit1ExpressionList (yyt->SetElab.Next);
/* line 1505 "sum.cg" */
 
  yyt->SetElab.Type = Tyof_SetElab (TyExtract(yyt->SetElab.ExpressionList), yyt->SetElab.ExpressionList->ExpressionList.Pos);
/* line 737 "sum.cg" */

    yyt->SetElab.DeclsOut = yyt->SetElab.DeclsIn;
/* line 362 "sum.cg" */
yyt->SetElab.IsTypeExp = false;
} break;
case kArrayUpd: {
/* line 772 "sum.cg" */
   
    yyt->ArrayUpd.Array->IdList.DeclsIn = yyt->ArrayUpd.DeclsIn;
yyVisit1IdList (yyt->ArrayUpd.Array);
/* line 465 "sum.cg" */

    yyt->ArrayUpd.Pos = yyt->ArrayUpd.Array->IdList.Pos;
/* line 774 "sum.cg" */

    yyt->ArrayUpd.Value->Exp.DeclsIn = yyt->ArrayUpd.DeclsIn;
yyVisit1Exp (yyt->ArrayUpd.Value);
/* line 773 "sum.cg" */

    yyt->ArrayUpd.Index->Exp.DeclsIn = yyt->ArrayUpd.DeclsIn;
yyVisit1Exp (yyt->ArrayUpd.Index);
yyt->ArrayUpd.Next->ExpressionList.DeclsIn=yyt->ArrayUpd.DeclsIn;
yyVisit1ExpressionList (yyt->ArrayUpd.Next);
/* line 1509 "sum.cg" */

    yyt->ArrayUpd.Type = Tyof_ArrayUpd(yyt->ArrayUpd.DeclsIn,yyt->ArrayUpd.Array,yyt->ArrayUpd.Index,yyt->ArrayUpd.Value);
/* line 737 "sum.cg" */

    yyt->ArrayUpd.DeclsOut = yyt->ArrayUpd.DeclsIn;
/* line 362 "sum.cg" */
yyt->ArrayUpd.IsTypeExp = false;
} break;
case kNamedArrayAgg: {
/* line 778 "sum.cg" */

    yyt->NamedArrayAgg.ExpressionList->ExpressionList.DeclsIn = yyt->NamedArrayAgg.DeclsIn;
yyVisit1ExpressionList (yyt->NamedArrayAgg.ExpressionList);
/* line 469 "sum.cg" */

    yyt->NamedArrayAgg.Pos = yyt->NamedArrayAgg.ExpressionList->ExpressionList.Pos;
yyt->NamedArrayAgg.Next->ExpressionList.DeclsIn=yyt->NamedArrayAgg.DeclsIn;
yyVisit1ExpressionList (yyt->NamedArrayAgg.Next);
/* line 1513 "sum.cg" */
 
  yyt->NamedArrayAgg.Type = Tyof_SetElab(TyExtract(yyt->NamedArrayAgg.ExpressionList), yyt->NamedArrayAgg.ExpressionList->ExpressionList.Pos);
/* line 737 "sum.cg" */

    yyt->NamedArrayAgg.DeclsOut = yyt->NamedArrayAgg.DeclsIn;
/* line 362 "sum.cg" */
yyt->NamedArrayAgg.IsTypeExp = false;
} break;
case kSequence: {
/* line 782 "sum.cg" */
 
    yyt->Sequence.ExpressionList->ExpressionList.DeclsIn = yyt->Sequence.DeclsIn;
yyVisit1ExpressionList (yyt->Sequence.ExpressionList);
/* line 473 "sum.cg" */

    yyt->Sequence.Pos = yyt->Sequence.ExpressionList->ExpressionList.Pos;
yyt->Sequence.Next->ExpressionList.DeclsIn=yyt->Sequence.DeclsIn;
yyVisit1ExpressionList (yyt->Sequence.Next);
/* line 1517 "sum.cg" */
 
  yyt->Sequence.Type = Tyof_Seq (TyExtract(yyt->Sequence.ExpressionList), yyt->Sequence.ExpressionList->ExpressionList.Pos);
/* line 737 "sum.cg" */

    yyt->Sequence.DeclsOut = yyt->Sequence.DeclsIn;
/* line 362 "sum.cg" */
yyt->Sequence.IsTypeExp = false;
} break;
case kBag: {
/* line 786 "sum.cg" */
 
    yyt->Bag.ExpressionList->ExpressionList.DeclsIn = yyt->Bag.DeclsIn;
yyVisit1ExpressionList (yyt->Bag.ExpressionList);
/* line 477 "sum.cg" */

    yyt->Bag.Pos = yyt->Bag.ExpressionList->ExpressionList.Pos;
yyt->Bag.Next->ExpressionList.DeclsIn=yyt->Bag.DeclsIn;
yyVisit1ExpressionList (yyt->Bag.Next);
/* line 1521 "sum.cg" */
 
  yyt->Bag.Type = Tyof_Bag (TyExtract(yyt->Bag.ExpressionList), yyt->Bag.ExpressionList->ExpressionList.Pos);
/* line 737 "sum.cg" */

    yyt->Bag.DeclsOut = yyt->Bag.DeclsIn;
/* line 362 "sum.cg" */
yyt->Bag.IsTypeExp = false;
} break;
case kCartProd: {
/* line 790 "sum.cg" */
 
    yyt->CartProd.ExpressionList->ExpressionList.DeclsIn = yyt->CartProd.DeclsIn;
yyVisit1ExpressionList (yyt->CartProd.ExpressionList);
/* line 481 "sum.cg" */

    yyt->CartProd.Pos = yyt->CartProd.ExpressionList->ExpressionList.Pos;
yyt->CartProd.Next->ExpressionList.DeclsIn=yyt->CartProd.DeclsIn;
yyVisit1ExpressionList (yyt->CartProd.Next);
/* line 1525 "sum.cg" */
 
    yyt->CartProd.Type = Tyof_CartProd (yyt->CartProd.ExpressionList);
/* line 737 "sum.cg" */

    yyt->CartProd.DeclsOut = yyt->CartProd.DeclsIn;
/* line 1526 "sum.cg" */

    yyt->CartProd.IsTypeExp = yyt->CartProd.Type->Tp_Exp.IsTypeExp;
} break;
case kTuple: {
/* line 794 "sum.cg" */
 
    yyt->Tuple.ExpressionList->ExpressionList.DeclsIn = yyt->Tuple.DeclsIn;
yyVisit1ExpressionList (yyt->Tuple.ExpressionList);
/* line 485 "sum.cg" */

    yyt->Tuple.Pos = yyt->Tuple.ExpressionList->ExpressionList.Pos;
yyt->Tuple.Next->ExpressionList.DeclsIn=yyt->Tuple.DeclsIn;
yyVisit1ExpressionList (yyt->Tuple.Next);
/* line 1530 "sum.cg" */
 
  yyt->Tuple.Type = Tyof_Tuple (TyExtract(yyt->Tuple.ExpressionList));
/* line 737 "sum.cg" */

    yyt->Tuple.DeclsOut = yyt->Tuple.DeclsIn;
/* line 362 "sum.cg" */
yyt->Tuple.IsTypeExp = false;
} break;
case kExp_SchemaRef: {
/* line 798 "sum.cg" */
 
    yyt->Exp_SchemaRef.IdList->IdList.DeclsIn = yyt->Exp_SchemaRef.DeclsIn;
yyVisit1IdList (yyt->Exp_SchemaRef.IdList);
/* line 489 "sum.cg" */

    yyt->Exp_SchemaRef.Pos = yyt->Exp_SchemaRef.IdList->IdList.Pos;
/* line 799 "sum.cg" */

    yyt->Exp_SchemaRef.ExpressionList->ExpressionList.DeclsIn = yyt->Exp_SchemaRef.DeclsIn;
yyVisit1ExpressionList (yyt->Exp_SchemaRef.ExpressionList);
yyt->Exp_SchemaRef.Next->ExpressionList.DeclsIn=yyt->Exp_SchemaRef.DeclsIn;
yyVisit1ExpressionList (yyt->Exp_SchemaRef.Next);
/* line 1534 "sum.cg" */
 
  yyt->Exp_SchemaRef.Type = Tyof_Exp_SchemaRef (yyt->Exp_SchemaRef.DeclsIn, yyt->Exp_SchemaRef.IdList, yyt->Exp_SchemaRef.ExpressionList);
/* line 737 "sum.cg" */

    yyt->Exp_SchemaRef.DeclsOut = yyt->Exp_SchemaRef.DeclsIn;
/* line 1535 "sum.cg" */

  yyt->Exp_SchemaRef.IsTypeExp = true;
} break;
case kTheta: {
/* line 803 "sum.cg" */
  
    yyt->Theta.Exp->Exp.DeclsIn = yyt->Theta.DeclsIn;
yyVisit1Exp (yyt->Theta.Exp);
/* line 493 "sum.cg" */

    yyt->Theta.Pos = yyt->Theta.Exp->Exp.Pos;
yyt->Theta.Next->ExpressionList.DeclsIn=yyt->Theta.DeclsIn;
yyVisit1ExpressionList (yyt->Theta.Next);
/* line 1539 "sum.cg" */

 
     CkThetaAIEnv(yyt->Theta.Exp);
     yyt->Theta.Type = ThetaType(yyt->Theta.Exp->Exp.Type,yyt->Theta.DeclsIn);
  
/* line 737 "sum.cg" */

    yyt->Theta.DeclsOut = yyt->Theta.DeclsIn;
/* line 362 "sum.cg" */
yyt->Theta.IsTypeExp = false;
} break;
case kInfixOp: {
yyt->InfixOp.Next->ExpressionList.DeclsIn=yyt->InfixOp.DeclsIn;
yyVisit1ExpressionList (yyt->InfixOp.Next);
yyt->InfixOp.Op1->Exp.DeclsIn=yyt->InfixOp.Next->ExpressionList.DeclsOut;
yyVisit1Exp (yyt->InfixOp.Op1);
/* line 497 "sum.cg" */

    yyt->InfixOp.Pos = yyt->InfixOp.Op1->Exp.Pos;
yyt->InfixOp.Op2->Exp.DeclsIn=yyt->InfixOp.Op1->Exp.DeclsOut;
yyVisit1Exp (yyt->InfixOp.Op2);
/* line 1548 "sum.cg" */
 
  
  yyt->InfixOp.Type = Tyof_InfixExp (yyt->InfixOp.DeclsIn, yyt->InfixOp.Infix, yyt->InfixOp.Op1, yyt->InfixOp.Op2);
/* line 737 "sum.cg" */

    yyt->InfixOp.DeclsOut = yyt->InfixOp.DeclsIn;
/* line 1549 "sum.cg" */

  yyt->InfixOp.IsTypeExp = yyt->InfixOp.Type->Tp_Exp.IsTypeExp;
} break;
case kPredExp: {
/* line 1553 "sum.cg" */

    yyt->PredExp.Pred->Pred.DeclsIn = yyt->PredExp.DeclsIn;
yyVisit1Pred (yyt->PredExp.Pred);
/* line 501 "sum.cg" */

    yyt->PredExp.Pos = yyt->PredExp.Pred->Pred.Pos;
yyt->PredExp.Next->ExpressionList.DeclsIn=yyt->PredExp.DeclsIn;
yyVisit1ExpressionList (yyt->PredExp.Next);
/* line 1554 "sum.cg" */

    yyt->PredExp.Type = yyt->PredExp.Pred->Pred.Type;
/* line 737 "sum.cg" */

    yyt->PredExp.DeclsOut = yyt->PredExp.DeclsIn;
/* line 1555 "sum.cg" */

    yyt->PredExp.IsTypeExp = yyt->PredExp.Type->Tp_Exp.IsTypeExp;
} break;
 default: ;
 }
}

static void yyVisit1PredList
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kPredList: {
/* line 359 "sum.cg" */
yyt->PredList.Pos = NoPosition;
/* line 366 "sum.cg" */
yyt->PredList.Type = NoType;
/* line 1326 "sum.cg" */

    yyt->PredList.DeclsOut = yyt->PredList.DeclsIn;
/* line 362 "sum.cg" */
yyt->PredList.IsTypeExp = false;
} break;
case kNoPred: {
/* line 359 "sum.cg" */
yyt->NoPred.Pos = NoPosition;
/* line 366 "sum.cg" */
yyt->NoPred.Type = NoType;
/* line 1326 "sum.cg" */

    yyt->NoPred.DeclsOut = yyt->NoPred.DeclsIn;
/* line 362 "sum.cg" */
yyt->NoPred.IsTypeExp = false;
} break;
case kPred: {
/* line 359 "sum.cg" */
yyt->Pred.Pos = NoPosition;
yyt->Pred.Next->PredList.DeclsIn=yyt->Pred.DeclsIn;
yyVisit1PredList (yyt->Pred.Next);
/* line 366 "sum.cg" */
yyt->Pred.Type = NoType;
/* line 1326 "sum.cg" */

    yyt->Pred.DeclsOut = yyt->Pred.DeclsIn;
/* line 362 "sum.cg" */
yyt->Pred.IsTypeExp = false;
} break;
case kQuantPred: {
/* line 1330 "sum.cg" */
 
    yyt->QuantPred.SchemaText->SchemaText.DeclsIn = yyt->QuantPred.DeclsIn;
yyVisit1SchemaText (yyt->QuantPred.SchemaText);
/* line 574 "sum.cg" */

    yyt->QuantPred.Pos = yyt->QuantPred.SchemaText->SchemaText.Pos;
yyt->QuantPred.Pred->Pred.DeclsIn=yyt->QuantPred.SchemaText->SchemaText.DeclsOut;
yyVisit1Pred (yyt->QuantPred.Pred);
yyt->QuantPred.Next->PredList.DeclsIn=yyt->QuantPred.DeclsIn;
yyVisit1PredList (yyt->QuantPred.Next);
/* line 1561 "sum.cg" */

		yyt->QuantPred.Type = Tyof_QuantPred(yyt->QuantPred.Pred);
		CkPredListAIEnv (yyt->QuantPred.Pred);  
	
/* line 1332 "sum.cg" */
 
		yyt->QuantPred.DeclsOut = yyt->QuantPred.DeclsIn;
	
/* line 362 "sum.cg" */
yyt->QuantPred.IsTypeExp = false;
} break;
case kRelBinPred: {
/* line 1338 "sum.cg" */

    yyt->RelBinPred.L->Exp.DeclsIn = yyt->RelBinPred.DeclsIn;
yyVisit1Exp (yyt->RelBinPred.L);
/* line 578 "sum.cg" */

    yyt->RelBinPred.Pos = yyt->RelBinPred.L->Exp.Pos;
/* line 1339 "sum.cg" */

    yyt->RelBinPred.R->Exp.DeclsIn = yyt->RelBinPred.DeclsIn;
yyVisit1Exp (yyt->RelBinPred.R);
yyt->RelBinPred.Next->PredList.DeclsIn=yyt->RelBinPred.DeclsIn;
yyVisit1PredList (yyt->RelBinPred.Next);
/* line 1568 "sum.cg" */

    yyt->RelBinPred.Type = Tyof_RelBinPred (yyt->RelBinPred.DeclsIn, yyt->RelBinPred.L, yyt->RelBinPred.R, yyt->RelBinPred.RelBinOp);
/* line 1326 "sum.cg" */

    yyt->RelBinPred.DeclsOut = yyt->RelBinPred.DeclsIn;
/* line 362 "sum.cg" */
yyt->RelBinPred.IsTypeExp = false;
} break;
case kAssign: {
/* line 1345 "sum.cg" */

    yyt->Assign.L->NameList.DeclsIn = yyt->Assign.DeclsIn;
yyVisit1NameList (yyt->Assign.L);
/* line 582 "sum.cg" */

    yyt->Assign.Pos = yyt->Assign.L->NameList.Pos;
/* line 1346 "sum.cg" */

    yyt->Assign.R->ExpressionList.DeclsIn = yyt->Assign.DeclsIn;
yyVisit1ExpressionList (yyt->Assign.R);
yyt->Assign.Next->PredList.DeclsIn=yyt->Assign.DeclsIn;
yyVisit1PredList (yyt->Assign.Next);
/* line 1572 "sum.cg" */

    yyt->Assign.Type = Tyof_Assign (yyt->Assign.DeclsIn, yyt->Assign.L, yyt->Assign.R);
/* line 1326 "sum.cg" */

    yyt->Assign.DeclsOut = yyt->Assign.DeclsIn;
/* line 362 "sum.cg" */
yyt->Assign.IsTypeExp = false;
} break;
case kRelPrePred: {
/* line 1350 "sum.cg" */

    yyt->RelPrePred.Exp->Exp.DeclsIn = yyt->RelPrePred.DeclsIn;
yyVisit1Exp (yyt->RelPrePred.Exp);
/* line 586 "sum.cg" */

    yyt->RelPrePred.Pos = yyt->RelPrePred.Exp->Exp.Pos;
yyt->RelPrePred.Next->PredList.DeclsIn=yyt->RelPrePred.DeclsIn;
yyVisit1PredList (yyt->RelPrePred.Next);
/* line 1576 "sum.cg" */

    yyt->RelPrePred.Type = Tyof_RelPrePred (yyt->RelPrePred.DeclsIn, yyt->RelPrePred.RelPreOp, yyt->RelPrePred.Exp);
/* line 1326 "sum.cg" */

    yyt->RelPrePred.DeclsOut = yyt->RelPrePred.DeclsIn;
/* line 362 "sum.cg" */
yyt->RelPrePred.IsTypeExp = false;
} break;
case kLogBinPred: {
/* line 1354 "sum.cg" */

    yyt->LogBinPred.L->Pred.DeclsIn = yyt->LogBinPred.DeclsIn;
yyVisit1Pred (yyt->LogBinPred.L);
/* line 590 "sum.cg" */

    yyt->LogBinPred.Pos = yyt->LogBinPred.L->Pred.Pos;
/* line 1355 "sum.cg" */

    yyt->LogBinPred.R->Pred.DeclsIn = yyt->LogBinPred.DeclsIn;
yyVisit1Pred (yyt->LogBinPred.R);
yyVisit1LogBinOp (yyt->LogBinPred.LogBinOp);
yyt->LogBinPred.Next->PredList.DeclsIn=yyt->LogBinPred.DeclsIn;
yyVisit1PredList (yyt->LogBinPred.Next);
/* line 1580 "sum.cg" */

    yyt->LogBinPred.Type = Tyof_LogBinPred (yyt->LogBinPred.L->Pred.Type, yyt->LogBinPred.R->Pred.Type, yyt->LogBinPred.L->Pred.Pos, yyt->LogBinPred.R->Pred.Pos);
/* line 1326 "sum.cg" */

    yyt->LogBinPred.DeclsOut = yyt->LogBinPred.DeclsIn;
/* line 362 "sum.cg" */
yyt->LogBinPred.IsTypeExp = false;
} break;
case kLogicalNot: {
/* line 1359 "sum.cg" */

    yyt->LogicalNot.Pred->Pred.DeclsIn = yyt->LogicalNot.DeclsIn;
yyVisit1Pred (yyt->LogicalNot.Pred);
/* line 594 "sum.cg" */

    yyt->LogicalNot.Pos = yyt->LogicalNot.Pred->Pred.Pos;
yyt->LogicalNot.Next->PredList.DeclsIn=yyt->LogicalNot.DeclsIn;
yyVisit1PredList (yyt->LogicalNot.Next);
/* line 1584 "sum.cg" */

    yyt->LogicalNot.Type = BoolTy;
/* line 1326 "sum.cg" */

    yyt->LogicalNot.DeclsOut = yyt->LogicalNot.DeclsIn;
/* line 362 "sum.cg" */
yyt->LogicalNot.IsTypeExp = false;
} break;
case kPreCondPred: {
/* line 1363 "sum.cg" */

    yyt->PreCondPred.Pred->Pred.DeclsIn = yyt->PreCondPred.DeclsIn;
yyVisit1Pred (yyt->PreCondPred.Pred);
/* line 598 "sum.cg" */

    yyt->PreCondPred.Pos = yyt->PreCondPred.Pred->Pred.Pos;
yyt->PreCondPred.Next->PredList.DeclsIn=yyt->PreCondPred.DeclsIn;
yyVisit1PredList (yyt->PreCondPred.Next);
/* line 1588 "sum.cg" */
 
    yyt->PreCondPred.Type = Tyof_PreCondPred (yyt->PreCondPred.Pred->Pred.Type, yyt->PreCondPred.Pred->Pred.Pos);
/* line 1326 "sum.cg" */

    yyt->PreCondPred.DeclsOut = yyt->PreCondPred.DeclsIn;
/* line 362 "sum.cg" */
yyt->PreCondPred.IsTypeExp = false;
} break;
case kIfPred: {
/* line 1367 "sum.cg" */

    yyt->IfPred.Con->Pred.DeclsIn = yyt->IfPred.DeclsIn;
yyVisit1Pred (yyt->IfPred.Con);
/* line 602 "sum.cg" */

    yyt->IfPred.Pos = yyt->IfPred.Con->Pred.Pos;
/* line 1369 "sum.cg" */

    yyt->IfPred.Else->Pred.DeclsIn = yyt->IfPred.DeclsIn;
yyVisit1Pred (yyt->IfPred.Else);
/* line 1368 "sum.cg" */

    yyt->IfPred.Then->Pred.DeclsIn = yyt->IfPred.DeclsIn;
yyVisit1Pred (yyt->IfPred.Then);
yyt->IfPred.Next->PredList.DeclsIn=yyt->IfPred.DeclsIn;
yyVisit1PredList (yyt->IfPred.Next);
/* line 1593 "sum.cg" */

    yyt->IfPred.Type = BoolTy;
/* line 1326 "sum.cg" */

    yyt->IfPred.DeclsOut = yyt->IfPred.DeclsIn;
/* line 362 "sum.cg" */
yyt->IfPred.IsTypeExp = false;
} break;
case kWhilePred: {
/* line 1373 "sum.cg" */

    yyt->WhilePred.Con->Pred.DeclsIn = yyt->WhilePred.DeclsIn;
yyVisit1Pred (yyt->WhilePred.Con);
/* line 606 "sum.cg" */

    yyt->WhilePred.Pos = yyt->WhilePred.Con->Pred.Pos;
/* line 1374 "sum.cg" */

    yyt->WhilePred.Do->Pred.DeclsIn = yyt->WhilePred.DeclsIn;
yyVisit1Pred (yyt->WhilePred.Do);
yyt->WhilePred.Next->PredList.DeclsIn=yyt->WhilePred.DeclsIn;
yyVisit1PredList (yyt->WhilePred.Next);
/* line 1597 "sum.cg" */

    yyt->WhilePred.Type = BoolTy;
/* line 1326 "sum.cg" */

    yyt->WhilePred.DeclsOut = yyt->WhilePred.DeclsIn;
/* line 362 "sum.cg" */
yyt->WhilePred.IsTypeExp = false;
} break;
case kCallPred: {
/* line 1378 "sum.cg" */

    yyt->CallPred.IdList->IdList.DeclsIn = yyt->CallPred.DeclsIn;
yyVisit1IdList (yyt->CallPred.IdList);
/* line 610 "sum.cg" */

    yyt->CallPred.Pos = yyt->CallPred.IdList->IdList.Pos;
/* line 1380 "sum.cg" */

    yyt->CallPred.OutputBindList->OutputBindList.DeclsIn = yyt->CallPred.DeclsIn;
yyVisit1OutputBindList (yyt->CallPred.OutputBindList);
/* line 1379 "sum.cg" */

    yyt->CallPred.InputBindList->InputBindList.DeclsIn = yyt->CallPred.DeclsIn;
yyVisit1InputBindList (yyt->CallPred.InputBindList);
yyt->CallPred.Next->PredList.DeclsIn=yyt->CallPred.DeclsIn;
yyVisit1PredList (yyt->CallPred.Next);
/* line 1601 "sum.cg" */

    yyt->CallPred.Type = BoolTy;
/* line 1326 "sum.cg" */

    yyt->CallPred.DeclsOut = yyt->CallPred.DeclsIn;
/* line 362 "sum.cg" */
yyt->CallPred.IsTypeExp = false;
} break;
case kChgOnly: {
/* line 1384 "sum.cg" */

    yyt->ChgOnly.NameList->NameList.DeclsIn = yyt->ChgOnly.DeclsIn;
yyVisit1NameList (yyt->ChgOnly.NameList);
/* line 614 "sum.cg" */

	yyt->ChgOnly.Pos = yyt->ChgOnly.NameList->NameList.Pos;
	yyt->ChgOnly.Pos.Column = yyt->ChgOnly.Pos.Column-13;
yyt->ChgOnly.Next->PredList.DeclsIn=yyt->ChgOnly.DeclsIn;
yyVisit1PredList (yyt->ChgOnly.Next);
/* line 1605 "sum.cg" */
 
    yyt->ChgOnly.Type = Tyof_ChgOnly (yyt->ChgOnly.DeclsIn, yyt->ChgOnly.NameList);
/* line 1326 "sum.cg" */

    yyt->ChgOnly.DeclsOut = yyt->ChgOnly.DeclsIn;
/* line 362 "sum.cg" */
yyt->ChgOnly.IsTypeExp = false;
} break;
case kDefined: {
/* line 359 "sum.cg" */
yyt->Defined.Pos = NoPosition;
yyt->Defined.Next->PredList.DeclsIn=yyt->Defined.DeclsIn;
yyVisit1PredList (yyt->Defined.Next);
yyt->Defined.Exp->Exp.DeclsIn=yyt->Defined.Next->PredList.DeclsOut;
yyVisit1Exp (yyt->Defined.Exp);
/* line 366 "sum.cg" */
yyt->Defined.Type = NoType;
/* line 1326 "sum.cg" */

    yyt->Defined.DeclsOut = yyt->Defined.DeclsIn;
/* line 362 "sum.cg" */
yyt->Defined.IsTypeExp = false;
} break;
case kSchemaPred: {
/* line 1388 "sum.cg" */

    yyt->SchemaPred.Schema->Schema.DeclsIn = yyt->SchemaPred.DeclsIn;
yyVisit1Schema (yyt->SchemaPred.Schema);
/* line 620 "sum.cg" */

    yyt->SchemaPred.Pos = yyt->SchemaPred.Schema->Schema.Pos;
yyt->SchemaPred.Next->PredList.DeclsIn=yyt->SchemaPred.DeclsIn;
yyVisit1PredList (yyt->SchemaPred.Next);
/* line 1613 "sum.cg" */

    yyt->SchemaPred.Type = yyt->SchemaPred.Schema->Schema.Type;
/* line 1326 "sum.cg" */

    yyt->SchemaPred.DeclsOut = yyt->SchemaPred.DeclsIn;
/* line 1614 "sum.cg" */

    yyt->SchemaPred.IsTypeExp = yyt->SchemaPred.Type->Tp_Exp.IsTypeExp;
} break;
case kBoolValue: {
/* line 359 "sum.cg" */
yyt->BoolValue.Pos = NoPosition;
yyt->BoolValue.Next->PredList.DeclsIn=yyt->BoolValue.DeclsIn;
yyVisit1PredList (yyt->BoolValue.Next);
/* line 1609 "sum.cg" */

    yyt->BoolValue.Type = BoolTy;
/* line 1326 "sum.cg" */

    yyt->BoolValue.DeclsOut = yyt->BoolValue.DeclsIn;
/* line 362 "sum.cg" */
yyt->BoolValue.IsTypeExp = false;
} break;
 default: ;
 }
}

static void yyVisit1Pred
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kPred: {
/* line 359 "sum.cg" */
yyt->Pred.Pos = NoPosition;
yyt->Pred.Next->PredList.DeclsIn=yyt->Pred.DeclsIn;
yyVisit1PredList (yyt->Pred.Next);
/* line 366 "sum.cg" */
yyt->Pred.Type = NoType;
/* line 1326 "sum.cg" */

    yyt->Pred.DeclsOut = yyt->Pred.DeclsIn;
/* line 362 "sum.cg" */
yyt->Pred.IsTypeExp = false;
} break;
case kQuantPred: {
/* line 1330 "sum.cg" */
 
    yyt->QuantPred.SchemaText->SchemaText.DeclsIn = yyt->QuantPred.DeclsIn;
yyVisit1SchemaText (yyt->QuantPred.SchemaText);
/* line 574 "sum.cg" */

    yyt->QuantPred.Pos = yyt->QuantPred.SchemaText->SchemaText.Pos;
yyt->QuantPred.Pred->Pred.DeclsIn=yyt->QuantPred.SchemaText->SchemaText.DeclsOut;
yyVisit1Pred (yyt->QuantPred.Pred);
yyt->QuantPred.Next->PredList.DeclsIn=yyt->QuantPred.DeclsIn;
yyVisit1PredList (yyt->QuantPred.Next);
/* line 1561 "sum.cg" */

		yyt->QuantPred.Type = Tyof_QuantPred(yyt->QuantPred.Pred);
		CkPredListAIEnv (yyt->QuantPred.Pred);  
	
/* line 1332 "sum.cg" */
 
		yyt->QuantPred.DeclsOut = yyt->QuantPred.DeclsIn;
	
/* line 362 "sum.cg" */
yyt->QuantPred.IsTypeExp = false;
} break;
case kRelBinPred: {
/* line 1338 "sum.cg" */

    yyt->RelBinPred.L->Exp.DeclsIn = yyt->RelBinPred.DeclsIn;
yyVisit1Exp (yyt->RelBinPred.L);
/* line 578 "sum.cg" */

    yyt->RelBinPred.Pos = yyt->RelBinPred.L->Exp.Pos;
/* line 1339 "sum.cg" */

    yyt->RelBinPred.R->Exp.DeclsIn = yyt->RelBinPred.DeclsIn;
yyVisit1Exp (yyt->RelBinPred.R);
yyt->RelBinPred.Next->PredList.DeclsIn=yyt->RelBinPred.DeclsIn;
yyVisit1PredList (yyt->RelBinPred.Next);
/* line 1568 "sum.cg" */

    yyt->RelBinPred.Type = Tyof_RelBinPred (yyt->RelBinPred.DeclsIn, yyt->RelBinPred.L, yyt->RelBinPred.R, yyt->RelBinPred.RelBinOp);
/* line 1326 "sum.cg" */

    yyt->RelBinPred.DeclsOut = yyt->RelBinPred.DeclsIn;
/* line 362 "sum.cg" */
yyt->RelBinPred.IsTypeExp = false;
} break;
case kAssign: {
/* line 1345 "sum.cg" */

    yyt->Assign.L->NameList.DeclsIn = yyt->Assign.DeclsIn;
yyVisit1NameList (yyt->Assign.L);
/* line 582 "sum.cg" */

    yyt->Assign.Pos = yyt->Assign.L->NameList.Pos;
/* line 1346 "sum.cg" */

    yyt->Assign.R->ExpressionList.DeclsIn = yyt->Assign.DeclsIn;
yyVisit1ExpressionList (yyt->Assign.R);
yyt->Assign.Next->PredList.DeclsIn=yyt->Assign.DeclsIn;
yyVisit1PredList (yyt->Assign.Next);
/* line 1572 "sum.cg" */

    yyt->Assign.Type = Tyof_Assign (yyt->Assign.DeclsIn, yyt->Assign.L, yyt->Assign.R);
/* line 1326 "sum.cg" */

    yyt->Assign.DeclsOut = yyt->Assign.DeclsIn;
/* line 362 "sum.cg" */
yyt->Assign.IsTypeExp = false;
} break;
case kRelPrePred: {
/* line 1350 "sum.cg" */

    yyt->RelPrePred.Exp->Exp.DeclsIn = yyt->RelPrePred.DeclsIn;
yyVisit1Exp (yyt->RelPrePred.Exp);
/* line 586 "sum.cg" */

    yyt->RelPrePred.Pos = yyt->RelPrePred.Exp->Exp.Pos;
yyt->RelPrePred.Next->PredList.DeclsIn=yyt->RelPrePred.DeclsIn;
yyVisit1PredList (yyt->RelPrePred.Next);
/* line 1576 "sum.cg" */

    yyt->RelPrePred.Type = Tyof_RelPrePred (yyt->RelPrePred.DeclsIn, yyt->RelPrePred.RelPreOp, yyt->RelPrePred.Exp);
/* line 1326 "sum.cg" */

    yyt->RelPrePred.DeclsOut = yyt->RelPrePred.DeclsIn;
/* line 362 "sum.cg" */
yyt->RelPrePred.IsTypeExp = false;
} break;
case kLogBinPred: {
/* line 1354 "sum.cg" */

    yyt->LogBinPred.L->Pred.DeclsIn = yyt->LogBinPred.DeclsIn;
yyVisit1Pred (yyt->LogBinPred.L);
/* line 590 "sum.cg" */

    yyt->LogBinPred.Pos = yyt->LogBinPred.L->Pred.Pos;
/* line 1355 "sum.cg" */

    yyt->LogBinPred.R->Pred.DeclsIn = yyt->LogBinPred.DeclsIn;
yyVisit1Pred (yyt->LogBinPred.R);
yyVisit1LogBinOp (yyt->LogBinPred.LogBinOp);
yyt->LogBinPred.Next->PredList.DeclsIn=yyt->LogBinPred.DeclsIn;
yyVisit1PredList (yyt->LogBinPred.Next);
/* line 1580 "sum.cg" */

    yyt->LogBinPred.Type = Tyof_LogBinPred (yyt->LogBinPred.L->Pred.Type, yyt->LogBinPred.R->Pred.Type, yyt->LogBinPred.L->Pred.Pos, yyt->LogBinPred.R->Pred.Pos);
/* line 1326 "sum.cg" */

    yyt->LogBinPred.DeclsOut = yyt->LogBinPred.DeclsIn;
/* line 362 "sum.cg" */
yyt->LogBinPred.IsTypeExp = false;
} break;
case kLogicalNot: {
/* line 1359 "sum.cg" */

    yyt->LogicalNot.Pred->Pred.DeclsIn = yyt->LogicalNot.DeclsIn;
yyVisit1Pred (yyt->LogicalNot.Pred);
/* line 594 "sum.cg" */

    yyt->LogicalNot.Pos = yyt->LogicalNot.Pred->Pred.Pos;
yyt->LogicalNot.Next->PredList.DeclsIn=yyt->LogicalNot.DeclsIn;
yyVisit1PredList (yyt->LogicalNot.Next);
/* line 1584 "sum.cg" */

    yyt->LogicalNot.Type = BoolTy;
/* line 1326 "sum.cg" */

    yyt->LogicalNot.DeclsOut = yyt->LogicalNot.DeclsIn;
/* line 362 "sum.cg" */
yyt->LogicalNot.IsTypeExp = false;
} break;
case kPreCondPred: {
/* line 1363 "sum.cg" */

    yyt->PreCondPred.Pred->Pred.DeclsIn = yyt->PreCondPred.DeclsIn;
yyVisit1Pred (yyt->PreCondPred.Pred);
/* line 598 "sum.cg" */

    yyt->PreCondPred.Pos = yyt->PreCondPred.Pred->Pred.Pos;
yyt->PreCondPred.Next->PredList.DeclsIn=yyt->PreCondPred.DeclsIn;
yyVisit1PredList (yyt->PreCondPred.Next);
/* line 1588 "sum.cg" */
 
    yyt->PreCondPred.Type = Tyof_PreCondPred (yyt->PreCondPred.Pred->Pred.Type, yyt->PreCondPred.Pred->Pred.Pos);
/* line 1326 "sum.cg" */

    yyt->PreCondPred.DeclsOut = yyt->PreCondPred.DeclsIn;
/* line 362 "sum.cg" */
yyt->PreCondPred.IsTypeExp = false;
} break;
case kIfPred: {
/* line 1367 "sum.cg" */

    yyt->IfPred.Con->Pred.DeclsIn = yyt->IfPred.DeclsIn;
yyVisit1Pred (yyt->IfPred.Con);
/* line 602 "sum.cg" */

    yyt->IfPred.Pos = yyt->IfPred.Con->Pred.Pos;
/* line 1369 "sum.cg" */

    yyt->IfPred.Else->Pred.DeclsIn = yyt->IfPred.DeclsIn;
yyVisit1Pred (yyt->IfPred.Else);
/* line 1368 "sum.cg" */

    yyt->IfPred.Then->Pred.DeclsIn = yyt->IfPred.DeclsIn;
yyVisit1Pred (yyt->IfPred.Then);
yyt->IfPred.Next->PredList.DeclsIn=yyt->IfPred.DeclsIn;
yyVisit1PredList (yyt->IfPred.Next);
/* line 1593 "sum.cg" */

    yyt->IfPred.Type = BoolTy;
/* line 1326 "sum.cg" */

    yyt->IfPred.DeclsOut = yyt->IfPred.DeclsIn;
/* line 362 "sum.cg" */
yyt->IfPred.IsTypeExp = false;
} break;
case kWhilePred: {
/* line 1373 "sum.cg" */

    yyt->WhilePred.Con->Pred.DeclsIn = yyt->WhilePred.DeclsIn;
yyVisit1Pred (yyt->WhilePred.Con);
/* line 606 "sum.cg" */

    yyt->WhilePred.Pos = yyt->WhilePred.Con->Pred.Pos;
/* line 1374 "sum.cg" */

    yyt->WhilePred.Do->Pred.DeclsIn = yyt->WhilePred.DeclsIn;
yyVisit1Pred (yyt->WhilePred.Do);
yyt->WhilePred.Next->PredList.DeclsIn=yyt->WhilePred.DeclsIn;
yyVisit1PredList (yyt->WhilePred.Next);
/* line 1597 "sum.cg" */

    yyt->WhilePred.Type = BoolTy;
/* line 1326 "sum.cg" */

    yyt->WhilePred.DeclsOut = yyt->WhilePred.DeclsIn;
/* line 362 "sum.cg" */
yyt->WhilePred.IsTypeExp = false;
} break;
case kCallPred: {
/* line 1378 "sum.cg" */

    yyt->CallPred.IdList->IdList.DeclsIn = yyt->CallPred.DeclsIn;
yyVisit1IdList (yyt->CallPred.IdList);
/* line 610 "sum.cg" */

    yyt->CallPred.Pos = yyt->CallPred.IdList->IdList.Pos;
/* line 1380 "sum.cg" */

    yyt->CallPred.OutputBindList->OutputBindList.DeclsIn = yyt->CallPred.DeclsIn;
yyVisit1OutputBindList (yyt->CallPred.OutputBindList);
/* line 1379 "sum.cg" */

    yyt->CallPred.InputBindList->InputBindList.DeclsIn = yyt->CallPred.DeclsIn;
yyVisit1InputBindList (yyt->CallPred.InputBindList);
yyt->CallPred.Next->PredList.DeclsIn=yyt->CallPred.DeclsIn;
yyVisit1PredList (yyt->CallPred.Next);
/* line 1601 "sum.cg" */

    yyt->CallPred.Type = BoolTy;
/* line 1326 "sum.cg" */

    yyt->CallPred.DeclsOut = yyt->CallPred.DeclsIn;
/* line 362 "sum.cg" */
yyt->CallPred.IsTypeExp = false;
} break;
case kChgOnly: {
/* line 1384 "sum.cg" */

    yyt->ChgOnly.NameList->NameList.DeclsIn = yyt->ChgOnly.DeclsIn;
yyVisit1NameList (yyt->ChgOnly.NameList);
/* line 614 "sum.cg" */

	yyt->ChgOnly.Pos = yyt->ChgOnly.NameList->NameList.Pos;
	yyt->ChgOnly.Pos.Column = yyt->ChgOnly.Pos.Column-13;
yyt->ChgOnly.Next->PredList.DeclsIn=yyt->ChgOnly.DeclsIn;
yyVisit1PredList (yyt->ChgOnly.Next);
/* line 1605 "sum.cg" */
 
    yyt->ChgOnly.Type = Tyof_ChgOnly (yyt->ChgOnly.DeclsIn, yyt->ChgOnly.NameList);
/* line 1326 "sum.cg" */

    yyt->ChgOnly.DeclsOut = yyt->ChgOnly.DeclsIn;
/* line 362 "sum.cg" */
yyt->ChgOnly.IsTypeExp = false;
} break;
case kDefined: {
/* line 359 "sum.cg" */
yyt->Defined.Pos = NoPosition;
yyt->Defined.Next->PredList.DeclsIn=yyt->Defined.DeclsIn;
yyVisit1PredList (yyt->Defined.Next);
yyt->Defined.Exp->Exp.DeclsIn=yyt->Defined.Next->PredList.DeclsOut;
yyVisit1Exp (yyt->Defined.Exp);
/* line 366 "sum.cg" */
yyt->Defined.Type = NoType;
/* line 1326 "sum.cg" */

    yyt->Defined.DeclsOut = yyt->Defined.DeclsIn;
/* line 362 "sum.cg" */
yyt->Defined.IsTypeExp = false;
} break;
case kSchemaPred: {
/* line 1388 "sum.cg" */

    yyt->SchemaPred.Schema->Schema.DeclsIn = yyt->SchemaPred.DeclsIn;
yyVisit1Schema (yyt->SchemaPred.Schema);
/* line 620 "sum.cg" */

    yyt->SchemaPred.Pos = yyt->SchemaPred.Schema->Schema.Pos;
yyt->SchemaPred.Next->PredList.DeclsIn=yyt->SchemaPred.DeclsIn;
yyVisit1PredList (yyt->SchemaPred.Next);
/* line 1613 "sum.cg" */

    yyt->SchemaPred.Type = yyt->SchemaPred.Schema->Schema.Type;
/* line 1326 "sum.cg" */

    yyt->SchemaPred.DeclsOut = yyt->SchemaPred.DeclsIn;
/* line 1614 "sum.cg" */

    yyt->SchemaPred.IsTypeExp = yyt->SchemaPred.Type->Tp_Exp.IsTypeExp;
} break;
case kBoolValue: {
/* line 359 "sum.cg" */
yyt->BoolValue.Pos = NoPosition;
yyt->BoolValue.Next->PredList.DeclsIn=yyt->BoolValue.DeclsIn;
yyVisit1PredList (yyt->BoolValue.Next);
/* line 1609 "sum.cg" */

    yyt->BoolValue.Type = BoolTy;
/* line 1326 "sum.cg" */

    yyt->BoolValue.DeclsOut = yyt->BoolValue.DeclsIn;
/* line 362 "sum.cg" */
yyt->BoolValue.IsTypeExp = false;
} break;
 default: ;
 }
}

static void yyVisit1InputBindList
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kInputBindList: {
yyt->InputBindList.DeclsOut=yyt->InputBindList.DeclsIn;
/* line 366 "sum.cg" */
yyt->InputBindList.Type = NoType;
} break;
case kNoInputBind: {
yyt->NoInputBind.DeclsOut=yyt->NoInputBind.DeclsIn;
/* line 366 "sum.cg" */
yyt->NoInputBind.Type = NoType;
} break;
case kInputBind: {
yyt->InputBind.Next->InputBindList.DeclsIn=yyt->InputBind.DeclsIn;
yyVisit1InputBindList (yyt->InputBind.Next);
yyt->InputBind.ExpressionList->ExpressionList.DeclsIn=yyt->InputBind.Next->InputBindList.DeclsOut;
yyVisit1ExpressionList (yyt->InputBind.ExpressionList);
yyt->InputBind.DeclsOut=yyt->InputBind.ExpressionList->ExpressionList.DeclsOut;
/* line 366 "sum.cg" */
yyt->InputBind.Type = NoType;
} break;
 default: ;
 }
}

static void yyVisit1OutputBindList
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kOutputBindList: {
yyt->OutputBindList.DeclsOut=yyt->OutputBindList.DeclsIn;
/* line 366 "sum.cg" */
yyt->OutputBindList.Type = NoType;
} break;
case kNoOutputBind: {
yyt->NoOutputBind.DeclsOut=yyt->NoOutputBind.DeclsIn;
/* line 366 "sum.cg" */
yyt->NoOutputBind.Type = NoType;
} break;
case kOutputBind: {
yyt->OutputBind.Next->OutputBindList.DeclsIn=yyt->OutputBind.DeclsIn;
yyVisit1OutputBindList (yyt->OutputBind.Next);
yyt->OutputBind.IdList->IdList.DeclsIn=yyt->OutputBind.Next->OutputBindList.DeclsOut;
yyVisit1IdList (yyt->OutputBind.IdList);
yyt->OutputBind.DeclsOut=yyt->OutputBind.IdList->IdList.DeclsOut;
/* line 366 "sum.cg" */
yyt->OutputBind.Type = NoType;
} break;
 default: ;
 }
}

static void yyVisit1LogBinOp
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kLogBinOp: {
} break;
case kLogSeq: {
} break;
case kLogAnd: {
} break;
case kLogExor: {
} break;
case kLogOr: {
} break;
case kLogImply: {
} break;
case kLogEquiv: {
} break;
 default: ;
 }
}

static void yyVisit1DeclList
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kDeclList: {
/* line 359 "sum.cg" */
yyt->DeclList.Pos = NoPosition;
/* line 366 "sum.cg" */
yyt->DeclList.Type = NoType;
yyt->DeclList.DeclsOut=yyt->DeclList.DeclsIn;
} break;
case kNoDecl: {
/* line 359 "sum.cg" */
yyt->NoDecl.Pos = NoPosition;
/* line 366 "sum.cg" */
yyt->NoDecl.Type = NoType;
yyt->NoDecl.DeclsOut=yyt->NoDecl.DeclsIn;
} break;
case kDecl: {
/* line 359 "sum.cg" */
yyt->Decl.Pos = NoPosition;
yyt->Decl.Next->DeclList.DeclsIn=yyt->Decl.DeclsIn;
yyVisit1DeclList (yyt->Decl.Next);
/* line 366 "sum.cg" */
yyt->Decl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Decl.DeclsOut = yyt->Decl.Next->DeclList.DeclsOut;
} break;
case kVarDecl: {
/* line 813 "sum.cg" */
 
    yyt->VarDecl.Exp->Exp.DeclsIn = yyt->VarDecl.DeclsIn;
yyVisit1Exp (yyt->VarDecl.Exp);
/* line 816 "sum.cg" */

        if (yyt->VarDecl.Exp->Exp.Type == NoType || yyt->VarDecl.Exp->Exp.Type->Kind == kTp_Err) 
            yyt->VarDecl.Next->DeclList.DeclsIn = yyt->VarDecl.DeclsIn;
        else if (yyt->VarDecl.Exp->Exp.IsTypeExp)
            yyt->VarDecl.Next->DeclList.DeclsIn = mObj_IdList (yyt->VarDecl.DeclsIn, yyt->VarDecl.Exp->Exp.Type, yyt->VarDecl.IdList, yyt->VarDecl.VarDeclKind, ModIdent); 
        else if (yyt->VarDecl.Exp->Exp.Type->Kind == kTp_Power)
            yyt->VarDecl.Next->DeclList.DeclsIn = mObj_IdList (yyt->VarDecl.DeclsIn, yyt->VarDecl.Exp->Exp.Type->Tp_Power.Tp_Exp, yyt->VarDecl.IdList, yyt->VarDecl.VarDeclKind, ModIdent); 
        else {
            Error (yyt->VarDecl.Exp->Exp.Pos, error32);
            yyt->VarDecl.Next->DeclList.DeclsIn = yyt->VarDecl.DeclsIn;
        }
    
yyVisit1DeclList (yyt->VarDecl.Next);
yyt->VarDecl.IdList->IdList.DeclsIn=yyt->VarDecl.Next->DeclList.DeclsOut;
yyVisit1IdList (yyt->VarDecl.IdList);
/* line 506 "sum.cg" */

    yyt->VarDecl.Pos = yyt->VarDecl.IdList->IdList.Pos;
/* line 366 "sum.cg" */
yyt->VarDecl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->VarDecl.DeclsOut = yyt->VarDecl.Next->DeclList.DeclsOut;
} break;
case kGivenSet: {
/* line 831 "sum.cg" */
 
    {
    tTree ptr = yyt->GivenSet.IdList; 
    tObjects declsin = yyt->GivenSet.DeclsIn;
    tObjects obj; 

    for (; ptr && ptr->Kind == kId; ptr = ptr->Id.Next) {
        if (IsDeclared (declsin, ptr->Id.Ident.Ident, NoType)) 
            Error (ptr->Id.Ident.Pos, error22);
        obj = mObj_TyId (NoSym, declsin, ModIdent, 
              mTp_Base (ModIdent, ptr->Id.Ident.Ident), ptr->Id.Ident.Ident, 1);

        if (declsin->Kind == kObj_Inn && !declsin->Obj_Inn.Inner) 
            declsin->Obj_Inn.Inner = obj;
        else
            declsin->Object.Next = obj;
        declsin = obj; 
    }
    yyt->GivenSet.Next->DeclList.DeclsIn = declsin; 
    }
  
yyVisit1DeclList (yyt->GivenSet.Next);
yyt->GivenSet.IdList->IdList.DeclsIn=yyt->GivenSet.Next->DeclList.DeclsOut;
yyVisit1IdList (yyt->GivenSet.IdList);
/* line 510 "sum.cg" */

    yyt->GivenSet.Pos = yyt->GivenSet.IdList->IdList.Pos;
/* line 366 "sum.cg" */
yyt->GivenSet.Type = NoType;
/* line 809 "sum.cg" */

    yyt->GivenSet.DeclsOut = yyt->GivenSet.Next->DeclList.DeclsOut;
} break;
case kAxiomDecl: {
/* line 864 "sum.cg" */

    { tTree tr=yyt->AxiomDecl.FormalParams;
        for (; tr && tr->Kind != kNoParam; tr = tr->Param.Next)
            if (tr->Kind == kTyParam)
                tr->TyParam.IsPolyTy = true;
        yyt->AxiomDecl.FormalParams->FormalParams.DeclsIn = mObj_Tmp (NoSym, yyt->AxiomDecl.DeclsIn, ModIdent, NoType, NoIdent, 0, NoSym);
       };
    
yyVisit1FormalParams (yyt->AxiomDecl.FormalParams);
/* line 514 "sum.cg" */

    yyt->AxiomDecl.Pos = yyt->AxiomDecl.FormalParams->FormalParams.Pos;
/* line 872 "sum.cg" */


	SetLocalGenParameters(yyt->AxiomDecl.FormalParams->FormalParams.DeclsIn);
	yyt->AxiomDecl.DeclList->DeclList.DeclsIn = yyt->AxiomDecl.FormalParams->FormalParams.DeclsOut;
yyVisit1DeclList (yyt->AxiomDecl.DeclList);
yyt->AxiomDecl.PredList->PredList.DeclsIn=yyt->AxiomDecl.DeclList->DeclList.DeclsOut;
yyVisit1PredList (yyt->AxiomDecl.PredList);
/* line 876 "sum.cg" */

    { tObjects sym=yyt->AxiomDecl.FormalParams->FormalParams.DeclsIn->Obj_Tmp.Inner;

        for (; sym && sym->Kind == kObj_PTyId; sym=sym->Object.Next) {
           };
        if (sym && sym->Kind != kNoObject) {
            sym->Object.Pre = yyt->AxiomDecl.DeclsIn;
            if (yyt->AxiomDecl.DeclsIn->Kind == kObj_Inn && !yyt->AxiomDecl.DeclsIn->Obj_Inn.Inner)
                yyt->AxiomDecl.DeclsIn->Obj_Inn.Inner = sym;
            else
                yyt->AxiomDecl.DeclsIn->Object.Next = sym;
            for (; sym && sym->Kind != kNoObject && 
                sym->Object.Next && (sym->Object.Next)->Kind != kNoObject; sym=sym->Object.Next)
                ;
            yyt->AxiomDecl.Next->DeclList.DeclsIn = sym;
        }
        else
            yyt->AxiomDecl.Next->DeclList.DeclsIn = yyt->AxiomDecl.DeclsIn;
    };
		CkPredListAIEnv (yyt->AxiomDecl.PredList);

		ResetLocalGenParamPtr();
    
yyVisit1DeclList (yyt->AxiomDecl.Next);
/* line 1418 "sum.cg" */
if (! ( PredIsBool(yyt->AxiomDecl.PredList) )) { Error(NonBoolPredPos(yyt->AxiomDecl.PredList),error33); }
/* line 366 "sum.cg" */
yyt->AxiomDecl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->AxiomDecl.DeclsOut = yyt->AxiomDecl.Next->DeclList.DeclsOut;
} break;
case kSchemaDef: {
/* line 518 "sum.cg" */

    yyt->SchemaDef.Pos = yyt->SchemaDef.Ident.Pos;
/* line 915 "sum.cg" */

        {
        tObjects obj = NoSym;
        if (IsDeclared (yyt->SchemaDef.DeclsIn, yyt->SchemaDef.Ident.Ident, NoType))
            Error (yyt->SchemaDef.Ident.Pos, error22); 
        obj = mObj_Inn (NoSym, yyt->SchemaDef.DeclsIn, ModIdent, NoType, yyt->SchemaDef.Ident.Ident, 1, NoSym, Obj_schema, false);
        if (yyt->SchemaDef.DeclsIn->Kind == kObj_Inn && !yyt->SchemaDef.DeclsIn->Obj_Inn.Inner)
            yyt->SchemaDef.DeclsIn->Obj_Inn.Inner = obj;
        else
            yyt->SchemaDef.DeclsIn->Object.Next = obj;
        yyt->SchemaDef.FormalParams->FormalParams.DeclsIn = obj;
        };
    
yyVisit1FormalParams (yyt->SchemaDef.FormalParams);
/* line 928 "sum.cg" */


	SetLocalGenParameters(yyt->SchemaDef.FormalParams->FormalParams.DeclsIn);
        if (yyt->SchemaDef.IsOp) {
	    bool HasState=false;

            if (yyt->SchemaDef.Ident.Ident == Ident_init)
                yyt->SchemaDef.DeclList->DeclList.DeclsIn = StateIncl (yyt->SchemaDef.FormalParams->FormalParams.DeclsOut, 2, &HasState);
            else
                yyt->SchemaDef.DeclList->DeclList.DeclsIn = StateIncl (yyt->SchemaDef.FormalParams->FormalParams.DeclsOut, 3, &HasState);
        }
        else
            yyt->SchemaDef.DeclList->DeclList.DeclsIn = yyt->SchemaDef.FormalParams->FormalParams.DeclsOut;
    
yyVisit1DeclList (yyt->SchemaDef.DeclList);
/* line 942 "sum.cg" */

        if (yyt->SchemaDef.DeclList->DeclList.DeclsOut == yyt->SchemaDef.FormalParams->FormalParams.DeclsIn)
            yyt->SchemaDef.FormalParams->FormalParams.DeclsIn->Obj_Inn.Inner = nnNoObj;
        yyt->SchemaDef.FormalParams->FormalParams.DeclsIn->Object.Type = FormTp_Schema(yyt->SchemaDef.FormalParams->FormalParams.DeclsIn->Obj_Inn.Inner, ModIdent); 
        yyt->SchemaDef.PredList->PredList.DeclsIn = yyt->SchemaDef.DeclList->DeclList.DeclsOut;
    
yyVisit1PredList (yyt->SchemaDef.PredList);
/* line 954 "sum.cg" */

		yyt->SchemaDef.Next->DeclList.DeclsIn = yyt->SchemaDef.FormalParams->FormalParams.DeclsIn;
		CkPredListAIEnv (yyt->SchemaDef.PredList);

		ResetLocalGenParamPtr();
	
yyVisit1DeclList (yyt->SchemaDef.Next);
/* line 375 "sum.cg" */
yyt->SchemaDef.HasStateIncl=false;
/* line 1420 "sum.cg" */
if (! ( PredIsBool(yyt->SchemaDef.PredList) )) { Error(NonBoolPredPos(yyt->SchemaDef.PredList),error33); }
/* line 366 "sum.cg" */
yyt->SchemaDef.Type = NoType;
/* line 809 "sum.cg" */

    yyt->SchemaDef.DeclsOut = yyt->SchemaDef.Next->DeclList.DeclsOut;
} break;
case kAnnotation: {
yyt->Annotation.Next->DeclList.DeclsIn=yyt->Annotation.DeclsIn;
yyVisit1DeclList (yyt->Annotation.Next);
yyt->Annotation.Decl->Decl.DeclsIn=yyt->Annotation.Next->DeclList.DeclsOut;
yyVisit1Decl (yyt->Annotation.Decl);
/* line 522 "sum.cg" */

    yyt->Annotation.Pos = yyt->Annotation.Decl->Decl.Pos;
/* line 366 "sum.cg" */
yyt->Annotation.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Annotation.DeclsOut = yyt->Annotation.Next->DeclList.DeclsOut;
} break;
case kErgoAnno: {
/* line 526 "sum.cg" */

    yyt->ErgoAnno.Pos = yyt->ErgoAnno.Ident.Pos;
/* line 1313 "sum.cg" */

	yyt->ErgoAnno.Next->DeclList.DeclsIn = yyt->ErgoAnno.DeclsIn;
yyVisit1DeclList (yyt->ErgoAnno.Next);
/* line 366 "sum.cg" */
yyt->ErgoAnno.Type = NoType;
/* line 809 "sum.cg" */

    yyt->ErgoAnno.DeclsOut = yyt->ErgoAnno.Next->DeclList.DeclsOut;
} break;
case kStateMachine: {
/* line 1317 "sum.cg" */

	yyt->StateMachine.Next->DeclList.DeclsIn = yyt->StateMachine.DeclsIn;
yyVisit1DeclList (yyt->StateMachine.Next);
yyt->StateMachine.IdList->IdList.DeclsIn=yyt->StateMachine.Next->DeclList.DeclsOut;
yyVisit1IdList (yyt->StateMachine.IdList);
/* line 530 "sum.cg" */

    yyt->StateMachine.Pos = yyt->StateMachine.IdList->IdList.Pos;
/* line 366 "sum.cg" */
yyt->StateMachine.Type = NoType;
/* line 809 "sum.cg" */

    yyt->StateMachine.DeclsOut = yyt->StateMachine.Next->DeclList.DeclsOut;
} break;
case kAbbreviation: {
/* line 535 "sum.cg" */

    yyt->Abbreviation.Pos = yyt->Abbreviation.Ident.Pos;
/* line 977 "sum.cg" */
 
    yyt->Abbreviation.Exp->Exp.DeclsIn = yyt->Abbreviation.DeclsIn;
yyVisit1Exp (yyt->Abbreviation.Exp);
/* line 978 "sum.cg" */

        if (IsDeclared (yyt->Abbreviation.DeclsIn, yyt->Abbreviation.Ident.Ident, NoType)) 
            Error (yyt->Abbreviation.Ident.Pos, error22); 
        if (yyt->Abbreviation.Exp->Exp.IsTypeExp) 
            yyt->Abbreviation.Next->DeclList.DeclsIn = mObj_TyId (NoSym, yyt->Abbreviation.DeclsIn, ModIdent, yyt->Abbreviation.Exp->Exp.Type, yyt->Abbreviation.Ident.Ident, 1);
        else 
            yyt->Abbreviation.Next->DeclList.DeclsIn = mObj_Id (NoSym, yyt->Abbreviation.DeclsIn, ModIdent, yyt->Abbreviation.Exp->Exp.Type, yyt->Abbreviation.Ident.Ident, 1, NoIdent, 0);
    
yyVisit1DeclList (yyt->Abbreviation.Next);

        if (yyt->Abbreviation.DeclsIn->Kind == kObj_Inn && !yyt->Abbreviation.DeclsIn->Obj_Inn.Inner)
            yyt->Abbreviation.DeclsIn->Obj_Inn.Inner = yyt->Abbreviation.Next->DeclList.DeclsIn;
        else
            yyt->Abbreviation.DeclsIn->Object.Next = yyt->Abbreviation.Next->DeclList.DeclsIn;
    ;
/* line 366 "sum.cg" */
yyt->Abbreviation.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Abbreviation.DeclsOut = yyt->Abbreviation.Next->DeclList.DeclsOut;
} break;
case kFunctionDecl: {
/* line 903 "sum.cg" */

    yyt->FunctionDecl.DeclList->DeclList.DeclsIn = yyt->FunctionDecl.DeclsIn;
yyVisit1DeclList (yyt->FunctionDecl.DeclList);
/* line 539 "sum.cg" */

    yyt->FunctionDecl.Pos = yyt->FunctionDecl.DeclList->DeclList.Pos;
/* line 904 "sum.cg" */

    yyt->FunctionDecl.PredList->PredList.DeclsIn = yyt->FunctionDecl.DeclList->DeclList.DeclsOut;
yyVisit1PredList (yyt->FunctionDecl.PredList);
/* line 905 "sum.cg" */

                yyt->FunctionDecl.Next->DeclList.DeclsIn = yyt->FunctionDecl.DeclList->DeclList.DeclsOut;
		CkPredListAIEnv (yyt->FunctionDecl.PredList);
    
yyVisit1DeclList (yyt->FunctionDecl.Next);
/* line 1423 "sum.cg" */
if (! ( PredIsBool(yyt->FunctionDecl.PredList) )) { Error(NonBoolPredPos(yyt->FunctionDecl.PredList),error33); }
/* line 366 "sum.cg" */
yyt->FunctionDecl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->FunctionDecl.DeclsOut = yyt->FunctionDecl.Next->DeclList.DeclsOut;
} break;
case kFreeType: {
/* line 543 "sum.cg" */

    yyt->FreeType.Pos = yyt->FreeType.Ident.Pos;
/* line 1003 "sum.cg" */

        if (IsDeclared (yyt->FreeType.DeclsIn, yyt->FreeType.Ident.Ident, NoType)) 
            Error (yyt->FreeType.Ident.Pos, error22);   
        yyt->FreeType.BranchList->BranchList.DeclsIn = mObj_TyId (NoSym, yyt->FreeType.DeclsIn, ModIdent, 
            mTp_Base (ModIdent, yyt->FreeType.Ident.Ident), yyt->FreeType.Ident.Ident, 1);
        if (yyt->FreeType.DeclsIn->Kind == kObj_Inn && !yyt->FreeType.DeclsIn->Obj_Inn.Inner)
            yyt->FreeType.DeclsIn->Obj_Inn.Inner = yyt->FreeType.BranchList->BranchList.DeclsIn;
        else
            yyt->FreeType.DeclsIn->Object.Next = yyt->FreeType.BranchList->BranchList.DeclsIn;
    
yyVisit1BranchList (yyt->FreeType.BranchList);
/* line 1014 "sum.cg" */

    
    yyt->FreeType.Next->DeclList.DeclsIn = yyt->FreeType.BranchList->BranchList.DeclsOut;
yyVisit1DeclList (yyt->FreeType.Next);
/* line 373 "sum.cg" */
yyt->FreeType.ModId=ModIdent;
/* line 366 "sum.cg" */
yyt->FreeType.Type = NoType;
/* line 809 "sum.cg" */

    yyt->FreeType.DeclsOut = yyt->FreeType.Next->DeclList.DeclsOut;
} break;
case kEnum: {
/* line 547 "sum.cg" */

    yyt->Enum.Pos = yyt->Enum.Ident.Pos;
/* line 1026 "sum.cg" */

        if (IsDeclared (yyt->Enum.DeclsIn, yyt->Enum.Ident.Ident, NoType)) 
            Error (yyt->Enum.Ident.Pos, error22);   
        yyt->Enum.BranchList->BranchList.DeclsIn = mObj_TyId (NoSym, yyt->Enum.DeclsIn, ModIdent, 
            mTp_Base (ModIdent, yyt->Enum.Ident.Ident), yyt->Enum.Ident.Ident, 1);

        
        if (yyt->Enum.DeclsIn->Kind == kObj_Inn && !yyt->Enum.DeclsIn->Obj_Inn.Inner)
            yyt->Enum.DeclsIn->Obj_Inn.Inner = yyt->Enum.BranchList->BranchList.DeclsIn;
        else
            yyt->Enum.DeclsIn->Object.Next = yyt->Enum.BranchList->BranchList.DeclsIn;
    
yyVisit1BranchList (yyt->Enum.BranchList);
/* line 1044 "sum.cg" */

        {
                char enumstr[IDENT_LENGTH];
		char *mathpath="MATHPATH";
		char mathpathstr[256];  
                tIdent EnumIdent;
                tIdPos EnumIdentPos;
                tIdPos EnumMod;
                IML_List iml = NULL;
                tObjects fmlparams;
		tObjects sym;
		tType basetp;
                

                
                
                
                
                
                

                enumstr[0] = '\0';
                GetString(yyt->Enum.Ident.Ident, enumstr);
                strcat(enumstr, "_Enum");
                EnumIdent = MakeIdent(enumstr, strlen(enumstr));
		if ((sym = LookUp(yyt->Enum.BranchList->BranchList.DeclsOut ,yyt->Enum.Ident.Ident, NoSym)) 
                          == NoSym)
                      Error(yyt->Enum.Ident.Pos, error31);
                else if (sym->Kind != kObj_TyId) 
             	       Error(yyt->Enum.Ident.Pos, error31);
		else
		       basetp = sym->Object.Type; 
                
		yyt->Enum.Next->DeclList.DeclsIn = mObj_Inn (NoSym, yyt->Enum.BranchList->BranchList.DeclsOut, ModIdent, 
                        NoType, EnumIdent, 1, NoSym, Obj_import, 1); 
                
                

                if (yyt->Enum.BranchList->BranchList.DeclsOut->Kind == kObj_Inn && !yyt->Enum.BranchList->BranchList.DeclsOut->Obj_Inn.Inner)
                      yyt->Enum.BranchList->BranchList.DeclsOut->Obj_Inn.Inner = yyt->Enum.Next->DeclList.DeclsIn;
                else
                      yyt->Enum.BranchList->BranchList.DeclsOut->Object.Next = yyt->Enum.Next->DeclList.DeclsIn;


                strcpy(mathpathstr,getenv(mathpath));
		strcat(mathpathstr,"/adaenum");
		EnumMod.Ident = MakeIdent(mathpathstr, strlen(mathpathstr));
                EnumMod.Pos = yyt->Enum.Ident.Pos;

                yyt->Enum.Next->DeclList.DeclsIn->Obj_Inn.Inner= ReadModule(EnumMod,&iml,EnumIdent);

                
                if (yyt->Enum.Next->DeclList.DeclsIn->Obj_Inn.Inner->Kind != kNoObject)
                    yyt->Enum.Next->DeclList.DeclsIn->Obj_Inn.Inner->Object.Pre = yyt->Enum.Next->DeclList.DeclsIn;

                fmlparams = yyt->Enum.Next->DeclList.DeclsIn->Obj_Inn.Inner;
                
                *(fmlparams->Object.Type) = *(basetp);
                fmlparams->Object.Type->Tp_Exp.PtrToCopy = basetp;
                   

                EnumIdentPos.Ident = EnumIdent;
                EnumIdentPos.Pos = yyt->Enum.Ident.Pos;
                VisibleH (yyt->Enum.Next->DeclList.DeclsIn, EnumIdentPos, mNoSelection()); 
        } 
    
yyVisit1DeclList (yyt->Enum.Next);
/* line 373 "sum.cg" */
yyt->Enum.ModId=ModIdent;
/* line 366 "sum.cg" */
yyt->Enum.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Enum.DeclsOut = yyt->Enum.Next->DeclList.DeclsOut;
} break;
case kImport: {
/* line 551 "sum.cg" */

    yyt->Import.Pos = yyt->Import.Ident.Pos;
/* line 1296 "sum.cg" */

    yyt->Import.ExpressionList->ExpressionList.DeclsIn = yyt->Import.DeclsIn;
yyVisit1ExpressionList (yyt->Import.ExpressionList);
yyt->Import.RenameList->RenameList.DeclsIn=yyt->Import.ExpressionList->ExpressionList.DeclsOut;
yyVisit1RenameList (yyt->Import.RenameList);
/* line 378 "sum.cg" */
yyt->Import.FmlParams=NoSyms;
/* line 377 "sum.cg" */
yyt->Import.ModIMLlist=NULL;
/* line 1176 "sum.cg" */

        if (IsDeclared (yyt->Import.DeclsIn, yyt->Import.NewIdent.Ident, NoType))
            Error (yyt->Import.NewIdent.Pos, error22);
        yyt->Import.Next->DeclList.DeclsIn = mObj_Inn (NoSym, yyt->Import.DeclsIn, ModIdent, 
                        NoType, yyt->Import.NewIdent.Ident, 1, NoSym, Obj_import, false); 
        if (yyt->Import.DeclsIn->Kind == kObj_Inn && !yyt->Import.DeclsIn->Obj_Inn.Inner)
            yyt->Import.DeclsIn->Obj_Inn.Inner = yyt->Import.Next->DeclList.DeclsIn;
        else
            yyt->Import.DeclsIn->Object.Next = yyt->Import.Next->DeclList.DeclsIn;

	if (yyt->Import.Ident.Ident != yyt->Import.NewIdent.Ident) { 
                
		yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.ImportHasAsPart = true;
		if (cur_mod_imllist==NULL) {
			cur_mod_imllist = (IML_List) 
                                 my_malloc (sizeof (struct IMLstruct));
			cur_mod_imllist_hd = cur_mod_imllist;
		}
		else {
			cur_mod_imllist->next = (IML_List) 
                                 my_malloc (sizeof (struct IMLstruct));
			cur_mod_imllist = cur_mod_imllist->next;
		}
		if (yyt->Import.ExpressionList->Kind != kNoExp) {
			cur_mod_imllist->subthyid[0] = '\0';
			GetString (yyt->Import.NewIdent.Ident, cur_mod_imllist->subthyid);
			strcat (cur_mod_imllist->subthyid, "#Param");
			cur_mod_imllist->ParentModId = ModIdent;
			cur_mod_imllist->next = (IML_List) 
                                 my_malloc (sizeof (struct IMLstruct));
			cur_mod_imllist = cur_mod_imllist->next;
		}
		cur_mod_imllist->subthyid[0] = '\0';
		GetString (yyt->Import.NewIdent.Ident, cur_mod_imllist->subthyid);

		cur_mod_imllist->ParentModId = ModIdent;
		cur_mod_imllist->next = NULL;
	}
        {
		IML_List iml=NULL;
		tObjects sym, fmlparams;

                
    
                sym = LookUp(yyt->Import.DeclsIn, yyt->Import.Ident.Ident, NoSym);
                if (sym != NoSym) {
                  
                   yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner=InstMod(sym->Obj_Inn.Inner, yyt->Import.NewIdent.Ident);
                       
                
                
                }
                else {
                
                

                if (yyt->Import.Ident.Ident == yyt->Import.NewIdent.Ident)
	         yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner= ReadModule(yyt->Import.Ident,&iml,NoIdent);
                else 
	         yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner= ReadModule(yyt->Import.Ident,&iml,yyt->Import.NewIdent.Ident);               
                

                }

                

                if (yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner->Kind != kNoObject) {
                   yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner->Object.Pre = yyt->Import.Next->DeclList.DeclsIn;
		   ImportHandler (yyt->Import.Next->DeclList.DeclsIn, yyt->Import.ExpressionList, &fmlparams);

                 
               
                }
		yyt->Import.ModIMLlist = iml;
		yyt->Import.FmlParams = fmlparams;
		for (; iml != NULL; iml=iml->next) {
			if (cur_mod_imllist==NULL) {
				cur_mod_imllist = (IML_List) 
					my_malloc (sizeof (struct IMLstruct));
				cur_mod_imllist_hd = cur_mod_imllist;
			}
			else {
				cur_mod_imllist->next = (IML_List)
					my_malloc (sizeof (struct IMLstruct));
				cur_mod_imllist = cur_mod_imllist->next;
			}
			cur_mod_imllist->subthyid[0] = '\0';
			if (yyt->Import.Ident.Ident != yyt->Import.NewIdent.Ident) {
			      GetString (yyt->Import.NewIdent.Ident, 
                                        cur_mod_imllist->subthyid);
			      strcat (cur_mod_imllist->subthyid, "_");
			      strcat (cur_mod_imllist->subthyid, iml->subthyid);
			      cur_mod_imllist->ParentModId = ModIdent;
			}
			else {
			      strcat (cur_mod_imllist->subthyid, iml->subthyid);
			      cur_mod_imllist->ParentModId = iml->ParentModId;
			}
			cur_mod_imllist->next = NULL;

		}
	}
        RenameHandler (yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner, yyt->Import.RenameList);
    
yyVisit1DeclList (yyt->Import.Next);
/* line 366 "sum.cg" */
yyt->Import.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Import.DeclsOut = yyt->Import.Next->DeclList.DeclsOut;
} break;
case kModuleDecl: {
/* line 1301 "sum.cg" */

    yyt->ModuleDecl.Module->Module.DeclsIn = yyt->ModuleDecl.DeclsIn;
yyVisit1Module (yyt->ModuleDecl.Module);
/* line 555 "sum.cg" */

    yyt->ModuleDecl.Pos = yyt->ModuleDecl.Module->Module.Pos;
/* line 1302 "sum.cg" */

    yyt->ModuleDecl.Next->DeclList.DeclsIn = yyt->ModuleDecl.Module->Module.DeclsOut;
yyVisit1DeclList (yyt->ModuleDecl.Next);
/* line 366 "sum.cg" */
yyt->ModuleDecl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->ModuleDecl.DeclsOut = yyt->ModuleDecl.Next->DeclList.DeclsOut;
} break;
case kConstraint: {
/* line 1321 "sum.cg" */

    yyt->Constraint.Pred->Pred.DeclsIn = yyt->Constraint.DeclsIn;
yyVisit1Pred (yyt->Constraint.Pred);
/* line 559 "sum.cg" */

    yyt->Constraint.Pos = yyt->Constraint.Pred->Pred.Pos;
yyt->Constraint.Next->DeclList.DeclsIn=yyt->Constraint.DeclsIn;
yyVisit1DeclList (yyt->Constraint.Next);
/* line 366 "sum.cg" */
yyt->Constraint.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Constraint.DeclsOut = yyt->Constraint.Next->DeclList.DeclsOut;
} break;
case kSchemaIncl: {
/* line 373 "sum.cg" */
yyt->SchemaIncl.ModId=ModIdent;
/* line 963 "sum.cg" */
 
    yyt->SchemaIncl.ExpressionList->ExpressionList.DeclsIn = yyt->SchemaIncl.DeclsIn;
yyVisit1ExpressionList (yyt->SchemaIncl.ExpressionList);
/* line 965 "sum.cg" */

	{
		tIdent modid;

		yyt->SchemaIncl.Next->DeclList.DeclsIn = SchemaInclH (yyt->SchemaIncl.DeclsIn, yyt->SchemaIncl.IdList, yyt->SchemaIncl.ExpressionList, &modid);
		yyt->SchemaIncl.ModId = modid;
	}
	
yyVisit1DeclList (yyt->SchemaIncl.Next);
yyt->SchemaIncl.IdList->IdList.DeclsIn=yyt->SchemaIncl.Next->DeclList.DeclsOut;
yyVisit1IdList (yyt->SchemaIncl.IdList);
/* line 563 "sum.cg" */

    yyt->SchemaIncl.Pos = yyt->SchemaIncl.IdList->IdList.Pos;
/* line 366 "sum.cg" */
yyt->SchemaIncl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->SchemaIncl.DeclsOut = yyt->SchemaIncl.Next->DeclList.DeclsOut;
} break;
case kVisibility: {
/* line 359 "sum.cg" */
yyt->Visibility.Pos = NoPosition;
yyVisit1SelectionList (yyt->Visibility.SelectionList);
/* line 1306 "sum.cg" */

        VisibleH (yyt->Visibility.DeclsIn, yyt->Visibility.Ident, yyt->Visibility.SelectionList);
        yyt->Visibility.Next->DeclList.DeclsIn = yyt->Visibility.DeclsIn;
    
yyVisit1DeclList (yyt->Visibility.Next);
/* line 366 "sum.cg" */
yyt->Visibility.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Visibility.DeclsOut = yyt->Visibility.Next->DeclList.DeclsOut;
} break;
 default: ;
 }
}

static void yyVisit1Decl
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kDecl: {
/* line 359 "sum.cg" */
yyt->Decl.Pos = NoPosition;
yyt->Decl.Next->DeclList.DeclsIn=yyt->Decl.DeclsIn;
yyVisit1DeclList (yyt->Decl.Next);
/* line 366 "sum.cg" */
yyt->Decl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Decl.DeclsOut = yyt->Decl.Next->DeclList.DeclsOut;
} break;
case kVarDecl: {
/* line 813 "sum.cg" */
 
    yyt->VarDecl.Exp->Exp.DeclsIn = yyt->VarDecl.DeclsIn;
yyVisit1Exp (yyt->VarDecl.Exp);
/* line 816 "sum.cg" */

        if (yyt->VarDecl.Exp->Exp.Type == NoType || yyt->VarDecl.Exp->Exp.Type->Kind == kTp_Err) 
            yyt->VarDecl.Next->DeclList.DeclsIn = yyt->VarDecl.DeclsIn;
        else if (yyt->VarDecl.Exp->Exp.IsTypeExp)
            yyt->VarDecl.Next->DeclList.DeclsIn = mObj_IdList (yyt->VarDecl.DeclsIn, yyt->VarDecl.Exp->Exp.Type, yyt->VarDecl.IdList, yyt->VarDecl.VarDeclKind, ModIdent); 
        else if (yyt->VarDecl.Exp->Exp.Type->Kind == kTp_Power)
            yyt->VarDecl.Next->DeclList.DeclsIn = mObj_IdList (yyt->VarDecl.DeclsIn, yyt->VarDecl.Exp->Exp.Type->Tp_Power.Tp_Exp, yyt->VarDecl.IdList, yyt->VarDecl.VarDeclKind, ModIdent); 
        else {
            Error (yyt->VarDecl.Exp->Exp.Pos, error32);
            yyt->VarDecl.Next->DeclList.DeclsIn = yyt->VarDecl.DeclsIn;
        }
    
yyVisit1DeclList (yyt->VarDecl.Next);
yyt->VarDecl.IdList->IdList.DeclsIn=yyt->VarDecl.Next->DeclList.DeclsOut;
yyVisit1IdList (yyt->VarDecl.IdList);
/* line 506 "sum.cg" */

    yyt->VarDecl.Pos = yyt->VarDecl.IdList->IdList.Pos;
/* line 366 "sum.cg" */
yyt->VarDecl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->VarDecl.DeclsOut = yyt->VarDecl.Next->DeclList.DeclsOut;
} break;
case kGivenSet: {
/* line 831 "sum.cg" */
 
    {
    tTree ptr = yyt->GivenSet.IdList; 
    tObjects declsin = yyt->GivenSet.DeclsIn;
    tObjects obj; 

    for (; ptr && ptr->Kind == kId; ptr = ptr->Id.Next) {
        if (IsDeclared (declsin, ptr->Id.Ident.Ident, NoType)) 
            Error (ptr->Id.Ident.Pos, error22);
        obj = mObj_TyId (NoSym, declsin, ModIdent, 
              mTp_Base (ModIdent, ptr->Id.Ident.Ident), ptr->Id.Ident.Ident, 1);

        if (declsin->Kind == kObj_Inn && !declsin->Obj_Inn.Inner) 
            declsin->Obj_Inn.Inner = obj;
        else
            declsin->Object.Next = obj;
        declsin = obj; 
    }
    yyt->GivenSet.Next->DeclList.DeclsIn = declsin; 
    }
  
yyVisit1DeclList (yyt->GivenSet.Next);
yyt->GivenSet.IdList->IdList.DeclsIn=yyt->GivenSet.Next->DeclList.DeclsOut;
yyVisit1IdList (yyt->GivenSet.IdList);
/* line 510 "sum.cg" */

    yyt->GivenSet.Pos = yyt->GivenSet.IdList->IdList.Pos;
/* line 366 "sum.cg" */
yyt->GivenSet.Type = NoType;
/* line 809 "sum.cg" */

    yyt->GivenSet.DeclsOut = yyt->GivenSet.Next->DeclList.DeclsOut;
} break;
case kAxiomDecl: {
/* line 864 "sum.cg" */

    { tTree tr=yyt->AxiomDecl.FormalParams;
        for (; tr && tr->Kind != kNoParam; tr = tr->Param.Next)
            if (tr->Kind == kTyParam)
                tr->TyParam.IsPolyTy = true;
        yyt->AxiomDecl.FormalParams->FormalParams.DeclsIn = mObj_Tmp (NoSym, yyt->AxiomDecl.DeclsIn, ModIdent, NoType, NoIdent, 0, NoSym);
       };
    
yyVisit1FormalParams (yyt->AxiomDecl.FormalParams);
/* line 514 "sum.cg" */

    yyt->AxiomDecl.Pos = yyt->AxiomDecl.FormalParams->FormalParams.Pos;
/* line 872 "sum.cg" */


	SetLocalGenParameters(yyt->AxiomDecl.FormalParams->FormalParams.DeclsIn);
	yyt->AxiomDecl.DeclList->DeclList.DeclsIn = yyt->AxiomDecl.FormalParams->FormalParams.DeclsOut;
yyVisit1DeclList (yyt->AxiomDecl.DeclList);
yyt->AxiomDecl.PredList->PredList.DeclsIn=yyt->AxiomDecl.DeclList->DeclList.DeclsOut;
yyVisit1PredList (yyt->AxiomDecl.PredList);
/* line 876 "sum.cg" */

    { tObjects sym=yyt->AxiomDecl.FormalParams->FormalParams.DeclsIn->Obj_Tmp.Inner;

        for (; sym && sym->Kind == kObj_PTyId; sym=sym->Object.Next) {
           };
        if (sym && sym->Kind != kNoObject) {
            sym->Object.Pre = yyt->AxiomDecl.DeclsIn;
            if (yyt->AxiomDecl.DeclsIn->Kind == kObj_Inn && !yyt->AxiomDecl.DeclsIn->Obj_Inn.Inner)
                yyt->AxiomDecl.DeclsIn->Obj_Inn.Inner = sym;
            else
                yyt->AxiomDecl.DeclsIn->Object.Next = sym;
            for (; sym && sym->Kind != kNoObject && 
                sym->Object.Next && (sym->Object.Next)->Kind != kNoObject; sym=sym->Object.Next)
                ;
            yyt->AxiomDecl.Next->DeclList.DeclsIn = sym;
        }
        else
            yyt->AxiomDecl.Next->DeclList.DeclsIn = yyt->AxiomDecl.DeclsIn;
    };
		CkPredListAIEnv (yyt->AxiomDecl.PredList);

		ResetLocalGenParamPtr();
    
yyVisit1DeclList (yyt->AxiomDecl.Next);
/* line 1418 "sum.cg" */
if (! ( PredIsBool(yyt->AxiomDecl.PredList) )) { Error(NonBoolPredPos(yyt->AxiomDecl.PredList),error33); }
/* line 366 "sum.cg" */
yyt->AxiomDecl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->AxiomDecl.DeclsOut = yyt->AxiomDecl.Next->DeclList.DeclsOut;
} break;
case kSchemaDef: {
/* line 518 "sum.cg" */

    yyt->SchemaDef.Pos = yyt->SchemaDef.Ident.Pos;
/* line 915 "sum.cg" */

        {
        tObjects obj = NoSym;
        if (IsDeclared (yyt->SchemaDef.DeclsIn, yyt->SchemaDef.Ident.Ident, NoType))
            Error (yyt->SchemaDef.Ident.Pos, error22); 
        obj = mObj_Inn (NoSym, yyt->SchemaDef.DeclsIn, ModIdent, NoType, yyt->SchemaDef.Ident.Ident, 1, NoSym, Obj_schema, false);
        if (yyt->SchemaDef.DeclsIn->Kind == kObj_Inn && !yyt->SchemaDef.DeclsIn->Obj_Inn.Inner)
            yyt->SchemaDef.DeclsIn->Obj_Inn.Inner = obj;
        else
            yyt->SchemaDef.DeclsIn->Object.Next = obj;
        yyt->SchemaDef.FormalParams->FormalParams.DeclsIn = obj;
        };
    
yyVisit1FormalParams (yyt->SchemaDef.FormalParams);
/* line 928 "sum.cg" */


	SetLocalGenParameters(yyt->SchemaDef.FormalParams->FormalParams.DeclsIn);
        if (yyt->SchemaDef.IsOp) {
	    bool HasState=false;

            if (yyt->SchemaDef.Ident.Ident == Ident_init)
                yyt->SchemaDef.DeclList->DeclList.DeclsIn = StateIncl (yyt->SchemaDef.FormalParams->FormalParams.DeclsOut, 2, &HasState);
            else
                yyt->SchemaDef.DeclList->DeclList.DeclsIn = StateIncl (yyt->SchemaDef.FormalParams->FormalParams.DeclsOut, 3, &HasState);
        }
        else
            yyt->SchemaDef.DeclList->DeclList.DeclsIn = yyt->SchemaDef.FormalParams->FormalParams.DeclsOut;
    
yyVisit1DeclList (yyt->SchemaDef.DeclList);
/* line 942 "sum.cg" */

        if (yyt->SchemaDef.DeclList->DeclList.DeclsOut == yyt->SchemaDef.FormalParams->FormalParams.DeclsIn)
            yyt->SchemaDef.FormalParams->FormalParams.DeclsIn->Obj_Inn.Inner = nnNoObj;
        yyt->SchemaDef.FormalParams->FormalParams.DeclsIn->Object.Type = FormTp_Schema(yyt->SchemaDef.FormalParams->FormalParams.DeclsIn->Obj_Inn.Inner, ModIdent); 
        yyt->SchemaDef.PredList->PredList.DeclsIn = yyt->SchemaDef.DeclList->DeclList.DeclsOut;
    
yyVisit1PredList (yyt->SchemaDef.PredList);
/* line 954 "sum.cg" */

		yyt->SchemaDef.Next->DeclList.DeclsIn = yyt->SchemaDef.FormalParams->FormalParams.DeclsIn;
		CkPredListAIEnv (yyt->SchemaDef.PredList);

		ResetLocalGenParamPtr();
	
yyVisit1DeclList (yyt->SchemaDef.Next);
/* line 375 "sum.cg" */
yyt->SchemaDef.HasStateIncl=false;
/* line 1420 "sum.cg" */
if (! ( PredIsBool(yyt->SchemaDef.PredList) )) { Error(NonBoolPredPos(yyt->SchemaDef.PredList),error33); }
/* line 366 "sum.cg" */
yyt->SchemaDef.Type = NoType;
/* line 809 "sum.cg" */

    yyt->SchemaDef.DeclsOut = yyt->SchemaDef.Next->DeclList.DeclsOut;
} break;
case kAnnotation: {
yyt->Annotation.Next->DeclList.DeclsIn=yyt->Annotation.DeclsIn;
yyVisit1DeclList (yyt->Annotation.Next);
yyt->Annotation.Decl->Decl.DeclsIn=yyt->Annotation.Next->DeclList.DeclsOut;
yyVisit1Decl (yyt->Annotation.Decl);
/* line 522 "sum.cg" */

    yyt->Annotation.Pos = yyt->Annotation.Decl->Decl.Pos;
/* line 366 "sum.cg" */
yyt->Annotation.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Annotation.DeclsOut = yyt->Annotation.Next->DeclList.DeclsOut;
} break;
case kErgoAnno: {
/* line 526 "sum.cg" */

    yyt->ErgoAnno.Pos = yyt->ErgoAnno.Ident.Pos;
/* line 1313 "sum.cg" */

	yyt->ErgoAnno.Next->DeclList.DeclsIn = yyt->ErgoAnno.DeclsIn;
yyVisit1DeclList (yyt->ErgoAnno.Next);
/* line 366 "sum.cg" */
yyt->ErgoAnno.Type = NoType;
/* line 809 "sum.cg" */

    yyt->ErgoAnno.DeclsOut = yyt->ErgoAnno.Next->DeclList.DeclsOut;
} break;
case kStateMachine: {
/* line 1317 "sum.cg" */

	yyt->StateMachine.Next->DeclList.DeclsIn = yyt->StateMachine.DeclsIn;
yyVisit1DeclList (yyt->StateMachine.Next);
yyt->StateMachine.IdList->IdList.DeclsIn=yyt->StateMachine.Next->DeclList.DeclsOut;
yyVisit1IdList (yyt->StateMachine.IdList);
/* line 530 "sum.cg" */

    yyt->StateMachine.Pos = yyt->StateMachine.IdList->IdList.Pos;
/* line 366 "sum.cg" */
yyt->StateMachine.Type = NoType;
/* line 809 "sum.cg" */

    yyt->StateMachine.DeclsOut = yyt->StateMachine.Next->DeclList.DeclsOut;
} break;
case kAbbreviation: {
/* line 535 "sum.cg" */

    yyt->Abbreviation.Pos = yyt->Abbreviation.Ident.Pos;
/* line 977 "sum.cg" */
 
    yyt->Abbreviation.Exp->Exp.DeclsIn = yyt->Abbreviation.DeclsIn;
yyVisit1Exp (yyt->Abbreviation.Exp);
/* line 978 "sum.cg" */

        if (IsDeclared (yyt->Abbreviation.DeclsIn, yyt->Abbreviation.Ident.Ident, NoType)) 
            Error (yyt->Abbreviation.Ident.Pos, error22); 
        if (yyt->Abbreviation.Exp->Exp.IsTypeExp) 
            yyt->Abbreviation.Next->DeclList.DeclsIn = mObj_TyId (NoSym, yyt->Abbreviation.DeclsIn, ModIdent, yyt->Abbreviation.Exp->Exp.Type, yyt->Abbreviation.Ident.Ident, 1);
        else 
            yyt->Abbreviation.Next->DeclList.DeclsIn = mObj_Id (NoSym, yyt->Abbreviation.DeclsIn, ModIdent, yyt->Abbreviation.Exp->Exp.Type, yyt->Abbreviation.Ident.Ident, 1, NoIdent, 0);
    
yyVisit1DeclList (yyt->Abbreviation.Next);

        if (yyt->Abbreviation.DeclsIn->Kind == kObj_Inn && !yyt->Abbreviation.DeclsIn->Obj_Inn.Inner)
            yyt->Abbreviation.DeclsIn->Obj_Inn.Inner = yyt->Abbreviation.Next->DeclList.DeclsIn;
        else
            yyt->Abbreviation.DeclsIn->Object.Next = yyt->Abbreviation.Next->DeclList.DeclsIn;
    ;
/* line 366 "sum.cg" */
yyt->Abbreviation.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Abbreviation.DeclsOut = yyt->Abbreviation.Next->DeclList.DeclsOut;
} break;
case kFunctionDecl: {
/* line 903 "sum.cg" */

    yyt->FunctionDecl.DeclList->DeclList.DeclsIn = yyt->FunctionDecl.DeclsIn;
yyVisit1DeclList (yyt->FunctionDecl.DeclList);
/* line 539 "sum.cg" */

    yyt->FunctionDecl.Pos = yyt->FunctionDecl.DeclList->DeclList.Pos;
/* line 904 "sum.cg" */

    yyt->FunctionDecl.PredList->PredList.DeclsIn = yyt->FunctionDecl.DeclList->DeclList.DeclsOut;
yyVisit1PredList (yyt->FunctionDecl.PredList);
/* line 905 "sum.cg" */

                yyt->FunctionDecl.Next->DeclList.DeclsIn = yyt->FunctionDecl.DeclList->DeclList.DeclsOut;
		CkPredListAIEnv (yyt->FunctionDecl.PredList);
    
yyVisit1DeclList (yyt->FunctionDecl.Next);
/* line 1423 "sum.cg" */
if (! ( PredIsBool(yyt->FunctionDecl.PredList) )) { Error(NonBoolPredPos(yyt->FunctionDecl.PredList),error33); }
/* line 366 "sum.cg" */
yyt->FunctionDecl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->FunctionDecl.DeclsOut = yyt->FunctionDecl.Next->DeclList.DeclsOut;
} break;
case kFreeType: {
/* line 543 "sum.cg" */

    yyt->FreeType.Pos = yyt->FreeType.Ident.Pos;
/* line 1003 "sum.cg" */

        if (IsDeclared (yyt->FreeType.DeclsIn, yyt->FreeType.Ident.Ident, NoType)) 
            Error (yyt->FreeType.Ident.Pos, error22);   
        yyt->FreeType.BranchList->BranchList.DeclsIn = mObj_TyId (NoSym, yyt->FreeType.DeclsIn, ModIdent, 
            mTp_Base (ModIdent, yyt->FreeType.Ident.Ident), yyt->FreeType.Ident.Ident, 1);
        if (yyt->FreeType.DeclsIn->Kind == kObj_Inn && !yyt->FreeType.DeclsIn->Obj_Inn.Inner)
            yyt->FreeType.DeclsIn->Obj_Inn.Inner = yyt->FreeType.BranchList->BranchList.DeclsIn;
        else
            yyt->FreeType.DeclsIn->Object.Next = yyt->FreeType.BranchList->BranchList.DeclsIn;
    
yyVisit1BranchList (yyt->FreeType.BranchList);
/* line 1014 "sum.cg" */

    
    yyt->FreeType.Next->DeclList.DeclsIn = yyt->FreeType.BranchList->BranchList.DeclsOut;
yyVisit1DeclList (yyt->FreeType.Next);
/* line 373 "sum.cg" */
yyt->FreeType.ModId=ModIdent;
/* line 366 "sum.cg" */
yyt->FreeType.Type = NoType;
/* line 809 "sum.cg" */

    yyt->FreeType.DeclsOut = yyt->FreeType.Next->DeclList.DeclsOut;
} break;
case kEnum: {
/* line 547 "sum.cg" */

    yyt->Enum.Pos = yyt->Enum.Ident.Pos;
/* line 1026 "sum.cg" */

        if (IsDeclared (yyt->Enum.DeclsIn, yyt->Enum.Ident.Ident, NoType)) 
            Error (yyt->Enum.Ident.Pos, error22);   
        yyt->Enum.BranchList->BranchList.DeclsIn = mObj_TyId (NoSym, yyt->Enum.DeclsIn, ModIdent, 
            mTp_Base (ModIdent, yyt->Enum.Ident.Ident), yyt->Enum.Ident.Ident, 1);

        
        if (yyt->Enum.DeclsIn->Kind == kObj_Inn && !yyt->Enum.DeclsIn->Obj_Inn.Inner)
            yyt->Enum.DeclsIn->Obj_Inn.Inner = yyt->Enum.BranchList->BranchList.DeclsIn;
        else
            yyt->Enum.DeclsIn->Object.Next = yyt->Enum.BranchList->BranchList.DeclsIn;
    
yyVisit1BranchList (yyt->Enum.BranchList);
/* line 1044 "sum.cg" */

        {
                char enumstr[IDENT_LENGTH];
		char *mathpath="MATHPATH";
		char mathpathstr[256];  
                tIdent EnumIdent;
                tIdPos EnumIdentPos;
                tIdPos EnumMod;
                IML_List iml = NULL;
                tObjects fmlparams;
		tObjects sym;
		tType basetp;
                

                
                
                
                
                
                

                enumstr[0] = '\0';
                GetString(yyt->Enum.Ident.Ident, enumstr);
                strcat(enumstr, "_Enum");
                EnumIdent = MakeIdent(enumstr, strlen(enumstr));
		if ((sym = LookUp(yyt->Enum.BranchList->BranchList.DeclsOut ,yyt->Enum.Ident.Ident, NoSym)) 
                          == NoSym)
                      Error(yyt->Enum.Ident.Pos, error31);
                else if (sym->Kind != kObj_TyId) 
             	       Error(yyt->Enum.Ident.Pos, error31);
		else
		       basetp = sym->Object.Type; 
                
		yyt->Enum.Next->DeclList.DeclsIn = mObj_Inn (NoSym, yyt->Enum.BranchList->BranchList.DeclsOut, ModIdent, 
                        NoType, EnumIdent, 1, NoSym, Obj_import, 1); 
                
                

                if (yyt->Enum.BranchList->BranchList.DeclsOut->Kind == kObj_Inn && !yyt->Enum.BranchList->BranchList.DeclsOut->Obj_Inn.Inner)
                      yyt->Enum.BranchList->BranchList.DeclsOut->Obj_Inn.Inner = yyt->Enum.Next->DeclList.DeclsIn;
                else
                      yyt->Enum.BranchList->BranchList.DeclsOut->Object.Next = yyt->Enum.Next->DeclList.DeclsIn;


                strcpy(mathpathstr,getenv(mathpath));
		strcat(mathpathstr,"/adaenum");
		EnumMod.Ident = MakeIdent(mathpathstr, strlen(mathpathstr));
                EnumMod.Pos = yyt->Enum.Ident.Pos;

                yyt->Enum.Next->DeclList.DeclsIn->Obj_Inn.Inner= ReadModule(EnumMod,&iml,EnumIdent);

                
                if (yyt->Enum.Next->DeclList.DeclsIn->Obj_Inn.Inner->Kind != kNoObject)
                    yyt->Enum.Next->DeclList.DeclsIn->Obj_Inn.Inner->Object.Pre = yyt->Enum.Next->DeclList.DeclsIn;

                fmlparams = yyt->Enum.Next->DeclList.DeclsIn->Obj_Inn.Inner;
                
                *(fmlparams->Object.Type) = *(basetp);
                fmlparams->Object.Type->Tp_Exp.PtrToCopy = basetp;
                   

                EnumIdentPos.Ident = EnumIdent;
                EnumIdentPos.Pos = yyt->Enum.Ident.Pos;
                VisibleH (yyt->Enum.Next->DeclList.DeclsIn, EnumIdentPos, mNoSelection()); 
        } 
    
yyVisit1DeclList (yyt->Enum.Next);
/* line 373 "sum.cg" */
yyt->Enum.ModId=ModIdent;
/* line 366 "sum.cg" */
yyt->Enum.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Enum.DeclsOut = yyt->Enum.Next->DeclList.DeclsOut;
} break;
case kImport: {
/* line 551 "sum.cg" */

    yyt->Import.Pos = yyt->Import.Ident.Pos;
/* line 1296 "sum.cg" */

    yyt->Import.ExpressionList->ExpressionList.DeclsIn = yyt->Import.DeclsIn;
yyVisit1ExpressionList (yyt->Import.ExpressionList);
yyt->Import.RenameList->RenameList.DeclsIn=yyt->Import.ExpressionList->ExpressionList.DeclsOut;
yyVisit1RenameList (yyt->Import.RenameList);
/* line 378 "sum.cg" */
yyt->Import.FmlParams=NoSyms;
/* line 377 "sum.cg" */
yyt->Import.ModIMLlist=NULL;
/* line 1176 "sum.cg" */

        if (IsDeclared (yyt->Import.DeclsIn, yyt->Import.NewIdent.Ident, NoType))
            Error (yyt->Import.NewIdent.Pos, error22);
        yyt->Import.Next->DeclList.DeclsIn = mObj_Inn (NoSym, yyt->Import.DeclsIn, ModIdent, 
                        NoType, yyt->Import.NewIdent.Ident, 1, NoSym, Obj_import, false); 
        if (yyt->Import.DeclsIn->Kind == kObj_Inn && !yyt->Import.DeclsIn->Obj_Inn.Inner)
            yyt->Import.DeclsIn->Obj_Inn.Inner = yyt->Import.Next->DeclList.DeclsIn;
        else
            yyt->Import.DeclsIn->Object.Next = yyt->Import.Next->DeclList.DeclsIn;

	if (yyt->Import.Ident.Ident != yyt->Import.NewIdent.Ident) { 
                
		yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.ImportHasAsPart = true;
		if (cur_mod_imllist==NULL) {
			cur_mod_imllist = (IML_List) 
                                 my_malloc (sizeof (struct IMLstruct));
			cur_mod_imllist_hd = cur_mod_imllist;
		}
		else {
			cur_mod_imllist->next = (IML_List) 
                                 my_malloc (sizeof (struct IMLstruct));
			cur_mod_imllist = cur_mod_imllist->next;
		}
		if (yyt->Import.ExpressionList->Kind != kNoExp) {
			cur_mod_imllist->subthyid[0] = '\0';
			GetString (yyt->Import.NewIdent.Ident, cur_mod_imllist->subthyid);
			strcat (cur_mod_imllist->subthyid, "#Param");
			cur_mod_imllist->ParentModId = ModIdent;
			cur_mod_imllist->next = (IML_List) 
                                 my_malloc (sizeof (struct IMLstruct));
			cur_mod_imllist = cur_mod_imllist->next;
		}
		cur_mod_imllist->subthyid[0] = '\0';
		GetString (yyt->Import.NewIdent.Ident, cur_mod_imllist->subthyid);

		cur_mod_imllist->ParentModId = ModIdent;
		cur_mod_imllist->next = NULL;
	}
        {
		IML_List iml=NULL;
		tObjects sym, fmlparams;

                
    
                sym = LookUp(yyt->Import.DeclsIn, yyt->Import.Ident.Ident, NoSym);
                if (sym != NoSym) {
                  
                   yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner=InstMod(sym->Obj_Inn.Inner, yyt->Import.NewIdent.Ident);
                       
                
                
                }
                else {
                
                

                if (yyt->Import.Ident.Ident == yyt->Import.NewIdent.Ident)
	         yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner= ReadModule(yyt->Import.Ident,&iml,NoIdent);
                else 
	         yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner= ReadModule(yyt->Import.Ident,&iml,yyt->Import.NewIdent.Ident);               
                

                }

                

                if (yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner->Kind != kNoObject) {
                   yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner->Object.Pre = yyt->Import.Next->DeclList.DeclsIn;
		   ImportHandler (yyt->Import.Next->DeclList.DeclsIn, yyt->Import.ExpressionList, &fmlparams);

                 
               
                }
		yyt->Import.ModIMLlist = iml;
		yyt->Import.FmlParams = fmlparams;
		for (; iml != NULL; iml=iml->next) {
			if (cur_mod_imllist==NULL) {
				cur_mod_imllist = (IML_List) 
					my_malloc (sizeof (struct IMLstruct));
				cur_mod_imllist_hd = cur_mod_imllist;
			}
			else {
				cur_mod_imllist->next = (IML_List)
					my_malloc (sizeof (struct IMLstruct));
				cur_mod_imllist = cur_mod_imllist->next;
			}
			cur_mod_imllist->subthyid[0] = '\0';
			if (yyt->Import.Ident.Ident != yyt->Import.NewIdent.Ident) {
			      GetString (yyt->Import.NewIdent.Ident, 
                                        cur_mod_imllist->subthyid);
			      strcat (cur_mod_imllist->subthyid, "_");
			      strcat (cur_mod_imllist->subthyid, iml->subthyid);
			      cur_mod_imllist->ParentModId = ModIdent;
			}
			else {
			      strcat (cur_mod_imllist->subthyid, iml->subthyid);
			      cur_mod_imllist->ParentModId = iml->ParentModId;
			}
			cur_mod_imllist->next = NULL;

		}
	}
        RenameHandler (yyt->Import.Next->DeclList.DeclsIn->Obj_Inn.Inner, yyt->Import.RenameList);
    
yyVisit1DeclList (yyt->Import.Next);
/* line 366 "sum.cg" */
yyt->Import.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Import.DeclsOut = yyt->Import.Next->DeclList.DeclsOut;
} break;
case kModuleDecl: {
/* line 1301 "sum.cg" */

    yyt->ModuleDecl.Module->Module.DeclsIn = yyt->ModuleDecl.DeclsIn;
yyVisit1Module (yyt->ModuleDecl.Module);
/* line 555 "sum.cg" */

    yyt->ModuleDecl.Pos = yyt->ModuleDecl.Module->Module.Pos;
/* line 1302 "sum.cg" */

    yyt->ModuleDecl.Next->DeclList.DeclsIn = yyt->ModuleDecl.Module->Module.DeclsOut;
yyVisit1DeclList (yyt->ModuleDecl.Next);
/* line 366 "sum.cg" */
yyt->ModuleDecl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->ModuleDecl.DeclsOut = yyt->ModuleDecl.Next->DeclList.DeclsOut;
} break;
case kConstraint: {
/* line 1321 "sum.cg" */

    yyt->Constraint.Pred->Pred.DeclsIn = yyt->Constraint.DeclsIn;
yyVisit1Pred (yyt->Constraint.Pred);
/* line 559 "sum.cg" */

    yyt->Constraint.Pos = yyt->Constraint.Pred->Pred.Pos;
yyt->Constraint.Next->DeclList.DeclsIn=yyt->Constraint.DeclsIn;
yyVisit1DeclList (yyt->Constraint.Next);
/* line 366 "sum.cg" */
yyt->Constraint.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Constraint.DeclsOut = yyt->Constraint.Next->DeclList.DeclsOut;
} break;
case kSchemaIncl: {
/* line 373 "sum.cg" */
yyt->SchemaIncl.ModId=ModIdent;
/* line 963 "sum.cg" */
 
    yyt->SchemaIncl.ExpressionList->ExpressionList.DeclsIn = yyt->SchemaIncl.DeclsIn;
yyVisit1ExpressionList (yyt->SchemaIncl.ExpressionList);
/* line 965 "sum.cg" */

	{
		tIdent modid;

		yyt->SchemaIncl.Next->DeclList.DeclsIn = SchemaInclH (yyt->SchemaIncl.DeclsIn, yyt->SchemaIncl.IdList, yyt->SchemaIncl.ExpressionList, &modid);
		yyt->SchemaIncl.ModId = modid;
	}
	
yyVisit1DeclList (yyt->SchemaIncl.Next);
yyt->SchemaIncl.IdList->IdList.DeclsIn=yyt->SchemaIncl.Next->DeclList.DeclsOut;
yyVisit1IdList (yyt->SchemaIncl.IdList);
/* line 563 "sum.cg" */

    yyt->SchemaIncl.Pos = yyt->SchemaIncl.IdList->IdList.Pos;
/* line 366 "sum.cg" */
yyt->SchemaIncl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->SchemaIncl.DeclsOut = yyt->SchemaIncl.Next->DeclList.DeclsOut;
} break;
case kVisibility: {
/* line 359 "sum.cg" */
yyt->Visibility.Pos = NoPosition;
yyVisit1SelectionList (yyt->Visibility.SelectionList);
/* line 1306 "sum.cg" */

        VisibleH (yyt->Visibility.DeclsIn, yyt->Visibility.Ident, yyt->Visibility.SelectionList);
        yyt->Visibility.Next->DeclList.DeclsIn = yyt->Visibility.DeclsIn;
    
yyVisit1DeclList (yyt->Visibility.Next);
/* line 366 "sum.cg" */
yyt->Visibility.Type = NoType;
/* line 809 "sum.cg" */

    yyt->Visibility.DeclsOut = yyt->Visibility.Next->DeclList.DeclsOut;
} break;
 default: ;
 }
}

static void yyVisit1VarDecl
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kVarDecl: {
/* line 813 "sum.cg" */
 
    yyt->VarDecl.Exp->Exp.DeclsIn = yyt->VarDecl.DeclsIn;
yyVisit1Exp (yyt->VarDecl.Exp);
/* line 816 "sum.cg" */

        if (yyt->VarDecl.Exp->Exp.Type == NoType || yyt->VarDecl.Exp->Exp.Type->Kind == kTp_Err) 
            yyt->VarDecl.Next->DeclList.DeclsIn = yyt->VarDecl.DeclsIn;
        else if (yyt->VarDecl.Exp->Exp.IsTypeExp)
            yyt->VarDecl.Next->DeclList.DeclsIn = mObj_IdList (yyt->VarDecl.DeclsIn, yyt->VarDecl.Exp->Exp.Type, yyt->VarDecl.IdList, yyt->VarDecl.VarDeclKind, ModIdent); 
        else if (yyt->VarDecl.Exp->Exp.Type->Kind == kTp_Power)
            yyt->VarDecl.Next->DeclList.DeclsIn = mObj_IdList (yyt->VarDecl.DeclsIn, yyt->VarDecl.Exp->Exp.Type->Tp_Power.Tp_Exp, yyt->VarDecl.IdList, yyt->VarDecl.VarDeclKind, ModIdent); 
        else {
            Error (yyt->VarDecl.Exp->Exp.Pos, error32);
            yyt->VarDecl.Next->DeclList.DeclsIn = yyt->VarDecl.DeclsIn;
        }
    
yyVisit1DeclList (yyt->VarDecl.Next);
yyt->VarDecl.IdList->IdList.DeclsIn=yyt->VarDecl.Next->DeclList.DeclsOut;
yyVisit1IdList (yyt->VarDecl.IdList);
/* line 506 "sum.cg" */

    yyt->VarDecl.Pos = yyt->VarDecl.IdList->IdList.Pos;
/* line 366 "sum.cg" */
yyt->VarDecl.Type = NoType;
/* line 809 "sum.cg" */

    yyt->VarDecl.DeclsOut = yyt->VarDecl.Next->DeclList.DeclsOut;
} break;
 default: ;
 }
}

static void yyVisit1BranchList
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kBranchList: {
yyt->BranchList.DeclsOut=yyt->BranchList.DeclsIn;
/* line 366 "sum.cg" */
yyt->BranchList.Type = NoType;
} break;
case kNoBranch: {
yyt->NoBranch.DeclsOut=yyt->NoBranch.DeclsIn;
/* line 366 "sum.cg" */
yyt->NoBranch.Type = NoType;
} break;
case kBranch: {
yyt->Branch.Next->BranchList.DeclsIn=yyt->Branch.DeclsIn;
yyVisit1BranchList (yyt->Branch.Next);
/* line 1126 "sum.cg" */

    yyt->Branch.DeclsOut = yyt->Branch.Next->BranchList.DeclsOut;
/* line 366 "sum.cg" */
yyt->Branch.Type = NoType;
} break;
case kFTConstant: {
/* line 1130 "sum.cg" */

        if (IsDeclared (yyt->FTConstant.DeclsIn, yyt->FTConstant.Ident.Ident, NoType))
            Error (yyt->FTConstant.Ident.Pos, error22);
        yyt->FTConstant.Next->BranchList.DeclsIn = mObj_Id (NoSym, yyt->FTConstant.DeclsIn, ModIdent, mTp_Base(ModIdent, yyt->FTConstant.FTIdent), yyt->FTConstant.Ident.Ident, 1, NoIdent, 0);
        yyt->FTConstant.DeclsIn->Object.Next = yyt->FTConstant.Next->BranchList.DeclsIn;
    
yyVisit1BranchList (yyt->FTConstant.Next);
/* line 1126 "sum.cg" */

    yyt->FTConstant.DeclsOut = yyt->FTConstant.Next->BranchList.DeclsOut;
/* line 366 "sum.cg" */
yyt->FTConstant.Type = NoType;
} break;
case kFTConstructor: {
/* line 1139 "sum.cg" */
 
    yyt->FTConstructor.Exp->Exp.DeclsIn = yyt->FTConstructor.DeclsIn;
yyVisit1Exp (yyt->FTConstructor.Exp);
/* line 1140 "sum.cg" */

        if (IsDeclared (yyt->FTConstructor.DeclsIn, yyt->FTConstructor.Ident.Ident, NoType))
            Error (yyt->FTConstructor.Ident.Pos, error22);
        if (yyt->FTConstructor.Exp->Exp.Type == NoType || yyt->FTConstructor.Exp->Exp.Type->Kind == kTp_Err) 
            yyt->FTConstructor.Next->BranchList.DeclsIn = yyt->FTConstructor.DeclsIn;
        else if (yyt->FTConstructor.Exp->Exp.IsTypeExp) {
            yyt->FTConstructor.Next->BranchList.DeclsIn = mObj_Id (NoSym, yyt->FTConstructor.DeclsIn, ModIdent,
                mTp_Infix (NoIdent, Ident_totalinj, yyt->FTConstructor.Exp->Exp.Type, mTp_Base(ModIdent, yyt->FTConstructor.FTIdent)),
                yyt->FTConstructor.Ident.Ident, 1, NoIdent, 0);
            yyt->FTConstructor.DeclsIn->Object.Next = yyt->FTConstructor.Next->BranchList.DeclsIn;
        }
        else if (yyt->FTConstructor.Exp->Exp.Type->Kind == kTp_Power) {
            yyt->FTConstructor.Next->BranchList.DeclsIn = mObj_Id (NoSym, yyt->FTConstructor.DeclsIn, ModIdent,
                mTp_Infix (NoIdent, Ident_totalinj, yyt->FTConstructor.Exp->Exp.Type->Tp_Power.Tp_Exp, mTp_Base(ModIdent, yyt->FTConstructor.FTIdent)),
                yyt->FTConstructor.Ident.Ident, 1, NoIdent, 0);
            yyt->FTConstructor.DeclsIn->Object.Next = yyt->FTConstructor.Next->BranchList.DeclsIn;
        }
        else {
            Error (yyt->FTConstructor.Exp->Exp.Pos, error32);
            yyt->FTConstructor.Next->BranchList.DeclsIn = yyt->FTConstructor.DeclsIn;
        }
    
yyVisit1BranchList (yyt->FTConstructor.Next);
/* line 1126 "sum.cg" */

    yyt->FTConstructor.DeclsOut = yyt->FTConstructor.Next->BranchList.DeclsOut;
/* line 366 "sum.cg" */
yyt->FTConstructor.Type = NoType;
} break;
 default: ;
 }
}

static void yyVisit1Schema
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kSchema: {
/* line 359 "sum.cg" */
yyt->Schema.Pos = NoPosition;
/* line 366 "sum.cg" */
yyt->Schema.Type = NoType;
yyt->Schema.DeclsOut=yyt->Schema.DeclsIn;
/* line 362 "sum.cg" */
yyt->Schema.IsTypeExp = false;
} break;
case kExpPred: {
yyt->ExpPred.Exp->Exp.DeclsIn=yyt->ExpPred.DeclsIn;
yyVisit1Exp (yyt->ExpPred.Exp);
/* line 625 "sum.cg" */

    yyt->ExpPred.Pos = yyt->ExpPred.Exp->Exp.Pos;
/* line 1621 "sum.cg" */


    yyt->ExpPred.Type = yyt->ExpPred.Exp->Exp.Type;
yyt->ExpPred.DeclsOut=yyt->ExpPred.Exp->Exp.DeclsOut;
/* line 1622 "sum.cg" */

    yyt->ExpPred.IsTypeExp = yyt->ExpPred.Type->Tp_Exp.IsTypeExp;
} break;
case kSchemaText: {
/* line 1392 "sum.cg" */
 
    yyt->SchemaText.DeclList->DeclList.DeclsIn = mObj_Tmp(NoSym, yyt->SchemaText.DeclsIn, ModIdent, NoType, NoIdent, 0, NoSym);
yyVisit1DeclList (yyt->SchemaText.DeclList);
/* line 629 "sum.cg" */

    yyt->SchemaText.Pos = yyt->SchemaText.DeclList->DeclList.Pos;
yyt->SchemaText.PredList->PredList.DeclsIn=yyt->SchemaText.DeclList->DeclList.DeclsOut;
yyVisit1PredList (yyt->SchemaText.PredList);
/* line 1425 "sum.cg" */
if (! ( PredIsBool(yyt->SchemaText.PredList) )) { Error(NonBoolPredPos(yyt->SchemaText.PredList),error33); }
/* line 1393 "sum.cg" */

    yyt->SchemaText.Type = FormTp_Schema(yyt->SchemaText.DeclList->DeclList.DeclsIn->Obj_Tmp.Inner, ModIdent);
/* line 1394 "sum.cg" */

		yyt->SchemaText.DeclsOut = yyt->SchemaText.DeclList->DeclList.DeclsOut; 
		CkPredListAIEnv(yyt->SchemaText.PredList);
	
/* line 362 "sum.cg" */
yyt->SchemaText.IsTypeExp = false;
} break;
case kSchemaRef: {
/* line 359 "sum.cg" */
yyt->SchemaRef.Pos = NoPosition;
yyt->SchemaRef.IdList->IdList.DeclsIn=yyt->SchemaRef.DeclsIn;
yyVisit1IdList (yyt->SchemaRef.IdList);
yyt->SchemaRef.ExpressionList->ExpressionList.DeclsIn=yyt->SchemaRef.IdList->IdList.DeclsOut;
yyVisit1ExpressionList (yyt->SchemaRef.ExpressionList);
/* line 366 "sum.cg" */
yyt->SchemaRef.Type = NoType;
yyt->SchemaRef.DeclsOut=yyt->SchemaRef.ExpressionList->ExpressionList.DeclsOut;
/* line 362 "sum.cg" */
yyt->SchemaRef.IsTypeExp = false;
} break;
case kSchemaCons: {
yyt->SchemaCons.L->Schema.DeclsIn=yyt->SchemaCons.DeclsIn;
yyVisit1Schema (yyt->SchemaCons.L);
/* line 633 "sum.cg" */

    yyt->SchemaCons.Pos = yyt->SchemaCons.L->Schema.Pos;
yyt->SchemaCons.R->Schema.DeclsIn=yyt->SchemaCons.L->Schema.DeclsOut;
yyVisit1Schema (yyt->SchemaCons.R);
yyVisit1LogOp (yyt->SchemaCons.LogOp);
/* line 366 "sum.cg" */
yyt->SchemaCons.Type = NoType;
yyt->SchemaCons.DeclsOut=yyt->SchemaCons.R->Schema.DeclsOut;
/* line 362 "sum.cg" */
yyt->SchemaCons.IsTypeExp = false;
} break;
case kSchemaCompos: {
yyt->SchemaCompos.Sch1->Schema.DeclsIn=yyt->SchemaCompos.DeclsIn;
yyVisit1Schema (yyt->SchemaCompos.Sch1);
/* line 637 "sum.cg" */

    yyt->SchemaCompos.Pos = yyt->SchemaCompos.Sch1->Schema.Pos;
yyt->SchemaCompos.Sch2->Schema.DeclsIn=yyt->SchemaCompos.Sch1->Schema.DeclsOut;
yyVisit1Schema (yyt->SchemaCompos.Sch2);
/* line 1626 "sum.cg" */

    yyt->SchemaCompos.Type = Tyof_SchCompos (yyt->SchemaCompos.Sch1->Schema.Type, yyt->SchemaCompos.Compos, yyt->SchemaCompos.Sch2->Schema.Type);
yyt->SchemaCompos.DeclsOut=yyt->SchemaCompos.Sch2->Schema.DeclsOut;
/* line 362 "sum.cg" */
yyt->SchemaCompos.IsTypeExp = false;
} break;
case kSchemaProj: {
yyt->SchemaProj.Sch1->Schema.DeclsIn=yyt->SchemaProj.DeclsIn;
yyVisit1Schema (yyt->SchemaProj.Sch1);
/* line 641 "sum.cg" */

    yyt->SchemaProj.Pos = yyt->SchemaProj.Sch1->Schema.Pos;
yyt->SchemaProj.Sch2->Schema.DeclsIn=yyt->SchemaProj.Sch1->Schema.DeclsOut;
yyVisit1Schema (yyt->SchemaProj.Sch2);
/* line 1630 "sum.cg" */

    yyt->SchemaProj.Type = Tyof_SchProj (yyt->SchemaProj.Sch1->Schema.Type, yyt->SchemaProj.Proj, yyt->SchemaProj.Sch2->Schema.Type);
yyt->SchemaProj.DeclsOut=yyt->SchemaProj.Sch2->Schema.DeclsOut;
/* line 362 "sum.cg" */
yyt->SchemaProj.IsTypeExp = false;
} break;
case kSchemaSubst: {
yyt->SchemaSubst.Schema->Schema.DeclsIn=yyt->SchemaSubst.DeclsIn;
yyVisit1Schema (yyt->SchemaSubst.Schema);
/* line 645 "sum.cg" */

    yyt->SchemaSubst.Pos = yyt->SchemaSubst.Schema->Schema.Pos;
yyt->SchemaSubst.RenameList->RenameList.DeclsIn=yyt->SchemaSubst.Schema->Schema.DeclsOut;
yyVisit1RenameList (yyt->SchemaSubst.RenameList);
/* line 1634 "sum.cg" */

    yyt->SchemaSubst.Type = Tyof_SchSubst (yyt->SchemaSubst.Schema->Schema.Type, yyt->SchemaSubst.RenameList, yyt->SchemaSubst.Schema->Schema.Pos);
yyt->SchemaSubst.DeclsOut=yyt->SchemaSubst.RenameList->RenameList.DeclsOut;
/* line 362 "sum.cg" */
yyt->SchemaSubst.IsTypeExp = false;
} break;
case kSchemaHiding: {
yyt->SchemaHiding.Schema->Schema.DeclsIn=yyt->SchemaHiding.DeclsIn;
yyVisit1Schema (yyt->SchemaHiding.Schema);
/* line 649 "sum.cg" */

    yyt->SchemaHiding.Pos = yyt->SchemaHiding.Schema->Schema.Pos;
yyt->SchemaHiding.NameList->NameList.DeclsIn=yyt->SchemaHiding.Schema->Schema.DeclsOut;
yyVisit1NameList (yyt->SchemaHiding.NameList);
/* line 1638 "sum.cg" */
 
    yyt->SchemaHiding.Type = Tyof_SchHiding (yyt->SchemaHiding.Schema->Schema.Type, yyt->SchemaHiding.NameList, yyt->SchemaHiding.Schema->Schema.Pos);
yyt->SchemaHiding.DeclsOut=yyt->SchemaHiding.NameList->NameList.DeclsOut;
/* line 362 "sum.cg" */
yyt->SchemaHiding.IsTypeExp = false;
} break;
 default: ;
 }
}

static void yyVisit1SchemaText
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kSchemaText: {
/* line 1392 "sum.cg" */
 
    yyt->SchemaText.DeclList->DeclList.DeclsIn = mObj_Tmp(NoSym, yyt->SchemaText.DeclsIn, ModIdent, NoType, NoIdent, 0, NoSym);
yyVisit1DeclList (yyt->SchemaText.DeclList);
/* line 629 "sum.cg" */

    yyt->SchemaText.Pos = yyt->SchemaText.DeclList->DeclList.Pos;
yyt->SchemaText.PredList->PredList.DeclsIn=yyt->SchemaText.DeclList->DeclList.DeclsOut;
yyVisit1PredList (yyt->SchemaText.PredList);
/* line 1425 "sum.cg" */
if (! ( PredIsBool(yyt->SchemaText.PredList) )) { Error(NonBoolPredPos(yyt->SchemaText.PredList),error33); }
/* line 1393 "sum.cg" */

    yyt->SchemaText.Type = FormTp_Schema(yyt->SchemaText.DeclList->DeclList.DeclsIn->Obj_Tmp.Inner, ModIdent);
/* line 1394 "sum.cg" */

		yyt->SchemaText.DeclsOut = yyt->SchemaText.DeclList->DeclList.DeclsOut; 
		CkPredListAIEnv(yyt->SchemaText.PredList);
	
/* line 362 "sum.cg" */
yyt->SchemaText.IsTypeExp = false;
} break;
 default: ;
 }
}

static void yyVisit1LogOp
# if defined __STDC__ | defined __cplusplus
 (register tTree yyt)
# else
 (yyt)
 register tTree yyt;
# endif
{
 switch (yyt->Kind) {
case kLogOp: {
} break;
case kSDisjunction: {
} break;
case kSConjunction: {
} break;
case kSImplication: {
} break;
case kSEquivalence: {
} break;
 default: ;
 }
}

void BeginSemantics ()
{
/* line 176 "sum.cg" */

    SymsRoot = NoSym;
	ModIdent = NoIdent;

}

void CloseSemantics ()
{
}
