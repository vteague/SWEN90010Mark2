/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include "env.h"

/* construct an IdPos */
tIdPos ZMakeIdPos (Idstr, Pos) 
    char *Idstr;
    tPosition Pos;
{
    tIdPos idpos;

    idpos.Ident = MakeIdent(Idstr, strlen(Idstr));
    idpos.Pos = Pos;
    return idpos;
}

/* write an IdPos to a binary tree file */
void PutIdPos(file,id)
  FILE *file;
  tIdPos id;
{
  char str[256];
  GetString(id.Ident,str);
  fprintf(file,"%s\n",str);
  PutPosition(file,id.Pos);
}

/* read an IdPos from a binary tree file */
void GetIdPos(file,id)
  FILE *file;
  tIdPos *id;
{
  char str[256],str1[256];
  fscanf(file,"%s%*c",str);
  if ((strcmp("_Delta",str)==0) || (strcmp("_Xi",str)==0))
      /* there is a space in delta or xi schema names to confuse the issue */
        {fscanf(file,"%s",str1); /*collect schema name*/
        strcat(str," ");         /*add space to delta or xi*/
        strcat(str,str1);}       /*concatenate delta and name*/
  id->Ident = MakeIdent((tString)str,strlen(str));
  GetPosition(file,&id->Pos);
}
 
/* write a Position to an binary tree file */
void PutPosition(file,pos)
  FILE *file;
  tPosition pos;
{
  fprintf(file,"%3d%3d\n",pos.Line,pos.Column);
}

/* read a Position from a binary tree file */
void GetPosition(file,pos)     
  FILE *file;
  tPosition *pos;
{
  int i,j;
  fscanf(file,"%3d%3d%*c",&i,&j);
  pos->Line = i;
  pos->Column = j;
}

/*replace the backslash prefix with underscore to make a reserve word */
void ReplaceBackslashPrefix(str)
     char *str;
{  char ch,s[256];
   ch = str[0];
   if (ch == '\\')
     str[0] = '_';
}
