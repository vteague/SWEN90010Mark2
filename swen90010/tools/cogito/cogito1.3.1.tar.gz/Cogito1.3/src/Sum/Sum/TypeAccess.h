# ifndef yyTypeAccess
# define yyTypeAccess

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "Type.h"
# include "Syms.h"

/* line 10 "types.puma" */

#include "Idents.h"
#include "Syms.h"
#include <string.h>
#include "Type.h"
#include "global.h"
#include "Positions.h"
#include "ratc.h"
#include <fcntl.h>


extern void (* TypeAccess_Exit) ();

extern bool IsBoolOrSchRef ARGS((tType ty));
extern tIdent RemoveDecn ARGS((tIdent id));
extern tType ThetaType ARGS((tType S, tSyms DeclsIn));

extern void BeginTypeAccess ();
extern void CloseTypeAccess ();

# endif
