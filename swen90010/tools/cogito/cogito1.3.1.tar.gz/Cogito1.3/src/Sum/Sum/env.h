#include "Idents.h"
#include "Positions.h"
#include "global.h"

#ifndef MYIDPOS
#define MYIDPOS
tIdPos ZMakeIdPos () ;
#define NoIdPos ZMakeIdPos("",NoPosition)
void PutIdPos(); /* write an IdPos to binary tree file */
void GetIdPos(); /* read an IdPos from binary tree file */
void PutPosition(); /* write a Position from binary tree file */
void GetPosition(); /* read a Position from binary tree file */
void ReplaceBackslashPrefix();/* replace a backslash prefix with _ */
int ErrorsInTranslation;
#endif
