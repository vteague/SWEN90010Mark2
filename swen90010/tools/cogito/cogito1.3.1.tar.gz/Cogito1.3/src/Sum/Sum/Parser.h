# ifndef yyParser
# define yyParser

/* $Id: Parser.h,v 2.1 1992/08/07 15:28:42 grosch rel $ */

/* line 176 "Parser.lalr" */


# include "Idents.h"
# include "Positions.h"
# include "Tree.h"
# include "ratc.h"
# include <string.h>
# include <stdio.h>
# include "Errors.h"

extern int CountErr;



# ifdef yacc_interface
# define Parser			yyparse
# define yyInitStackSize	YYMAXDEPTH
# endif

extern	char *	Parser_TokenName [];

extern	int	Parser	();
extern	void	CloseParser	();

# endif
