# ifndef yytex
# define yytex

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "Tree.h"
# include "Type.h"


extern void (* tex_Exit) ();

extern void SumGForm ARGS((tTree t));

extern void Begintex ();
extern void Closetex ();

# endif
