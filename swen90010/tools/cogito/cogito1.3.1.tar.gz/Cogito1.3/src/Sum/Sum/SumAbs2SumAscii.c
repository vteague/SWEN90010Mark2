# include "SumAbs2SumAscii.h"
# include "yySumAbs2SumAscii.w"
# include "System.h"
# include <stdio.h>
# include "Tree.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 17 "sumabs2sum.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "SumTreeAccess.h"
#include "env.h"
#define INLINE 1
#define VERT 2
char leftmargin[256],linedown[20];
FILE *fileptr,*fopen();



static void yyExit () { Exit (1); }

void (* SumAbs2SumAscii_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module SumAbs2SumAscii, routine %s failed\n", yyFunction);
 SumAbs2SumAscii_Exit ();
}

static void ResetLeftMargin ARGS(());
static void ResetLineDown ARGS(());
void UnparseSum ARGS((tTree yyP1, tString str, tString str2));
static void IncLeftMargin ARGS((int inc));
static void DecLeftMargin ARGS((int dec));
static void IncLineDown ARGS(());
static void DecLineDown ARGS(());
static void LocalWriteIdPos ARGS((tIdPos id));
static void UnparseModuleList ARGS((tTree yyP2));
static void UnparseFormalParams ARGS((tTree yyP3));
static void UnparseNextDecl ARGS((tTree rest, int ind));
static void UnparseDeclList ARGS((tTree yyP4, int ind));
static void UnparseSelectionList ARGS((tTree yyP5));
void UnparseIdList ARGS((tTree yyP6));
static void UnparseSchemaIdList ARGS((tTree yyP7));
static void UnparseNextExp ARGS((tTree rest));
static void UnparseExpressionList ARGS((tTree elist));
static void UnparseNextPred ARGS((tTree rest, int ind));
static void UnparsePredList ARGS((tTree yyP8, int ind));
static void UnparseLogBinOp ARGS((tTree yyP9, int ind));
static void UnparseBranchList ARGS((tTree b));
static void UnparseRenameList ARGS((tTree yyP10));
static void CrossProdFromNextExp ARGS((tTree rest));
static void CrossProdFromExp ARGS((tTree elist));
static void UnparseNameList ARGS((tTree yyP11));
static void UnparseSchema ARGS((tTree yyP12));
static void UnparseBoxedSchemaText ARGS((tTree s));
static void UnparseLogOp ARGS((tTree yyP13));
static bool IsInfun ARGS((tIdent id));
static bool IsIngen ARGS((tIdent id));
static bool NeedsPrefixBrackets ARGS((tTree yyP14));
static bool NeedsInFunBrackets ARGS((tTree yyP15));
static bool NeedsCrossBrackets ARGS((tTree yyP16));
static bool NeedsInGenBrackets ARGS((tTree yyP17));

static void ResetLeftMargin
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
/* line 38 "sumabs2sum.puma" */
  {
/* line 38 "sumabs2sum.puma" */
strcpy(leftmargin," ");
  }
   return;

;
}

static void ResetLineDown
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
/* line 42 "sumabs2sum.puma" */
  {
/* line 42 "sumabs2sum.puma" */
strcpy(linedown,"\n");
  }
   return;

;
}

void UnparseSum
# if defined __STDC__ | defined __cplusplus
(register tTree yyP1, tString str, tString str2)
# else
(yyP1, str, str2)
 register tTree yyP1;
 tString str;
 tString str2;
# endif
{
/* line 46 "sumabs2sum.puma" */
  {
/* line 47 "sumabs2sum.puma" */
char sumname[256],latexname[256];
	strcpy(sumname,str);strcpy(latexname,str2);

	fileptr = fopen(sumname,"w");
	fprintf(fileptr,"// This is a Sum file, derived automatically from the LaTeX file %s\n\n",latexname);
	UnparseModuleList(yyP1->Sum.ModuleList);
  }
   return;

;
}

static void IncLeftMargin
# if defined __STDC__ | defined __cplusplus
(int inc)
# else
(inc)
 int inc;
# endif
{
/* line 56 "sumabs2sum.puma" */
  {
/* line 57 "sumabs2sum.puma" */
int i=0;
	while ((i<inc)&&(strlen(leftmargin)<256)) 
	  {strcat(leftmargin," ");
	   i=i+1;}
  }
   return;

;
}

static void DecLeftMargin
# if defined __STDC__ | defined __cplusplus
(int dec)
# else
(dec)
 int dec;
# endif
{
/* line 64 "sumabs2sum.puma" */
  {
/* line 65 "sumabs2sum.puma" */
int i;
	i = strlen(leftmargin);
	if ((i>dec)&&(i<=256))
	  leftmargin[i-dec]='\0';
  }
   return;

;
}

static void IncLineDown
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
/* line 72 "sumabs2sum.puma" */
  {
/* line 73 "sumabs2sum.puma" */
if (strlen(linedown)<256) strcat(linedown,"\n");
  }
   return;

;
}

static void DecLineDown
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
/* line 77 "sumabs2sum.puma" */
  {
/* line 78 "sumabs2sum.puma" */
int i;
	i = strlen(linedown);
	if ((i>0)&&(i<=256))
	  linedown[i-1]='\0';
  }
   return;

;
}

static void LocalWriteIdPos
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 85 "sumabs2sum.puma" */
  {
/* line 86 "sumabs2sum.puma" */
char str[256],str1[256];
	int i,j,len;
	GetString(id.Ident,str);
	
	len = strlen(str); j = 0;
	for (i=0;i<len;i++)
	  if (str[i]=='\\');
	  else {str1[j] = str[i];j++;}
	str1[j] = '\0';
	fprintf(fileptr,"%s",str1);
	
  }
   return;

;
}

static void UnparseModuleList
# if defined __STDC__ | defined __cplusplus
(register tTree yyP2)
# else
(yyP2)
 register tTree yyP2;
# endif
{
  if (yyP2->Kind == kNoModule) {
/* line 100 "sumabs2sum.puma" */
   return;

  }
  if (yyP2->Kind == kModule) {
/* line 101 "sumabs2sum.puma" */
  {
/* line 102 "sumabs2sum.puma" */
ResetLeftMargin();
		ResetLineDown();
		fprintf(fileptr,"%s%s",linedown,leftmargin);
		fprintf(fileptr,"module ");
		LocalWriteIdPos(yyP2->Module.Ident);
		
		if (Tree_IsType(yyP2->Module.FormalParams,kParam))
			{fprintf(fileptr,"(");
			UnparseFormalParams(yyP2->Module.FormalParams);
			fprintf(fileptr,") ");
			}
		fprintf(fileptr," is");
		IncLineDown(); fprintf(fileptr,"%s%s",linedown,leftmargin);
		
		UnparseDeclList(yyP2->Module.DeclList,VERT);
		fprintf(fileptr,"%s%s",linedown,leftmargin);
		fprintf(fileptr,"end ");
		LocalWriteIdPos(yyP2->Module.Ident);
		if (Tree_IsType(yyP2->Module.Next,kModule))
			{fprintf(fileptr,";\n");
			UnparseModuleList(yyP2->Module.Next);}
		
  }
   return;

  }
;
}

static void UnparseFormalParams
# if defined __STDC__ | defined __cplusplus
(register tTree yyP3)
# else
(yyP3)
 register tTree yyP3;
# endif
{
  if (yyP3->Kind == kNoParam) {
/* line 128 "sumabs2sum.puma" */
   return;

  }
  if (yyP3->Kind == kTyParam) {
/* line 129 "sumabs2sum.puma" */
  {
/* line 130 "sumabs2sum.puma" */
LocalWriteIdPos(yyP3->TyParam.Ident);
		if (Tree_IsType(yyP3->TyParam.Next,kParam))
			{fprintf(fileptr,",");
			UnparseFormalParams(yyP3->TyParam.Next);
			}
  }
   return;

  }
;
}

static void UnparseNextDecl
# if defined __STDC__ | defined __cplusplus
(register tTree rest, int ind)
# else
(rest, ind)
 register tTree rest;
 int ind;
# endif
{
/* line 138 "sumabs2sum.puma" */
  {
/* line 139 "sumabs2sum.puma" */
if (Tree_IsType(rest,kDecl))
			{if (ind==INLINE) 
				fprintf(fileptr,"; ");
			else
				fprintf(fileptr,";%s%s",linedown,leftmargin);
			UnparseDeclList(rest,ind);}
  }
   return;

;
}

static void UnparseDeclList
# if defined __STDC__ | defined __cplusplus
(register tTree yyP4, int ind)
# else
(yyP4, ind)
 register tTree yyP4;
 int ind;
# endif
{

  switch (yyP4->Kind) {
  case kNoDecl:
/* line 148 "sumabs2sum.puma" */
   return;

  case kVarDecl:
/* line 149 "sumabs2sum.puma" */
  {
/* line 150 "sumabs2sum.puma" */
UnparseIdList(yyP4->VarDecl.IdList);
		fprintf(fileptr," : ");
		UnparseExpressionList(yyP4->VarDecl.Exp);
		UnparseNextDecl(yyP4->VarDecl.Next,ind);
  }
   return;

  case kGivenSet:
/* line 154 "sumabs2sum.puma" */
  {
/* line 155 "sumabs2sum.puma" */
fprintf(fileptr,"[");
		UnparseIdList(yyP4->GivenSet.IdList);
		fprintf(fileptr,"]");
		UnparseNextDecl(yyP4->GivenSet.Next,ind);
  }
   return;

  case kAxiomDecl:
/* line 159 "sumabs2sum.puma" */
  {
/* line 160 "sumabs2sum.puma" */
fprintf(fileptr,"axiom ");
		
		if (Tree_IsType(yyP4->AxiomDecl.FormalParams,kParam))
			{fprintf(fileptr,"[");
			UnparseFormalParams(yyP4->AxiomDecl.FormalParams);
			fprintf(fileptr,"]");
			}
		DecLineDown();
		
		if (Tree_IsType(yyP4->AxiomDecl.DeclList,kDecl))
			{fprintf(fileptr," is%s%sdec  ",linedown,leftmargin);
			IncLeftMargin(5);
			UnparseDeclList(yyP4->AxiomDecl.DeclList,ind);
			DecLeftMargin(5);}
		
		if (Tree_IsType(yyP4->AxiomDecl.PredList,kPred))
			{fprintf(fileptr,"%s%spred ",linedown,leftmargin);
			IncLeftMargin(5);
			UnparsePredList(yyP4->AxiomDecl.PredList,VERT);
			DecLeftMargin(5);}
		fprintf(fileptr,"%s%send",linedown,leftmargin);
		IncLineDown();
		UnparseNextDecl(yyP4->AxiomDecl.Next,ind);
  }
   return;

  case kSchemaDef:
/* line 183 "sumabs2sum.puma" */
  {
/* line 184 "sumabs2sum.puma" */
fprintf(fileptr,"schema ");
		LocalWriteIdPos(yyP4->SchemaDef.Ident);
		
		if (Tree_IsType(yyP4->SchemaDef.FormalParams,kParam))
			{fprintf(fileptr,"[");
			UnparseFormalParams(yyP4->SchemaDef.FormalParams);
			fprintf(fileptr,"]");
			}
		DecLineDown();
		fprintf(fileptr," is%s%s",linedown,leftmargin);
		
		if (Tree_IsType(yyP4->SchemaDef.DeclList,kDecl))
			{fprintf(fileptr,"dec  ");
			IncLeftMargin(5);
			UnparseDeclList(yyP4->SchemaDef.DeclList,ind);
			DecLeftMargin(5);}
		
		if (Tree_IsType(yyP4->SchemaDef.PredList,kPred))
			{fprintf(fileptr,"%s%spred ",linedown,leftmargin);
			IncLeftMargin(5);
			UnparsePredList(yyP4->SchemaDef.PredList,VERT);
			DecLeftMargin(5);}
		fprintf(fileptr,"%s%send ",linedown,leftmargin);
		LocalWriteIdPos(yyP4->SchemaDef.Ident);
		IncLineDown();
		UnparseNextDecl(yyP4->SchemaDef.Next,ind);
  }
   return;

  case kAbbreviation:
/* line 210 "sumabs2sum.puma" */
  {
/* line 211 "sumabs2sum.puma" */
LocalWriteIdPos(yyP4->Abbreviation.Ident);
		fprintf(fileptr," == ");
		UnparseExpressionList(yyP4->Abbreviation.Exp);
		UnparseNextDecl(yyP4->Abbreviation.Next,ind);
  }
   return;

  case kFreeType:
/* line 215 "sumabs2sum.puma" */
  {
/* line 216 "sumabs2sum.puma" */
LocalWriteIdPos(yyP4->FreeType.Ident);
		fprintf(fileptr," ::= ");
		UnparseBranchList(yyP4->FreeType.BranchList);
		UnparseNextDecl(yyP4->FreeType.Next,ind);
  }
   return;

  case kConstraint:
/* line 220 "sumabs2sum.puma" */
  {
/* line 221 "sumabs2sum.puma" */
UnparsePredList(yyP4->Constraint.Pred,VERT);
		UnparseNextDecl(yyP4->Constraint.Next,ind);
  }
   return;

  case kSchemaIncl:
/* line 223 "sumabs2sum.puma" */
  {
/* line 224 "sumabs2sum.puma" */
UnparseSchemaIdList(yyP4->SchemaIncl.IdList);
		if (Tree_IsType(yyP4->SchemaIncl.ExpressionList,kExp))
			{fprintf(fileptr,"[");
			UnparseExpressionList(yyP4->SchemaIncl.ExpressionList);
			fprintf(fileptr,"]");}
		UnparseNextDecl(yyP4->SchemaIncl.Next,ind);
  }
   return;

  case kModuleDecl:
/* line 230 "sumabs2sum.puma" */
  {
/* line 231 "sumabs2sum.puma" */
DecLineDown();
		UnparseModuleList(yyP4->ModuleDecl.Module);
		UnparseNextDecl(yyP4->ModuleDecl.Next,ind);
  }
   return;

  case kVisibility:
/* line 234 "sumabs2sum.puma" */
  {
/* line 235 "sumabs2sum.puma" */
char str[256];
		GetString(yyP4->Visibility.Ident.Ident,str);
		fprintf(fileptr,"visible %s ",str);
		if (Tree_IsType(yyP4->Visibility.SelectionList,kSelection))
			{fprintf(fileptr,"[");
			UnparseSelectionList(yyP4->Visibility.SelectionList);
			fprintf(fileptr,"]");}
		UnparseNextDecl(yyP4->Visibility.Next,ind);
  }
   return;

  case kImport:
/* line 243 "sumabs2sum.puma" */
  {
/* line 244 "sumabs2sum.puma" */
char str[256];
		GetString(yyP4->Import.Ident.Ident,str);
		fprintf(fileptr,"import %s ",str);
		if (Tree_IsType(yyP4->Import.ExpressionList,kExp))
			{fprintf(fileptr,"(");
			UnparseExpressionList(yyP4->Import.ExpressionList);
			fprintf(fileptr,")");}
		if (Tree_IsType(yyP4->Import.RenameList,kRename))
			{fprintf(fileptr,"(");
			UnparseRenameList(yyP4->Import.RenameList);
			fprintf(fileptr,")");}
		GetString(yyP4->Import.NewIdent.Ident,str);
		if (strcmp("",str)!=0)
			fprintf(fileptr," as %s ",str);
		UnparseNextDecl(yyP4->Import.Next,ind);
  }
   return;

  }

/* line 259 "sumabs2sum.puma" */
   return;

;
}

static void UnparseSelectionList
# if defined __STDC__ | defined __cplusplus
(register tTree yyP5)
# else
(yyP5)
 register tTree yyP5;
# endif
{
  if (yyP5->Kind == kNoSelection) {
/* line 263 "sumabs2sum.puma" */
   return;

  }
  if (yyP5->Kind == kSelection) {
/* line 264 "sumabs2sum.puma" */
  {
/* line 265 "sumabs2sum.puma" */
LocalWriteIdPos(yyP5->Selection.Ident);
		if (Tree_IsType(yyP5->Selection.Next,kSelection))
			{fprintf(fileptr,",");
			UnparseSelectionList(yyP5->Selection.Next);}
  }
   return;

  }
;
}

void UnparseIdList
# if defined __STDC__ | defined __cplusplus
(register tTree yyP6)
# else
(yyP6)
 register tTree yyP6;
# endif
{
  if (yyP6->Kind == kNoId) {
/* line 272 "sumabs2sum.puma" */
   return;

  }
  if (yyP6->Kind == kId) {
/* line 273 "sumabs2sum.puma" */
  {
/* line 274 "sumabs2sum.puma" */
LocalWriteIdPos(yyP6->Id.Ident);
		if (Tree_IsType(yyP6->Id.Next,kId))
			{fprintf(fileptr,",");
			UnparseIdList(yyP6->Id.Next);}
  }
   return;

  }
;
}

static void UnparseSchemaIdList
# if defined __STDC__ | defined __cplusplus
(register tTree yyP7)
# else
(yyP7)
 register tTree yyP7;
# endif
{
  if (yyP7->Kind == kNoId) {
/* line 281 "sumabs2sum.puma" */
   return;

  }
  if (yyP7->Kind == kId) {
/* line 282 "sumabs2sum.puma" */
  {
/* line 283 "sumabs2sum.puma" */
LocalWriteIdPos(yyP7->Id.Ident);
		if (Tree_IsType(yyP7->Id.Next,kId))
			{fprintf(fileptr,".");
			UnparseSchemaIdList(yyP7->Id.Next);}
  }
   return;

  }
;
}

static void UnparseNextExp
# if defined __STDC__ | defined __cplusplus
(register tTree rest)
# else
(rest)
 register tTree rest;
# endif
{
/* line 290 "sumabs2sum.puma" */
  {
/* line 291 "sumabs2sum.puma" */
if (Tree_IsType(rest,kExp))
			{fprintf(fileptr,",");
			UnparseExpressionList(rest);}
  }
   return;

;
}

static void UnparseExpressionList
# if defined __STDC__ | defined __cplusplus
(register tTree elist)
# else
(elist)
 register tTree elist;
# endif
{

  switch (elist->Kind) {
  case kNoExp:
/* line 297 "sumabs2sum.puma" */
   return;

  case kVariable:
/* line 298 "sumabs2sum.puma" */
  {
/* line 299 "sumabs2sum.puma" */
UnparseSchemaIdList(elist->Variable.IdList);
		UnparseNextExp(elist->Variable.Next);
  }
   return;

  case kExp_SchemaRef:
/* line 301 "sumabs2sum.puma" */
  {
/* line 302 "sumabs2sum.puma" */
UnparseSchemaIdList(elist->Exp_SchemaRef.IdList);
		
		if (Tree_IsType(elist->Exp_SchemaRef.ExpressionList,kExp))
			{fprintf(fileptr,"[");
			UnparseExpressionList(elist->Exp_SchemaRef.ExpressionList);
			fprintf(fileptr,"]");}
		UnparseNextExp(elist->Exp_SchemaRef.Next);
  }
   return;

  case kLiteral:
/* line 309 "sumabs2sum.puma" */
  {
/* line 310 "sumabs2sum.puma" */
LocalWriteIdPos(elist->Literal.Literal);
		UnparseNextExp(elist->Literal.Next);
  }
   return;

  case kPrefixOp:
/* line 312 "sumabs2sum.puma" */
  {
/* line 313 "sumabs2sum.puma" */
char str[256];
		GetString(elist->PrefixOp.Prefix.Ident,str);
		fprintf(fileptr,"%s ",str);
		if (NeedsPrefixBrackets(elist->PrefixOp.Exp))
			{fprintf(fileptr,"( ");
			UnparseExpressionList(elist->PrefixOp.Exp);
			fprintf(fileptr," ) ");}
		else 
			UnparseExpressionList(elist->PrefixOp.Exp);
		UnparseNextExp(elist->PrefixOp.Next);
  }
   return;

  case kLambda:
/* line 323 "sumabs2sum.puma" */
  {
/* line 324 "sumabs2sum.puma" */
fprintf(fileptr,"(lambda ");
		UnparseSchema(elist->Lambda.SchemaText);
		fprintf(fileptr,"@ ");
		UnparseExpressionList(elist->Lambda.Exp);
		fprintf(fileptr," )");
		UnparseNextExp(elist->Lambda.Next);
  }
   return;

  case kMu:
/* line 330 "sumabs2sum.puma" */
  {
/* line 331 "sumabs2sum.puma" */
fprintf(fileptr,"(mu ");
		UnparseSchema(elist->Mu.SchemaText);
		if (Tree_IsType(elist->Mu.ExpressionList,kExp))
			{fprintf(fileptr," @ ");
			UnparseExpressionList(elist->Mu.ExpressionList);}
		fprintf(fileptr," )");
		UnparseNextExp(elist->Mu.Next);
  }
   return;

  case kTheta:
/* line 338 "sumabs2sum.puma" */
  {
/* line 339 "sumabs2sum.puma" */
fprintf(fileptr,"theta ");
		UnparseExpressionList(elist->Theta.Exp);
		UnparseNextExp(elist->Theta.Next);
  }
   return;

  case kVarSelection:
/* line 342 "sumabs2sum.puma" */
  {
/* line 343 "sumabs2sum.puma" */
UnparseExpressionList(elist->VarSelection.Exp);
		fprintf(fileptr,".");
		LocalWriteIdPos(elist->VarSelection.Ident);
		UnparseNextExp(elist->VarSelection.Next);
  }
   return;

  case kIfExp:
/* line 347 "sumabs2sum.puma" */
  {
/* line 348 "sumabs2sum.puma" */
fprintf(fileptr,"if ");
		UnparsePredList(elist->IfExp.Con,INLINE);
		fprintf(fileptr," then ");
		UnparseExpressionList(elist->IfExp.Then);
		if (Tree_IsType(elist->IfExp.Else,kExp))
			{fprintf(fileptr," else ");
			UnparseExpressionList(elist->IfExp.Else);}
		fprintf(fileptr," fi");
		UnparseNextExp(elist->IfExp.Next);
  }
   return;

  case kFncApplication:
/* line 357 "sumabs2sum.puma" */
  {
/* line 358 "sumabs2sum.puma" */
UnparseExpressionList(elist->FncApplication.Fnc);
		if (Tree_IsType(elist->FncApplication.Arg,kExp))
			{fprintf(fileptr,"(");
			UnparseExpressionList(elist->FncApplication.Arg);
			fprintf(fileptr,")");}
		UnparseNextExp(elist->FncApplication.Next);
  }
   return;

  case kSetComp:
/* line 364 "sumabs2sum.puma" */
  {
/* line 365 "sumabs2sum.puma" */
fprintf(fileptr,"{ ");
		
		UnparseSchema(elist->SetComp.SchemaText);
		if (Tree_IsType(elist->SetComp.ExpressionList,kExp))
		
			{fprintf(fileptr," @ ");
			UnparseExpressionList(elist->SetComp.ExpressionList);}
		fprintf(fileptr,"}");
		UnparseNextExp(elist->SetComp.Next);
  }
   return;

  case kSetElab:
/* line 374 "sumabs2sum.puma" */
  {
/* line 375 "sumabs2sum.puma" */
fprintf(fileptr,"{");
		if (Tree_IsType(elist->SetElab.ExpressionList,kExp))
			UnparseExpressionList(elist->SetElab.ExpressionList);
		fprintf(fileptr,"}");
		UnparseNextExp(elist->SetElab.Next);
  }
   return;

  case kSequence:
/* line 380 "sumabs2sum.puma" */
  {
/* line 381 "sumabs2sum.puma" */
fprintf(fileptr,"<");
		if (Tree_IsType(elist->Sequence.ExpressionList,kExp))
			UnparseExpressionList(elist->Sequence.ExpressionList);
		fprintf(fileptr,">");
		UnparseNextExp(elist->Sequence.Next);
  }
   return;

  case kBag:
/* line 386 "sumabs2sum.puma" */
  {
/* line 387 "sumabs2sum.puma" */
fprintf(fileptr,"[[");
		if (Tree_IsType(elist->Bag.ExpressionList,kExp))
			UnparseExpressionList(elist->Bag.ExpressionList);
		fprintf(fileptr,"]]");
		UnparseNextExp(elist->Bag.Next);
  }
   return;

  case kCartProd:
/* line 392 "sumabs2sum.puma" */
  {
/* line 393 "sumabs2sum.puma" */
CrossProdFromExp(elist->CartProd.ExpressionList);
		UnparseNextExp(elist->CartProd.Next);
  }
   return;

  case kTuple:
/* line 395 "sumabs2sum.puma" */
  {
/* line 396 "sumabs2sum.puma" */
fprintf(fileptr,"(");
		UnparseExpressionList(elist->Tuple.ExpressionList);
		fprintf(fileptr,")");
		UnparseNextExp(elist->Tuple.Next);
  }
   return;

  case kInfixOp:
/* line 400 "sumabs2sum.puma" */
  {
/* line 401 "sumabs2sum.puma" */
if (IsInfun(elist->InfixOp.Infix.Ident))
			if (NeedsInFunBrackets(elist->InfixOp.Op1))
				{fprintf(fileptr,"(");
				UnparseExpressionList(elist->InfixOp.Op1);
				fprintf(fileptr,")");}
		else if (IsIngen(elist->InfixOp.Infix.Ident))
			if (NeedsInGenBrackets(elist->InfixOp.Op1))
				{fprintf(fileptr,"(");
				UnparseExpressionList(elist->InfixOp.Op1);
				fprintf(fileptr,")");}
		else UnparseExpressionList(elist->InfixOp.Op1);
		fprintf(fileptr," ");	
		LocalWriteIdPos(elist->InfixOp.Infix);
		fprintf(fileptr," ");
		if (IsInfun(elist->InfixOp.Infix.Ident))
			if (NeedsInFunBrackets(elist->InfixOp.Op2))
				{fprintf(fileptr,"(");
				UnparseExpressionList(elist->InfixOp.Op2);
				fprintf(fileptr,")");}
		else if (IsIngen(elist->InfixOp.Infix.Ident))
			if (NeedsInGenBrackets(elist->InfixOp.Op2))
				{fprintf(fileptr,"(");
				UnparseExpressionList(elist->InfixOp.Op2);
				fprintf(fileptr,")");}
		else
			UnparseExpressionList(elist->InfixOp.Op2);
		UnparseNextExp(elist->InfixOp.Next);
  }
   return;

  case kPredExp:
/* line 428 "sumabs2sum.puma" */
  {
/* line 429 "sumabs2sum.puma" */
fprintf(fileptr,"(");
		UnparsePredList(elist->PredExp.Pred,INLINE);
		fprintf(fileptr,")");
		UnparseNextExp(elist->PredExp.Next);
  }
   return;

  }

/* line 433 "sumabs2sum.puma" */
   return;

;
}

static void UnparseNextPred
# if defined __STDC__ | defined __cplusplus
(register tTree rest, int ind)
# else
(rest, ind)
 register tTree rest;
 int ind;
# endif
{
/* line 437 "sumabs2sum.puma" */
  {
/* line 438 "sumabs2sum.puma" */
if (Tree_IsType(rest,kPred))
			{if (ind==INLINE)
			   fprintf(fileptr," and ");
			else
			   fprintf(fileptr,"; %s%s",linedown,leftmargin);
			UnparsePredList(rest,ind);}
  }
   return;

;
}

static void UnparsePredList
# if defined __STDC__ | defined __cplusplus
(register tTree yyP8, int ind)
# else
(yyP8, ind)
 register tTree yyP8;
 int ind;
# endif
{

  switch (yyP8->Kind) {
  case kNoPred:
/* line 447 "sumabs2sum.puma" */
   return;

  case kQuantPred:
/* line 448 "sumabs2sum.puma" */
  {
/* line 449 "sumabs2sum.puma" */
fprintf(fileptr,"(");
		LocalWriteIdPos(yyP8->QuantPred.LogQuant);
		fprintf(fileptr," ");
		UnparseSchema(yyP8->QuantPred.SchemaText);
		fprintf(fileptr," @ ");
		UnparsePredList(yyP8->QuantPred.Pred,INLINE);
		fprintf(fileptr,")");
		UnparseNextPred(yyP8->QuantPred.Next,ind);
  }
   return;

  case kRelBinPred:
/* line 457 "sumabs2sum.puma" */
  {
/* line 458 "sumabs2sum.puma" */


		UnparseExpressionList(yyP8->RelBinPred.L);
		fprintf(fileptr," ");	
		LocalWriteIdPos(yyP8->RelBinPred.RelBinOp);
		fprintf(fileptr," ");
		UnparseExpressionList(yyP8->RelBinPred.R);
		UnparseNextPred(yyP8->RelBinPred.Next,ind);
  }
   return;

  case kRelPrePred:
/* line 480 "sumabs2sum.puma" */
  {
/* line 481 "sumabs2sum.puma" */
LocalWriteIdPos(yyP8->RelPrePred.RelPreOp);
		fprintf(fileptr," ");
		UnparseExpressionList(yyP8->RelPrePred.Exp);
		UnparseNextPred(yyP8->RelPrePred.Next,ind);
  }
   return;

  case kLogBinPred:
/* line 485 "sumabs2sum.puma" */
  {
/* line 486 "sumabs2sum.puma" */
UnparsePredList(yyP8->LogBinPred.L,ind);
		fprintf(fileptr," ");
		UnparseLogBinOp(yyP8->LogBinPred.LogBinOp,ind);
		fprintf(fileptr," ");
		UnparsePredList(yyP8->LogBinPred.R,ind);
		UnparseNextPred(yyP8->LogBinPred.Next,ind);
  }
   return;

  case kLogicalNot:
/* line 492 "sumabs2sum.puma" */
  {
/* line 493 "sumabs2sum.puma" */
fprintf(fileptr,"not ");
		UnparsePredList(yyP8->LogicalNot.Pred,ind);
		UnparseNextPred(yyP8->LogicalNot.Next,ind);
  }
   return;

  case kPreCondPred:
/* line 496 "sumabs2sum.puma" */
  {
/* line 497 "sumabs2sum.puma" */
fprintf(fileptr,"pre ");
		UnparsePredList(yyP8->PreCondPred.Pred,ind);
		UnparseNextPred(yyP8->PreCondPred.Next,ind);
  }
   return;

  case kIfPred:
/* line 500 "sumabs2sum.puma" */
  {
/* line 501 "sumabs2sum.puma" */
fprintf(fileptr,"if ");
		UnparsePredList(yyP8->IfPred.Con,ind);
		fprintf(fileptr," then ");
		UnparsePredList(yyP8->IfPred.Then,ind);
		fprintf(fileptr," else ");
		UnparsePredList(yyP8->IfPred.Else,ind);
		UnparseNextPred(yyP8->IfPred.Next,ind);
  }
   return;

  case kChgOnly:
/* line 508 "sumabs2sum.puma" */
  {
/* line 509 "sumabs2sum.puma" */
fprintf(fileptr,"changes_only{");
		UnparseNameList(yyP8->ChgOnly.NameList);
		fprintf(fileptr,"}");
		UnparseNextPred(yyP8->ChgOnly.Next,ind);
  }
   return;

  case kSchemaPred:
/* line 513 "sumabs2sum.puma" */
  {
/* line 514 "sumabs2sum.puma" */
UnparseSchema(yyP8->SchemaPred.Schema);
		UnparseNextPred(yyP8->SchemaPred.Next,ind);
  }
   return;

  case kBoolValue:
/* line 516 "sumabs2sum.puma" */
  {
/* line 517 "sumabs2sum.puma" */
LocalWriteIdPos(yyP8->BoolValue.Ident);
		UnparseNextPred(yyP8->BoolValue.Next,ind);
  }
   return;

  }

/* line 519 "sumabs2sum.puma" */
   return;

;
}

static void UnparseLogBinOp
# if defined __STDC__ | defined __cplusplus
(register tTree yyP9, int ind)
# else
(yyP9, ind)
 register tTree yyP9;
 int ind;
# endif
{
  if (yyP9->Kind == kLogSeq) {
/* line 523 "sumabs2sum.puma" */
  {
/* line 524 "sumabs2sum.puma" */
if (ind==VERT)
			fprintf(fileptr,";%s%s",linedown,leftmargin);
		else
			fprintf(fileptr,"; ");
  }
   return;

  }
  if (yyP9->Kind == kLogAnd) {
/* line 528 "sumabs2sum.puma" */
  {
/* line 528 "sumabs2sum.puma" */
fprintf(fileptr," and ");
  }
   return;

  }
  if (yyP9->Kind == kLogOr) {
/* line 529 "sumabs2sum.puma" */
  {
/* line 529 "sumabs2sum.puma" */
fprintf(fileptr," or ");
  }
   return;

  }
  if (yyP9->Kind == kLogImply) {
/* line 530 "sumabs2sum.puma" */
  {
/* line 530 "sumabs2sum.puma" */
fprintf(fileptr," => ");
  }
   return;

  }
  if (yyP9->Kind == kLogEquiv) {
/* line 531 "sumabs2sum.puma" */
  {
/* line 531 "sumabs2sum.puma" */
fprintf(fileptr," <=> ");
  }
   return;

  }
/* line 532 "sumabs2sum.puma" */
   return;

;
}

static void UnparseBranchList
# if defined __STDC__ | defined __cplusplus
(register tTree b)
# else
(b)
 register tTree b;
# endif
{
  if (b->Kind == kFTConstant) {
/* line 536 "sumabs2sum.puma" */
  {
/* line 537 "sumabs2sum.puma" */
LocalWriteIdPos(b->FTConstant.Ident);
		if (Tree_IsType(b->FTConstant.Next,kBranch))
			{fprintf(fileptr," | ");
			UnparseBranchList(b->FTConstant.Next);}
  }
   return;

  }
  if (b->Kind == kFTConstructor) {
/* line 541 "sumabs2sum.puma" */
  {
/* line 542 "sumabs2sum.puma" */
LocalWriteIdPos(b->FTConstructor.Ident);
		fprintf(fileptr,"<<");
		UnparseExpressionList(b->FTConstructor.Exp);
		fprintf(fileptr,">>");
		if (Tree_IsType(b->FTConstructor.Next,kBranch))
			{fprintf(fileptr," | ");
			UnparseBranchList(b->FTConstructor.Next);}
  }
   return;

  }
;
}

static void UnparseRenameList
# if defined __STDC__ | defined __cplusplus
(register tTree yyP10)
# else
(yyP10)
 register tTree yyP10;
# endif
{
  if (yyP10->Kind == kNoRename) {
/* line 552 "sumabs2sum.puma" */
   return;

  }
  if (yyP10->Kind == kRename) {
/* line 553 "sumabs2sum.puma" */
  {
/* line 554 "sumabs2sum.puma" */
LocalWriteIdPos(yyP10->Rename.NewIdent);
		fprintf(fileptr,"/");
		UnparseSchemaIdList(yyP10->Rename.OldIdent);
		if (Tree_IsType(yyP10->Rename.Next,kRename))
			{fprintf(fileptr,",");
			UnparseRenameList(yyP10->Rename.Next);}
  }
   return;

  }
;
}

static void CrossProdFromNextExp
# if defined __STDC__ | defined __cplusplus
(register tTree rest)
# else
(rest)
 register tTree rest;
# endif
{
/* line 563 "sumabs2sum.puma" */
  {
/* line 564 "sumabs2sum.puma" */
if (Tree_IsType(rest,kExp))
			{fprintf(fileptr," cross ");
			CrossProdFromExp(rest);};
  }
   return;

;
}

static void CrossProdFromExp
# if defined __STDC__ | defined __cplusplus
(register tTree elist)
# else
(elist)
 register tTree elist;
# endif
{

  switch (elist->Kind) {
  case kNoExp:
/* line 570 "sumabs2sum.puma" */
   return;

  case kPredExp:
/* line 571 "sumabs2sum.puma" */
  {
/* line 572 "sumabs2sum.puma" */
UnparsePredList(elist->PredExp.Pred,INLINE);
		CrossProdFromNextExp(elist->PredExp.Next);
  }
   return;

  case kInfixOp:
/* line 574 "sumabs2sum.puma" */
  {
/* line 575 "sumabs2sum.puma" */
if (NeedsCrossBrackets(elist))
			fprintf(fileptr,"(");
		if (IsInfun(elist->InfixOp.Infix.Ident))
			if (NeedsInFunBrackets(elist->InfixOp.Op1))
				{fprintf(fileptr,"(");
				UnparseExpressionList(elist->InfixOp.Op1);
				fprintf(fileptr,")");}
		else if (IsIngen(elist->InfixOp.Infix.Ident))
			if (NeedsInGenBrackets(elist->InfixOp.Op1))
				{fprintf(fileptr,"(");
				UnparseExpressionList(elist->InfixOp.Op1);
				fprintf(fileptr,")");}
		else UnparseExpressionList(elist->InfixOp.Op1);
		fprintf(fileptr," ");	
		LocalWriteIdPos(elist->InfixOp.Infix);
		fprintf(fileptr," ");
		if (IsInfun(elist->InfixOp.Infix.Ident))
			if (NeedsInFunBrackets(elist->InfixOp.Op2))
				{fprintf(fileptr,"(");
				UnparseExpressionList(elist->InfixOp.Op2);
				fprintf(fileptr,")");}
		else if (IsIngen(elist->InfixOp.Infix.Ident))
			if (NeedsInGenBrackets(elist->InfixOp.Op2))
				{fprintf(fileptr,"(");
				UnparseExpressionList(elist->InfixOp.Op2);
				fprintf(fileptr,")");}
		else
			UnparseExpressionList(elist->InfixOp.Op2);
		if (NeedsCrossBrackets(elist))
			fprintf(fileptr,")");
		CrossProdFromNextExp(elist->InfixOp.Next);
  }
   return;

  case kTuple:
/* line 606 "sumabs2sum.puma" */
  {
/* line 607 "sumabs2sum.puma" */
fprintf(fileptr,"(");
		UnparseExpressionList(elist->Tuple.ExpressionList);
		fprintf(fileptr,")");
		CrossProdFromNextExp(elist->Tuple.Next);
  }
   return;

  case kCartProd:
/* line 611 "sumabs2sum.puma" */
  {
/* line 612 "sumabs2sum.puma" */
fprintf(fileptr,"(");
		CrossProdFromExp(elist->CartProd.ExpressionList);
		fprintf(fileptr,")");
		CrossProdFromNextExp(elist->CartProd.Next);
  }
   return;

  case kBag:
/* line 616 "sumabs2sum.puma" */
  {
/* line 617 "sumabs2sum.puma" */
fprintf(fileptr,"[[");
		if (Tree_IsType(elist->Bag.ExpressionList,kExp))
			UnparseExpressionList(elist->Bag.ExpressionList);
		fprintf(fileptr,"]]");
		CrossProdFromNextExp(elist->Bag.Next);
  }
   return;

  case kSequence:
/* line 622 "sumabs2sum.puma" */
  {
/* line 623 "sumabs2sum.puma" */
fprintf(fileptr,"<");
		if (Tree_IsType(elist->Sequence.ExpressionList,kExp))
			UnparseExpressionList(elist->Sequence.ExpressionList);
		fprintf(fileptr,">");
		CrossProdFromNextExp(elist->Sequence.Next);
  }
   return;

  case kSetElab:
/* line 628 "sumabs2sum.puma" */
  {
/* line 629 "sumabs2sum.puma" */
fprintf(fileptr,"{");
		if (Tree_IsType(elist->SetElab.ExpressionList,kExp))
			UnparseExpressionList(elist->SetElab.ExpressionList);
		fprintf(fileptr,"}");
		CrossProdFromNextExp(elist->SetElab.Next);
  }
   return;

  case kSetComp:
/* line 634 "sumabs2sum.puma" */
  {
/* line 635 "sumabs2sum.puma" */
fprintf(fileptr,"{ ");
		
		UnparseSchema(elist->SetComp.SchemaText);
		if (Tree_IsType(elist->SetComp.ExpressionList,kExp))
			{fprintf(fileptr," @ ");
			
			UnparseExpressionList(elist->SetComp.ExpressionList);}
		fprintf(fileptr,"}");
		CrossProdFromNextExp(elist->SetComp.Next);
  }
   return;

  case kFncApplication:
/* line 644 "sumabs2sum.puma" */
  {
/* line 645 "sumabs2sum.puma" */
UnparseExpressionList(elist->FncApplication.Fnc);
		if (Tree_IsType(elist->FncApplication.Arg,kExp))
			{fprintf(fileptr,"(");
			UnparseExpressionList(elist->FncApplication.Arg);
			fprintf(fileptr,")");}
		CrossProdFromNextExp(elist->FncApplication.Next);
  }
   return;

  case kIfExp:
/* line 651 "sumabs2sum.puma" */
  {
/* line 652 "sumabs2sum.puma" */
fprintf(fileptr,"if ");
		UnparsePredList(elist->IfExp.Con,INLINE);
		fprintf(fileptr," then ");
		UnparseExpressionList(elist->IfExp.Then);
		if (Tree_IsType(elist->IfExp.Else,kExp))
			{fprintf(fileptr," else ");
			UnparseExpressionList(elist->IfExp.Else);}
		fprintf(fileptr," fi");
		CrossProdFromNextExp(elist->IfExp.Next);
  }
   return;

  case kVarSelection:
/* line 661 "sumabs2sum.puma" */
  {
/* line 662 "sumabs2sum.puma" */
UnparseExpressionList(elist->VarSelection.Exp);
		fprintf(fileptr," ");
		LocalWriteIdPos(elist->VarSelection.Ident);
		CrossProdFromNextExp(elist->VarSelection.Next);
  }
   return;

  case kMu:
/* line 666 "sumabs2sum.puma" */
  {
/* line 667 "sumabs2sum.puma" */
fprintf(fileptr,"(mu ");
		UnparseSchema(elist->Mu.SchemaText);
		fprintf(fileptr," @ ");
		UnparseExpressionList(elist->Mu.ExpressionList);
		fprintf(fileptr," ) ");
		CrossProdFromNextExp(elist->Mu.Next);
  }
   return;

  case kLambda:
/* line 673 "sumabs2sum.puma" */
  {
/* line 674 "sumabs2sum.puma" */
fprintf(fileptr,"(lambda ");
		UnparseSchema(elist->Lambda.SchemaText);
		fprintf(fileptr,"@ ");
		UnparseExpressionList(elist->Lambda.Exp);
		fprintf(fileptr," ) ");
		CrossProdFromNextExp(elist->Lambda.Next);
  }
   return;

  case kTheta:
/* line 680 "sumabs2sum.puma" */
  {
/* line 681 "sumabs2sum.puma" */
fprintf(fileptr,"theta ");
		UnparseExpressionList(elist->Theta.Exp);
		CrossProdFromNextExp(elist->Theta.Next);
  }
   return;

  case kPrefixOp:
/* line 684 "sumabs2sum.puma" */
  {
/* line 685 "sumabs2sum.puma" */
char str[256];
		GetString(elist->PrefixOp.Prefix.Ident,str);
		fprintf(fileptr,"%s ",str);
		if (NeedsPrefixBrackets(elist->PrefixOp.Exp))
			{fprintf(fileptr,"( ");
			UnparseExpressionList(elist->PrefixOp.Exp);
			fprintf(fileptr," ) ");}
		else 
			UnparseExpressionList(elist->PrefixOp.Exp);
		CrossProdFromNextExp(elist->PrefixOp.Next);
  }
   return;

  case kLiteral:
/* line 695 "sumabs2sum.puma" */
  {
/* line 696 "sumabs2sum.puma" */
LocalWriteIdPos(elist->Literal.Literal);
		CrossProdFromNextExp(elist->Literal.Next);
  }
   return;

  case kExp_SchemaRef:
/* line 698 "sumabs2sum.puma" */
  {
/* line 699 "sumabs2sum.puma" */
UnparseIdList(elist->Exp_SchemaRef.IdList);
		
		if (Tree_IsType(elist->Exp_SchemaRef.ExpressionList,kExp))
			{fprintf(fileptr,"[");
			UnparseExpressionList(elist->Exp_SchemaRef.ExpressionList);
			fprintf(fileptr,"]");}
		CrossProdFromNextExp(elist->Exp_SchemaRef.Next);
  }
   return;

  case kVariable:
/* line 706 "sumabs2sum.puma" */
  {
/* line 707 "sumabs2sum.puma" */
UnparseSchemaIdList(elist->Variable.IdList);
		CrossProdFromNextExp(elist->Variable.Next);
  }
   return;

  }

/* line 709 "sumabs2sum.puma" */
   return;

;
}

static void UnparseNameList
# if defined __STDC__ | defined __cplusplus
(register tTree yyP11)
# else
(yyP11)
 register tTree yyP11;
# endif
{
  if (yyP11->Kind == kNoName) {
/* line 713 "sumabs2sum.puma" */
   return;

  }
  if (yyP11->Kind == kName) {
/* line 714 "sumabs2sum.puma" */
  {
/* line 715 "sumabs2sum.puma" */
UnparseIdList(yyP11->Name.IdList);
		if (Tree_IsType(yyP11->Name.Next,kName))
			{fprintf(fileptr,",");
			UnparseNameList(yyP11->Name.Next);}
  }
   return;

  }
;
}

static void UnparseSchema
# if defined __STDC__ | defined __cplusplus
(register tTree yyP12)
# else
(yyP12)
 register tTree yyP12;
# endif
{

  switch (yyP12->Kind) {
  case kExpPred:
/* line 722 "sumabs2sum.puma" */
  {
/* line 722 "sumabs2sum.puma" */
   UnparseExpressionList (yyP12->ExpPred.Exp);
  }
   return;

  case kSchemaText:
/* line 723 "sumabs2sum.puma" */
  {
/* line 724 "sumabs2sum.puma" */
UnparseDeclList(yyP12->SchemaText.DeclList,INLINE);
		if (Tree_IsType(yyP12->SchemaText.PredList,kPred))
			{fprintf(fileptr," | ");
			UnparsePredList(yyP12->SchemaText.PredList,INLINE);}
  }
   return;

  case kSchemaRef:
/* line 728 "sumabs2sum.puma" */
  {
/* line 729 "sumabs2sum.puma" */
UnparseIdList(yyP12->SchemaRef.IdList);
		if (Tree_IsType(yyP12->SchemaRef.ExpressionList,kExp))
			{fprintf(fileptr,"[");
			UnparseExpressionList(yyP12->SchemaRef.ExpressionList);
			fprintf(fileptr,"]");}
  }
   return;

  case kSchemaCons:
/* line 734 "sumabs2sum.puma" */
  {
/* line 735 "sumabs2sum.puma" */
UnparseBoxedSchemaText(yyP12->SchemaCons.L);
		fprintf(fileptr," ");
		UnparseLogOp(yyP12->SchemaCons.LogOp);
		fprintf(fileptr," ");
		UnparseBoxedSchemaText(yyP12->SchemaCons.R);
  }
   return;

  case kSchemaCompos:
/* line 740 "sumabs2sum.puma" */
  {
/* line 741 "sumabs2sum.puma" */
UnparseBoxedSchemaText(yyP12->SchemaCompos.Sch1);
		fprintf(fileptr," ");
		LocalWriteIdPos(yyP12->SchemaCompos.Compos);
		fprintf(fileptr," ");
		UnparseBoxedSchemaText(yyP12->SchemaCompos.Sch2);
  }
   return;

  case kSchemaProj:
/* line 746 "sumabs2sum.puma" */
  {
/* line 747 "sumabs2sum.puma" */
UnparseBoxedSchemaText(yyP12->SchemaProj.Sch1);
		fprintf(fileptr," ");
		LocalWriteIdPos(yyP12->SchemaProj.Proj);
		fprintf(fileptr," ");
		UnparseBoxedSchemaText(yyP12->SchemaProj.Sch2);
  }
   return;

  case kSchemaSubst:
/* line 752 "sumabs2sum.puma" */
  {
/* line 753 "sumabs2sum.puma" */
UnparseBoxedSchemaText(yyP12->SchemaSubst.Schema);
		fprintf(fileptr,"{");
		UnparseRenameList(yyP12->SchemaSubst.RenameList);
		fprintf(fileptr,"}");
  }
   return;

  case kSchemaHiding:
/* line 757 "sumabs2sum.puma" */
  {
/* line 758 "sumabs2sum.puma" */
UnparseBoxedSchemaText(yyP12->SchemaHiding.Schema);
		fprintf(fileptr,"\\(");
		UnparseNameList(yyP12->SchemaHiding.NameList);
		fprintf(fileptr,")");
  }
   return;

  }

/* line 762 "sumabs2sum.puma" */
   return;

;
}

static void UnparseBoxedSchemaText
# if defined __STDC__ | defined __cplusplus
(register tTree s)
# else
(s)
 register tTree s;
# endif
{
  if (s->Kind == kSchemaText) {
/* line 766 "sumabs2sum.puma" */
  {
/* line 767 "sumabs2sum.puma" */
fprintf(fileptr,"[ ");
		UnparseSchema(s);
		fprintf(fileptr,"]");
  }
   return;

  }
/* line 770 "sumabs2sum.puma" */
  {
/* line 770 "sumabs2sum.puma" */
   UnparseSchema (s);
  }
   return;

;
}

static void UnparseLogOp
# if defined __STDC__ | defined __cplusplus
(register tTree yyP13)
# else
(yyP13)
 register tTree yyP13;
# endif
{
  if (yyP13->Kind == kSDisjunction) {
/* line 775 "sumabs2sum.puma" */
  {
/* line 775 "sumabs2sum.puma" */
fprintf(fileptr,"or");
  }
   return;

  }
  if (yyP13->Kind == kSConjunction) {
/* line 776 "sumabs2sum.puma" */
  {
/* line 776 "sumabs2sum.puma" */
fprintf(fileptr,"and");
  }
   return;

  }
  if (yyP13->Kind == kSImplication) {
/* line 777 "sumabs2sum.puma" */
  {
/* line 777 "sumabs2sum.puma" */
fprintf(fileptr,"=>");
  }
   return;

  }
  if (yyP13->Kind == kSEquivalence) {
/* line 778 "sumabs2sum.puma" */
  {
/* line 778 "sumabs2sum.puma" */
fprintf(fileptr,"<=>");
  }
   return;

  }
;
}

static bool IsInfun
# if defined __STDC__ | defined __cplusplus
(tIdent id)
# else
(id)
 tIdent id;
# endif
{
/* line 788 "sumabs2sum.puma" */
  {
/* line 789 "sumabs2sum.puma" */
char str[IDENT_LENGTH];
	int ok=0;
	GetString(id,str);
	if (strcmp(str,"..")) ok=1;
	else if (strcmp(str,"^")) ok=1;
	else if (strcmp(str,"|-->")) ok=1;
	else if (strcmp(str,"bag_union")) ok=1;
	else if (strcmp(str,"inter")) ok=1;
	else if (strcmp(str,"union")) ok=1;
	else if (strcmp(str,"diff")) ok=1;
	else if (strcmp(str,"f_compose")) ok=1;
	else if (strcmp(str,"b_compose")) ok=1;
        else if (strcmp(str,"func_override")) ok=1;
	else if (strcmp(str,"dom_restrict")) ok=1;
	else if (strcmp(str,"ran_restrict")) ok=1;
	else if (strcmp(str,"dom_subtract")) ok=1;
	else if (strcmp(str,"ran_subtract")) ok=1;
/* line 806 "sumabs2sum.puma" */
   if (! ((ok == 1))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

static bool IsIngen
# if defined __STDC__ | defined __cplusplus
(tIdent id)
# else
(id)
 tIdent id;
# endif
{
/* line 811 "sumabs2sum.puma" */
  {
/* line 812 "sumabs2sum.puma" */
char str[IDENT_LENGTH];
	int ok=0;
	GetString(id,str);
	if (strcmp(str,"<-->")) ok=1;
	else if (strcmp(str,"-|->")) ok=1;
	else if (strcmp(str,"-->")) ok=1;
	else if (strcmp(str,">-|->")) ok=1;
	else if (strcmp(str,">-->")) ok=1;
	else if (strcmp(str,"-|->>")) ok=1;
	else if (strcmp(str,"-->>")) ok=1;
	else if (strcmp(str,">-->>")) ok=1;
	else if (strcmp(str,"-||->")) ok=1;
	else if (strcmp(str,">-||->")) ok=1;
/* line 825 "sumabs2sum.puma" */
   if (! ((ok == 1))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

static bool NeedsPrefixBrackets
# if defined __STDC__ | defined __cplusplus
(register tTree yyP14)
# else
(yyP14)
 register tTree yyP14;
# endif
{
  if (yyP14->Kind == kInfixOp) {
/* line 830 "sumabs2sum.puma" */
   return true;

  }
  if (yyP14->Kind == kCartProd) {
/* line 831 "sumabs2sum.puma" */
   return true;

  }
  return false;
}

static bool NeedsInFunBrackets
# if defined __STDC__ | defined __cplusplus
(register tTree yyP15)
# else
(yyP15)
 register tTree yyP15;
# endif
{
  if (yyP15->Kind == kInfixOp) {
/* line 836 "sumabs2sum.puma" */
  {
/* line 836 "sumabs2sum.puma" */
   if (! (IsIngen (yyP15->InfixOp.Infix . Ident))) goto yyL1;
  }
   return true;
yyL1:;

  }
  if (yyP15->Kind == kCartProd) {
/* line 837 "sumabs2sum.puma" */
   return true;

  }
  return false;
}

static bool NeedsCrossBrackets
# if defined __STDC__ | defined __cplusplus
(register tTree yyP16)
# else
(yyP16)
 register tTree yyP16;
# endif
{
  if (yyP16->Kind == kInfixOp) {
/* line 842 "sumabs2sum.puma" */
  {
/* line 842 "sumabs2sum.puma" */
   if (! (IsIngen (yyP16->InfixOp.Infix . Ident))) goto yyL1;
  }
   return true;
yyL1:;

  }
  if (yyP16->Kind == kCartProd) {
/* line 843 "sumabs2sum.puma" */
   return true;

  }
  return false;
}

static bool NeedsInGenBrackets
# if defined __STDC__ | defined __cplusplus
(register tTree yyP17)
# else
(yyP17)
 register tTree yyP17;
# endif
{
  if (yyP17->Kind == kInfixOp) {
/* line 847 "sumabs2sum.puma" */
  {
/* line 847 "sumabs2sum.puma" */
   if (! (IsIngen (yyP17->InfixOp.Infix . Ident))) goto yyL1;
  }
   return true;
yyL1:;

  }
  return false;
}

void BeginSumAbs2SumAscii ()
{
}

void CloseSumAbs2SumAscii ()
{
}
