# ifndef yySumToAda
# define yySumToAda

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "Tree.h"
# include "Type.h"


extern void (* SumToAda_Exit) ();

extern void TransAda ARGS((tTree t));
extern void TransAdaType ARGS((tType t));
extern void Unparse ARGS((tTree t));

extern void BeginSumToAda ();
extern void CloseSumToAda ();

# endif
