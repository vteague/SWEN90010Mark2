# include "ZSyms.h"
# define yyALLOC(ptr, size)	if ((ptr = (tZSyms) ZSyms_PoolFreePtr) >= (tZSyms) ZSyms_PoolMaxPtr) \
  ptr = ZSyms_Alloc (); \
  ZSyms_PoolFreePtr += size;
# define yyFREE(ptr, size)	
# ifdef __cplusplus
extern "C" {
# include <stdio.h>
# include "yyZSyms.w"
# include "System.h"
# include "General.h"
# include "Memory.h"
# include "DynArray.h"
# include "StringMem.h"
# include "Idents.h"
# include "Sets.h"
# include "Positions.h"
}
# else
# include <stdio.h>
# include "yyZSyms.w"
# include "System.h"
# include "General.h"
# include "Memory.h"
# include "DynArray.h"
# include "StringMem.h"
# include "Idents.h"
# include "Sets.h"
# include "Positions.h"
# endif

/* line 20 "zsyms.ast" */

#include "Idents.h" 
#include "Positions.h"
#include "global.h"
#include "env.h"

/** redefine macros for reuse of trees once the hash table is lost **/
#define writetPosition(pos) WritePosition(yyf,pos);
#define readtPosition(a) ReadPosition(yyf,&a);
#define writetIdPos(a) WriteIdPos(yyf,a);
#define readtIdPos(a) ReadIdPos(yyf,&a);
#define gettPosition(pos) GetPosition(yyf,&pos);
#define puttPosition(pos) PutPosition(yyf,pos);
#define gettIdPos(a) GetIdPos(yyf,&a);
#define puttIdPos(a) PutIdPos(yyf,a);


static void yyExit () { Exit (1); }

void (* ZSyms_Exit) () = yyExit;

# define yyBlockSize 20480

typedef struct yysBlock {
 char yyBlock [yyBlockSize];
 struct yysBlock * yySuccessor;
} yytBlock, * yytBlockPtr;

tZSyms ZSymsRoot;
unsigned long ZSyms_HeapUsed = 0;

static yytBlockPtr yyBlockList	= (yytBlockPtr) NoZSyms;
char * ZSyms_PoolFreePtr	= (char *) NoZSyms;
char * ZSyms_PoolMaxPtr	= (char *) NoZSyms;
static unsigned short yyMaxSize	= 0;
unsigned short ZSyms_NodeSize [16 + 1] = { 0,
 sizeof (yEnvirons),
 sizeof (yno_env),
 sizeof (yscope_env),
 sizeof (ySymbols),
 sizeof (yno_symbol),
 sizeof (ysymbol),
 sizeof (ySymbol),
 sizeof (yvar),
 sizeof (ygeneric),
 sizeof (yschema),
 sizeof (yZSymList),
 sizeof (ynoZSym),
 sizeof (yzSym),
 sizeof (ySumRenames),
 sizeof (ynoSumRename),
 sizeof (ysumRename),
};
char * ZSyms_NodeName [16 + 1] = {
 "NoZSyms",
 "Environs",
 "no_env",
 "scope_env",
 "Symbols",
 "no_symbol",
 "symbol",
 "Symbol",
 "var",
 "generic",
 "schema",
 "ZSymList",
 "noZSym",
 "zSym",
 "SumRenames",
 "noSumRename",
 "sumRename",
};
static ZSyms_tKind yyTypeRange [16 + 1] = { 0,
 kscope_env,
 kno_env,
 kscope_env,
 ksymbol,
 kno_symbol,
 ksymbol,
 kschema,
 kvar,
 kgeneric,
 kschema,
 kzSym,
 knoZSym,
 kzSym,
 ksumRename,
 knoSumRename,
 ksumRename,
};

tZSyms ZSyms_Alloc ()
{
 register yytBlockPtr yyBlockPtr = yyBlockList;
 register int i;

 if (yyMaxSize == 0)
  for (i = 1; i <= 16; i ++) {
   ZSyms_NodeSize [i] = (ZSyms_NodeSize [i] + yyMaxAlign - 1) & yyAlignMasks [yyMaxAlign];
   yyMaxSize = Max (ZSyms_NodeSize [i], yyMaxSize);
  }
 yyBlockList = (yytBlockPtr) Alloc (sizeof (yytBlock));
 yyBlockList->yySuccessor = yyBlockPtr;
 ZSyms_PoolFreePtr = yyBlockList->yyBlock;
 ZSyms_PoolMaxPtr = ZSyms_PoolFreePtr + yyBlockSize - yyMaxSize + 1;
 ZSyms_HeapUsed += yyBlockSize;
 return (tZSyms) ZSyms_PoolFreePtr;
}

tZSyms MakeZSyms
# if defined __STDC__ | defined __cplusplus
 (ZSyms_tKind yyKind)
# else
 (yyKind) ZSyms_tKind yyKind;
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [yyKind])
 yyt->Kind = yyKind;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

bool ZSyms_IsType
# if defined __STDC__ | defined __cplusplus
 (register tZSyms yyt, register ZSyms_tKind yyKind)
# else
 (yyt, yyKind) register tZSyms yyt; register ZSyms_tKind yyKind;
# endif
{
 return yyt != NoZSyms && yyKind <= yyt->Kind && yyt->Kind <= yyTypeRange [yyKind];
}

tZSyms nEnvirons () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kEnvirons])
 yyt->Kind = kEnvirons;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms nno_env () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kno_env])
 yyt->Kind = kno_env;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms nscope_env () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kscope_env])
 yyt->Kind = kscope_env;
 yyt->yyHead.yyMark = 0;
 begintZSyms(yyt->scope_env.Symbols)
 begintZSyms(yyt->scope_env.Outer)
 return yyt;
}

tZSyms nSymbols () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kSymbols])
 yyt->Kind = kSymbols;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms nno_symbol () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kno_symbol])
 yyt->Kind = kno_symbol;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms nsymbol () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [ksymbol])
 yyt->Kind = ksymbol;
 yyt->yyHead.yyMark = 0;
 begintZSyms(yyt->symbol.Rest)
 begintZSyms(yyt->symbol.Symbol)
 begintIdPos(yyt->symbol.Sym)
 begintIdPos(yyt->symbol.schid)
 begintIdPos(yyt->symbol.modid)
 return yyt;
}

tZSyms nSymbol () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kSymbol])
 yyt->Kind = kSymbol;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms nvar () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kvar])
 yyt->Kind = kvar;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms ngeneric () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kgeneric])
 yyt->Kind = kgeneric;
 yyt->yyHead.yyMark = 0;
 begintZSyms(yyt->generic.params)
 return yyt;
}

tZSyms nschema () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kschema])
 yyt->Kind = kschema;
 yyt->yyHead.yyMark = 0;
 begintZSyms(yyt->schema.params)
 begintZSyms(yyt->schema.locs)
 return yyt;
}

tZSyms nZSymList () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kZSymList])
 yyt->Kind = kZSymList;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms nnoZSym () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [knoZSym])
 yyt->Kind = knoZSym;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms nzSym () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kzSym])
 yyt->Kind = kzSym;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->zSym.Sym)
 begintZSyms(yyt->zSym.Next)
 return yyt;
}

tZSyms nSumRenames () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kSumRenames])
 yyt->Kind = kSumRenames;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms nnoSumRename () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [knoSumRename])
 yyt->Kind = knoSumRename;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms nsumRename () {
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [ksumRename])
 yyt->Kind = ksumRename;
 yyt->yyHead.yyMark = 0;
 begintZSyms(yyt->sumRename.Next)
 begintIdPos(yyt->sumRename.zname)
 begintIdPos(yyt->sumRename.sumname)
 return yyt;
}


tZSyms mEnvirons
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kEnvirons])
 yyt->Kind = kEnvirons;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms mno_env
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kno_env])
 yyt->Kind = kno_env;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms mscope_env
# if defined __STDC__ | defined __cplusplus
(tZSyms pSymbols, tZSyms pOuter)
# else
(pSymbols, pOuter)
tZSyms pSymbols;
tZSyms pOuter;
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kscope_env])
 yyt->Kind = kscope_env;
 yyt->yyHead.yyMark = 0;
 yyt->scope_env.Symbols = pSymbols;
 yyt->scope_env.Outer = pOuter;
 return yyt;
}

tZSyms mSymbols
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kSymbols])
 yyt->Kind = kSymbols;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms mno_symbol
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kno_symbol])
 yyt->Kind = kno_symbol;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms msymbol
# if defined __STDC__ | defined __cplusplus
(tZSyms pRest, tZSyms pSymbol, tIdPos pSym, tIdPos pschid, tIdPos pmodid)
# else
(pRest, pSymbol, pSym, pschid, pmodid)
tZSyms pRest;
tZSyms pSymbol;
tIdPos pSym;
tIdPos pschid;
tIdPos pmodid;
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [ksymbol])
 yyt->Kind = ksymbol;
 yyt->yyHead.yyMark = 0;
 yyt->symbol.Rest = pRest;
 yyt->symbol.Symbol = pSymbol;
 yyt->symbol.Sym = pSym;
 yyt->symbol.schid = pschid;
 yyt->symbol.modid = pmodid;
 return yyt;
}

tZSyms mSymbol
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kSymbol])
 yyt->Kind = kSymbol;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms mvar
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kvar])
 yyt->Kind = kvar;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms mgeneric
# if defined __STDC__ | defined __cplusplus
(tZSyms pparams)
# else
(pparams)
tZSyms pparams;
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kgeneric])
 yyt->Kind = kgeneric;
 yyt->yyHead.yyMark = 0;
 yyt->generic.params = pparams;
 return yyt;
}

tZSyms mschema
# if defined __STDC__ | defined __cplusplus
(tZSyms pparams, tZSyms plocs)
# else
(pparams, plocs)
tZSyms pparams;
tZSyms plocs;
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kschema])
 yyt->Kind = kschema;
 yyt->yyHead.yyMark = 0;
 yyt->schema.params = pparams;
 yyt->schema.locs = plocs;
 return yyt;
}

tZSyms mZSymList
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kZSymList])
 yyt->Kind = kZSymList;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms mnoZSym
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [knoZSym])
 yyt->Kind = knoZSym;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms mzSym
# if defined __STDC__ | defined __cplusplus
(tIdPos pSym, tZSyms pNext)
# else
(pSym, pNext)
tIdPos pSym;
tZSyms pNext;
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kzSym])
 yyt->Kind = kzSym;
 yyt->yyHead.yyMark = 0;
 yyt->zSym.Sym = pSym;
 yyt->zSym.Next = pNext;
 return yyt;
}

tZSyms mSumRenames
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [kSumRenames])
 yyt->Kind = kSumRenames;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms mnoSumRename
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [knoSumRename])
 yyt->Kind = knoSumRename;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZSyms msumRename
# if defined __STDC__ | defined __cplusplus
(tZSyms pNext, tIdPos pzname, tIdPos psumname)
# else
(pNext, pzname, psumname)
tZSyms pNext;
tIdPos pzname;
tIdPos psumname;
# endif
{
 register tZSyms yyt;
 yyALLOC (yyt, ZSyms_NodeSize [ksumRename])
 yyt->Kind = ksumRename;
 yyt->yyHead.yyMark = 0;
 yyt->sumRename.Next = pNext;
 yyt->sumRename.zname = pzname;
 yyt->sumRename.sumname = psumname;
 return yyt;
}

typedef tZSyms * yyPtrtTree;

static FILE * yyf;

static void yyMark
# if defined __STDC__ | defined __cplusplus
 (register tZSyms yyt)
# else
 (yyt) register tZSyms yyt;
# endif
{
 for (;;) {
  if (yyt == NoZSyms || ++ yyt->yyHead.yyMark > 1) return;

  switch (yyt->Kind) {
case kscope_env:
yyMark (yyt->scope_env.Symbols);
yyt = yyt->scope_env.Outer; break;
case ksymbol:
yyMark (yyt->symbol.Rest);
yyt = yyt->symbol.Symbol; break;
case kgeneric:
yyt = yyt->generic.params; break;
case kschema:
yyMark (yyt->schema.params);
yyt = yyt->schema.locs; break;
case kzSym:
yyt = yyt->zSym.Next; break;
case ksumRename:
yyt = yyt->sumRename.Next; break;
  default: return;
  }
 }
}

# define yyInitTreeStoreSize 32
# define yyMapToTree(yyLabel) yyTreeStorePtr [yyLabel]

static unsigned long yyTreeStoreSize = yyInitTreeStoreSize;
static tZSyms yyTreeStore [yyInitTreeStoreSize];
static tZSyms * yyTreeStorePtr = yyTreeStore;
static int yyLabelCount;
static short yyRecursionLevel = 0;

static ZSyms_tLabel yyMapToLabel
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyLabelCount; yyi ++) if (yyTreeStorePtr [yyi] == yyt) return yyi;
 if (++ yyLabelCount == yyTreeStoreSize)
  ExtendArray ((char * *) & yyTreeStorePtr, & yyTreeStoreSize, sizeof (tZSyms));
 yyTreeStorePtr [yyLabelCount] = yyt;
 return yyLabelCount;
}

static void yyWriteZSyms ();

static void yyWriteNl () { (void) putc ('\n', yyf); }

static void yyWriteSelector
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyi = 16 - strlen (yys);
 (void) fputs (yys, yyf);
 while (yyi -- > 0) (void) putc (' ', yyf);
 (void) fputs (" = ", yyf);
}

static void yyWriteHex
# if defined __STDC__ | defined __cplusplus
 (unsigned char * yyx, int yysize)
# else
 (yyx, yysize) unsigned char * yyx; int yysize;
# endif
{ register int yyi; for (yyi = 0; yyi < yysize; yyi ++) (void) fprintf (yyf, "%02x ", yyx [yyi]); }

static void yyWriteAdr
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 if (yyt == NoZSyms) (void) fputs ("NoZSyms", yyf);
 else yyWriteHex ((unsigned char *) & yyt, sizeof (yyt));
 yyWriteNl ();
}

static void yWriteNodescope_env
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 yyWriteSelector ("Symbols"); yyWriteAdr (yyt->scope_env.Symbols);
 yyWriteSelector ("Outer"); yyWriteAdr (yyt->scope_env.Outer);
}

static void yWriteNodesymbol
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 yyWriteSelector ("Rest"); yyWriteAdr (yyt->symbol.Rest);
 yyWriteSelector ("Symbol"); yyWriteAdr (yyt->symbol.Symbol);
 yyWriteSelector ("Sym"); writetIdPos (yyt->symbol.Sym) yyWriteNl ();
 yyWriteSelector ("schid"); writetIdPos (yyt->symbol.schid) yyWriteNl ();
 yyWriteSelector ("modid"); writetIdPos (yyt->symbol.modid) yyWriteNl ();
}

static void yWriteNodegeneric
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 yyWriteSelector ("params"); yyWriteAdr (yyt->generic.params);
}

static void yWriteNodeschema
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 yyWriteSelector ("params"); yyWriteAdr (yyt->schema.params);
 yyWriteSelector ("locs"); yyWriteAdr (yyt->schema.locs);
}

static void yWriteNodezSym
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 yyWriteSelector ("Sym"); writetIdPos (yyt->zSym.Sym) yyWriteNl ();
 yyWriteSelector ("Next"); yyWriteAdr (yyt->zSym.Next);
}

static void yWriteNodesumRename
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 yyWriteSelector ("Next"); yyWriteAdr (yyt->sumRename.Next);
 yyWriteSelector ("zname"); writetIdPos (yyt->sumRename.zname) yyWriteNl ();
 yyWriteSelector ("sumname"); writetIdPos (yyt->sumRename.sumname) yyWriteNl ();
}

void WriteZSymsNode
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf, tZSyms yyt)
# else
 (yyyf, yyt) FILE * yyyf; tZSyms yyt;
# endif
{
 yyf = yyyf;
 if (yyt == NoZSyms) { (void) fputs ("NoZSyms\n", yyf); return; }

 switch (yyt->Kind) {
case kEnvirons: (void) fputs (ZSyms_NodeName [kEnvirons], yyf); (void) fputc ('\n', yyf);
 break;
case kno_env: (void) fputs (ZSyms_NodeName [kno_env], yyf); (void) fputc ('\n', yyf);
 break;
case kscope_env: (void) fputs (ZSyms_NodeName [kscope_env], yyf); (void) fputc ('\n', yyf);
 yWriteNodescope_env (yyt); break;
case kSymbols: (void) fputs (ZSyms_NodeName [kSymbols], yyf); (void) fputc ('\n', yyf);
 break;
case kno_symbol: (void) fputs (ZSyms_NodeName [kno_symbol], yyf); (void) fputc ('\n', yyf);
 break;
case ksymbol: (void) fputs (ZSyms_NodeName [ksymbol], yyf); (void) fputc ('\n', yyf);
 yWriteNodesymbol (yyt); break;
case kSymbol: (void) fputs (ZSyms_NodeName [kSymbol], yyf); (void) fputc ('\n', yyf);
 break;
case kvar: (void) fputs (ZSyms_NodeName [kvar], yyf); (void) fputc ('\n', yyf);
 break;
case kgeneric: (void) fputs (ZSyms_NodeName [kgeneric], yyf); (void) fputc ('\n', yyf);
 yWriteNodegeneric (yyt); break;
case kschema: (void) fputs (ZSyms_NodeName [kschema], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschema (yyt); break;
case kZSymList: (void) fputs (ZSyms_NodeName [kZSymList], yyf); (void) fputc ('\n', yyf);
 break;
case knoZSym: (void) fputs (ZSyms_NodeName [knoZSym], yyf); (void) fputc ('\n', yyf);
 break;
case kzSym: (void) fputs (ZSyms_NodeName [kzSym], yyf); (void) fputc ('\n', yyf);
 yWriteNodezSym (yyt); break;
case kSumRenames: (void) fputs (ZSyms_NodeName [kSumRenames], yyf); (void) fputc ('\n', yyf);
 break;
case knoSumRename: (void) fputs (ZSyms_NodeName [knoSumRename], yyf); (void) fputc ('\n', yyf);
 break;
case ksumRename: (void) fputs (ZSyms_NodeName [ksumRename], yyf); (void) fputc ('\n', yyf);
 yWriteNodesumRename (yyt); break;
 default: ;
 }
}

static short yyIndentLevel;

void WriteZSyms
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf, tZSyms yyt)
# else
 (yyyf, yyt) FILE * yyyf; tZSyms yyt;
# endif
{
 short yySaveLevel = yyIndentLevel;
 yyf = yyyf;
 if (yyRecursionLevel ++ == 0) yyLabelCount = 0;
 yyMark (yyt);
 yyIndentLevel = 0;
 yyWriteZSyms (yyt);
 yyIndentLevel = yySaveLevel;
 yyRecursionLevel --;
}

static void yyIndentSelector
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyIndentLevel; yyi ++) (void) putc (' ', yyf);
 yyWriteSelector (yys);
}

static void yyIndentSelectorTree
# if defined __STDC__ | defined __cplusplus
 (char * yys, tZSyms yyt)
# else
 (yys, yyt) char * yys; tZSyms yyt;
# endif
{ yyIndentSelector (yys); writetZSyms (yyt) }

static void yWritescope_env
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 (void) fputs (ZSyms_NodeName [kscope_env], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Symbols", yyt->scope_env.Symbols);
}

static void yWritesymbol
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 (void) fputs (ZSyms_NodeName [ksymbol], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Rest", yyt->symbol.Rest);
 yyIndentSelector ("Sym"); writetIdPos (yyt->symbol.Sym) yyWriteNl ();
 yyIndentSelector ("schid"); writetIdPos (yyt->symbol.schid) yyWriteNl ();
 yyIndentSelector ("modid"); writetIdPos (yyt->symbol.modid) yyWriteNl ();
}

static void yWritegeneric
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 (void) fputs (ZSyms_NodeName [kgeneric], yyf); (void) fputc ('\n', yyf);
}

static void yWriteschema
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 (void) fputs (ZSyms_NodeName [kschema], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("params", yyt->schema.params);
}

static void yWritezSym
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 (void) fputs (ZSyms_NodeName [kzSym], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Sym"); writetIdPos (yyt->zSym.Sym) yyWriteNl ();
}

static void yWritesumRename
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 (void) fputs (ZSyms_NodeName [ksumRename], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("zname"); writetIdPos (yyt->sumRename.zname) yyWriteNl ();
 yyIndentSelector ("sumname"); writetIdPos (yyt->sumRename.sumname) yyWriteNl ();
}

static void yyWriteZSyms
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{ unsigned short yyLevel = yyIndentLevel;
 for (;;) {
  if (yyt == NoZSyms) { (void) fputs (" NoZSyms\n", yyf); goto yyExit;
  } else if (yyt->yyHead.yyMark == 0) { (void) fprintf (yyf, "^%d\n", yyMapToLabel (yyt)); goto yyExit;
  } else if (yyt->yyHead.yyMark > 1) {
   register int yyi;
   (void) fprintf (yyf, "\n%06d:", yyMapToLabel (yyt));
   for (yyi = 8; yyi <= yyIndentLevel; yyi ++) (void) putc (' ', yyf);
  } else (void) putc (' ', yyf);
  yyt->yyHead.yyMark = 0;
  yyIndentLevel += 2;

  switch (yyt->Kind) {
case kEnvirons: (void) fputs (ZSyms_NodeName [kEnvirons], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kno_env: (void) fputs (ZSyms_NodeName [kno_env], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kscope_env: yWritescope_env (yyt); yyIndentSelector ("Outer"); yyt = yyt->scope_env.Outer; break;
case kSymbols: (void) fputs (ZSyms_NodeName [kSymbols], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kno_symbol: (void) fputs (ZSyms_NodeName [kno_symbol], yyf); (void) fputc ('\n', yyf); goto yyExit;
case ksymbol: yWritesymbol (yyt); yyIndentSelector ("Symbol"); yyt = yyt->symbol.Symbol; break;
case kSymbol: (void) fputs (ZSyms_NodeName [kSymbol], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kvar: (void) fputs (ZSyms_NodeName [kvar], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kgeneric: yWritegeneric (yyt); yyIndentSelector ("params"); yyt = yyt->generic.params; break;
case kschema: yWriteschema (yyt); yyIndentSelector ("locs"); yyt = yyt->schema.locs; break;
case kZSymList: (void) fputs (ZSyms_NodeName [kZSymList], yyf); (void) fputc ('\n', yyf); goto yyExit;
case knoZSym: (void) fputs (ZSyms_NodeName [knoZSym], yyf); (void) fputc ('\n', yyf); goto yyExit;
case kzSym: yWritezSym (yyt); yyIndentSelector ("Next"); yyt = yyt->zSym.Next; break;
case kSumRenames: (void) fputs (ZSyms_NodeName [kSumRenames], yyf); (void) fputc ('\n', yyf); goto yyExit;
case knoSumRename: (void) fputs (ZSyms_NodeName [knoSumRename], yyf); (void) fputc ('\n', yyf); goto yyExit;
case ksumRename: yWritesumRename (yyt); yyIndentSelector ("Next"); yyt = yyt->sumRename.Next; break;
  default: goto yyExit;
  }
 }
yyExit:
 yyIndentLevel = yyLevel;
}

static tIdent yyKindToIdent [16 + 1];
static bool yyIsInitialized = false;

static short yyMapToKind
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyk;
 register tIdent yyi = MakeIdent ((tString) yys, strlen (yys));
 for (yyk = 0; yyk <= 16; yyk ++) {
  if (yyKindToIdent [yyk] == yyi) return yyk;
 }
 return 0;
}

static void yyReadNl () { (void) fscanf (yyf, "\n"); }

static tIdent yyReadIdent ()
{
 char yys [256];
 (void) fscanf (yyf, "%s", yys);
 return MakeIdent ((tString) yys, strlen (yys));
}

static void yyReadHex
# if defined __STDC__ | defined __cplusplus
 (unsigned char * yyx, int yysize)
# else
 (yyx, yysize) unsigned char * yyx; int yysize;
# endif
{
 register int yyi; int yyk;
 for (yyi = 0; yyi < yysize; yyi ++) { (void) fscanf (yyf, "%x ", & yyk); yyx [yyi] = yyk; }
}

static void yySkip () { (void) fscanf (yyf, " %*s =%*c"); }

static void yyReadZSyms
# if defined __STDC__ | defined __cplusplus
 (yyPtrtTree yyt)
# else
 (yyt) yyPtrtTree yyt;
# endif
{
 static ZSyms_tLabel yyLabel;
 static ZSyms_tKind yyKind;
 static char yys [256];
 for (;;) {
  switch (getc (yyf)) {
  case '^': (void) fscanf (yyf, "%hd\n", & yyLabel); * yyt = yyMapToTree (yyLabel); return;
  case '\n': case '0': (void) fscanf (yyf, "%hd%*c %s\n", & yyLabel, yys);
   yyKind = yyMapToKind (yys); * yyt = MakeZSyms (yyKind);
   if (yyLabel != yyMapToLabel (* yyt)) { (void) fputs ("ZSyms: error in ReadZSyms\n", stderr); ZSyms_Exit (); } break;
  default: ;
   (void) fscanf (yyf, "%s", yys);
   yyKind = yyMapToKind (yys);
   if (yyKind == 0) { * yyt = NoZSyms; return; }
   * yyt = MakeZSyms (yyKind);
  }

  switch (yyKind) {
case kscope_env:
yySkip (); readtZSyms (& ((* yyt)->scope_env.Symbols))
yySkip (); yyt = & ((* yyt)->scope_env.Outer); break;
case ksymbol:
yySkip (); readtZSyms (& ((* yyt)->symbol.Rest))
yySkip (); readtIdPos ((* yyt)->symbol.Sym) yyReadNl ();
yySkip (); readtIdPos ((* yyt)->symbol.schid) yyReadNl ();
yySkip (); readtIdPos ((* yyt)->symbol.modid) yyReadNl ();
yySkip (); yyt = & ((* yyt)->symbol.Symbol); break;
case kgeneric:
yySkip (); yyt = & ((* yyt)->generic.params); break;
case kschema:
yySkip (); readtZSyms (& ((* yyt)->schema.params))
yySkip (); yyt = & ((* yyt)->schema.locs); break;
case kzSym:
yySkip (); readtIdPos ((* yyt)->zSym.Sym) yyReadNl ();
yySkip (); yyt = & ((* yyt)->zSym.Next); break;
case ksumRename:
yySkip (); readtIdPos ((* yyt)->sumRename.zname) yyReadNl ();
yySkip (); readtIdPos ((* yyt)->sumRename.sumname) yyReadNl ();
yySkip (); yyt = & ((* yyt)->sumRename.Next); break;
  default: return;
  }
 }
}

tZSyms ReadZSyms
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf)
# else
 (yyyf) FILE * yyyf;
# endif
{
 tZSyms yyt;
 yyf = yyyf;
 if (yyRecursionLevel ++ == 0) yyLabelCount = 0;
 if (! yyIsInitialized) {
  register int yyi;
  for (yyi = 0; yyi <= 16; yyi ++)
   yyKindToIdent [yyi] = MakeIdent ((tString) ZSyms_NodeName [yyi], strlen (ZSyms_NodeName [yyi]));
  yyIsInitialized = true;
 }
 yyReadZSyms (& yyt);
 yyRecursionLevel --;
 return yyt;
}

# define yyNil	0374
# define yyNoLabel	0375
# define yyLabelDef	0376
# define yyLabelUse	0377

static void yyPut
# if defined __STDC__ | defined __cplusplus
 (char * yyx, int yysize)
# else
 (yyx, yysize) char * yyx; int yysize;
# endif
{ (void) fwrite (yyx, 1, yysize, yyf); }

static void yyPutIdent
# if defined __STDC__ | defined __cplusplus
 (tIdent yyi)
# else
 (yyi) tIdent yyi;
# endif
{
 char yys [256];
 GetString (yyi, (tString) yys);
 (void) fprintf (yyf, "%s\n", yys);
}

static void yyPutZSyms
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 static ZSyms_tLabel yyLabel;
 for (;;) {
  if (yyt == NoZSyms) {
   (void) putc (yyNil, yyf); return;
  } else if (yyt->yyHead.yyMark == 0) {
   (void) putc (yyLabelUse, yyf); yyLabel = yyMapToLabel (yyt); yyPut ((char *) & yyLabel, sizeof (yyLabel)); return;
  } else if (yyt->yyHead.yyMark > 1) {
   (void) putc (yyLabelDef, yyf); yyLabel = yyMapToLabel (yyt); yyPut ((char *) & yyLabel, sizeof (yyLabel));
   (void) putc ((char) yyt->Kind, yyf);
  } else {
   (void) putc ((char) yyt->Kind, yyf);
  }
  yyt->yyHead.yyMark = 0;

  switch (yyt->Kind) {
case kscope_env:
puttZSyms (yyt->scope_env.Symbols)
yyt = yyt->scope_env.Outer; break;
case ksymbol:
puttZSyms (yyt->symbol.Rest)
puttIdPos (yyt->symbol.Sym)
puttIdPos (yyt->symbol.schid)
puttIdPos (yyt->symbol.modid)
yyt = yyt->symbol.Symbol; break;
case kgeneric:
yyt = yyt->generic.params; break;
case kschema:
puttZSyms (yyt->schema.params)
yyt = yyt->schema.locs; break;
case kzSym:
puttIdPos (yyt->zSym.Sym)
yyt = yyt->zSym.Next; break;
case ksumRename:
puttIdPos (yyt->sumRename.zname)
puttIdPos (yyt->sumRename.sumname)
yyt = yyt->sumRename.Next; break;
  default: return;
  }
 }
}

void PutZSyms
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf, tZSyms yyt)
# else
 (yyyf, yyt) FILE * yyyf; tZSyms yyt;
# endif
{
 yyf = yyyf;
 if (yyRecursionLevel ++ == 0) yyLabelCount = 0;
 yyMark (yyt);
 yyPutZSyms (yyt);
 yyRecursionLevel --;
}

static void yyGet
# if defined __STDC__ | defined __cplusplus
 (char * yyx, int yysize)
# else
 (yyx, yysize) char * yyx; int yysize;
# endif
{ (void) fread (yyx, 1, yysize, yyf); }

static void yyGetIdent
# if defined __STDC__ | defined __cplusplus
 (tIdent * yyi)
# else
 (yyi) tIdent * yyi;
# endif
{
 char yys [256];
 (void) fscanf (yyf, "%s%*c", yys);
 * yyi = MakeIdent ((tString) yys, strlen (yys));
}

static void yyGetZSyms
# if defined __STDC__ | defined __cplusplus
 (yyPtrtTree yyt)
# else
 (yyt) yyPtrtTree yyt;
# endif
{
 static ZSyms_tLabel yyLabel;
 static ZSyms_tKind yyKind;
 for (;;) {
  switch (yyKind = getc (yyf)) {
  case yyNil		: * yyt = NoZSyms; return;
  case yyLabelUse	: yyGet ((char *) & yyLabel, sizeof (yyLabel));
   * yyt = yyMapToTree (yyLabel); return;
  case yyLabelDef	: yyGet ((char *) & yyLabel, sizeof (yyLabel));
   yyKind = getc (yyf);   * yyt = MakeZSyms (yyKind);
   if (yyLabel != yyMapToLabel (* yyt)) { (void) fputs ("ZSyms: error in GetZSyms\n", stderr); ZSyms_Exit (); } break;
  default	: * yyt = MakeZSyms (yyKind);
  }

  switch (yyKind) {
case kscope_env:
gettZSyms (& ((* yyt)->scope_env.Symbols))
yyt = & ((* yyt)->scope_env.Outer); break;
case ksymbol:
gettZSyms (& ((* yyt)->symbol.Rest))
gettIdPos ((* yyt)->symbol.Sym)
gettIdPos ((* yyt)->symbol.schid)
gettIdPos ((* yyt)->symbol.modid)
yyt = & ((* yyt)->symbol.Symbol); break;
case kgeneric:
yyt = & ((* yyt)->generic.params); break;
case kschema:
gettZSyms (& ((* yyt)->schema.params))
yyt = & ((* yyt)->schema.locs); break;
case kzSym:
gettIdPos ((* yyt)->zSym.Sym)
yyt = & ((* yyt)->zSym.Next); break;
case ksumRename:
gettIdPos ((* yyt)->sumRename.zname)
gettIdPos ((* yyt)->sumRename.sumname)
yyt = & ((* yyt)->sumRename.Next); break;
  default: return;
  }
 }
}

tZSyms GetZSyms
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf)
# else
 (yyyf) FILE * yyyf;
# endif
{
 tZSyms yyt;
 yyf = yyyf;
 if (yyRecursionLevel ++ == 0) yyLabelCount = 0;
 yyGetZSyms (& yyt);
 yyRecursionLevel --;
 return yyt;
}

static tZSyms yyChild;

static void yyReleaseZSyms
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 if (yyt == NoZSyms) return;
 switch (yyt->Kind) {
case kscope_env:
closetZSyms (yyt->scope_env.Symbols)
closetZSyms (yyt->scope_env.Outer)
break;
case ksymbol:
closetZSyms (yyt->symbol.Rest)
closetZSyms (yyt->symbol.Symbol)
break;
case kgeneric:
closetZSyms (yyt->generic.params)
break;
case kschema:
closetZSyms (yyt->schema.params)
closetZSyms (yyt->schema.locs)
break;
case kzSym:
closetZSyms (yyt->zSym.Next)
break;
case ksumRename:
closetZSyms (yyt->sumRename.Next)
break;
 default: ;
 }

 if (-- yyt->yyHead.yyMark == 0) {
  switch (yyt->Kind) {
case ksymbol:
closetIdPos (yyt->symbol.Sym)
closetIdPos (yyt->symbol.schid)
closetIdPos (yyt->symbol.modid)
break;
case kzSym:
closetIdPos (yyt->zSym.Sym)
break;
case ksumRename:
closetIdPos (yyt->sumRename.zname)
closetIdPos (yyt->sumRename.sumname)
break;
  default: ;
  }
  yyFREE (yyt, ZSyms_NodeSize [yyt->Kind])
 }
}

void ReleaseZSyms
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 yyMark (yyt);
 yyReleaseZSyms (yyt);
}

void ReleaseZSymsModule ()
{
 yytBlockPtr yyBlockPtr;
 while (yyBlockList != (yytBlockPtr) NoZSyms) {
  yyBlockPtr = yyBlockList;
  yyBlockList = yyBlockList->yySuccessor;
  Free (sizeof (yytBlock), (char *) yyBlockPtr);
 }
 ZSyms_PoolFreePtr = (char *) NoZSyms;
 ZSyms_PoolMaxPtr = (char *) NoZSyms;
 ZSyms_HeapUsed = 0;
}

static ZSyms_tProcTree yyProc;

static void yyTraverseZSymsTD
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 for (;;) {
  if (yyt == NoZSyms || yyt->yyHead.yyMark == 0) return;
  yyt->yyHead.yyMark = 0;
  yyProc (yyt);

  switch (yyt->Kind) {
case kscope_env:
yyTraverseZSymsTD (yyt->scope_env.Symbols);
yyt = yyt->scope_env.Outer; break;
case ksymbol:
yyTraverseZSymsTD (yyt->symbol.Rest);
yyt = yyt->symbol.Symbol; break;
case kgeneric:
yyt = yyt->generic.params; break;
case kschema:
yyTraverseZSymsTD (yyt->schema.params);
yyt = yyt->schema.locs; break;
case kzSym:
yyt = yyt->zSym.Next; break;
case ksumRename:
yyt = yyt->sumRename.Next; break;
  default: return;
  }
 }
}

void TraverseZSymsTD
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt, ZSyms_tProcTree yyyProc)
# else
 (yyt, yyyProc) tZSyms yyt; ZSyms_tProcTree yyyProc;
# endif
{
 yyMark (yyt);
 yyProc = yyyProc;
 yyTraverseZSymsTD (yyt);
}

static void yyTraverseZSymsBU
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 if (yyt == NoZSyms || yyt->yyHead.yyMark == 0) return;
 yyt->yyHead.yyMark = 0;

 switch (yyt->Kind) {
case kscope_env:
yyTraverseZSymsBU (yyt->scope_env.Symbols);
yyTraverseZSymsBU (yyt->scope_env.Outer); break;
case ksymbol:
yyTraverseZSymsBU (yyt->symbol.Rest);
yyTraverseZSymsBU (yyt->symbol.Symbol); break;
case kgeneric:
yyTraverseZSymsBU (yyt->generic.params); break;
case kschema:
yyTraverseZSymsBU (yyt->schema.params);
yyTraverseZSymsBU (yyt->schema.locs); break;
case kzSym:
yyTraverseZSymsBU (yyt->zSym.Next); break;
case ksumRename:
yyTraverseZSymsBU (yyt->sumRename.Next); break;
 default: ;
 }
 yyProc (yyt);
}

void TraverseZSymsBU
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt, ZSyms_tProcTree yyyProc)
# else
 (yyt, yyyProc) tZSyms yyt; ZSyms_tProcTree yyyProc;
# endif
{
 yyMark (yyt);
 yyProc = yyyProc;
 yyTraverseZSymsBU (yyt);
}

tZSyms ReverseZSyms
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyOld)
# else
 (yyOld) tZSyms yyOld;
# endif
{
 register tZSyms yyNew, yyNext, yyTail;
 yyNew = yyOld;
 yyTail = yyOld;
 for (;;) {
  switch (yyOld->Kind) {
  default: goto yyExit;
  }
  yyNew = yyOld;
  yyOld = yyNext;
 }
yyExit:
 switch (yyTail->Kind) {
 default: ;
 }
 return yyNew;
}

# define yyInitOldToNewStoreSize 32

typedef struct { tZSyms yyOld, yyNew; } yytOldToNew;
static unsigned long yyOldToNewStoreSize = yyInitOldToNewStoreSize;
static yytOldToNew yyOldToNewStore [yyInitOldToNewStoreSize];
static yytOldToNew * yyOldToNewStorePtr = yyOldToNewStore;
static int yyOldToNewCount;

static void yyStoreOldToNew
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyOld, tZSyms yyNew)
# else
 (yyOld, yyNew) tZSyms yyOld, yyNew;
# endif
{
 if (++ yyOldToNewCount == yyOldToNewStoreSize)
  ExtendArray ((char * *) & yyOldToNewStorePtr, & yyOldToNewStoreSize, sizeof (yytOldToNew));
 yyOldToNewStorePtr [yyOldToNewCount].yyOld = yyOld;
 yyOldToNewStorePtr [yyOldToNewCount].yyNew = yyNew;
}

static tZSyms yyMapOldToNew
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyOld)
# else
 (yyOld) tZSyms yyOld;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyOldToNewCount; yyi ++)
  if (yyOldToNewStorePtr [yyi].yyOld == yyOld) return yyOldToNewStorePtr [yyi].yyNew;
}

static tZSyms yyCopyZSyms
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt, yyPtrtTree yyNew)
# else
 (yyt, yyNew) tZSyms yyt; yyPtrtTree yyNew;
# endif
{
 for (;;) {
  if (yyt == NoZSyms) { * yyNew = NoZSyms; return; }
  if (yyt->yyHead.yyMark == 0) { * yyNew = yyMapOldToNew (yyt); return; }
  yyALLOC (* yyNew, ZSyms_NodeSize [yyt->Kind])
  if (yyt->yyHead.yyMark > 1) { yyStoreOldToNew (yyt, * yyNew); }
  yyt->yyHead.yyMark = 0;

  switch (yyt->Kind) {
case kEnvirons: (* yyNew)->Environs = yyt->Environs;
return;
case kno_env: (* yyNew)->no_env = yyt->no_env;
return;
case kscope_env: (* yyNew)->scope_env = yyt->scope_env;
copytZSyms ((* yyNew)->scope_env.Symbols, yyt->scope_env.Symbols)
yyt = yyt->scope_env.Outer;
yyNew = & (* yyNew)->scope_env.Outer; break;
case kSymbols: (* yyNew)->Symbols = yyt->Symbols;
return;
case kno_symbol: (* yyNew)->no_symbol = yyt->no_symbol;
return;
case ksymbol: (* yyNew)->symbol = yyt->symbol;
copytZSyms ((* yyNew)->symbol.Rest, yyt->symbol.Rest)
copytIdPos ((* yyNew)->symbol.Sym, yyt->symbol.Sym)
copytIdPos ((* yyNew)->symbol.schid, yyt->symbol.schid)
copytIdPos ((* yyNew)->symbol.modid, yyt->symbol.modid)
yyt = yyt->symbol.Symbol;
yyNew = & (* yyNew)->symbol.Symbol; break;
case kSymbol: (* yyNew)->Symbol = yyt->Symbol;
return;
case kvar: (* yyNew)->var = yyt->var;
return;
case kgeneric: (* yyNew)->generic = yyt->generic;
yyt = yyt->generic.params;
yyNew = & (* yyNew)->generic.params; break;
case kschema: (* yyNew)->schema = yyt->schema;
copytZSyms ((* yyNew)->schema.params, yyt->schema.params)
yyt = yyt->schema.locs;
yyNew = & (* yyNew)->schema.locs; break;
case kZSymList: (* yyNew)->ZSymList = yyt->ZSymList;
return;
case knoZSym: (* yyNew)->noZSym = yyt->noZSym;
return;
case kzSym: (* yyNew)->zSym = yyt->zSym;
copytIdPos ((* yyNew)->zSym.Sym, yyt->zSym.Sym)
yyt = yyt->zSym.Next;
yyNew = & (* yyNew)->zSym.Next; break;
case kSumRenames: (* yyNew)->SumRenames = yyt->SumRenames;
return;
case knoSumRename: (* yyNew)->noSumRename = yyt->noSumRename;
return;
case ksumRename: (* yyNew)->sumRename = yyt->sumRename;
copytIdPos ((* yyNew)->sumRename.zname, yyt->sumRename.zname)
copytIdPos ((* yyNew)->sumRename.sumname, yyt->sumRename.sumname)
yyt = yyt->sumRename.Next;
yyNew = & (* yyNew)->sumRename.Next; break;
  default: ;
  }
 }
}

tZSyms CopyZSyms
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 tZSyms yyNew;
 yyMark (yyt);
 yyOldToNewCount = 0;
 yyCopyZSyms (yyt, & yyNew);
 return yyNew;
}

static bool yyCheckZSyms ARGS((tZSyms yyt));

bool CheckZSyms
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 yyMark (yyt);
 return yyCheckZSyms (yyt);
}

static bool yyCheckChild
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyParent, tZSyms yyyChild, ZSyms_tKind yyType, char * yySelector)
# else
 (yyParent, yyyChild, yyType, yySelector)
 tZSyms yyParent, yyyChild;
 ZSyms_tKind yyType;
 char * yySelector;
# endif
{
 bool yySuccess = ZSyms_IsType (yyyChild, yyType);
 if (! yySuccess) {
  (void) fputs ("CheckTree: parent = ", stderr);
  WriteZSymsNode (stderr, yyParent);
  (void) fprintf (stderr, "\nselector: %s child = ", yySelector);
  WriteZSymsNode (stderr, yyyChild);
  (void) fputc ('\n', stderr);
 }
 return yyCheckZSyms (yyyChild) && yySuccess;
}

static bool yyCheckZSyms
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 bool yyResult;
 if (yyt == NoZSyms) return false;
 else if (yyt->yyHead.yyMark == 0) return true;
 yyt->yyHead.yyMark = 0;

 yyResult = true;
 switch (yyt->Kind) {
case kscope_env:
yyResult = yyCheckChild (yyt, yyt->scope_env.Symbols, kSymbols, "Symbols") && yyResult;
yyResult = yyCheckChild (yyt, yyt->scope_env.Outer, kEnvirons, "Outer") && yyResult;
break;
case ksymbol:
yyResult = yyCheckChild (yyt, yyt->symbol.Rest, kSymbols, "Rest") && yyResult;
yyResult = yyCheckChild (yyt, yyt->symbol.Symbol, kSymbol, "Symbol") && yyResult;
break;
case kgeneric:
yyResult = yyCheckChild (yyt, yyt->generic.params, kZSymList, "params") && yyResult;
break;
case kschema:
yyResult = yyCheckChild (yyt, yyt->schema.params, kZSymList, "params") && yyResult;
yyResult = yyCheckChild (yyt, yyt->schema.locs, kSymbols, "locs") && yyResult;
break;
case kzSym:
yyResult = yyCheckChild (yyt, yyt->zSym.Next, kZSymList, "Next") && yyResult;
break;
case ksumRename:
yyResult = yyCheckChild (yyt, yyt->sumRename.Next, kSumRenames, "Next") && yyResult;
break;
 default: ;
 }
 return yyResult;
}

# define yyyWrite	1
# define yyyRead	2
# define yyyQuit	3

static char yyyString [32], yyCh;
static int yyLength, yyState;

static bool yyyIsEqual
# if defined __STDC__ | defined __cplusplus
 (char * yya)
# else
 (yya) char * yya;
# endif
{
 register int yyi;
 if (yyLength >= 0 && yyyString [yyLength] == ' ') {
  if (yyLength != strlen (yya)) return false;
  for (yyi = 0; yyi < yyLength; yyi ++)
   if (yyyString [yyi] != yya [yyi]) return false;
 } else {
  if (yyLength >= strlen (yya)) return false;
  for (yyi = 0; yyi <= yyLength; yyi ++)
   if (yyyString [yyi] != yya [yyi]) return false;
 }
 return true;
}

void QueryZSyms
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt)
# else
 (yyt) tZSyms yyt;
# endif
{
 yyState = yyyWrite;
 for (;;) {
  switch (yyState) {
  case yyyQuit : return;
  case yyyWrite: WriteZSymsNode (stdout, yyt); yyState = yyyRead;
  case yyyRead : (void) printf ("? "); yyLength = -1; yyCh = getc (stdin);
   while (yyCh != '\n' && yyCh > 0)
    { yyyString [++ yyLength] = yyCh; yyCh = getc (stdin); }
   if (yyCh < 0) { (void) fputs ("QueryTree: eof reached\n", stderr);
    yyState = yyyQuit; return; }
   if      (yyyIsEqual ("parent")) { yyState = yyyWrite; return; }
   else if (yyyIsEqual ("quit"  )) { yyState = yyyQuit ; return; }
   else if (yyt != NoZSyms) {
    switch (yyt->Kind) {
case kscope_env: if (false) ;
else if (yyyIsEqual ("Symbols")) QueryZSyms (yyt->scope_env.Symbols);
else if (yyyIsEqual ("Outer")) QueryZSyms (yyt->scope_env.Outer);
break;
case ksymbol: if (false) ;
else if (yyyIsEqual ("Rest")) QueryZSyms (yyt->symbol.Rest);
else if (yyyIsEqual ("Symbol")) QueryZSyms (yyt->symbol.Symbol);
break;
case kgeneric: if (false) ;
else if (yyyIsEqual ("params")) QueryZSyms (yyt->generic.params);
break;
case kschema: if (false) ;
else if (yyyIsEqual ("params")) QueryZSyms (yyt->schema.params);
else if (yyyIsEqual ("locs")) QueryZSyms (yyt->schema.locs);
break;
case kzSym: if (false) ;
else if (yyyIsEqual ("Next")) QueryZSyms (yyt->zSym.Next);
break;
case ksumRename: if (false) ;
else if (yyyIsEqual ("Next")) QueryZSyms (yyt->sumRename.Next);
break;
    default: ;
    }
   }
  }
 }
}

bool IsEqualZSyms
# if defined __STDC__ | defined __cplusplus
 (tZSyms yyt1, tZSyms yyt2)
# else
 (yyt1, yyt2) tZSyms yyt1, yyt2;
# endif
{
 if (yyt1 == NoZSyms && yyt2 == NoZSyms) return true;
 if (yyt1 == NoZSyms || yyt2 == NoZSyms || yyt1->Kind != yyt2->Kind) return false;
 switch (yyt1->Kind) {
case kscope_env: return true
&& equaltZSyms (yyt1->scope_env.Symbols, yyt2->scope_env.Symbols)
&& equaltZSyms (yyt1->scope_env.Outer, yyt2->scope_env.Outer)
;
case ksymbol: return true
&& equaltZSyms (yyt1->symbol.Rest, yyt2->symbol.Rest)
&& equaltZSyms (yyt1->symbol.Symbol, yyt2->symbol.Symbol)
&& (equaltIdPos (yyt1->symbol.Sym, yyt2->symbol.Sym))
&& (equaltIdPos (yyt1->symbol.schid, yyt2->symbol.schid))
&& (equaltIdPos (yyt1->symbol.modid, yyt2->symbol.modid))
;
case kgeneric: return true
&& equaltZSyms (yyt1->generic.params, yyt2->generic.params)
;
case kschema: return true
&& equaltZSyms (yyt1->schema.params, yyt2->schema.params)
&& equaltZSyms (yyt1->schema.locs, yyt2->schema.locs)
;
case kzSym: return true
&& (equaltIdPos (yyt1->zSym.Sym, yyt2->zSym.Sym))
&& equaltZSyms (yyt1->zSym.Next, yyt2->zSym.Next)
;
case ksumRename: return true
&& equaltZSyms (yyt1->sumRename.Next, yyt2->sumRename.Next)
&& (equaltIdPos (yyt1->sumRename.zname, yyt2->sumRename.zname))
&& (equaltIdPos (yyt1->sumRename.sumname, yyt2->sumRename.sumname))
;
 default: return true;
 }
}

void BeginZSyms ()
{
}

void CloseZSyms ()
{
}
