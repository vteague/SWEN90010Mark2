# include "ZSymTabAccess.h"
# include "yyZSymTabAccess.w"
# include "System.h"
# include <stdio.h>
# include "ZSyms.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 15 "zsymtab.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "env.h"
#include <stdio.h>


static void yyExit () { Exit (1); }

void (* ZSymTabAccess_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module ZSymTabAccess, routine %s failed\n", yyFunction);
 ZSymTabAccess_Exit ();
}

tZSyms AddVarSeq ARGS((tZSyms yyP1, tZSyms locs, tIdPos mid));
tZSyms AddAxSeq ARGS((tZSyms yyP2, tZSyms locs, tIdPos mid));
tZSyms AddGenSeq ARGS((tZSyms g, tZSyms yyP3, tZSyms locs, tIdPos mid));
static bool SameIds ARGS((tIdPos id1, tIdPos id2));
static bool IsLocalName ARGS((tZSyms yyP4, tIdPos id));
static bool InLocalTable ARGS((tIdPos s1, tZSyms list));
static bool InGlobalTable ARGS((tIdPos s1, tZSyms env));
bool InTable ARGS((tIdPos s1, tZSyms list, tZSyms env));
static bool InWholeLocalTable ARGS((tIdPos s1, tZSyms list));
static bool InWholeGlobalTable ARGS((tIdPos s1, tZSyms env));
bool InWholeTable ARGS((tIdPos s1, tZSyms list, tZSyms env));
tZSyms LocalLookup ARGS((tIdPos id, tZSyms syms));
static tZSyms EnvLookup ARGS((tIdPos id, tZSyms env));
tZSyms TotalLookup ARGS((tIdPos id, tZSyms syms, tZSyms env));
tIdPos SchemaName ARGS((tZSyms yyP5));
tZSyms IncSymbols ARGS((tZSyms alocs, tZSyms blocs));
tZSyms HideSymbols ARGS((tZSyms locs, tZSyms zsyms));
static tZSyms HideSymbolsA ARGS((tZSyms locs, tZSyms zsyms, tZSyms list));
static bool InZSymList ARGS((tIdPos id, tZSyms yyP6));
static bool IsPrimed ARGS((tIdPos id));
static bool IsShrieked ARGS((tIdPos id));
static tIdPos ShriekToQuery ARGS((tIdPos id));
static tIdPos RemoveDecoration ARGS((tIdPos id));
tZSyms ComposeSymbols ARGS((tZSyms slocs, tZSyms tlocs));
static tZSyms ComposeSymbolsA ARGS((tZSyms slocs, tZSyms tlocs, tZSyms keeplist, tZSyms outlist));
static tZSyms FinishSymbols ARGS((tZSyms tlocs, tZSyms keeplist, tZSyms outlist));
tZSyms PipeSymbols ARGS((tZSyms slocs, tZSyms tlocs));
static tZSyms PipeSymbolsA ARGS((tZSyms slocs, tZSyms tlocs, tZSyms keeplist, tZSyms outlist));

tZSyms AddVarSeq
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP1, register tZSyms locs, tIdPos mid)
# else
(yyP1, locs, mid)
 register tZSyms yyP1;
 register tZSyms locs;
 tIdPos mid;
# endif
{
/* line 31 "zsymtab.puma" */
tZSyms syms;
  if (yyP1->Kind == knoZSym) {
/* line 32 "zsymtab.puma" */
   return locs;

  }
  if (yyP1->Kind == kzSym) {
/* line 33 "zsymtab.puma" */
  {
/* line 34 "zsymtab.puma" */
syms = AddVarSeq(yyP1->zSym.Next,msymbol(locs,mvar(),yyP1->zSym.Sym,NoIdPos,mid),mid);
  }
   return syms;

  }
 yyAbort ("AddVarSeq");
}

tZSyms AddAxSeq
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP2, register tZSyms locs, tIdPos mid)
# else
(yyP2, locs, mid)
 register tZSyms yyP2;
 register tZSyms locs;
 tIdPos mid;
# endif
{
/* line 37 "zsymtab.puma" */
tZSyms syms;
  if (yyP2->Kind == kno_symbol) {
/* line 38 "zsymtab.puma" */
   return locs;

  }
  if (yyP2->Kind == ksymbol) {
/* line 39 "zsymtab.puma" */
  {
/* line 40 "zsymtab.puma" */
syms = AddAxSeq(yyP2->symbol.Rest,msymbol(locs,yyP2->symbol.Symbol,yyP2->symbol.Sym,NoIdPos,mid),mid);
  }
   return syms;

  }
 yyAbort ("AddAxSeq");
}

tZSyms AddGenSeq
# if defined __STDC__ | defined __cplusplus
(register tZSyms g, register tZSyms yyP3, register tZSyms locs, tIdPos mid)
# else
(g, yyP3, locs, mid)
 register tZSyms g;
 register tZSyms yyP3;
 register tZSyms locs;
 tIdPos mid;
# endif
{
/* line 43 "zsymtab.puma" */
tZSyms syms;
  if (yyP3->Kind == kno_symbol) {
/* line 44 "zsymtab.puma" */
   return locs;

  }
  if (yyP3->Kind == ksymbol) {
/* line 45 "zsymtab.puma" */
  {
/* line 46 "zsymtab.puma" */
syms = AddGenSeq(g,yyP3->symbol.Rest,msymbol(locs,mgeneric(g),yyP3->symbol.Sym,NoIdPos,mid),mid);
  }
   return syms;

  }
 yyAbort ("AddGenSeq");
}

static bool SameIds
# if defined __STDC__ | defined __cplusplus
(tIdPos id1, tIdPos id2)
# else
(id1, id2)
 tIdPos id1;
 tIdPos id2;
# endif
{
/* line 49 "zsymtab.puma" */
int found;
/* line 52 "zsymtab.puma" */
  {
/* line 54 "zsymtab.puma" */
char s1[256], s2[256]; 
	GetString(id1.Ident,s1);
	GetString(id2.Ident,s2);
	found = strcmp(s1,s2);
	
/* line 59 "zsymtab.puma" */
   if (! ((found == 0))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

static bool IsLocalName
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP4, tIdPos id)
# else
(yyP4, id)
 register tZSyms yyP4;
 tIdPos id;
# endif
{
  if (yyP4->Kind == ksymbol) {
/* line 63 "zsymtab.puma" */
  {
/* line 63 "zsymtab.puma" */
   if (! ((SameIds (yyP4->symbol.Sym, id) || IsLocalName (yyP4->symbol.Rest, id)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  return false;
}

static bool InLocalTable
# if defined __STDC__ | defined __cplusplus
(tIdPos s1, register tZSyms list)
# else
(s1, list)
 tIdPos s1;
 register tZSyms list;
# endif
{
  if (list->Kind == ksymbol) {
/* line 72 "zsymtab.puma" */
  {
/* line 72 "zsymtab.puma" */
   if (! ((SameIds (s1, list->symbol.Sym) || InLocalTable (s1, list->symbol.Rest)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  return false;
}

static bool InGlobalTable
# if defined __STDC__ | defined __cplusplus
(tIdPos s1, register tZSyms env)
# else
(s1, env)
 tIdPos s1;
 register tZSyms env;
# endif
{
  if (env->Kind == kscope_env) {
/* line 79 "zsymtab.puma" */
  {
/* line 79 "zsymtab.puma" */
   if (! ((InLocalTable (s1, env->scope_env.Symbols) || InGlobalTable (s1, env->scope_env.Outer)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  return false;
}

bool InTable
# if defined __STDC__ | defined __cplusplus
(tIdPos s1, register tZSyms list, register tZSyms env)
# else
(s1, list, env)
 tIdPos s1;
 register tZSyms list;
 register tZSyms env;
# endif
{
  if (list->Kind == ksymbol) {
/* line 87 "zsymtab.puma" */
  {
/* line 87 "zsymtab.puma" */
   if (! ((InLocalTable (s1, list) || InGlobalTable (s1, env)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  if (list->Kind == kno_symbol) {
/* line 88 "zsymtab.puma" */
  {
/* line 88 "zsymtab.puma" */
   if (! (InGlobalTable (s1, env))) goto yyL2;
  }
   return true;
yyL2:;

  }
  return false;
}

static bool InWholeLocalTable
# if defined __STDC__ | defined __cplusplus
(tIdPos s1, register tZSyms list)
# else
(s1, list)
 tIdPos s1;
 register tZSyms list;
# endif
{
  if (list->Kind == ksymbol) {
  if (list->symbol.Symbol->Kind == kschema) {
/* line 95 "zsymtab.puma" */
  {
/* line 96 "zsymtab.puma" */
   if (! ((SameIds (s1, list->symbol.Sym) || InLocalTable (s1, list->symbol.Symbol->schema.locs) || InWholeLocalTable (s1, list->symbol.Rest)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  if (list->symbol.Symbol->Kind == kvar) {
/* line 97 "zsymtab.puma" */
  {
/* line 98 "zsymtab.puma" */
   if (! ((SameIds (s1, list->symbol.Sym) || InWholeLocalTable (s1, list->symbol.Rest)))) goto yyL2;
  }
   return true;
yyL2:;

  }
  if (list->symbol.Symbol->Kind == kgeneric) {
/* line 99 "zsymtab.puma" */
  {
/* line 100 "zsymtab.puma" */
   if (! ((SameIds (s1, list->symbol.Sym) || InWholeLocalTable (s1, list->symbol.Rest)))) goto yyL3;
  }
   return true;
yyL3:;

  }
  }
  return false;
}

static bool InWholeGlobalTable
# if defined __STDC__ | defined __cplusplus
(tIdPos s1, register tZSyms env)
# else
(s1, env)
 tIdPos s1;
 register tZSyms env;
# endif
{
  if (env->Kind == kscope_env) {
/* line 107 "zsymtab.puma" */
  {
/* line 107 "zsymtab.puma" */
   if (! ((InWholeLocalTable (s1, env->scope_env.Symbols) || InWholeGlobalTable (s1, env->scope_env.Outer)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  return false;
}

bool InWholeTable
# if defined __STDC__ | defined __cplusplus
(tIdPos s1, register tZSyms list, register tZSyms env)
# else
(s1, list, env)
 tIdPos s1;
 register tZSyms list;
 register tZSyms env;
# endif
{
  if (list->Kind == ksymbol) {
/* line 115 "zsymtab.puma" */
  {
/* line 116 "zsymtab.puma" */
   if (! ((InWholeLocalTable (s1, list) || InWholeGlobalTable (s1, env)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  if (list->Kind == kno_symbol) {
/* line 117 "zsymtab.puma" */
  {
/* line 118 "zsymtab.puma" */
   if (! (InWholeGlobalTable (s1, env))) goto yyL2;
  }
   return true;
yyL2:;

  }
  return false;
}

tZSyms LocalLookup
# if defined __STDC__ | defined __cplusplus
(tIdPos id, register tZSyms syms)
# else
(id, syms)
 tIdPos id;
 register tZSyms syms;
# endif
{
/* line 122 "zsymtab.puma" */
tZSyms t;
  if (syms->Kind == kno_symbol) {
/* line 126 "zsymtab.puma" */
  {
/* line 126 "zsymtab.puma" */
t = mno_symbol();
  }
   return t;

  }
  if (syms->Kind == ksymbol) {
/* line 127 "zsymtab.puma" */
  {
/* line 128 "zsymtab.puma" */
if (SameIds(id,syms->symbol.Sym)) t = syms; 
		else t = LocalLookup(id,syms->symbol.Rest); 
		
  }
   return t;

  }
 yyAbort ("LocalLookup");
}

static tZSyms EnvLookup
# if defined __STDC__ | defined __cplusplus
(tIdPos id, register tZSyms env)
# else
(id, env)
 tIdPos id;
 register tZSyms env;
# endif
{
/* line 133 "zsymtab.puma" */
tZSyms s;
  if (env->Kind == kno_env) {
/* line 137 "zsymtab.puma" */
   return mno_symbol ();

  }
  if (env->Kind == kscope_env) {
/* line 138 "zsymtab.puma" */
  {
/* line 139 "zsymtab.puma" */
s = LocalLookup(id,env->scope_env.Symbols);
		if (Syms_IsType(s,kno_symbol))
			s = EnvLookup(id,env->scope_env.Outer);
  }
   return s;

  }
/* line 142 "zsymtab.puma" */
  {
/* line 142 "zsymtab.puma" */
Message("Symbol table lookup error",3,id.Pos); exit(1);
  }
   return mno_symbol ();

}

tZSyms TotalLookup
# if defined __STDC__ | defined __cplusplus
(tIdPos id, register tZSyms syms, register tZSyms env)
# else
(id, syms, env)
 tIdPos id;
 register tZSyms syms;
 register tZSyms env;
# endif
{
/* line 145 "zsymtab.puma" */
tZSyms s;
  if (syms->Kind == kno_symbol) {
/* line 150 "zsymtab.puma" */
   return EnvLookup (id, env);

  }
  if (syms->Kind == ksymbol) {
/* line 151 "zsymtab.puma" */
  {
/* line 152 "zsymtab.puma" */
s = LocalLookup(id,syms);
		if (Syms_IsType(s,kno_symbol))
			s = EnvLookup(id,env);
  }
   return s;

  }
/* line 155 "zsymtab.puma" */
  {
/* line 155 "zsymtab.puma" */
Message("Symbol table lookup error",3,id.Pos); exit(1);
  }
   return mno_symbol ();

}

tIdPos SchemaName
# if defined __STDC__ | defined __cplusplus
(register tZSyms yyP5)
# else
(yyP5)
 register tZSyms yyP5;
# endif
{
  if (yyP5->Kind == kno_symbol) {
/* line 159 "zsymtab.puma" */
   return NoIdPos;

  }
  if (yyP5->Kind == ksymbol) {
/* line 160 "zsymtab.puma" */
   return yyP5->symbol.schid;

  }
 yyAbort ("SchemaName");
}

tZSyms IncSymbols
# if defined __STDC__ | defined __cplusplus
(register tZSyms alocs, register tZSyms blocs)
# else
(alocs, blocs)
 register tZSyms alocs;
 register tZSyms blocs;
# endif
{
/* line 163 "zsymtab.puma" */
tZSyms syms;
  if (alocs->Kind == kno_symbol) {
/* line 164 "zsymtab.puma" */
   return blocs;

  }
  if (blocs->Kind == kno_symbol) {
/* line 165 "zsymtab.puma" */
   return alocs;

  }
  if (blocs->Kind == ksymbol) {
/* line 166 "zsymtab.puma" */
   return IncSymbols (msymbol (alocs, CopyZSyms (blocs->symbol.Symbol), blocs->symbol.Sym, blocs->symbol.schid, blocs->symbol.modid), blocs->symbol.Rest);

  }
 yyAbort ("IncSymbols");
}

tZSyms HideSymbols
# if defined __STDC__ | defined __cplusplus
(register tZSyms locs, register tZSyms zsyms)
# else
(locs, zsyms)
 register tZSyms locs;
 register tZSyms zsyms;
# endif
{
  if (zsyms->Kind == knoZSym) {
/* line 171 "zsymtab.puma" */
   return locs;

  }
/* line 172 "zsymtab.puma" */
   return HideSymbolsA (locs, zsyms, mno_symbol ());

}

static tZSyms HideSymbolsA
# if defined __STDC__ | defined __cplusplus
(register tZSyms locs, register tZSyms zsyms, register tZSyms list)
# else
(locs, zsyms, list)
 register tZSyms locs;
 register tZSyms zsyms;
 register tZSyms list;
# endif
{
/* line 176 "zsymtab.puma" */
tZSyms syms;
  if (locs->Kind == kno_symbol) {
/* line 177 "zsymtab.puma" */
   return list;

  }
  if (locs->Kind == ksymbol) {
  if (zsyms->Kind == knoZSym) {
/* line 178 "zsymtab.puma" */
   return HideSymbolsA (locs->symbol.Rest, zsyms, msymbol (list, CopyZSyms (locs->symbol.Symbol), locs->symbol.Sym, locs->symbol.schid, locs->symbol.modid));

  }
/* line 180 "zsymtab.puma" */
  {
/* line 181 "zsymtab.puma" */
if (InZSymList(locs->symbol.Sym,zsyms))
			
			syms = list;
		else
			syms = HideSymbolsA(locs->symbol.Rest,zsyms,msymbol(list,CopyZSyms(locs->symbol.Symbol),locs->symbol.Sym,locs->symbol.schid,locs->symbol.modid));
  }
   return syms;

  }
 yyAbort ("HideSymbolsA");
}

static bool InZSymList
# if defined __STDC__ | defined __cplusplus
(tIdPos id, register tZSyms yyP6)
# else
(id, yyP6)
 tIdPos id;
 register tZSyms yyP6;
# endif
{
  if (yyP6->Kind == kzSym) {
/* line 189 "zsymtab.puma" */
  {
/* line 190 "zsymtab.puma" */
   if (! ((SameIds (yyP6->zSym.Sym, id) || InZSymList (id, yyP6->zSym.Next)))) goto yyL1;
  }
   return true;
yyL1:;

  }
  return false;
}

static bool IsPrimed
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 194 "zsymtab.puma" */
  {
/* line 195 "zsymtab.puma" */
char str[256];
	int len,primed;
	GetString(id.Ident,str);
	len = strlen(str);
	primed =0;
	if (str[len-1]=='\'')
		primed=1;
/* line 202 "zsymtab.puma" */
   if (! ((primed == 1))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

static bool IsShrieked
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 206 "zsymtab.puma" */
  {
/* line 207 "zsymtab.puma" */
char str[256];
	int len,shrieked;
	GetString(id.Ident,str);
	len = strlen(str);
	shrieked =0;
	if (str[len-1]=='\'')
		shrieked=1;
/* line 214 "zsymtab.puma" */
   if (! ((shrieked == 1))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

static tIdPos ShriekToQuery
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 217 "zsymtab.puma" */
tIdPos sym;
/* line 218 "zsymtab.puma" */
  {
/* line 219 "zsymtab.puma" */
char str[256];
	int len;
	GetString(id.Ident,str);
	len = strlen(str);
	str[len-1] = '?';
	sym = ZMakeIdPos(str,NoPosition);
  }
   return sym;

}

static tIdPos RemoveDecoration
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 227 "zsymtab.puma" */
tIdPos sym;
/* line 228 "zsymtab.puma" */
  {
/* line 229 "zsymtab.puma" */
char str[256];
	int len;
	GetString(id.Ident,str);
	len = strlen(str);
	str[len-1] = '\0';
	sym = ZMakeIdPos(str,NoPosition);
  }
   return sym;

}

tZSyms ComposeSymbols
# if defined __STDC__ | defined __cplusplus
(register tZSyms slocs, register tZSyms tlocs)
# else
(slocs, tlocs)
 register tZSyms slocs;
 register tZSyms tlocs;
# endif
{
/* line 238 "zsymtab.puma" */
tZSyms syms;
  if (slocs->Kind == kno_symbol) {
/* line 239 "zsymtab.puma" */
   return tlocs;

  }
  if (tlocs->Kind == kno_symbol) {
/* line 240 "zsymtab.puma" */
   return slocs;

  }
/* line 241 "zsymtab.puma" */
   return ComposeSymbolsA (slocs, tlocs, mno_symbol (), mnoZSym ());

}

static tZSyms ComposeSymbolsA
# if defined __STDC__ | defined __cplusplus
(register tZSyms slocs, register tZSyms tlocs, register tZSyms keeplist, register tZSyms outlist)
# else
(slocs, tlocs, keeplist, outlist)
 register tZSyms slocs;
 register tZSyms tlocs;
 register tZSyms keeplist;
 register tZSyms outlist;
# endif
{
/* line 244 "zsymtab.puma" */
tZSyms syms;
  if (slocs->Kind == kno_symbol) {
/* line 245 "zsymtab.puma" */
   return FinishSymbols (tlocs, keeplist, outlist);

  }
  if (slocs->Kind == ksymbol) {
/* line 247 "zsymtab.puma" */
  {
/* line 248 "zsymtab.puma" */
tIdPos newid;
		if (IsPrimed(slocs->symbol.Sym))
			{newid = RemoveDecoration(slocs->symbol.Sym);
			if (InLocalTable(newid,tlocs))
				syms = ComposeSymbolsA(slocs->symbol.Rest,tlocs,keeplist,mzSym(newid,outlist));
			else syms = ComposeSymbolsA(slocs->symbol.Rest,tlocs,msymbol(keeplist,CopyZSyms(slocs->symbol.Symbol),slocs->symbol.Sym,slocs->symbol.schid,slocs->symbol.modid),outlist);}
		else syms = ComposeSymbolsA(slocs->symbol.Rest,tlocs,msymbol(keeplist,CopyZSyms(slocs->symbol.Symbol),slocs->symbol.Sym,slocs->symbol.schid,slocs->symbol.modid),outlist);
  }
   return syms;

  }
 yyAbort ("ComposeSymbolsA");
}

static tZSyms FinishSymbols
# if defined __STDC__ | defined __cplusplus
(register tZSyms tlocs, register tZSyms keeplist, register tZSyms outlist)
# else
(tlocs, keeplist, outlist)
 register tZSyms tlocs;
 register tZSyms keeplist;
 register tZSyms outlist;
# endif
{
/* line 257 "zsymtab.puma" */
tZSyms syms;
  if (tlocs->Kind == kno_symbol) {
/* line 258 "zsymtab.puma" */
   return keeplist;

  }
  if (tlocs->Kind == ksymbol) {
/* line 259 "zsymtab.puma" */
  {
/* line 260 "zsymtab.puma" */
if (InZSymList(tlocs->symbol.Sym,outlist))
			syms = FinishSymbols(tlocs->symbol.Rest,keeplist,outlist);
		else syms = FinishSymbols(tlocs->symbol.Rest,msymbol(keeplist,CopyZSyms(tlocs->symbol.Symbol),tlocs->symbol.Sym,tlocs->symbol.schid,tlocs->symbol.modid),outlist);
  }
   return syms;

  }
 yyAbort ("FinishSymbols");
}

tZSyms PipeSymbols
# if defined __STDC__ | defined __cplusplus
(register tZSyms slocs, register tZSyms tlocs)
# else
(slocs, tlocs)
 register tZSyms slocs;
 register tZSyms tlocs;
# endif
{
/* line 266 "zsymtab.puma" */
tZSyms syms;
  if (slocs->Kind == kno_symbol) {
/* line 267 "zsymtab.puma" */
   return tlocs;

  }
  if (tlocs->Kind == kno_symbol) {
/* line 268 "zsymtab.puma" */
   return slocs;

  }
/* line 269 "zsymtab.puma" */
   return PipeSymbolsA (slocs, tlocs, mno_symbol (), mnoZSym ());

}

static tZSyms PipeSymbolsA
# if defined __STDC__ | defined __cplusplus
(register tZSyms slocs, register tZSyms tlocs, register tZSyms keeplist, register tZSyms outlist)
# else
(slocs, tlocs, keeplist, outlist)
 register tZSyms slocs;
 register tZSyms tlocs;
 register tZSyms keeplist;
 register tZSyms outlist;
# endif
{
/* line 272 "zsymtab.puma" */
tZSyms syms;
  if (slocs->Kind == kno_symbol) {
/* line 273 "zsymtab.puma" */
   return FinishSymbols (tlocs, keeplist, outlist);

  }
  if (slocs->Kind == ksymbol) {
/* line 275 "zsymtab.puma" */
  {
/* line 276 "zsymtab.puma" */
tIdPos newid;
		if (IsShrieked(slocs->symbol.Sym))
			{newid = ShriekToQuery(slocs->symbol.Sym);
			if (InLocalTable(newid,tlocs))
				syms = PipeSymbolsA(slocs->symbol.Rest,tlocs,keeplist,mzSym(newid,outlist));
			else syms = PipeSymbolsA(slocs->symbol.Rest,tlocs,msymbol(keeplist,CopyZSyms(slocs->symbol.Symbol),slocs->symbol.Sym,slocs->symbol.schid,slocs->symbol.modid),outlist);}
		else syms = PipeSymbolsA(slocs->symbol.Rest,tlocs,msymbol(keeplist,CopyZSyms(slocs->symbol.Symbol),slocs->symbol.Sym,slocs->symbol.schid,slocs->symbol.modid),outlist);
  }
   return syms;

  }
 yyAbort ("PipeSymbolsA");
}

void BeginZSymTabAccess ()
{
}

void CloseZSymTabAccess ()
{
}
