# ifndef yyZParser
# define yyZParser

/* $Id: Parser.h,v 2.1 1992/08/07 15:28:42 grosch rel $ */

# line 12 "/tmp/lalr14416"
# line 187 "ZParser.lalr"


# include "Idents.h"
# include "Positions.h"
# include "ZTree.h"
# include "Errors.h"
# include "global.h"
#include "env.h"



# ifdef yacc_interface
# define ZParser			yyparse
# define yyInitStackSize	YYMAXDEPTH
# endif

extern	char *	ZParser_TokenName [];

extern	int	ZParser	();
extern	void	CloseZParser	();

# endif
