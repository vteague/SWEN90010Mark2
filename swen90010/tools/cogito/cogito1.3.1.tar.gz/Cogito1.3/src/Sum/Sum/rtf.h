# ifndef yyrtf
# define yyrtf

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "Tree.h"
# include "Type.h"


extern void (* rtf_Exit) ();

extern void SumWForm ARGS((tTree t));

extern void Beginrtf ();
extern void Closertf ();

# endif
