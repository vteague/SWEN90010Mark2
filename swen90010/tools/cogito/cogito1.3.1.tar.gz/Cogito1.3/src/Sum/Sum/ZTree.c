# include "ZTree.h"
# define yyALLOC(ptr, size)	if ((ptr = (tZTree) ZTree_PoolFreePtr) >= (tZTree) ZTree_PoolMaxPtr) \
  ptr = ZTree_Alloc (); \
  ZTree_PoolFreePtr += size;
# define yyFREE(ptr, size)	
# ifdef __cplusplus
extern "C" {
# include <stdio.h>
# include "yyZTree.w"
# include "System.h"
# include "General.h"
# include "Memory.h"
# include "DynArray.h"
# include "StringMem.h"
# include "Idents.h"
# include "Sets.h"
# include "Positions.h"
}
# else
# include <stdio.h>
# include "yyZTree.w"
# include "System.h"
# include "General.h"
# include "Memory.h"
# include "DynArray.h"
# include "StringMem.h"
# include "Idents.h"
# include "Sets.h"
# include "Positions.h"
# endif

/* line 17 "z.ast" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include "Idents.h" 
#include "Positions.h"
#include "global.h"
#include "env.h"
#include "ZSyms.h"


/** redefine macros for reuse of trees once the hash table is lost **/
#define writetPosition(pos) WritePosition(yyf,pos);
#define readtPosition(a) ReadPosition(yyf,&a);
#define writetIdPos(a) WriteIdPos(yyf,a);
#define readtIdPos(a) ReadIdPos(yyf,&a);
#define gettPosition(pos) GetPosition(yyf,&pos);
#define puttPosition(pos) PutPosition(yyf,pos);
#define gettIdPos(a) GetIdPos(yyf,&a);
#define puttIdPos(a) PutIdPos(yyf,a);



static void yyExit () { Exit (1); }

void (* ZTree_Exit) () = yyExit;

# define yyBlockSize 20480

typedef struct yysBlock {
 char yyBlock [yyBlockSize];
 struct yysBlock * yySuccessor;
} yytBlock, * yytBlockPtr;

tZTree ZTreeRoot;
unsigned long ZTree_HeapUsed = 0;

static yytBlockPtr yyBlockList	= (yytBlockPtr) NoZTree;
char * ZTree_PoolFreePtr	= (char *) NoZTree;
char * ZTree_PoolMaxPtr	= (char *) NoZTree;
static unsigned short yyMaxSize	= 0;
unsigned short ZTree_NodeSize [116 + 1] = { 0,
 sizeof (ySpecification),
 sizeof (yGlobalParagraphSeq),
 sizeof (ynoGlobalParagraph),
 sizeof (yglobalParagraphs),
 sizeof (yGlobalParagraph),
 sizeof (yaxiomaticDef),
 sizeof (yhorizPar),
 sizeof (ygenericDef),
 sizeof (yschemaboxDef),
 sizeof (yHorizParagraphs),
 sizeof (ynoHorizParagraph),
 sizeof (yhorizParagraphs),
 sizeof (yHorizParagraph),
 sizeof (ytypeDef),
 sizeof (yglobalPredicate),
 sizeof (yschemaDef),
 sizeof (yTypeDef),
 sizeof (ygivenSet),
 sizeof (yfreeType),
 sizeof (ytypeDef1),
 sizeof (ytypeDefPregen),
 sizeof (ytypeDefIngen),
 sizeof (yNameFormals),
 sizeof (ynoFormals),
 sizeof (ynameFormals),
 sizeof (yBranchSeq),
 sizeof (ynoBranch),
 sizeof (ybranch),
 sizeof (yZFormalParams),
 sizeof (ynoFormalParams),
 sizeof (yformalParams),
 sizeof (yZBranch),
 sizeof (ysimpleBranch),
 sizeof (ycompoundBranch),
 sizeof (ySchemaExp),
 sizeof (yschemaSimple),
 sizeof (yschemaDes),
 sizeof (yschemaPreop),
 sizeof (yschemaCons),
 sizeof (yschemaHide),
 sizeof (yschemaQuant),
 sizeof (yschemaComp),
 sizeof (yschemaProject),
 sizeof (yschemaPipe),
 sizeof (yschemaParen),
 sizeof (yDesignator),
 sizeof (yVarNameSeq),
 sizeof (ynoVarName),
 sizeof (yvarNames),
 sizeof (yExpressionSeq),
 sizeof (ynoExpSeq),
 sizeof (yexpSeq),
 sizeof (yRenameSeq),
 sizeof (ynoRename),
 sizeof (yrenames),
 sizeof (yVarRename),
 sizeof (yZSchemaText),
 sizeof (yDeclaration),
 sizeof (ynoDecl),
 sizeof (ydecl),
 sizeof (yBasicDecl),
 sizeof (ycolonDecl),
 sizeof (yschemaRef),
 sizeof (yPredicate),
 sizeof (ynoPred),
 sizeof (ypredNegate),
 sizeof (ypredInfixRelSeq),
 sizeof (ypredTrueOrFalse),
 sizeof (ypredSchemaRef),
 sizeof (ypredPreRel),
 sizeof (ypredCons),
 sizeof (ypredQuant),
 sizeof (ypredLet),
 sizeof (ypredParen),
 sizeof (yPredInfixRelSeq),
 sizeof (ynoInfixRel),
 sizeof (yinfixRels),
 sizeof (yPredInfixRel),
 sizeof (yInfixRel),
 sizeof (yExpression),
 sizeof (ynoExp),
 sizeof (yexpBinaryGen),
 sizeof (yexpBinaryFun),
 sizeof (yexpLiteral),
 sizeof (yexpOpname),
 sizeof (yexpSetElab),
 sizeof (yexpSeqElab),
 sizeof (yexpBagElab),
 sizeof (yexpSetComp),
 sizeof (yexpPowerSet),
 sizeof (yexpPreGen),
 sizeof (yexpPostFun),
 sizeof (yexpIter),
 sizeof (yexpTuple),
 sizeof (yexpCartProd),
 sizeof (yexpTheta),
 sizeof (yexpSelectVar),
 sizeof (yexpFnApp),
 sizeof (yexpMu),
 sizeof (yexpLambda),
 sizeof (yexpLet),
 sizeof (yexpIf),
 sizeof (yexpImage),
 sizeof (yexpDesignator),
 sizeof (yexpParen),
 sizeof (yLetDefSeq),
 sizeof (ynoLetDef),
 sizeof (yletDefs),
 sizeof (yLetDef),
 sizeof (yVarName),
 sizeof (yZId),
 sizeof (yOpname),
 sizeof (yDecoration),
 sizeof (ynoDecoration),
 sizeof (ydecoration),
 sizeof (yZName),
};
char * ZTree_NodeName [116 + 1] = {
 "NoZTree",
 "Specification",
 "GlobalParagraphSeq",
 "noGlobalParagraph",
 "globalParagraphs",
 "GlobalParagraph",
 "axiomaticDef",
 "horizPar",
 "genericDef",
 "schemaboxDef",
 "HorizParagraphs",
 "noHorizParagraph",
 "horizParagraphs",
 "HorizParagraph",
 "typeDef",
 "globalPredicate",
 "schemaDef",
 "TypeDef",
 "givenSet",
 "freeType",
 "typeDef1",
 "typeDefPregen",
 "typeDefIngen",
 "NameFormals",
 "noFormals",
 "nameFormals",
 "BranchSeq",
 "noBranch",
 "branch",
 "ZFormalParams",
 "noFormalParams",
 "formalParams",
 "ZBranch",
 "simpleBranch",
 "compoundBranch",
 "SchemaExp",
 "schemaSimple",
 "schemaDes",
 "schemaPreop",
 "schemaCons",
 "schemaHide",
 "schemaQuant",
 "schemaComp",
 "schemaProject",
 "schemaPipe",
 "schemaParen",
 "Designator",
 "VarNameSeq",
 "noVarName",
 "varNames",
 "ExpressionSeq",
 "noExpSeq",
 "expSeq",
 "RenameSeq",
 "noRename",
 "renames",
 "VarRename",
 "ZSchemaText",
 "Declaration",
 "noDecl",
 "decl",
 "BasicDecl",
 "colonDecl",
 "schemaRef",
 "Predicate",
 "noPred",
 "predNegate",
 "predInfixRelSeq",
 "predTrueOrFalse",
 "predSchemaRef",
 "predPreRel",
 "predCons",
 "predQuant",
 "predLet",
 "predParen",
 "PredInfixRelSeq",
 "noInfixRel",
 "infixRels",
 "PredInfixRel",
 "InfixRel",
 "Expression",
 "noExp",
 "expBinaryGen",
 "expBinaryFun",
 "expLiteral",
 "expOpname",
 "expSetElab",
 "expSeqElab",
 "expBagElab",
 "expSetComp",
 "expPowerSet",
 "expPreGen",
 "expPostFun",
 "expIter",
 "expTuple",
 "expCartProd",
 "expTheta",
 "expSelectVar",
 "expFnApp",
 "expMu",
 "expLambda",
 "expLet",
 "expIf",
 "expImage",
 "expDesignator",
 "expParen",
 "LetDefSeq",
 "noLetDef",
 "letDefs",
 "LetDef",
 "VarName",
 "ZId",
 "Opname",
 "Decoration",
 "noDecoration",
 "decoration",
 "ZName",
};
static ZTree_tKind yyTypeRange [116 + 1] = { 0,
 kSpecification,
 kglobalParagraphs,
 knoGlobalParagraph,
 kglobalParagraphs,
 kschemaboxDef,
 kaxiomaticDef,
 khorizPar,
 kgenericDef,
 kschemaboxDef,
 khorizParagraphs,
 knoHorizParagraph,
 khorizParagraphs,
 kschemaDef,
 ktypeDef,
 kglobalPredicate,
 kschemaDef,
 ktypeDefIngen,
 kgivenSet,
 kfreeType,
 ktypeDef1,
 ktypeDefPregen,
 ktypeDefIngen,
 knameFormals,
 knoFormals,
 knameFormals,
 kbranch,
 knoBranch,
 kbranch,
 kformalParams,
 knoFormalParams,
 kformalParams,
 kcompoundBranch,
 ksimpleBranch,
 kcompoundBranch,
 kschemaParen,
 kschemaSimple,
 kschemaDes,
 kschemaPreop,
 kschemaCons,
 kschemaHide,
 kschemaQuant,
 kschemaComp,
 kschemaProject,
 kschemaPipe,
 kschemaParen,
 kDesignator,
 kvarNames,
 knoVarName,
 kvarNames,
 kexpSeq,
 knoExpSeq,
 kexpSeq,
 krenames,
 knoRename,
 krenames,
 kVarRename,
 kZSchemaText,
 kdecl,
 knoDecl,
 kdecl,
 kschemaRef,
 kcolonDecl,
 kschemaRef,
 kpredParen,
 knoPred,
 kpredNegate,
 kpredInfixRelSeq,
 kpredTrueOrFalse,
 kpredSchemaRef,
 kpredPreRel,
 kpredCons,
 kpredQuant,
 kpredLet,
 kpredParen,
 kinfixRels,
 knoInfixRel,
 kinfixRels,
 kPredInfixRel,
 kInfixRel,
 kexpParen,
 knoExp,
 kexpBinaryGen,
 kexpBinaryFun,
 kexpLiteral,
 kexpOpname,
 kexpSetElab,
 kexpSeqElab,
 kexpBagElab,
 kexpSetComp,
 kexpPowerSet,
 kexpPreGen,
 kexpPostFun,
 kexpIter,
 kexpTuple,
 kexpCartProd,
 kexpTheta,
 kexpSelectVar,
 kexpFnApp,
 kexpMu,
 kexpLambda,
 kexpLet,
 kexpIf,
 kexpImage,
 kexpDesignator,
 kexpParen,
 kletDefs,
 knoLetDef,
 kletDefs,
 kLetDef,
 kOpname,
 kZId,
 kOpname,
 kdecoration,
 knoDecoration,
 kdecoration,
 kZName,
};

tZTree ZTree_Alloc ()
{
 register yytBlockPtr yyBlockPtr = yyBlockList;
 register int i;

 if (yyMaxSize == 0)
  for (i = 1; i <= 116; i ++) {
   ZTree_NodeSize [i] = (ZTree_NodeSize [i] + yyMaxAlign - 1) & yyAlignMasks [yyMaxAlign];
   yyMaxSize = Max (ZTree_NodeSize [i], yyMaxSize);
  }
 yyBlockList = (yytBlockPtr) Alloc (sizeof (yytBlock));
 yyBlockList->yySuccessor = yyBlockPtr;
 ZTree_PoolFreePtr = yyBlockList->yyBlock;
 ZTree_PoolMaxPtr = ZTree_PoolFreePtr + yyBlockSize - yyMaxSize + 1;
 ZTree_HeapUsed += yyBlockSize;
 return (tZTree) ZTree_PoolFreePtr;
}

tZTree MakeZTree
# if defined __STDC__ | defined __cplusplus
 (ZTree_tKind yyKind)
# else
 (yyKind) ZTree_tKind yyKind;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [yyKind])
 yyt->Kind = yyKind;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

bool ZTree_IsType
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt, register ZTree_tKind yyKind)
# else
 (yyt, yyKind) register tZTree yyt; register ZTree_tKind yyKind;
# endif
{
 return yyt != NoZTree && yyKind <= yyt->Kind && yyt->Kind <= yyTypeRange [yyKind];
}

tZTree nSpecification () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kSpecification])
 yyt->Kind = kSpecification;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->Specification.GlobalParagraphSeq)
 return yyt;
}

tZTree nGlobalParagraphSeq () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kGlobalParagraphSeq])
 yyt->Kind = kGlobalParagraphSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoGlobalParagraph () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoGlobalParagraph])
 yyt->Kind = knoGlobalParagraph;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nglobalParagraphs () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kglobalParagraphs])
 yyt->Kind = kglobalParagraphs;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->globalParagraphs.GlobalParagraph)
 begintZTree(yyt->globalParagraphs.Next)
 return yyt;
}

tZTree nGlobalParagraph () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kGlobalParagraph])
 yyt->Kind = kGlobalParagraph;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree naxiomaticDef () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kaxiomaticDef])
 yyt->Kind = kaxiomaticDef;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->axiomaticDef.ZSchemaText)
 return yyt;
}

tZTree nhorizPar () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [khorizPar])
 yyt->Kind = khorizPar;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->horizPar.HorizParagraphs)
 return yyt;
}

tZTree ngenericDef () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kgenericDef])
 yyt->Kind = kgenericDef;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->genericDef.ZFormalParams)
 begintZTree(yyt->genericDef.ZSchemaText)
 return yyt;
}

tZTree nschemaboxDef () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaboxDef])
 yyt->Kind = kschemaboxDef;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->schemaboxDef.ZName)
 begintZTree(yyt->schemaboxDef.ZFormalParams)
 begintZTree(yyt->schemaboxDef.ZSchemaText)
 return yyt;
}

tZTree nHorizParagraphs () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kHorizParagraphs])
 yyt->Kind = kHorizParagraphs;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoHorizParagraph () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoHorizParagraph])
 yyt->Kind = knoHorizParagraph;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nhorizParagraphs () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [khorizParagraphs])
 yyt->Kind = khorizParagraphs;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->horizParagraphs.HorizParagraph)
 begintZTree(yyt->horizParagraphs.Next)
 return yyt;
}

tZTree nHorizParagraph () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kHorizParagraph])
 yyt->Kind = kHorizParagraph;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree ntypeDef () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [ktypeDef])
 yyt->Kind = ktypeDef;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->typeDef.TypeDef)
 return yyt;
}

tZTree nglobalPredicate () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kglobalPredicate])
 yyt->Kind = kglobalPredicate;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->globalPredicate.Predicate)
 return yyt;
}

tZTree nschemaDef () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaDef])
 yyt->Kind = kschemaDef;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->schemaDef.NameFormals)
 begintZTree(yyt->schemaDef.SchemaExp)
 return yyt;
}

tZTree nTypeDef () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kTypeDef])
 yyt->Kind = kTypeDef;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree ngivenSet () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kgivenSet])
 yyt->Kind = kgivenSet;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->givenSet.VarNameSeq)
 return yyt;
}

tZTree nfreeType () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kfreeType])
 yyt->Kind = kfreeType;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->freeType.VarName)
 begintZTree(yyt->freeType.BranchSeq)
 return yyt;
}

tZTree ntypeDef1 () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [ktypeDef1])
 yyt->Kind = ktypeDef1;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->typeDef1.NameFormals)
 begintZTree(yyt->typeDef1.Expression)
 return yyt;
}

tZTree ntypeDefPregen () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [ktypeDefPregen])
 yyt->Kind = ktypeDefPregen;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->typeDefPregen.PreGen)
 begintZTree(yyt->typeDefPregen.Decoration)
 begintZTree(yyt->typeDefPregen.VarName)
 begintZTree(yyt->typeDefPregen.Expression)
 return yyt;
}

tZTree ntypeDefIngen () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [ktypeDefIngen])
 yyt->Kind = ktypeDefIngen;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->typeDefIngen.Var1)
 begintIdPos(yyt->typeDefIngen.InGen)
 begintZTree(yyt->typeDefIngen.Decoration)
 begintZTree(yyt->typeDefIngen.Var2)
 begintZTree(yyt->typeDefIngen.Expression)
 return yyt;
}

tZTree nNameFormals () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kNameFormals])
 yyt->Kind = kNameFormals;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->NameFormals.VarName)
 return yyt;
}

tZTree nnoFormals () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoFormals])
 yyt->Kind = knoFormals;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->noFormals.VarName)
 return yyt;
}

tZTree nnameFormals () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knameFormals])
 yyt->Kind = knameFormals;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->nameFormals.VarName)
 begintZTree(yyt->nameFormals.ZFormalParams)
 return yyt;
}

tZTree nBranchSeq () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kBranchSeq])
 yyt->Kind = kBranchSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoBranch () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoBranch])
 yyt->Kind = knoBranch;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nbranch () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kbranch])
 yyt->Kind = kbranch;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->branch.ZBranch)
 begintZTree(yyt->branch.Next)
 return yyt;
}

tZTree nZFormalParams () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kZFormalParams])
 yyt->Kind = kZFormalParams;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoFormalParams () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoFormalParams])
 yyt->Kind = knoFormalParams;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nformalParams () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kformalParams])
 yyt->Kind = kformalParams;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->formalParams.VarNameSeq)
 return yyt;
}

tZTree nZBranch () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kZBranch])
 yyt->Kind = kZBranch;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nsimpleBranch () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [ksimpleBranch])
 yyt->Kind = ksimpleBranch;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->simpleBranch.VarName)
 return yyt;
}

tZTree ncompoundBranch () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kcompoundBranch])
 yyt->Kind = kcompoundBranch;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->compoundBranch.VarName)
 begintZTree(yyt->compoundBranch.Expression)
 return yyt;
}

tZTree nSchemaExp () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kSchemaExp])
 yyt->Kind = kSchemaExp;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nschemaSimple () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaSimple])
 yyt->Kind = kschemaSimple;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->schemaSimple.ZSchemaText)
 return yyt;
}

tZTree nschemaDes () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaDes])
 yyt->Kind = kschemaDes;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->schemaDes.Designator)
 return yyt;
}

tZTree nschemaPreop () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaPreop])
 yyt->Kind = kschemaPreop;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->schemaPreop.PreOp)
 begintZTree(yyt->schemaPreop.SchemaExp)
 return yyt;
}

tZTree nschemaCons () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaCons])
 yyt->Kind = kschemaCons;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->schemaCons.Lop)
 begintIdPos(yyt->schemaCons.SchemaOp)
 begintZTree(yyt->schemaCons.Rop)
 return yyt;
}

tZTree nschemaHide () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaHide])
 yyt->Kind = kschemaHide;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->schemaHide.SchemaExp)
 begintZTree(yyt->schemaHide.VarNameSeq)
 return yyt;
}

tZTree nschemaQuant () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaQuant])
 yyt->Kind = kschemaQuant;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->schemaQuant.LogQuant)
 begintZTree(yyt->schemaQuant.ZSchemaText)
 begintZTree(yyt->schemaQuant.SchemaExp)
 return yyt;
}

tZTree nschemaComp () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaComp])
 yyt->Kind = kschemaComp;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->schemaComp.Lop)
 begintZTree(yyt->schemaComp.Rop)
 return yyt;
}

tZTree nschemaProject () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaProject])
 yyt->Kind = kschemaProject;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->schemaProject.Lop)
 begintZTree(yyt->schemaProject.Rop)
 return yyt;
}

tZTree nschemaPipe () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaPipe])
 yyt->Kind = kschemaPipe;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->schemaPipe.Lop)
 begintZTree(yyt->schemaPipe.Rop)
 return yyt;
}

tZTree nschemaParen () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaParen])
 yyt->Kind = kschemaParen;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->schemaParen.SchemaExp)
 return yyt;
}

tZTree nDesignator () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kDesignator])
 yyt->Kind = kDesignator;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->Designator.ZName)
 begintZTree(yyt->Designator.Decoration)
 begintZTree(yyt->Designator.ExpressionSeq)
 begintZTree(yyt->Designator.RenameSeq)
 beginbool(yyt->Designator.IsSchemaRef)
 return yyt;
}

tZTree nVarNameSeq () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kVarNameSeq])
 yyt->Kind = kVarNameSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoVarName () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoVarName])
 yyt->Kind = knoVarName;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nvarNames () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kvarNames])
 yyt->Kind = kvarNames;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->varNames.VarName)
 begintZTree(yyt->varNames.Next)
 return yyt;
}

tZTree nExpressionSeq () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kExpressionSeq])
 yyt->Kind = kExpressionSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoExpSeq () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoExpSeq])
 yyt->Kind = knoExpSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nexpSeq () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpSeq])
 yyt->Kind = kexpSeq;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expSeq.Expression)
 begintZTree(yyt->expSeq.Next)
 return yyt;
}

tZTree nRenameSeq () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kRenameSeq])
 yyt->Kind = kRenameSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoRename () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoRename])
 yyt->Kind = knoRename;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nrenames () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [krenames])
 yyt->Kind = krenames;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->renames.VarRename)
 begintZTree(yyt->renames.Next)
 return yyt;
}

tZTree nVarRename () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kVarRename])
 yyt->Kind = kVarRename;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->VarRename.New)
 begintZTree(yyt->VarRename.Old)
 return yyt;
}

tZTree nZSchemaText () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kZSchemaText])
 yyt->Kind = kZSchemaText;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->ZSchemaText.Declaration)
 begintZTree(yyt->ZSchemaText.Predicate)
 return yyt;
}

tZTree nDeclaration () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kDeclaration])
 yyt->Kind = kDeclaration;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoDecl () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoDecl])
 yyt->Kind = knoDecl;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree ndecl () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kdecl])
 yyt->Kind = kdecl;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->decl.BasicDecl)
 begintZTree(yyt->decl.Next)
 return yyt;
}

tZTree nBasicDecl () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kBasicDecl])
 yyt->Kind = kBasicDecl;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree ncolonDecl () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kcolonDecl])
 yyt->Kind = kcolonDecl;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->colonDecl.VarNameSeq)
 begintZTree(yyt->colonDecl.Expression)
 return yyt;
}

tZTree nschemaRef () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaRef])
 yyt->Kind = kschemaRef;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->schemaRef.Designator)
 return yyt;
}

tZTree nPredicate () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kPredicate])
 yyt->Kind = kPredicate;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoPred () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoPred])
 yyt->Kind = knoPred;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree npredNegate () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredNegate])
 yyt->Kind = kpredNegate;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->predNegate.Predicate)
 return yyt;
}

tZTree npredInfixRelSeq () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredInfixRelSeq])
 yyt->Kind = kpredInfixRelSeq;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->predInfixRelSeq.PredInfixRelSeq)
 return yyt;
}

tZTree npredTrueOrFalse () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredTrueOrFalse])
 yyt->Kind = kpredTrueOrFalse;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->predTrueOrFalse.TrueFalse)
 return yyt;
}

tZTree npredSchemaRef () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredSchemaRef])
 yyt->Kind = kpredSchemaRef;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->predSchemaRef.PredOrPre)
 begintZTree(yyt->predSchemaRef.Designator)
 return yyt;
}

tZTree npredPreRel () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredPreRel])
 yyt->Kind = kpredPreRel;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->predPreRel.PreRel)
 begintZTree(yyt->predPreRel.Decoration)
 begintZTree(yyt->predPreRel.Expression)
 return yyt;
}

tZTree npredCons () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredCons])
 yyt->Kind = kpredCons;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->predCons.Lpred)
 begintIdPos(yyt->predCons.LogOp)
 begintZTree(yyt->predCons.Rpred)
 return yyt;
}

tZTree npredQuant () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredQuant])
 yyt->Kind = kpredQuant;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->predQuant.LogQuant)
 begintZTree(yyt->predQuant.ZSchemaText)
 begintZTree(yyt->predQuant.Predicate)
 return yyt;
}

tZTree npredLet () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredLet])
 yyt->Kind = kpredLet;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->predLet.LetDefSeq)
 begintZTree(yyt->predLet.Predicate)
 return yyt;
}

tZTree npredParen () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredParen])
 yyt->Kind = kpredParen;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->predParen.Predicate)
 return yyt;
}

tZTree nPredInfixRelSeq () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kPredInfixRelSeq])
 yyt->Kind = kPredInfixRelSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoInfixRel () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoInfixRel])
 yyt->Kind = knoInfixRel;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree ninfixRels () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kinfixRels])
 yyt->Kind = kinfixRels;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->infixRels.PredInfixRel)
 begintZTree(yyt->infixRels.Next)
 return yyt;
}

tZTree nPredInfixRel () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kPredInfixRel])
 yyt->Kind = kPredInfixRel;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->PredInfixRel.Lexp)
 begintZTree(yyt->PredInfixRel.InfixRel)
 begintZTree(yyt->PredInfixRel.Rexp)
 return yyt;
}

tZTree nInfixRel () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kInfixRel])
 yyt->Kind = kInfixRel;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->InfixRel.InRel)
 begintZTree(yyt->InfixRel.Decoration)
 return yyt;
}

tZTree nExpression () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kExpression])
 yyt->Kind = kExpression;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoExp () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoExp])
 yyt->Kind = knoExp;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nexpBinaryGen () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpBinaryGen])
 yyt->Kind = kexpBinaryGen;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expBinaryGen.lexp)
 begintIdPos(yyt->expBinaryGen.InGen)
 begintZTree(yyt->expBinaryGen.Decoration)
 begintZTree(yyt->expBinaryGen.rexp)
 return yyt;
}

tZTree nexpBinaryFun () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpBinaryFun])
 yyt->Kind = kexpBinaryFun;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expBinaryFun.lexp)
 begintIdPos(yyt->expBinaryFun.InFun)
 begintZTree(yyt->expBinaryFun.Decoration)
 begintZTree(yyt->expBinaryFun.rexp)
 return yyt;
}

tZTree nexpLiteral () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpLiteral])
 yyt->Kind = kexpLiteral;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->expLiteral.Literal)
 return yyt;
}

tZTree nexpOpname () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpOpname])
 yyt->Kind = kexpOpname;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expOpname.VarName)
 begintZTree(yyt->expOpname.ExpressionSeq)
 return yyt;
}

tZTree nexpSetElab () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpSetElab])
 yyt->Kind = kexpSetElab;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expSetElab.ExpressionSeq)
 return yyt;
}

tZTree nexpSeqElab () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpSeqElab])
 yyt->Kind = kexpSeqElab;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expSeqElab.ExpressionSeq)
 return yyt;
}

tZTree nexpBagElab () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpBagElab])
 yyt->Kind = kexpBagElab;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expBagElab.ExpressionSeq)
 return yyt;
}

tZTree nexpSetComp () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpSetComp])
 yyt->Kind = kexpSetComp;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expSetComp.ZSchemaText)
 begintZTree(yyt->expSetComp.Expression)
 return yyt;
}

tZTree nexpPowerSet () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpPowerSet])
 yyt->Kind = kexpPowerSet;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expPowerSet.Expression)
 return yyt;
}

tZTree nexpPreGen () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpPreGen])
 yyt->Kind = kexpPreGen;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->expPreGen.Pregen)
 begintZTree(yyt->expPreGen.Decoration)
 begintZTree(yyt->expPreGen.Expression)
 return yyt;
}

tZTree nexpPostFun () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpPostFun])
 yyt->Kind = kexpPostFun;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expPostFun.Expression)
 begintIdPos(yyt->expPostFun.Postfun)
 begintZTree(yyt->expPostFun.Decoration)
 return yyt;
}

tZTree nexpIter () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpIter])
 yyt->Kind = kexpIter;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expIter.exp1)
 begintZTree(yyt->expIter.exp2)
 return yyt;
}

tZTree nexpTuple () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpTuple])
 yyt->Kind = kexpTuple;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expTuple.ExpressionSeq)
 return yyt;
}

tZTree nexpCartProd () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpCartProd])
 yyt->Kind = kexpCartProd;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expCartProd.ExpressionSeq)
 return yyt;
}

tZTree nexpTheta () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpTheta])
 yyt->Kind = kexpTheta;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expTheta.ZName)
 begintZTree(yyt->expTheta.Decoration)
 begintZTree(yyt->expTheta.RenameSeq)
 return yyt;
}

tZTree nexpSelectVar () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpSelectVar])
 yyt->Kind = kexpSelectVar;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expSelectVar.Expression)
 begintZTree(yyt->expSelectVar.VarName)
 return yyt;
}

tZTree nexpFnApp () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpFnApp])
 yyt->Kind = kexpFnApp;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expFnApp.FnName)
 begintZTree(yyt->expFnApp.Params)
 return yyt;
}

tZTree nexpMu () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpMu])
 yyt->Kind = kexpMu;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expMu.ZSchemaText)
 begintZTree(yyt->expMu.Expression)
 return yyt;
}

tZTree nexpLambda () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpLambda])
 yyt->Kind = kexpLambda;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expLambda.ZSchemaText)
 begintZTree(yyt->expLambda.Expression)
 return yyt;
}

tZTree nexpLet () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpLet])
 yyt->Kind = kexpLet;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expLet.LetDefSeq)
 begintZTree(yyt->expLet.Expression)
 return yyt;
}

tZTree nexpIf () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpIf])
 yyt->Kind = kexpIf;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expIf.Predicate)
 begintZTree(yyt->expIf.Exp1)
 begintZTree(yyt->expIf.Exp2)
 return yyt;
}

tZTree nexpImage () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpImage])
 yyt->Kind = kexpImage;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expImage.Exp1)
 begintZTree(yyt->expImage.Exp2)
 begintIdPos(yyt->expImage.Image)
 begintZTree(yyt->expImage.Decoration)
 return yyt;
}

tZTree nexpDesignator () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpDesignator])
 yyt->Kind = kexpDesignator;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expDesignator.Designator)
 return yyt;
}

tZTree nexpParen () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpParen])
 yyt->Kind = kexpParen;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->expParen.Expression)
 return yyt;
}

tZTree nLetDefSeq () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kLetDefSeq])
 yyt->Kind = kLetDefSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoLetDef () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoLetDef])
 yyt->Kind = knoLetDef;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nletDefs () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kletDefs])
 yyt->Kind = kletDefs;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->letDefs.LetDef)
 begintZTree(yyt->letDefs.Next)
 return yyt;
}

tZTree nLetDef () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kLetDef])
 yyt->Kind = kLetDef;
 yyt->yyHead.yyMark = 0;
 begintZTree(yyt->LetDef.VarName)
 begintZTree(yyt->LetDef.Expression)
 return yyt;
}

tZTree nVarName () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kVarName])
 yyt->Kind = kVarName;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->VarName.Ident)
 begintZTree(yyt->VarName.Decoration)
 return yyt;
}

tZTree nZId () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kZId])
 yyt->Kind = kZId;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->ZId.Ident)
 begintZTree(yyt->ZId.Decoration)
 return yyt;
}

tZTree nOpname () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kOpname])
 yyt->Kind = kOpname;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->Opname.Ident)
 begintZTree(yyt->Opname.Decoration)
 return yyt;
}

tZTree nDecoration () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kDecoration])
 yyt->Kind = kDecoration;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree nnoDecoration () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoDecoration])
 yyt->Kind = knoDecoration;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree ndecoration () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kdecoration])
 yyt->Kind = kdecoration;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->decoration.Stroke)
 begintZTree(yyt->decoration.Next)
 return yyt;
}

tZTree nZName () {
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kZName])
 yyt->Kind = kZName;
 yyt->yyHead.yyMark = 0;
 begintIdPos(yyt->ZName.Ident)
 return yyt;
}


tZTree mSpecification
# if defined __STDC__ | defined __cplusplus
(tZTree pGlobalParagraphSeq)
# else
(pGlobalParagraphSeq)
tZTree pGlobalParagraphSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kSpecification])
 yyt->Kind = kSpecification;
 yyt->yyHead.yyMark = 0;
 yyt->Specification.GlobalParagraphSeq = pGlobalParagraphSeq;
 return yyt;
}

tZTree mGlobalParagraphSeq
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kGlobalParagraphSeq])
 yyt->Kind = kGlobalParagraphSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoGlobalParagraph
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoGlobalParagraph])
 yyt->Kind = knoGlobalParagraph;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mglobalParagraphs
# if defined __STDC__ | defined __cplusplus
(tZTree pGlobalParagraph, tZTree pNext)
# else
(pGlobalParagraph, pNext)
tZTree pGlobalParagraph;
tZTree pNext;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kglobalParagraphs])
 yyt->Kind = kglobalParagraphs;
 yyt->yyHead.yyMark = 0;
 yyt->globalParagraphs.GlobalParagraph = pGlobalParagraph;
 yyt->globalParagraphs.Next = pNext;
 return yyt;
}

tZTree mGlobalParagraph
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kGlobalParagraph])
 yyt->Kind = kGlobalParagraph;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree maxiomaticDef
# if defined __STDC__ | defined __cplusplus
(tZTree pZSchemaText)
# else
(pZSchemaText)
tZTree pZSchemaText;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kaxiomaticDef])
 yyt->Kind = kaxiomaticDef;
 yyt->yyHead.yyMark = 0;
 yyt->axiomaticDef.ZSchemaText = pZSchemaText;
 return yyt;
}

tZTree mhorizPar
# if defined __STDC__ | defined __cplusplus
(tZTree pHorizParagraphs)
# else
(pHorizParagraphs)
tZTree pHorizParagraphs;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [khorizPar])
 yyt->Kind = khorizPar;
 yyt->yyHead.yyMark = 0;
 yyt->horizPar.HorizParagraphs = pHorizParagraphs;
 return yyt;
}

tZTree mgenericDef
# if defined __STDC__ | defined __cplusplus
(tZTree pZFormalParams, tZTree pZSchemaText)
# else
(pZFormalParams, pZSchemaText)
tZTree pZFormalParams;
tZTree pZSchemaText;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kgenericDef])
 yyt->Kind = kgenericDef;
 yyt->yyHead.yyMark = 0;
 yyt->genericDef.ZFormalParams = pZFormalParams;
 yyt->genericDef.ZSchemaText = pZSchemaText;
 return yyt;
}

tZTree mschemaboxDef
# if defined __STDC__ | defined __cplusplus
(tZTree pZName, tZTree pZFormalParams, tZTree pZSchemaText)
# else
(pZName, pZFormalParams, pZSchemaText)
tZTree pZName;
tZTree pZFormalParams;
tZTree pZSchemaText;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaboxDef])
 yyt->Kind = kschemaboxDef;
 yyt->yyHead.yyMark = 0;
 yyt->schemaboxDef.ZName = pZName;
 yyt->schemaboxDef.ZFormalParams = pZFormalParams;
 yyt->schemaboxDef.ZSchemaText = pZSchemaText;
 return yyt;
}

tZTree mHorizParagraphs
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kHorizParagraphs])
 yyt->Kind = kHorizParagraphs;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoHorizParagraph
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoHorizParagraph])
 yyt->Kind = knoHorizParagraph;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mhorizParagraphs
# if defined __STDC__ | defined __cplusplus
(tZTree pHorizParagraph, tZTree pNext)
# else
(pHorizParagraph, pNext)
tZTree pHorizParagraph;
tZTree pNext;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [khorizParagraphs])
 yyt->Kind = khorizParagraphs;
 yyt->yyHead.yyMark = 0;
 yyt->horizParagraphs.HorizParagraph = pHorizParagraph;
 yyt->horizParagraphs.Next = pNext;
 return yyt;
}

tZTree mHorizParagraph
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kHorizParagraph])
 yyt->Kind = kHorizParagraph;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mtypeDef
# if defined __STDC__ | defined __cplusplus
(tZTree pTypeDef)
# else
(pTypeDef)
tZTree pTypeDef;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [ktypeDef])
 yyt->Kind = ktypeDef;
 yyt->yyHead.yyMark = 0;
 yyt->typeDef.TypeDef = pTypeDef;
 return yyt;
}

tZTree mglobalPredicate
# if defined __STDC__ | defined __cplusplus
(tZTree pPredicate)
# else
(pPredicate)
tZTree pPredicate;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kglobalPredicate])
 yyt->Kind = kglobalPredicate;
 yyt->yyHead.yyMark = 0;
 yyt->globalPredicate.Predicate = pPredicate;
 return yyt;
}

tZTree mschemaDef
# if defined __STDC__ | defined __cplusplus
(tZTree pNameFormals, tZTree pSchemaExp)
# else
(pNameFormals, pSchemaExp)
tZTree pNameFormals;
tZTree pSchemaExp;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaDef])
 yyt->Kind = kschemaDef;
 yyt->yyHead.yyMark = 0;
 yyt->schemaDef.NameFormals = pNameFormals;
 yyt->schemaDef.SchemaExp = pSchemaExp;
 return yyt;
}

tZTree mTypeDef
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kTypeDef])
 yyt->Kind = kTypeDef;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mgivenSet
# if defined __STDC__ | defined __cplusplus
(tZTree pVarNameSeq)
# else
(pVarNameSeq)
tZTree pVarNameSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kgivenSet])
 yyt->Kind = kgivenSet;
 yyt->yyHead.yyMark = 0;
 yyt->givenSet.VarNameSeq = pVarNameSeq;
 return yyt;
}

tZTree mfreeType
# if defined __STDC__ | defined __cplusplus
(tZTree pVarName, tZTree pBranchSeq)
# else
(pVarName, pBranchSeq)
tZTree pVarName;
tZTree pBranchSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kfreeType])
 yyt->Kind = kfreeType;
 yyt->yyHead.yyMark = 0;
 yyt->freeType.VarName = pVarName;
 yyt->freeType.BranchSeq = pBranchSeq;
 return yyt;
}

tZTree mtypeDef1
# if defined __STDC__ | defined __cplusplus
(tZTree pNameFormals, tZTree pExpression)
# else
(pNameFormals, pExpression)
tZTree pNameFormals;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [ktypeDef1])
 yyt->Kind = ktypeDef1;
 yyt->yyHead.yyMark = 0;
 yyt->typeDef1.NameFormals = pNameFormals;
 yyt->typeDef1.Expression = pExpression;
 return yyt;
}

tZTree mtypeDefPregen
# if defined __STDC__ | defined __cplusplus
(tIdPos pPreGen, tZTree pDecoration, tZTree pVarName, tZTree pExpression)
# else
(pPreGen, pDecoration, pVarName, pExpression)
tIdPos pPreGen;
tZTree pDecoration;
tZTree pVarName;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [ktypeDefPregen])
 yyt->Kind = ktypeDefPregen;
 yyt->yyHead.yyMark = 0;
 yyt->typeDefPregen.PreGen = pPreGen;
 yyt->typeDefPregen.Decoration = pDecoration;
 yyt->typeDefPregen.VarName = pVarName;
 yyt->typeDefPregen.Expression = pExpression;
 return yyt;
}

tZTree mtypeDefIngen
# if defined __STDC__ | defined __cplusplus
(tZTree pVar1, tIdPos pInGen, tZTree pDecoration, tZTree pVar2, tZTree pExpression)
# else
(pVar1, pInGen, pDecoration, pVar2, pExpression)
tZTree pVar1;
tIdPos pInGen;
tZTree pDecoration;
tZTree pVar2;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [ktypeDefIngen])
 yyt->Kind = ktypeDefIngen;
 yyt->yyHead.yyMark = 0;
 yyt->typeDefIngen.Var1 = pVar1;
 yyt->typeDefIngen.InGen = pInGen;
 yyt->typeDefIngen.Decoration = pDecoration;
 yyt->typeDefIngen.Var2 = pVar2;
 yyt->typeDefIngen.Expression = pExpression;
 return yyt;
}

tZTree mNameFormals
# if defined __STDC__ | defined __cplusplus
(tZTree pVarName)
# else
(pVarName)
tZTree pVarName;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kNameFormals])
 yyt->Kind = kNameFormals;
 yyt->yyHead.yyMark = 0;
 yyt->NameFormals.VarName = pVarName;
 return yyt;
}

tZTree mnoFormals
# if defined __STDC__ | defined __cplusplus
(tZTree pVarName)
# else
(pVarName)
tZTree pVarName;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoFormals])
 yyt->Kind = knoFormals;
 yyt->yyHead.yyMark = 0;
 yyt->noFormals.VarName = pVarName;
 return yyt;
}

tZTree mnameFormals
# if defined __STDC__ | defined __cplusplus
(tZTree pVarName, tZTree pZFormalParams)
# else
(pVarName, pZFormalParams)
tZTree pVarName;
tZTree pZFormalParams;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knameFormals])
 yyt->Kind = knameFormals;
 yyt->yyHead.yyMark = 0;
 yyt->nameFormals.VarName = pVarName;
 yyt->nameFormals.ZFormalParams = pZFormalParams;
 return yyt;
}

tZTree mBranchSeq
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kBranchSeq])
 yyt->Kind = kBranchSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoBranch
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoBranch])
 yyt->Kind = knoBranch;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mbranch
# if defined __STDC__ | defined __cplusplus
(tZTree pZBranch, tZTree pNext)
# else
(pZBranch, pNext)
tZTree pZBranch;
tZTree pNext;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kbranch])
 yyt->Kind = kbranch;
 yyt->yyHead.yyMark = 0;
 yyt->branch.ZBranch = pZBranch;
 yyt->branch.Next = pNext;
 return yyt;
}

tZTree mZFormalParams
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kZFormalParams])
 yyt->Kind = kZFormalParams;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoFormalParams
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoFormalParams])
 yyt->Kind = knoFormalParams;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mformalParams
# if defined __STDC__ | defined __cplusplus
(tZTree pVarNameSeq)
# else
(pVarNameSeq)
tZTree pVarNameSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kformalParams])
 yyt->Kind = kformalParams;
 yyt->yyHead.yyMark = 0;
 yyt->formalParams.VarNameSeq = pVarNameSeq;
 return yyt;
}

tZTree mZBranch
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kZBranch])
 yyt->Kind = kZBranch;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree msimpleBranch
# if defined __STDC__ | defined __cplusplus
(tZTree pVarName)
# else
(pVarName)
tZTree pVarName;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [ksimpleBranch])
 yyt->Kind = ksimpleBranch;
 yyt->yyHead.yyMark = 0;
 yyt->simpleBranch.VarName = pVarName;
 return yyt;
}

tZTree mcompoundBranch
# if defined __STDC__ | defined __cplusplus
(tZTree pVarName, tZTree pExpression)
# else
(pVarName, pExpression)
tZTree pVarName;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kcompoundBranch])
 yyt->Kind = kcompoundBranch;
 yyt->yyHead.yyMark = 0;
 yyt->compoundBranch.VarName = pVarName;
 yyt->compoundBranch.Expression = pExpression;
 return yyt;
}

tZTree mSchemaExp
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kSchemaExp])
 yyt->Kind = kSchemaExp;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mschemaSimple
# if defined __STDC__ | defined __cplusplus
(tZTree pZSchemaText)
# else
(pZSchemaText)
tZTree pZSchemaText;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaSimple])
 yyt->Kind = kschemaSimple;
 yyt->yyHead.yyMark = 0;
 yyt->schemaSimple.ZSchemaText = pZSchemaText;
 return yyt;
}

tZTree mschemaDes
# if defined __STDC__ | defined __cplusplus
(tZTree pDesignator)
# else
(pDesignator)
tZTree pDesignator;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaDes])
 yyt->Kind = kschemaDes;
 yyt->yyHead.yyMark = 0;
 yyt->schemaDes.Designator = pDesignator;
 return yyt;
}

tZTree mschemaPreop
# if defined __STDC__ | defined __cplusplus
(tIdPos pPreOp, tZTree pSchemaExp)
# else
(pPreOp, pSchemaExp)
tIdPos pPreOp;
tZTree pSchemaExp;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaPreop])
 yyt->Kind = kschemaPreop;
 yyt->yyHead.yyMark = 0;
 yyt->schemaPreop.PreOp = pPreOp;
 yyt->schemaPreop.SchemaExp = pSchemaExp;
 return yyt;
}

tZTree mschemaCons
# if defined __STDC__ | defined __cplusplus
(tZTree pLop, tIdPos pSchemaOp, tZTree pRop)
# else
(pLop, pSchemaOp, pRop)
tZTree pLop;
tIdPos pSchemaOp;
tZTree pRop;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaCons])
 yyt->Kind = kschemaCons;
 yyt->yyHead.yyMark = 0;
 yyt->schemaCons.Lop = pLop;
 yyt->schemaCons.SchemaOp = pSchemaOp;
 yyt->schemaCons.Rop = pRop;
 return yyt;
}

tZTree mschemaHide
# if defined __STDC__ | defined __cplusplus
(tZTree pSchemaExp, tZTree pVarNameSeq)
# else
(pSchemaExp, pVarNameSeq)
tZTree pSchemaExp;
tZTree pVarNameSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaHide])
 yyt->Kind = kschemaHide;
 yyt->yyHead.yyMark = 0;
 yyt->schemaHide.SchemaExp = pSchemaExp;
 yyt->schemaHide.VarNameSeq = pVarNameSeq;
 return yyt;
}

tZTree mschemaQuant
# if defined __STDC__ | defined __cplusplus
(tIdPos pLogQuant, tZTree pZSchemaText, tZTree pSchemaExp)
# else
(pLogQuant, pZSchemaText, pSchemaExp)
tIdPos pLogQuant;
tZTree pZSchemaText;
tZTree pSchemaExp;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaQuant])
 yyt->Kind = kschemaQuant;
 yyt->yyHead.yyMark = 0;
 yyt->schemaQuant.LogQuant = pLogQuant;
 yyt->schemaQuant.ZSchemaText = pZSchemaText;
 yyt->schemaQuant.SchemaExp = pSchemaExp;
 return yyt;
}

tZTree mschemaComp
# if defined __STDC__ | defined __cplusplus
(tZTree pLop, tZTree pRop)
# else
(pLop, pRop)
tZTree pLop;
tZTree pRop;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaComp])
 yyt->Kind = kschemaComp;
 yyt->yyHead.yyMark = 0;
 yyt->schemaComp.Lop = pLop;
 yyt->schemaComp.Rop = pRop;
 return yyt;
}

tZTree mschemaProject
# if defined __STDC__ | defined __cplusplus
(tZTree pLop, tZTree pRop)
# else
(pLop, pRop)
tZTree pLop;
tZTree pRop;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaProject])
 yyt->Kind = kschemaProject;
 yyt->yyHead.yyMark = 0;
 yyt->schemaProject.Lop = pLop;
 yyt->schemaProject.Rop = pRop;
 return yyt;
}

tZTree mschemaPipe
# if defined __STDC__ | defined __cplusplus
(tZTree pLop, tZTree pRop)
# else
(pLop, pRop)
tZTree pLop;
tZTree pRop;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaPipe])
 yyt->Kind = kschemaPipe;
 yyt->yyHead.yyMark = 0;
 yyt->schemaPipe.Lop = pLop;
 yyt->schemaPipe.Rop = pRop;
 return yyt;
}

tZTree mschemaParen
# if defined __STDC__ | defined __cplusplus
(tZTree pSchemaExp)
# else
(pSchemaExp)
tZTree pSchemaExp;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaParen])
 yyt->Kind = kschemaParen;
 yyt->yyHead.yyMark = 0;
 yyt->schemaParen.SchemaExp = pSchemaExp;
 return yyt;
}

tZTree mDesignator
# if defined __STDC__ | defined __cplusplus
(tZTree pZName, tZTree pDecoration, tZTree pExpressionSeq, tZTree pRenameSeq, bool pIsSchemaRef)
# else
(pZName, pDecoration, pExpressionSeq, pRenameSeq, pIsSchemaRef)
tZTree pZName;
tZTree pDecoration;
tZTree pExpressionSeq;
tZTree pRenameSeq;
bool pIsSchemaRef;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kDesignator])
 yyt->Kind = kDesignator;
 yyt->yyHead.yyMark = 0;
 yyt->Designator.ZName = pZName;
 yyt->Designator.Decoration = pDecoration;
 yyt->Designator.ExpressionSeq = pExpressionSeq;
 yyt->Designator.RenameSeq = pRenameSeq;
 yyt->Designator.IsSchemaRef = pIsSchemaRef;
 return yyt;
}

tZTree mVarNameSeq
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kVarNameSeq])
 yyt->Kind = kVarNameSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoVarName
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoVarName])
 yyt->Kind = knoVarName;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mvarNames
# if defined __STDC__ | defined __cplusplus
(tZTree pVarName, tZTree pNext)
# else
(pVarName, pNext)
tZTree pVarName;
tZTree pNext;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kvarNames])
 yyt->Kind = kvarNames;
 yyt->yyHead.yyMark = 0;
 yyt->varNames.VarName = pVarName;
 yyt->varNames.Next = pNext;
 return yyt;
}

tZTree mExpressionSeq
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kExpressionSeq])
 yyt->Kind = kExpressionSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoExpSeq
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoExpSeq])
 yyt->Kind = knoExpSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mexpSeq
# if defined __STDC__ | defined __cplusplus
(tZTree pExpression, tZTree pNext)
# else
(pExpression, pNext)
tZTree pExpression;
tZTree pNext;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpSeq])
 yyt->Kind = kexpSeq;
 yyt->yyHead.yyMark = 0;
 yyt->expSeq.Expression = pExpression;
 yyt->expSeq.Next = pNext;
 return yyt;
}

tZTree mRenameSeq
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kRenameSeq])
 yyt->Kind = kRenameSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoRename
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoRename])
 yyt->Kind = knoRename;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mrenames
# if defined __STDC__ | defined __cplusplus
(tZTree pVarRename, tZTree pNext)
# else
(pVarRename, pNext)
tZTree pVarRename;
tZTree pNext;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [krenames])
 yyt->Kind = krenames;
 yyt->yyHead.yyMark = 0;
 yyt->renames.VarRename = pVarRename;
 yyt->renames.Next = pNext;
 return yyt;
}

tZTree mVarRename
# if defined __STDC__ | defined __cplusplus
(tZTree pNew, tZTree pOld)
# else
(pNew, pOld)
tZTree pNew;
tZTree pOld;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kVarRename])
 yyt->Kind = kVarRename;
 yyt->yyHead.yyMark = 0;
 yyt->VarRename.New = pNew;
 yyt->VarRename.Old = pOld;
 return yyt;
}

tZTree mZSchemaText
# if defined __STDC__ | defined __cplusplus
(tZTree pDeclaration, tZTree pPredicate)
# else
(pDeclaration, pPredicate)
tZTree pDeclaration;
tZTree pPredicate;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kZSchemaText])
 yyt->Kind = kZSchemaText;
 yyt->yyHead.yyMark = 0;
 yyt->ZSchemaText.Declaration = pDeclaration;
 yyt->ZSchemaText.Predicate = pPredicate;
 return yyt;
}

tZTree mDeclaration
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kDeclaration])
 yyt->Kind = kDeclaration;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoDecl
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoDecl])
 yyt->Kind = knoDecl;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mdecl
# if defined __STDC__ | defined __cplusplus
(tZTree pBasicDecl, tZTree pNext)
# else
(pBasicDecl, pNext)
tZTree pBasicDecl;
tZTree pNext;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kdecl])
 yyt->Kind = kdecl;
 yyt->yyHead.yyMark = 0;
 yyt->decl.BasicDecl = pBasicDecl;
 yyt->decl.Next = pNext;
 return yyt;
}

tZTree mBasicDecl
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kBasicDecl])
 yyt->Kind = kBasicDecl;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mcolonDecl
# if defined __STDC__ | defined __cplusplus
(tZTree pVarNameSeq, tZTree pExpression)
# else
(pVarNameSeq, pExpression)
tZTree pVarNameSeq;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kcolonDecl])
 yyt->Kind = kcolonDecl;
 yyt->yyHead.yyMark = 0;
 yyt->colonDecl.VarNameSeq = pVarNameSeq;
 yyt->colonDecl.Expression = pExpression;
 return yyt;
}

tZTree mschemaRef
# if defined __STDC__ | defined __cplusplus
(tZTree pDesignator)
# else
(pDesignator)
tZTree pDesignator;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kschemaRef])
 yyt->Kind = kschemaRef;
 yyt->yyHead.yyMark = 0;
 yyt->schemaRef.Designator = pDesignator;
 return yyt;
}

tZTree mPredicate
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kPredicate])
 yyt->Kind = kPredicate;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoPred
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoPred])
 yyt->Kind = knoPred;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mpredNegate
# if defined __STDC__ | defined __cplusplus
(tZTree pPredicate)
# else
(pPredicate)
tZTree pPredicate;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredNegate])
 yyt->Kind = kpredNegate;
 yyt->yyHead.yyMark = 0;
 yyt->predNegate.Predicate = pPredicate;
 return yyt;
}

tZTree mpredInfixRelSeq
# if defined __STDC__ | defined __cplusplus
(tZTree pPredInfixRelSeq)
# else
(pPredInfixRelSeq)
tZTree pPredInfixRelSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredInfixRelSeq])
 yyt->Kind = kpredInfixRelSeq;
 yyt->yyHead.yyMark = 0;
 yyt->predInfixRelSeq.PredInfixRelSeq = pPredInfixRelSeq;
 return yyt;
}

tZTree mpredTrueOrFalse
# if defined __STDC__ | defined __cplusplus
(tIdPos pTrueFalse)
# else
(pTrueFalse)
tIdPos pTrueFalse;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredTrueOrFalse])
 yyt->Kind = kpredTrueOrFalse;
 yyt->yyHead.yyMark = 0;
 yyt->predTrueOrFalse.TrueFalse = pTrueFalse;
 return yyt;
}

tZTree mpredSchemaRef
# if defined __STDC__ | defined __cplusplus
(tIdPos pPredOrPre, tZTree pDesignator)
# else
(pPredOrPre, pDesignator)
tIdPos pPredOrPre;
tZTree pDesignator;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredSchemaRef])
 yyt->Kind = kpredSchemaRef;
 yyt->yyHead.yyMark = 0;
 yyt->predSchemaRef.PredOrPre = pPredOrPre;
 yyt->predSchemaRef.Designator = pDesignator;
 return yyt;
}

tZTree mpredPreRel
# if defined __STDC__ | defined __cplusplus
(tIdPos pPreRel, tZTree pDecoration, tZTree pExpression)
# else
(pPreRel, pDecoration, pExpression)
tIdPos pPreRel;
tZTree pDecoration;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredPreRel])
 yyt->Kind = kpredPreRel;
 yyt->yyHead.yyMark = 0;
 yyt->predPreRel.PreRel = pPreRel;
 yyt->predPreRel.Decoration = pDecoration;
 yyt->predPreRel.Expression = pExpression;
 return yyt;
}

tZTree mpredCons
# if defined __STDC__ | defined __cplusplus
(tZTree pLpred, tIdPos pLogOp, tZTree pRpred)
# else
(pLpred, pLogOp, pRpred)
tZTree pLpred;
tIdPos pLogOp;
tZTree pRpred;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredCons])
 yyt->Kind = kpredCons;
 yyt->yyHead.yyMark = 0;
 yyt->predCons.Lpred = pLpred;
 yyt->predCons.LogOp = pLogOp;
 yyt->predCons.Rpred = pRpred;
 return yyt;
}

tZTree mpredQuant
# if defined __STDC__ | defined __cplusplus
(tIdPos pLogQuant, tZTree pZSchemaText, tZTree pPredicate)
# else
(pLogQuant, pZSchemaText, pPredicate)
tIdPos pLogQuant;
tZTree pZSchemaText;
tZTree pPredicate;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredQuant])
 yyt->Kind = kpredQuant;
 yyt->yyHead.yyMark = 0;
 yyt->predQuant.LogQuant = pLogQuant;
 yyt->predQuant.ZSchemaText = pZSchemaText;
 yyt->predQuant.Predicate = pPredicate;
 return yyt;
}

tZTree mpredLet
# if defined __STDC__ | defined __cplusplus
(tZTree pLetDefSeq, tZTree pPredicate)
# else
(pLetDefSeq, pPredicate)
tZTree pLetDefSeq;
tZTree pPredicate;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredLet])
 yyt->Kind = kpredLet;
 yyt->yyHead.yyMark = 0;
 yyt->predLet.LetDefSeq = pLetDefSeq;
 yyt->predLet.Predicate = pPredicate;
 return yyt;
}

tZTree mpredParen
# if defined __STDC__ | defined __cplusplus
(tZTree pPredicate)
# else
(pPredicate)
tZTree pPredicate;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kpredParen])
 yyt->Kind = kpredParen;
 yyt->yyHead.yyMark = 0;
 yyt->predParen.Predicate = pPredicate;
 return yyt;
}

tZTree mPredInfixRelSeq
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kPredInfixRelSeq])
 yyt->Kind = kPredInfixRelSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoInfixRel
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoInfixRel])
 yyt->Kind = knoInfixRel;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree minfixRels
# if defined __STDC__ | defined __cplusplus
(tZTree pPredInfixRel, tZTree pNext)
# else
(pPredInfixRel, pNext)
tZTree pPredInfixRel;
tZTree pNext;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kinfixRels])
 yyt->Kind = kinfixRels;
 yyt->yyHead.yyMark = 0;
 yyt->infixRels.PredInfixRel = pPredInfixRel;
 yyt->infixRels.Next = pNext;
 return yyt;
}

tZTree mPredInfixRel
# if defined __STDC__ | defined __cplusplus
(tZTree pLexp, tZTree pInfixRel, tZTree pRexp)
# else
(pLexp, pInfixRel, pRexp)
tZTree pLexp;
tZTree pInfixRel;
tZTree pRexp;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kPredInfixRel])
 yyt->Kind = kPredInfixRel;
 yyt->yyHead.yyMark = 0;
 yyt->PredInfixRel.Lexp = pLexp;
 yyt->PredInfixRel.InfixRel = pInfixRel;
 yyt->PredInfixRel.Rexp = pRexp;
 return yyt;
}

tZTree mInfixRel
# if defined __STDC__ | defined __cplusplus
(tIdPos pInRel, tZTree pDecoration)
# else
(pInRel, pDecoration)
tIdPos pInRel;
tZTree pDecoration;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kInfixRel])
 yyt->Kind = kInfixRel;
 yyt->yyHead.yyMark = 0;
 yyt->InfixRel.InRel = pInRel;
 yyt->InfixRel.Decoration = pDecoration;
 return yyt;
}

tZTree mExpression
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kExpression])
 yyt->Kind = kExpression;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoExp
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoExp])
 yyt->Kind = knoExp;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mexpBinaryGen
# if defined __STDC__ | defined __cplusplus
(tZTree plexp, tIdPos pInGen, tZTree pDecoration, tZTree prexp)
# else
(plexp, pInGen, pDecoration, prexp)
tZTree plexp;
tIdPos pInGen;
tZTree pDecoration;
tZTree prexp;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpBinaryGen])
 yyt->Kind = kexpBinaryGen;
 yyt->yyHead.yyMark = 0;
 yyt->expBinaryGen.lexp = plexp;
 yyt->expBinaryGen.InGen = pInGen;
 yyt->expBinaryGen.Decoration = pDecoration;
 yyt->expBinaryGen.rexp = prexp;
 return yyt;
}

tZTree mexpBinaryFun
# if defined __STDC__ | defined __cplusplus
(tZTree plexp, tIdPos pInFun, tZTree pDecoration, tZTree prexp)
# else
(plexp, pInFun, pDecoration, prexp)
tZTree plexp;
tIdPos pInFun;
tZTree pDecoration;
tZTree prexp;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpBinaryFun])
 yyt->Kind = kexpBinaryFun;
 yyt->yyHead.yyMark = 0;
 yyt->expBinaryFun.lexp = plexp;
 yyt->expBinaryFun.InFun = pInFun;
 yyt->expBinaryFun.Decoration = pDecoration;
 yyt->expBinaryFun.rexp = prexp;
 return yyt;
}

tZTree mexpLiteral
# if defined __STDC__ | defined __cplusplus
(tIdPos pLiteral)
# else
(pLiteral)
tIdPos pLiteral;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpLiteral])
 yyt->Kind = kexpLiteral;
 yyt->yyHead.yyMark = 0;
 yyt->expLiteral.Literal = pLiteral;
 return yyt;
}

tZTree mexpOpname
# if defined __STDC__ | defined __cplusplus
(tZTree pVarName, tZTree pExpressionSeq)
# else
(pVarName, pExpressionSeq)
tZTree pVarName;
tZTree pExpressionSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpOpname])
 yyt->Kind = kexpOpname;
 yyt->yyHead.yyMark = 0;
 yyt->expOpname.VarName = pVarName;
 yyt->expOpname.ExpressionSeq = pExpressionSeq;
 return yyt;
}

tZTree mexpSetElab
# if defined __STDC__ | defined __cplusplus
(tZTree pExpressionSeq)
# else
(pExpressionSeq)
tZTree pExpressionSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpSetElab])
 yyt->Kind = kexpSetElab;
 yyt->yyHead.yyMark = 0;
 yyt->expSetElab.ExpressionSeq = pExpressionSeq;
 return yyt;
}

tZTree mexpSeqElab
# if defined __STDC__ | defined __cplusplus
(tZTree pExpressionSeq)
# else
(pExpressionSeq)
tZTree pExpressionSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpSeqElab])
 yyt->Kind = kexpSeqElab;
 yyt->yyHead.yyMark = 0;
 yyt->expSeqElab.ExpressionSeq = pExpressionSeq;
 return yyt;
}

tZTree mexpBagElab
# if defined __STDC__ | defined __cplusplus
(tZTree pExpressionSeq)
# else
(pExpressionSeq)
tZTree pExpressionSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpBagElab])
 yyt->Kind = kexpBagElab;
 yyt->yyHead.yyMark = 0;
 yyt->expBagElab.ExpressionSeq = pExpressionSeq;
 return yyt;
}

tZTree mexpSetComp
# if defined __STDC__ | defined __cplusplus
(tZTree pZSchemaText, tZTree pExpression)
# else
(pZSchemaText, pExpression)
tZTree pZSchemaText;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpSetComp])
 yyt->Kind = kexpSetComp;
 yyt->yyHead.yyMark = 0;
 yyt->expSetComp.ZSchemaText = pZSchemaText;
 yyt->expSetComp.Expression = pExpression;
 return yyt;
}

tZTree mexpPowerSet
# if defined __STDC__ | defined __cplusplus
(tZTree pExpression)
# else
(pExpression)
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpPowerSet])
 yyt->Kind = kexpPowerSet;
 yyt->yyHead.yyMark = 0;
 yyt->expPowerSet.Expression = pExpression;
 return yyt;
}

tZTree mexpPreGen
# if defined __STDC__ | defined __cplusplus
(tIdPos pPregen, tZTree pDecoration, tZTree pExpression)
# else
(pPregen, pDecoration, pExpression)
tIdPos pPregen;
tZTree pDecoration;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpPreGen])
 yyt->Kind = kexpPreGen;
 yyt->yyHead.yyMark = 0;
 yyt->expPreGen.Pregen = pPregen;
 yyt->expPreGen.Decoration = pDecoration;
 yyt->expPreGen.Expression = pExpression;
 return yyt;
}

tZTree mexpPostFun
# if defined __STDC__ | defined __cplusplus
(tZTree pExpression, tIdPos pPostfun, tZTree pDecoration)
# else
(pExpression, pPostfun, pDecoration)
tZTree pExpression;
tIdPos pPostfun;
tZTree pDecoration;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpPostFun])
 yyt->Kind = kexpPostFun;
 yyt->yyHead.yyMark = 0;
 yyt->expPostFun.Expression = pExpression;
 yyt->expPostFun.Postfun = pPostfun;
 yyt->expPostFun.Decoration = pDecoration;
 return yyt;
}

tZTree mexpIter
# if defined __STDC__ | defined __cplusplus
(tZTree pexp1, tZTree pexp2)
# else
(pexp1, pexp2)
tZTree pexp1;
tZTree pexp2;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpIter])
 yyt->Kind = kexpIter;
 yyt->yyHead.yyMark = 0;
 yyt->expIter.exp1 = pexp1;
 yyt->expIter.exp2 = pexp2;
 return yyt;
}

tZTree mexpTuple
# if defined __STDC__ | defined __cplusplus
(tZTree pExpressionSeq)
# else
(pExpressionSeq)
tZTree pExpressionSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpTuple])
 yyt->Kind = kexpTuple;
 yyt->yyHead.yyMark = 0;
 yyt->expTuple.ExpressionSeq = pExpressionSeq;
 return yyt;
}

tZTree mexpCartProd
# if defined __STDC__ | defined __cplusplus
(tZTree pExpressionSeq)
# else
(pExpressionSeq)
tZTree pExpressionSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpCartProd])
 yyt->Kind = kexpCartProd;
 yyt->yyHead.yyMark = 0;
 yyt->expCartProd.ExpressionSeq = pExpressionSeq;
 return yyt;
}

tZTree mexpTheta
# if defined __STDC__ | defined __cplusplus
(tZTree pZName, tZTree pDecoration, tZTree pRenameSeq)
# else
(pZName, pDecoration, pRenameSeq)
tZTree pZName;
tZTree pDecoration;
tZTree pRenameSeq;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpTheta])
 yyt->Kind = kexpTheta;
 yyt->yyHead.yyMark = 0;
 yyt->expTheta.ZName = pZName;
 yyt->expTheta.Decoration = pDecoration;
 yyt->expTheta.RenameSeq = pRenameSeq;
 return yyt;
}

tZTree mexpSelectVar
# if defined __STDC__ | defined __cplusplus
(tZTree pExpression, tZTree pVarName)
# else
(pExpression, pVarName)
tZTree pExpression;
tZTree pVarName;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpSelectVar])
 yyt->Kind = kexpSelectVar;
 yyt->yyHead.yyMark = 0;
 yyt->expSelectVar.Expression = pExpression;
 yyt->expSelectVar.VarName = pVarName;
 return yyt;
}

tZTree mexpFnApp
# if defined __STDC__ | defined __cplusplus
(tZTree pFnName, tZTree pParams)
# else
(pFnName, pParams)
tZTree pFnName;
tZTree pParams;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpFnApp])
 yyt->Kind = kexpFnApp;
 yyt->yyHead.yyMark = 0;
 yyt->expFnApp.FnName = pFnName;
 yyt->expFnApp.Params = pParams;
 return yyt;
}

tZTree mexpMu
# if defined __STDC__ | defined __cplusplus
(tZTree pZSchemaText, tZTree pExpression)
# else
(pZSchemaText, pExpression)
tZTree pZSchemaText;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpMu])
 yyt->Kind = kexpMu;
 yyt->yyHead.yyMark = 0;
 yyt->expMu.ZSchemaText = pZSchemaText;
 yyt->expMu.Expression = pExpression;
 return yyt;
}

tZTree mexpLambda
# if defined __STDC__ | defined __cplusplus
(tZTree pZSchemaText, tZTree pExpression)
# else
(pZSchemaText, pExpression)
tZTree pZSchemaText;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpLambda])
 yyt->Kind = kexpLambda;
 yyt->yyHead.yyMark = 0;
 yyt->expLambda.ZSchemaText = pZSchemaText;
 yyt->expLambda.Expression = pExpression;
 return yyt;
}

tZTree mexpLet
# if defined __STDC__ | defined __cplusplus
(tZTree pLetDefSeq, tZTree pExpression)
# else
(pLetDefSeq, pExpression)
tZTree pLetDefSeq;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpLet])
 yyt->Kind = kexpLet;
 yyt->yyHead.yyMark = 0;
 yyt->expLet.LetDefSeq = pLetDefSeq;
 yyt->expLet.Expression = pExpression;
 return yyt;
}

tZTree mexpIf
# if defined __STDC__ | defined __cplusplus
(tZTree pPredicate, tZTree pExp1, tZTree pExp2)
# else
(pPredicate, pExp1, pExp2)
tZTree pPredicate;
tZTree pExp1;
tZTree pExp2;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpIf])
 yyt->Kind = kexpIf;
 yyt->yyHead.yyMark = 0;
 yyt->expIf.Predicate = pPredicate;
 yyt->expIf.Exp1 = pExp1;
 yyt->expIf.Exp2 = pExp2;
 return yyt;
}

tZTree mexpImage
# if defined __STDC__ | defined __cplusplus
(tZTree pExp1, tZTree pExp2, tIdPos pImage, tZTree pDecoration)
# else
(pExp1, pExp2, pImage, pDecoration)
tZTree pExp1;
tZTree pExp2;
tIdPos pImage;
tZTree pDecoration;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpImage])
 yyt->Kind = kexpImage;
 yyt->yyHead.yyMark = 0;
 yyt->expImage.Exp1 = pExp1;
 yyt->expImage.Exp2 = pExp2;
 yyt->expImage.Image = pImage;
 yyt->expImage.Decoration = pDecoration;
 return yyt;
}

tZTree mexpDesignator
# if defined __STDC__ | defined __cplusplus
(tZTree pDesignator)
# else
(pDesignator)
tZTree pDesignator;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpDesignator])
 yyt->Kind = kexpDesignator;
 yyt->yyHead.yyMark = 0;
 yyt->expDesignator.Designator = pDesignator;
 return yyt;
}

tZTree mexpParen
# if defined __STDC__ | defined __cplusplus
(tZTree pExpression)
# else
(pExpression)
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kexpParen])
 yyt->Kind = kexpParen;
 yyt->yyHead.yyMark = 0;
 yyt->expParen.Expression = pExpression;
 return yyt;
}

tZTree mLetDefSeq
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kLetDefSeq])
 yyt->Kind = kLetDefSeq;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoLetDef
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoLetDef])
 yyt->Kind = knoLetDef;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mletDefs
# if defined __STDC__ | defined __cplusplus
(tZTree pLetDef, tZTree pNext)
# else
(pLetDef, pNext)
tZTree pLetDef;
tZTree pNext;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kletDefs])
 yyt->Kind = kletDefs;
 yyt->yyHead.yyMark = 0;
 yyt->letDefs.LetDef = pLetDef;
 yyt->letDefs.Next = pNext;
 return yyt;
}

tZTree mLetDef
# if defined __STDC__ | defined __cplusplus
(tZTree pVarName, tZTree pExpression)
# else
(pVarName, pExpression)
tZTree pVarName;
tZTree pExpression;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kLetDef])
 yyt->Kind = kLetDef;
 yyt->yyHead.yyMark = 0;
 yyt->LetDef.VarName = pVarName;
 yyt->LetDef.Expression = pExpression;
 return yyt;
}

tZTree mVarName
# if defined __STDC__ | defined __cplusplus
(tIdPos pIdent, tZTree pDecoration)
# else
(pIdent, pDecoration)
tIdPos pIdent;
tZTree pDecoration;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kVarName])
 yyt->Kind = kVarName;
 yyt->yyHead.yyMark = 0;
 yyt->VarName.Ident = pIdent;
 yyt->VarName.Decoration = pDecoration;
 return yyt;
}

tZTree mZId
# if defined __STDC__ | defined __cplusplus
(tIdPos pIdent, tZTree pDecoration)
# else
(pIdent, pDecoration)
tIdPos pIdent;
tZTree pDecoration;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kZId])
 yyt->Kind = kZId;
 yyt->yyHead.yyMark = 0;
 yyt->ZId.Ident = pIdent;
 yyt->ZId.Decoration = pDecoration;
 return yyt;
}

tZTree mOpname
# if defined __STDC__ | defined __cplusplus
(tIdPos pIdent, tZTree pDecoration)
# else
(pIdent, pDecoration)
tIdPos pIdent;
tZTree pDecoration;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kOpname])
 yyt->Kind = kOpname;
 yyt->yyHead.yyMark = 0;
 yyt->Opname.Ident = pIdent;
 yyt->Opname.Decoration = pDecoration;
 return yyt;
}

tZTree mDecoration
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kDecoration])
 yyt->Kind = kDecoration;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mnoDecoration
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [knoDecoration])
 yyt->Kind = knoDecoration;
 yyt->yyHead.yyMark = 0;
 return yyt;
}

tZTree mdecoration
# if defined __STDC__ | defined __cplusplus
(tIdPos pStroke, tZTree pNext)
# else
(pStroke, pNext)
tIdPos pStroke;
tZTree pNext;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kdecoration])
 yyt->Kind = kdecoration;
 yyt->yyHead.yyMark = 0;
 yyt->decoration.Stroke = pStroke;
 yyt->decoration.Next = pNext;
 return yyt;
}

tZTree mZName
# if defined __STDC__ | defined __cplusplus
(tIdPos pIdent)
# else
(pIdent)
tIdPos pIdent;
# endif
{
 register tZTree yyt;
 yyALLOC (yyt, ZTree_NodeSize [kZName])
 yyt->Kind = kZName;
 yyt->yyHead.yyMark = 0;
 yyt->ZName.Ident = pIdent;
 return yyt;
}

typedef tZTree * yyPtrtTree;

static FILE * yyf;

static void yyMark
# if defined __STDC__ | defined __cplusplus
 (register tZTree yyt)
# else
 (yyt) register tZTree yyt;
# endif
{
 for (;;) {
  if (yyt == NoZTree || ++ yyt->yyHead.yyMark > 1) return;

  switch (yyt->Kind) {
case kSpecification:
yyt = yyt->Specification.GlobalParagraphSeq; break;
case kglobalParagraphs:
yyMark (yyt->globalParagraphs.GlobalParagraph);
yyt = yyt->globalParagraphs.Next; break;
case kaxiomaticDef:
yyt = yyt->axiomaticDef.ZSchemaText; break;
case khorizPar:
yyt = yyt->horizPar.HorizParagraphs; break;
case kgenericDef:
yyMark (yyt->genericDef.ZFormalParams);
yyt = yyt->genericDef.ZSchemaText; break;
case kschemaboxDef:
yyMark (yyt->schemaboxDef.ZName);
yyMark (yyt->schemaboxDef.ZFormalParams);
yyt = yyt->schemaboxDef.ZSchemaText; break;
case khorizParagraphs:
yyMark (yyt->horizParagraphs.HorizParagraph);
yyt = yyt->horizParagraphs.Next; break;
case ktypeDef:
yyt = yyt->typeDef.TypeDef; break;
case kglobalPredicate:
yyt = yyt->globalPredicate.Predicate; break;
case kschemaDef:
yyMark (yyt->schemaDef.NameFormals);
yyt = yyt->schemaDef.SchemaExp; break;
case kgivenSet:
yyt = yyt->givenSet.VarNameSeq; break;
case kfreeType:
yyMark (yyt->freeType.VarName);
yyt = yyt->freeType.BranchSeq; break;
case ktypeDef1:
yyMark (yyt->typeDef1.NameFormals);
yyt = yyt->typeDef1.Expression; break;
case ktypeDefPregen:
yyMark (yyt->typeDefPregen.Decoration);
yyMark (yyt->typeDefPregen.VarName);
yyt = yyt->typeDefPregen.Expression; break;
case ktypeDefIngen:
yyMark (yyt->typeDefIngen.Var1);
yyMark (yyt->typeDefIngen.Decoration);
yyMark (yyt->typeDefIngen.Var2);
yyt = yyt->typeDefIngen.Expression; break;
case kNameFormals:
yyt = yyt->NameFormals.VarName; break;
case knoFormals:
yyt = yyt->noFormals.VarName; break;
case knameFormals:
yyMark (yyt->nameFormals.VarName);
yyt = yyt->nameFormals.ZFormalParams; break;
case kbranch:
yyMark (yyt->branch.ZBranch);
yyt = yyt->branch.Next; break;
case kformalParams:
yyt = yyt->formalParams.VarNameSeq; break;
case ksimpleBranch:
yyt = yyt->simpleBranch.VarName; break;
case kcompoundBranch:
yyMark (yyt->compoundBranch.VarName);
yyt = yyt->compoundBranch.Expression; break;
case kschemaSimple:
yyt = yyt->schemaSimple.ZSchemaText; break;
case kschemaDes:
yyt = yyt->schemaDes.Designator; break;
case kschemaPreop:
yyt = yyt->schemaPreop.SchemaExp; break;
case kschemaCons:
yyMark (yyt->schemaCons.Lop);
yyt = yyt->schemaCons.Rop; break;
case kschemaHide:
yyMark (yyt->schemaHide.SchemaExp);
yyt = yyt->schemaHide.VarNameSeq; break;
case kschemaQuant:
yyMark (yyt->schemaQuant.ZSchemaText);
yyt = yyt->schemaQuant.SchemaExp; break;
case kschemaComp:
yyMark (yyt->schemaComp.Lop);
yyt = yyt->schemaComp.Rop; break;
case kschemaProject:
yyMark (yyt->schemaProject.Lop);
yyt = yyt->schemaProject.Rop; break;
case kschemaPipe:
yyMark (yyt->schemaPipe.Lop);
yyt = yyt->schemaPipe.Rop; break;
case kschemaParen:
yyt = yyt->schemaParen.SchemaExp; break;
case kDesignator:
yyMark (yyt->Designator.ZName);
yyMark (yyt->Designator.Decoration);
yyMark (yyt->Designator.ExpressionSeq);
yyt = yyt->Designator.RenameSeq; break;
case kvarNames:
yyMark (yyt->varNames.VarName);
yyt = yyt->varNames.Next; break;
case kexpSeq:
yyMark (yyt->expSeq.Expression);
yyt = yyt->expSeq.Next; break;
case krenames:
yyMark (yyt->renames.VarRename);
yyt = yyt->renames.Next; break;
case kVarRename:
yyMark (yyt->VarRename.New);
yyt = yyt->VarRename.Old; break;
case kZSchemaText:
yyMark (yyt->ZSchemaText.Declaration);
yyt = yyt->ZSchemaText.Predicate; break;
case kdecl:
yyMark (yyt->decl.BasicDecl);
yyt = yyt->decl.Next; break;
case kcolonDecl:
yyMark (yyt->colonDecl.VarNameSeq);
yyt = yyt->colonDecl.Expression; break;
case kschemaRef:
yyt = yyt->schemaRef.Designator; break;
case kpredNegate:
yyt = yyt->predNegate.Predicate; break;
case kpredInfixRelSeq:
yyt = yyt->predInfixRelSeq.PredInfixRelSeq; break;
case kpredSchemaRef:
yyt = yyt->predSchemaRef.Designator; break;
case kpredPreRel:
yyMark (yyt->predPreRel.Decoration);
yyt = yyt->predPreRel.Expression; break;
case kpredCons:
yyMark (yyt->predCons.Lpred);
yyt = yyt->predCons.Rpred; break;
case kpredQuant:
yyMark (yyt->predQuant.ZSchemaText);
yyt = yyt->predQuant.Predicate; break;
case kpredLet:
yyMark (yyt->predLet.LetDefSeq);
yyt = yyt->predLet.Predicate; break;
case kpredParen:
yyt = yyt->predParen.Predicate; break;
case kinfixRels:
yyMark (yyt->infixRels.PredInfixRel);
yyt = yyt->infixRels.Next; break;
case kPredInfixRel:
yyMark (yyt->PredInfixRel.Lexp);
yyMark (yyt->PredInfixRel.InfixRel);
yyt = yyt->PredInfixRel.Rexp; break;
case kInfixRel:
yyt = yyt->InfixRel.Decoration; break;
case kexpBinaryGen:
yyMark (yyt->expBinaryGen.lexp);
yyMark (yyt->expBinaryGen.Decoration);
yyt = yyt->expBinaryGen.rexp; break;
case kexpBinaryFun:
yyMark (yyt->expBinaryFun.lexp);
yyMark (yyt->expBinaryFun.Decoration);
yyt = yyt->expBinaryFun.rexp; break;
case kexpOpname:
yyMark (yyt->expOpname.VarName);
yyt = yyt->expOpname.ExpressionSeq; break;
case kexpSetElab:
yyt = yyt->expSetElab.ExpressionSeq; break;
case kexpSeqElab:
yyt = yyt->expSeqElab.ExpressionSeq; break;
case kexpBagElab:
yyt = yyt->expBagElab.ExpressionSeq; break;
case kexpSetComp:
yyMark (yyt->expSetComp.ZSchemaText);
yyt = yyt->expSetComp.Expression; break;
case kexpPowerSet:
yyt = yyt->expPowerSet.Expression; break;
case kexpPreGen:
yyMark (yyt->expPreGen.Decoration);
yyt = yyt->expPreGen.Expression; break;
case kexpPostFun:
yyMark (yyt->expPostFun.Expression);
yyt = yyt->expPostFun.Decoration; break;
case kexpIter:
yyMark (yyt->expIter.exp1);
yyt = yyt->expIter.exp2; break;
case kexpTuple:
yyt = yyt->expTuple.ExpressionSeq; break;
case kexpCartProd:
yyt = yyt->expCartProd.ExpressionSeq; break;
case kexpTheta:
yyMark (yyt->expTheta.ZName);
yyMark (yyt->expTheta.Decoration);
yyt = yyt->expTheta.RenameSeq; break;
case kexpSelectVar:
yyMark (yyt->expSelectVar.Expression);
yyt = yyt->expSelectVar.VarName; break;
case kexpFnApp:
yyMark (yyt->expFnApp.FnName);
yyt = yyt->expFnApp.Params; break;
case kexpMu:
yyMark (yyt->expMu.ZSchemaText);
yyt = yyt->expMu.Expression; break;
case kexpLambda:
yyMark (yyt->expLambda.ZSchemaText);
yyt = yyt->expLambda.Expression; break;
case kexpLet:
yyMark (yyt->expLet.LetDefSeq);
yyt = yyt->expLet.Expression; break;
case kexpIf:
yyMark (yyt->expIf.Predicate);
yyMark (yyt->expIf.Exp1);
yyt = yyt->expIf.Exp2; break;
case kexpImage:
yyMark (yyt->expImage.Exp1);
yyMark (yyt->expImage.Exp2);
yyt = yyt->expImage.Decoration; break;
case kexpDesignator:
yyt = yyt->expDesignator.Designator; break;
case kexpParen:
yyt = yyt->expParen.Expression; break;
case kletDefs:
yyMark (yyt->letDefs.LetDef);
yyt = yyt->letDefs.Next; break;
case kLetDef:
yyMark (yyt->LetDef.VarName);
yyt = yyt->LetDef.Expression; break;
case kVarName:
yyt = yyt->VarName.Decoration; break;
case kZId:
yyt = yyt->ZId.Decoration; break;
case kOpname:
yyt = yyt->Opname.Decoration; break;
case kdecoration:
yyt = yyt->decoration.Next; break;
  default: return;
  }
 }
}

# define yyInitTreeStoreSize 32
# define yyMapToTree(yyLabel) yyTreeStorePtr [yyLabel]

static unsigned long yyTreeStoreSize = yyInitTreeStoreSize;
static tZTree yyTreeStore [yyInitTreeStoreSize];
static tZTree * yyTreeStorePtr = yyTreeStore;
static int yyLabelCount;
static short yyRecursionLevel = 0;

static ZTree_tLabel yyMapToLabel
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyLabelCount; yyi ++) if (yyTreeStorePtr [yyi] == yyt) return yyi;
 if (++ yyLabelCount == yyTreeStoreSize)
  ExtendArray ((char * *) & yyTreeStorePtr, & yyTreeStoreSize, sizeof (tZTree));
 yyTreeStorePtr [yyLabelCount] = yyt;
 return yyLabelCount;
}

static void yyWriteZTree ();

static void yyWriteNl () { (void) putc ('\n', yyf); }

static void yyWriteSelector
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyi = 16 - strlen (yys);
 (void) fputs (yys, yyf);
 while (yyi -- > 0) (void) putc (' ', yyf);
 (void) fputs (" = ", yyf);
}

static void yyWriteHex
# if defined __STDC__ | defined __cplusplus
 (unsigned char * yyx, int yysize)
# else
 (yyx, yysize) unsigned char * yyx; int yysize;
# endif
{ register int yyi; for (yyi = 0; yyi < yysize; yyi ++) (void) fprintf (yyf, "%02x ", yyx [yyi]); }

static void yyWriteAdr
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 if (yyt == NoZTree) (void) fputs ("NoZTree", yyf);
 else yyWriteHex ((unsigned char *) & yyt, sizeof (yyt));
 yyWriteNl ();
}

static void yWriteNodeSpecification
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyWriteSelector ("GlobalParagraphSeq"); yyWriteAdr (yyt->Specification.GlobalParagraphSeq);
}

static void yWriteNodeGlobalParagraphSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoGlobalParagraph
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeGlobalParagraphSeq (yyt); 
}

static void yWriteNodeglobalParagraphs
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeGlobalParagraphSeq (yyt); 
 yyWriteSelector ("GlobalParagraph"); yyWriteAdr (yyt->globalParagraphs.GlobalParagraph);
 yyWriteSelector ("Next"); yyWriteAdr (yyt->globalParagraphs.Next);
}

static void yWriteNodeGlobalParagraph
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodeaxiomaticDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeGlobalParagraph (yyt); 
 yyWriteSelector ("ZSchemaText"); yyWriteAdr (yyt->axiomaticDef.ZSchemaText);
}

static void yWriteNodehorizPar
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeGlobalParagraph (yyt); 
 yyWriteSelector ("HorizParagraphs"); yyWriteAdr (yyt->horizPar.HorizParagraphs);
}

static void yWriteNodegenericDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeGlobalParagraph (yyt); 
 yyWriteSelector ("ZFormalParams"); yyWriteAdr (yyt->genericDef.ZFormalParams);
 yyWriteSelector ("ZSchemaText"); yyWriteAdr (yyt->genericDef.ZSchemaText);
}

static void yWriteNodeschemaboxDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeGlobalParagraph (yyt); 
 yyWriteSelector ("ZName"); yyWriteAdr (yyt->schemaboxDef.ZName);
 yyWriteSelector ("ZFormalParams"); yyWriteAdr (yyt->schemaboxDef.ZFormalParams);
 yyWriteSelector ("ZSchemaText"); yyWriteAdr (yyt->schemaboxDef.ZSchemaText);
}

static void yWriteNodeHorizParagraphs
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoHorizParagraph
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeHorizParagraphs (yyt); 
}

static void yWriteNodehorizParagraphs
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeHorizParagraphs (yyt); 
 yyWriteSelector ("HorizParagraph"); yyWriteAdr (yyt->horizParagraphs.HorizParagraph);
 yyWriteSelector ("Next"); yyWriteAdr (yyt->horizParagraphs.Next);
}

static void yWriteNodeHorizParagraph
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodetypeDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeHorizParagraph (yyt); 
 yyWriteSelector ("TypeDef"); yyWriteAdr (yyt->typeDef.TypeDef);
}

static void yWriteNodeglobalPredicate
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeHorizParagraph (yyt); 
 yyWriteSelector ("Predicate"); yyWriteAdr (yyt->globalPredicate.Predicate);
}

static void yWriteNodeschemaDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeHorizParagraph (yyt); 
 yyWriteSelector ("NameFormals"); yyWriteAdr (yyt->schemaDef.NameFormals);
 yyWriteSelector ("SchemaExp"); yyWriteAdr (yyt->schemaDef.SchemaExp);
}

static void yWriteNodeTypeDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodegivenSet
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeTypeDef (yyt); 
 yyWriteSelector ("VarNameSeq"); yyWriteAdr (yyt->givenSet.VarNameSeq);
}

static void yWriteNodefreeType
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeTypeDef (yyt); 
 yyWriteSelector ("VarName"); yyWriteAdr (yyt->freeType.VarName);
 yyWriteSelector ("BranchSeq"); yyWriteAdr (yyt->freeType.BranchSeq);
}

static void yWriteNodetypeDef1
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeTypeDef (yyt); 
 yyWriteSelector ("NameFormals"); yyWriteAdr (yyt->typeDef1.NameFormals);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->typeDef1.Expression);
}

static void yWriteNodetypeDefPregen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeTypeDef (yyt); 
 yyWriteSelector ("PreGen"); writetIdPos (yyt->typeDefPregen.PreGen) yyWriteNl ();
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->typeDefPregen.Decoration);
 yyWriteSelector ("VarName"); yyWriteAdr (yyt->typeDefPregen.VarName);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->typeDefPregen.Expression);
}

static void yWriteNodetypeDefIngen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeTypeDef (yyt); 
 yyWriteSelector ("Var1"); yyWriteAdr (yyt->typeDefIngen.Var1);
 yyWriteSelector ("InGen"); writetIdPos (yyt->typeDefIngen.InGen) yyWriteNl ();
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->typeDefIngen.Decoration);
 yyWriteSelector ("Var2"); yyWriteAdr (yyt->typeDefIngen.Var2);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->typeDefIngen.Expression);
}

static void yWriteNodeNameFormals
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyWriteSelector ("VarName"); yyWriteAdr (yyt->NameFormals.VarName);
}

static void yWriteNodenoFormals
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeNameFormals (yyt); 
}

static void yWriteNodenameFormals
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeNameFormals (yyt); 
 yyWriteSelector ("ZFormalParams"); yyWriteAdr (yyt->nameFormals.ZFormalParams);
}

static void yWriteNodeBranchSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoBranch
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeBranchSeq (yyt); 
}

static void yWriteNodebranch
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeBranchSeq (yyt); 
 yyWriteSelector ("ZBranch"); yyWriteAdr (yyt->branch.ZBranch);
 yyWriteSelector ("Next"); yyWriteAdr (yyt->branch.Next);
}

static void yWriteNodeZFormalParams
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoFormalParams
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeZFormalParams (yyt); 
}

static void yWriteNodeformalParams
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeZFormalParams (yyt); 
 yyWriteSelector ("VarNameSeq"); yyWriteAdr (yyt->formalParams.VarNameSeq);
}

static void yWriteNodeZBranch
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodesimpleBranch
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeZBranch (yyt); 
 yyWriteSelector ("VarName"); yyWriteAdr (yyt->simpleBranch.VarName);
}

static void yWriteNodecompoundBranch
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeZBranch (yyt); 
 yyWriteSelector ("VarName"); yyWriteAdr (yyt->compoundBranch.VarName);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->compoundBranch.Expression);
}

static void yWriteNodeSchemaExp
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodeschemaSimple
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeSchemaExp (yyt); 
 yyWriteSelector ("ZSchemaText"); yyWriteAdr (yyt->schemaSimple.ZSchemaText);
}

static void yWriteNodeschemaDes
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeSchemaExp (yyt); 
 yyWriteSelector ("Designator"); yyWriteAdr (yyt->schemaDes.Designator);
}

static void yWriteNodeschemaPreop
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeSchemaExp (yyt); 
 yyWriteSelector ("PreOp"); writetIdPos (yyt->schemaPreop.PreOp) yyWriteNl ();
 yyWriteSelector ("SchemaExp"); yyWriteAdr (yyt->schemaPreop.SchemaExp);
}

static void yWriteNodeschemaCons
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeSchemaExp (yyt); 
 yyWriteSelector ("Lop"); yyWriteAdr (yyt->schemaCons.Lop);
 yyWriteSelector ("SchemaOp"); writetIdPos (yyt->schemaCons.SchemaOp) yyWriteNl ();
 yyWriteSelector ("Rop"); yyWriteAdr (yyt->schemaCons.Rop);
}

static void yWriteNodeschemaHide
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeSchemaExp (yyt); 
 yyWriteSelector ("SchemaExp"); yyWriteAdr (yyt->schemaHide.SchemaExp);
 yyWriteSelector ("VarNameSeq"); yyWriteAdr (yyt->schemaHide.VarNameSeq);
}

static void yWriteNodeschemaQuant
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeSchemaExp (yyt); 
 yyWriteSelector ("LogQuant"); writetIdPos (yyt->schemaQuant.LogQuant) yyWriteNl ();
 yyWriteSelector ("ZSchemaText"); yyWriteAdr (yyt->schemaQuant.ZSchemaText);
 yyWriteSelector ("SchemaExp"); yyWriteAdr (yyt->schemaQuant.SchemaExp);
}

static void yWriteNodeschemaComp
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeSchemaExp (yyt); 
 yyWriteSelector ("Lop"); yyWriteAdr (yyt->schemaComp.Lop);
 yyWriteSelector ("Rop"); yyWriteAdr (yyt->schemaComp.Rop);
}

static void yWriteNodeschemaProject
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeSchemaExp (yyt); 
 yyWriteSelector ("Lop"); yyWriteAdr (yyt->schemaProject.Lop);
 yyWriteSelector ("Rop"); yyWriteAdr (yyt->schemaProject.Rop);
}

static void yWriteNodeschemaPipe
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeSchemaExp (yyt); 
 yyWriteSelector ("Lop"); yyWriteAdr (yyt->schemaPipe.Lop);
 yyWriteSelector ("Rop"); yyWriteAdr (yyt->schemaPipe.Rop);
}

static void yWriteNodeschemaParen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeSchemaExp (yyt); 
 yyWriteSelector ("SchemaExp"); yyWriteAdr (yyt->schemaParen.SchemaExp);
}

static void yWriteNodeDesignator
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyWriteSelector ("ZName"); yyWriteAdr (yyt->Designator.ZName);
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->Designator.Decoration);
 yyWriteSelector ("ExpressionSeq"); yyWriteAdr (yyt->Designator.ExpressionSeq);
 yyWriteSelector ("RenameSeq"); yyWriteAdr (yyt->Designator.RenameSeq);
 yyWriteSelector ("IsSchemaRef"); writebool (yyt->Designator.IsSchemaRef) yyWriteNl ();
}

static void yWriteNodeVarNameSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoVarName
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeVarNameSeq (yyt); 
}

static void yWriteNodevarNames
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeVarNameSeq (yyt); 
 yyWriteSelector ("VarName"); yyWriteAdr (yyt->varNames.VarName);
 yyWriteSelector ("Next"); yyWriteAdr (yyt->varNames.Next);
}

static void yWriteNodeExpressionSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoExpSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpressionSeq (yyt); 
}

static void yWriteNodeexpSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpressionSeq (yyt); 
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->expSeq.Expression);
 yyWriteSelector ("Next"); yyWriteAdr (yyt->expSeq.Next);
}

static void yWriteNodeRenameSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoRename
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeRenameSeq (yyt); 
}

static void yWriteNoderenames
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeRenameSeq (yyt); 
 yyWriteSelector ("VarRename"); yyWriteAdr (yyt->renames.VarRename);
 yyWriteSelector ("Next"); yyWriteAdr (yyt->renames.Next);
}

static void yWriteNodeVarRename
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyWriteSelector ("New"); yyWriteAdr (yyt->VarRename.New);
 yyWriteSelector ("Old"); yyWriteAdr (yyt->VarRename.Old);
}

static void yWriteNodeZSchemaText
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyWriteSelector ("Declaration"); yyWriteAdr (yyt->ZSchemaText.Declaration);
 yyWriteSelector ("Predicate"); yyWriteAdr (yyt->ZSchemaText.Predicate);
}

static void yWriteNodeDeclaration
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoDecl
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeDeclaration (yyt); 
}

static void yWriteNodedecl
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeDeclaration (yyt); 
 yyWriteSelector ("BasicDecl"); yyWriteAdr (yyt->decl.BasicDecl);
 yyWriteSelector ("Next"); yyWriteAdr (yyt->decl.Next);
}

static void yWriteNodeBasicDecl
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodecolonDecl
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeBasicDecl (yyt); 
 yyWriteSelector ("VarNameSeq"); yyWriteAdr (yyt->colonDecl.VarNameSeq);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->colonDecl.Expression);
}

static void yWriteNodeschemaRef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeBasicDecl (yyt); 
 yyWriteSelector ("Designator"); yyWriteAdr (yyt->schemaRef.Designator);
}

static void yWriteNodePredicate
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoPred
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredicate (yyt); 
}

static void yWriteNodepredNegate
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredicate (yyt); 
 yyWriteSelector ("Predicate"); yyWriteAdr (yyt->predNegate.Predicate);
}

static void yWriteNodepredInfixRelSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredicate (yyt); 
 yyWriteSelector ("PredInfixRelSeq"); yyWriteAdr (yyt->predInfixRelSeq.PredInfixRelSeq);
}

static void yWriteNodepredTrueOrFalse
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredicate (yyt); 
 yyWriteSelector ("TrueFalse"); writetIdPos (yyt->predTrueOrFalse.TrueFalse) yyWriteNl ();
}

static void yWriteNodepredSchemaRef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredicate (yyt); 
 yyWriteSelector ("PredOrPre"); writetIdPos (yyt->predSchemaRef.PredOrPre) yyWriteNl ();
 yyWriteSelector ("Designator"); yyWriteAdr (yyt->predSchemaRef.Designator);
}

static void yWriteNodepredPreRel
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredicate (yyt); 
 yyWriteSelector ("PreRel"); writetIdPos (yyt->predPreRel.PreRel) yyWriteNl ();
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->predPreRel.Decoration);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->predPreRel.Expression);
}

static void yWriteNodepredCons
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredicate (yyt); 
 yyWriteSelector ("Lpred"); yyWriteAdr (yyt->predCons.Lpred);
 yyWriteSelector ("LogOp"); writetIdPos (yyt->predCons.LogOp) yyWriteNl ();
 yyWriteSelector ("Rpred"); yyWriteAdr (yyt->predCons.Rpred);
}

static void yWriteNodepredQuant
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredicate (yyt); 
 yyWriteSelector ("LogQuant"); writetIdPos (yyt->predQuant.LogQuant) yyWriteNl ();
 yyWriteSelector ("ZSchemaText"); yyWriteAdr (yyt->predQuant.ZSchemaText);
 yyWriteSelector ("Predicate"); yyWriteAdr (yyt->predQuant.Predicate);
}

static void yWriteNodepredLet
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredicate (yyt); 
 yyWriteSelector ("LetDefSeq"); yyWriteAdr (yyt->predLet.LetDefSeq);
 yyWriteSelector ("Predicate"); yyWriteAdr (yyt->predLet.Predicate);
}

static void yWriteNodepredParen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredicate (yyt); 
 yyWriteSelector ("Predicate"); yyWriteAdr (yyt->predParen.Predicate);
}

static void yWriteNodePredInfixRelSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoInfixRel
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredInfixRelSeq (yyt); 
}

static void yWriteNodeinfixRels
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodePredInfixRelSeq (yyt); 
 yyWriteSelector ("PredInfixRel"); yyWriteAdr (yyt->infixRels.PredInfixRel);
 yyWriteSelector ("Next"); yyWriteAdr (yyt->infixRels.Next);
}

static void yWriteNodePredInfixRel
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyWriteSelector ("Lexp"); yyWriteAdr (yyt->PredInfixRel.Lexp);
 yyWriteSelector ("InfixRel"); yyWriteAdr (yyt->PredInfixRel.InfixRel);
 yyWriteSelector ("Rexp"); yyWriteAdr (yyt->PredInfixRel.Rexp);
}

static void yWriteNodeInfixRel
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyWriteSelector ("InRel"); writetIdPos (yyt->InfixRel.InRel) yyWriteNl ();
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->InfixRel.Decoration);
}

static void yWriteNodeExpression
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoExp
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
}

static void yWriteNodeexpBinaryGen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("lexp"); yyWriteAdr (yyt->expBinaryGen.lexp);
 yyWriteSelector ("InGen"); writetIdPos (yyt->expBinaryGen.InGen) yyWriteNl ();
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->expBinaryGen.Decoration);
 yyWriteSelector ("rexp"); yyWriteAdr (yyt->expBinaryGen.rexp);
}

static void yWriteNodeexpBinaryFun
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("lexp"); yyWriteAdr (yyt->expBinaryFun.lexp);
 yyWriteSelector ("InFun"); writetIdPos (yyt->expBinaryFun.InFun) yyWriteNl ();
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->expBinaryFun.Decoration);
 yyWriteSelector ("rexp"); yyWriteAdr (yyt->expBinaryFun.rexp);
}

static void yWriteNodeexpLiteral
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("Literal"); writetIdPos (yyt->expLiteral.Literal) yyWriteNl ();
}

static void yWriteNodeexpOpname
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("VarName"); yyWriteAdr (yyt->expOpname.VarName);
 yyWriteSelector ("ExpressionSeq"); yyWriteAdr (yyt->expOpname.ExpressionSeq);
}

static void yWriteNodeexpSetElab
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("ExpressionSeq"); yyWriteAdr (yyt->expSetElab.ExpressionSeq);
}

static void yWriteNodeexpSeqElab
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("ExpressionSeq"); yyWriteAdr (yyt->expSeqElab.ExpressionSeq);
}

static void yWriteNodeexpBagElab
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("ExpressionSeq"); yyWriteAdr (yyt->expBagElab.ExpressionSeq);
}

static void yWriteNodeexpSetComp
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("ZSchemaText"); yyWriteAdr (yyt->expSetComp.ZSchemaText);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->expSetComp.Expression);
}

static void yWriteNodeexpPowerSet
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->expPowerSet.Expression);
}

static void yWriteNodeexpPreGen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("Pregen"); writetIdPos (yyt->expPreGen.Pregen) yyWriteNl ();
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->expPreGen.Decoration);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->expPreGen.Expression);
}

static void yWriteNodeexpPostFun
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->expPostFun.Expression);
 yyWriteSelector ("Postfun"); writetIdPos (yyt->expPostFun.Postfun) yyWriteNl ();
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->expPostFun.Decoration);
}

static void yWriteNodeexpIter
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("exp1"); yyWriteAdr (yyt->expIter.exp1);
 yyWriteSelector ("exp2"); yyWriteAdr (yyt->expIter.exp2);
}

static void yWriteNodeexpTuple
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("ExpressionSeq"); yyWriteAdr (yyt->expTuple.ExpressionSeq);
}

static void yWriteNodeexpCartProd
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("ExpressionSeq"); yyWriteAdr (yyt->expCartProd.ExpressionSeq);
}

static void yWriteNodeexpTheta
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("ZName"); yyWriteAdr (yyt->expTheta.ZName);
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->expTheta.Decoration);
 yyWriteSelector ("RenameSeq"); yyWriteAdr (yyt->expTheta.RenameSeq);
}

static void yWriteNodeexpSelectVar
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->expSelectVar.Expression);
 yyWriteSelector ("VarName"); yyWriteAdr (yyt->expSelectVar.VarName);
}

static void yWriteNodeexpFnApp
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("FnName"); yyWriteAdr (yyt->expFnApp.FnName);
 yyWriteSelector ("Params"); yyWriteAdr (yyt->expFnApp.Params);
}

static void yWriteNodeexpMu
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("ZSchemaText"); yyWriteAdr (yyt->expMu.ZSchemaText);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->expMu.Expression);
}

static void yWriteNodeexpLambda
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("ZSchemaText"); yyWriteAdr (yyt->expLambda.ZSchemaText);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->expLambda.Expression);
}

static void yWriteNodeexpLet
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("LetDefSeq"); yyWriteAdr (yyt->expLet.LetDefSeq);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->expLet.Expression);
}

static void yWriteNodeexpIf
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("Predicate"); yyWriteAdr (yyt->expIf.Predicate);
 yyWriteSelector ("Exp1"); yyWriteAdr (yyt->expIf.Exp1);
 yyWriteSelector ("Exp2"); yyWriteAdr (yyt->expIf.Exp2);
}

static void yWriteNodeexpImage
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("Exp1"); yyWriteAdr (yyt->expImage.Exp1);
 yyWriteSelector ("Exp2"); yyWriteAdr (yyt->expImage.Exp2);
 yyWriteSelector ("Image"); writetIdPos (yyt->expImage.Image) yyWriteNl ();
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->expImage.Decoration);
}

static void yWriteNodeexpDesignator
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("Designator"); yyWriteAdr (yyt->expDesignator.Designator);
}

static void yWriteNodeexpParen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeExpression (yyt); 
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->expParen.Expression);
}

static void yWriteNodeLetDefSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoLetDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeLetDefSeq (yyt); 
}

static void yWriteNodeletDefs
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeLetDefSeq (yyt); 
 yyWriteSelector ("LetDef"); yyWriteAdr (yyt->letDefs.LetDef);
 yyWriteSelector ("Next"); yyWriteAdr (yyt->letDefs.Next);
}

static void yWriteNodeLetDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyWriteSelector ("VarName"); yyWriteAdr (yyt->LetDef.VarName);
 yyWriteSelector ("Expression"); yyWriteAdr (yyt->LetDef.Expression);
}

static void yWriteNodeVarName
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyWriteSelector ("Ident"); writetIdPos (yyt->VarName.Ident) yyWriteNl ();
 yyWriteSelector ("Decoration"); yyWriteAdr (yyt->VarName.Decoration);
}

static void yWriteNodeZId
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeVarName (yyt); 
}

static void yWriteNodeOpname
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeVarName (yyt); 
}

static void yWriteNodeDecoration
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
}

static void yWriteNodenoDecoration
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeDecoration (yyt); 
}

static void yWriteNodedecoration
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yWriteNodeDecoration (yyt); 
 yyWriteSelector ("Stroke"); writetIdPos (yyt->decoration.Stroke) yyWriteNl ();
 yyWriteSelector ("Next"); yyWriteAdr (yyt->decoration.Next);
}

static void yWriteNodeZName
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyWriteSelector ("Ident"); writetIdPos (yyt->ZName.Ident) yyWriteNl ();
}

void WriteZTreeNode
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf, tZTree yyt)
# else
 (yyyf, yyt) FILE * yyyf; tZTree yyt;
# endif
{
 yyf = yyyf;
 if (yyt == NoZTree) { (void) fputs ("NoZTree\n", yyf); return; }

 switch (yyt->Kind) {
case kSpecification: (void) fputs (ZTree_NodeName [kSpecification], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSpecification (yyt); break;
case kGlobalParagraphSeq: (void) fputs (ZTree_NodeName [kGlobalParagraphSeq], yyf); (void) fputc ('\n', yyf);
 yWriteNodeGlobalParagraphSeq (yyt); break;
case knoGlobalParagraph: (void) fputs (ZTree_NodeName [knoGlobalParagraph], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoGlobalParagraph (yyt); break;
case kglobalParagraphs: (void) fputs (ZTree_NodeName [kglobalParagraphs], yyf); (void) fputc ('\n', yyf);
 yWriteNodeglobalParagraphs (yyt); break;
case kGlobalParagraph: (void) fputs (ZTree_NodeName [kGlobalParagraph], yyf); (void) fputc ('\n', yyf);
 yWriteNodeGlobalParagraph (yyt); break;
case kaxiomaticDef: (void) fputs (ZTree_NodeName [kaxiomaticDef], yyf); (void) fputc ('\n', yyf);
 yWriteNodeaxiomaticDef (yyt); break;
case khorizPar: (void) fputs (ZTree_NodeName [khorizPar], yyf); (void) fputc ('\n', yyf);
 yWriteNodehorizPar (yyt); break;
case kgenericDef: (void) fputs (ZTree_NodeName [kgenericDef], yyf); (void) fputc ('\n', yyf);
 yWriteNodegenericDef (yyt); break;
case kschemaboxDef: (void) fputs (ZTree_NodeName [kschemaboxDef], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaboxDef (yyt); break;
case kHorizParagraphs: (void) fputs (ZTree_NodeName [kHorizParagraphs], yyf); (void) fputc ('\n', yyf);
 yWriteNodeHorizParagraphs (yyt); break;
case knoHorizParagraph: (void) fputs (ZTree_NodeName [knoHorizParagraph], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoHorizParagraph (yyt); break;
case khorizParagraphs: (void) fputs (ZTree_NodeName [khorizParagraphs], yyf); (void) fputc ('\n', yyf);
 yWriteNodehorizParagraphs (yyt); break;
case kHorizParagraph: (void) fputs (ZTree_NodeName [kHorizParagraph], yyf); (void) fputc ('\n', yyf);
 yWriteNodeHorizParagraph (yyt); break;
case ktypeDef: (void) fputs (ZTree_NodeName [ktypeDef], yyf); (void) fputc ('\n', yyf);
 yWriteNodetypeDef (yyt); break;
case kglobalPredicate: (void) fputs (ZTree_NodeName [kglobalPredicate], yyf); (void) fputc ('\n', yyf);
 yWriteNodeglobalPredicate (yyt); break;
case kschemaDef: (void) fputs (ZTree_NodeName [kschemaDef], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaDef (yyt); break;
case kTypeDef: (void) fputs (ZTree_NodeName [kTypeDef], yyf); (void) fputc ('\n', yyf);
 yWriteNodeTypeDef (yyt); break;
case kgivenSet: (void) fputs (ZTree_NodeName [kgivenSet], yyf); (void) fputc ('\n', yyf);
 yWriteNodegivenSet (yyt); break;
case kfreeType: (void) fputs (ZTree_NodeName [kfreeType], yyf); (void) fputc ('\n', yyf);
 yWriteNodefreeType (yyt); break;
case ktypeDef1: (void) fputs (ZTree_NodeName [ktypeDef1], yyf); (void) fputc ('\n', yyf);
 yWriteNodetypeDef1 (yyt); break;
case ktypeDefPregen: (void) fputs (ZTree_NodeName [ktypeDefPregen], yyf); (void) fputc ('\n', yyf);
 yWriteNodetypeDefPregen (yyt); break;
case ktypeDefIngen: (void) fputs (ZTree_NodeName [ktypeDefIngen], yyf); (void) fputc ('\n', yyf);
 yWriteNodetypeDefIngen (yyt); break;
case kNameFormals: (void) fputs (ZTree_NodeName [kNameFormals], yyf); (void) fputc ('\n', yyf);
 yWriteNodeNameFormals (yyt); break;
case knoFormals: (void) fputs (ZTree_NodeName [knoFormals], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoFormals (yyt); break;
case knameFormals: (void) fputs (ZTree_NodeName [knameFormals], yyf); (void) fputc ('\n', yyf);
 yWriteNodenameFormals (yyt); break;
case kBranchSeq: (void) fputs (ZTree_NodeName [kBranchSeq], yyf); (void) fputc ('\n', yyf);
 yWriteNodeBranchSeq (yyt); break;
case knoBranch: (void) fputs (ZTree_NodeName [knoBranch], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoBranch (yyt); break;
case kbranch: (void) fputs (ZTree_NodeName [kbranch], yyf); (void) fputc ('\n', yyf);
 yWriteNodebranch (yyt); break;
case kZFormalParams: (void) fputs (ZTree_NodeName [kZFormalParams], yyf); (void) fputc ('\n', yyf);
 yWriteNodeZFormalParams (yyt); break;
case knoFormalParams: (void) fputs (ZTree_NodeName [knoFormalParams], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoFormalParams (yyt); break;
case kformalParams: (void) fputs (ZTree_NodeName [kformalParams], yyf); (void) fputc ('\n', yyf);
 yWriteNodeformalParams (yyt); break;
case kZBranch: (void) fputs (ZTree_NodeName [kZBranch], yyf); (void) fputc ('\n', yyf);
 yWriteNodeZBranch (yyt); break;
case ksimpleBranch: (void) fputs (ZTree_NodeName [ksimpleBranch], yyf); (void) fputc ('\n', yyf);
 yWriteNodesimpleBranch (yyt); break;
case kcompoundBranch: (void) fputs (ZTree_NodeName [kcompoundBranch], yyf); (void) fputc ('\n', yyf);
 yWriteNodecompoundBranch (yyt); break;
case kSchemaExp: (void) fputs (ZTree_NodeName [kSchemaExp], yyf); (void) fputc ('\n', yyf);
 yWriteNodeSchemaExp (yyt); break;
case kschemaSimple: (void) fputs (ZTree_NodeName [kschemaSimple], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaSimple (yyt); break;
case kschemaDes: (void) fputs (ZTree_NodeName [kschemaDes], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaDes (yyt); break;
case kschemaPreop: (void) fputs (ZTree_NodeName [kschemaPreop], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaPreop (yyt); break;
case kschemaCons: (void) fputs (ZTree_NodeName [kschemaCons], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaCons (yyt); break;
case kschemaHide: (void) fputs (ZTree_NodeName [kschemaHide], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaHide (yyt); break;
case kschemaQuant: (void) fputs (ZTree_NodeName [kschemaQuant], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaQuant (yyt); break;
case kschemaComp: (void) fputs (ZTree_NodeName [kschemaComp], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaComp (yyt); break;
case kschemaProject: (void) fputs (ZTree_NodeName [kschemaProject], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaProject (yyt); break;
case kschemaPipe: (void) fputs (ZTree_NodeName [kschemaPipe], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaPipe (yyt); break;
case kschemaParen: (void) fputs (ZTree_NodeName [kschemaParen], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaParen (yyt); break;
case kDesignator: (void) fputs (ZTree_NodeName [kDesignator], yyf); (void) fputc ('\n', yyf);
 yWriteNodeDesignator (yyt); break;
case kVarNameSeq: (void) fputs (ZTree_NodeName [kVarNameSeq], yyf); (void) fputc ('\n', yyf);
 yWriteNodeVarNameSeq (yyt); break;
case knoVarName: (void) fputs (ZTree_NodeName [knoVarName], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoVarName (yyt); break;
case kvarNames: (void) fputs (ZTree_NodeName [kvarNames], yyf); (void) fputc ('\n', yyf);
 yWriteNodevarNames (yyt); break;
case kExpressionSeq: (void) fputs (ZTree_NodeName [kExpressionSeq], yyf); (void) fputc ('\n', yyf);
 yWriteNodeExpressionSeq (yyt); break;
case knoExpSeq: (void) fputs (ZTree_NodeName [knoExpSeq], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoExpSeq (yyt); break;
case kexpSeq: (void) fputs (ZTree_NodeName [kexpSeq], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpSeq (yyt); break;
case kRenameSeq: (void) fputs (ZTree_NodeName [kRenameSeq], yyf); (void) fputc ('\n', yyf);
 yWriteNodeRenameSeq (yyt); break;
case knoRename: (void) fputs (ZTree_NodeName [knoRename], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoRename (yyt); break;
case krenames: (void) fputs (ZTree_NodeName [krenames], yyf); (void) fputc ('\n', yyf);
 yWriteNoderenames (yyt); break;
case kVarRename: (void) fputs (ZTree_NodeName [kVarRename], yyf); (void) fputc ('\n', yyf);
 yWriteNodeVarRename (yyt); break;
case kZSchemaText: (void) fputs (ZTree_NodeName [kZSchemaText], yyf); (void) fputc ('\n', yyf);
 yWriteNodeZSchemaText (yyt); break;
case kDeclaration: (void) fputs (ZTree_NodeName [kDeclaration], yyf); (void) fputc ('\n', yyf);
 yWriteNodeDeclaration (yyt); break;
case knoDecl: (void) fputs (ZTree_NodeName [knoDecl], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoDecl (yyt); break;
case kdecl: (void) fputs (ZTree_NodeName [kdecl], yyf); (void) fputc ('\n', yyf);
 yWriteNodedecl (yyt); break;
case kBasicDecl: (void) fputs (ZTree_NodeName [kBasicDecl], yyf); (void) fputc ('\n', yyf);
 yWriteNodeBasicDecl (yyt); break;
case kcolonDecl: (void) fputs (ZTree_NodeName [kcolonDecl], yyf); (void) fputc ('\n', yyf);
 yWriteNodecolonDecl (yyt); break;
case kschemaRef: (void) fputs (ZTree_NodeName [kschemaRef], yyf); (void) fputc ('\n', yyf);
 yWriteNodeschemaRef (yyt); break;
case kPredicate: (void) fputs (ZTree_NodeName [kPredicate], yyf); (void) fputc ('\n', yyf);
 yWriteNodePredicate (yyt); break;
case knoPred: (void) fputs (ZTree_NodeName [knoPred], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoPred (yyt); break;
case kpredNegate: (void) fputs (ZTree_NodeName [kpredNegate], yyf); (void) fputc ('\n', yyf);
 yWriteNodepredNegate (yyt); break;
case kpredInfixRelSeq: (void) fputs (ZTree_NodeName [kpredInfixRelSeq], yyf); (void) fputc ('\n', yyf);
 yWriteNodepredInfixRelSeq (yyt); break;
case kpredTrueOrFalse: (void) fputs (ZTree_NodeName [kpredTrueOrFalse], yyf); (void) fputc ('\n', yyf);
 yWriteNodepredTrueOrFalse (yyt); break;
case kpredSchemaRef: (void) fputs (ZTree_NodeName [kpredSchemaRef], yyf); (void) fputc ('\n', yyf);
 yWriteNodepredSchemaRef (yyt); break;
case kpredPreRel: (void) fputs (ZTree_NodeName [kpredPreRel], yyf); (void) fputc ('\n', yyf);
 yWriteNodepredPreRel (yyt); break;
case kpredCons: (void) fputs (ZTree_NodeName [kpredCons], yyf); (void) fputc ('\n', yyf);
 yWriteNodepredCons (yyt); break;
case kpredQuant: (void) fputs (ZTree_NodeName [kpredQuant], yyf); (void) fputc ('\n', yyf);
 yWriteNodepredQuant (yyt); break;
case kpredLet: (void) fputs (ZTree_NodeName [kpredLet], yyf); (void) fputc ('\n', yyf);
 yWriteNodepredLet (yyt); break;
case kpredParen: (void) fputs (ZTree_NodeName [kpredParen], yyf); (void) fputc ('\n', yyf);
 yWriteNodepredParen (yyt); break;
case kPredInfixRelSeq: (void) fputs (ZTree_NodeName [kPredInfixRelSeq], yyf); (void) fputc ('\n', yyf);
 yWriteNodePredInfixRelSeq (yyt); break;
case knoInfixRel: (void) fputs (ZTree_NodeName [knoInfixRel], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoInfixRel (yyt); break;
case kinfixRels: (void) fputs (ZTree_NodeName [kinfixRels], yyf); (void) fputc ('\n', yyf);
 yWriteNodeinfixRels (yyt); break;
case kPredInfixRel: (void) fputs (ZTree_NodeName [kPredInfixRel], yyf); (void) fputc ('\n', yyf);
 yWriteNodePredInfixRel (yyt); break;
case kInfixRel: (void) fputs (ZTree_NodeName [kInfixRel], yyf); (void) fputc ('\n', yyf);
 yWriteNodeInfixRel (yyt); break;
case kExpression: (void) fputs (ZTree_NodeName [kExpression], yyf); (void) fputc ('\n', yyf);
 yWriteNodeExpression (yyt); break;
case knoExp: (void) fputs (ZTree_NodeName [knoExp], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoExp (yyt); break;
case kexpBinaryGen: (void) fputs (ZTree_NodeName [kexpBinaryGen], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpBinaryGen (yyt); break;
case kexpBinaryFun: (void) fputs (ZTree_NodeName [kexpBinaryFun], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpBinaryFun (yyt); break;
case kexpLiteral: (void) fputs (ZTree_NodeName [kexpLiteral], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpLiteral (yyt); break;
case kexpOpname: (void) fputs (ZTree_NodeName [kexpOpname], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpOpname (yyt); break;
case kexpSetElab: (void) fputs (ZTree_NodeName [kexpSetElab], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpSetElab (yyt); break;
case kexpSeqElab: (void) fputs (ZTree_NodeName [kexpSeqElab], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpSeqElab (yyt); break;
case kexpBagElab: (void) fputs (ZTree_NodeName [kexpBagElab], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpBagElab (yyt); break;
case kexpSetComp: (void) fputs (ZTree_NodeName [kexpSetComp], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpSetComp (yyt); break;
case kexpPowerSet: (void) fputs (ZTree_NodeName [kexpPowerSet], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpPowerSet (yyt); break;
case kexpPreGen: (void) fputs (ZTree_NodeName [kexpPreGen], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpPreGen (yyt); break;
case kexpPostFun: (void) fputs (ZTree_NodeName [kexpPostFun], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpPostFun (yyt); break;
case kexpIter: (void) fputs (ZTree_NodeName [kexpIter], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpIter (yyt); break;
case kexpTuple: (void) fputs (ZTree_NodeName [kexpTuple], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpTuple (yyt); break;
case kexpCartProd: (void) fputs (ZTree_NodeName [kexpCartProd], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpCartProd (yyt); break;
case kexpTheta: (void) fputs (ZTree_NodeName [kexpTheta], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpTheta (yyt); break;
case kexpSelectVar: (void) fputs (ZTree_NodeName [kexpSelectVar], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpSelectVar (yyt); break;
case kexpFnApp: (void) fputs (ZTree_NodeName [kexpFnApp], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpFnApp (yyt); break;
case kexpMu: (void) fputs (ZTree_NodeName [kexpMu], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpMu (yyt); break;
case kexpLambda: (void) fputs (ZTree_NodeName [kexpLambda], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpLambda (yyt); break;
case kexpLet: (void) fputs (ZTree_NodeName [kexpLet], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpLet (yyt); break;
case kexpIf: (void) fputs (ZTree_NodeName [kexpIf], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpIf (yyt); break;
case kexpImage: (void) fputs (ZTree_NodeName [kexpImage], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpImage (yyt); break;
case kexpDesignator: (void) fputs (ZTree_NodeName [kexpDesignator], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpDesignator (yyt); break;
case kexpParen: (void) fputs (ZTree_NodeName [kexpParen], yyf); (void) fputc ('\n', yyf);
 yWriteNodeexpParen (yyt); break;
case kLetDefSeq: (void) fputs (ZTree_NodeName [kLetDefSeq], yyf); (void) fputc ('\n', yyf);
 yWriteNodeLetDefSeq (yyt); break;
case knoLetDef: (void) fputs (ZTree_NodeName [knoLetDef], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoLetDef (yyt); break;
case kletDefs: (void) fputs (ZTree_NodeName [kletDefs], yyf); (void) fputc ('\n', yyf);
 yWriteNodeletDefs (yyt); break;
case kLetDef: (void) fputs (ZTree_NodeName [kLetDef], yyf); (void) fputc ('\n', yyf);
 yWriteNodeLetDef (yyt); break;
case kVarName: (void) fputs (ZTree_NodeName [kVarName], yyf); (void) fputc ('\n', yyf);
 yWriteNodeVarName (yyt); break;
case kZId: (void) fputs (ZTree_NodeName [kZId], yyf); (void) fputc ('\n', yyf);
 yWriteNodeZId (yyt); break;
case kOpname: (void) fputs (ZTree_NodeName [kOpname], yyf); (void) fputc ('\n', yyf);
 yWriteNodeOpname (yyt); break;
case kDecoration: (void) fputs (ZTree_NodeName [kDecoration], yyf); (void) fputc ('\n', yyf);
 yWriteNodeDecoration (yyt); break;
case knoDecoration: (void) fputs (ZTree_NodeName [knoDecoration], yyf); (void) fputc ('\n', yyf);
 yWriteNodenoDecoration (yyt); break;
case kdecoration: (void) fputs (ZTree_NodeName [kdecoration], yyf); (void) fputc ('\n', yyf);
 yWriteNodedecoration (yyt); break;
case kZName: (void) fputs (ZTree_NodeName [kZName], yyf); (void) fputc ('\n', yyf);
 yWriteNodeZName (yyt); break;
 default: ;
 }
}

static short yyIndentLevel;

void WriteZTree
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf, tZTree yyt)
# else
 (yyyf, yyt) FILE * yyyf; tZTree yyt;
# endif
{
 short yySaveLevel = yyIndentLevel;
 yyf = yyyf;
 if (yyRecursionLevel ++ == 0) yyLabelCount = 0;
 yyMark (yyt);
 yyIndentLevel = 0;
 yyWriteZTree (yyt);
 yyIndentLevel = yySaveLevel;
 yyRecursionLevel --;
}

static void yyIndentSelector
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyIndentLevel; yyi ++) (void) putc (' ', yyf);
 yyWriteSelector (yys);
}

static void yyIndentSelectorTree
# if defined __STDC__ | defined __cplusplus
 (char * yys, tZTree yyt)
# else
 (yys, yyt) char * yys; tZTree yyt;
# endif
{ yyIndentSelector (yys); writetZTree (yyt) }

static void yWriteSpecification
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kSpecification], yyf); (void) fputc ('\n', yyf);
}

static void yWriteGlobalParagraphSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kGlobalParagraphSeq], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoGlobalParagraph
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoGlobalParagraph], yyf); (void) fputc ('\n', yyf);
}

static void yWriteglobalParagraphs
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kglobalParagraphs], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("GlobalParagraph", yyt->globalParagraphs.GlobalParagraph);
}

static void yWriteGlobalParagraph
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kGlobalParagraph], yyf); (void) fputc ('\n', yyf);
}

static void yWriteaxiomaticDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kaxiomaticDef], yyf); (void) fputc ('\n', yyf);
}

static void yWritehorizPar
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [khorizPar], yyf); (void) fputc ('\n', yyf);
}

static void yWritegenericDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kgenericDef], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("ZFormalParams", yyt->genericDef.ZFormalParams);
}

static void yWriteschemaboxDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaboxDef], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("ZName", yyt->schemaboxDef.ZName);
 yyIndentSelectorTree ("ZFormalParams", yyt->schemaboxDef.ZFormalParams);
}

static void yWriteHorizParagraphs
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kHorizParagraphs], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoHorizParagraph
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoHorizParagraph], yyf); (void) fputc ('\n', yyf);
}

static void yWritehorizParagraphs
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [khorizParagraphs], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("HorizParagraph", yyt->horizParagraphs.HorizParagraph);
}

static void yWriteHorizParagraph
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kHorizParagraph], yyf); (void) fputc ('\n', yyf);
}

static void yWritetypeDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [ktypeDef], yyf); (void) fputc ('\n', yyf);
}

static void yWriteglobalPredicate
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kglobalPredicate], yyf); (void) fputc ('\n', yyf);
}

static void yWriteschemaDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaDef], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("NameFormals", yyt->schemaDef.NameFormals);
}

static void yWriteTypeDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kTypeDef], yyf); (void) fputc ('\n', yyf);
}

static void yWritegivenSet
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kgivenSet], yyf); (void) fputc ('\n', yyf);
}

static void yWritefreeType
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kfreeType], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("VarName", yyt->freeType.VarName);
}

static void yWritetypeDef1
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [ktypeDef1], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("NameFormals", yyt->typeDef1.NameFormals);
}

static void yWritetypeDefPregen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [ktypeDefPregen], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("PreGen"); writetIdPos (yyt->typeDefPregen.PreGen) yyWriteNl ();
 yyIndentSelectorTree ("Decoration", yyt->typeDefPregen.Decoration);
 yyIndentSelectorTree ("VarName", yyt->typeDefPregen.VarName);
}

static void yWritetypeDefIngen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [ktypeDefIngen], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Var1", yyt->typeDefIngen.Var1);
 yyIndentSelector ("InGen"); writetIdPos (yyt->typeDefIngen.InGen) yyWriteNl ();
 yyIndentSelectorTree ("Decoration", yyt->typeDefIngen.Decoration);
 yyIndentSelectorTree ("Var2", yyt->typeDefIngen.Var2);
}

static void yWriteNameFormals
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kNameFormals], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoFormals
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoFormals], yyf); (void) fputc ('\n', yyf);
}

static void yWritenameFormals
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knameFormals], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("VarName", yyt->nameFormals.VarName);
}

static void yWriteBranchSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kBranchSeq], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoBranch
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoBranch], yyf); (void) fputc ('\n', yyf);
}

static void yWritebranch
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kbranch], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("ZBranch", yyt->branch.ZBranch);
}

static void yWriteZFormalParams
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kZFormalParams], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoFormalParams
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoFormalParams], yyf); (void) fputc ('\n', yyf);
}

static void yWriteformalParams
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kformalParams], yyf); (void) fputc ('\n', yyf);
}

static void yWriteZBranch
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kZBranch], yyf); (void) fputc ('\n', yyf);
}

static void yWritesimpleBranch
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [ksimpleBranch], yyf); (void) fputc ('\n', yyf);
}

static void yWritecompoundBranch
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kcompoundBranch], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("VarName", yyt->compoundBranch.VarName);
}

static void yWriteSchemaExp
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kSchemaExp], yyf); (void) fputc ('\n', yyf);
}

static void yWriteschemaSimple
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaSimple], yyf); (void) fputc ('\n', yyf);
}

static void yWriteschemaDes
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaDes], yyf); (void) fputc ('\n', yyf);
}

static void yWriteschemaPreop
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaPreop], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("PreOp"); writetIdPos (yyt->schemaPreop.PreOp) yyWriteNl ();
}

static void yWriteschemaCons
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaCons], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Lop", yyt->schemaCons.Lop);
 yyIndentSelector ("SchemaOp"); writetIdPos (yyt->schemaCons.SchemaOp) yyWriteNl ();
}

static void yWriteschemaHide
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaHide], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("SchemaExp", yyt->schemaHide.SchemaExp);
}

static void yWriteschemaQuant
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaQuant], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("LogQuant"); writetIdPos (yyt->schemaQuant.LogQuant) yyWriteNl ();
 yyIndentSelectorTree ("ZSchemaText", yyt->schemaQuant.ZSchemaText);
}

static void yWriteschemaComp
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaComp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Lop", yyt->schemaComp.Lop);
}

static void yWriteschemaProject
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaProject], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Lop", yyt->schemaProject.Lop);
}

static void yWriteschemaPipe
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaPipe], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Lop", yyt->schemaPipe.Lop);
}

static void yWriteschemaParen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaParen], yyf); (void) fputc ('\n', yyf);
}

static void yWriteDesignator
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kDesignator], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("ZName", yyt->Designator.ZName);
 yyIndentSelectorTree ("Decoration", yyt->Designator.Decoration);
 yyIndentSelectorTree ("ExpressionSeq", yyt->Designator.ExpressionSeq);
 yyIndentSelector ("IsSchemaRef"); writebool (yyt->Designator.IsSchemaRef) yyWriteNl ();
}

static void yWriteVarNameSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kVarNameSeq], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoVarName
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoVarName], yyf); (void) fputc ('\n', yyf);
}

static void yWritevarNames
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kvarNames], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("VarName", yyt->varNames.VarName);
}

static void yWriteExpressionSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kExpressionSeq], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoExpSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoExpSeq], yyf); (void) fputc ('\n', yyf);
}

static void yWriteexpSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpSeq], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Expression", yyt->expSeq.Expression);
}

static void yWriteRenameSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kRenameSeq], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoRename
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoRename], yyf); (void) fputc ('\n', yyf);
}

static void yWriterenames
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [krenames], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("VarRename", yyt->renames.VarRename);
}

static void yWriteVarRename
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kVarRename], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("New", yyt->VarRename.New);
}

static void yWriteZSchemaText
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kZSchemaText], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Declaration", yyt->ZSchemaText.Declaration);
}

static void yWriteDeclaration
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kDeclaration], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoDecl
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoDecl], yyf); (void) fputc ('\n', yyf);
}

static void yWritedecl
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kdecl], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("BasicDecl", yyt->decl.BasicDecl);
}

static void yWriteBasicDecl
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kBasicDecl], yyf); (void) fputc ('\n', yyf);
}

static void yWritecolonDecl
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kcolonDecl], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("VarNameSeq", yyt->colonDecl.VarNameSeq);
}

static void yWriteschemaRef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kschemaRef], yyf); (void) fputc ('\n', yyf);
}

static void yWritePredicate
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kPredicate], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoPred
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoPred], yyf); (void) fputc ('\n', yyf);
}

static void yWritepredNegate
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kpredNegate], yyf); (void) fputc ('\n', yyf);
}

static void yWritepredInfixRelSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kpredInfixRelSeq], yyf); (void) fputc ('\n', yyf);
}

static void yWritepredTrueOrFalse
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kpredTrueOrFalse], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("TrueFalse"); writetIdPos (yyt->predTrueOrFalse.TrueFalse) yyWriteNl ();
}

static void yWritepredSchemaRef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kpredSchemaRef], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("PredOrPre"); writetIdPos (yyt->predSchemaRef.PredOrPre) yyWriteNl ();
}

static void yWritepredPreRel
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kpredPreRel], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("PreRel"); writetIdPos (yyt->predPreRel.PreRel) yyWriteNl ();
 yyIndentSelectorTree ("Decoration", yyt->predPreRel.Decoration);
}

static void yWritepredCons
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kpredCons], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Lpred", yyt->predCons.Lpred);
 yyIndentSelector ("LogOp"); writetIdPos (yyt->predCons.LogOp) yyWriteNl ();
}

static void yWritepredQuant
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kpredQuant], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("LogQuant"); writetIdPos (yyt->predQuant.LogQuant) yyWriteNl ();
 yyIndentSelectorTree ("ZSchemaText", yyt->predQuant.ZSchemaText);
}

static void yWritepredLet
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kpredLet], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("LetDefSeq", yyt->predLet.LetDefSeq);
}

static void yWritepredParen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kpredParen], yyf); (void) fputc ('\n', yyf);
}

static void yWritePredInfixRelSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kPredInfixRelSeq], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoInfixRel
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoInfixRel], yyf); (void) fputc ('\n', yyf);
}

static void yWriteinfixRels
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kinfixRels], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("PredInfixRel", yyt->infixRels.PredInfixRel);
}

static void yWritePredInfixRel
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kPredInfixRel], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Lexp", yyt->PredInfixRel.Lexp);
 yyIndentSelectorTree ("InfixRel", yyt->PredInfixRel.InfixRel);
}

static void yWriteInfixRel
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kInfixRel], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("InRel"); writetIdPos (yyt->InfixRel.InRel) yyWriteNl ();
}

static void yWriteExpression
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kExpression], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoExp
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoExp], yyf); (void) fputc ('\n', yyf);
}

static void yWriteexpBinaryGen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpBinaryGen], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("lexp", yyt->expBinaryGen.lexp);
 yyIndentSelector ("InGen"); writetIdPos (yyt->expBinaryGen.InGen) yyWriteNl ();
 yyIndentSelectorTree ("Decoration", yyt->expBinaryGen.Decoration);
}

static void yWriteexpBinaryFun
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpBinaryFun], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("lexp", yyt->expBinaryFun.lexp);
 yyIndentSelector ("InFun"); writetIdPos (yyt->expBinaryFun.InFun) yyWriteNl ();
 yyIndentSelectorTree ("Decoration", yyt->expBinaryFun.Decoration);
}

static void yWriteexpLiteral
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpLiteral], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Literal"); writetIdPos (yyt->expLiteral.Literal) yyWriteNl ();
}

static void yWriteexpOpname
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpOpname], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("VarName", yyt->expOpname.VarName);
}

static void yWriteexpSetElab
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpSetElab], yyf); (void) fputc ('\n', yyf);
}

static void yWriteexpSeqElab
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpSeqElab], yyf); (void) fputc ('\n', yyf);
}

static void yWriteexpBagElab
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpBagElab], yyf); (void) fputc ('\n', yyf);
}

static void yWriteexpSetComp
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpSetComp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("ZSchemaText", yyt->expSetComp.ZSchemaText);
}

static void yWriteexpPowerSet
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpPowerSet], yyf); (void) fputc ('\n', yyf);
}

static void yWriteexpPreGen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpPreGen], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Pregen"); writetIdPos (yyt->expPreGen.Pregen) yyWriteNl ();
 yyIndentSelectorTree ("Decoration", yyt->expPreGen.Decoration);
}

static void yWriteexpPostFun
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpPostFun], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Expression", yyt->expPostFun.Expression);
 yyIndentSelector ("Postfun"); writetIdPos (yyt->expPostFun.Postfun) yyWriteNl ();
}

static void yWriteexpIter
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpIter], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("exp1", yyt->expIter.exp1);
}

static void yWriteexpTuple
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpTuple], yyf); (void) fputc ('\n', yyf);
}

static void yWriteexpCartProd
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpCartProd], yyf); (void) fputc ('\n', yyf);
}

static void yWriteexpTheta
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpTheta], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("ZName", yyt->expTheta.ZName);
 yyIndentSelectorTree ("Decoration", yyt->expTheta.Decoration);
}

static void yWriteexpSelectVar
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpSelectVar], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Expression", yyt->expSelectVar.Expression);
}

static void yWriteexpFnApp
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpFnApp], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("FnName", yyt->expFnApp.FnName);
}

static void yWriteexpMu
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpMu], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("ZSchemaText", yyt->expMu.ZSchemaText);
}

static void yWriteexpLambda
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpLambda], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("ZSchemaText", yyt->expLambda.ZSchemaText);
}

static void yWriteexpLet
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpLet], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("LetDefSeq", yyt->expLet.LetDefSeq);
}

static void yWriteexpIf
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpIf], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Predicate", yyt->expIf.Predicate);
 yyIndentSelectorTree ("Exp1", yyt->expIf.Exp1);
}

static void yWriteexpImage
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpImage], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("Exp1", yyt->expImage.Exp1);
 yyIndentSelectorTree ("Exp2", yyt->expImage.Exp2);
 yyIndentSelector ("Image"); writetIdPos (yyt->expImage.Image) yyWriteNl ();
}

static void yWriteexpDesignator
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpDesignator], yyf); (void) fputc ('\n', yyf);
}

static void yWriteexpParen
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kexpParen], yyf); (void) fputc ('\n', yyf);
}

static void yWriteLetDefSeq
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kLetDefSeq], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoLetDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoLetDef], yyf); (void) fputc ('\n', yyf);
}

static void yWriteletDefs
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kletDefs], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("LetDef", yyt->letDefs.LetDef);
}

static void yWriteLetDef
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kLetDef], yyf); (void) fputc ('\n', yyf);
 yyIndentSelectorTree ("VarName", yyt->LetDef.VarName);
}

static void yWriteVarName
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kVarName], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Ident"); writetIdPos (yyt->VarName.Ident) yyWriteNl ();
}

static void yWriteZId
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kZId], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Ident"); writetIdPos (yyt->ZId.Ident) yyWriteNl ();
}

static void yWriteOpname
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kOpname], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Ident"); writetIdPos (yyt->Opname.Ident) yyWriteNl ();
}

static void yWriteDecoration
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kDecoration], yyf); (void) fputc ('\n', yyf);
}

static void yWritenoDecoration
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [knoDecoration], yyf); (void) fputc ('\n', yyf);
}

static void yWritedecoration
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kdecoration], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Stroke"); writetIdPos (yyt->decoration.Stroke) yyWriteNl ();
}

static void yWriteZName
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 (void) fputs (ZTree_NodeName [kZName], yyf); (void) fputc ('\n', yyf);
 yyIndentSelector ("Ident"); writetIdPos (yyt->ZName.Ident) yyWriteNl ();
}

static void yyWriteZTree
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{ unsigned short yyLevel = yyIndentLevel;
 for (;;) {
  if (yyt == NoZTree) { (void) fputs (" NoZTree\n", yyf); goto yyExit;
  } else if (yyt->yyHead.yyMark == 0) { (void) fprintf (yyf, "^%d\n", yyMapToLabel (yyt)); goto yyExit;
  } else if (yyt->yyHead.yyMark > 1) {
   register int yyi;
   (void) fprintf (yyf, "\n%06d:", yyMapToLabel (yyt));
   for (yyi = 8; yyi <= yyIndentLevel; yyi ++) (void) putc (' ', yyf);
  } else (void) putc (' ', yyf);
  yyt->yyHead.yyMark = 0;
  yyIndentLevel += 2;

  switch (yyt->Kind) {
case kSpecification: yWriteSpecification (yyt); yyIndentSelector ("GlobalParagraphSeq"); yyt = yyt->Specification.GlobalParagraphSeq; break;
case kGlobalParagraphSeq: yWriteGlobalParagraphSeq (yyt); goto yyExit;
case knoGlobalParagraph: yWritenoGlobalParagraph (yyt); goto yyExit;
case kglobalParagraphs: yWriteglobalParagraphs (yyt); yyIndentSelector ("Next"); yyt = yyt->globalParagraphs.Next; break;
case kGlobalParagraph: yWriteGlobalParagraph (yyt); goto yyExit;
case kaxiomaticDef: yWriteaxiomaticDef (yyt); yyIndentSelector ("ZSchemaText"); yyt = yyt->axiomaticDef.ZSchemaText; break;
case khorizPar: yWritehorizPar (yyt); yyIndentSelector ("HorizParagraphs"); yyt = yyt->horizPar.HorizParagraphs; break;
case kgenericDef: yWritegenericDef (yyt); yyIndentSelector ("ZSchemaText"); yyt = yyt->genericDef.ZSchemaText; break;
case kschemaboxDef: yWriteschemaboxDef (yyt); yyIndentSelector ("ZSchemaText"); yyt = yyt->schemaboxDef.ZSchemaText; break;
case kHorizParagraphs: yWriteHorizParagraphs (yyt); goto yyExit;
case knoHorizParagraph: yWritenoHorizParagraph (yyt); goto yyExit;
case khorizParagraphs: yWritehorizParagraphs (yyt); yyIndentSelector ("Next"); yyt = yyt->horizParagraphs.Next; break;
case kHorizParagraph: yWriteHorizParagraph (yyt); goto yyExit;
case ktypeDef: yWritetypeDef (yyt); yyIndentSelector ("TypeDef"); yyt = yyt->typeDef.TypeDef; break;
case kglobalPredicate: yWriteglobalPredicate (yyt); yyIndentSelector ("Predicate"); yyt = yyt->globalPredicate.Predicate; break;
case kschemaDef: yWriteschemaDef (yyt); yyIndentSelector ("SchemaExp"); yyt = yyt->schemaDef.SchemaExp; break;
case kTypeDef: yWriteTypeDef (yyt); goto yyExit;
case kgivenSet: yWritegivenSet (yyt); yyIndentSelector ("VarNameSeq"); yyt = yyt->givenSet.VarNameSeq; break;
case kfreeType: yWritefreeType (yyt); yyIndentSelector ("BranchSeq"); yyt = yyt->freeType.BranchSeq; break;
case ktypeDef1: yWritetypeDef1 (yyt); yyIndentSelector ("Expression"); yyt = yyt->typeDef1.Expression; break;
case ktypeDefPregen: yWritetypeDefPregen (yyt); yyIndentSelector ("Expression"); yyt = yyt->typeDefPregen.Expression; break;
case ktypeDefIngen: yWritetypeDefIngen (yyt); yyIndentSelector ("Expression"); yyt = yyt->typeDefIngen.Expression; break;
case kNameFormals: yWriteNameFormals (yyt); yyIndentSelector ("VarName"); yyt = yyt->NameFormals.VarName; break;
case knoFormals: yWritenoFormals (yyt); yyIndentSelector ("VarName"); yyt = yyt->noFormals.VarName; break;
case knameFormals: yWritenameFormals (yyt); yyIndentSelector ("ZFormalParams"); yyt = yyt->nameFormals.ZFormalParams; break;
case kBranchSeq: yWriteBranchSeq (yyt); goto yyExit;
case knoBranch: yWritenoBranch (yyt); goto yyExit;
case kbranch: yWritebranch (yyt); yyIndentSelector ("Next"); yyt = yyt->branch.Next; break;
case kZFormalParams: yWriteZFormalParams (yyt); goto yyExit;
case knoFormalParams: yWritenoFormalParams (yyt); goto yyExit;
case kformalParams: yWriteformalParams (yyt); yyIndentSelector ("VarNameSeq"); yyt = yyt->formalParams.VarNameSeq; break;
case kZBranch: yWriteZBranch (yyt); goto yyExit;
case ksimpleBranch: yWritesimpleBranch (yyt); yyIndentSelector ("VarName"); yyt = yyt->simpleBranch.VarName; break;
case kcompoundBranch: yWritecompoundBranch (yyt); yyIndentSelector ("Expression"); yyt = yyt->compoundBranch.Expression; break;
case kSchemaExp: yWriteSchemaExp (yyt); goto yyExit;
case kschemaSimple: yWriteschemaSimple (yyt); yyIndentSelector ("ZSchemaText"); yyt = yyt->schemaSimple.ZSchemaText; break;
case kschemaDes: yWriteschemaDes (yyt); yyIndentSelector ("Designator"); yyt = yyt->schemaDes.Designator; break;
case kschemaPreop: yWriteschemaPreop (yyt); yyIndentSelector ("SchemaExp"); yyt = yyt->schemaPreop.SchemaExp; break;
case kschemaCons: yWriteschemaCons (yyt); yyIndentSelector ("Rop"); yyt = yyt->schemaCons.Rop; break;
case kschemaHide: yWriteschemaHide (yyt); yyIndentSelector ("VarNameSeq"); yyt = yyt->schemaHide.VarNameSeq; break;
case kschemaQuant: yWriteschemaQuant (yyt); yyIndentSelector ("SchemaExp"); yyt = yyt->schemaQuant.SchemaExp; break;
case kschemaComp: yWriteschemaComp (yyt); yyIndentSelector ("Rop"); yyt = yyt->schemaComp.Rop; break;
case kschemaProject: yWriteschemaProject (yyt); yyIndentSelector ("Rop"); yyt = yyt->schemaProject.Rop; break;
case kschemaPipe: yWriteschemaPipe (yyt); yyIndentSelector ("Rop"); yyt = yyt->schemaPipe.Rop; break;
case kschemaParen: yWriteschemaParen (yyt); yyIndentSelector ("SchemaExp"); yyt = yyt->schemaParen.SchemaExp; break;
case kDesignator: yWriteDesignator (yyt); yyIndentSelector ("RenameSeq"); yyt = yyt->Designator.RenameSeq; break;
case kVarNameSeq: yWriteVarNameSeq (yyt); goto yyExit;
case knoVarName: yWritenoVarName (yyt); goto yyExit;
case kvarNames: yWritevarNames (yyt); yyIndentSelector ("Next"); yyt = yyt->varNames.Next; break;
case kExpressionSeq: yWriteExpressionSeq (yyt); goto yyExit;
case knoExpSeq: yWritenoExpSeq (yyt); goto yyExit;
case kexpSeq: yWriteexpSeq (yyt); yyIndentSelector ("Next"); yyt = yyt->expSeq.Next; break;
case kRenameSeq: yWriteRenameSeq (yyt); goto yyExit;
case knoRename: yWritenoRename (yyt); goto yyExit;
case krenames: yWriterenames (yyt); yyIndentSelector ("Next"); yyt = yyt->renames.Next; break;
case kVarRename: yWriteVarRename (yyt); yyIndentSelector ("Old"); yyt = yyt->VarRename.Old; break;
case kZSchemaText: yWriteZSchemaText (yyt); yyIndentSelector ("Predicate"); yyt = yyt->ZSchemaText.Predicate; break;
case kDeclaration: yWriteDeclaration (yyt); goto yyExit;
case knoDecl: yWritenoDecl (yyt); goto yyExit;
case kdecl: yWritedecl (yyt); yyIndentSelector ("Next"); yyt = yyt->decl.Next; break;
case kBasicDecl: yWriteBasicDecl (yyt); goto yyExit;
case kcolonDecl: yWritecolonDecl (yyt); yyIndentSelector ("Expression"); yyt = yyt->colonDecl.Expression; break;
case kschemaRef: yWriteschemaRef (yyt); yyIndentSelector ("Designator"); yyt = yyt->schemaRef.Designator; break;
case kPredicate: yWritePredicate (yyt); goto yyExit;
case knoPred: yWritenoPred (yyt); goto yyExit;
case kpredNegate: yWritepredNegate (yyt); yyIndentSelector ("Predicate"); yyt = yyt->predNegate.Predicate; break;
case kpredInfixRelSeq: yWritepredInfixRelSeq (yyt); yyIndentSelector ("PredInfixRelSeq"); yyt = yyt->predInfixRelSeq.PredInfixRelSeq; break;
case kpredTrueOrFalse: yWritepredTrueOrFalse (yyt); goto yyExit;
case kpredSchemaRef: yWritepredSchemaRef (yyt); yyIndentSelector ("Designator"); yyt = yyt->predSchemaRef.Designator; break;
case kpredPreRel: yWritepredPreRel (yyt); yyIndentSelector ("Expression"); yyt = yyt->predPreRel.Expression; break;
case kpredCons: yWritepredCons (yyt); yyIndentSelector ("Rpred"); yyt = yyt->predCons.Rpred; break;
case kpredQuant: yWritepredQuant (yyt); yyIndentSelector ("Predicate"); yyt = yyt->predQuant.Predicate; break;
case kpredLet: yWritepredLet (yyt); yyIndentSelector ("Predicate"); yyt = yyt->predLet.Predicate; break;
case kpredParen: yWritepredParen (yyt); yyIndentSelector ("Predicate"); yyt = yyt->predParen.Predicate; break;
case kPredInfixRelSeq: yWritePredInfixRelSeq (yyt); goto yyExit;
case knoInfixRel: yWritenoInfixRel (yyt); goto yyExit;
case kinfixRels: yWriteinfixRels (yyt); yyIndentSelector ("Next"); yyt = yyt->infixRels.Next; break;
case kPredInfixRel: yWritePredInfixRel (yyt); yyIndentSelector ("Rexp"); yyt = yyt->PredInfixRel.Rexp; break;
case kInfixRel: yWriteInfixRel (yyt); yyIndentSelector ("Decoration"); yyt = yyt->InfixRel.Decoration; break;
case kExpression: yWriteExpression (yyt); goto yyExit;
case knoExp: yWritenoExp (yyt); goto yyExit;
case kexpBinaryGen: yWriteexpBinaryGen (yyt); yyIndentSelector ("rexp"); yyt = yyt->expBinaryGen.rexp; break;
case kexpBinaryFun: yWriteexpBinaryFun (yyt); yyIndentSelector ("rexp"); yyt = yyt->expBinaryFun.rexp; break;
case kexpLiteral: yWriteexpLiteral (yyt); goto yyExit;
case kexpOpname: yWriteexpOpname (yyt); yyIndentSelector ("ExpressionSeq"); yyt = yyt->expOpname.ExpressionSeq; break;
case kexpSetElab: yWriteexpSetElab (yyt); yyIndentSelector ("ExpressionSeq"); yyt = yyt->expSetElab.ExpressionSeq; break;
case kexpSeqElab: yWriteexpSeqElab (yyt); yyIndentSelector ("ExpressionSeq"); yyt = yyt->expSeqElab.ExpressionSeq; break;
case kexpBagElab: yWriteexpBagElab (yyt); yyIndentSelector ("ExpressionSeq"); yyt = yyt->expBagElab.ExpressionSeq; break;
case kexpSetComp: yWriteexpSetComp (yyt); yyIndentSelector ("Expression"); yyt = yyt->expSetComp.Expression; break;
case kexpPowerSet: yWriteexpPowerSet (yyt); yyIndentSelector ("Expression"); yyt = yyt->expPowerSet.Expression; break;
case kexpPreGen: yWriteexpPreGen (yyt); yyIndentSelector ("Expression"); yyt = yyt->expPreGen.Expression; break;
case kexpPostFun: yWriteexpPostFun (yyt); yyIndentSelector ("Decoration"); yyt = yyt->expPostFun.Decoration; break;
case kexpIter: yWriteexpIter (yyt); yyIndentSelector ("exp2"); yyt = yyt->expIter.exp2; break;
case kexpTuple: yWriteexpTuple (yyt); yyIndentSelector ("ExpressionSeq"); yyt = yyt->expTuple.ExpressionSeq; break;
case kexpCartProd: yWriteexpCartProd (yyt); yyIndentSelector ("ExpressionSeq"); yyt = yyt->expCartProd.ExpressionSeq; break;
case kexpTheta: yWriteexpTheta (yyt); yyIndentSelector ("RenameSeq"); yyt = yyt->expTheta.RenameSeq; break;
case kexpSelectVar: yWriteexpSelectVar (yyt); yyIndentSelector ("VarName"); yyt = yyt->expSelectVar.VarName; break;
case kexpFnApp: yWriteexpFnApp (yyt); yyIndentSelector ("Params"); yyt = yyt->expFnApp.Params; break;
case kexpMu: yWriteexpMu (yyt); yyIndentSelector ("Expression"); yyt = yyt->expMu.Expression; break;
case kexpLambda: yWriteexpLambda (yyt); yyIndentSelector ("Expression"); yyt = yyt->expLambda.Expression; break;
case kexpLet: yWriteexpLet (yyt); yyIndentSelector ("Expression"); yyt = yyt->expLet.Expression; break;
case kexpIf: yWriteexpIf (yyt); yyIndentSelector ("Exp2"); yyt = yyt->expIf.Exp2; break;
case kexpImage: yWriteexpImage (yyt); yyIndentSelector ("Decoration"); yyt = yyt->expImage.Decoration; break;
case kexpDesignator: yWriteexpDesignator (yyt); yyIndentSelector ("Designator"); yyt = yyt->expDesignator.Designator; break;
case kexpParen: yWriteexpParen (yyt); yyIndentSelector ("Expression"); yyt = yyt->expParen.Expression; break;
case kLetDefSeq: yWriteLetDefSeq (yyt); goto yyExit;
case knoLetDef: yWritenoLetDef (yyt); goto yyExit;
case kletDefs: yWriteletDefs (yyt); yyIndentSelector ("Next"); yyt = yyt->letDefs.Next; break;
case kLetDef: yWriteLetDef (yyt); yyIndentSelector ("Expression"); yyt = yyt->LetDef.Expression; break;
case kVarName: yWriteVarName (yyt); yyIndentSelector ("Decoration"); yyt = yyt->VarName.Decoration; break;
case kZId: yWriteZId (yyt); yyIndentSelector ("Decoration"); yyt = yyt->ZId.Decoration; break;
case kOpname: yWriteOpname (yyt); yyIndentSelector ("Decoration"); yyt = yyt->Opname.Decoration; break;
case kDecoration: yWriteDecoration (yyt); goto yyExit;
case knoDecoration: yWritenoDecoration (yyt); goto yyExit;
case kdecoration: yWritedecoration (yyt); yyIndentSelector ("Next"); yyt = yyt->decoration.Next; break;
case kZName: yWriteZName (yyt); goto yyExit;
  default: goto yyExit;
  }
 }
yyExit:
 yyIndentLevel = yyLevel;
}

static tIdent yyKindToIdent [116 + 1];
static bool yyIsInitialized = false;

static short yyMapToKind
# if defined __STDC__ | defined __cplusplus
 (char * yys)
# else
 (yys) char * yys;
# endif
{
 register int yyk;
 register tIdent yyi = MakeIdent ((tString) yys, strlen (yys));
 for (yyk = 0; yyk <= 116; yyk ++) {
  if (yyKindToIdent [yyk] == yyi) return yyk;
 }
 return 0;
}

static void yyReadNl () { (void) fscanf (yyf, "\n"); }

static tIdent yyReadIdent ()
{
 char yys [256];
 (void) fscanf (yyf, "%s", yys);
 return MakeIdent ((tString) yys, strlen (yys));
}

static void yyReadHex
# if defined __STDC__ | defined __cplusplus
 (unsigned char * yyx, int yysize)
# else
 (yyx, yysize) unsigned char * yyx; int yysize;
# endif
{
 register int yyi; int yyk;
 for (yyi = 0; yyi < yysize; yyi ++) { (void) fscanf (yyf, "%x ", & yyk); yyx [yyi] = yyk; }
}

static void yySkip () { (void) fscanf (yyf, " %*s =%*c"); }

static void yyReadZTree
# if defined __STDC__ | defined __cplusplus
 (yyPtrtTree yyt)
# else
 (yyt) yyPtrtTree yyt;
# endif
{
 static ZTree_tLabel yyLabel;
 static ZTree_tKind yyKind;
 static char yys [256];
 for (;;) {
  switch (getc (yyf)) {
  case '^': (void) fscanf (yyf, "%hd\n", & yyLabel); * yyt = yyMapToTree (yyLabel); return;
  case '\n': case '0': (void) fscanf (yyf, "%hd%*c %s\n", & yyLabel, yys);
   yyKind = yyMapToKind (yys); * yyt = MakeZTree (yyKind);
   if (yyLabel != yyMapToLabel (* yyt)) { (void) fputs ("ZTree: error in ReadZTree\n", stderr); ZTree_Exit (); } break;
  default: ;
   (void) fscanf (yyf, "%s", yys);
   yyKind = yyMapToKind (yys);
   if (yyKind == 0) { * yyt = NoZTree; return; }
   * yyt = MakeZTree (yyKind);
  }

  switch (yyKind) {
case kSpecification:
yySkip (); yyt = & ((* yyt)->Specification.GlobalParagraphSeq); break;
case kGlobalParagraphSeq:
return;
case knoGlobalParagraph:
return;
case kglobalParagraphs:
yySkip (); readtZTree (& ((* yyt)->globalParagraphs.GlobalParagraph))
yySkip (); yyt = & ((* yyt)->globalParagraphs.Next); break;
case kGlobalParagraph:
return;
case kaxiomaticDef:
yySkip (); yyt = & ((* yyt)->axiomaticDef.ZSchemaText); break;
case khorizPar:
yySkip (); yyt = & ((* yyt)->horizPar.HorizParagraphs); break;
case kgenericDef:
yySkip (); readtZTree (& ((* yyt)->genericDef.ZFormalParams))
yySkip (); yyt = & ((* yyt)->genericDef.ZSchemaText); break;
case kschemaboxDef:
yySkip (); readtZTree (& ((* yyt)->schemaboxDef.ZName))
yySkip (); readtZTree (& ((* yyt)->schemaboxDef.ZFormalParams))
yySkip (); yyt = & ((* yyt)->schemaboxDef.ZSchemaText); break;
case kHorizParagraphs:
return;
case knoHorizParagraph:
return;
case khorizParagraphs:
yySkip (); readtZTree (& ((* yyt)->horizParagraphs.HorizParagraph))
yySkip (); yyt = & ((* yyt)->horizParagraphs.Next); break;
case kHorizParagraph:
return;
case ktypeDef:
yySkip (); yyt = & ((* yyt)->typeDef.TypeDef); break;
case kglobalPredicate:
yySkip (); yyt = & ((* yyt)->globalPredicate.Predicate); break;
case kschemaDef:
yySkip (); readtZTree (& ((* yyt)->schemaDef.NameFormals))
yySkip (); yyt = & ((* yyt)->schemaDef.SchemaExp); break;
case kTypeDef:
return;
case kgivenSet:
yySkip (); yyt = & ((* yyt)->givenSet.VarNameSeq); break;
case kfreeType:
yySkip (); readtZTree (& ((* yyt)->freeType.VarName))
yySkip (); yyt = & ((* yyt)->freeType.BranchSeq); break;
case ktypeDef1:
yySkip (); readtZTree (& ((* yyt)->typeDef1.NameFormals))
yySkip (); yyt = & ((* yyt)->typeDef1.Expression); break;
case ktypeDefPregen:
yySkip (); readtIdPos ((* yyt)->typeDefPregen.PreGen) yyReadNl ();
yySkip (); readtZTree (& ((* yyt)->typeDefPregen.Decoration))
yySkip (); readtZTree (& ((* yyt)->typeDefPregen.VarName))
yySkip (); yyt = & ((* yyt)->typeDefPregen.Expression); break;
case ktypeDefIngen:
yySkip (); readtZTree (& ((* yyt)->typeDefIngen.Var1))
yySkip (); readtIdPos ((* yyt)->typeDefIngen.InGen) yyReadNl ();
yySkip (); readtZTree (& ((* yyt)->typeDefIngen.Decoration))
yySkip (); readtZTree (& ((* yyt)->typeDefIngen.Var2))
yySkip (); yyt = & ((* yyt)->typeDefIngen.Expression); break;
case kNameFormals:
yySkip (); yyt = & ((* yyt)->NameFormals.VarName); break;
case knoFormals:
yySkip (); yyt = & ((* yyt)->noFormals.VarName); break;
case knameFormals:
yySkip (); readtZTree (& ((* yyt)->nameFormals.VarName))
yySkip (); yyt = & ((* yyt)->nameFormals.ZFormalParams); break;
case kBranchSeq:
return;
case knoBranch:
return;
case kbranch:
yySkip (); readtZTree (& ((* yyt)->branch.ZBranch))
yySkip (); yyt = & ((* yyt)->branch.Next); break;
case kZFormalParams:
return;
case knoFormalParams:
return;
case kformalParams:
yySkip (); yyt = & ((* yyt)->formalParams.VarNameSeq); break;
case kZBranch:
return;
case ksimpleBranch:
yySkip (); yyt = & ((* yyt)->simpleBranch.VarName); break;
case kcompoundBranch:
yySkip (); readtZTree (& ((* yyt)->compoundBranch.VarName))
yySkip (); yyt = & ((* yyt)->compoundBranch.Expression); break;
case kSchemaExp:
return;
case kschemaSimple:
yySkip (); yyt = & ((* yyt)->schemaSimple.ZSchemaText); break;
case kschemaDes:
yySkip (); yyt = & ((* yyt)->schemaDes.Designator); break;
case kschemaPreop:
yySkip (); readtIdPos ((* yyt)->schemaPreop.PreOp) yyReadNl ();
yySkip (); yyt = & ((* yyt)->schemaPreop.SchemaExp); break;
case kschemaCons:
yySkip (); readtZTree (& ((* yyt)->schemaCons.Lop))
yySkip (); readtIdPos ((* yyt)->schemaCons.SchemaOp) yyReadNl ();
yySkip (); yyt = & ((* yyt)->schemaCons.Rop); break;
case kschemaHide:
yySkip (); readtZTree (& ((* yyt)->schemaHide.SchemaExp))
yySkip (); yyt = & ((* yyt)->schemaHide.VarNameSeq); break;
case kschemaQuant:
yySkip (); readtIdPos ((* yyt)->schemaQuant.LogQuant) yyReadNl ();
yySkip (); readtZTree (& ((* yyt)->schemaQuant.ZSchemaText))
yySkip (); yyt = & ((* yyt)->schemaQuant.SchemaExp); break;
case kschemaComp:
yySkip (); readtZTree (& ((* yyt)->schemaComp.Lop))
yySkip (); yyt = & ((* yyt)->schemaComp.Rop); break;
case kschemaProject:
yySkip (); readtZTree (& ((* yyt)->schemaProject.Lop))
yySkip (); yyt = & ((* yyt)->schemaProject.Rop); break;
case kschemaPipe:
yySkip (); readtZTree (& ((* yyt)->schemaPipe.Lop))
yySkip (); yyt = & ((* yyt)->schemaPipe.Rop); break;
case kschemaParen:
yySkip (); yyt = & ((* yyt)->schemaParen.SchemaExp); break;
case kDesignator:
yySkip (); readtZTree (& ((* yyt)->Designator.ZName))
yySkip (); readtZTree (& ((* yyt)->Designator.Decoration))
yySkip (); readtZTree (& ((* yyt)->Designator.ExpressionSeq))
yySkip (); readbool ((* yyt)->Designator.IsSchemaRef) yyReadNl ();
yySkip (); yyt = & ((* yyt)->Designator.RenameSeq); break;
case kVarNameSeq:
return;
case knoVarName:
return;
case kvarNames:
yySkip (); readtZTree (& ((* yyt)->varNames.VarName))
yySkip (); yyt = & ((* yyt)->varNames.Next); break;
case kExpressionSeq:
return;
case knoExpSeq:
return;
case kexpSeq:
yySkip (); readtZTree (& ((* yyt)->expSeq.Expression))
yySkip (); yyt = & ((* yyt)->expSeq.Next); break;
case kRenameSeq:
return;
case knoRename:
return;
case krenames:
yySkip (); readtZTree (& ((* yyt)->renames.VarRename))
yySkip (); yyt = & ((* yyt)->renames.Next); break;
case kVarRename:
yySkip (); readtZTree (& ((* yyt)->VarRename.New))
yySkip (); yyt = & ((* yyt)->VarRename.Old); break;
case kZSchemaText:
yySkip (); readtZTree (& ((* yyt)->ZSchemaText.Declaration))
yySkip (); yyt = & ((* yyt)->ZSchemaText.Predicate); break;
case kDeclaration:
return;
case knoDecl:
return;
case kdecl:
yySkip (); readtZTree (& ((* yyt)->decl.BasicDecl))
yySkip (); yyt = & ((* yyt)->decl.Next); break;
case kBasicDecl:
return;
case kcolonDecl:
yySkip (); readtZTree (& ((* yyt)->colonDecl.VarNameSeq))
yySkip (); yyt = & ((* yyt)->colonDecl.Expression); break;
case kschemaRef:
yySkip (); yyt = & ((* yyt)->schemaRef.Designator); break;
case kPredicate:
return;
case knoPred:
return;
case kpredNegate:
yySkip (); yyt = & ((* yyt)->predNegate.Predicate); break;
case kpredInfixRelSeq:
yySkip (); yyt = & ((* yyt)->predInfixRelSeq.PredInfixRelSeq); break;
case kpredTrueOrFalse:
yySkip (); readtIdPos ((* yyt)->predTrueOrFalse.TrueFalse) yyReadNl ();
return;
case kpredSchemaRef:
yySkip (); readtIdPos ((* yyt)->predSchemaRef.PredOrPre) yyReadNl ();
yySkip (); yyt = & ((* yyt)->predSchemaRef.Designator); break;
case kpredPreRel:
yySkip (); readtIdPos ((* yyt)->predPreRel.PreRel) yyReadNl ();
yySkip (); readtZTree (& ((* yyt)->predPreRel.Decoration))
yySkip (); yyt = & ((* yyt)->predPreRel.Expression); break;
case kpredCons:
yySkip (); readtZTree (& ((* yyt)->predCons.Lpred))
yySkip (); readtIdPos ((* yyt)->predCons.LogOp) yyReadNl ();
yySkip (); yyt = & ((* yyt)->predCons.Rpred); break;
case kpredQuant:
yySkip (); readtIdPos ((* yyt)->predQuant.LogQuant) yyReadNl ();
yySkip (); readtZTree (& ((* yyt)->predQuant.ZSchemaText))
yySkip (); yyt = & ((* yyt)->predQuant.Predicate); break;
case kpredLet:
yySkip (); readtZTree (& ((* yyt)->predLet.LetDefSeq))
yySkip (); yyt = & ((* yyt)->predLet.Predicate); break;
case kpredParen:
yySkip (); yyt = & ((* yyt)->predParen.Predicate); break;
case kPredInfixRelSeq:
return;
case knoInfixRel:
return;
case kinfixRels:
yySkip (); readtZTree (& ((* yyt)->infixRels.PredInfixRel))
yySkip (); yyt = & ((* yyt)->infixRels.Next); break;
case kPredInfixRel:
yySkip (); readtZTree (& ((* yyt)->PredInfixRel.Lexp))
yySkip (); readtZTree (& ((* yyt)->PredInfixRel.InfixRel))
yySkip (); yyt = & ((* yyt)->PredInfixRel.Rexp); break;
case kInfixRel:
yySkip (); readtIdPos ((* yyt)->InfixRel.InRel) yyReadNl ();
yySkip (); yyt = & ((* yyt)->InfixRel.Decoration); break;
case kExpression:
return;
case knoExp:
return;
case kexpBinaryGen:
yySkip (); readtZTree (& ((* yyt)->expBinaryGen.lexp))
yySkip (); readtIdPos ((* yyt)->expBinaryGen.InGen) yyReadNl ();
yySkip (); readtZTree (& ((* yyt)->expBinaryGen.Decoration))
yySkip (); yyt = & ((* yyt)->expBinaryGen.rexp); break;
case kexpBinaryFun:
yySkip (); readtZTree (& ((* yyt)->expBinaryFun.lexp))
yySkip (); readtIdPos ((* yyt)->expBinaryFun.InFun) yyReadNl ();
yySkip (); readtZTree (& ((* yyt)->expBinaryFun.Decoration))
yySkip (); yyt = & ((* yyt)->expBinaryFun.rexp); break;
case kexpLiteral:
yySkip (); readtIdPos ((* yyt)->expLiteral.Literal) yyReadNl ();
return;
case kexpOpname:
yySkip (); readtZTree (& ((* yyt)->expOpname.VarName))
yySkip (); yyt = & ((* yyt)->expOpname.ExpressionSeq); break;
case kexpSetElab:
yySkip (); yyt = & ((* yyt)->expSetElab.ExpressionSeq); break;
case kexpSeqElab:
yySkip (); yyt = & ((* yyt)->expSeqElab.ExpressionSeq); break;
case kexpBagElab:
yySkip (); yyt = & ((* yyt)->expBagElab.ExpressionSeq); break;
case kexpSetComp:
yySkip (); readtZTree (& ((* yyt)->expSetComp.ZSchemaText))
yySkip (); yyt = & ((* yyt)->expSetComp.Expression); break;
case kexpPowerSet:
yySkip (); yyt = & ((* yyt)->expPowerSet.Expression); break;
case kexpPreGen:
yySkip (); readtIdPos ((* yyt)->expPreGen.Pregen) yyReadNl ();
yySkip (); readtZTree (& ((* yyt)->expPreGen.Decoration))
yySkip (); yyt = & ((* yyt)->expPreGen.Expression); break;
case kexpPostFun:
yySkip (); readtZTree (& ((* yyt)->expPostFun.Expression))
yySkip (); readtIdPos ((* yyt)->expPostFun.Postfun) yyReadNl ();
yySkip (); yyt = & ((* yyt)->expPostFun.Decoration); break;
case kexpIter:
yySkip (); readtZTree (& ((* yyt)->expIter.exp1))
yySkip (); yyt = & ((* yyt)->expIter.exp2); break;
case kexpTuple:
yySkip (); yyt = & ((* yyt)->expTuple.ExpressionSeq); break;
case kexpCartProd:
yySkip (); yyt = & ((* yyt)->expCartProd.ExpressionSeq); break;
case kexpTheta:
yySkip (); readtZTree (& ((* yyt)->expTheta.ZName))
yySkip (); readtZTree (& ((* yyt)->expTheta.Decoration))
yySkip (); yyt = & ((* yyt)->expTheta.RenameSeq); break;
case kexpSelectVar:
yySkip (); readtZTree (& ((* yyt)->expSelectVar.Expression))
yySkip (); yyt = & ((* yyt)->expSelectVar.VarName); break;
case kexpFnApp:
yySkip (); readtZTree (& ((* yyt)->expFnApp.FnName))
yySkip (); yyt = & ((* yyt)->expFnApp.Params); break;
case kexpMu:
yySkip (); readtZTree (& ((* yyt)->expMu.ZSchemaText))
yySkip (); yyt = & ((* yyt)->expMu.Expression); break;
case kexpLambda:
yySkip (); readtZTree (& ((* yyt)->expLambda.ZSchemaText))
yySkip (); yyt = & ((* yyt)->expLambda.Expression); break;
case kexpLet:
yySkip (); readtZTree (& ((* yyt)->expLet.LetDefSeq))
yySkip (); yyt = & ((* yyt)->expLet.Expression); break;
case kexpIf:
yySkip (); readtZTree (& ((* yyt)->expIf.Predicate))
yySkip (); readtZTree (& ((* yyt)->expIf.Exp1))
yySkip (); yyt = & ((* yyt)->expIf.Exp2); break;
case kexpImage:
yySkip (); readtZTree (& ((* yyt)->expImage.Exp1))
yySkip (); readtZTree (& ((* yyt)->expImage.Exp2))
yySkip (); readtIdPos ((* yyt)->expImage.Image) yyReadNl ();
yySkip (); yyt = & ((* yyt)->expImage.Decoration); break;
case kexpDesignator:
yySkip (); yyt = & ((* yyt)->expDesignator.Designator); break;
case kexpParen:
yySkip (); yyt = & ((* yyt)->expParen.Expression); break;
case kLetDefSeq:
return;
case knoLetDef:
return;
case kletDefs:
yySkip (); readtZTree (& ((* yyt)->letDefs.LetDef))
yySkip (); yyt = & ((* yyt)->letDefs.Next); break;
case kLetDef:
yySkip (); readtZTree (& ((* yyt)->LetDef.VarName))
yySkip (); yyt = & ((* yyt)->LetDef.Expression); break;
case kVarName:
yySkip (); readtIdPos ((* yyt)->VarName.Ident) yyReadNl ();
yySkip (); yyt = & ((* yyt)->VarName.Decoration); break;
case kZId:
yySkip (); readtIdPos ((* yyt)->ZId.Ident) yyReadNl ();
yySkip (); yyt = & ((* yyt)->ZId.Decoration); break;
case kOpname:
yySkip (); readtIdPos ((* yyt)->Opname.Ident) yyReadNl ();
yySkip (); yyt = & ((* yyt)->Opname.Decoration); break;
case kDecoration:
return;
case knoDecoration:
return;
case kdecoration:
yySkip (); readtIdPos ((* yyt)->decoration.Stroke) yyReadNl ();
yySkip (); yyt = & ((* yyt)->decoration.Next); break;
case kZName:
yySkip (); readtIdPos ((* yyt)->ZName.Ident) yyReadNl ();
return;
  default: return;
  }
 }
}

tZTree ReadZTree
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf)
# else
 (yyyf) FILE * yyyf;
# endif
{
 tZTree yyt;
 yyf = yyyf;
 if (yyRecursionLevel ++ == 0) yyLabelCount = 0;
 if (! yyIsInitialized) {
  register int yyi;
  for (yyi = 0; yyi <= 116; yyi ++)
   yyKindToIdent [yyi] = MakeIdent ((tString) ZTree_NodeName [yyi], strlen (ZTree_NodeName [yyi]));
  yyIsInitialized = true;
 }
 yyReadZTree (& yyt);
 yyRecursionLevel --;
 return yyt;
}

# define yyNil	0374
# define yyNoLabel	0375
# define yyLabelDef	0376
# define yyLabelUse	0377

static void yyPut
# if defined __STDC__ | defined __cplusplus
 (char * yyx, int yysize)
# else
 (yyx, yysize) char * yyx; int yysize;
# endif
{ (void) fwrite (yyx, 1, yysize, yyf); }

static void yyPutIdent
# if defined __STDC__ | defined __cplusplus
 (tIdent yyi)
# else
 (yyi) tIdent yyi;
# endif
{
 char yys [256];
 GetString (yyi, (tString) yys);
 (void) fprintf (yyf, "%s\n", yys);
}

static void yyPutZTree
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 static ZTree_tLabel yyLabel;
 for (;;) {
  if (yyt == NoZTree) {
   (void) putc (yyNil, yyf); return;
  } else if (yyt->yyHead.yyMark == 0) {
   (void) putc (yyLabelUse, yyf); yyLabel = yyMapToLabel (yyt); yyPut ((char *) & yyLabel, sizeof (yyLabel)); return;
  } else if (yyt->yyHead.yyMark > 1) {
   (void) putc (yyLabelDef, yyf); yyLabel = yyMapToLabel (yyt); yyPut ((char *) & yyLabel, sizeof (yyLabel));
   (void) putc ((char) yyt->Kind, yyf);
  } else {
   (void) putc ((char) yyt->Kind, yyf);
  }
  yyt->yyHead.yyMark = 0;

  switch (yyt->Kind) {
case kSpecification:
yyt = yyt->Specification.GlobalParagraphSeq; break;
case kGlobalParagraphSeq:
return;
case knoGlobalParagraph:
return;
case kglobalParagraphs:
puttZTree (yyt->globalParagraphs.GlobalParagraph)
yyt = yyt->globalParagraphs.Next; break;
case kGlobalParagraph:
return;
case kaxiomaticDef:
yyt = yyt->axiomaticDef.ZSchemaText; break;
case khorizPar:
yyt = yyt->horizPar.HorizParagraphs; break;
case kgenericDef:
puttZTree (yyt->genericDef.ZFormalParams)
yyt = yyt->genericDef.ZSchemaText; break;
case kschemaboxDef:
puttZTree (yyt->schemaboxDef.ZName)
puttZTree (yyt->schemaboxDef.ZFormalParams)
yyt = yyt->schemaboxDef.ZSchemaText; break;
case kHorizParagraphs:
return;
case knoHorizParagraph:
return;
case khorizParagraphs:
puttZTree (yyt->horizParagraphs.HorizParagraph)
yyt = yyt->horizParagraphs.Next; break;
case kHorizParagraph:
return;
case ktypeDef:
yyt = yyt->typeDef.TypeDef; break;
case kglobalPredicate:
yyt = yyt->globalPredicate.Predicate; break;
case kschemaDef:
puttZTree (yyt->schemaDef.NameFormals)
yyt = yyt->schemaDef.SchemaExp; break;
case kTypeDef:
return;
case kgivenSet:
yyt = yyt->givenSet.VarNameSeq; break;
case kfreeType:
puttZTree (yyt->freeType.VarName)
yyt = yyt->freeType.BranchSeq; break;
case ktypeDef1:
puttZTree (yyt->typeDef1.NameFormals)
yyt = yyt->typeDef1.Expression; break;
case ktypeDefPregen:
puttIdPos (yyt->typeDefPregen.PreGen)
puttZTree (yyt->typeDefPregen.Decoration)
puttZTree (yyt->typeDefPregen.VarName)
yyt = yyt->typeDefPregen.Expression; break;
case ktypeDefIngen:
puttZTree (yyt->typeDefIngen.Var1)
puttIdPos (yyt->typeDefIngen.InGen)
puttZTree (yyt->typeDefIngen.Decoration)
puttZTree (yyt->typeDefIngen.Var2)
yyt = yyt->typeDefIngen.Expression; break;
case kNameFormals:
yyt = yyt->NameFormals.VarName; break;
case knoFormals:
yyt = yyt->noFormals.VarName; break;
case knameFormals:
puttZTree (yyt->nameFormals.VarName)
yyt = yyt->nameFormals.ZFormalParams; break;
case kBranchSeq:
return;
case knoBranch:
return;
case kbranch:
puttZTree (yyt->branch.ZBranch)
yyt = yyt->branch.Next; break;
case kZFormalParams:
return;
case knoFormalParams:
return;
case kformalParams:
yyt = yyt->formalParams.VarNameSeq; break;
case kZBranch:
return;
case ksimpleBranch:
yyt = yyt->simpleBranch.VarName; break;
case kcompoundBranch:
puttZTree (yyt->compoundBranch.VarName)
yyt = yyt->compoundBranch.Expression; break;
case kSchemaExp:
return;
case kschemaSimple:
yyt = yyt->schemaSimple.ZSchemaText; break;
case kschemaDes:
yyt = yyt->schemaDes.Designator; break;
case kschemaPreop:
puttIdPos (yyt->schemaPreop.PreOp)
yyt = yyt->schemaPreop.SchemaExp; break;
case kschemaCons:
puttZTree (yyt->schemaCons.Lop)
puttIdPos (yyt->schemaCons.SchemaOp)
yyt = yyt->schemaCons.Rop; break;
case kschemaHide:
puttZTree (yyt->schemaHide.SchemaExp)
yyt = yyt->schemaHide.VarNameSeq; break;
case kschemaQuant:
puttIdPos (yyt->schemaQuant.LogQuant)
puttZTree (yyt->schemaQuant.ZSchemaText)
yyt = yyt->schemaQuant.SchemaExp; break;
case kschemaComp:
puttZTree (yyt->schemaComp.Lop)
yyt = yyt->schemaComp.Rop; break;
case kschemaProject:
puttZTree (yyt->schemaProject.Lop)
yyt = yyt->schemaProject.Rop; break;
case kschemaPipe:
puttZTree (yyt->schemaPipe.Lop)
yyt = yyt->schemaPipe.Rop; break;
case kschemaParen:
yyt = yyt->schemaParen.SchemaExp; break;
case kDesignator:
puttZTree (yyt->Designator.ZName)
puttZTree (yyt->Designator.Decoration)
puttZTree (yyt->Designator.ExpressionSeq)
putbool (yyt->Designator.IsSchemaRef)
yyt = yyt->Designator.RenameSeq; break;
case kVarNameSeq:
return;
case knoVarName:
return;
case kvarNames:
puttZTree (yyt->varNames.VarName)
yyt = yyt->varNames.Next; break;
case kExpressionSeq:
return;
case knoExpSeq:
return;
case kexpSeq:
puttZTree (yyt->expSeq.Expression)
yyt = yyt->expSeq.Next; break;
case kRenameSeq:
return;
case knoRename:
return;
case krenames:
puttZTree (yyt->renames.VarRename)
yyt = yyt->renames.Next; break;
case kVarRename:
puttZTree (yyt->VarRename.New)
yyt = yyt->VarRename.Old; break;
case kZSchemaText:
puttZTree (yyt->ZSchemaText.Declaration)
yyt = yyt->ZSchemaText.Predicate; break;
case kDeclaration:
return;
case knoDecl:
return;
case kdecl:
puttZTree (yyt->decl.BasicDecl)
yyt = yyt->decl.Next; break;
case kBasicDecl:
return;
case kcolonDecl:
puttZTree (yyt->colonDecl.VarNameSeq)
yyt = yyt->colonDecl.Expression; break;
case kschemaRef:
yyt = yyt->schemaRef.Designator; break;
case kPredicate:
return;
case knoPred:
return;
case kpredNegate:
yyt = yyt->predNegate.Predicate; break;
case kpredInfixRelSeq:
yyt = yyt->predInfixRelSeq.PredInfixRelSeq; break;
case kpredTrueOrFalse:
puttIdPos (yyt->predTrueOrFalse.TrueFalse)
return;
case kpredSchemaRef:
puttIdPos (yyt->predSchemaRef.PredOrPre)
yyt = yyt->predSchemaRef.Designator; break;
case kpredPreRel:
puttIdPos (yyt->predPreRel.PreRel)
puttZTree (yyt->predPreRel.Decoration)
yyt = yyt->predPreRel.Expression; break;
case kpredCons:
puttZTree (yyt->predCons.Lpred)
puttIdPos (yyt->predCons.LogOp)
yyt = yyt->predCons.Rpred; break;
case kpredQuant:
puttIdPos (yyt->predQuant.LogQuant)
puttZTree (yyt->predQuant.ZSchemaText)
yyt = yyt->predQuant.Predicate; break;
case kpredLet:
puttZTree (yyt->predLet.LetDefSeq)
yyt = yyt->predLet.Predicate; break;
case kpredParen:
yyt = yyt->predParen.Predicate; break;
case kPredInfixRelSeq:
return;
case knoInfixRel:
return;
case kinfixRels:
puttZTree (yyt->infixRels.PredInfixRel)
yyt = yyt->infixRels.Next; break;
case kPredInfixRel:
puttZTree (yyt->PredInfixRel.Lexp)
puttZTree (yyt->PredInfixRel.InfixRel)
yyt = yyt->PredInfixRel.Rexp; break;
case kInfixRel:
puttIdPos (yyt->InfixRel.InRel)
yyt = yyt->InfixRel.Decoration; break;
case kExpression:
return;
case knoExp:
return;
case kexpBinaryGen:
puttZTree (yyt->expBinaryGen.lexp)
puttIdPos (yyt->expBinaryGen.InGen)
puttZTree (yyt->expBinaryGen.Decoration)
yyt = yyt->expBinaryGen.rexp; break;
case kexpBinaryFun:
puttZTree (yyt->expBinaryFun.lexp)
puttIdPos (yyt->expBinaryFun.InFun)
puttZTree (yyt->expBinaryFun.Decoration)
yyt = yyt->expBinaryFun.rexp; break;
case kexpLiteral:
puttIdPos (yyt->expLiteral.Literal)
return;
case kexpOpname:
puttZTree (yyt->expOpname.VarName)
yyt = yyt->expOpname.ExpressionSeq; break;
case kexpSetElab:
yyt = yyt->expSetElab.ExpressionSeq; break;
case kexpSeqElab:
yyt = yyt->expSeqElab.ExpressionSeq; break;
case kexpBagElab:
yyt = yyt->expBagElab.ExpressionSeq; break;
case kexpSetComp:
puttZTree (yyt->expSetComp.ZSchemaText)
yyt = yyt->expSetComp.Expression; break;
case kexpPowerSet:
yyt = yyt->expPowerSet.Expression; break;
case kexpPreGen:
puttIdPos (yyt->expPreGen.Pregen)
puttZTree (yyt->expPreGen.Decoration)
yyt = yyt->expPreGen.Expression; break;
case kexpPostFun:
puttZTree (yyt->expPostFun.Expression)
puttIdPos (yyt->expPostFun.Postfun)
yyt = yyt->expPostFun.Decoration; break;
case kexpIter:
puttZTree (yyt->expIter.exp1)
yyt = yyt->expIter.exp2; break;
case kexpTuple:
yyt = yyt->expTuple.ExpressionSeq; break;
case kexpCartProd:
yyt = yyt->expCartProd.ExpressionSeq; break;
case kexpTheta:
puttZTree (yyt->expTheta.ZName)
puttZTree (yyt->expTheta.Decoration)
yyt = yyt->expTheta.RenameSeq; break;
case kexpSelectVar:
puttZTree (yyt->expSelectVar.Expression)
yyt = yyt->expSelectVar.VarName; break;
case kexpFnApp:
puttZTree (yyt->expFnApp.FnName)
yyt = yyt->expFnApp.Params; break;
case kexpMu:
puttZTree (yyt->expMu.ZSchemaText)
yyt = yyt->expMu.Expression; break;
case kexpLambda:
puttZTree (yyt->expLambda.ZSchemaText)
yyt = yyt->expLambda.Expression; break;
case kexpLet:
puttZTree (yyt->expLet.LetDefSeq)
yyt = yyt->expLet.Expression; break;
case kexpIf:
puttZTree (yyt->expIf.Predicate)
puttZTree (yyt->expIf.Exp1)
yyt = yyt->expIf.Exp2; break;
case kexpImage:
puttZTree (yyt->expImage.Exp1)
puttZTree (yyt->expImage.Exp2)
puttIdPos (yyt->expImage.Image)
yyt = yyt->expImage.Decoration; break;
case kexpDesignator:
yyt = yyt->expDesignator.Designator; break;
case kexpParen:
yyt = yyt->expParen.Expression; break;
case kLetDefSeq:
return;
case knoLetDef:
return;
case kletDefs:
puttZTree (yyt->letDefs.LetDef)
yyt = yyt->letDefs.Next; break;
case kLetDef:
puttZTree (yyt->LetDef.VarName)
yyt = yyt->LetDef.Expression; break;
case kVarName:
puttIdPos (yyt->VarName.Ident)
yyt = yyt->VarName.Decoration; break;
case kZId:
puttIdPos (yyt->ZId.Ident)
yyt = yyt->ZId.Decoration; break;
case kOpname:
puttIdPos (yyt->Opname.Ident)
yyt = yyt->Opname.Decoration; break;
case kDecoration:
return;
case knoDecoration:
return;
case kdecoration:
puttIdPos (yyt->decoration.Stroke)
yyt = yyt->decoration.Next; break;
case kZName:
puttIdPos (yyt->ZName.Ident)
return;
  default: return;
  }
 }
}

void PutZTree
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf, tZTree yyt)
# else
 (yyyf, yyt) FILE * yyyf; tZTree yyt;
# endif
{
 yyf = yyyf;
 if (yyRecursionLevel ++ == 0) yyLabelCount = 0;
 yyMark (yyt);
 yyPutZTree (yyt);
 yyRecursionLevel --;
}

static void yyGet
# if defined __STDC__ | defined __cplusplus
 (char * yyx, int yysize)
# else
 (yyx, yysize) char * yyx; int yysize;
# endif
{ (void) fread (yyx, 1, yysize, yyf); }

static void yyGetIdent
# if defined __STDC__ | defined __cplusplus
 (tIdent * yyi)
# else
 (yyi) tIdent * yyi;
# endif
{
 char yys [256];
 (void) fscanf (yyf, "%s%*c", yys);
 * yyi = MakeIdent ((tString) yys, strlen (yys));
}

static void yyGetZTree
# if defined __STDC__ | defined __cplusplus
 (yyPtrtTree yyt)
# else
 (yyt) yyPtrtTree yyt;
# endif
{
 static ZTree_tLabel yyLabel;
 static ZTree_tKind yyKind;
 for (;;) {
  switch (yyKind = getc (yyf)) {
  case yyNil		: * yyt = NoZTree; return;
  case yyLabelUse	: yyGet ((char *) & yyLabel, sizeof (yyLabel));
   * yyt = yyMapToTree (yyLabel); return;
  case yyLabelDef	: yyGet ((char *) & yyLabel, sizeof (yyLabel));
   yyKind = getc (yyf);   * yyt = MakeZTree (yyKind);
   if (yyLabel != yyMapToLabel (* yyt)) { (void) fputs ("ZTree: error in GetZTree\n", stderr); ZTree_Exit (); } break;
  default	: * yyt = MakeZTree (yyKind);
  }

  switch (yyKind) {
case kSpecification:
yyt = & ((* yyt)->Specification.GlobalParagraphSeq); break;
case kGlobalParagraphSeq:
return;
case knoGlobalParagraph:
return;
case kglobalParagraphs:
gettZTree (& ((* yyt)->globalParagraphs.GlobalParagraph))
yyt = & ((* yyt)->globalParagraphs.Next); break;
case kGlobalParagraph:
return;
case kaxiomaticDef:
yyt = & ((* yyt)->axiomaticDef.ZSchemaText); break;
case khorizPar:
yyt = & ((* yyt)->horizPar.HorizParagraphs); break;
case kgenericDef:
gettZTree (& ((* yyt)->genericDef.ZFormalParams))
yyt = & ((* yyt)->genericDef.ZSchemaText); break;
case kschemaboxDef:
gettZTree (& ((* yyt)->schemaboxDef.ZName))
gettZTree (& ((* yyt)->schemaboxDef.ZFormalParams))
yyt = & ((* yyt)->schemaboxDef.ZSchemaText); break;
case kHorizParagraphs:
return;
case knoHorizParagraph:
return;
case khorizParagraphs:
gettZTree (& ((* yyt)->horizParagraphs.HorizParagraph))
yyt = & ((* yyt)->horizParagraphs.Next); break;
case kHorizParagraph:
return;
case ktypeDef:
yyt = & ((* yyt)->typeDef.TypeDef); break;
case kglobalPredicate:
yyt = & ((* yyt)->globalPredicate.Predicate); break;
case kschemaDef:
gettZTree (& ((* yyt)->schemaDef.NameFormals))
yyt = & ((* yyt)->schemaDef.SchemaExp); break;
case kTypeDef:
return;
case kgivenSet:
yyt = & ((* yyt)->givenSet.VarNameSeq); break;
case kfreeType:
gettZTree (& ((* yyt)->freeType.VarName))
yyt = & ((* yyt)->freeType.BranchSeq); break;
case ktypeDef1:
gettZTree (& ((* yyt)->typeDef1.NameFormals))
yyt = & ((* yyt)->typeDef1.Expression); break;
case ktypeDefPregen:
gettIdPos ((* yyt)->typeDefPregen.PreGen)
gettZTree (& ((* yyt)->typeDefPregen.Decoration))
gettZTree (& ((* yyt)->typeDefPregen.VarName))
yyt = & ((* yyt)->typeDefPregen.Expression); break;
case ktypeDefIngen:
gettZTree (& ((* yyt)->typeDefIngen.Var1))
gettIdPos ((* yyt)->typeDefIngen.InGen)
gettZTree (& ((* yyt)->typeDefIngen.Decoration))
gettZTree (& ((* yyt)->typeDefIngen.Var2))
yyt = & ((* yyt)->typeDefIngen.Expression); break;
case kNameFormals:
yyt = & ((* yyt)->NameFormals.VarName); break;
case knoFormals:
yyt = & ((* yyt)->noFormals.VarName); break;
case knameFormals:
gettZTree (& ((* yyt)->nameFormals.VarName))
yyt = & ((* yyt)->nameFormals.ZFormalParams); break;
case kBranchSeq:
return;
case knoBranch:
return;
case kbranch:
gettZTree (& ((* yyt)->branch.ZBranch))
yyt = & ((* yyt)->branch.Next); break;
case kZFormalParams:
return;
case knoFormalParams:
return;
case kformalParams:
yyt = & ((* yyt)->formalParams.VarNameSeq); break;
case kZBranch:
return;
case ksimpleBranch:
yyt = & ((* yyt)->simpleBranch.VarName); break;
case kcompoundBranch:
gettZTree (& ((* yyt)->compoundBranch.VarName))
yyt = & ((* yyt)->compoundBranch.Expression); break;
case kSchemaExp:
return;
case kschemaSimple:
yyt = & ((* yyt)->schemaSimple.ZSchemaText); break;
case kschemaDes:
yyt = & ((* yyt)->schemaDes.Designator); break;
case kschemaPreop:
gettIdPos ((* yyt)->schemaPreop.PreOp)
yyt = & ((* yyt)->schemaPreop.SchemaExp); break;
case kschemaCons:
gettZTree (& ((* yyt)->schemaCons.Lop))
gettIdPos ((* yyt)->schemaCons.SchemaOp)
yyt = & ((* yyt)->schemaCons.Rop); break;
case kschemaHide:
gettZTree (& ((* yyt)->schemaHide.SchemaExp))
yyt = & ((* yyt)->schemaHide.VarNameSeq); break;
case kschemaQuant:
gettIdPos ((* yyt)->schemaQuant.LogQuant)
gettZTree (& ((* yyt)->schemaQuant.ZSchemaText))
yyt = & ((* yyt)->schemaQuant.SchemaExp); break;
case kschemaComp:
gettZTree (& ((* yyt)->schemaComp.Lop))
yyt = & ((* yyt)->schemaComp.Rop); break;
case kschemaProject:
gettZTree (& ((* yyt)->schemaProject.Lop))
yyt = & ((* yyt)->schemaProject.Rop); break;
case kschemaPipe:
gettZTree (& ((* yyt)->schemaPipe.Lop))
yyt = & ((* yyt)->schemaPipe.Rop); break;
case kschemaParen:
yyt = & ((* yyt)->schemaParen.SchemaExp); break;
case kDesignator:
gettZTree (& ((* yyt)->Designator.ZName))
gettZTree (& ((* yyt)->Designator.Decoration))
gettZTree (& ((* yyt)->Designator.ExpressionSeq))
getbool ((* yyt)->Designator.IsSchemaRef)
yyt = & ((* yyt)->Designator.RenameSeq); break;
case kVarNameSeq:
return;
case knoVarName:
return;
case kvarNames:
gettZTree (& ((* yyt)->varNames.VarName))
yyt = & ((* yyt)->varNames.Next); break;
case kExpressionSeq:
return;
case knoExpSeq:
return;
case kexpSeq:
gettZTree (& ((* yyt)->expSeq.Expression))
yyt = & ((* yyt)->expSeq.Next); break;
case kRenameSeq:
return;
case knoRename:
return;
case krenames:
gettZTree (& ((* yyt)->renames.VarRename))
yyt = & ((* yyt)->renames.Next); break;
case kVarRename:
gettZTree (& ((* yyt)->VarRename.New))
yyt = & ((* yyt)->VarRename.Old); break;
case kZSchemaText:
gettZTree (& ((* yyt)->ZSchemaText.Declaration))
yyt = & ((* yyt)->ZSchemaText.Predicate); break;
case kDeclaration:
return;
case knoDecl:
return;
case kdecl:
gettZTree (& ((* yyt)->decl.BasicDecl))
yyt = & ((* yyt)->decl.Next); break;
case kBasicDecl:
return;
case kcolonDecl:
gettZTree (& ((* yyt)->colonDecl.VarNameSeq))
yyt = & ((* yyt)->colonDecl.Expression); break;
case kschemaRef:
yyt = & ((* yyt)->schemaRef.Designator); break;
case kPredicate:
return;
case knoPred:
return;
case kpredNegate:
yyt = & ((* yyt)->predNegate.Predicate); break;
case kpredInfixRelSeq:
yyt = & ((* yyt)->predInfixRelSeq.PredInfixRelSeq); break;
case kpredTrueOrFalse:
gettIdPos ((* yyt)->predTrueOrFalse.TrueFalse)
return;
case kpredSchemaRef:
gettIdPos ((* yyt)->predSchemaRef.PredOrPre)
yyt = & ((* yyt)->predSchemaRef.Designator); break;
case kpredPreRel:
gettIdPos ((* yyt)->predPreRel.PreRel)
gettZTree (& ((* yyt)->predPreRel.Decoration))
yyt = & ((* yyt)->predPreRel.Expression); break;
case kpredCons:
gettZTree (& ((* yyt)->predCons.Lpred))
gettIdPos ((* yyt)->predCons.LogOp)
yyt = & ((* yyt)->predCons.Rpred); break;
case kpredQuant:
gettIdPos ((* yyt)->predQuant.LogQuant)
gettZTree (& ((* yyt)->predQuant.ZSchemaText))
yyt = & ((* yyt)->predQuant.Predicate); break;
case kpredLet:
gettZTree (& ((* yyt)->predLet.LetDefSeq))
yyt = & ((* yyt)->predLet.Predicate); break;
case kpredParen:
yyt = & ((* yyt)->predParen.Predicate); break;
case kPredInfixRelSeq:
return;
case knoInfixRel:
return;
case kinfixRels:
gettZTree (& ((* yyt)->infixRels.PredInfixRel))
yyt = & ((* yyt)->infixRels.Next); break;
case kPredInfixRel:
gettZTree (& ((* yyt)->PredInfixRel.Lexp))
gettZTree (& ((* yyt)->PredInfixRel.InfixRel))
yyt = & ((* yyt)->PredInfixRel.Rexp); break;
case kInfixRel:
gettIdPos ((* yyt)->InfixRel.InRel)
yyt = & ((* yyt)->InfixRel.Decoration); break;
case kExpression:
return;
case knoExp:
return;
case kexpBinaryGen:
gettZTree (& ((* yyt)->expBinaryGen.lexp))
gettIdPos ((* yyt)->expBinaryGen.InGen)
gettZTree (& ((* yyt)->expBinaryGen.Decoration))
yyt = & ((* yyt)->expBinaryGen.rexp); break;
case kexpBinaryFun:
gettZTree (& ((* yyt)->expBinaryFun.lexp))
gettIdPos ((* yyt)->expBinaryFun.InFun)
gettZTree (& ((* yyt)->expBinaryFun.Decoration))
yyt = & ((* yyt)->expBinaryFun.rexp); break;
case kexpLiteral:
gettIdPos ((* yyt)->expLiteral.Literal)
return;
case kexpOpname:
gettZTree (& ((* yyt)->expOpname.VarName))
yyt = & ((* yyt)->expOpname.ExpressionSeq); break;
case kexpSetElab:
yyt = & ((* yyt)->expSetElab.ExpressionSeq); break;
case kexpSeqElab:
yyt = & ((* yyt)->expSeqElab.ExpressionSeq); break;
case kexpBagElab:
yyt = & ((* yyt)->expBagElab.ExpressionSeq); break;
case kexpSetComp:
gettZTree (& ((* yyt)->expSetComp.ZSchemaText))
yyt = & ((* yyt)->expSetComp.Expression); break;
case kexpPowerSet:
yyt = & ((* yyt)->expPowerSet.Expression); break;
case kexpPreGen:
gettIdPos ((* yyt)->expPreGen.Pregen)
gettZTree (& ((* yyt)->expPreGen.Decoration))
yyt = & ((* yyt)->expPreGen.Expression); break;
case kexpPostFun:
gettZTree (& ((* yyt)->expPostFun.Expression))
gettIdPos ((* yyt)->expPostFun.Postfun)
yyt = & ((* yyt)->expPostFun.Decoration); break;
case kexpIter:
gettZTree (& ((* yyt)->expIter.exp1))
yyt = & ((* yyt)->expIter.exp2); break;
case kexpTuple:
yyt = & ((* yyt)->expTuple.ExpressionSeq); break;
case kexpCartProd:
yyt = & ((* yyt)->expCartProd.ExpressionSeq); break;
case kexpTheta:
gettZTree (& ((* yyt)->expTheta.ZName))
gettZTree (& ((* yyt)->expTheta.Decoration))
yyt = & ((* yyt)->expTheta.RenameSeq); break;
case kexpSelectVar:
gettZTree (& ((* yyt)->expSelectVar.Expression))
yyt = & ((* yyt)->expSelectVar.VarName); break;
case kexpFnApp:
gettZTree (& ((* yyt)->expFnApp.FnName))
yyt = & ((* yyt)->expFnApp.Params); break;
case kexpMu:
gettZTree (& ((* yyt)->expMu.ZSchemaText))
yyt = & ((* yyt)->expMu.Expression); break;
case kexpLambda:
gettZTree (& ((* yyt)->expLambda.ZSchemaText))
yyt = & ((* yyt)->expLambda.Expression); break;
case kexpLet:
gettZTree (& ((* yyt)->expLet.LetDefSeq))
yyt = & ((* yyt)->expLet.Expression); break;
case kexpIf:
gettZTree (& ((* yyt)->expIf.Predicate))
gettZTree (& ((* yyt)->expIf.Exp1))
yyt = & ((* yyt)->expIf.Exp2); break;
case kexpImage:
gettZTree (& ((* yyt)->expImage.Exp1))
gettZTree (& ((* yyt)->expImage.Exp2))
gettIdPos ((* yyt)->expImage.Image)
yyt = & ((* yyt)->expImage.Decoration); break;
case kexpDesignator:
yyt = & ((* yyt)->expDesignator.Designator); break;
case kexpParen:
yyt = & ((* yyt)->expParen.Expression); break;
case kLetDefSeq:
return;
case knoLetDef:
return;
case kletDefs:
gettZTree (& ((* yyt)->letDefs.LetDef))
yyt = & ((* yyt)->letDefs.Next); break;
case kLetDef:
gettZTree (& ((* yyt)->LetDef.VarName))
yyt = & ((* yyt)->LetDef.Expression); break;
case kVarName:
gettIdPos ((* yyt)->VarName.Ident)
yyt = & ((* yyt)->VarName.Decoration); break;
case kZId:
gettIdPos ((* yyt)->ZId.Ident)
yyt = & ((* yyt)->ZId.Decoration); break;
case kOpname:
gettIdPos ((* yyt)->Opname.Ident)
yyt = & ((* yyt)->Opname.Decoration); break;
case kDecoration:
return;
case knoDecoration:
return;
case kdecoration:
gettIdPos ((* yyt)->decoration.Stroke)
yyt = & ((* yyt)->decoration.Next); break;
case kZName:
gettIdPos ((* yyt)->ZName.Ident)
return;
  default: return;
  }
 }
}

tZTree GetZTree
# if defined __STDC__ | defined __cplusplus
 (FILE * yyyf)
# else
 (yyyf) FILE * yyyf;
# endif
{
 tZTree yyt;
 yyf = yyyf;
 if (yyRecursionLevel ++ == 0) yyLabelCount = 0;
 yyGetZTree (& yyt);
 yyRecursionLevel --;
 return yyt;
}

static tZTree yyChild;

static void yyReleaseZTree
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 if (yyt == NoZTree) return;
 switch (yyt->Kind) {
case kSpecification:
closetZTree (yyt->Specification.GlobalParagraphSeq)
break;
case kglobalParagraphs:
closetZTree (yyt->globalParagraphs.GlobalParagraph)
closetZTree (yyt->globalParagraphs.Next)
break;
case kaxiomaticDef:
closetZTree (yyt->axiomaticDef.ZSchemaText)
break;
case khorizPar:
closetZTree (yyt->horizPar.HorizParagraphs)
break;
case kgenericDef:
closetZTree (yyt->genericDef.ZFormalParams)
closetZTree (yyt->genericDef.ZSchemaText)
break;
case kschemaboxDef:
closetZTree (yyt->schemaboxDef.ZName)
closetZTree (yyt->schemaboxDef.ZFormalParams)
closetZTree (yyt->schemaboxDef.ZSchemaText)
break;
case khorizParagraphs:
closetZTree (yyt->horizParagraphs.HorizParagraph)
closetZTree (yyt->horizParagraphs.Next)
break;
case ktypeDef:
closetZTree (yyt->typeDef.TypeDef)
break;
case kglobalPredicate:
closetZTree (yyt->globalPredicate.Predicate)
break;
case kschemaDef:
closetZTree (yyt->schemaDef.NameFormals)
closetZTree (yyt->schemaDef.SchemaExp)
break;
case kgivenSet:
closetZTree (yyt->givenSet.VarNameSeq)
break;
case kfreeType:
closetZTree (yyt->freeType.VarName)
closetZTree (yyt->freeType.BranchSeq)
break;
case ktypeDef1:
closetZTree (yyt->typeDef1.NameFormals)
closetZTree (yyt->typeDef1.Expression)
break;
case ktypeDefPregen:
closetZTree (yyt->typeDefPregen.Decoration)
closetZTree (yyt->typeDefPregen.VarName)
closetZTree (yyt->typeDefPregen.Expression)
break;
case ktypeDefIngen:
closetZTree (yyt->typeDefIngen.Var1)
closetZTree (yyt->typeDefIngen.Decoration)
closetZTree (yyt->typeDefIngen.Var2)
closetZTree (yyt->typeDefIngen.Expression)
break;
case kNameFormals:
closetZTree (yyt->NameFormals.VarName)
break;
case knoFormals:
closetZTree (yyt->noFormals.VarName)
break;
case knameFormals:
closetZTree (yyt->nameFormals.VarName)
closetZTree (yyt->nameFormals.ZFormalParams)
break;
case kbranch:
closetZTree (yyt->branch.ZBranch)
closetZTree (yyt->branch.Next)
break;
case kformalParams:
closetZTree (yyt->formalParams.VarNameSeq)
break;
case ksimpleBranch:
closetZTree (yyt->simpleBranch.VarName)
break;
case kcompoundBranch:
closetZTree (yyt->compoundBranch.VarName)
closetZTree (yyt->compoundBranch.Expression)
break;
case kschemaSimple:
closetZTree (yyt->schemaSimple.ZSchemaText)
break;
case kschemaDes:
closetZTree (yyt->schemaDes.Designator)
break;
case kschemaPreop:
closetZTree (yyt->schemaPreop.SchemaExp)
break;
case kschemaCons:
closetZTree (yyt->schemaCons.Lop)
closetZTree (yyt->schemaCons.Rop)
break;
case kschemaHide:
closetZTree (yyt->schemaHide.SchemaExp)
closetZTree (yyt->schemaHide.VarNameSeq)
break;
case kschemaQuant:
closetZTree (yyt->schemaQuant.ZSchemaText)
closetZTree (yyt->schemaQuant.SchemaExp)
break;
case kschemaComp:
closetZTree (yyt->schemaComp.Lop)
closetZTree (yyt->schemaComp.Rop)
break;
case kschemaProject:
closetZTree (yyt->schemaProject.Lop)
closetZTree (yyt->schemaProject.Rop)
break;
case kschemaPipe:
closetZTree (yyt->schemaPipe.Lop)
closetZTree (yyt->schemaPipe.Rop)
break;
case kschemaParen:
closetZTree (yyt->schemaParen.SchemaExp)
break;
case kDesignator:
closetZTree (yyt->Designator.ZName)
closetZTree (yyt->Designator.Decoration)
closetZTree (yyt->Designator.ExpressionSeq)
closetZTree (yyt->Designator.RenameSeq)
break;
case kvarNames:
closetZTree (yyt->varNames.VarName)
closetZTree (yyt->varNames.Next)
break;
case kexpSeq:
closetZTree (yyt->expSeq.Expression)
closetZTree (yyt->expSeq.Next)
break;
case krenames:
closetZTree (yyt->renames.VarRename)
closetZTree (yyt->renames.Next)
break;
case kVarRename:
closetZTree (yyt->VarRename.New)
closetZTree (yyt->VarRename.Old)
break;
case kZSchemaText:
closetZTree (yyt->ZSchemaText.Declaration)
closetZTree (yyt->ZSchemaText.Predicate)
break;
case kdecl:
closetZTree (yyt->decl.BasicDecl)
closetZTree (yyt->decl.Next)
break;
case kcolonDecl:
closetZTree (yyt->colonDecl.VarNameSeq)
closetZTree (yyt->colonDecl.Expression)
break;
case kschemaRef:
closetZTree (yyt->schemaRef.Designator)
break;
case kpredNegate:
closetZTree (yyt->predNegate.Predicate)
break;
case kpredInfixRelSeq:
closetZTree (yyt->predInfixRelSeq.PredInfixRelSeq)
break;
case kpredSchemaRef:
closetZTree (yyt->predSchemaRef.Designator)
break;
case kpredPreRel:
closetZTree (yyt->predPreRel.Decoration)
closetZTree (yyt->predPreRel.Expression)
break;
case kpredCons:
closetZTree (yyt->predCons.Lpred)
closetZTree (yyt->predCons.Rpred)
break;
case kpredQuant:
closetZTree (yyt->predQuant.ZSchemaText)
closetZTree (yyt->predQuant.Predicate)
break;
case kpredLet:
closetZTree (yyt->predLet.LetDefSeq)
closetZTree (yyt->predLet.Predicate)
break;
case kpredParen:
closetZTree (yyt->predParen.Predicate)
break;
case kinfixRels:
closetZTree (yyt->infixRels.PredInfixRel)
closetZTree (yyt->infixRels.Next)
break;
case kPredInfixRel:
closetZTree (yyt->PredInfixRel.Lexp)
closetZTree (yyt->PredInfixRel.InfixRel)
closetZTree (yyt->PredInfixRel.Rexp)
break;
case kInfixRel:
closetZTree (yyt->InfixRel.Decoration)
break;
case kexpBinaryGen:
closetZTree (yyt->expBinaryGen.lexp)
closetZTree (yyt->expBinaryGen.Decoration)
closetZTree (yyt->expBinaryGen.rexp)
break;
case kexpBinaryFun:
closetZTree (yyt->expBinaryFun.lexp)
closetZTree (yyt->expBinaryFun.Decoration)
closetZTree (yyt->expBinaryFun.rexp)
break;
case kexpOpname:
closetZTree (yyt->expOpname.VarName)
closetZTree (yyt->expOpname.ExpressionSeq)
break;
case kexpSetElab:
closetZTree (yyt->expSetElab.ExpressionSeq)
break;
case kexpSeqElab:
closetZTree (yyt->expSeqElab.ExpressionSeq)
break;
case kexpBagElab:
closetZTree (yyt->expBagElab.ExpressionSeq)
break;
case kexpSetComp:
closetZTree (yyt->expSetComp.ZSchemaText)
closetZTree (yyt->expSetComp.Expression)
break;
case kexpPowerSet:
closetZTree (yyt->expPowerSet.Expression)
break;
case kexpPreGen:
closetZTree (yyt->expPreGen.Decoration)
closetZTree (yyt->expPreGen.Expression)
break;
case kexpPostFun:
closetZTree (yyt->expPostFun.Expression)
closetZTree (yyt->expPostFun.Decoration)
break;
case kexpIter:
closetZTree (yyt->expIter.exp1)
closetZTree (yyt->expIter.exp2)
break;
case kexpTuple:
closetZTree (yyt->expTuple.ExpressionSeq)
break;
case kexpCartProd:
closetZTree (yyt->expCartProd.ExpressionSeq)
break;
case kexpTheta:
closetZTree (yyt->expTheta.ZName)
closetZTree (yyt->expTheta.Decoration)
closetZTree (yyt->expTheta.RenameSeq)
break;
case kexpSelectVar:
closetZTree (yyt->expSelectVar.Expression)
closetZTree (yyt->expSelectVar.VarName)
break;
case kexpFnApp:
closetZTree (yyt->expFnApp.FnName)
closetZTree (yyt->expFnApp.Params)
break;
case kexpMu:
closetZTree (yyt->expMu.ZSchemaText)
closetZTree (yyt->expMu.Expression)
break;
case kexpLambda:
closetZTree (yyt->expLambda.ZSchemaText)
closetZTree (yyt->expLambda.Expression)
break;
case kexpLet:
closetZTree (yyt->expLet.LetDefSeq)
closetZTree (yyt->expLet.Expression)
break;
case kexpIf:
closetZTree (yyt->expIf.Predicate)
closetZTree (yyt->expIf.Exp1)
closetZTree (yyt->expIf.Exp2)
break;
case kexpImage:
closetZTree (yyt->expImage.Exp1)
closetZTree (yyt->expImage.Exp2)
closetZTree (yyt->expImage.Decoration)
break;
case kexpDesignator:
closetZTree (yyt->expDesignator.Designator)
break;
case kexpParen:
closetZTree (yyt->expParen.Expression)
break;
case kletDefs:
closetZTree (yyt->letDefs.LetDef)
closetZTree (yyt->letDefs.Next)
break;
case kLetDef:
closetZTree (yyt->LetDef.VarName)
closetZTree (yyt->LetDef.Expression)
break;
case kVarName:
closetZTree (yyt->VarName.Decoration)
break;
case kZId:
closetZTree (yyt->ZId.Decoration)
break;
case kOpname:
closetZTree (yyt->Opname.Decoration)
break;
case kdecoration:
closetZTree (yyt->decoration.Next)
break;
 default: ;
 }

 if (-- yyt->yyHead.yyMark == 0) {
  switch (yyt->Kind) {
case kGlobalParagraphSeq:
break;
case knoGlobalParagraph:
break;
case kglobalParagraphs:
break;
case kGlobalParagraph:
break;
case kaxiomaticDef:
break;
case khorizPar:
break;
case kgenericDef:
break;
case kschemaboxDef:
break;
case kHorizParagraphs:
break;
case knoHorizParagraph:
break;
case khorizParagraphs:
break;
case kHorizParagraph:
break;
case ktypeDef:
break;
case kglobalPredicate:
break;
case kschemaDef:
break;
case kTypeDef:
break;
case kgivenSet:
break;
case kfreeType:
break;
case ktypeDef1:
break;
case ktypeDefPregen:
closetIdPos (yyt->typeDefPregen.PreGen)
break;
case ktypeDefIngen:
closetIdPos (yyt->typeDefIngen.InGen)
break;
case kNameFormals:
break;
case knoFormals:
break;
case knameFormals:
break;
case kBranchSeq:
break;
case knoBranch:
break;
case kbranch:
break;
case kZFormalParams:
break;
case knoFormalParams:
break;
case kformalParams:
break;
case kZBranch:
break;
case ksimpleBranch:
break;
case kcompoundBranch:
break;
case kSchemaExp:
break;
case kschemaSimple:
break;
case kschemaDes:
break;
case kschemaPreop:
closetIdPos (yyt->schemaPreop.PreOp)
break;
case kschemaCons:
closetIdPos (yyt->schemaCons.SchemaOp)
break;
case kschemaHide:
break;
case kschemaQuant:
closetIdPos (yyt->schemaQuant.LogQuant)
break;
case kschemaComp:
break;
case kschemaProject:
break;
case kschemaPipe:
break;
case kschemaParen:
break;
case kDesignator:
closebool (yyt->Designator.IsSchemaRef)
break;
case kVarNameSeq:
break;
case knoVarName:
break;
case kvarNames:
break;
case kExpressionSeq:
break;
case knoExpSeq:
break;
case kexpSeq:
break;
case kRenameSeq:
break;
case knoRename:
break;
case krenames:
break;
case kVarRename:
break;
case kZSchemaText:
break;
case kDeclaration:
break;
case knoDecl:
break;
case kdecl:
break;
case kBasicDecl:
break;
case kcolonDecl:
break;
case kschemaRef:
break;
case kPredicate:
break;
case knoPred:
break;
case kpredNegate:
break;
case kpredInfixRelSeq:
break;
case kpredTrueOrFalse:
closetIdPos (yyt->predTrueOrFalse.TrueFalse)
break;
case kpredSchemaRef:
closetIdPos (yyt->predSchemaRef.PredOrPre)
break;
case kpredPreRel:
closetIdPos (yyt->predPreRel.PreRel)
break;
case kpredCons:
closetIdPos (yyt->predCons.LogOp)
break;
case kpredQuant:
closetIdPos (yyt->predQuant.LogQuant)
break;
case kpredLet:
break;
case kpredParen:
break;
case kPredInfixRelSeq:
break;
case knoInfixRel:
break;
case kinfixRels:
break;
case kPredInfixRel:
break;
case kInfixRel:
closetIdPos (yyt->InfixRel.InRel)
break;
case kExpression:
break;
case knoExp:
break;
case kexpBinaryGen:
closetIdPos (yyt->expBinaryGen.InGen)
break;
case kexpBinaryFun:
closetIdPos (yyt->expBinaryFun.InFun)
break;
case kexpLiteral:
closetIdPos (yyt->expLiteral.Literal)
break;
case kexpOpname:
break;
case kexpSetElab:
break;
case kexpSeqElab:
break;
case kexpBagElab:
break;
case kexpSetComp:
break;
case kexpPowerSet:
break;
case kexpPreGen:
closetIdPos (yyt->expPreGen.Pregen)
break;
case kexpPostFun:
closetIdPos (yyt->expPostFun.Postfun)
break;
case kexpIter:
break;
case kexpTuple:
break;
case kexpCartProd:
break;
case kexpTheta:
break;
case kexpSelectVar:
break;
case kexpFnApp:
break;
case kexpMu:
break;
case kexpLambda:
break;
case kexpLet:
break;
case kexpIf:
break;
case kexpImage:
closetIdPos (yyt->expImage.Image)
break;
case kexpDesignator:
break;
case kexpParen:
break;
case kLetDefSeq:
break;
case knoLetDef:
break;
case kletDefs:
break;
case kLetDef:
break;
case kVarName:
closetIdPos (yyt->VarName.Ident)
break;
case kZId:
closetIdPos (yyt->ZId.Ident)
break;
case kOpname:
closetIdPos (yyt->Opname.Ident)
break;
case kDecoration:
break;
case knoDecoration:
break;
case kdecoration:
closetIdPos (yyt->decoration.Stroke)
break;
case kZName:
closetIdPos (yyt->ZName.Ident)
break;
  default: ;
  }
  yyFREE (yyt, ZTree_NodeSize [yyt->Kind])
 }
}

void ReleaseZTree
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyMark (yyt);
 yyReleaseZTree (yyt);
}

void ReleaseZTreeModule ()
{
 yytBlockPtr yyBlockPtr;
 while (yyBlockList != (yytBlockPtr) NoZTree) {
  yyBlockPtr = yyBlockList;
  yyBlockList = yyBlockList->yySuccessor;
  Free (sizeof (yytBlock), (char *) yyBlockPtr);
 }
 ZTree_PoolFreePtr = (char *) NoZTree;
 ZTree_PoolMaxPtr = (char *) NoZTree;
 ZTree_HeapUsed = 0;
}

static ZTree_tProcTree yyProc;

static void yyTraverseZTreeTD
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 for (;;) {
  if (yyt == NoZTree || yyt->yyHead.yyMark == 0) return;
  yyt->yyHead.yyMark = 0;
  yyProc (yyt);

  switch (yyt->Kind) {
case kSpecification:
yyt = yyt->Specification.GlobalParagraphSeq; break;
case kglobalParagraphs:
yyTraverseZTreeTD (yyt->globalParagraphs.GlobalParagraph);
yyt = yyt->globalParagraphs.Next; break;
case kaxiomaticDef:
yyt = yyt->axiomaticDef.ZSchemaText; break;
case khorizPar:
yyt = yyt->horizPar.HorizParagraphs; break;
case kgenericDef:
yyTraverseZTreeTD (yyt->genericDef.ZFormalParams);
yyt = yyt->genericDef.ZSchemaText; break;
case kschemaboxDef:
yyTraverseZTreeTD (yyt->schemaboxDef.ZName);
yyTraverseZTreeTD (yyt->schemaboxDef.ZFormalParams);
yyt = yyt->schemaboxDef.ZSchemaText; break;
case khorizParagraphs:
yyTraverseZTreeTD (yyt->horizParagraphs.HorizParagraph);
yyt = yyt->horizParagraphs.Next; break;
case ktypeDef:
yyt = yyt->typeDef.TypeDef; break;
case kglobalPredicate:
yyt = yyt->globalPredicate.Predicate; break;
case kschemaDef:
yyTraverseZTreeTD (yyt->schemaDef.NameFormals);
yyt = yyt->schemaDef.SchemaExp; break;
case kgivenSet:
yyt = yyt->givenSet.VarNameSeq; break;
case kfreeType:
yyTraverseZTreeTD (yyt->freeType.VarName);
yyt = yyt->freeType.BranchSeq; break;
case ktypeDef1:
yyTraverseZTreeTD (yyt->typeDef1.NameFormals);
yyt = yyt->typeDef1.Expression; break;
case ktypeDefPregen:
yyTraverseZTreeTD (yyt->typeDefPregen.Decoration);
yyTraverseZTreeTD (yyt->typeDefPregen.VarName);
yyt = yyt->typeDefPregen.Expression; break;
case ktypeDefIngen:
yyTraverseZTreeTD (yyt->typeDefIngen.Var1);
yyTraverseZTreeTD (yyt->typeDefIngen.Decoration);
yyTraverseZTreeTD (yyt->typeDefIngen.Var2);
yyt = yyt->typeDefIngen.Expression; break;
case kNameFormals:
yyt = yyt->NameFormals.VarName; break;
case knoFormals:
yyt = yyt->noFormals.VarName; break;
case knameFormals:
yyTraverseZTreeTD (yyt->nameFormals.VarName);
yyt = yyt->nameFormals.ZFormalParams; break;
case kbranch:
yyTraverseZTreeTD (yyt->branch.ZBranch);
yyt = yyt->branch.Next; break;
case kformalParams:
yyt = yyt->formalParams.VarNameSeq; break;
case ksimpleBranch:
yyt = yyt->simpleBranch.VarName; break;
case kcompoundBranch:
yyTraverseZTreeTD (yyt->compoundBranch.VarName);
yyt = yyt->compoundBranch.Expression; break;
case kschemaSimple:
yyt = yyt->schemaSimple.ZSchemaText; break;
case kschemaDes:
yyt = yyt->schemaDes.Designator; break;
case kschemaPreop:
yyt = yyt->schemaPreop.SchemaExp; break;
case kschemaCons:
yyTraverseZTreeTD (yyt->schemaCons.Lop);
yyt = yyt->schemaCons.Rop; break;
case kschemaHide:
yyTraverseZTreeTD (yyt->schemaHide.SchemaExp);
yyt = yyt->schemaHide.VarNameSeq; break;
case kschemaQuant:
yyTraverseZTreeTD (yyt->schemaQuant.ZSchemaText);
yyt = yyt->schemaQuant.SchemaExp; break;
case kschemaComp:
yyTraverseZTreeTD (yyt->schemaComp.Lop);
yyt = yyt->schemaComp.Rop; break;
case kschemaProject:
yyTraverseZTreeTD (yyt->schemaProject.Lop);
yyt = yyt->schemaProject.Rop; break;
case kschemaPipe:
yyTraverseZTreeTD (yyt->schemaPipe.Lop);
yyt = yyt->schemaPipe.Rop; break;
case kschemaParen:
yyt = yyt->schemaParen.SchemaExp; break;
case kDesignator:
yyTraverseZTreeTD (yyt->Designator.ZName);
yyTraverseZTreeTD (yyt->Designator.Decoration);
yyTraverseZTreeTD (yyt->Designator.ExpressionSeq);
yyt = yyt->Designator.RenameSeq; break;
case kvarNames:
yyTraverseZTreeTD (yyt->varNames.VarName);
yyt = yyt->varNames.Next; break;
case kexpSeq:
yyTraverseZTreeTD (yyt->expSeq.Expression);
yyt = yyt->expSeq.Next; break;
case krenames:
yyTraverseZTreeTD (yyt->renames.VarRename);
yyt = yyt->renames.Next; break;
case kVarRename:
yyTraverseZTreeTD (yyt->VarRename.New);
yyt = yyt->VarRename.Old; break;
case kZSchemaText:
yyTraverseZTreeTD (yyt->ZSchemaText.Declaration);
yyt = yyt->ZSchemaText.Predicate; break;
case kdecl:
yyTraverseZTreeTD (yyt->decl.BasicDecl);
yyt = yyt->decl.Next; break;
case kcolonDecl:
yyTraverseZTreeTD (yyt->colonDecl.VarNameSeq);
yyt = yyt->colonDecl.Expression; break;
case kschemaRef:
yyt = yyt->schemaRef.Designator; break;
case kpredNegate:
yyt = yyt->predNegate.Predicate; break;
case kpredInfixRelSeq:
yyt = yyt->predInfixRelSeq.PredInfixRelSeq; break;
case kpredSchemaRef:
yyt = yyt->predSchemaRef.Designator; break;
case kpredPreRel:
yyTraverseZTreeTD (yyt->predPreRel.Decoration);
yyt = yyt->predPreRel.Expression; break;
case kpredCons:
yyTraverseZTreeTD (yyt->predCons.Lpred);
yyt = yyt->predCons.Rpred; break;
case kpredQuant:
yyTraverseZTreeTD (yyt->predQuant.ZSchemaText);
yyt = yyt->predQuant.Predicate; break;
case kpredLet:
yyTraverseZTreeTD (yyt->predLet.LetDefSeq);
yyt = yyt->predLet.Predicate; break;
case kpredParen:
yyt = yyt->predParen.Predicate; break;
case kinfixRels:
yyTraverseZTreeTD (yyt->infixRels.PredInfixRel);
yyt = yyt->infixRels.Next; break;
case kPredInfixRel:
yyTraverseZTreeTD (yyt->PredInfixRel.Lexp);
yyTraverseZTreeTD (yyt->PredInfixRel.InfixRel);
yyt = yyt->PredInfixRel.Rexp; break;
case kInfixRel:
yyt = yyt->InfixRel.Decoration; break;
case kexpBinaryGen:
yyTraverseZTreeTD (yyt->expBinaryGen.lexp);
yyTraverseZTreeTD (yyt->expBinaryGen.Decoration);
yyt = yyt->expBinaryGen.rexp; break;
case kexpBinaryFun:
yyTraverseZTreeTD (yyt->expBinaryFun.lexp);
yyTraverseZTreeTD (yyt->expBinaryFun.Decoration);
yyt = yyt->expBinaryFun.rexp; break;
case kexpOpname:
yyTraverseZTreeTD (yyt->expOpname.VarName);
yyt = yyt->expOpname.ExpressionSeq; break;
case kexpSetElab:
yyt = yyt->expSetElab.ExpressionSeq; break;
case kexpSeqElab:
yyt = yyt->expSeqElab.ExpressionSeq; break;
case kexpBagElab:
yyt = yyt->expBagElab.ExpressionSeq; break;
case kexpSetComp:
yyTraverseZTreeTD (yyt->expSetComp.ZSchemaText);
yyt = yyt->expSetComp.Expression; break;
case kexpPowerSet:
yyt = yyt->expPowerSet.Expression; break;
case kexpPreGen:
yyTraverseZTreeTD (yyt->expPreGen.Decoration);
yyt = yyt->expPreGen.Expression; break;
case kexpPostFun:
yyTraverseZTreeTD (yyt->expPostFun.Expression);
yyt = yyt->expPostFun.Decoration; break;
case kexpIter:
yyTraverseZTreeTD (yyt->expIter.exp1);
yyt = yyt->expIter.exp2; break;
case kexpTuple:
yyt = yyt->expTuple.ExpressionSeq; break;
case kexpCartProd:
yyt = yyt->expCartProd.ExpressionSeq; break;
case kexpTheta:
yyTraverseZTreeTD (yyt->expTheta.ZName);
yyTraverseZTreeTD (yyt->expTheta.Decoration);
yyt = yyt->expTheta.RenameSeq; break;
case kexpSelectVar:
yyTraverseZTreeTD (yyt->expSelectVar.Expression);
yyt = yyt->expSelectVar.VarName; break;
case kexpFnApp:
yyTraverseZTreeTD (yyt->expFnApp.FnName);
yyt = yyt->expFnApp.Params; break;
case kexpMu:
yyTraverseZTreeTD (yyt->expMu.ZSchemaText);
yyt = yyt->expMu.Expression; break;
case kexpLambda:
yyTraverseZTreeTD (yyt->expLambda.ZSchemaText);
yyt = yyt->expLambda.Expression; break;
case kexpLet:
yyTraverseZTreeTD (yyt->expLet.LetDefSeq);
yyt = yyt->expLet.Expression; break;
case kexpIf:
yyTraverseZTreeTD (yyt->expIf.Predicate);
yyTraverseZTreeTD (yyt->expIf.Exp1);
yyt = yyt->expIf.Exp2; break;
case kexpImage:
yyTraverseZTreeTD (yyt->expImage.Exp1);
yyTraverseZTreeTD (yyt->expImage.Exp2);
yyt = yyt->expImage.Decoration; break;
case kexpDesignator:
yyt = yyt->expDesignator.Designator; break;
case kexpParen:
yyt = yyt->expParen.Expression; break;
case kletDefs:
yyTraverseZTreeTD (yyt->letDefs.LetDef);
yyt = yyt->letDefs.Next; break;
case kLetDef:
yyTraverseZTreeTD (yyt->LetDef.VarName);
yyt = yyt->LetDef.Expression; break;
case kVarName:
yyt = yyt->VarName.Decoration; break;
case kZId:
yyt = yyt->ZId.Decoration; break;
case kOpname:
yyt = yyt->Opname.Decoration; break;
case kdecoration:
yyt = yyt->decoration.Next; break;
  default: return;
  }
 }
}

void TraverseZTreeTD
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt, ZTree_tProcTree yyyProc)
# else
 (yyt, yyyProc) tZTree yyt; ZTree_tProcTree yyyProc;
# endif
{
 yyMark (yyt);
 yyProc = yyyProc;
 yyTraverseZTreeTD (yyt);
}

static void yyTraverseZTreeBU
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 if (yyt == NoZTree || yyt->yyHead.yyMark == 0) return;
 yyt->yyHead.yyMark = 0;

 switch (yyt->Kind) {
case kSpecification:
yyTraverseZTreeBU (yyt->Specification.GlobalParagraphSeq); break;
case kglobalParagraphs:
yyTraverseZTreeBU (yyt->globalParagraphs.GlobalParagraph);
yyTraverseZTreeBU (yyt->globalParagraphs.Next); break;
case kaxiomaticDef:
yyTraverseZTreeBU (yyt->axiomaticDef.ZSchemaText); break;
case khorizPar:
yyTraverseZTreeBU (yyt->horizPar.HorizParagraphs); break;
case kgenericDef:
yyTraverseZTreeBU (yyt->genericDef.ZFormalParams);
yyTraverseZTreeBU (yyt->genericDef.ZSchemaText); break;
case kschemaboxDef:
yyTraverseZTreeBU (yyt->schemaboxDef.ZName);
yyTraverseZTreeBU (yyt->schemaboxDef.ZFormalParams);
yyTraverseZTreeBU (yyt->schemaboxDef.ZSchemaText); break;
case khorizParagraphs:
yyTraverseZTreeBU (yyt->horizParagraphs.HorizParagraph);
yyTraverseZTreeBU (yyt->horizParagraphs.Next); break;
case ktypeDef:
yyTraverseZTreeBU (yyt->typeDef.TypeDef); break;
case kglobalPredicate:
yyTraverseZTreeBU (yyt->globalPredicate.Predicate); break;
case kschemaDef:
yyTraverseZTreeBU (yyt->schemaDef.NameFormals);
yyTraverseZTreeBU (yyt->schemaDef.SchemaExp); break;
case kgivenSet:
yyTraverseZTreeBU (yyt->givenSet.VarNameSeq); break;
case kfreeType:
yyTraverseZTreeBU (yyt->freeType.VarName);
yyTraverseZTreeBU (yyt->freeType.BranchSeq); break;
case ktypeDef1:
yyTraverseZTreeBU (yyt->typeDef1.NameFormals);
yyTraverseZTreeBU (yyt->typeDef1.Expression); break;
case ktypeDefPregen:
yyTraverseZTreeBU (yyt->typeDefPregen.Decoration);
yyTraverseZTreeBU (yyt->typeDefPregen.VarName);
yyTraverseZTreeBU (yyt->typeDefPregen.Expression); break;
case ktypeDefIngen:
yyTraverseZTreeBU (yyt->typeDefIngen.Var1);
yyTraverseZTreeBU (yyt->typeDefIngen.Decoration);
yyTraverseZTreeBU (yyt->typeDefIngen.Var2);
yyTraverseZTreeBU (yyt->typeDefIngen.Expression); break;
case kNameFormals:
yyTraverseZTreeBU (yyt->NameFormals.VarName); break;
case knoFormals:
yyTraverseZTreeBU (yyt->noFormals.VarName); break;
case knameFormals:
yyTraverseZTreeBU (yyt->nameFormals.VarName);
yyTraverseZTreeBU (yyt->nameFormals.ZFormalParams); break;
case kbranch:
yyTraverseZTreeBU (yyt->branch.ZBranch);
yyTraverseZTreeBU (yyt->branch.Next); break;
case kformalParams:
yyTraverseZTreeBU (yyt->formalParams.VarNameSeq); break;
case ksimpleBranch:
yyTraverseZTreeBU (yyt->simpleBranch.VarName); break;
case kcompoundBranch:
yyTraverseZTreeBU (yyt->compoundBranch.VarName);
yyTraverseZTreeBU (yyt->compoundBranch.Expression); break;
case kschemaSimple:
yyTraverseZTreeBU (yyt->schemaSimple.ZSchemaText); break;
case kschemaDes:
yyTraverseZTreeBU (yyt->schemaDes.Designator); break;
case kschemaPreop:
yyTraverseZTreeBU (yyt->schemaPreop.SchemaExp); break;
case kschemaCons:
yyTraverseZTreeBU (yyt->schemaCons.Lop);
yyTraverseZTreeBU (yyt->schemaCons.Rop); break;
case kschemaHide:
yyTraverseZTreeBU (yyt->schemaHide.SchemaExp);
yyTraverseZTreeBU (yyt->schemaHide.VarNameSeq); break;
case kschemaQuant:
yyTraverseZTreeBU (yyt->schemaQuant.ZSchemaText);
yyTraverseZTreeBU (yyt->schemaQuant.SchemaExp); break;
case kschemaComp:
yyTraverseZTreeBU (yyt->schemaComp.Lop);
yyTraverseZTreeBU (yyt->schemaComp.Rop); break;
case kschemaProject:
yyTraverseZTreeBU (yyt->schemaProject.Lop);
yyTraverseZTreeBU (yyt->schemaProject.Rop); break;
case kschemaPipe:
yyTraverseZTreeBU (yyt->schemaPipe.Lop);
yyTraverseZTreeBU (yyt->schemaPipe.Rop); break;
case kschemaParen:
yyTraverseZTreeBU (yyt->schemaParen.SchemaExp); break;
case kDesignator:
yyTraverseZTreeBU (yyt->Designator.ZName);
yyTraverseZTreeBU (yyt->Designator.Decoration);
yyTraverseZTreeBU (yyt->Designator.ExpressionSeq);
yyTraverseZTreeBU (yyt->Designator.RenameSeq); break;
case kvarNames:
yyTraverseZTreeBU (yyt->varNames.VarName);
yyTraverseZTreeBU (yyt->varNames.Next); break;
case kexpSeq:
yyTraverseZTreeBU (yyt->expSeq.Expression);
yyTraverseZTreeBU (yyt->expSeq.Next); break;
case krenames:
yyTraverseZTreeBU (yyt->renames.VarRename);
yyTraverseZTreeBU (yyt->renames.Next); break;
case kVarRename:
yyTraverseZTreeBU (yyt->VarRename.New);
yyTraverseZTreeBU (yyt->VarRename.Old); break;
case kZSchemaText:
yyTraverseZTreeBU (yyt->ZSchemaText.Declaration);
yyTraverseZTreeBU (yyt->ZSchemaText.Predicate); break;
case kdecl:
yyTraverseZTreeBU (yyt->decl.BasicDecl);
yyTraverseZTreeBU (yyt->decl.Next); break;
case kcolonDecl:
yyTraverseZTreeBU (yyt->colonDecl.VarNameSeq);
yyTraverseZTreeBU (yyt->colonDecl.Expression); break;
case kschemaRef:
yyTraverseZTreeBU (yyt->schemaRef.Designator); break;
case kpredNegate:
yyTraverseZTreeBU (yyt->predNegate.Predicate); break;
case kpredInfixRelSeq:
yyTraverseZTreeBU (yyt->predInfixRelSeq.PredInfixRelSeq); break;
case kpredSchemaRef:
yyTraverseZTreeBU (yyt->predSchemaRef.Designator); break;
case kpredPreRel:
yyTraverseZTreeBU (yyt->predPreRel.Decoration);
yyTraverseZTreeBU (yyt->predPreRel.Expression); break;
case kpredCons:
yyTraverseZTreeBU (yyt->predCons.Lpred);
yyTraverseZTreeBU (yyt->predCons.Rpred); break;
case kpredQuant:
yyTraverseZTreeBU (yyt->predQuant.ZSchemaText);
yyTraverseZTreeBU (yyt->predQuant.Predicate); break;
case kpredLet:
yyTraverseZTreeBU (yyt->predLet.LetDefSeq);
yyTraverseZTreeBU (yyt->predLet.Predicate); break;
case kpredParen:
yyTraverseZTreeBU (yyt->predParen.Predicate); break;
case kinfixRels:
yyTraverseZTreeBU (yyt->infixRels.PredInfixRel);
yyTraverseZTreeBU (yyt->infixRels.Next); break;
case kPredInfixRel:
yyTraverseZTreeBU (yyt->PredInfixRel.Lexp);
yyTraverseZTreeBU (yyt->PredInfixRel.InfixRel);
yyTraverseZTreeBU (yyt->PredInfixRel.Rexp); break;
case kInfixRel:
yyTraverseZTreeBU (yyt->InfixRel.Decoration); break;
case kexpBinaryGen:
yyTraverseZTreeBU (yyt->expBinaryGen.lexp);
yyTraverseZTreeBU (yyt->expBinaryGen.Decoration);
yyTraverseZTreeBU (yyt->expBinaryGen.rexp); break;
case kexpBinaryFun:
yyTraverseZTreeBU (yyt->expBinaryFun.lexp);
yyTraverseZTreeBU (yyt->expBinaryFun.Decoration);
yyTraverseZTreeBU (yyt->expBinaryFun.rexp); break;
case kexpOpname:
yyTraverseZTreeBU (yyt->expOpname.VarName);
yyTraverseZTreeBU (yyt->expOpname.ExpressionSeq); break;
case kexpSetElab:
yyTraverseZTreeBU (yyt->expSetElab.ExpressionSeq); break;
case kexpSeqElab:
yyTraverseZTreeBU (yyt->expSeqElab.ExpressionSeq); break;
case kexpBagElab:
yyTraverseZTreeBU (yyt->expBagElab.ExpressionSeq); break;
case kexpSetComp:
yyTraverseZTreeBU (yyt->expSetComp.ZSchemaText);
yyTraverseZTreeBU (yyt->expSetComp.Expression); break;
case kexpPowerSet:
yyTraverseZTreeBU (yyt->expPowerSet.Expression); break;
case kexpPreGen:
yyTraverseZTreeBU (yyt->expPreGen.Decoration);
yyTraverseZTreeBU (yyt->expPreGen.Expression); break;
case kexpPostFun:
yyTraverseZTreeBU (yyt->expPostFun.Expression);
yyTraverseZTreeBU (yyt->expPostFun.Decoration); break;
case kexpIter:
yyTraverseZTreeBU (yyt->expIter.exp1);
yyTraverseZTreeBU (yyt->expIter.exp2); break;
case kexpTuple:
yyTraverseZTreeBU (yyt->expTuple.ExpressionSeq); break;
case kexpCartProd:
yyTraverseZTreeBU (yyt->expCartProd.ExpressionSeq); break;
case kexpTheta:
yyTraverseZTreeBU (yyt->expTheta.ZName);
yyTraverseZTreeBU (yyt->expTheta.Decoration);
yyTraverseZTreeBU (yyt->expTheta.RenameSeq); break;
case kexpSelectVar:
yyTraverseZTreeBU (yyt->expSelectVar.Expression);
yyTraverseZTreeBU (yyt->expSelectVar.VarName); break;
case kexpFnApp:
yyTraverseZTreeBU (yyt->expFnApp.FnName);
yyTraverseZTreeBU (yyt->expFnApp.Params); break;
case kexpMu:
yyTraverseZTreeBU (yyt->expMu.ZSchemaText);
yyTraverseZTreeBU (yyt->expMu.Expression); break;
case kexpLambda:
yyTraverseZTreeBU (yyt->expLambda.ZSchemaText);
yyTraverseZTreeBU (yyt->expLambda.Expression); break;
case kexpLet:
yyTraverseZTreeBU (yyt->expLet.LetDefSeq);
yyTraverseZTreeBU (yyt->expLet.Expression); break;
case kexpIf:
yyTraverseZTreeBU (yyt->expIf.Predicate);
yyTraverseZTreeBU (yyt->expIf.Exp1);
yyTraverseZTreeBU (yyt->expIf.Exp2); break;
case kexpImage:
yyTraverseZTreeBU (yyt->expImage.Exp1);
yyTraverseZTreeBU (yyt->expImage.Exp2);
yyTraverseZTreeBU (yyt->expImage.Decoration); break;
case kexpDesignator:
yyTraverseZTreeBU (yyt->expDesignator.Designator); break;
case kexpParen:
yyTraverseZTreeBU (yyt->expParen.Expression); break;
case kletDefs:
yyTraverseZTreeBU (yyt->letDefs.LetDef);
yyTraverseZTreeBU (yyt->letDefs.Next); break;
case kLetDef:
yyTraverseZTreeBU (yyt->LetDef.VarName);
yyTraverseZTreeBU (yyt->LetDef.Expression); break;
case kVarName:
yyTraverseZTreeBU (yyt->VarName.Decoration); break;
case kZId:
yyTraverseZTreeBU (yyt->ZId.Decoration); break;
case kOpname:
yyTraverseZTreeBU (yyt->Opname.Decoration); break;
case kdecoration:
yyTraverseZTreeBU (yyt->decoration.Next); break;
 default: ;
 }
 yyProc (yyt);
}

void TraverseZTreeBU
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt, ZTree_tProcTree yyyProc)
# else
 (yyt, yyyProc) tZTree yyt; ZTree_tProcTree yyyProc;
# endif
{
 yyMark (yyt);
 yyProc = yyyProc;
 yyTraverseZTreeBU (yyt);
}

tZTree ReverseZTree
# if defined __STDC__ | defined __cplusplus
 (tZTree yyOld)
# else
 (yyOld) tZTree yyOld;
# endif
{
 register tZTree yyNew, yyNext, yyTail;
 yyNew = yyOld;
 yyTail = yyOld;
 for (;;) {
  switch (yyOld->Kind) {
  default: goto yyExit;
  }
  yyNew = yyOld;
  yyOld = yyNext;
 }
yyExit:
 switch (yyTail->Kind) {
 default: ;
 }
 return yyNew;
}

# define yyInitOldToNewStoreSize 32

typedef struct { tZTree yyOld, yyNew; } yytOldToNew;
static unsigned long yyOldToNewStoreSize = yyInitOldToNewStoreSize;
static yytOldToNew yyOldToNewStore [yyInitOldToNewStoreSize];
static yytOldToNew * yyOldToNewStorePtr = yyOldToNewStore;
static int yyOldToNewCount;

static void yyStoreOldToNew
# if defined __STDC__ | defined __cplusplus
 (tZTree yyOld, tZTree yyNew)
# else
 (yyOld, yyNew) tZTree yyOld, yyNew;
# endif
{
 if (++ yyOldToNewCount == yyOldToNewStoreSize)
  ExtendArray ((char * *) & yyOldToNewStorePtr, & yyOldToNewStoreSize, sizeof (yytOldToNew));
 yyOldToNewStorePtr [yyOldToNewCount].yyOld = yyOld;
 yyOldToNewStorePtr [yyOldToNewCount].yyNew = yyNew;
}

static tZTree yyMapOldToNew
# if defined __STDC__ | defined __cplusplus
 (tZTree yyOld)
# else
 (yyOld) tZTree yyOld;
# endif
{
 register int yyi;
 for (yyi = 1; yyi <= yyOldToNewCount; yyi ++)
  if (yyOldToNewStorePtr [yyi].yyOld == yyOld) return yyOldToNewStorePtr [yyi].yyNew;
}

static tZTree yyCopyZTree
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt, yyPtrtTree yyNew)
# else
 (yyt, yyNew) tZTree yyt; yyPtrtTree yyNew;
# endif
{
 for (;;) {
  if (yyt == NoZTree) { * yyNew = NoZTree; return; }
  if (yyt->yyHead.yyMark == 0) { * yyNew = yyMapOldToNew (yyt); return; }
  yyALLOC (* yyNew, ZTree_NodeSize [yyt->Kind])
  if (yyt->yyHead.yyMark > 1) { yyStoreOldToNew (yyt, * yyNew); }
  yyt->yyHead.yyMark = 0;

  switch (yyt->Kind) {
case kSpecification: (* yyNew)->Specification = yyt->Specification;
yyt = yyt->Specification.GlobalParagraphSeq;
yyNew = & (* yyNew)->Specification.GlobalParagraphSeq; break;
case kGlobalParagraphSeq: (* yyNew)->GlobalParagraphSeq = yyt->GlobalParagraphSeq;
return;
case knoGlobalParagraph: (* yyNew)->noGlobalParagraph = yyt->noGlobalParagraph;
return;
case kglobalParagraphs: (* yyNew)->globalParagraphs = yyt->globalParagraphs;
copytZTree ((* yyNew)->globalParagraphs.GlobalParagraph, yyt->globalParagraphs.GlobalParagraph)
yyt = yyt->globalParagraphs.Next;
yyNew = & (* yyNew)->globalParagraphs.Next; break;
case kGlobalParagraph: (* yyNew)->GlobalParagraph = yyt->GlobalParagraph;
return;
case kaxiomaticDef: (* yyNew)->axiomaticDef = yyt->axiomaticDef;
yyt = yyt->axiomaticDef.ZSchemaText;
yyNew = & (* yyNew)->axiomaticDef.ZSchemaText; break;
case khorizPar: (* yyNew)->horizPar = yyt->horizPar;
yyt = yyt->horizPar.HorizParagraphs;
yyNew = & (* yyNew)->horizPar.HorizParagraphs; break;
case kgenericDef: (* yyNew)->genericDef = yyt->genericDef;
copytZTree ((* yyNew)->genericDef.ZFormalParams, yyt->genericDef.ZFormalParams)
yyt = yyt->genericDef.ZSchemaText;
yyNew = & (* yyNew)->genericDef.ZSchemaText; break;
case kschemaboxDef: (* yyNew)->schemaboxDef = yyt->schemaboxDef;
copytZTree ((* yyNew)->schemaboxDef.ZName, yyt->schemaboxDef.ZName)
copytZTree ((* yyNew)->schemaboxDef.ZFormalParams, yyt->schemaboxDef.ZFormalParams)
yyt = yyt->schemaboxDef.ZSchemaText;
yyNew = & (* yyNew)->schemaboxDef.ZSchemaText; break;
case kHorizParagraphs: (* yyNew)->HorizParagraphs = yyt->HorizParagraphs;
return;
case knoHorizParagraph: (* yyNew)->noHorizParagraph = yyt->noHorizParagraph;
return;
case khorizParagraphs: (* yyNew)->horizParagraphs = yyt->horizParagraphs;
copytZTree ((* yyNew)->horizParagraphs.HorizParagraph, yyt->horizParagraphs.HorizParagraph)
yyt = yyt->horizParagraphs.Next;
yyNew = & (* yyNew)->horizParagraphs.Next; break;
case kHorizParagraph: (* yyNew)->HorizParagraph = yyt->HorizParagraph;
return;
case ktypeDef: (* yyNew)->typeDef = yyt->typeDef;
yyt = yyt->typeDef.TypeDef;
yyNew = & (* yyNew)->typeDef.TypeDef; break;
case kglobalPredicate: (* yyNew)->globalPredicate = yyt->globalPredicate;
yyt = yyt->globalPredicate.Predicate;
yyNew = & (* yyNew)->globalPredicate.Predicate; break;
case kschemaDef: (* yyNew)->schemaDef = yyt->schemaDef;
copytZTree ((* yyNew)->schemaDef.NameFormals, yyt->schemaDef.NameFormals)
yyt = yyt->schemaDef.SchemaExp;
yyNew = & (* yyNew)->schemaDef.SchemaExp; break;
case kTypeDef: (* yyNew)->TypeDef = yyt->TypeDef;
return;
case kgivenSet: (* yyNew)->givenSet = yyt->givenSet;
yyt = yyt->givenSet.VarNameSeq;
yyNew = & (* yyNew)->givenSet.VarNameSeq; break;
case kfreeType: (* yyNew)->freeType = yyt->freeType;
copytZTree ((* yyNew)->freeType.VarName, yyt->freeType.VarName)
yyt = yyt->freeType.BranchSeq;
yyNew = & (* yyNew)->freeType.BranchSeq; break;
case ktypeDef1: (* yyNew)->typeDef1 = yyt->typeDef1;
copytZTree ((* yyNew)->typeDef1.NameFormals, yyt->typeDef1.NameFormals)
yyt = yyt->typeDef1.Expression;
yyNew = & (* yyNew)->typeDef1.Expression; break;
case ktypeDefPregen: (* yyNew)->typeDefPregen = yyt->typeDefPregen;
copytIdPos ((* yyNew)->typeDefPregen.PreGen, yyt->typeDefPregen.PreGen)
copytZTree ((* yyNew)->typeDefPregen.Decoration, yyt->typeDefPregen.Decoration)
copytZTree ((* yyNew)->typeDefPregen.VarName, yyt->typeDefPregen.VarName)
yyt = yyt->typeDefPregen.Expression;
yyNew = & (* yyNew)->typeDefPregen.Expression; break;
case ktypeDefIngen: (* yyNew)->typeDefIngen = yyt->typeDefIngen;
copytZTree ((* yyNew)->typeDefIngen.Var1, yyt->typeDefIngen.Var1)
copytIdPos ((* yyNew)->typeDefIngen.InGen, yyt->typeDefIngen.InGen)
copytZTree ((* yyNew)->typeDefIngen.Decoration, yyt->typeDefIngen.Decoration)
copytZTree ((* yyNew)->typeDefIngen.Var2, yyt->typeDefIngen.Var2)
yyt = yyt->typeDefIngen.Expression;
yyNew = & (* yyNew)->typeDefIngen.Expression; break;
case kNameFormals: (* yyNew)->NameFormals = yyt->NameFormals;
yyt = yyt->NameFormals.VarName;
yyNew = & (* yyNew)->NameFormals.VarName; break;
case knoFormals: (* yyNew)->noFormals = yyt->noFormals;
yyt = yyt->noFormals.VarName;
yyNew = & (* yyNew)->noFormals.VarName; break;
case knameFormals: (* yyNew)->nameFormals = yyt->nameFormals;
copytZTree ((* yyNew)->nameFormals.VarName, yyt->nameFormals.VarName)
yyt = yyt->nameFormals.ZFormalParams;
yyNew = & (* yyNew)->nameFormals.ZFormalParams; break;
case kBranchSeq: (* yyNew)->BranchSeq = yyt->BranchSeq;
return;
case knoBranch: (* yyNew)->noBranch = yyt->noBranch;
return;
case kbranch: (* yyNew)->branch = yyt->branch;
copytZTree ((* yyNew)->branch.ZBranch, yyt->branch.ZBranch)
yyt = yyt->branch.Next;
yyNew = & (* yyNew)->branch.Next; break;
case kZFormalParams: (* yyNew)->ZFormalParams = yyt->ZFormalParams;
return;
case knoFormalParams: (* yyNew)->noFormalParams = yyt->noFormalParams;
return;
case kformalParams: (* yyNew)->formalParams = yyt->formalParams;
yyt = yyt->formalParams.VarNameSeq;
yyNew = & (* yyNew)->formalParams.VarNameSeq; break;
case kZBranch: (* yyNew)->ZBranch = yyt->ZBranch;
return;
case ksimpleBranch: (* yyNew)->simpleBranch = yyt->simpleBranch;
yyt = yyt->simpleBranch.VarName;
yyNew = & (* yyNew)->simpleBranch.VarName; break;
case kcompoundBranch: (* yyNew)->compoundBranch = yyt->compoundBranch;
copytZTree ((* yyNew)->compoundBranch.VarName, yyt->compoundBranch.VarName)
yyt = yyt->compoundBranch.Expression;
yyNew = & (* yyNew)->compoundBranch.Expression; break;
case kSchemaExp: (* yyNew)->SchemaExp = yyt->SchemaExp;
return;
case kschemaSimple: (* yyNew)->schemaSimple = yyt->schemaSimple;
yyt = yyt->schemaSimple.ZSchemaText;
yyNew = & (* yyNew)->schemaSimple.ZSchemaText; break;
case kschemaDes: (* yyNew)->schemaDes = yyt->schemaDes;
yyt = yyt->schemaDes.Designator;
yyNew = & (* yyNew)->schemaDes.Designator; break;
case kschemaPreop: (* yyNew)->schemaPreop = yyt->schemaPreop;
copytIdPos ((* yyNew)->schemaPreop.PreOp, yyt->schemaPreop.PreOp)
yyt = yyt->schemaPreop.SchemaExp;
yyNew = & (* yyNew)->schemaPreop.SchemaExp; break;
case kschemaCons: (* yyNew)->schemaCons = yyt->schemaCons;
copytZTree ((* yyNew)->schemaCons.Lop, yyt->schemaCons.Lop)
copytIdPos ((* yyNew)->schemaCons.SchemaOp, yyt->schemaCons.SchemaOp)
yyt = yyt->schemaCons.Rop;
yyNew = & (* yyNew)->schemaCons.Rop; break;
case kschemaHide: (* yyNew)->schemaHide = yyt->schemaHide;
copytZTree ((* yyNew)->schemaHide.SchemaExp, yyt->schemaHide.SchemaExp)
yyt = yyt->schemaHide.VarNameSeq;
yyNew = & (* yyNew)->schemaHide.VarNameSeq; break;
case kschemaQuant: (* yyNew)->schemaQuant = yyt->schemaQuant;
copytIdPos ((* yyNew)->schemaQuant.LogQuant, yyt->schemaQuant.LogQuant)
copytZTree ((* yyNew)->schemaQuant.ZSchemaText, yyt->schemaQuant.ZSchemaText)
yyt = yyt->schemaQuant.SchemaExp;
yyNew = & (* yyNew)->schemaQuant.SchemaExp; break;
case kschemaComp: (* yyNew)->schemaComp = yyt->schemaComp;
copytZTree ((* yyNew)->schemaComp.Lop, yyt->schemaComp.Lop)
yyt = yyt->schemaComp.Rop;
yyNew = & (* yyNew)->schemaComp.Rop; break;
case kschemaProject: (* yyNew)->schemaProject = yyt->schemaProject;
copytZTree ((* yyNew)->schemaProject.Lop, yyt->schemaProject.Lop)
yyt = yyt->schemaProject.Rop;
yyNew = & (* yyNew)->schemaProject.Rop; break;
case kschemaPipe: (* yyNew)->schemaPipe = yyt->schemaPipe;
copytZTree ((* yyNew)->schemaPipe.Lop, yyt->schemaPipe.Lop)
yyt = yyt->schemaPipe.Rop;
yyNew = & (* yyNew)->schemaPipe.Rop; break;
case kschemaParen: (* yyNew)->schemaParen = yyt->schemaParen;
yyt = yyt->schemaParen.SchemaExp;
yyNew = & (* yyNew)->schemaParen.SchemaExp; break;
case kDesignator: (* yyNew)->Designator = yyt->Designator;
copytZTree ((* yyNew)->Designator.ZName, yyt->Designator.ZName)
copytZTree ((* yyNew)->Designator.Decoration, yyt->Designator.Decoration)
copytZTree ((* yyNew)->Designator.ExpressionSeq, yyt->Designator.ExpressionSeq)
copybool ((* yyNew)->Designator.IsSchemaRef, yyt->Designator.IsSchemaRef)
yyt = yyt->Designator.RenameSeq;
yyNew = & (* yyNew)->Designator.RenameSeq; break;
case kVarNameSeq: (* yyNew)->VarNameSeq = yyt->VarNameSeq;
return;
case knoVarName: (* yyNew)->noVarName = yyt->noVarName;
return;
case kvarNames: (* yyNew)->varNames = yyt->varNames;
copytZTree ((* yyNew)->varNames.VarName, yyt->varNames.VarName)
yyt = yyt->varNames.Next;
yyNew = & (* yyNew)->varNames.Next; break;
case kExpressionSeq: (* yyNew)->ExpressionSeq = yyt->ExpressionSeq;
return;
case knoExpSeq: (* yyNew)->noExpSeq = yyt->noExpSeq;
return;
case kexpSeq: (* yyNew)->expSeq = yyt->expSeq;
copytZTree ((* yyNew)->expSeq.Expression, yyt->expSeq.Expression)
yyt = yyt->expSeq.Next;
yyNew = & (* yyNew)->expSeq.Next; break;
case kRenameSeq: (* yyNew)->RenameSeq = yyt->RenameSeq;
return;
case knoRename: (* yyNew)->noRename = yyt->noRename;
return;
case krenames: (* yyNew)->renames = yyt->renames;
copytZTree ((* yyNew)->renames.VarRename, yyt->renames.VarRename)
yyt = yyt->renames.Next;
yyNew = & (* yyNew)->renames.Next; break;
case kVarRename: (* yyNew)->VarRename = yyt->VarRename;
copytZTree ((* yyNew)->VarRename.New, yyt->VarRename.New)
yyt = yyt->VarRename.Old;
yyNew = & (* yyNew)->VarRename.Old; break;
case kZSchemaText: (* yyNew)->ZSchemaText = yyt->ZSchemaText;
copytZTree ((* yyNew)->ZSchemaText.Declaration, yyt->ZSchemaText.Declaration)
yyt = yyt->ZSchemaText.Predicate;
yyNew = & (* yyNew)->ZSchemaText.Predicate; break;
case kDeclaration: (* yyNew)->Declaration = yyt->Declaration;
return;
case knoDecl: (* yyNew)->noDecl = yyt->noDecl;
return;
case kdecl: (* yyNew)->decl = yyt->decl;
copytZTree ((* yyNew)->decl.BasicDecl, yyt->decl.BasicDecl)
yyt = yyt->decl.Next;
yyNew = & (* yyNew)->decl.Next; break;
case kBasicDecl: (* yyNew)->BasicDecl = yyt->BasicDecl;
return;
case kcolonDecl: (* yyNew)->colonDecl = yyt->colonDecl;
copytZTree ((* yyNew)->colonDecl.VarNameSeq, yyt->colonDecl.VarNameSeq)
yyt = yyt->colonDecl.Expression;
yyNew = & (* yyNew)->colonDecl.Expression; break;
case kschemaRef: (* yyNew)->schemaRef = yyt->schemaRef;
yyt = yyt->schemaRef.Designator;
yyNew = & (* yyNew)->schemaRef.Designator; break;
case kPredicate: (* yyNew)->Predicate = yyt->Predicate;
return;
case knoPred: (* yyNew)->noPred = yyt->noPred;
return;
case kpredNegate: (* yyNew)->predNegate = yyt->predNegate;
yyt = yyt->predNegate.Predicate;
yyNew = & (* yyNew)->predNegate.Predicate; break;
case kpredInfixRelSeq: (* yyNew)->predInfixRelSeq = yyt->predInfixRelSeq;
yyt = yyt->predInfixRelSeq.PredInfixRelSeq;
yyNew = & (* yyNew)->predInfixRelSeq.PredInfixRelSeq; break;
case kpredTrueOrFalse: (* yyNew)->predTrueOrFalse = yyt->predTrueOrFalse;
copytIdPos ((* yyNew)->predTrueOrFalse.TrueFalse, yyt->predTrueOrFalse.TrueFalse)
return;
case kpredSchemaRef: (* yyNew)->predSchemaRef = yyt->predSchemaRef;
copytIdPos ((* yyNew)->predSchemaRef.PredOrPre, yyt->predSchemaRef.PredOrPre)
yyt = yyt->predSchemaRef.Designator;
yyNew = & (* yyNew)->predSchemaRef.Designator; break;
case kpredPreRel: (* yyNew)->predPreRel = yyt->predPreRel;
copytIdPos ((* yyNew)->predPreRel.PreRel, yyt->predPreRel.PreRel)
copytZTree ((* yyNew)->predPreRel.Decoration, yyt->predPreRel.Decoration)
yyt = yyt->predPreRel.Expression;
yyNew = & (* yyNew)->predPreRel.Expression; break;
case kpredCons: (* yyNew)->predCons = yyt->predCons;
copytZTree ((* yyNew)->predCons.Lpred, yyt->predCons.Lpred)
copytIdPos ((* yyNew)->predCons.LogOp, yyt->predCons.LogOp)
yyt = yyt->predCons.Rpred;
yyNew = & (* yyNew)->predCons.Rpred; break;
case kpredQuant: (* yyNew)->predQuant = yyt->predQuant;
copytIdPos ((* yyNew)->predQuant.LogQuant, yyt->predQuant.LogQuant)
copytZTree ((* yyNew)->predQuant.ZSchemaText, yyt->predQuant.ZSchemaText)
yyt = yyt->predQuant.Predicate;
yyNew = & (* yyNew)->predQuant.Predicate; break;
case kpredLet: (* yyNew)->predLet = yyt->predLet;
copytZTree ((* yyNew)->predLet.LetDefSeq, yyt->predLet.LetDefSeq)
yyt = yyt->predLet.Predicate;
yyNew = & (* yyNew)->predLet.Predicate; break;
case kpredParen: (* yyNew)->predParen = yyt->predParen;
yyt = yyt->predParen.Predicate;
yyNew = & (* yyNew)->predParen.Predicate; break;
case kPredInfixRelSeq: (* yyNew)->PredInfixRelSeq = yyt->PredInfixRelSeq;
return;
case knoInfixRel: (* yyNew)->noInfixRel = yyt->noInfixRel;
return;
case kinfixRels: (* yyNew)->infixRels = yyt->infixRels;
copytZTree ((* yyNew)->infixRels.PredInfixRel, yyt->infixRels.PredInfixRel)
yyt = yyt->infixRels.Next;
yyNew = & (* yyNew)->infixRels.Next; break;
case kPredInfixRel: (* yyNew)->PredInfixRel = yyt->PredInfixRel;
copytZTree ((* yyNew)->PredInfixRel.Lexp, yyt->PredInfixRel.Lexp)
copytZTree ((* yyNew)->PredInfixRel.InfixRel, yyt->PredInfixRel.InfixRel)
yyt = yyt->PredInfixRel.Rexp;
yyNew = & (* yyNew)->PredInfixRel.Rexp; break;
case kInfixRel: (* yyNew)->InfixRel = yyt->InfixRel;
copytIdPos ((* yyNew)->InfixRel.InRel, yyt->InfixRel.InRel)
yyt = yyt->InfixRel.Decoration;
yyNew = & (* yyNew)->InfixRel.Decoration; break;
case kExpression: (* yyNew)->Expression = yyt->Expression;
return;
case knoExp: (* yyNew)->noExp = yyt->noExp;
return;
case kexpBinaryGen: (* yyNew)->expBinaryGen = yyt->expBinaryGen;
copytZTree ((* yyNew)->expBinaryGen.lexp, yyt->expBinaryGen.lexp)
copytIdPos ((* yyNew)->expBinaryGen.InGen, yyt->expBinaryGen.InGen)
copytZTree ((* yyNew)->expBinaryGen.Decoration, yyt->expBinaryGen.Decoration)
yyt = yyt->expBinaryGen.rexp;
yyNew = & (* yyNew)->expBinaryGen.rexp; break;
case kexpBinaryFun: (* yyNew)->expBinaryFun = yyt->expBinaryFun;
copytZTree ((* yyNew)->expBinaryFun.lexp, yyt->expBinaryFun.lexp)
copytIdPos ((* yyNew)->expBinaryFun.InFun, yyt->expBinaryFun.InFun)
copytZTree ((* yyNew)->expBinaryFun.Decoration, yyt->expBinaryFun.Decoration)
yyt = yyt->expBinaryFun.rexp;
yyNew = & (* yyNew)->expBinaryFun.rexp; break;
case kexpLiteral: (* yyNew)->expLiteral = yyt->expLiteral;
copytIdPos ((* yyNew)->expLiteral.Literal, yyt->expLiteral.Literal)
return;
case kexpOpname: (* yyNew)->expOpname = yyt->expOpname;
copytZTree ((* yyNew)->expOpname.VarName, yyt->expOpname.VarName)
yyt = yyt->expOpname.ExpressionSeq;
yyNew = & (* yyNew)->expOpname.ExpressionSeq; break;
case kexpSetElab: (* yyNew)->expSetElab = yyt->expSetElab;
yyt = yyt->expSetElab.ExpressionSeq;
yyNew = & (* yyNew)->expSetElab.ExpressionSeq; break;
case kexpSeqElab: (* yyNew)->expSeqElab = yyt->expSeqElab;
yyt = yyt->expSeqElab.ExpressionSeq;
yyNew = & (* yyNew)->expSeqElab.ExpressionSeq; break;
case kexpBagElab: (* yyNew)->expBagElab = yyt->expBagElab;
yyt = yyt->expBagElab.ExpressionSeq;
yyNew = & (* yyNew)->expBagElab.ExpressionSeq; break;
case kexpSetComp: (* yyNew)->expSetComp = yyt->expSetComp;
copytZTree ((* yyNew)->expSetComp.ZSchemaText, yyt->expSetComp.ZSchemaText)
yyt = yyt->expSetComp.Expression;
yyNew = & (* yyNew)->expSetComp.Expression; break;
case kexpPowerSet: (* yyNew)->expPowerSet = yyt->expPowerSet;
yyt = yyt->expPowerSet.Expression;
yyNew = & (* yyNew)->expPowerSet.Expression; break;
case kexpPreGen: (* yyNew)->expPreGen = yyt->expPreGen;
copytIdPos ((* yyNew)->expPreGen.Pregen, yyt->expPreGen.Pregen)
copytZTree ((* yyNew)->expPreGen.Decoration, yyt->expPreGen.Decoration)
yyt = yyt->expPreGen.Expression;
yyNew = & (* yyNew)->expPreGen.Expression; break;
case kexpPostFun: (* yyNew)->expPostFun = yyt->expPostFun;
copytZTree ((* yyNew)->expPostFun.Expression, yyt->expPostFun.Expression)
copytIdPos ((* yyNew)->expPostFun.Postfun, yyt->expPostFun.Postfun)
yyt = yyt->expPostFun.Decoration;
yyNew = & (* yyNew)->expPostFun.Decoration; break;
case kexpIter: (* yyNew)->expIter = yyt->expIter;
copytZTree ((* yyNew)->expIter.exp1, yyt->expIter.exp1)
yyt = yyt->expIter.exp2;
yyNew = & (* yyNew)->expIter.exp2; break;
case kexpTuple: (* yyNew)->expTuple = yyt->expTuple;
yyt = yyt->expTuple.ExpressionSeq;
yyNew = & (* yyNew)->expTuple.ExpressionSeq; break;
case kexpCartProd: (* yyNew)->expCartProd = yyt->expCartProd;
yyt = yyt->expCartProd.ExpressionSeq;
yyNew = & (* yyNew)->expCartProd.ExpressionSeq; break;
case kexpTheta: (* yyNew)->expTheta = yyt->expTheta;
copytZTree ((* yyNew)->expTheta.ZName, yyt->expTheta.ZName)
copytZTree ((* yyNew)->expTheta.Decoration, yyt->expTheta.Decoration)
yyt = yyt->expTheta.RenameSeq;
yyNew = & (* yyNew)->expTheta.RenameSeq; break;
case kexpSelectVar: (* yyNew)->expSelectVar = yyt->expSelectVar;
copytZTree ((* yyNew)->expSelectVar.Expression, yyt->expSelectVar.Expression)
yyt = yyt->expSelectVar.VarName;
yyNew = & (* yyNew)->expSelectVar.VarName; break;
case kexpFnApp: (* yyNew)->expFnApp = yyt->expFnApp;
copytZTree ((* yyNew)->expFnApp.FnName, yyt->expFnApp.FnName)
yyt = yyt->expFnApp.Params;
yyNew = & (* yyNew)->expFnApp.Params; break;
case kexpMu: (* yyNew)->expMu = yyt->expMu;
copytZTree ((* yyNew)->expMu.ZSchemaText, yyt->expMu.ZSchemaText)
yyt = yyt->expMu.Expression;
yyNew = & (* yyNew)->expMu.Expression; break;
case kexpLambda: (* yyNew)->expLambda = yyt->expLambda;
copytZTree ((* yyNew)->expLambda.ZSchemaText, yyt->expLambda.ZSchemaText)
yyt = yyt->expLambda.Expression;
yyNew = & (* yyNew)->expLambda.Expression; break;
case kexpLet: (* yyNew)->expLet = yyt->expLet;
copytZTree ((* yyNew)->expLet.LetDefSeq, yyt->expLet.LetDefSeq)
yyt = yyt->expLet.Expression;
yyNew = & (* yyNew)->expLet.Expression; break;
case kexpIf: (* yyNew)->expIf = yyt->expIf;
copytZTree ((* yyNew)->expIf.Predicate, yyt->expIf.Predicate)
copytZTree ((* yyNew)->expIf.Exp1, yyt->expIf.Exp1)
yyt = yyt->expIf.Exp2;
yyNew = & (* yyNew)->expIf.Exp2; break;
case kexpImage: (* yyNew)->expImage = yyt->expImage;
copytZTree ((* yyNew)->expImage.Exp1, yyt->expImage.Exp1)
copytZTree ((* yyNew)->expImage.Exp2, yyt->expImage.Exp2)
copytIdPos ((* yyNew)->expImage.Image, yyt->expImage.Image)
yyt = yyt->expImage.Decoration;
yyNew = & (* yyNew)->expImage.Decoration; break;
case kexpDesignator: (* yyNew)->expDesignator = yyt->expDesignator;
yyt = yyt->expDesignator.Designator;
yyNew = & (* yyNew)->expDesignator.Designator; break;
case kexpParen: (* yyNew)->expParen = yyt->expParen;
yyt = yyt->expParen.Expression;
yyNew = & (* yyNew)->expParen.Expression; break;
case kLetDefSeq: (* yyNew)->LetDefSeq = yyt->LetDefSeq;
return;
case knoLetDef: (* yyNew)->noLetDef = yyt->noLetDef;
return;
case kletDefs: (* yyNew)->letDefs = yyt->letDefs;
copytZTree ((* yyNew)->letDefs.LetDef, yyt->letDefs.LetDef)
yyt = yyt->letDefs.Next;
yyNew = & (* yyNew)->letDefs.Next; break;
case kLetDef: (* yyNew)->LetDef = yyt->LetDef;
copytZTree ((* yyNew)->LetDef.VarName, yyt->LetDef.VarName)
yyt = yyt->LetDef.Expression;
yyNew = & (* yyNew)->LetDef.Expression; break;
case kVarName: (* yyNew)->VarName = yyt->VarName;
copytIdPos ((* yyNew)->VarName.Ident, yyt->VarName.Ident)
yyt = yyt->VarName.Decoration;
yyNew = & (* yyNew)->VarName.Decoration; break;
case kZId: (* yyNew)->ZId = yyt->ZId;
copytIdPos ((* yyNew)->ZId.Ident, yyt->ZId.Ident)
yyt = yyt->ZId.Decoration;
yyNew = & (* yyNew)->ZId.Decoration; break;
case kOpname: (* yyNew)->Opname = yyt->Opname;
copytIdPos ((* yyNew)->Opname.Ident, yyt->Opname.Ident)
yyt = yyt->Opname.Decoration;
yyNew = & (* yyNew)->Opname.Decoration; break;
case kDecoration: (* yyNew)->Decoration = yyt->Decoration;
return;
case knoDecoration: (* yyNew)->noDecoration = yyt->noDecoration;
return;
case kdecoration: (* yyNew)->decoration = yyt->decoration;
copytIdPos ((* yyNew)->decoration.Stroke, yyt->decoration.Stroke)
yyt = yyt->decoration.Next;
yyNew = & (* yyNew)->decoration.Next; break;
case kZName: (* yyNew)->ZName = yyt->ZName;
copytIdPos ((* yyNew)->ZName.Ident, yyt->ZName.Ident)
return;
  default: ;
  }
 }
}

tZTree CopyZTree
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 tZTree yyNew;
 yyMark (yyt);
 yyOldToNewCount = 0;
 yyCopyZTree (yyt, & yyNew);
 return yyNew;
}

static bool yyCheckZTree ARGS((tZTree yyt));

bool CheckZTree
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyMark (yyt);
 return yyCheckZTree (yyt);
}

static bool yyCheckChild
# if defined __STDC__ | defined __cplusplus
 (tZTree yyParent, tZTree yyyChild, ZTree_tKind yyType, char * yySelector)
# else
 (yyParent, yyyChild, yyType, yySelector)
 tZTree yyParent, yyyChild;
 ZTree_tKind yyType;
 char * yySelector;
# endif
{
 bool yySuccess = ZTree_IsType (yyyChild, yyType);
 if (! yySuccess) {
  (void) fputs ("CheckTree: parent = ", stderr);
  WriteZTreeNode (stderr, yyParent);
  (void) fprintf (stderr, "\nselector: %s child = ", yySelector);
  WriteZTreeNode (stderr, yyyChild);
  (void) fputc ('\n', stderr);
 }
 return yyCheckZTree (yyyChild) && yySuccess;
}

static bool yyCheckZTree
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 bool yyResult;
 if (yyt == NoZTree) return false;
 else if (yyt->yyHead.yyMark == 0) return true;
 yyt->yyHead.yyMark = 0;

 yyResult = true;
 switch (yyt->Kind) {
case kSpecification:
yyResult = yyCheckChild (yyt, yyt->Specification.GlobalParagraphSeq, kGlobalParagraphSeq, "GlobalParagraphSeq") && yyResult;
break;
case kglobalParagraphs:
yyResult = yyCheckChild (yyt, yyt->globalParagraphs.GlobalParagraph, kGlobalParagraph, "GlobalParagraph") && yyResult;
yyResult = yyCheckChild (yyt, yyt->globalParagraphs.Next, kGlobalParagraphSeq, "Next") && yyResult;
break;
case kaxiomaticDef:
yyResult = yyCheckChild (yyt, yyt->axiomaticDef.ZSchemaText, kZSchemaText, "ZSchemaText") && yyResult;
break;
case khorizPar:
yyResult = yyCheckChild (yyt, yyt->horizPar.HorizParagraphs, kHorizParagraphs, "HorizParagraphs") && yyResult;
break;
case kgenericDef:
yyResult = yyCheckChild (yyt, yyt->genericDef.ZFormalParams, kZFormalParams, "ZFormalParams") && yyResult;
yyResult = yyCheckChild (yyt, yyt->genericDef.ZSchemaText, kZSchemaText, "ZSchemaText") && yyResult;
break;
case kschemaboxDef:
yyResult = yyCheckChild (yyt, yyt->schemaboxDef.ZName, kZName, "ZName") && yyResult;
yyResult = yyCheckChild (yyt, yyt->schemaboxDef.ZFormalParams, kZFormalParams, "ZFormalParams") && yyResult;
yyResult = yyCheckChild (yyt, yyt->schemaboxDef.ZSchemaText, kZSchemaText, "ZSchemaText") && yyResult;
break;
case khorizParagraphs:
yyResult = yyCheckChild (yyt, yyt->horizParagraphs.HorizParagraph, kHorizParagraph, "HorizParagraph") && yyResult;
yyResult = yyCheckChild (yyt, yyt->horizParagraphs.Next, kHorizParagraphs, "Next") && yyResult;
break;
case ktypeDef:
yyResult = yyCheckChild (yyt, yyt->typeDef.TypeDef, kTypeDef, "TypeDef") && yyResult;
break;
case kglobalPredicate:
yyResult = yyCheckChild (yyt, yyt->globalPredicate.Predicate, kPredicate, "Predicate") && yyResult;
break;
case kschemaDef:
yyResult = yyCheckChild (yyt, yyt->schemaDef.NameFormals, kNameFormals, "NameFormals") && yyResult;
yyResult = yyCheckChild (yyt, yyt->schemaDef.SchemaExp, kSchemaExp, "SchemaExp") && yyResult;
break;
case kgivenSet:
yyResult = yyCheckChild (yyt, yyt->givenSet.VarNameSeq, kVarNameSeq, "VarNameSeq") && yyResult;
break;
case kfreeType:
yyResult = yyCheckChild (yyt, yyt->freeType.VarName, kVarName, "VarName") && yyResult;
yyResult = yyCheckChild (yyt, yyt->freeType.BranchSeq, kBranchSeq, "BranchSeq") && yyResult;
break;
case ktypeDef1:
yyResult = yyCheckChild (yyt, yyt->typeDef1.NameFormals, kNameFormals, "NameFormals") && yyResult;
yyResult = yyCheckChild (yyt, yyt->typeDef1.Expression, kExpression, "Expression") && yyResult;
break;
case ktypeDefPregen:
yyResult = yyCheckChild (yyt, yyt->typeDefPregen.Decoration, kDecoration, "Decoration") && yyResult;
yyResult = yyCheckChild (yyt, yyt->typeDefPregen.VarName, kVarName, "VarName") && yyResult;
yyResult = yyCheckChild (yyt, yyt->typeDefPregen.Expression, kExpression, "Expression") && yyResult;
break;
case ktypeDefIngen:
yyResult = yyCheckChild (yyt, yyt->typeDefIngen.Var1, kVarName, "Var1") && yyResult;
yyResult = yyCheckChild (yyt, yyt->typeDefIngen.Decoration, kDecoration, "Decoration") && yyResult;
yyResult = yyCheckChild (yyt, yyt->typeDefIngen.Var2, kVarName, "Var2") && yyResult;
yyResult = yyCheckChild (yyt, yyt->typeDefIngen.Expression, kExpression, "Expression") && yyResult;
break;
case kNameFormals:
yyResult = yyCheckChild (yyt, yyt->NameFormals.VarName, kVarName, "VarName") && yyResult;
break;
case knoFormals:
yyResult = yyCheckChild (yyt, yyt->noFormals.VarName, kVarName, "VarName") && yyResult;
break;
case knameFormals:
yyResult = yyCheckChild (yyt, yyt->nameFormals.VarName, kVarName, "VarName") && yyResult;
yyResult = yyCheckChild (yyt, yyt->nameFormals.ZFormalParams, kZFormalParams, "ZFormalParams") && yyResult;
break;
case kbranch:
yyResult = yyCheckChild (yyt, yyt->branch.ZBranch, kZBranch, "ZBranch") && yyResult;
yyResult = yyCheckChild (yyt, yyt->branch.Next, kBranchSeq, "Next") && yyResult;
break;
case kformalParams:
yyResult = yyCheckChild (yyt, yyt->formalParams.VarNameSeq, kVarNameSeq, "VarNameSeq") && yyResult;
break;
case ksimpleBranch:
yyResult = yyCheckChild (yyt, yyt->simpleBranch.VarName, kVarName, "VarName") && yyResult;
break;
case kcompoundBranch:
yyResult = yyCheckChild (yyt, yyt->compoundBranch.VarName, kVarName, "VarName") && yyResult;
yyResult = yyCheckChild (yyt, yyt->compoundBranch.Expression, kExpression, "Expression") && yyResult;
break;
case kschemaSimple:
yyResult = yyCheckChild (yyt, yyt->schemaSimple.ZSchemaText, kZSchemaText, "ZSchemaText") && yyResult;
break;
case kschemaDes:
yyResult = yyCheckChild (yyt, yyt->schemaDes.Designator, kDesignator, "Designator") && yyResult;
break;
case kschemaPreop:
yyResult = yyCheckChild (yyt, yyt->schemaPreop.SchemaExp, kSchemaExp, "SchemaExp") && yyResult;
break;
case kschemaCons:
yyResult = yyCheckChild (yyt, yyt->schemaCons.Lop, kSchemaExp, "Lop") && yyResult;
yyResult = yyCheckChild (yyt, yyt->schemaCons.Rop, kSchemaExp, "Rop") && yyResult;
break;
case kschemaHide:
yyResult = yyCheckChild (yyt, yyt->schemaHide.SchemaExp, kSchemaExp, "SchemaExp") && yyResult;
yyResult = yyCheckChild (yyt, yyt->schemaHide.VarNameSeq, kVarNameSeq, "VarNameSeq") && yyResult;
break;
case kschemaQuant:
yyResult = yyCheckChild (yyt, yyt->schemaQuant.ZSchemaText, kZSchemaText, "ZSchemaText") && yyResult;
yyResult = yyCheckChild (yyt, yyt->schemaQuant.SchemaExp, kSchemaExp, "SchemaExp") && yyResult;
break;
case kschemaComp:
yyResult = yyCheckChild (yyt, yyt->schemaComp.Lop, kSchemaExp, "Lop") && yyResult;
yyResult = yyCheckChild (yyt, yyt->schemaComp.Rop, kSchemaExp, "Rop") && yyResult;
break;
case kschemaProject:
yyResult = yyCheckChild (yyt, yyt->schemaProject.Lop, kSchemaExp, "Lop") && yyResult;
yyResult = yyCheckChild (yyt, yyt->schemaProject.Rop, kSchemaExp, "Rop") && yyResult;
break;
case kschemaPipe:
yyResult = yyCheckChild (yyt, yyt->schemaPipe.Lop, kSchemaExp, "Lop") && yyResult;
yyResult = yyCheckChild (yyt, yyt->schemaPipe.Rop, kSchemaExp, "Rop") && yyResult;
break;
case kschemaParen:
yyResult = yyCheckChild (yyt, yyt->schemaParen.SchemaExp, kSchemaExp, "SchemaExp") && yyResult;
break;
case kDesignator:
yyResult = yyCheckChild (yyt, yyt->Designator.ZName, kZName, "ZName") && yyResult;
yyResult = yyCheckChild (yyt, yyt->Designator.Decoration, kDecoration, "Decoration") && yyResult;
yyResult = yyCheckChild (yyt, yyt->Designator.ExpressionSeq, kExpressionSeq, "ExpressionSeq") && yyResult;
yyResult = yyCheckChild (yyt, yyt->Designator.RenameSeq, kRenameSeq, "RenameSeq") && yyResult;
break;
case kvarNames:
yyResult = yyCheckChild (yyt, yyt->varNames.VarName, kVarName, "VarName") && yyResult;
yyResult = yyCheckChild (yyt, yyt->varNames.Next, kVarNameSeq, "Next") && yyResult;
break;
case kexpSeq:
yyResult = yyCheckChild (yyt, yyt->expSeq.Expression, kExpression, "Expression") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expSeq.Next, kExpressionSeq, "Next") && yyResult;
break;
case krenames:
yyResult = yyCheckChild (yyt, yyt->renames.VarRename, kVarRename, "VarRename") && yyResult;
yyResult = yyCheckChild (yyt, yyt->renames.Next, kRenameSeq, "Next") && yyResult;
break;
case kVarRename:
yyResult = yyCheckChild (yyt, yyt->VarRename.New, kVarName, "New") && yyResult;
yyResult = yyCheckChild (yyt, yyt->VarRename.Old, kVarName, "Old") && yyResult;
break;
case kZSchemaText:
yyResult = yyCheckChild (yyt, yyt->ZSchemaText.Declaration, kDeclaration, "Declaration") && yyResult;
yyResult = yyCheckChild (yyt, yyt->ZSchemaText.Predicate, kPredicate, "Predicate") && yyResult;
break;
case kdecl:
yyResult = yyCheckChild (yyt, yyt->decl.BasicDecl, kBasicDecl, "BasicDecl") && yyResult;
yyResult = yyCheckChild (yyt, yyt->decl.Next, kDeclaration, "Next") && yyResult;
break;
case kcolonDecl:
yyResult = yyCheckChild (yyt, yyt->colonDecl.VarNameSeq, kVarNameSeq, "VarNameSeq") && yyResult;
yyResult = yyCheckChild (yyt, yyt->colonDecl.Expression, kExpression, "Expression") && yyResult;
break;
case kschemaRef:
yyResult = yyCheckChild (yyt, yyt->schemaRef.Designator, kDesignator, "Designator") && yyResult;
break;
case kpredNegate:
yyResult = yyCheckChild (yyt, yyt->predNegate.Predicate, kPredicate, "Predicate") && yyResult;
break;
case kpredInfixRelSeq:
yyResult = yyCheckChild (yyt, yyt->predInfixRelSeq.PredInfixRelSeq, kPredInfixRelSeq, "PredInfixRelSeq") && yyResult;
break;
case kpredSchemaRef:
yyResult = yyCheckChild (yyt, yyt->predSchemaRef.Designator, kDesignator, "Designator") && yyResult;
break;
case kpredPreRel:
yyResult = yyCheckChild (yyt, yyt->predPreRel.Decoration, kDecoration, "Decoration") && yyResult;
yyResult = yyCheckChild (yyt, yyt->predPreRel.Expression, kExpression, "Expression") && yyResult;
break;
case kpredCons:
yyResult = yyCheckChild (yyt, yyt->predCons.Lpred, kPredicate, "Lpred") && yyResult;
yyResult = yyCheckChild (yyt, yyt->predCons.Rpred, kPredicate, "Rpred") && yyResult;
break;
case kpredQuant:
yyResult = yyCheckChild (yyt, yyt->predQuant.ZSchemaText, kZSchemaText, "ZSchemaText") && yyResult;
yyResult = yyCheckChild (yyt, yyt->predQuant.Predicate, kPredicate, "Predicate") && yyResult;
break;
case kpredLet:
yyResult = yyCheckChild (yyt, yyt->predLet.LetDefSeq, kLetDefSeq, "LetDefSeq") && yyResult;
yyResult = yyCheckChild (yyt, yyt->predLet.Predicate, kPredicate, "Predicate") && yyResult;
break;
case kpredParen:
yyResult = yyCheckChild (yyt, yyt->predParen.Predicate, kPredicate, "Predicate") && yyResult;
break;
case kinfixRels:
yyResult = yyCheckChild (yyt, yyt->infixRels.PredInfixRel, kPredInfixRel, "PredInfixRel") && yyResult;
yyResult = yyCheckChild (yyt, yyt->infixRels.Next, kPredInfixRelSeq, "Next") && yyResult;
break;
case kPredInfixRel:
yyResult = yyCheckChild (yyt, yyt->PredInfixRel.Lexp, kExpression, "Lexp") && yyResult;
yyResult = yyCheckChild (yyt, yyt->PredInfixRel.InfixRel, kInfixRel, "InfixRel") && yyResult;
yyResult = yyCheckChild (yyt, yyt->PredInfixRel.Rexp, kExpression, "Rexp") && yyResult;
break;
case kInfixRel:
yyResult = yyCheckChild (yyt, yyt->InfixRel.Decoration, kDecoration, "Decoration") && yyResult;
break;
case kexpBinaryGen:
yyResult = yyCheckChild (yyt, yyt->expBinaryGen.lexp, kExpression, "lexp") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expBinaryGen.Decoration, kDecoration, "Decoration") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expBinaryGen.rexp, kExpression, "rexp") && yyResult;
break;
case kexpBinaryFun:
yyResult = yyCheckChild (yyt, yyt->expBinaryFun.lexp, kExpression, "lexp") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expBinaryFun.Decoration, kDecoration, "Decoration") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expBinaryFun.rexp, kExpression, "rexp") && yyResult;
break;
case kexpOpname:
yyResult = yyCheckChild (yyt, yyt->expOpname.VarName, kVarName, "VarName") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expOpname.ExpressionSeq, kExpressionSeq, "ExpressionSeq") && yyResult;
break;
case kexpSetElab:
yyResult = yyCheckChild (yyt, yyt->expSetElab.ExpressionSeq, kExpressionSeq, "ExpressionSeq") && yyResult;
break;
case kexpSeqElab:
yyResult = yyCheckChild (yyt, yyt->expSeqElab.ExpressionSeq, kExpressionSeq, "ExpressionSeq") && yyResult;
break;
case kexpBagElab:
yyResult = yyCheckChild (yyt, yyt->expBagElab.ExpressionSeq, kExpressionSeq, "ExpressionSeq") && yyResult;
break;
case kexpSetComp:
yyResult = yyCheckChild (yyt, yyt->expSetComp.ZSchemaText, kZSchemaText, "ZSchemaText") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expSetComp.Expression, kExpression, "Expression") && yyResult;
break;
case kexpPowerSet:
yyResult = yyCheckChild (yyt, yyt->expPowerSet.Expression, kExpression, "Expression") && yyResult;
break;
case kexpPreGen:
yyResult = yyCheckChild (yyt, yyt->expPreGen.Decoration, kDecoration, "Decoration") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expPreGen.Expression, kExpression, "Expression") && yyResult;
break;
case kexpPostFun:
yyResult = yyCheckChild (yyt, yyt->expPostFun.Expression, kExpression, "Expression") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expPostFun.Decoration, kDecoration, "Decoration") && yyResult;
break;
case kexpIter:
yyResult = yyCheckChild (yyt, yyt->expIter.exp1, kExpression, "exp1") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expIter.exp2, kExpression, "exp2") && yyResult;
break;
case kexpTuple:
yyResult = yyCheckChild (yyt, yyt->expTuple.ExpressionSeq, kExpressionSeq, "ExpressionSeq") && yyResult;
break;
case kexpCartProd:
yyResult = yyCheckChild (yyt, yyt->expCartProd.ExpressionSeq, kExpressionSeq, "ExpressionSeq") && yyResult;
break;
case kexpTheta:
yyResult = yyCheckChild (yyt, yyt->expTheta.ZName, kZName, "ZName") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expTheta.Decoration, kDecoration, "Decoration") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expTheta.RenameSeq, kRenameSeq, "RenameSeq") && yyResult;
break;
case kexpSelectVar:
yyResult = yyCheckChild (yyt, yyt->expSelectVar.Expression, kExpression, "Expression") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expSelectVar.VarName, kVarName, "VarName") && yyResult;
break;
case kexpFnApp:
yyResult = yyCheckChild (yyt, yyt->expFnApp.FnName, kExpression, "FnName") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expFnApp.Params, kExpression, "Params") && yyResult;
break;
case kexpMu:
yyResult = yyCheckChild (yyt, yyt->expMu.ZSchemaText, kZSchemaText, "ZSchemaText") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expMu.Expression, kExpression, "Expression") && yyResult;
break;
case kexpLambda:
yyResult = yyCheckChild (yyt, yyt->expLambda.ZSchemaText, kZSchemaText, "ZSchemaText") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expLambda.Expression, kExpression, "Expression") && yyResult;
break;
case kexpLet:
yyResult = yyCheckChild (yyt, yyt->expLet.LetDefSeq, kLetDefSeq, "LetDefSeq") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expLet.Expression, kExpression, "Expression") && yyResult;
break;
case kexpIf:
yyResult = yyCheckChild (yyt, yyt->expIf.Predicate, kPredicate, "Predicate") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expIf.Exp1, kExpression, "Exp1") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expIf.Exp2, kExpression, "Exp2") && yyResult;
break;
case kexpImage:
yyResult = yyCheckChild (yyt, yyt->expImage.Exp1, kExpression, "Exp1") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expImage.Exp2, kExpression, "Exp2") && yyResult;
yyResult = yyCheckChild (yyt, yyt->expImage.Decoration, kDecoration, "Decoration") && yyResult;
break;
case kexpDesignator:
yyResult = yyCheckChild (yyt, yyt->expDesignator.Designator, kDesignator, "Designator") && yyResult;
break;
case kexpParen:
yyResult = yyCheckChild (yyt, yyt->expParen.Expression, kExpression, "Expression") && yyResult;
break;
case kletDefs:
yyResult = yyCheckChild (yyt, yyt->letDefs.LetDef, kLetDef, "LetDef") && yyResult;
yyResult = yyCheckChild (yyt, yyt->letDefs.Next, kLetDefSeq, "Next") && yyResult;
break;
case kLetDef:
yyResult = yyCheckChild (yyt, yyt->LetDef.VarName, kVarName, "VarName") && yyResult;
yyResult = yyCheckChild (yyt, yyt->LetDef.Expression, kExpression, "Expression") && yyResult;
break;
case kVarName:
yyResult = yyCheckChild (yyt, yyt->VarName.Decoration, kDecoration, "Decoration") && yyResult;
break;
case kZId:
yyResult = yyCheckChild (yyt, yyt->ZId.Decoration, kDecoration, "Decoration") && yyResult;
break;
case kOpname:
yyResult = yyCheckChild (yyt, yyt->Opname.Decoration, kDecoration, "Decoration") && yyResult;
break;
case kdecoration:
yyResult = yyCheckChild (yyt, yyt->decoration.Next, kDecoration, "Next") && yyResult;
break;
 default: ;
 }
 return yyResult;
}

# define yyyWrite	1
# define yyyRead	2
# define yyyQuit	3

static char yyyString [32], yyCh;
static int yyLength, yyState;

static bool yyyIsEqual
# if defined __STDC__ | defined __cplusplus
 (char * yya)
# else
 (yya) char * yya;
# endif
{
 register int yyi;
 if (yyLength >= 0 && yyyString [yyLength] == ' ') {
  if (yyLength != strlen (yya)) return false;
  for (yyi = 0; yyi < yyLength; yyi ++)
   if (yyyString [yyi] != yya [yyi]) return false;
 } else {
  if (yyLength >= strlen (yya)) return false;
  for (yyi = 0; yyi <= yyLength; yyi ++)
   if (yyyString [yyi] != yya [yyi]) return false;
 }
 return true;
}

void QueryZTree
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt)
# else
 (yyt) tZTree yyt;
# endif
{
 yyState = yyyWrite;
 for (;;) {
  switch (yyState) {
  case yyyQuit : return;
  case yyyWrite: WriteZTreeNode (stdout, yyt); yyState = yyyRead;
  case yyyRead : (void) printf ("? "); yyLength = -1; yyCh = getc (stdin);
   while (yyCh != '\n' && yyCh > 0)
    { yyyString [++ yyLength] = yyCh; yyCh = getc (stdin); }
   if (yyCh < 0) { (void) fputs ("QueryTree: eof reached\n", stderr);
    yyState = yyyQuit; return; }
   if      (yyyIsEqual ("parent")) { yyState = yyyWrite; return; }
   else if (yyyIsEqual ("quit"  )) { yyState = yyyQuit ; return; }
   else if (yyt != NoZTree) {
    switch (yyt->Kind) {
case kSpecification: if (false) ;
else if (yyyIsEqual ("GlobalParagraphSeq")) QueryZTree (yyt->Specification.GlobalParagraphSeq);
break;
case kglobalParagraphs: if (false) ;
else if (yyyIsEqual ("GlobalParagraph")) QueryZTree (yyt->globalParagraphs.GlobalParagraph);
else if (yyyIsEqual ("Next")) QueryZTree (yyt->globalParagraphs.Next);
break;
case kaxiomaticDef: if (false) ;
else if (yyyIsEqual ("ZSchemaText")) QueryZTree (yyt->axiomaticDef.ZSchemaText);
break;
case khorizPar: if (false) ;
else if (yyyIsEqual ("HorizParagraphs")) QueryZTree (yyt->horizPar.HorizParagraphs);
break;
case kgenericDef: if (false) ;
else if (yyyIsEqual ("ZFormalParams")) QueryZTree (yyt->genericDef.ZFormalParams);
else if (yyyIsEqual ("ZSchemaText")) QueryZTree (yyt->genericDef.ZSchemaText);
break;
case kschemaboxDef: if (false) ;
else if (yyyIsEqual ("ZName")) QueryZTree (yyt->schemaboxDef.ZName);
else if (yyyIsEqual ("ZFormalParams")) QueryZTree (yyt->schemaboxDef.ZFormalParams);
else if (yyyIsEqual ("ZSchemaText")) QueryZTree (yyt->schemaboxDef.ZSchemaText);
break;
case khorizParagraphs: if (false) ;
else if (yyyIsEqual ("HorizParagraph")) QueryZTree (yyt->horizParagraphs.HorizParagraph);
else if (yyyIsEqual ("Next")) QueryZTree (yyt->horizParagraphs.Next);
break;
case ktypeDef: if (false) ;
else if (yyyIsEqual ("TypeDef")) QueryZTree (yyt->typeDef.TypeDef);
break;
case kglobalPredicate: if (false) ;
else if (yyyIsEqual ("Predicate")) QueryZTree (yyt->globalPredicate.Predicate);
break;
case kschemaDef: if (false) ;
else if (yyyIsEqual ("NameFormals")) QueryZTree (yyt->schemaDef.NameFormals);
else if (yyyIsEqual ("SchemaExp")) QueryZTree (yyt->schemaDef.SchemaExp);
break;
case kgivenSet: if (false) ;
else if (yyyIsEqual ("VarNameSeq")) QueryZTree (yyt->givenSet.VarNameSeq);
break;
case kfreeType: if (false) ;
else if (yyyIsEqual ("VarName")) QueryZTree (yyt->freeType.VarName);
else if (yyyIsEqual ("BranchSeq")) QueryZTree (yyt->freeType.BranchSeq);
break;
case ktypeDef1: if (false) ;
else if (yyyIsEqual ("NameFormals")) QueryZTree (yyt->typeDef1.NameFormals);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->typeDef1.Expression);
break;
case ktypeDefPregen: if (false) ;
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->typeDefPregen.Decoration);
else if (yyyIsEqual ("VarName")) QueryZTree (yyt->typeDefPregen.VarName);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->typeDefPregen.Expression);
break;
case ktypeDefIngen: if (false) ;
else if (yyyIsEqual ("Var1")) QueryZTree (yyt->typeDefIngen.Var1);
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->typeDefIngen.Decoration);
else if (yyyIsEqual ("Var2")) QueryZTree (yyt->typeDefIngen.Var2);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->typeDefIngen.Expression);
break;
case kNameFormals: if (false) ;
else if (yyyIsEqual ("VarName")) QueryZTree (yyt->NameFormals.VarName);
break;
case knoFormals: if (false) ;
else if (yyyIsEqual ("VarName")) QueryZTree (yyt->noFormals.VarName);
break;
case knameFormals: if (false) ;
else if (yyyIsEqual ("VarName")) QueryZTree (yyt->nameFormals.VarName);
else if (yyyIsEqual ("ZFormalParams")) QueryZTree (yyt->nameFormals.ZFormalParams);
break;
case kbranch: if (false) ;
else if (yyyIsEqual ("ZBranch")) QueryZTree (yyt->branch.ZBranch);
else if (yyyIsEqual ("Next")) QueryZTree (yyt->branch.Next);
break;
case kformalParams: if (false) ;
else if (yyyIsEqual ("VarNameSeq")) QueryZTree (yyt->formalParams.VarNameSeq);
break;
case ksimpleBranch: if (false) ;
else if (yyyIsEqual ("VarName")) QueryZTree (yyt->simpleBranch.VarName);
break;
case kcompoundBranch: if (false) ;
else if (yyyIsEqual ("VarName")) QueryZTree (yyt->compoundBranch.VarName);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->compoundBranch.Expression);
break;
case kschemaSimple: if (false) ;
else if (yyyIsEqual ("ZSchemaText")) QueryZTree (yyt->schemaSimple.ZSchemaText);
break;
case kschemaDes: if (false) ;
else if (yyyIsEqual ("Designator")) QueryZTree (yyt->schemaDes.Designator);
break;
case kschemaPreop: if (false) ;
else if (yyyIsEqual ("SchemaExp")) QueryZTree (yyt->schemaPreop.SchemaExp);
break;
case kschemaCons: if (false) ;
else if (yyyIsEqual ("Lop")) QueryZTree (yyt->schemaCons.Lop);
else if (yyyIsEqual ("Rop")) QueryZTree (yyt->schemaCons.Rop);
break;
case kschemaHide: if (false) ;
else if (yyyIsEqual ("SchemaExp")) QueryZTree (yyt->schemaHide.SchemaExp);
else if (yyyIsEqual ("VarNameSeq")) QueryZTree (yyt->schemaHide.VarNameSeq);
break;
case kschemaQuant: if (false) ;
else if (yyyIsEqual ("ZSchemaText")) QueryZTree (yyt->schemaQuant.ZSchemaText);
else if (yyyIsEqual ("SchemaExp")) QueryZTree (yyt->schemaQuant.SchemaExp);
break;
case kschemaComp: if (false) ;
else if (yyyIsEqual ("Lop")) QueryZTree (yyt->schemaComp.Lop);
else if (yyyIsEqual ("Rop")) QueryZTree (yyt->schemaComp.Rop);
break;
case kschemaProject: if (false) ;
else if (yyyIsEqual ("Lop")) QueryZTree (yyt->schemaProject.Lop);
else if (yyyIsEqual ("Rop")) QueryZTree (yyt->schemaProject.Rop);
break;
case kschemaPipe: if (false) ;
else if (yyyIsEqual ("Lop")) QueryZTree (yyt->schemaPipe.Lop);
else if (yyyIsEqual ("Rop")) QueryZTree (yyt->schemaPipe.Rop);
break;
case kschemaParen: if (false) ;
else if (yyyIsEqual ("SchemaExp")) QueryZTree (yyt->schemaParen.SchemaExp);
break;
case kDesignator: if (false) ;
else if (yyyIsEqual ("ZName")) QueryZTree (yyt->Designator.ZName);
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->Designator.Decoration);
else if (yyyIsEqual ("ExpressionSeq")) QueryZTree (yyt->Designator.ExpressionSeq);
else if (yyyIsEqual ("RenameSeq")) QueryZTree (yyt->Designator.RenameSeq);
break;
case kvarNames: if (false) ;
else if (yyyIsEqual ("VarName")) QueryZTree (yyt->varNames.VarName);
else if (yyyIsEqual ("Next")) QueryZTree (yyt->varNames.Next);
break;
case kexpSeq: if (false) ;
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->expSeq.Expression);
else if (yyyIsEqual ("Next")) QueryZTree (yyt->expSeq.Next);
break;
case krenames: if (false) ;
else if (yyyIsEqual ("VarRename")) QueryZTree (yyt->renames.VarRename);
else if (yyyIsEqual ("Next")) QueryZTree (yyt->renames.Next);
break;
case kVarRename: if (false) ;
else if (yyyIsEqual ("New")) QueryZTree (yyt->VarRename.New);
else if (yyyIsEqual ("Old")) QueryZTree (yyt->VarRename.Old);
break;
case kZSchemaText: if (false) ;
else if (yyyIsEqual ("Declaration")) QueryZTree (yyt->ZSchemaText.Declaration);
else if (yyyIsEqual ("Predicate")) QueryZTree (yyt->ZSchemaText.Predicate);
break;
case kdecl: if (false) ;
else if (yyyIsEqual ("BasicDecl")) QueryZTree (yyt->decl.BasicDecl);
else if (yyyIsEqual ("Next")) QueryZTree (yyt->decl.Next);
break;
case kcolonDecl: if (false) ;
else if (yyyIsEqual ("VarNameSeq")) QueryZTree (yyt->colonDecl.VarNameSeq);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->colonDecl.Expression);
break;
case kschemaRef: if (false) ;
else if (yyyIsEqual ("Designator")) QueryZTree (yyt->schemaRef.Designator);
break;
case kpredNegate: if (false) ;
else if (yyyIsEqual ("Predicate")) QueryZTree (yyt->predNegate.Predicate);
break;
case kpredInfixRelSeq: if (false) ;
else if (yyyIsEqual ("PredInfixRelSeq")) QueryZTree (yyt->predInfixRelSeq.PredInfixRelSeq);
break;
case kpredSchemaRef: if (false) ;
else if (yyyIsEqual ("Designator")) QueryZTree (yyt->predSchemaRef.Designator);
break;
case kpredPreRel: if (false) ;
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->predPreRel.Decoration);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->predPreRel.Expression);
break;
case kpredCons: if (false) ;
else if (yyyIsEqual ("Lpred")) QueryZTree (yyt->predCons.Lpred);
else if (yyyIsEqual ("Rpred")) QueryZTree (yyt->predCons.Rpred);
break;
case kpredQuant: if (false) ;
else if (yyyIsEqual ("ZSchemaText")) QueryZTree (yyt->predQuant.ZSchemaText);
else if (yyyIsEqual ("Predicate")) QueryZTree (yyt->predQuant.Predicate);
break;
case kpredLet: if (false) ;
else if (yyyIsEqual ("LetDefSeq")) QueryZTree (yyt->predLet.LetDefSeq);
else if (yyyIsEqual ("Predicate")) QueryZTree (yyt->predLet.Predicate);
break;
case kpredParen: if (false) ;
else if (yyyIsEqual ("Predicate")) QueryZTree (yyt->predParen.Predicate);
break;
case kinfixRels: if (false) ;
else if (yyyIsEqual ("PredInfixRel")) QueryZTree (yyt->infixRels.PredInfixRel);
else if (yyyIsEqual ("Next")) QueryZTree (yyt->infixRels.Next);
break;
case kPredInfixRel: if (false) ;
else if (yyyIsEqual ("Lexp")) QueryZTree (yyt->PredInfixRel.Lexp);
else if (yyyIsEqual ("InfixRel")) QueryZTree (yyt->PredInfixRel.InfixRel);
else if (yyyIsEqual ("Rexp")) QueryZTree (yyt->PredInfixRel.Rexp);
break;
case kInfixRel: if (false) ;
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->InfixRel.Decoration);
break;
case kexpBinaryGen: if (false) ;
else if (yyyIsEqual ("lexp")) QueryZTree (yyt->expBinaryGen.lexp);
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->expBinaryGen.Decoration);
else if (yyyIsEqual ("rexp")) QueryZTree (yyt->expBinaryGen.rexp);
break;
case kexpBinaryFun: if (false) ;
else if (yyyIsEqual ("lexp")) QueryZTree (yyt->expBinaryFun.lexp);
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->expBinaryFun.Decoration);
else if (yyyIsEqual ("rexp")) QueryZTree (yyt->expBinaryFun.rexp);
break;
case kexpOpname: if (false) ;
else if (yyyIsEqual ("VarName")) QueryZTree (yyt->expOpname.VarName);
else if (yyyIsEqual ("ExpressionSeq")) QueryZTree (yyt->expOpname.ExpressionSeq);
break;
case kexpSetElab: if (false) ;
else if (yyyIsEqual ("ExpressionSeq")) QueryZTree (yyt->expSetElab.ExpressionSeq);
break;
case kexpSeqElab: if (false) ;
else if (yyyIsEqual ("ExpressionSeq")) QueryZTree (yyt->expSeqElab.ExpressionSeq);
break;
case kexpBagElab: if (false) ;
else if (yyyIsEqual ("ExpressionSeq")) QueryZTree (yyt->expBagElab.ExpressionSeq);
break;
case kexpSetComp: if (false) ;
else if (yyyIsEqual ("ZSchemaText")) QueryZTree (yyt->expSetComp.ZSchemaText);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->expSetComp.Expression);
break;
case kexpPowerSet: if (false) ;
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->expPowerSet.Expression);
break;
case kexpPreGen: if (false) ;
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->expPreGen.Decoration);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->expPreGen.Expression);
break;
case kexpPostFun: if (false) ;
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->expPostFun.Expression);
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->expPostFun.Decoration);
break;
case kexpIter: if (false) ;
else if (yyyIsEqual ("exp1")) QueryZTree (yyt->expIter.exp1);
else if (yyyIsEqual ("exp2")) QueryZTree (yyt->expIter.exp2);
break;
case kexpTuple: if (false) ;
else if (yyyIsEqual ("ExpressionSeq")) QueryZTree (yyt->expTuple.ExpressionSeq);
break;
case kexpCartProd: if (false) ;
else if (yyyIsEqual ("ExpressionSeq")) QueryZTree (yyt->expCartProd.ExpressionSeq);
break;
case kexpTheta: if (false) ;
else if (yyyIsEqual ("ZName")) QueryZTree (yyt->expTheta.ZName);
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->expTheta.Decoration);
else if (yyyIsEqual ("RenameSeq")) QueryZTree (yyt->expTheta.RenameSeq);
break;
case kexpSelectVar: if (false) ;
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->expSelectVar.Expression);
else if (yyyIsEqual ("VarName")) QueryZTree (yyt->expSelectVar.VarName);
break;
case kexpFnApp: if (false) ;
else if (yyyIsEqual ("FnName")) QueryZTree (yyt->expFnApp.FnName);
else if (yyyIsEqual ("Params")) QueryZTree (yyt->expFnApp.Params);
break;
case kexpMu: if (false) ;
else if (yyyIsEqual ("ZSchemaText")) QueryZTree (yyt->expMu.ZSchemaText);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->expMu.Expression);
break;
case kexpLambda: if (false) ;
else if (yyyIsEqual ("ZSchemaText")) QueryZTree (yyt->expLambda.ZSchemaText);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->expLambda.Expression);
break;
case kexpLet: if (false) ;
else if (yyyIsEqual ("LetDefSeq")) QueryZTree (yyt->expLet.LetDefSeq);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->expLet.Expression);
break;
case kexpIf: if (false) ;
else if (yyyIsEqual ("Predicate")) QueryZTree (yyt->expIf.Predicate);
else if (yyyIsEqual ("Exp1")) QueryZTree (yyt->expIf.Exp1);
else if (yyyIsEqual ("Exp2")) QueryZTree (yyt->expIf.Exp2);
break;
case kexpImage: if (false) ;
else if (yyyIsEqual ("Exp1")) QueryZTree (yyt->expImage.Exp1);
else if (yyyIsEqual ("Exp2")) QueryZTree (yyt->expImage.Exp2);
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->expImage.Decoration);
break;
case kexpDesignator: if (false) ;
else if (yyyIsEqual ("Designator")) QueryZTree (yyt->expDesignator.Designator);
break;
case kexpParen: if (false) ;
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->expParen.Expression);
break;
case kletDefs: if (false) ;
else if (yyyIsEqual ("LetDef")) QueryZTree (yyt->letDefs.LetDef);
else if (yyyIsEqual ("Next")) QueryZTree (yyt->letDefs.Next);
break;
case kLetDef: if (false) ;
else if (yyyIsEqual ("VarName")) QueryZTree (yyt->LetDef.VarName);
else if (yyyIsEqual ("Expression")) QueryZTree (yyt->LetDef.Expression);
break;
case kVarName: if (false) ;
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->VarName.Decoration);
break;
case kZId: if (false) ;
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->ZId.Decoration);
break;
case kOpname: if (false) ;
else if (yyyIsEqual ("Decoration")) QueryZTree (yyt->Opname.Decoration);
break;
case kdecoration: if (false) ;
else if (yyyIsEqual ("Next")) QueryZTree (yyt->decoration.Next);
break;
    default: ;
    }
   }
  }
 }
}

bool IsEqualZTree
# if defined __STDC__ | defined __cplusplus
 (tZTree yyt1, tZTree yyt2)
# else
 (yyt1, yyt2) tZTree yyt1, yyt2;
# endif
{
 if (yyt1 == NoZTree && yyt2 == NoZTree) return true;
 if (yyt1 == NoZTree || yyt2 == NoZTree || yyt1->Kind != yyt2->Kind) return false;
 switch (yyt1->Kind) {
case kSpecification: return true
&& equaltZTree (yyt1->Specification.GlobalParagraphSeq, yyt2->Specification.GlobalParagraphSeq)
;
case kGlobalParagraphSeq: return true
;
case knoGlobalParagraph: return true
;
case kglobalParagraphs: return true
&& equaltZTree (yyt1->globalParagraphs.GlobalParagraph, yyt2->globalParagraphs.GlobalParagraph)
&& equaltZTree (yyt1->globalParagraphs.Next, yyt2->globalParagraphs.Next)
;
case kGlobalParagraph: return true
;
case kaxiomaticDef: return true
&& equaltZTree (yyt1->axiomaticDef.ZSchemaText, yyt2->axiomaticDef.ZSchemaText)
;
case khorizPar: return true
&& equaltZTree (yyt1->horizPar.HorizParagraphs, yyt2->horizPar.HorizParagraphs)
;
case kgenericDef: return true
&& equaltZTree (yyt1->genericDef.ZFormalParams, yyt2->genericDef.ZFormalParams)
&& equaltZTree (yyt1->genericDef.ZSchemaText, yyt2->genericDef.ZSchemaText)
;
case kschemaboxDef: return true
&& equaltZTree (yyt1->schemaboxDef.ZName, yyt2->schemaboxDef.ZName)
&& equaltZTree (yyt1->schemaboxDef.ZFormalParams, yyt2->schemaboxDef.ZFormalParams)
&& equaltZTree (yyt1->schemaboxDef.ZSchemaText, yyt2->schemaboxDef.ZSchemaText)
;
case kHorizParagraphs: return true
;
case knoHorizParagraph: return true
;
case khorizParagraphs: return true
&& equaltZTree (yyt1->horizParagraphs.HorizParagraph, yyt2->horizParagraphs.HorizParagraph)
&& equaltZTree (yyt1->horizParagraphs.Next, yyt2->horizParagraphs.Next)
;
case kHorizParagraph: return true
;
case ktypeDef: return true
&& equaltZTree (yyt1->typeDef.TypeDef, yyt2->typeDef.TypeDef)
;
case kglobalPredicate: return true
&& equaltZTree (yyt1->globalPredicate.Predicate, yyt2->globalPredicate.Predicate)
;
case kschemaDef: return true
&& equaltZTree (yyt1->schemaDef.NameFormals, yyt2->schemaDef.NameFormals)
&& equaltZTree (yyt1->schemaDef.SchemaExp, yyt2->schemaDef.SchemaExp)
;
case kTypeDef: return true
;
case kgivenSet: return true
&& equaltZTree (yyt1->givenSet.VarNameSeq, yyt2->givenSet.VarNameSeq)
;
case kfreeType: return true
&& equaltZTree (yyt1->freeType.VarName, yyt2->freeType.VarName)
&& equaltZTree (yyt1->freeType.BranchSeq, yyt2->freeType.BranchSeq)
;
case ktypeDef1: return true
&& equaltZTree (yyt1->typeDef1.NameFormals, yyt2->typeDef1.NameFormals)
&& equaltZTree (yyt1->typeDef1.Expression, yyt2->typeDef1.Expression)
;
case ktypeDefPregen: return true
&& (equaltIdPos (yyt1->typeDefPregen.PreGen, yyt2->typeDefPregen.PreGen))
&& equaltZTree (yyt1->typeDefPregen.Decoration, yyt2->typeDefPregen.Decoration)
&& equaltZTree (yyt1->typeDefPregen.VarName, yyt2->typeDefPregen.VarName)
&& equaltZTree (yyt1->typeDefPregen.Expression, yyt2->typeDefPregen.Expression)
;
case ktypeDefIngen: return true
&& equaltZTree (yyt1->typeDefIngen.Var1, yyt2->typeDefIngen.Var1)
&& (equaltIdPos (yyt1->typeDefIngen.InGen, yyt2->typeDefIngen.InGen))
&& equaltZTree (yyt1->typeDefIngen.Decoration, yyt2->typeDefIngen.Decoration)
&& equaltZTree (yyt1->typeDefIngen.Var2, yyt2->typeDefIngen.Var2)
&& equaltZTree (yyt1->typeDefIngen.Expression, yyt2->typeDefIngen.Expression)
;
case kNameFormals: return true
&& equaltZTree (yyt1->NameFormals.VarName, yyt2->NameFormals.VarName)
;
case knoFormals: return true
&& equaltZTree (yyt1->noFormals.VarName, yyt2->noFormals.VarName)
;
case knameFormals: return true
&& equaltZTree (yyt1->nameFormals.VarName, yyt2->nameFormals.VarName)
&& equaltZTree (yyt1->nameFormals.ZFormalParams, yyt2->nameFormals.ZFormalParams)
;
case kBranchSeq: return true
;
case knoBranch: return true
;
case kbranch: return true
&& equaltZTree (yyt1->branch.ZBranch, yyt2->branch.ZBranch)
&& equaltZTree (yyt1->branch.Next, yyt2->branch.Next)
;
case kZFormalParams: return true
;
case knoFormalParams: return true
;
case kformalParams: return true
&& equaltZTree (yyt1->formalParams.VarNameSeq, yyt2->formalParams.VarNameSeq)
;
case kZBranch: return true
;
case ksimpleBranch: return true
&& equaltZTree (yyt1->simpleBranch.VarName, yyt2->simpleBranch.VarName)
;
case kcompoundBranch: return true
&& equaltZTree (yyt1->compoundBranch.VarName, yyt2->compoundBranch.VarName)
&& equaltZTree (yyt1->compoundBranch.Expression, yyt2->compoundBranch.Expression)
;
case kSchemaExp: return true
;
case kschemaSimple: return true
&& equaltZTree (yyt1->schemaSimple.ZSchemaText, yyt2->schemaSimple.ZSchemaText)
;
case kschemaDes: return true
&& equaltZTree (yyt1->schemaDes.Designator, yyt2->schemaDes.Designator)
;
case kschemaPreop: return true
&& (equaltIdPos (yyt1->schemaPreop.PreOp, yyt2->schemaPreop.PreOp))
&& equaltZTree (yyt1->schemaPreop.SchemaExp, yyt2->schemaPreop.SchemaExp)
;
case kschemaCons: return true
&& equaltZTree (yyt1->schemaCons.Lop, yyt2->schemaCons.Lop)
&& (equaltIdPos (yyt1->schemaCons.SchemaOp, yyt2->schemaCons.SchemaOp))
&& equaltZTree (yyt1->schemaCons.Rop, yyt2->schemaCons.Rop)
;
case kschemaHide: return true
&& equaltZTree (yyt1->schemaHide.SchemaExp, yyt2->schemaHide.SchemaExp)
&& equaltZTree (yyt1->schemaHide.VarNameSeq, yyt2->schemaHide.VarNameSeq)
;
case kschemaQuant: return true
&& (equaltIdPos (yyt1->schemaQuant.LogQuant, yyt2->schemaQuant.LogQuant))
&& equaltZTree (yyt1->schemaQuant.ZSchemaText, yyt2->schemaQuant.ZSchemaText)
&& equaltZTree (yyt1->schemaQuant.SchemaExp, yyt2->schemaQuant.SchemaExp)
;
case kschemaComp: return true
&& equaltZTree (yyt1->schemaComp.Lop, yyt2->schemaComp.Lop)
&& equaltZTree (yyt1->schemaComp.Rop, yyt2->schemaComp.Rop)
;
case kschemaProject: return true
&& equaltZTree (yyt1->schemaProject.Lop, yyt2->schemaProject.Lop)
&& equaltZTree (yyt1->schemaProject.Rop, yyt2->schemaProject.Rop)
;
case kschemaPipe: return true
&& equaltZTree (yyt1->schemaPipe.Lop, yyt2->schemaPipe.Lop)
&& equaltZTree (yyt1->schemaPipe.Rop, yyt2->schemaPipe.Rop)
;
case kschemaParen: return true
&& equaltZTree (yyt1->schemaParen.SchemaExp, yyt2->schemaParen.SchemaExp)
;
case kDesignator: return true
&& equaltZTree (yyt1->Designator.ZName, yyt2->Designator.ZName)
&& equaltZTree (yyt1->Designator.Decoration, yyt2->Designator.Decoration)
&& equaltZTree (yyt1->Designator.ExpressionSeq, yyt2->Designator.ExpressionSeq)
&& equaltZTree (yyt1->Designator.RenameSeq, yyt2->Designator.RenameSeq)
&& (equalbool (yyt1->Designator.IsSchemaRef, yyt2->Designator.IsSchemaRef))
;
case kVarNameSeq: return true
;
case knoVarName: return true
;
case kvarNames: return true
&& equaltZTree (yyt1->varNames.VarName, yyt2->varNames.VarName)
&& equaltZTree (yyt1->varNames.Next, yyt2->varNames.Next)
;
case kExpressionSeq: return true
;
case knoExpSeq: return true
;
case kexpSeq: return true
&& equaltZTree (yyt1->expSeq.Expression, yyt2->expSeq.Expression)
&& equaltZTree (yyt1->expSeq.Next, yyt2->expSeq.Next)
;
case kRenameSeq: return true
;
case knoRename: return true
;
case krenames: return true
&& equaltZTree (yyt1->renames.VarRename, yyt2->renames.VarRename)
&& equaltZTree (yyt1->renames.Next, yyt2->renames.Next)
;
case kVarRename: return true
&& equaltZTree (yyt1->VarRename.New, yyt2->VarRename.New)
&& equaltZTree (yyt1->VarRename.Old, yyt2->VarRename.Old)
;
case kZSchemaText: return true
&& equaltZTree (yyt1->ZSchemaText.Declaration, yyt2->ZSchemaText.Declaration)
&& equaltZTree (yyt1->ZSchemaText.Predicate, yyt2->ZSchemaText.Predicate)
;
case kDeclaration: return true
;
case knoDecl: return true
;
case kdecl: return true
&& equaltZTree (yyt1->decl.BasicDecl, yyt2->decl.BasicDecl)
&& equaltZTree (yyt1->decl.Next, yyt2->decl.Next)
;
case kBasicDecl: return true
;
case kcolonDecl: return true
&& equaltZTree (yyt1->colonDecl.VarNameSeq, yyt2->colonDecl.VarNameSeq)
&& equaltZTree (yyt1->colonDecl.Expression, yyt2->colonDecl.Expression)
;
case kschemaRef: return true
&& equaltZTree (yyt1->schemaRef.Designator, yyt2->schemaRef.Designator)
;
case kPredicate: return true
;
case knoPred: return true
;
case kpredNegate: return true
&& equaltZTree (yyt1->predNegate.Predicate, yyt2->predNegate.Predicate)
;
case kpredInfixRelSeq: return true
&& equaltZTree (yyt1->predInfixRelSeq.PredInfixRelSeq, yyt2->predInfixRelSeq.PredInfixRelSeq)
;
case kpredTrueOrFalse: return true
&& (equaltIdPos (yyt1->predTrueOrFalse.TrueFalse, yyt2->predTrueOrFalse.TrueFalse))
;
case kpredSchemaRef: return true
&& (equaltIdPos (yyt1->predSchemaRef.PredOrPre, yyt2->predSchemaRef.PredOrPre))
&& equaltZTree (yyt1->predSchemaRef.Designator, yyt2->predSchemaRef.Designator)
;
case kpredPreRel: return true
&& (equaltIdPos (yyt1->predPreRel.PreRel, yyt2->predPreRel.PreRel))
&& equaltZTree (yyt1->predPreRel.Decoration, yyt2->predPreRel.Decoration)
&& equaltZTree (yyt1->predPreRel.Expression, yyt2->predPreRel.Expression)
;
case kpredCons: return true
&& equaltZTree (yyt1->predCons.Lpred, yyt2->predCons.Lpred)
&& (equaltIdPos (yyt1->predCons.LogOp, yyt2->predCons.LogOp))
&& equaltZTree (yyt1->predCons.Rpred, yyt2->predCons.Rpred)
;
case kpredQuant: return true
&& (equaltIdPos (yyt1->predQuant.LogQuant, yyt2->predQuant.LogQuant))
&& equaltZTree (yyt1->predQuant.ZSchemaText, yyt2->predQuant.ZSchemaText)
&& equaltZTree (yyt1->predQuant.Predicate, yyt2->predQuant.Predicate)
;
case kpredLet: return true
&& equaltZTree (yyt1->predLet.LetDefSeq, yyt2->predLet.LetDefSeq)
&& equaltZTree (yyt1->predLet.Predicate, yyt2->predLet.Predicate)
;
case kpredParen: return true
&& equaltZTree (yyt1->predParen.Predicate, yyt2->predParen.Predicate)
;
case kPredInfixRelSeq: return true
;
case knoInfixRel: return true
;
case kinfixRels: return true
&& equaltZTree (yyt1->infixRels.PredInfixRel, yyt2->infixRels.PredInfixRel)
&& equaltZTree (yyt1->infixRels.Next, yyt2->infixRels.Next)
;
case kPredInfixRel: return true
&& equaltZTree (yyt1->PredInfixRel.Lexp, yyt2->PredInfixRel.Lexp)
&& equaltZTree (yyt1->PredInfixRel.InfixRel, yyt2->PredInfixRel.InfixRel)
&& equaltZTree (yyt1->PredInfixRel.Rexp, yyt2->PredInfixRel.Rexp)
;
case kInfixRel: return true
&& (equaltIdPos (yyt1->InfixRel.InRel, yyt2->InfixRel.InRel))
&& equaltZTree (yyt1->InfixRel.Decoration, yyt2->InfixRel.Decoration)
;
case kExpression: return true
;
case knoExp: return true
;
case kexpBinaryGen: return true
&& equaltZTree (yyt1->expBinaryGen.lexp, yyt2->expBinaryGen.lexp)
&& (equaltIdPos (yyt1->expBinaryGen.InGen, yyt2->expBinaryGen.InGen))
&& equaltZTree (yyt1->expBinaryGen.Decoration, yyt2->expBinaryGen.Decoration)
&& equaltZTree (yyt1->expBinaryGen.rexp, yyt2->expBinaryGen.rexp)
;
case kexpBinaryFun: return true
&& equaltZTree (yyt1->expBinaryFun.lexp, yyt2->expBinaryFun.lexp)
&& (equaltIdPos (yyt1->expBinaryFun.InFun, yyt2->expBinaryFun.InFun))
&& equaltZTree (yyt1->expBinaryFun.Decoration, yyt2->expBinaryFun.Decoration)
&& equaltZTree (yyt1->expBinaryFun.rexp, yyt2->expBinaryFun.rexp)
;
case kexpLiteral: return true
&& (equaltIdPos (yyt1->expLiteral.Literal, yyt2->expLiteral.Literal))
;
case kexpOpname: return true
&& equaltZTree (yyt1->expOpname.VarName, yyt2->expOpname.VarName)
&& equaltZTree (yyt1->expOpname.ExpressionSeq, yyt2->expOpname.ExpressionSeq)
;
case kexpSetElab: return true
&& equaltZTree (yyt1->expSetElab.ExpressionSeq, yyt2->expSetElab.ExpressionSeq)
;
case kexpSeqElab: return true
&& equaltZTree (yyt1->expSeqElab.ExpressionSeq, yyt2->expSeqElab.ExpressionSeq)
;
case kexpBagElab: return true
&& equaltZTree (yyt1->expBagElab.ExpressionSeq, yyt2->expBagElab.ExpressionSeq)
;
case kexpSetComp: return true
&& equaltZTree (yyt1->expSetComp.ZSchemaText, yyt2->expSetComp.ZSchemaText)
&& equaltZTree (yyt1->expSetComp.Expression, yyt2->expSetComp.Expression)
;
case kexpPowerSet: return true
&& equaltZTree (yyt1->expPowerSet.Expression, yyt2->expPowerSet.Expression)
;
case kexpPreGen: return true
&& (equaltIdPos (yyt1->expPreGen.Pregen, yyt2->expPreGen.Pregen))
&& equaltZTree (yyt1->expPreGen.Decoration, yyt2->expPreGen.Decoration)
&& equaltZTree (yyt1->expPreGen.Expression, yyt2->expPreGen.Expression)
;
case kexpPostFun: return true
&& equaltZTree (yyt1->expPostFun.Expression, yyt2->expPostFun.Expression)
&& (equaltIdPos (yyt1->expPostFun.Postfun, yyt2->expPostFun.Postfun))
&& equaltZTree (yyt1->expPostFun.Decoration, yyt2->expPostFun.Decoration)
;
case kexpIter: return true
&& equaltZTree (yyt1->expIter.exp1, yyt2->expIter.exp1)
&& equaltZTree (yyt1->expIter.exp2, yyt2->expIter.exp2)
;
case kexpTuple: return true
&& equaltZTree (yyt1->expTuple.ExpressionSeq, yyt2->expTuple.ExpressionSeq)
;
case kexpCartProd: return true
&& equaltZTree (yyt1->expCartProd.ExpressionSeq, yyt2->expCartProd.ExpressionSeq)
;
case kexpTheta: return true
&& equaltZTree (yyt1->expTheta.ZName, yyt2->expTheta.ZName)
&& equaltZTree (yyt1->expTheta.Decoration, yyt2->expTheta.Decoration)
&& equaltZTree (yyt1->expTheta.RenameSeq, yyt2->expTheta.RenameSeq)
;
case kexpSelectVar: return true
&& equaltZTree (yyt1->expSelectVar.Expression, yyt2->expSelectVar.Expression)
&& equaltZTree (yyt1->expSelectVar.VarName, yyt2->expSelectVar.VarName)
;
case kexpFnApp: return true
&& equaltZTree (yyt1->expFnApp.FnName, yyt2->expFnApp.FnName)
&& equaltZTree (yyt1->expFnApp.Params, yyt2->expFnApp.Params)
;
case kexpMu: return true
&& equaltZTree (yyt1->expMu.ZSchemaText, yyt2->expMu.ZSchemaText)
&& equaltZTree (yyt1->expMu.Expression, yyt2->expMu.Expression)
;
case kexpLambda: return true
&& equaltZTree (yyt1->expLambda.ZSchemaText, yyt2->expLambda.ZSchemaText)
&& equaltZTree (yyt1->expLambda.Expression, yyt2->expLambda.Expression)
;
case kexpLet: return true
&& equaltZTree (yyt1->expLet.LetDefSeq, yyt2->expLet.LetDefSeq)
&& equaltZTree (yyt1->expLet.Expression, yyt2->expLet.Expression)
;
case kexpIf: return true
&& equaltZTree (yyt1->expIf.Predicate, yyt2->expIf.Predicate)
&& equaltZTree (yyt1->expIf.Exp1, yyt2->expIf.Exp1)
&& equaltZTree (yyt1->expIf.Exp2, yyt2->expIf.Exp2)
;
case kexpImage: return true
&& equaltZTree (yyt1->expImage.Exp1, yyt2->expImage.Exp1)
&& equaltZTree (yyt1->expImage.Exp2, yyt2->expImage.Exp2)
&& (equaltIdPos (yyt1->expImage.Image, yyt2->expImage.Image))
&& equaltZTree (yyt1->expImage.Decoration, yyt2->expImage.Decoration)
;
case kexpDesignator: return true
&& equaltZTree (yyt1->expDesignator.Designator, yyt2->expDesignator.Designator)
;
case kexpParen: return true
&& equaltZTree (yyt1->expParen.Expression, yyt2->expParen.Expression)
;
case kLetDefSeq: return true
;
case knoLetDef: return true
;
case kletDefs: return true
&& equaltZTree (yyt1->letDefs.LetDef, yyt2->letDefs.LetDef)
&& equaltZTree (yyt1->letDefs.Next, yyt2->letDefs.Next)
;
case kLetDef: return true
&& equaltZTree (yyt1->LetDef.VarName, yyt2->LetDef.VarName)
&& equaltZTree (yyt1->LetDef.Expression, yyt2->LetDef.Expression)
;
case kVarName: return true
&& (equaltIdPos (yyt1->VarName.Ident, yyt2->VarName.Ident))
&& equaltZTree (yyt1->VarName.Decoration, yyt2->VarName.Decoration)
;
case kZId: return true
&& (equaltIdPos (yyt1->ZId.Ident, yyt2->ZId.Ident))
&& equaltZTree (yyt1->ZId.Decoration, yyt2->ZId.Decoration)
;
case kOpname: return true
&& (equaltIdPos (yyt1->Opname.Ident, yyt2->Opname.Ident))
&& equaltZTree (yyt1->Opname.Decoration, yyt2->Opname.Decoration)
;
case kDecoration: return true
;
case knoDecoration: return true
;
case kdecoration: return true
&& (equaltIdPos (yyt1->decoration.Stroke, yyt2->decoration.Stroke))
&& equaltZTree (yyt1->decoration.Next, yyt2->decoration.Next)
;
case kZName: return true
&& (equaltIdPos (yyt1->ZName.Ident, yyt2->ZName.Ident))
;
 default: return true;
 }
}

void BeginZTree ()
{
}

void CloseZTree ()
{
}
