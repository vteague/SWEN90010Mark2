# include "SymAccess.h"
# include "yySymAccess.w"
# include "System.h"
# include <stdio.h>
# include "Tree.h"
# include "Syms.h"
# include "Type.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 38 "objects.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include <string.h>
#include <stdlib.h> 
#include "Idents.h"
#include "Tree.h"
#include "Type.h"
#include "Syms.h"
#include "Positions.h"
#include "ratc.h"
#include "TypeAccess.h"


#ifndef GENREC
  #define GENREC
  /* structure for storing local generic types */
  struct LGrec {
	tType local;
	struct LGrec *next;
  };

  typedef struct LGrec * LGList;
  LGList LocalGenPtr=NULL; /* start of the local generic list */
  LGList EndOfModGens=NULL; /* end of the current moduless generics */

  /* structure to store previous module generic pointers for nested generic module cases */
  struct MGRec {
	LGList mlist; /* end of generics for this module */
	struct MGRec *prev;
	struct MGRec *next;
  };
  typedef struct MGRec * MGList;
  MGList CurrentModGenPtr=NULL;
#endif




static void yyExit () { Exit (1); }

void (* SymAccess_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module SymAccess, routine %s failed\n", yyFunction);
 SymAccess_Exit ();
}

static tObjects MoveToLastObject ARGS((tSyms decs));
tObjects InitSymTab ARGS((tTree yyP1));
static void GetIdentString ARGS((tTree yyP2, tString str));
tIdent FormtIdent ARGS((tTree idlist));
void SetModGenParameters ARGS((tSyms decs));
void ResetModGenParameters ARGS(());
void SetLocalGenParameters ARGS((tSyms decs));
static void CollectGenParamType ARGS((tSyms yyP3, LGList lg));
void ResetLocalGenParamPtr ARGS(());
bool IsLocalGeneric ARGS((tType ty));
static void PrintLocalGenParams ARGS(());
bool PredIsBool ARGS((tTree yyP4));
static bool CouldBeSchemaRef ARGS((tSyms yyP5));
static bool SchemaRefTypeIsSchema ARGS((tSyms yyP6));
static tIdent ObjectModId ARGS((tSyms yyP7));
static void SubsDeclList ARGS((tSyms * decls, FAList fahead));
tType SubsTy ARGS((tType ty, FAList fahead));
static tType SubsCart ARGS((tType c, FAList fahead));
static tType SubsSchema ARGS((tType sch, FAList fahead));
static tType SubsTyB ARGS((tType ty, FAList fahead));
static tIdent QuantId ARGS((tTree idlist));
static void GetStrokes ARGS((tTree idlist, tString str));
static tTree UnPrimedIdList ARGS((tTree idlist));
static tType ObjectType ARGS((tSyms yyP8));
static bool ParamCompInner ARGS((tSyms f, tTree a));
bool ParamComp ARGS((tSyms f, tTree a));
FAList SchFAComInner ARGS((tSyms yyP9, tTree a));
FAList SchFACom ARGS((tSyms yyP10, tTree a));
tObjects SchemaInclH ARGS((tSyms declsin, tTree idlist, tTree actparams, tIdent * modidptr));
tPosition NonBoolPredPos ARGS((tTree yyP11));

static tObjects MoveToLastObject
# if defined __STDC__ | defined __cplusplus
(register tSyms decs)
# else
(decs)
 register tSyms decs;
# endif
{
/* line 87 "objects.puma" */
tObjects decls;
  if (decs == NULL) {
/* line 88 "objects.puma" */
   return NoSym;

  }
  if (decs->Kind == kNoObject) {
/* line 89 "objects.puma" */
   return mNoObject ();

  }
  if (Syms_IsType (decs, kObject)) {
/* line 90 "objects.puma" */
  {
/* line 91 "objects.puma" */
if (Syms_IsType(decs->Object.Next,kObject))
		decls = MoveToLastObject(decs->Object.Next);
	else decls = decs;
  }
   return decls;

  }
 yyAbort ("MoveToLastObject");
}

tObjects InitSymTab
# if defined __STDC__ | defined __cplusplus
(register tTree yyP1)
# else
(yyP1)
 register tTree yyP1;
# endif
{
/* line 97 "objects.puma" */
tObjects decls=mNoObject();
  if (yyP1->Kind == kNoModule) {
/* line 98 "objects.puma" */
   return decls;

  }
  if (yyP1->Kind == kModule) {
/* line 99 "objects.puma" */
  {
/* line 100 "objects.puma" */
tIdPos mathid;
		tObjects declsin=mNoObject();
    		char *mathpath=NULL;
    		char path[MathPathLength];
		IML_List iml;

		if (yyP1->Module.Ident.Ident!=Ident_math) { 
	
	
    			path[0] = '\0';
    			mathpath = getenv ("MATHPATH");
    			if (mathpath==NULL || mathpath[0] == '\0') {
        			strcat (path, "math");}
    			else
        			strcat (strcat (path, mathpath), "/math");
	
    			mathid.Ident = MakeIdent (path, strlen(path)); 
    			mathid.Pos = NoPosition; 
    			declsin = ReadModule (mathid, &iml, NoIdent);

	
	
		if (Syms_IsType(declsin,kObject))
        		declsin->Object.Pre = mNoObject();
	
		decls = MoveToLastObject(declsin);}
  }
   return decls;

  }
 yyAbort ("InitSymTab");
}

static void GetIdentString
# if defined __STDC__ | defined __cplusplus
(register tTree yyP2, tString str)
# else
(yyP2, str)
 register tTree yyP2;
 tString str;
# endif
{
  if (yyP2->Kind == kNoId) {
/* line 130 "objects.puma" */
   return;

  }
  if (yyP2->Kind == kId) {
/* line 131 "objects.puma" */
  {
/* line 132 "objects.puma" */
char str1[IDENT_LENGTH];
	
		GetString(yyP2->Id.Ident.Ident,str1);
	
		strcat(str,str1);
	
		if (Tree_IsType(yyP2->Id.Next,kId))
			{strcat(str,".");
			GetIdentString(yyP2->Id.Next,str);}
  }
   return;

  }
;
}

tIdent FormtIdent
# if defined __STDC__ | defined __cplusplus
(register tTree idlist)
# else
(idlist)
 register tTree idlist;
# endif
{
/* line 144 "objects.puma" */
tIdent id=NoIdent;
  if (idlist->Kind == kNoId) {
/* line 145 "objects.puma" */
   return id;

  }
  if (idlist->Kind == kId) {
/* line 146 "objects.puma" */
  {
/* line 147 "objects.puma" */
char str[IDENT_LENGTH];
		tString ptrtostr=str;
		str[0]='\0';
	
		GetIdentString(idlist,ptrtostr);
	
		id = MakeIdent(str,strlen(str));
  }
   return id;

  }
 yyAbort ("FormtIdent");
}

void SetModGenParameters
# if defined __STDC__ | defined __cplusplus
(register tSyms decs)
# else
(decs)
 register tSyms decs;
# endif
{
  if (decs->Kind == kObj_Tmp) {
  if (Syms_IsType (decs->Obj_Tmp.Inner, kObject)) {
/* line 157 "objects.puma" */
  {
/* line 158 "objects.puma" */
MGList link=CurrentModGenPtr;
		LGList ptr=NULL;
		if (!link) {
	
			link = (MGList) my_malloc(sizeof(struct MGRec));
			link->prev = NULL;
			link->next = NULL;}
	
		else {
			link->next = (MGList) my_malloc(sizeof(struct MGRec));
			link = link->next;
			link->prev = CurrentModGenPtr;
			link->next = NULL;}
		CurrentModGenPtr = link;
		CollectGenParamType(decs->Obj_Tmp.Inner,NULL);
	
		ptr = LocalGenPtr;
		while (ptr && ptr->next)
			ptr = ptr->next;
		link->mlist = ptr;
		EndOfModGens = ptr;
  }
   return;

  }
  }
/* line 179 "objects.puma" */
   return;

;
}

void ResetModGenParameters
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
/* line 183 "objects.puma" */
  {
/* line 184 "objects.puma" */
MGList link=CurrentModGenPtr;
	LGList ptr=NULL;
	if (link) {
	
		CurrentModGenPtr = link->prev;
		CurrentModGenPtr->next = NULL;
		EndOfModGens = CurrentModGenPtr->mlist;} 
	else 
		EndOfModGens = NULL;
  }
   return;

;
}

void SetLocalGenParameters
# if defined __STDC__ | defined __cplusplus
(register tSyms decs)
# else
(decs)
 register tSyms decs;
# endif
{
  if (decs->Kind == kObj_Tmp) {
  if (Syms_IsType (decs->Obj_Tmp.Inner, kObject)) {
/* line 196 "objects.puma" */
  {
/* line 197 "objects.puma" */
CollectGenParamType(decs->Obj_Tmp.Inner,EndOfModGens);
  }
   return;

  }
  }
/* line 198 "objects.puma" */
   return;

;
}

static void CollectGenParamType
# if defined __STDC__ | defined __cplusplus
(register tSyms yyP3, LGList lg)
# else
(yyP3, lg)
 register tSyms yyP3;
 LGList lg;
# endif
{
  if (yyP3 == NULL) {
/* line 202 "objects.puma" */
   return;

  }
  if (yyP3->Kind == kObj_PTyId) {
/* line 203 "objects.puma" */
  {
/* line 204 "objects.puma" */
LGList lglink=lg;
		if (lglink) {

			lglink->next= (LGList) my_malloc(sizeof(struct LGrec));
			lglink = lglink->next;
			lglink->local = yyP3->Obj_PTyId.Type;
			lglink->next = NULL;}
		else {

			lglink = (LGList) my_malloc(sizeof(struct LGrec));
			lglink->local = yyP3->Obj_PTyId.Type;
			lglink->next = NULL;

			LocalGenPtr = lglink;}
			CollectGenParamType(yyP3->Obj_PTyId.Next,lglink);
  }
   return;

  }
/* line 219 "objects.puma" */
   return;

;
}

void ResetLocalGenParamPtr
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
/* line 223 "objects.puma" */
  {
/* line 224 "objects.puma" */
if (CurrentModGenPtr) {
		EndOfModGens->next = NULL;} 
	else {
		LocalGenPtr = NULL;
		EndOfModGens = NULL;}
  }
   return;

;
}

bool IsLocalGeneric
# if defined __STDC__ | defined __cplusplus
(register tType ty)
# else
(ty)
 register tType ty;
# endif
{
/* line 233 "objects.puma" */
  {
/* line 234 "objects.puma" */
LGList link=LocalGenPtr;
	bool found=false;
	while (link&&!found) {
		if (link->local==ty) found=true;
		link=link->next;}
/* line 239 "objects.puma" */
   if (! ((found))) goto yyL1;
  }
   return true;
yyL1:;

  return false;
}

static void PrintLocalGenParams
# if defined __STDC__ | defined __cplusplus
()
# else
()
# endif
{
/* line 243 "objects.puma" */
  {
/* line 243 "objects.puma" */

		LGList link=LocalGenPtr;
		printf("\nLocal Parmaeters\n");
		while (link) {
			printf("\ntype is:");
			WriteType(stdout,link->local);
			link = link->next;}
  }
   return;

;
}

bool PredIsBool
# if defined __STDC__ | defined __cplusplus
(register tTree yyP4)
# else
(yyP4)
 register tTree yyP4;
# endif
{
  if (yyP4->Kind == kNoPred) {
/* line 253 "objects.puma" */
   return true;

  }
  if (Tree_IsType (yyP4, kPred)) {
/* line 254 "objects.puma" */
  {
/* line 255 "objects.puma" */
   if (! ((IsBoolOrSchRef (yyP4->Pred.Type) && PredIsBool (yyP4->Pred.Next)))) goto yyL2;
  }
   return true;
yyL2:;

  }
  return false;
}

static bool CouldBeSchemaRef
# if defined __STDC__ | defined __cplusplus
(register tSyms yyP5)
# else
(yyP5)
 register tSyms yyP5;
# endif
{
  if (yyP5->Kind == kObj_TyId) {
/* line 259 "objects.puma" */
   return true;

  }
  if (yyP5->Kind == kObj_Id) {
/* line 260 "objects.puma" */
   return true;

  }
  if (yyP5->Kind == kObj_Tmp) {
/* line 261 "objects.puma" */
   return true;

  }
  if (Syms_IsType (yyP5, kObj_Param)) {
/* line 262 "objects.puma" */
   return true;

  }
  if (yyP5->Kind == kObj_Inn) {
/* line 263 "objects.puma" */
  {
/* line 263 "objects.puma" */
   if (! ((yyP5->Obj_Inn.ObjKind != Obj_schema))) goto yyL5;
  }
   return true;
yyL5:;

  }
  return false;
}

static bool SchemaRefTypeIsSchema
# if defined __STDC__ | defined __cplusplus
(register tSyms yyP6)
# else
(yyP6)
 register tSyms yyP6;
# endif
{
  if (yyP6->Kind == kObj_Inn) {
  if (yyP6->Obj_Inn.Type->Kind == kTp_Schema) {
/* line 267 "objects.puma" */
  {
/* line 267 "objects.puma" */
   if (! ((yyP6->Obj_Inn.ObjKind != Obj_schema))) goto yyL1;
  }
   return true;
yyL1:;

  }
  }
  if (yyP6->Kind == kObj_TyId) {
  if (yyP6->Obj_TyId.Type->Kind == kTp_Schema) {
/* line 268 "objects.puma" */
   return true;

  }
  }
  if (yyP6->Kind == kObj_Id) {
  if (yyP6->Obj_Id.Type->Kind == kTp_Schema) {
/* line 269 "objects.puma" */
   return true;

  }
  }
  if (yyP6->Kind == kObj_Tmp) {
  if (yyP6->Obj_Tmp.Type->Kind == kTp_Schema) {
/* line 270 "objects.puma" */
   return true;

  }
  }
  if (Syms_IsType (yyP6, kObj_Param)) {
  if (yyP6->Obj_Param.Type->Kind == kTp_Schema) {
/* line 271 "objects.puma" */
   return true;

  }
  }
  return false;
}

static tIdent ObjectModId
# if defined __STDC__ | defined __cplusplus
(register tSyms yyP7)
# else
(yyP7)
 register tSyms yyP7;
# endif
{
  if (yyP7 == NULL) {
/* line 275 "objects.puma" */
   return NoIdent;

  }
  if (Syms_IsType (yyP7, kObject)) {
/* line 276 "objects.puma" */
   return yyP7->Object.ModId;

  }
/* line 277 "objects.puma" */
   return NoIdent;

}

static void SubsDeclList
# if defined __STDC__ | defined __cplusplus
(register tSyms * decls, FAList fahead)
# else
(decls, fahead)
 register tSyms * decls;
 FAList fahead;
# endif
{
  if ((* decls) == NULL) {
/* line 281 "objects.puma" */
   return;

  }
  if ((* decls)->Kind == kNoObject) {
/* line 282 "objects.puma" */
   return;

  }
  if (Syms_IsType ((* decls), kObject)) {
/* line 283 "objects.puma" */
  {
/* line 284 "objects.puma" */
(* decls)->Object.Type = SubsTy((* decls)->Object.Type,fahead);
		SubsDeclList(&(* decls)->Object.Next,fahead);
  }
   return;

  }
/* line 286 "objects.puma" */
   return;

;
}

tType SubsTy
# if defined __STDC__ | defined __cplusplus
(register tType ty, FAList fahead)
# else
(ty, fahead)
 register tType ty;
 FAList fahead;
# endif
{
/* line 290 "objects.puma" */
tType rtype;
  if (fahead == NULL) {
/* line 291 "objects.puma" */
   return NoType;

  }
/* line 292 "objects.puma" */
  {
/* line 293 "objects.puma" */
int found=0;
		FAList link=fahead;
		rtype = NoType;
	
		while (!found && link) {
			if (ty==link->fty) {
				found=1;
				rtype=link->aty;}
			else link = link->next;}

	
		if (rtype);
		else
			rtype = SubsTyB(ty,fahead);
  }
   return rtype;

}

static tType SubsCart
# if defined __STDC__ | defined __cplusplus
(register tType c, FAList fahead)
# else
(c, fahead)
 register tType c;
 FAList fahead;
# endif
{
  if (c == NULL) {
/* line 310 "objects.puma" */
   return NoType;

  }
  if (c->Kind == kTp_NoCart) {
/* line 311 "objects.puma" */
   return mTp_NoCart ();

  }
  if (c->Kind == kTp_Cart) {
/* line 312 "objects.puma" */
   return mTp_Cart (SubsCart (c->Tp_Cart.Next, fahead), SubsTy (c->Tp_Cart.Tp_Exp, fahead));

  }
 yyAbort ("SubsCart");
}

static tType SubsSchema
# if defined __STDC__ | defined __cplusplus
(register tType sch, FAList fahead)
# else
(sch, fahead)
 register tType sch;
 FAList fahead;
# endif
{
  if (sch == NULL) {
/* line 317 "objects.puma" */
   return NoType;

  }
  if (sch->Kind == kTp_NoSchField) {
/* line 318 "objects.puma" */
   return mTp_NoSchField ();

  }
  if (sch->Kind == kTp_SchField) {
/* line 319 "objects.puma" */
   return mTp_SchField (SubsSchema (sch->Tp_SchField.Next, fahead), sch->Tp_SchField.ModId, sch->Tp_SchField.Ident, SubsTy (sch->Tp_SchField.Tp_Exp, fahead), sch->Tp_SchField.QuId);

  }
 yyAbort ("SubsSchema");
}

static tType SubsTyB
# if defined __STDC__ | defined __cplusplus
(register tType ty, FAList fahead)
# else
(ty, fahead)
 register tType ty;
 FAList fahead;
# endif
{
/* line 324 "objects.puma" */
tType rtype;
  if (ty == NULL) {
/* line 325 "objects.puma" */
  {
/* line 325 "objects.puma" */
rtype=ty;
  }
   return rtype;

  }

  switch (ty->Kind) {
  case kTp_Poly:
/* line 326 "objects.puma" */
  {
/* line 331 "objects.puma" */
rtype = ty;
  }
   return rtype;

  case kTp_Err:
/* line 332 "objects.puma" */
   return ty;

  case kTp_Any:
/* line 333 "objects.puma" */
   return ty;

  case kTp_Base:
/* line 334 "objects.puma" */
   return ty;

  case kTp_Power:
/* line 335 "objects.puma" */
   return mTp_Power (NoIdent, ty->Tp_Power.Ident, SubsTy (ty->Tp_Power.Tp_Exp, fahead));

  case kTp_Seq:
/* line 337 "objects.puma" */
   return mTp_Seq (NoIdent, ty->Tp_Seq.Ident, SubsTy (ty->Tp_Seq.Tp_Exp, fahead));

  case kTp_Prefix:
/* line 339 "objects.puma" */
   return mTp_Prefix (NoIdent, ty->Tp_Prefix.Ident, SubsTy (ty->Tp_Prefix.Tp_Exp, fahead));

  case kTp_Infix:
/* line 341 "objects.puma" */
   return mTp_Infix (NoIdent, ty->Tp_Infix.Ident, SubsTy (ty->Tp_Infix.Fst, fahead), SubsTy (ty->Tp_Infix.Snd, fahead));

  case kTp_CartProd:
/* line 343 "objects.puma" */
   return mTp_CartProd (NoIdent, ty->Tp_CartProd.Ident, SubsCart (ty->Tp_CartProd.Tp_CartList, fahead));

  case kTp_Schema:
/* line 345 "objects.puma" */
   return mTp_Schema (NoIdent, ty->Tp_Schema.Ident, SubsSchema (ty->Tp_Schema.Tp_SchFieldList, fahead));

  }

 yyAbort ("SubsTyB");
}

static tIdent QuantId
# if defined __STDC__ | defined __cplusplus
(register tTree idlist)
# else
(idlist)
 register tTree idlist;
# endif
{
/* line 352 "objects.puma" */
tIdent id=NoIdent;
  if (idlist == NULL) {
/* line 353 "objects.puma" */
   return id;

  }
  if (idlist->Kind == kNoId) {
/* line 354 "objects.puma" */
   return id;

  }
  if (idlist->Kind == kId) {
  if (idlist->Id.Next->Kind == kNoId) {
/* line 355 "objects.puma" */
   return id;

  }
  if (idlist->Id.Next->Kind == kId) {
  if (idlist->Id.Next->Id.Next->Kind == kId) {
/* line 357 "objects.puma" */
   return QuantId (idlist->Id.Next);

  }
/* line 359 "objects.puma" */
  {
/* line 360 "objects.puma" */
tTree lastid;
	
		lastid = idlist->Id.Next;
		idlist->Id.Next = mNoId();
		id = FormtIdent(idlist);
	
		idlist->Id.Next = lastid;
  }
   return id;

  }
/* line 369 "objects.puma" */
   return id;

  }
 yyAbort ("QuantId");
}

static void GetStrokes
# if defined __STDC__ | defined __cplusplus
(register tTree idlist, tString str)
# else
(idlist, str)
 register tTree idlist;
 tString str;
# endif
{
  if (idlist == NULL) {
/* line 373 "objects.puma" */
   return;

  }
  if (idlist->Kind == kNoId) {
/* line 374 "objects.puma" */
   return;

  }
  if (idlist->Kind == kId) {
  if (idlist->Id.Next->Kind == kId) {
/* line 376 "objects.puma" */
  {
/* line 376 "objects.puma" */
GetStrokes(idlist->Id.Next,str);
  }
   return;

  }
/* line 378 "objects.puma" */
  {
/* line 379 "objects.puma" */
char str1[IDENT_LENGTH];
		int i;
		strcpy(str,"");
		GetString(idlist->Id.Ident.Ident,str1);
		for (i=0;i<strlen(str1);i++)
			if (str1[i]=='\'') {
				strcpy(str,str1+i);
				break;}
  }
   return;

  }
;
}

static tTree UnPrimedIdList
# if defined __STDC__ | defined __cplusplus
(register tTree idlist)
# else
(idlist)
 register tTree idlist;
# endif
{
/* line 390 "objects.puma" */
tTree unprimed=mNoId();
  if (idlist == NULL) {
/* line 391 "objects.puma" */
   return unprimed;

  }
  if (idlist->Kind == kNoId) {
/* line 392 "objects.puma" */
   return unprimed;

  }
  if (idlist->Kind == kId) {
  if (idlist->Id.Next->Kind == kId) {
/* line 394 "objects.puma" */
   return mId (UnPrimedIdList (idlist->Id.Next), idlist->Id.Ident, idlist->Id.IdKind);

  }
/* line 397 "objects.puma" */
  {
/* line 398 "objects.puma" */
char str[IDENT_LENGTH];
		int j=0;
		bool done=false;
		GetString(idlist->Id.Ident.Ident,str);
		while (!done && (j<strlen(str))) {
			if (str[j]=='\'') {
			
				str[j]='\0';
				done = true;}
			else j++;}
		unprimed = mId(mNoId(),ZMakeIdPos(str,idlist->Id.Ident.Pos),idlist->Id.IdKind);
  }
   return unprimed;

  }
 yyAbort ("UnPrimedIdList");
}

static tType ObjectType
# if defined __STDC__ | defined __cplusplus
(register tSyms yyP8)
# else
(yyP8)
 register tSyms yyP8;
# endif
{
  if (yyP8 == NULL) {
/* line 412 "objects.puma" */
   return NoType;

  }
  if (Syms_IsType (yyP8, kObject)) {
/* line 413 "objects.puma" */
   return yyP8->Object.Type;

  }
/* line 414 "objects.puma" */
   return NoType;

}

static bool ParamCompInner
# if defined __STDC__ | defined __cplusplus
(register tSyms f, register tTree a)
# else
(f, a)
 register tSyms f;
 register tTree a;
# endif
{
  if (f->Kind == kObj_Inn) {
/* line 418 "objects.puma" */
  {
/* line 418 "objects.puma" */
   if (! (ParamComp (f->Obj_Inn.Inner, a))) goto yyL1;
  }
   return true;
yyL1:;

  }
/* line 419 "objects.puma" */
  {
/* line 419 "objects.puma" */
   if (! (((! f || Syms_IsType (f, kNoObject)) && (! a || Tree_IsType (a, kNoExp))))) goto yyL2;
  }
   return true;
yyL2:;

  return false;
}

bool ParamComp
# if defined __STDC__ | defined __cplusplus
(register tSyms f, register tTree a)
# else
(f, a)
 register tSyms f;
 register tTree a;
# endif
{
  if (Syms_IsType (f, kObj_Param)) {
  if (a == NULL) {
/* line 423 "objects.puma" */
  {
/* line 423 "objects.puma" */
   return false;
  }

  }
  if (a->Kind == kNoExp) {
/* line 424 "objects.puma" */
  {
/* line 424 "objects.puma" */
   return false;
  }

  }
  }
  if (a == NULL) {
/* line 425 "objects.puma" */
   return true;

  }
  if (a->Kind == kNoExp) {
/* line 426 "objects.puma" */
   return true;

  }
  if (f->Kind == kObj_PTyId) {
  if (Tree_IsType (a, kExp)) {
/* line 427 "objects.puma" */
  {
/* line 428 "objects.puma" */
   if (! ((a->Exp.IsTypeExp && ParamComp (f->Obj_PTyId.Next, a->Exp.Next)))) goto yyL5;
  }
   return true;
yyL5:;

  if (a->Exp.Type->Kind == kTp_Power) {
/* line 429 "objects.puma" */
  {
/* line 430 "objects.puma" */
   if (! (ParamComp (f->Obj_PTyId.Next, a->Exp.Next))) goto yyL6;
  }
   return true;
yyL6:;

  }
  }
  }
  if (f->Kind == kObj_PId) {
  if (Tree_IsType (a, kExp)) {
/* line 431 "objects.puma" */
  {
/* line 432 "objects.puma" */
   if (! ((a->Exp.IsTypeExp && ParamComp (f->Obj_PId.Next, a->Exp.Next)))) goto yyL7;
  }
   return true;
yyL7:;

  if (a->Exp.Type->Kind == kTp_Power) {
/* line 433 "objects.puma" */
  {
/* line 434 "objects.puma" */
   if (! (ParamComp (f->Obj_PId.Next, a->Exp.Next))) goto yyL8;
  }
   return true;
yyL8:;

  }
  }
  }
/* line 435 "objects.puma" */
   return true;

}

FAList SchFAComInner
# if defined __STDC__ | defined __cplusplus
(register tSyms yyP9, register tTree a)
# else
(yyP9, a)
 register tSyms yyP9;
 register tTree a;
# endif
{
/* line 439 "objects.puma" */
FAList fahead=NULL;
  if (a->Kind == kNoExp) {
/* line 440 "objects.puma" */
   return fahead;

  }
  if (yyP9->Kind == kObj_Inn) {
/* line 441 "objects.puma" */
   return SchFACom (yyP9->Obj_Inn.Inner, a);

  }
/* line 442 "objects.puma" */
   return fahead;

}

FAList SchFACom
# if defined __STDC__ | defined __cplusplus
(register tSyms yyP10, register tTree a)
# else
(yyP10, a)
 register tSyms yyP10;
 register tTree a;
# endif
{
/* line 446 "objects.puma" */
FAList fahead=NULL;
  if (Syms_IsType (yyP10, kObject)) {
  if (Tree_IsType (a, kExp)) {
/* line 447 "objects.puma" */
  {
/* line 448 "objects.puma" */
fahead = (FAList) my_malloc(sizeof (struct FArec));
		fahead->next = SchFACom(yyP10->Object.Next,a->Exp.Next);
		fahead->fty = yyP10->Object.Type;
		fahead->aty = a->Exp.Type;
  }
   return fahead;

  }
  }
/* line 452 "objects.puma" */
   return fahead;

}

tObjects SchemaInclH
# if defined __STDC__ | defined __cplusplus
(register tSyms declsin, register tTree idlist, register tTree actparams, tIdent * modidptr)
# else
(declsin, idlist, actparams, modidptr)
 register tSyms declsin;
 register tTree idlist;
 register tTree actparams;
 tIdent * modidptr;
# endif
{
/* line 461 "objects.puma" */
tObjects decllist=NoSym;
  if (idlist == NULL) {
/* line 462 "objects.puma" */
  {
/* line 462 "objects.puma" */
decllist=declsin;
  }
   return decllist;

  }
  if (idlist->Kind == kNoId) {
/* line 463 "objects.puma" */
  {
/* line 463 "objects.puma" */
decllist=declsin;
  }
   return decllist;

  }
  if (idlist->Kind == kId) {
/* line 464 "objects.puma" */
  {
/* line 465 "objects.puma" */
tObjects sym_ptr = NoSym;  
    		tPosition pos;      
    		bool primed = 0;    
    		FAList fahead=NULL;
    		tIdent QuId=NoIdent;  

		tTree unprimedList; 
		char str[IDENT_LENGTH];/* last component of idlist->Id.Ident for prime stripping*/
		char strokes[IDENT_LENGTH];/* or storing primes taken off str */
		tString ptrtostr; 
		tString ptrtostrokes; 

	
		QuId = QuantId(idlist);

	
		ptrtostrokes = strokes;
		GetStrokes(idlist,ptrtostrokes);

	
		unprimedList = UnPrimedIdList(idlist);

	
		primed = (strcmp(strokes,"")==0) ? false : true;

	
		sym_ptr =  LookUpName (declsin, unprimedList, NoSym);

    	
    		pos = idlist->Id.Ident.Pos;
		if (!sym_ptr || Syms_IsType(sym_ptr,kNoObject)) {
        		Error (pos, error11);
        		decllist = declsin;}
		else {

	
		(* modidptr) = ObjectModId(sym_ptr);

	
	
		if (CouldBeSchemaRef(sym_ptr)) 
			if (SchemaRefTypeIsSchema(sym_ptr)) {
				if (primed)
					decllist = SchInclD(declsin,ObjectType(sym_ptr),strokes,pos,0,QuId);
				else
					decllist = SchIncl(declsin,ObjectType(sym_ptr),pos,0,QuId);}
			else {
        			Error (pos, error9);
				decllist = declsin;}
		else {

	
		if (!ParamCompInner(sym_ptr,actparams)) {
			Error (pos, error3);
			decllist=declsin;}
		else {

	
		fahead = SchFAComInner(sym_ptr,actparams);
		if (!fahead) { 
			if (primed)
				decllist = SchInclD(declsin,ObjectType(sym_ptr),strokes,pos,0,QuId);
			else
				decllist = SchIncl(declsin,ObjectType(sym_ptr),pos,0,QuId);}
		else { 
 			if (primed)
				decllist = SchInclD(declsin,ObjectType(sym_ptr),strokes,pos,1,QuId);
			else
				decllist = SchIncl(declsin,ObjectType(sym_ptr),pos,1,QuId);

		
			SubsDeclList(&decllist,fahead);
			MoveToLastObject(decllist);}}}}
  }
   return decllist;

  }
 yyAbort ("SchemaInclH");
}

tPosition NonBoolPredPos
# if defined __STDC__ | defined __cplusplus
(register tTree yyP11)
# else
(yyP11)
 register tTree yyP11;
# endif
{
/* line 541 "objects.puma" */
tPosition posn;
  if (yyP11->Kind == kNoPred) {
/* line 542 "objects.puma" */
   return NoPosition;

  }
  if (Tree_IsType (yyP11, kPred)) {
/* line 543 "objects.puma" */
  {
/* line 544 "objects.puma" */
if (IsBoolOrSchRef(yyP11->Pred.Type)) 
			posn = NonBoolPredPos(yyP11->Pred.Next);
		 else posn = yyP11->Pred.Pos;
  }
   return posn;

  }
 yyAbort ("NonBoolPredPos");
}

void BeginSymAccess ()
{
}

void CloseSymAccess ()
{
}
