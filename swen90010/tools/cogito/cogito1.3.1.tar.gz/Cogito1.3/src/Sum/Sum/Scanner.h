# ifndef yyScanner
# define yyScanner

/* $Id: Scanner.h,v 2.6 1992/08/07 15:29:41 grosch rel $ */

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

/* line 10 "sum.rex" */

# include "Idents.h"
# include "ratc.h"
# include "Positions.h"
# include "global.h"
# include <string.h>
#define Debug

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

typedef struct { tPosition yyPos; tIdPos Ident; } yyId;
typedef struct { tPosition yyPos; tIdPos Ident; } yyNumber;
typedef struct { tPosition yyPos; tIdPos Ident; } yyString;
typedef struct { tPosition yyPos; tIdPos Ident; } yyChar;
typedef struct { tPosition yyPos; tIdPos Ident; } yyPrefix;
typedef struct { tPosition yyPos; tIdPos Ident; } yyInGen;
typedef struct { tPosition yyPos; tIdPos Ident; } yyInRelOp;
typedef struct { tPosition yyPos; tIdPos Ident; } yyPreRelOp;
typedef struct { tPosition yyPos; tIdPos Ident; } yyQuantifier;
typedef struct { tPosition yyPos; tIdPos Ident; } yyBoolValue;

typedef union {
 tPosition Position;
 yyId Id;
 yyNumber Number;
 yyString String;
 yyChar Char;
 yyPrefix Prefix;
 yyInGen InGen;
 yyInRelOp InRelOp;
 yyPreRelOp PreRelOp;
 yyQuantifier Quantifier;
 yyBoolValue BoolValue;
} tScanAttribute;

extern void ErrorAttribute ARGS((int Token, tScanAttribute * pAttribute));


/* data structure to record refinement comments */

struct RefComm { char *comm; struct RefComm *next; };
typedef struct RefComm * RefCommLink;
extern RefCommLink ref_comm_head; 

extern void AddRefComm();

/* Data structure to capture c++ style comments and their position */
/* exported here for translation */

struct CppComm { char *comm; tPosition pos; struct CppComm *next; };
typedef struct CppComm * CppCommLink;

extern CppCommLink cpp_comm_head; 
extern CppCommLink cpp_comm_tail; 

extern void PrintCppComms();

/* structure to record tabs (t1,t2,t3) in sum input and strip them out
   the tabs are put back into latex output
*/
struct tabbing { char *tab;tPosition pos;struct tabbing *next;};
typedef struct tabbing * tabbing_link;

extern tabbing_link tabbing_head;
extern tabbing_link tabbing_tail;

 
# define EofToken	0
 
# ifdef lex_interface
#    define GetToken	yylex
#    define TokenLength	yyleng
# endif

extern	char *		TokenPtr	;
extern	short		TokenLength	;
extern	tScanAttribute	Attribute	;
extern	void		(* Scanner_Exit) ()	;
 
extern	void		BeginScanner	();
extern	void		BeginFile	ARGS ((char * yyFileName));
extern	int		GetToken	();
extern	int		GetWord		ARGS ((char * yyWord));
extern	int		GetLower	ARGS ((char * yyWord));
extern	int		GetUpper	ARGS ((char * yyWord));
extern	void		CloseFile	();
extern	void		CloseScanner	();

# endif
