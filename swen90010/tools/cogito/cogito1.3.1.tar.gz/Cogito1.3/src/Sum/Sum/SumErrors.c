# include "SumErrors.h"
# include "yySumErrors.w"
# include "System.h"
# include <stdio.h>
# include "Tree.h"
# include "Type.h"

# define yyInline
# ifndef NULL
# define NULL 0L
# endif
# ifndef false
# define false 0
# endif
# ifndef true
# define true 1
# endif

# ifdef yyInline
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) \
  if ((ptr = (tree) free) >= (tree) max) ptr = alloc (); \
  free += nodesize [kind]; \
  ptr->yyHead.yyMark = 0; \
  ptr->Kind = kind;
# else
# define yyALLOC(tree, free, max, alloc, nodesize, make, ptr, kind) ptr = make (kind);
# endif

# define yyWrite(s) (void) fputs (s, stdout)
# define yyWriteNl (void) fputc ('\n', stdout)

/* line 14 "sumerrors.puma" */

/*		 Copyright (C) 1999
		 Software Verification Research Centre
		 The University of Queensland
		 Australia 4072
*/
#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "env.h"
#include "DecodeType.h"
#ifdef TKGUI
  #define fileptr stdout
#else
  #define fileptr stderr
#endif


static void yyExit () { Exit (1); }

void (* SumErrors_Exit) () = yyExit;


static void yyAbort
# ifdef __cplusplus
 (char * yyFunction)
# else
 (yyFunction) char * yyFunction;
# endif
{
 (void) fprintf (stderr, "Error: module SumErrors, routine %s failed\n", yyFunction);
 SumErrors_Exit ();
}

void ErrorInSetElab ARGS((tType t));
void ErrorInFnType ARGS((tType f));
void ErrorInParams ARGS((tType ftype, tType argtype, int i));
void ErrorInFnResult ARGS((tType ftype, tType rtype));
void ErrorInPrefixNoArg ARGS((tIdent preId));
void ErrorInPrefix ARGS((tIdent preId, tType argtype));
void ErrorInInfix ARGS((tIdent inId, tType ltype, tType rtype));
void NoMoreFncOverloads ARGS((tType ftype, tType argtype));
void NoMorePrefixOverloads ARGS((tIdent preId, tType ftype, tType argtype));
void NoMoreInfixOverloads ARGS((tIdent inId, tType ftype, tType ltype, tType rtype));
static void LocalWriteIdPos ARGS((tIdPos id));
static void UnparseIdList ARGS((tTree yyP1));
void ErrorInName ARGS((tTree id));
void ErrorInThetaName ARGS((tType exp));

void ErrorInSetElab
# if defined __STDC__ | defined __cplusplus
(register tType t)
# else
(t)
 register tType t;
# endif
{
  if (t->Kind == kTp_NoCart) {
/* line 35 "sumerrors.puma" */
   return;

  }
/* line 36 "sumerrors.puma" */
  {
/* line 37 "sumerrors.puma" */
fprintf(fileptr,"      set display types are :\n      {");
		DecodeTpCartList(t,',');
		fprintf(fileptr,"}\n");
  }
   return;

;
}

void ErrorInFnType
# if defined __STDC__ | defined __cplusplus
(register tType f)
# else
(f)
 register tType f;
# endif
{
/* line 43 "sumerrors.puma" */
  {
/* line 44 "sumerrors.puma" */
fprintf(fileptr,"      type given: ");
	DecodeType(f);
	fprintf(fileptr,"\n\n");
  }
   return;

;
}

void ErrorInParams
# if defined __STDC__ | defined __cplusplus
(register tType ftype, register tType argtype, int i)
# else
(ftype, argtype, i)
 register tType ftype;
 register tType argtype;
 int i;
# endif
{
/* line 50 "sumerrors.puma" */
  {
/* line 51 "sumerrors.puma" */
fprintf(fileptr,"      actual type: ");
		DecodeType(argtype);
		fprintf(fileptr,"\n      expected type: ");
		DecodeType(ftype);
		fprintf(fileptr,"\n\n");
  }
   return;

;
}

void ErrorInFnResult
# if defined __STDC__ | defined __cplusplus
(register tType ftype, register tType rtype)
# else
(ftype, rtype)
 register tType ftype;
 register tType rtype;
# endif
{
/* line 59 "sumerrors.puma" */
  {
/* line 60 "sumerrors.puma" */
fprintf(fileptr,"      actual result type: ");
		DecodeType(rtype);
		fprintf(fileptr,"\n      expected result type: ");
		DecodeType(ftype);
		fprintf(fileptr,"\n\n");
  }
   return;

;
}

void ErrorInPrefixNoArg
# if defined __STDC__ | defined __cplusplus
(tIdent preId)
# else
(preId)
 tIdent preId;
# endif
{
/* line 68 "sumerrors.puma" */
  {
/* line 69 "sumerrors.puma" */
fprintf(fileptr,"      no type generated for the argument of the prefix function");
		fprintf(fileptr,"\n      prefix name: ");
		WriteIdent(fileptr,preId);
		fprintf(fileptr,"\n\n");
  }
   return;

;
}

void ErrorInPrefix
# if defined __STDC__ | defined __cplusplus
(tIdent preId, register tType argtype)
# else
(preId, argtype)
 tIdent preId;
 register tType argtype;
# endif
{
/* line 77 "sumerrors.puma" */
  {
/* line 78 "sumerrors.puma" */
fprintf(fileptr,"      prefix name: ");
		WriteIdent(fileptr,preId);
		fprintf(fileptr,"\n      argument type: ");
		DecodeType(argtype);
		fprintf(fileptr,"\n\n");
  }
   return;

;
}

void ErrorInInfix
# if defined __STDC__ | defined __cplusplus
(tIdent inId, register tType ltype, register tType rtype)
# else
(inId, ltype, rtype)
 tIdent inId;
 register tType ltype;
 register tType rtype;
# endif
{
/* line 87 "sumerrors.puma" */
  {
/* line 88 "sumerrors.puma" */
fprintf(fileptr,"      left operator type: ");
		DecodeType(ltype);
		fprintf(fileptr,"\n      infix name: ");
		WriteIdent(fileptr,inId);
		fprintf(fileptr,"\n      right operator type: ");
		DecodeType(rtype);
		fprintf(fileptr,"\n\n");
  }
   return;

;
}

void NoMoreFncOverloads
# if defined __STDC__ | defined __cplusplus
(register tType ftype, register tType argtype)
# else
(ftype, argtype)
 register tType ftype;
 register tType argtype;
# endif
{
  if (ftype->Kind == kTp_Cart) {
/* line 98 "sumerrors.puma" */
  {
/* line 99 "sumerrors.puma" */
fprintf(fileptr,"      argument type: ");
		DecodeType(argtype);
		fprintf(fileptr,"\n      function type: ");
		DecodeTpCartListOver(ftype);
		fprintf(fileptr,"\n\n");
  }
   return;

  }
/* line 104 "sumerrors.puma" */
  {
/* line 105 "sumerrors.puma" */
fprintf(fileptr,"      argument type: ");
		DecodeType(argtype);
		fprintf(fileptr,"\n      function type: ");
		DecodeType(ftype);
		fprintf(fileptr,"\n\n");
  }
   return;

;
}

void NoMorePrefixOverloads
# if defined __STDC__ | defined __cplusplus
(tIdent preId, register tType ftype, register tType argtype)
# else
(preId, ftype, argtype)
 tIdent preId;
 register tType ftype;
 register tType argtype;
# endif
{
  if (ftype->Kind == kTp_Cart) {
/* line 113 "sumerrors.puma" */
  {
/* line 114 "sumerrors.puma" */
fprintf(fileptr,"      argument type: ");
		DecodeType(argtype);
		fprintf(fileptr,"\n      prefix name: ");
		WriteIdent(fileptr,preId);
		fprintf(fileptr,"\n      prefix type: ");
		DecodeTpCartListOver(ftype);
		fprintf(fileptr,"\n\n");
  }
   return;

  }
/* line 121 "sumerrors.puma" */
  {
/* line 122 "sumerrors.puma" */
fprintf(fileptr,"     argument type: ");
		DecodeType(argtype);
		fprintf(fileptr,"\n      prefix name: ");
		WriteIdent(fileptr,preId);
		fprintf(fileptr,"\n      prefix  type: ");
		DecodeType(ftype);
		fprintf(fileptr,"\n\n");
  }
   return;

;
}

void NoMoreInfixOverloads
# if defined __STDC__ | defined __cplusplus
(tIdent inId, register tType ftype, register tType ltype, register tType rtype)
# else
(inId, ftype, ltype, rtype)
 tIdent inId;
 register tType ftype;
 register tType ltype;
 register tType rtype;
# endif
{
  if (ftype->Kind == kTp_Cart) {
/* line 132 "sumerrors.puma" */
  {
/* line 133 "sumerrors.puma" */
fprintf(fileptr,"      left operator type: ");
		DecodeType(ltype);
		fprintf(fileptr,"\n      infix name: ");
		WriteIdent(fileptr,inId);
		fprintf(fileptr,"\n      infix type: ");
		DecodeTpCartListOver(ftype);
		fprintf(fileptr,"\n      right operator type: ");
		DecodeType(rtype);
		fprintf(fileptr,"\n\n");
  }
   return;

  }
/* line 142 "sumerrors.puma" */
  {
/* line 143 "sumerrors.puma" */
fprintf(fileptr,"      left operator type: ");
		DecodeType(ltype);
		fprintf(fileptr,"\n      infix name: ");
		WriteIdent(fileptr,inId);
		fprintf(fileptr,"\n      infix type: ");
		DecodeType(ftype);
		fprintf(fileptr,"\n      right operator type: ");
		DecodeType(rtype);
		fprintf(fileptr,"\n\n");
  }
   return;

;
}

static void LocalWriteIdPos
# if defined __STDC__ | defined __cplusplus
(tIdPos id)
# else
(id)
 tIdPos id;
# endif
{
/* line 155 "sumerrors.puma" */
  {
/* line 156 "sumerrors.puma" */
char str[256];
	int i,j,len;
	GetString(id.Ident,str);
	fprintf(fileptr,"%s",str);
	
  }
   return;

;
}

static void UnparseIdList
# if defined __STDC__ | defined __cplusplus
(register tTree yyP1)
# else
(yyP1)
 register tTree yyP1;
# endif
{
  if (yyP1->Kind == kNoId) {
/* line 164 "sumerrors.puma" */
   return;

  }
  if (yyP1->Kind == kId) {
/* line 165 "sumerrors.puma" */
  {
/* line 166 "sumerrors.puma" */
LocalWriteIdPos(yyP1->Id.Ident);
		if (Tree_IsType(yyP1->Id.Next,kId))
			{fprintf(fileptr,",");
			UnparseIdList(yyP1->Id.Next);}
  }
   return;

  }
;
}

void ErrorInName
# if defined __STDC__ | defined __cplusplus
(register tTree id)
# else
(id)
 register tTree id;
# endif
{
  if (id->Kind == kId) {
/* line 173 "sumerrors.puma" */
  {
/* line 173 "sumerrors.puma" */
fprintf(fileptr,"      name is: ");
		UnparseIdList(id);
		fprintf(fileptr,"\n");
  }
   return;

  }
/* line 176 "sumerrors.puma" */
  {
/* line 176 "sumerrors.puma" */
fprintf(fileptr,"no name given\n");
  }
   return;

;
}

void ErrorInThetaName
# if defined __STDC__ | defined __cplusplus
(register tType exp)
# else
(exp)
 register tType exp;
# endif
{
/* line 180 "sumerrors.puma" */
  {
/* line 181 "sumerrors.puma" */
fprintf(fileptr,"type of theta name: ");
	DecodeType(exp);
	fprintf(fileptr,"\n\n");
  }
   return;

;
}

void BeginSumErrors ()
{
}

void CloseSumErrors ()
{
}
