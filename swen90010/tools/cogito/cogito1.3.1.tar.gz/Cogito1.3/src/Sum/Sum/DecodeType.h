# ifndef yyDecodeType
# define yyDecodeType

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "Type.h"

/* line 9 "decodetype.puma" */

#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "env.h"
#include "Type.h"


extern void (* DecodeType_Exit) ();

extern void DecodeType ARGS((tType t));
extern void DecodeTpCartList ARGS((tType c, char ch));
extern void DecodeTpCartListOver ARGS((tType c));

extern void BeginDecodeType ();
extern void CloseDecodeType ();

# endif
