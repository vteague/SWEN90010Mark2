# ifndef yySumTreeAccess
# define yySumTreeAccess

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "Tree.h"

/* line 9 "sumtree.puma" */

#include "Idents.h"
#include "Positions.h"
#include "global.h"
#include "env.h"
#include "Tree.h"


extern void (* SumTreeAccess_Exit) ();

extern tTree CatDeclList ARGS((tTree d1, tTree d2));
extern tTree CatPredList ARGS((tTree p1, tTree p2));
extern tTree FormalParams2CartProd ARGS((tTree yyP1));
extern tTree CatFormalParams ARGS((tTree f1, tTree f2));
extern tTree CatExpressionList ARGS((tTree e1, tTree e2));
extern bool InImportList ARGS((tIdPos n, tTree yyP4));
extern bool InIdList ARGS((tIdPos n, tTree yyP5));

extern void BeginSumTreeAccess ();
extern void CloseSumTreeAccess ();

# endif
