# ifndef yycopymod
# define yycopymod

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# ifndef bool
# define bool char
# endif

# include "Syms.h"
# include "Type.h"
# include "Tree.h"

/* line 6 "CopySyms.puma" */



extern void (* copymod_Exit) ();

extern tObjects InstMod ARGS((tObjects Mod, tIdent NewId));

extern void Begincopymod ();
extern void Closecopymod ();

# endif
