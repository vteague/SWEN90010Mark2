# ifndef yyBuildSymtab
# define yyBuildSymtab

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# include "ZTree.h"

/* line 221 "z.ast" */

#include "Idents.h" 
#include "Positions.h"
#include "global.h" 
#include "ZTreeAccess.h"
#include "ZSumAccess.h"
#include "ZSyms.h"

/* line 249 "z.ast" */

#include "Idents.h" 
#include "Positions.h"
#include "global.h" 
#include <stdio.h>


extern void BuildSymtab ARGS((tZTree yyt));
extern void BeginBuildSymtab ();
extern void CloseBuildSymtab ();

# endif
