# ifndef yySyms
# define yySyms

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif


# ifndef bool
# define bool char
# endif
# define NoSyms (tSyms) 0L
# define kObjects 1
# define kNoObject 2
# define kObject 3
# define kObj_Inn 4
# define kObj_TyId 5
# define kObj_Id 6
# define kObj_Tmp 7
# define kObj_Param 8
# define kObj_PTyId 9
# define kObj_PId 10

typedef unsigned char Syms_tKind;
typedef unsigned short Syms_tMark;
typedef unsigned short Syms_tLabel;
typedef union Syms_Node * tSyms;
typedef void (* Syms_tProcTree) ();
/* line 7 "Objects.cg" */

#define tObjects tSyms
#define NoSym (tSyms) 0L  

#include "Idents.h"
#include "Tree.h"
#include <string.h>
#include "Type.h"
#include "global.h"
#include "Positions.h"
#include "ratc.h"
#include <fcntl.h>

extern void     ObjPrint ();
extern void     PrintSymTab();
extern void     ImportHandler();
extern void     RenameHandler();
extern tSyms    ReadModule();
extern tSyms    ReadObj();
extern void     WriteModule();
extern void     WriteObj();
extern tObjects mObj_IdList();
extern bool     SchFldIsDeclared();
extern bool     IsDeclared(); 
extern bool     IsAxiomDeclared(); 
extern tObjects LookUp();
extern tObjects LookUpInn(); 
extern tObjects LookUpName(); 
extern tObjects StateIncl();
extern void     WriteTy();
extern tType    ReadType();
extern void     WriteId();
extern tIdent   ReadId();
extern void     VisibleH();
extern tObjects SchIncl();
extern tObjects SchInclD();
extern void     PrintMod();
extern tIdent   ImportAsMod();
/* bug trace extern void PrintBTvalues();*/

#define MathPathLength 128 

extern char *Argv[];
extern int Argc;


# ifndef Syms_NodeHead
# define Syms_NodeHead
# endif
typedef struct { Syms_tKind yyKind; Syms_tMark yyMark; Syms_NodeHead } Syms_tNodeHead;
typedef struct { Syms_tNodeHead yyHead; } yObjects;
typedef struct { Syms_tNodeHead yyHead; } yNoObject;
typedef struct { Syms_tNodeHead yyHead; tSyms Next; tSyms Pre; tIdent ModId; tType Type; tIdent Ident; bool IsSelected; bool Tag; } yObject;
typedef struct { Syms_tNodeHead yyHead; tSyms Next; tSyms Pre; tIdent ModId; tType Type; tIdent Ident; bool IsSelected; bool Tag; tSyms Inner; int ObjKind; bool Visible; bool ImportHasAsPart; } yObj_Inn;
typedef struct { Syms_tNodeHead yyHead; tSyms Next; tSyms Pre; tIdent ModId; tType Type; tIdent Ident; bool IsSelected; bool Tag; } yObj_TyId;
typedef struct { Syms_tNodeHead yyHead; tSyms Next; tSyms Pre; tIdent ModId; tType Type; tIdent Ident; bool IsSelected; bool Tag; tIdent QuId; int VarKind; } yObj_Id;
typedef struct { Syms_tNodeHead yyHead; tSyms Next; tSyms Pre; tIdent ModId; tType Type; tIdent Ident; bool IsSelected; bool Tag; tSyms Inner; } yObj_Tmp;
typedef struct { Syms_tNodeHead yyHead; tSyms Next; tSyms Pre; tIdent ModId; tType Type; tIdent Ident; bool IsSelected; bool Tag; } yObj_Param;
typedef struct { Syms_tNodeHead yyHead; tSyms Next; tSyms Pre; tIdent ModId; tType Type; tIdent Ident; bool IsSelected; bool Tag; } yObj_PTyId;
typedef struct { Syms_tNodeHead yyHead; tSyms Next; tSyms Pre; tIdent ModId; tType Type; tIdent Ident; bool IsSelected; bool Tag; } yObj_PId;

union Syms_Node {
 Syms_tKind Kind;
 Syms_tNodeHead yyHead;
 yObjects Objects;
 yNoObject NoObject;
 yObject Object;
 yObj_Inn Obj_Inn;
 yObj_TyId Obj_TyId;
 yObj_Id Obj_Id;
 yObj_Tmp Obj_Tmp;
 yObj_Param Obj_Param;
 yObj_PTyId Obj_PTyId;
 yObj_PId Obj_PId;
};

extern tSyms SymsRoot;
extern unsigned long Syms_HeapUsed;
extern char * Syms_PoolFreePtr, * Syms_PoolMaxPtr;
extern unsigned short Syms_NodeSize [10 + 1];
extern char * Syms_NodeName [10 + 1];

extern void (* Syms_Exit) ();
extern tSyms Syms_Alloc ();
extern tSyms MakeSyms ARGS((Syms_tKind yyKind));
extern bool Syms_IsType ARGS((register tSyms yyt, register Syms_tKind yyKind));

extern tSyms mObjects ARGS(());
extern tSyms mNoObject ARGS(());
extern tSyms mObject ARGS((tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected));
extern tSyms mObj_Inn ARGS((tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected, tSyms pInner, int pObjKind, bool pVisible));
extern tSyms mObj_TyId ARGS((tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected));
extern tSyms mObj_Id ARGS((tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected, tIdent pQuId, int pVarKind));
extern tSyms mObj_Tmp ARGS((tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected, tSyms pInner));
extern tSyms mObj_Param ARGS((tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected));
extern tSyms mObj_PTyId ARGS((tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected));
extern tSyms mObj_PId ARGS((tSyms pNext, tSyms pPre, tIdent pModId, tType pType, tIdent pIdent, bool pIsSelected));

extern void WriteSyms ARGS((FILE * yyyf, tSyms yyt));
extern void TraverseSymsTD ARGS((tSyms yyt, Syms_tProcTree yyyProc));
extern tSyms ReverseSyms ARGS((tSyms yyOld));
extern tSyms CopySyms ARGS((tSyms yyt));
extern void BeginSyms ();
extern void CloseSyms ();

# endif
