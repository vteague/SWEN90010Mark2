# ifndef yyTS_Semantics
# define yyTS_Semantics

# if defined __STDC__ | defined __cplusplus
# define ARGS(parameters)	parameters
# else
# define ARGS(parameters)	()
# endif

# include "Type.h"


extern void TS_Semantics ARGS((tType yyt));
extern void BeginTS_Semantics ();
extern void CloseTS_Semantics ();

# endif
